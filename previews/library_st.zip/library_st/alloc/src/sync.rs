#![stable(feature = "rust1", since = "1.0.0")]

//! Litlhahiso tsa ho bala litšupiso tse sireletsehileng ka khoele.
//!
//! Bona litokomane tsa [`Arc<T>`][Arc] bakeng sa lintlha tse ling.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Moeli o bonolo palong ea litšupiso tse ka etsoang ho `Arc`.
///
/// Ho feta moeli ona ho tla ntšetsa lenaneo la hau (leha ho se joalo) ho litšupiso tsa _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ha e tšehetse terata ea memori.
// Ho qoba litlaleho tse ntle tsa bohata ho ts'ebetsong ea Arc/Weak sebelisa mejaro ea athomo bakeng sa khokahano ho fapana.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Sesupi sa ho bala se sireletsehileng ka khoele.'Arc' e emetse 'Atomically Reference Counted'.
///
/// Mofuta oa `Arc<T>` o fana ka boleng bo arolelanoeng ba boleng ba mofuta oa `T`, bo abiloeng qubung.Ho mema [`clone`][clone] ho `Arc` ho hlahisa mohlala o mocha oa `Arc`, o supang kabo e tšoanang qubu e le mohloli `Arc`, ha o ntse o eketsa palo ea litšupiso.
/// Ha sesupa sa ho qetela sa `Arc` se fanoeng se senyeha, boleng bo bolokiloeng kabo eo (bo atisang ho bitsoa "inner value") le bona boa theoha.
///
/// Litemana tse arolelanoeng ho Rust ha li lumelle phetoho ka bo eona, 'me `Arc` ha e felle moo: ka kakaretso u ke ke ua fumana polelo e ka fetohang ea ntho e ka hare ho `Arc`.Haeba o hloka ho fetoha ka `Arc`, sebelisa [`Mutex`][mutex], [`RwLock`][rwlock], kapa e 'ngoe ea mefuta ea [`Atomic`][atomic].
///
/// ## Ts'ireletso ea Khoele
///
/// Ho fapana le [`Rc<T>`], `Arc<T>` e sebelisa ts'ebetso ea athomo bakeng sa ho bala ha eona.Sena se bolela hore e bolokehile ka khoele.Bothata ke hore ts'ebetso ea athomo e theko e phahameng ho feta mokhoa o tloaelehileng oa ho hopola.Haeba o sa arolelane likabo tse baloang ka mokhoa oa litšupiso lipakeng tsa likhoele, nahana ka ho sebelisa [`Rc<T>`] bakeng sa hlooho e tlase.
/// [`Rc<T>`] ke default e sireletsehileng, hobane moqapi o tla ts'oara boiteko bofe kapa bofe ba ho romella [`Rc<T>`] lipakeng tsa likhoele.
/// Leha ho le joalo, laeborari e kanna ea khetha `Arc<T>` molemong oa ho fa bareki ba laeborari maemo a bonolo haholoanyane.
///
/// `Arc<T>` e tla kenya tšebetsong [`Send`] le [`Sync`] ha feela `T` e kenya [`Send`] le [`Sync`].
/// Hobaneng o sa khone ho beha mofuta o sa sireletsehang oa `T` ho `Arc<T>` ho o etsa o sireletsehile ka khoele?Sena e kanna ea ba se khahlanong le tlhaiso-leseling qalong: ha e le hantle, na ha se ntlha ea polokeho ea khoele ea `Arc<T>`?Senotlolo ke sena: `Arc<T>` e etsa hore khoele e bolokehe hore e be le beng ba data e tšoanang, empa ha e kenye polokeho ea likhoele ho data ea eona.
///
/// Nahana ka `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ha se [`Sync`], 'me haeba `Arc<T>` e ne e lula e le [`Send`], `Arc <` [`RefCell<T>`]`>`ho tla ba joalo.
/// Empa joale re tla ba le bothata:
/// [`RefCell<T>`] ha e sireletsehe ka khoele;e boloka palo ea kalimo e sebelisa ts'ebetso eo e seng ea athomo.
///
/// Qetellong, sena se bolela hore o kanna oa hloka ho para `Arc<T>` le mofuta o itseng oa [`std::sync`], hangata [`Mutex<T>`][mutex].
///
/// ## Ho senya mekhahlelo le `Weak`
///
/// Mokhoa oa [`downgrade`][downgrade] o ka sebelisoa ho theha sesupa sa [`Weak`] seo e seng sa sona.Sesupi sa [`Weak`] e ka ba [`apkreite`][ntlafatsa] d ho `Arc`, empa sena se tla khutlisa [`None`] haeba boleng bo bolokiloeng kabo bo se bo theotsoe.
/// Ka mantsoe a mang, litsupa tsa `Weak` ha li boloke boleng bo ka hare ho kabo bo phela;leha ho le joalo, ba etsa * boloka kabelo (lebenkele le tšehetsang boleng) e phela.
///
/// Potoloho pakeng tsa lits'oants'o tsa `Arc` e ke ke ea hlola e tsamaisoa.
/// Ka lebaka lena, [`Weak`] e sebelisetsoa ho senya lipotoloho.Mohlala, sefate se ka ba le lipontšo tse matla tsa `Arc` ho tloha linotong tsa motsoali ho isa baneng, le litlhahiso tsa [`Weak`] ho tloha ho bana ho khutlela ho batsoali ba bona.
///
/// # Litšupiso tsa Cloning
///
/// Ho theha sets'oants'o se secha ho tsoa ho sesupa-palo se seng se ntse se baloa ho etsoa ho sebelisoa `Clone` trait e kentsoeng [`Arc<T>`][Arc] le [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Li-syntax tse peli tse ka tlase lia lekana.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, le foo kaofela ke li-Arcs tse supang sebakeng se le seng sa memori
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` e itlhalosa ka bo eona ho `T` (ka [`Deref`][deref] trait), o tle o letsetse mekhoa ea `T` ka boleng ba mofuta oa `Arc<T>`.Ho qoba likhohlano tsa mabitso le mekhoa ea `T`, mekhoa ea `Arc<T>` ka boeona ke mesebetsi e amanang, e bitsoang ho sebelisa [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Ts'ebetsong ea traits joalo ka `Clone` e kanna ea bitsoa ho sebelisa syntax e tšoanelehang ka botlalo.
/// Batho ba bang ba khetha ho sebelisa syntax e tšoanelehang ka botlalo, ha ba bang ba khetha ho sebelisa syntax ea mohala.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax ea mokhoa
/// let arc2 = arc.clone();
/// // Syntax e tšoanelehang ka botlalo
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ha e itlhahise ka ho iketsa `T`, hobane boleng ba kahare e kanna eaba e se e theohile.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ho arolelana lintlha tse sa fetoheng lipakeng tsa likhoele:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Hlokomela hore re **ha re** etsa liteko tsena mona.
// Lihahi tsa windows ha li thabe haholo ha khoele e feta khoele ea mantlha ebe e tsoa ka nako e ts'oanang (ho na le ho hong ho thibetsoeng) ka hona re qoba sena ka botlalo ka ho se sebelise liteko tsena.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ho arolelana [`AtomicUsize`] e ka fetohang:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Bona [`rc` documentation][rc_examples] bakeng sa mehlala e meng ea ho bala litšupiso ka kakaretso.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ke mofuta oa [`Arc`] o ts'oereng boits'oaro bo seng ba eona ho kabo e laoloang.
/// Kabo e fumaneha ka ho letsetsa [`upgrade`] ho pointer ea `Weak`, e khutlisetsang [`Khetho`]`<<`[`Arc`] `<T>>``.
///
/// Kaha ts'ebetso ea `Weak` ha e itšetlehe ka beng ba eona, e ke ke ea thibela boleng bo bolokiloeng kabo hore bo se ke ba theoleloa, 'me `Weak` ka boeona ha e fane ka tiiso ea boleng bo ntseng bo le teng.
///
/// Kahoo e kanna ea khutlisa [`None`] ha [`ntlafatso`] d.
/// Hlokomela leha ho le joalo hore `Weak` reference * ha e thibele kabo ka boyona (lebenkele le tšehetsang) hore le se ke la tsamaisoa.
///
/// Pointer ea `Weak` e na le thuso bakeng sa ho boloka tšupiso ea nakoana ho kabo e laoloang ke [`Arc`] ntle le ho thibela boleng ba eona ba ka hare hore bo se ke ba liheloa.
/// E boetse e sebelisetsoa ho thibela litšupiso tse chitja lipakeng tsa litlhahiso tsa [`Arc`], hobane ho ba le litšupiso ka bobeli ho ke ke ha lumella [`Arc`] hore e liheloe.
/// Mohlala, sefate se ka ba le lipontšo tse matla tsa [`Arc`] ho tloha linotong tsa motsoali ho isa ho bana, le litlhahiso tsa `Weak` ho tloha ho bana ba khutlela ho batsoali ba bona.
///
/// Mokhoa o tloaelehileng oa ho fumana sesupa sa `Weak` ke ho letsetsa [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ena ke `NonNull` ho lumella ho ntlafatsa boholo ba mofuta ona ka li-enum, empa ha se hakaalo hore ke sesupi se nepahetseng.
    //
    // `Weak::new` e beha sena ho `usize::MAX` hore e se hloke ho fana ka sebaka qubung.
    // Seo ha se boleng ba pointer ea 'nete bo tla ba le eona hobane RcBox e hokahane le bonyane 2.
    // Sena se ka etsahala feela ha `T: Sized`;`T` e sa lekanyetsoang le ka mohla ha e thekesele.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Hona ke bopaki ba repr(C) ho future khahlano le ho hlophisa bocha masimong, ho ka sitisang [into|from]_raw() e sireletsehileng ea mefuta e ka hare e fetisoang.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // boleng usize::MAX e sebetsa joalo ka sentinel bakeng sa "locking" ka nakoana bokhoni ba ho ntlafatsa lits'oants'o tse fokolang kapa ho theola tse matla;sena se sebelisetsoa ho qoba merabe ho `make_mut` le `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// E theha `Arc<T>` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Qala palo e fokolang ea sesupi e le 1 e supang e fokolang e ts'oeroeng ke litsupa tsohle tse matla (kinda), bona std/rc.rs bakeng sa tlhaiso-leseling e batsi
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// E theha `Arc<T>` e ncha e sebelisa lebitso le fokolang ho eona.
    /// Ho leka ho ntlafatsa litšupiso tse fokolang pele mosebetsi ona o khutla ho tla hlahisa boleng ba `None`.
    /// Leha ho le joalo, litšupiso tse fokolang li ka etsoa ka bolokolohi ebe li bolokoa hore li tle li sebelisoe hamorao.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Theha bokantle seterekeng sa "uninitialized" ka mokhoa o le mong o fokolang.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ho bohlokoa hore re se tlohele ho ba sesupi se fokolang, ho seng joalo mohopolo o kanna oa lokolloa ka nako ea `data_fn`.
        // Haeba re ne re hlile re batla ho fetisa beng, re ka iketsetsa sesupi se fokolang, empa sena se ka fella ka lintlafatso tse ling ho palo e fokolang ea litšupiso e kanna ea se hlokehe ka tsela e ngoe.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Hona joale re ka qala boleng ba ka hare ka nepo mme ra fetola litšupiso tsa rona tse fokolang hore e be litšupiso tse matla.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Lintlha tse kaholimo tse ngoliloeng lebaleng la data li tlameha ho bonahala ho likhoele life kapa life tse bolokang palo e se nang zero.
            // Ka hona re hloka bonyane odara ea "Release" molemong oa ho hokahanya le `compare_exchange_weak` ho `Weak::upgrade`.
            //
            // "Acquire" ho hlopha ha ho hlokehe.
            // Ha re nahana ka boits'oaro bo ka bang teng ba `data_fn` re hloka feela ho sheba hore na e ka etsa eng ha ho buuoa ka `Weak` e sa ntlafatsoeng:
            //
            // - E ka ts'oara * `Weak`, ea eketsa palo e fokolang ea litšupiso.
            // - E ka theola li-clone tseo, ea fokotsa palo e fokolang ea litšupiso (empa e se ke ea fihla ho zero).
            //
            // Litla-morao tsena ha li re ame ka tsela efe kapa efe, 'me ha ho litla-morao tse ling tse ka etsahalang ka khoutu e bolokehileng feela.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Litšupiso tse matla li lokela ho ba le litšupiso tse fokolang tse arolelanoeng, ka hona o se ke oa tsamaisa mosenyi bakeng sa ts'upiso ea rona ea khale e fokolang.
        //
        mem::forget(weak);
        strong
    }

    /// E theha `Arc` e ncha e nang le litaba tse sa qalisoang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// E theha `Arc` e ncha e nang le litaba tse sa qalisoang, mohopolo o tlatsoa ka li-byte tsa `0`.
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// E theha `Pin<Arc<T>>` e ncha.
    /// Haeba `T` e sa sebelise `Unpin`, `data` e tla manehoa mohopolong ebe e sitoa ho sisinyeha.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// E theha `Arc<T>` e ncha, e khutlisetsang phoso haeba kabo e sa atlehe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Qala palo e fokolang ea sesupi e le 1 e supang e fokolang e ts'oeroeng ke litsupa tsohle tse matla (kinda), bona std/rc.rs bakeng sa tlhaiso-leseling e batsi
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// E theha `Arc` e ncha e nang le litaba tse sa qalisoang, e khutlisa phoso haeba kabo e sa atlehe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// E theha `Arc` e ncha e nang le litaba tse sa qalisoang, mohopolo o tlatsitsoe ka li-byte tsa `0`, e khutlisa phoso haeba kabo e sa atlehe.
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// E khutlisa boleng ba kahare, haeba `Arc` e na le ts'upiso e le 'ngoe e matla.
    ///
    /// Ho seng joalo, [`Err`] e khutlisoa le `Arc` e tšoanang e ileng ea fetisoa.
    ///
    ///
    /// Sena se tla atleha leha ho na le litšupiso tse fokolang tse fokolang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Etsa sesupi se fokolang ho hloekisa ts'upiso e matla e fokolang
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// E theha selae se secha se baloang ka litšupiso se nang le likateng tse sa qalisoang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// E theha selae se secha se baloang ka litšupiso se nang le likateng tse sa qalisoang, mohopolo o tlatsoa ka li-byte tsa `0`.
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Fetolela ho `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Joalo ka [`MaybeUninit::assume_init`], ho ho motho ea letsitseng ho netefatsa hore boleng ba kahare bo maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlalosehang hanghang.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Fetolela ho `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Joalo ka [`MaybeUninit::assume_init`], ho ho motho ea letsitseng ho netefatsa hore boleng ba kahare bo maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlalosehang hanghang.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// E sebelisa `Arc`, e khutlisa sesupa se phuthetsoeng.
    ///
    /// Ho qoba ho lutla ha mohopolo sesupi se tlameha ho khutlisetsoa ho `Arc` ho sebelisoa [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// E fana ka sesupa e tala ho data.
    ///
    /// Lipalo ha li amehe ka tsela efe kapa efe 'me `Arc` ha e sebelisoe.
    /// Sesupi se sebetsa ha feela ho na le lipalo tse matla ho `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // TSHIRELETSO: Sena se ke ke sa feta Deref::deref kapa RcBoxPtr::inner hobane
        // sena se hlokahala ho boloka projeke ea raw/mut joalo ka mohlala
        // `get_mut` E ka ngola ka sesupa ka mor'a hore Rc e fole ka `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// E theha `Arc<T>` ho tsoa pointer e tala.
    ///
    /// Pointer e tala e tlameha ebe e ne e khutlisitsoe pejana ka mohala o eang ho [`Arc<U>::into_raw`][into_raw] moo `U` e tlamehang ho ba le boholo le tatellano e tšoanang le `T`.
    /// Sena ke 'nete haholo haeba `U` ke `T`.
    /// Hlokomela hore haeba `U` e se `T` empa e na le boholo le tatellano e ts'oanang, hona ho tšoana le ho fetisa litšupiso tsa mefuta e fapaneng.
    /// Bona [`mem::transmute`][transmute] bakeng sa tlhaiso-leseling e batsi mabapi le lithibelo life tse sebetsang ntlheng ena.
    ///
    /// Mosebelisi oa `from_raw` o tlameha ho etsa bonnete ba hore boleng bo itseng ba `T` bo theoha hanngoe feela.
    ///
    /// Mosebetsi ona ha o bolokehe hobane ts'ebeliso e fosahetseng e kanna ea etsa hore mohopolo o se bolokehe, leha `Arc<T>` e khutlisitsoeng e sa fihlelloe.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Fetolela ho `Arc` ho thibela ho dutla.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Mehala e meng e eang ho `Arc::from_raw(x_ptr)` e ka se bolokehe mohopolong.
    /// }
    ///
    /// // Memori e ile ea lokolloa ha `x` e tsoa boemong bo kaholimo, ka hona `x_ptr` e ntse e leketla!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Khutlisa offset ho fumana ArcInner ea mantlha.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// E theha sesupisi se secha sa [`Weak`] kabo ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Sena se phutholohile se lokile hobane re ntse re sheba boleng ho CAS e ka tlase.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // hlahloba hore na khaontara e fokolang hona joale ke "locked";haeba ho joalo, ohla.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: khoutu ena hajoale e hlokomoloha monyetla oa ho phalla
            // ho kena usize::MAX;ka kakaretso Rc le Arc li hloka ho fetoloa ho sebetsana le ho khaphatseha.
            //

            // Ho fapana le Clone(), re hloka hore ena e be Acquire e balloang hore e lumellane le mongolo o tsoang ho `is_unique`, e le hore liketsahalo tsa pele ho sengolo tseo li etsahale pele sena se baloa.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Etsa bonnete ba hore ha re thehe Bofokoli bo leketlileng
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// E fumana palo ea litlhahiso tsa [`Weak`] kabo ena.
    ///
    /// # Safety
    ///
    /// Mokhoa ona ka bo oona o bolokehile, empa ho o sebelisa ka nepo ho hloka tlhokomelo e eketsehileng.
    /// Khoele e ngoe e ka fetola palo e fokolang ka nako efe kapa efe, ho kenyeletsoa le monyetla oa ho ba teng pakeng tsa ho bitsa mokhoa ona le ho latela sephetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Tlhahiso ena ke ea qeto hobane ha rea arolelana `Arc` kapa `Weak` lipakeng tsa likhoele.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Haeba palo e fokolang e koetsoe hona joale, boleng ba palo e ne e le 0 pele a nka loko.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// E fumana palo ea litlhahiso tse matla tsa (`Arc`) kabo ena.
    ///
    /// # Safety
    ///
    /// Mokhoa ona ka bo oona o bolokehile, empa ho o sebelisa ka nepo ho hloka tlhokomelo e eketsehileng.
    /// Khoele e ngoe e ka fetola palo e matla ka nako efe kapa efe, ho kenyeletsoa le monyetla oa ho ba teng pakeng tsa ho bitsa mokhoa ona le ho nka khato ka sephetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Tlhahiso ena ke ea qeto hobane ha rea arolelana `Arc` lipakeng tsa likhoele.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// E eketsa palo e matla ea litšupiso ho `Arc<T>` e amanang le sesupa se fanoeng ka bonngoe.
    ///
    /// # Safety
    ///
    /// Sesupa se tlameha ebe se fumanoe ka `Arc::into_raw`, 'me mohlala o amanang le `Arc` o tlameha ho sebetsa (ke hore
    /// palo e matla e tlameha ho ba bonyane 1) bakeng sa nako ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tlhahiso ena ke ea qeto hobane ha rea arolelana `Arc` lipakeng tsa likhoele.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Boloka Arc, empa u se ke oa ama repcount ka ho phuthela ho ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Hona joale eketsa ho bala, empa u se ke ua tlohela ho bala hape
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ho fokotsa palo e matla ea litšupiso ho `Arc<T>` e amanang le sesupa se fanoeng ka bonngoe.
    ///
    /// # Safety
    ///
    /// Sesupa se tlameha ebe se fumanoe ka `Arc::into_raw`, 'me mohlala o amanang le `Arc` o tlameha ho sebetsa (ke hore
    /// palo e matla e tlameha ho ba bonyane 1) ha ho sebelisoa mokhoa ona.
    /// Mokhoa ona o ka sebelisoa ho lokolla `Arc` ea ho qetela le polokelo ea tšehetso, empa **ha ea lokela ho bitsoa** kamora hore `Arc` ea ho qetela e lokolloe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Maikemisetso ao ke a qeto hobane ha rea arolelana `Arc` lipakeng tsa likhoele.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ho se sireletsehe hona ho lokile hobane ha arc ena e ntse e phela re netefalitsoe hore sesupa-hare se nepahetse.
        // Ntle le moo, rea tseba hore sebopeho sa `ArcInner` ka boeona ke `Sync` hobane data ea ka hare le eona ke `Sync`, ka hona re hantle ho alima sesupi se sa fetoheng ho litaba tsena.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Karolo e sa ngolisoang ea `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Senya data ka nako ena, leha re kanna ra se lokolle kabelo ea mabokose ka boeona (ho kanna ha ba le lits'oants'o tse fokolang tse rapameng).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Lahlela litšupiso tse fokolang tse kopantsoeng ke litšupiso tsohle tse matla
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// E khutlisa `true` haeba `Arc` tse peli li supa kabo e tšoanang (ka mothapong o ts'oanang le [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// E aba `ArcInner<T>` e nang le sebaka se lekaneng bakeng sa boleng ba ka hare bo sa lekanyetsoang moo boleng bo nang le sebopeho se fanoeng.
    ///
    /// Mosebetsi `mem_to_arcinner` o bitsoa ka pointer ea data mme o tlameha ho khutlisa sekontiri (se ka bang mafura) bakeng sa `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Sebetsa moralo ka ho sebelisa sebopeho se fanoeng sa boleng.
        // Pejana, sebopeho se ne se baloa polelong ea `&*(ptr as* const ArcInner<T>)`, empa sena se thehile litšupiso tse fosahetseng (bona #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// E aba `ArcInner<T>` e nang le sebaka se lekaneng bakeng sa boleng ba ka hare bo sa lekanyetsoang moo boleng bo nang le sebopeho se fanoeng, ho khutlisa phoso haeba kabo e sa atlehe.
    ///
    ///
    /// Mosebetsi `mem_to_arcinner` o bitsoa ka pointer ea data mme o tlameha ho khutlisa sekontiri (se ka bang mafura) bakeng sa `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Sebetsa moralo ka ho sebelisa sebopeho se fanoeng sa boleng.
        // Pejana, sebopeho se ne se baloa polelong ea `&*(ptr as* const ArcInner<T>)`, empa sena se thehile litšupiso tse fosahetseng (bona #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Qala ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// E aba `ArcInner<T>` e nang le sebaka se lekaneng bakeng sa boleng bo ka hare bo sa lekanyetsoang.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Abela `ArcInner<T>` u sebelisa boleng bo fanoeng.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopitsa boleng joaloka li-byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Lokolla kabelo ntle le ho lahla litaba tsa eona
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// E aba `ArcInner<[T]>` ka bolelele bo fanoeng.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopitsa likarolo ho selae ho ea Arc <\[T\]> e sa tsoa fuoa
    ///
    /// Ha e bolokehe hobane moletsi o tlameha ho nka beng kapa a tlame `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// E theha `Arc<[T]>` ho tsoa ho iterator e tsejoang e le ea boholo bo itseng.
    ///
    /// Boitšoaro ha bo hlalosehe ha boholo bo fosahetse.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic e itebela ha e ntse e kopanya likarolo tsa T.
        // Ketsahalong ea panic, likarolo tse ngolisitsoeng ho ArcInner e ncha li tla tloheloa, ebe mohopolo oa lokolloa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Supa ho ntlha ea pele
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tsohle li hlakile.Lebala molebeli hore a se ke a lokolla ArcInner e ncha.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait e sebelisetsoa `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// E etsa sesepa sa sesupa sa `Arc`.
    ///
    /// Sena se theha sesupa se seng ho kabo e ts'oanang, ho eketsa palo e matla ea litšupiso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Ho sebelisa tatellano e phutholohileng ho nepahetse mona, kaha tsebo ea tšupiso ea mantlha e thibela likhoele tse ling ho tlosa phoso ka phoso.
        //
        // Joalokaha ho hlalositsoe ho [Boost documentation][1], Ho eketsa k'haontare ea litšupiso ho ka lula ho etsoa ka memory_order_relaxed: Litšupiso tse ncha tsa ntho li ka theoa feela ho tsoa bukaneng e seng e ntse e le teng, 'me ho fetisa sets'oants'o se seng se le teng ho tloha khoeleng e ngoe ho ea ho e ngoe ho tlameha hore se fane ka khokahano e hlokahalang.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Leha ho le joalo re hloka ho itebela khahlanong le lipalo tse kholo haeba motho e mong a le mem a lebala li Arcs.
        // Haeba re sa etse sena palo e ka khaphatseha mme basebelisi ba tla e sebelisa kamora mahala.
        // Re khotsofatsa ka mofuthu ho `isize::MAX` ka mohopolo oa hore ha ho na likhoele tsa ~2 billion tse eketsang palo ea litšupiso hang-hang.
        //
        // branch ena e ke ke ea nkuoa lenaneong lefe kapa lefe la 'nete.
        //
        // Re ntša mpa hobane lenaneo le joalo le senyehile hampe, 'me ha re tsotelle ho le tšehetsa.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// E etsa sets'oants'o se ka fetoloang ho `Arc` e fanoeng.
    ///
    /// Haeba ho na le lits'oants'o tse ling tsa `Arc` kapa [`Weak`] ho kabo e ts'oanang, `make_mut` e tla theha kabo e ncha ebe e kopa [`clone`][clone] boleng ba kahare ho netefatsa beng ba eona.
    /// Sena se boetse se bitsoa clone-on-write.
    ///
    /// Hlokomela hore sena se fapane le boitšoaro ba [`Rc::make_mut`] bo khethollang lits'oants'o tse setseng tsa `Weak`.
    ///
    /// Bona hape [`get_mut`][get_mut], e tla hloleha ho fapana le ho kopana.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // E ke ke ea kopanya letho
    /// let mut other_data = Arc::clone(&data); // Ke ke clone ya data ka hare
    /// *Arc::make_mut(&mut data) += 1;         // Clones ya data ka hare
    /// *Arc::make_mut(&mut data) += 1;         // E ke ke ea kopanya letho
    /// *Arc::make_mut(&mut other_data) *= 2;   // E ke ke ea kopanya letho
    ///
    /// // Hona joale `data` le `other_data` li supa likabo tse fapaneng.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Hlokomela hore re na le litšupiso tse matla le tse fokolang.
        // Ka hona, ho lokolla litšupiso tsa rona tse matla ho ke ke ha etsa hore memori e tsamaisoe ka bo eona.
        //
        // Sebelisa Fumana ho netefatsa hore re bona mang kapa mang a ngolla `weak` e etsahalang pele tokollo e ngola (ke hore, fokotseha) ho `strong`.
        // Kaha re na le palo e fokolang, ha ho na monyetla oa hore ArcInner ka boeona e ka tsamaisoa.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Sesupa se seng se matla se teng, ka hona re tlameha ho ts'oara.
            // Pele ho fana ka mohopolo ho lumella ho ngola boleng bo hlophisitsoeng ka kotloloho.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ho phomotse ho lekane kaholimo hobane sena ke ntlafatso ea mantlha: re lula re matha ka lipontšo tse fokolang tse oeloang.
            // Nyeoe e mpe ka ho fetesisa, re qetella re abetsoe Arc e ncha ho sa hlokahale.
            //

            // Re tlositse Ref ea ho qetela e matla, empa ho na le li-Ref tse ling tse fokolang tse setseng.
            // Re tla tsamaisa litaba tse ka hare ho Arc e ncha, ebe re etsa li-Ref tse ling tse fokolang hore li sebetse.
            //

            // Hlokomela hore ho ke ke ha khoneha hore `weak` e baloe ho hlahisa usize::MAX (ke hore, e notletsoe), kaha palo e fokolang e ka notleloa feela ke khoele e nang le ts'upiso e matla.
            //
            //

            // Kenya lisebelisoa tsa rona tse fokolang, e le hore e ka hloekisa ArcInner kamoo ho hlokahalang.
            //
            let _weak = Weak { ptr: this.ptr };

            // U ka utsoa data, se setseng ke Mefokolo
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Re ne re le bona feela ba mofuta ofe kapa ofe;khutlisa palo e matla ea Ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Joalo ka `get_mut()`, ho se sireletsehe ho lokile hobane ts'upiso ea rona e ne e ikhethile ho qala, kapa e ile ea fetoha e le ngoe ha ho hlophisoa litaba.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// E khutlisetsa ts'upiso e ka fetoloang ho `Arc` e fanoeng, haeba ho se na lits'oants'o tse ling tsa `Arc` kapa [`Weak`] kabo e tšoanang.
    ///
    ///
    /// E khutlisa [`None`] ho seng joalo, hobane ha ho bolokehe ho fetola boleng bo arolelanoeng.
    ///
    /// Bona hape [`make_mut`][make_mut], e tla [`clone`][clone] boleng ba kahare ha ho na le litsupa tse ling.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ho se sireletsehe hona ho lokile hobane re netefalitsoe hore sesupi se khutlisitsoe ke sesupa feela * se tla busetsoa ho T.
            // Palo ea rona ea litšupiso e netefalitsoe hore e tla ba 1 hona joale, 'me re hloka hore Arc ka boeona e be `mut`, ka hona re khutlisetsa moelelo o le mong feela oa data e kahare.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// E khutlisetsa ts'upiso e ka fetoloang ho `Arc` e fanoeng, ntle le cheke.
    ///
    /// Bona hape [`get_mut`], e bolokehileng mme e etsa licheke tse nepahetseng.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Litlhahiso tse ling tsa `Arc` kapa [`Weak`] tse abetsoeng kabo e tšoanang ha lia lokela ho hlalosoa bakeng sa nako ea kalimo e khutlisitsoeng.
    ///
    /// Sena ke taba e nyane haeba ho se na litlhahiso tse joalo, mohlala hang kamora `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Re hlokolosi hore re se ke ra etsa litšupiso tse koahelang likarolo tsa "count", kaha sena se ka etsa hore li-alias tse nang le phihlello e tšoanang ea lipalo tsa litšupiso (mohlala.
        // (`Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Etsa qeto ea hore na ena ke tšupiso e ikhethileng (ho kenyeletsoa le li-refs tse fokolang) ho data e ipehileng.
    ///
    ///
    /// Hlokomela hore sena se hloka ho notlela palo e fokolang ea ref.
    fn is_unique(&mut self) -> bool {
        // notlela palo e fokolang ea sesupi haeba re bonahala e le rona feela re nang le sesupi se fokolang.
        //
        // Letšoao le fumanehang mona le netefatsa kamano e etsahalang pele le mang kapa mang ea ngolang `strong` (haholo-holo ho `Weak::upgrade`) pele ho phokotso ea palo ea `weak` (ka `Weak::drop`, e sebelisang tokollo).
        // Haeba ts'ebetso e fokolang e ntlafalitsoeng e sa ka ea lahloa, CAS mona e tla hloleha kahoo ha re tsotelle ho hokahanya.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Sena se hloka ho ba `Acquire` ho hokahanya le phokotso ea k'haontara ea `strong` ho `drop`-phihlello e le 'ngoe feela e etsahalang ha ho na le e' ngoe ntle le ea ho qetela e tloheloang.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Phetolelo ngola mona e hokahana le e baloang ho `downgrade`, ka nepo e thibela ho bala ha `strong` e kaholimo ho etsahala kamora ho ngola.
            //
            //
            self.inner().weak.store(1, Release); // lokolla loko
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// E theola `Arc`.
    ///
    /// Sena se tla fokotsa palo e matla ea litšupiso.
    /// Haeba palo e matla ea litšupiso e fihla ho zero joale litšupiso tse ling feela (haeba li le teng) ke [`Weak`], ka hona re `drop` boleng ba kahare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ha e hatise letho
    /// drop(foo2);   // E hatisa "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Hobane `fetch_sub` e se e ntse e le athomo, ha ho hlokahale hore re lumellane le likhoele tse ling ntle le haeba re tla hlakola ntho eo.
        // Mohopolo ona ona o sebetsa ho `fetch_sub` e ka tlase ho palo ea `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Terata ena ea hlokahala ho thibela ho hlophisoa bocha ha ts'ebeliso ea data le ho hlakoloa ha data.
        // Hobane e tšoailoe `Release`, phokotso ea palo ea litšupiso e hokahana le terata ena ea `Acquire`.
        // Sena se bolela hore ts'ebeliso ea data e etsahala pele ho fokotsa palo ea litšupiso, e etsahalang pele ho terata ena, e etsahalang pele ho hlakoloa data.
        //
        // Joalokaha ho hlalositsoe ho [Boost documentation][1],
        //
        // > Ho bohlokoa ho tiisa phihlello efe kapa efe ea ntho ka bonngoe
        // > khoele (ka ts'upiso e seng e le teng) ho *etsahala pele ho* hlakoloa
        // > ntho ka kgwele e fapaneng.Sena se fihlelleha ka "release"
        // > ts'ebetso kamora ho lahla ts'upiso (phihlello efe kapa efe ea ntho
        // > ka mokhoa ona ho hlakile hore ho etsahetse pele), le an
        // > "acquire" tshebetso pele o phumula ntho.
        //
        // Haholo-holo, ha likahare tsa Arc hangata li sa fetohe, ho a khonahala hore kahare ho ngole ho ntho e kang Mutex<T>.
        // Kaha Mutex ha e fumanoe ha e hlakoloa, re ke ke ra itšetleha ka mohopolo oa eona oa khokahano ho etsa hore ho ngolisoe ka khoele A e ka bonoang ke mosenyi ea sebelisang khoele ea B.
        //
        //
        // Hape hlokomela hore fumana terata ea mona e kanna ea nkeloa sebaka ke ho fumana mojaro, e ka ntlafatsang ts'ebetso maemong a tsekisanoang haholo.Bona [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Leka ho theola `Arc<dyn Any + Send + Sync>` ho mofuta oa konkreite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// E theha `Weak<T>` e ncha, ntle le ho fana ka mohopolo.
    /// Ho letsetsa [`upgrade`] ka boleng ba ho khutla kamehla ho fa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Mofuta oa mothusi ho lumella ho fihlella lipalo tsa litšupiso ntle le ho tiisa mabapi le lefapha la data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// E khutlisetsa sesupi se tala ho ntho `T` e supiloeng ke `Weak<T>` ena.
    ///
    /// Sesupi se sebetsa ha feela ho na le litšupiso tse matla.
    /// Pointer e kanna ea leketla, e sa ts'oaroang kapa [`null`] ka tsela e ngoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ka bobeli li supa nthong e le 'ngoe
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ba matla mona ba e boloka e phela, ka hona re ntse re ka fihlela ntho eo.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Empa eseng ho feta.
    /// // Re ka etsa weak.as_ptr(), empa ho fihlella pointer ho ka lebisa ho boits'oaro bo sa hlalosoang.
    /// // assert_eq! ("hello", ha e bolokehe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Haeba sesupa se leketlile, re khutlisetsa molebeli ka kotloloho.
            // Sena e ke ke ea ba aterese e nepahetseng ea tefo, hobane tefo ea tefo e hokahane joalo ka ArcInner (usize).
            ptr as *const T
        } else {
            // TŠIRELETSO: haeba e_e leketlile e khutla e le leshano, joale sesupa-tsela ha se khonehe.
            // Meputso e kanna ea theoha hona joale, 'me re tlameha ho boloka projeke, ka hona sebelisa ts'ebeliso e mpe ea sesupa-tsela.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// E sebelisa `Weak<T>` ebe ee fetola sesupa se tala.
    ///
    /// Sena se fetola sesupi se fokolang hore e be sesupa se sa tsoakoang, ha se ntse se boloka boleng ba ts'upiso e le 'ngoe e fokolang (palo e fokolang ha e fetoloe ke ts'ebetso ena).
    /// E ka khutlisetsoa `Weak<T>` le [`from_raw`].
    ///
    /// Lithibelo tse tšoanang tsa ho fihlella sepheo sa sesupa joalo ka [`as_ptr`] lia sebetsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// E fetola sesupa se tala se neng se entsoe pele ke [`into_raw`] hape ho `Weak<T>`.
    ///
    /// Sena se ka sebelisoa ho fumana ts'upiso e matla (ka ho letsetsa [`upgrade`] hamorao) kapa ho tsamaisa palo e fokolang ka ho lahla `Weak<T>`.
    ///
    /// Ho nka mong'a tšupiso e le 'ngoe e fokolang (ntle le lits'oants'o tse entsoeng ke [`new`], kaha tsena ha li na letho; mokhoa ona o ntse o sebetsa ho bona).
    ///
    /// # Safety
    ///
    /// Pointer e tlameha ebe e tsoa ho [`into_raw`] mme e ntse e tlameha ho ba le eona litšupiso tse fokolang tse ka bang teng.
    ///
    /// Ho lumelloa hore palo e matla e be 0 ka nako ea ho letsetsa sena.
    /// Leha ho le joalo, sena se nka karolo ea ts'upiso e le 'ngoe e fokolang eo hajoale e emeloang e le sesupa se tala (palo e fokolang ha e fetoloe ke ts'ebetso ena) ka hona e tlameha ho tsamaisoa le mohala o fetileng ho [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Fokotsa palo ea ho qetela e fokolang.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Bona Weak::as_ptr bakeng sa moelelo oa hore na pointer ea ho kenya e tsoa joang.

        let ptr = if is_dangling(ptr as *mut T) {
            // Hona ke Bofokoli bo leketlileng.
            ptr as *mut ArcInner<T>
        } else {
            // Ho seng joalo, re netefalitsoe hore sesupi se tsoa ho Motho ea fokolang ea fokolang.
            // TSHIRELETSO: data_offset e bolokehile ho ka letsetsoa, joalo ka ha ptr e supa T.
            let offset = unsafe { data_offset(ptr) };
            // Kahoo, re khutlisetsa offset ho fumana RcBox kaofela.
            // TŠIRELETSO: sesupi se simolohile ho ea fokolang, ka hona, mokhoa ona o bolokehile.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TSHIRELETSO: re se re fumane sesupi sa mantlha se fokolang, ka hona re ka theha ba fokolang.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Boiteko ba ho ntlafatsa sesupa sa `Weak` ho ba [`Arc`], ho liehisa ho theoha hoa boleng ba ka hare haeba bo atlehile.
    ///
    ///
    /// E khutlisa [`None`] haeba boleng ba kahare bo se bo theohile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Senya litlhahiso tsohle tse matla.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Re sebelisa sekonopo sa CAS ho eketsa palo e matla ho fapana le fetch_add kaha mosebetsi ona ha oa lokela ho nka palo ea litšupiso ho tloha ho zero ho isa ho e le 'ngoe.
        //
        //
        let inner = self.inner()?;

        // Mojaro o khathollang hobane eng kapa eng eo re e bonang eo re ka e bonang e siea tšimo e le maemong a sa feleng (ka hona ho bala ha "stale" ha 0 ho lokile), mme boleng bofe kapa bofe bo bong bo netefatsoa ka CAS e ka tlase.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Bona litlhaloso ho `Arc::clone` hore hobaneng re etsa sena (bakeng sa `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ho phutholoha ho lokile bakeng sa nyeoe ea ho hloleha hobane ha re na litebello mabapi le mmuso o mocha.
            // Fumana ho hlokahala hore nyeoe ea katleho e hokahane le `Arc::new_cyclic`, ha boleng ba kahare bo ka qalisoa kamora hore litšupiso tsa `Weak` li se li thehiloe.
            // Maemong a joalo, re lebelletse ho bona boleng bo qalileng ka botlalo.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null e hlahlojoe kaholimo
                Err(old) => n = old,
            }
        }
    }

    /// E fumana palo ea litlhahiso tse matla tsa (`Arc`) tse supang kabo ena.
    ///
    /// Haeba `self` e entsoe ka [`Weak::new`], sena se tla khutla 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// E fumana palo ea linomoro tsa `Weak` tse supang kabo ena.
    ///
    /// Haeba `self` e entsoe ka [`Weak::new`], kapa haeba ho se na litlhahiso tse setseng tse matla, sena se tla khutla 0.
    ///
    /// # Accuracy
    ///
    /// Ka lebaka la lintlha tsa ts'ebetsong, boleng bo khutlisitsoeng bo ka tima ka 1 ntlheng efe kapa efe ha likhoele tse ling li qhekella `Arc`s kapa`Weak`s tse supang kabo e tšoanang.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kaha re hlokometse hore ho na le bonyane sesupa-matla se le seng kamora ho bala palo e fokolang, rea tseba hore litšupiso tse fokolang (tse teng neng kapa neng ha ho na le litšupiso tse matla) li ne li ntse li le teng ha re ne re bona palo e fokolang, ka hona re ka e tlosa ka polokeho
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// E khutlisa `None` ha sesupa se leketlile 'me ha ho na `ArcInner` e abetsoeng, ke hore, ha `Weak` ena e ne e etsoa ke `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Re hlokolosi hore * * re se ke ra etsa sets'oants'o se koahelang tšimo ea "data", hobane tšimo e ka fetoha ka nako e le ngoe (mohlala, haeba `Arc` ea ho qetela e theotsoe, lefapha la data le tla lahleloa sebakeng).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// E khutlisa `true` haeba tse peli tsa `Bofokoli li supa kabo e tšoanang (e ts'oanang le [`ptr::eq`]), kapa haeba ka bobeli li sa supe kabo efe kapa efe (hobane e entsoe ka `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kaha sena se bapisa litlhahiso ho bolela hore `Weak::new()` e tla lekana, leha e sa supe kabo efe kapa efe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ho bapisa `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// E etsa leseli la sesupa sa `Weak` se supang kabo e tšoanang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Bona litlhaloso ho Arc::clone() hore hobaneng sena se phutholohile.
        // Sena se ka sebelisa fetch_add (ho hlokomoloha senotlolo) hobane palo e fokolang e notletsoe feela moo ho seng lits'oants'o tse fokolang tse teng.
        //
        // (Kahoo re ke ke ra tsamaisa khoutu ena maemong ao).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Bona litlhaloso ho Arc::clone() hore hobaneng re etsa sena (bakeng sa mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// E theha `Weak<T>` e ncha, ntle le ho fana ka mohopolo.
    /// Ho letsetsa [`upgrade`] ka boleng ba ho khutla kamehla ho fa [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// E theola sesupa sa `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ha e hatise letho
    /// drop(foo);        // E hatisa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Haeba re fumana hore re ne re le sesupa-matla sa ho qetela, joale ke nako ea ho tsamaisa data ka botlalo.Bona puisano ka Arc::drop() mabapi le tatellano ea memori
        //
        // Ha ho hlokahale ho lekola boemo bo notletsoeng mona, hobane palo e fokolang e ka notleloa feela haeba ho ne ho na le "Ref" e le 'ngoe e fokolang, ho bolelang hore lerotholi le ne le ka khona ho matha holima Ref e fokolang e setseng e ka etsahalang kamora hore senotlolo se lokolloe.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Re etsa boiphihlelo bona mona, eseng joalo ka ntlafatso e akaretsang ho `&T`, hobane ho ka eketsa litšenyehelo ho licheke tsohle tsa tekano ho Refs.
/// Re nahana hore `Arc`s e sebelisetsoa ho boloka litekanyetso tse kholo, tse liehang ho ts'oaroa, empa hape li boima ho lekola tekano, e leng se etsang hore litšenyehelo tsena li lefe habonolo.
///
/// Ho na le monyetla oa ho ba le li-clone tse peli tsa `Arc`, tse supang boleng bo lekanang, ho feta li-`&T`s tse peli.
///
/// Re ka etsa sena feela ha `T: Eq` joalo ka `PartialEq` e kanna ea se ts'oane ka boomo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Tekano bakeng sa `Arc`s tse peli.
    ///
    /// Li-Arc` tse peli lia lekana haeba litekanyetso tsa tsona tsa ka hare li lekana, leha li bolokiloe ka likabelo tse fapaneng.
    ///
    /// Haeba `T` le eona e kenya tšebetsong `Eq` (ho bolelang ho se fetohe hoa tekano), `Arc`s tse peli tse supang kabo e ts'oanang li lula li lekana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ho se lekane ha `Arc`s tse peli.
    ///
    /// Li-Arc`s tse peli ha li lekane haeba boleng ba tsona ba ka hare bo sa lekana.
    ///
    /// Haeba `T` e boetse e kenya ts'ebetsong `Eq` (e bolelang ho se fetohe hoa tekano), `Arc`s tse peli tse supang boleng bo tšoanang ha ho mohla li lekanang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Papiso e sa fellang ea `Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `partial_cmp()` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ka tlase ho papiso ea `Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `<` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Papiso e ka tlase ho kapa e lekanang le' Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `<=` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// E kholo ho feta papiso ea `Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `>` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'E kholo ho feta kapa e lekana le' papiso ea `Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `>=` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Papiso ea `Arc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `cmp()` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// E etsa `Arc<T>` e ncha, e nang le boleng ba `Default` bakeng sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Abela selae se baliloeng 'me u se tlatse ka ho kopanya lintho tsa `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Abela `str` e baloang e le tšupiso ebe u e kopitsa `v` ho eona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Abela `str` e baloang e le tšupiso ebe u e kopitsa `v` ho eona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Tlosa ntho e kentsoeng mabokoseng ho kabo e ncha, e baloang ka litšupiso.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Abela selae se baliloeng 'me u tsamaise lintho tsa `v` ho sona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lumella Vec ho lokolla mohopolo oa eona, empa e se ke ea senya litaba tsa eona
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// E nka ntho e ngoe le e ngoe ho `Iterator` ebe ee bokella ho `Arc<[T]>`.
    ///
    /// # Litšobotsi tsa ts'ebetso
    ///
    /// ## Nyeoe e akaretsang
    ///
    /// Maemong a akaretsang, ho bokella ho `Arc<[T]>` ho etsoa ka ho qala ho bokelloa ho `Vec<T>`.Ka mantsoe a mang, ha u ngola tse latelang:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// sena se itšoara joalokaha eka re ngotse:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Sehlopha sa pele sa likabo se etsahala mona.
    ///     .into(); // Kabo ea bobeli ea `Arc<[T]>` e etsahala mona.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Sena se tla aba makhetlo a mangata kamoo ho hlokahalang bakeng sa ho aha `Vec<T>` mme e tla fana ka hanngoe bakeng sa ho fetola `Vec<T>` ho `Arc<[T]>`.
    ///
    ///
    /// ## Li-Iterator tsa bolelele bo tsebahalang
    ///
    /// Ha `Iterator` ea hau e kenya `TrustedLen` 'me e lekana hantle, ho tla etsoa kabelo e le' ngoe bakeng sa `Arc<[T]>`.Ka mohlala:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Kabo e le 'ngoe feela e etsahala mona.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Bokhoni ba trait bo sebelisetsoang ho bokella `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ho joalo bakeng sa sengoloa sa `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // TSHIRELETSO: Re hloka ho etsa bonnete ba hore iterator e na le bolelele bo nepahetseng mme re na le yona.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Khutlela ts'ebetsong e tloaelehileng.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Fumana phokotso kahare ho `ArcInner` bakeng sa tefo ea moputso kamora sesupa.
///
/// # Safety
///
/// Sesupi se tlameha ho supa (le ho ba le metadata e sebetsang bakeng sa) mohlala o neng o sebetsa pele oa T, empa T e lumelloa ho theoloa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Tsamaisa boleng bo sa lekanngoang ho ea qetellong ea ArcInner.
    // Hobane RcBox ke repr(C), e tla lula e le tšimo ea ho qetela mohopolong.
    // TŠIRELETSO: kaha mefuta feela e sa lekanyetsoang e ka ba lilae, lintho tsa trait,
    // le mefuta ea kantle, tlhoko ea polokeho ea ho kenya letsoho ha joale e lekane ho khotsofatsa litlhoko tsa align_of_val_raw;ena ke lintlha tsa ts'ebetsong tsa puo e ka se tšepeloeng kantle ho std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}