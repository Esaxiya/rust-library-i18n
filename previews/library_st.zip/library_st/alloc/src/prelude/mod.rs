//! Kabo ea Prelude
//!
//! Morero oa module ena ke ho fokotsa thepa e kenngoang kantle ho naha ea `alloc` crate ka ho kenyelletsa kenyelletso ea lefats'e kaholimo ho li-module:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;