//! Kabo ea memori APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Tsena ke matšoao a boloi a ho letsetsa kabo ea lefats'e.rustc e ba hlahisa hore ba letsetse `__rg_alloc` jj.
    // haeba ho na le semelo sa `#[global_allocator]` (khoutu e holisang tšobotsi eo e hlahisa mesebetsi eo), kapa ho letsetsa ts'ebetsong ea kamehla ho libstd (`__rdl_alloc` jj.
    //
    // ka `library/std/src/alloc.rs`) ho seng joalo.
    // rustc fork ea LLVM e boetse e na le linyeoe tse khethehileng tsa mabitso ana a sebetsang ho tseba ho a ntlafatsa joalo ka `malloc`, `realloc`, le `free`, ka ho latellana.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Kabo ea mohopolo oa lefatše.
///
/// Mofuta ona o sebelisa [`Allocator`] trait ka ho fetisetsa mehala ho morekisi ea ngolisitsoeng ka boleng ba `#[global_allocator]` haeba e le 'ngoe, kapa `std` crate ea kamehla.
///
///
/// Note: ha mofuta ona o sa tsitsa, ts'ebetso eo o fanang ka eona e ka fihlelleha ka [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Abela mohopolo le seabi sa lefats'e.
///
/// Mosebetsi ona o fetisetsa mohala ho [`GlobalAlloc::alloc`] mokhoa oa morekisi o ngolisitsoeng ka boleng ba `#[global_allocator]` haeba ho na le o le mong, kapa `std` crate ea kamehla.
///
///
/// Mosebetsi ona o lebelletsoe ho nyenyefatsoa molemong oa mofuta oa `alloc` oa mofuta oa [`Global`] ha eona le [`Allocator`] trait li tsitsitse.
///
/// # Safety
///
/// Bona [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Fana ka mohopolo le seabi sa lefats'e.
///
/// Mosebetsi ona o fetisetsa mohala ho [`GlobalAlloc::dealloc`] mokhoa oa morekisi o ngolisitsoeng ka boleng ba `#[global_allocator]` haeba ho na le o le mong, kapa `std` crate ea kamehla.
///
///
/// Mosebetsi ona o lebelletsoe ho nyenyefatsoa molemong oa mofuta oa `dealloc` oa mofuta oa [`Global`] ha eona le [`Allocator`] trait li tsitsitse.
///
/// # Safety
///
/// Bona [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Fana ka mohopolo le mofani oa lefats'e.
///
/// Mosebetsi ona o fetisetsa mohala ho [`GlobalAlloc::realloc`] mokhoa oa morekisi o ngolisitsoeng ka boleng ba `#[global_allocator]` haeba ho na le o le mong, kapa `std` crate ea kamehla.
///
///
/// Mosebetsi ona o lebelletsoe ho nyenyefatsoa molemong oa mofuta oa `realloc` oa mofuta oa [`Global`] ha eona le [`Allocator`] trait li tsitsitse.
///
/// # Safety
///
/// Bona [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Fana ka mohopolo o qalileng zero le moabi oa lefats'e.
///
/// Mosebetsi ona o fetisetsa mohala ho [`GlobalAlloc::alloc_zeroed`] mokhoa oa morekisi o ngolisitsoeng ka boleng ba `#[global_allocator]` haeba ho na le o le mong, kapa `std` crate ea kamehla.
///
///
/// Mosebetsi ona o lebelletsoe ho nyenyefatsoa molemong oa mofuta oa `alloc_zeroed` oa mofuta oa [`Global`] ha eona le [`Allocator`] trait li tsitsitse.
///
/// # Safety
///
/// Bona [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // TŠIRELETSO: `layout` ha e na zero ka boholo,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // TSHIRELETSO: E tshwana le `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // TSHIRELETSO: `new_size` ha se zero kaha `old_size` e feta kapa e lekana le `new_size`
            // kamoo ho hlokehang ka maemo a polokeho.Maemo a mang a tlameha ho bolokoa ke moletsi
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` mohlomong o batla `new_size >= old_layout.size()` kapa ntho e ts'oanang.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // POLOKEHO: hobane `new_layout.size()` e tlameha ho ba kholo ho feta kapa ho lekana le `old_size`,
            // Kabo ea mohopolo oa khale le e ncha e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tsa `old_size`.
            // Hape, hobane kabo ea khale e ne e so tsamaisoe, e ke ke ea feta `new_ptr`.
            // Kahoo, mohala oa `copy_nonoverlapping` o bolokehile.
            // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // TŠIRELETSO: `layout` ha e na zero ka boholo,
            // maemo a mang a tlameha ho bolokoa ke moletsi
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // POLOKEHO: maemo ohle a tlameha ho bolokoa ke motho ea letsitseng
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // POLOKEHO: maemo ohle a tlameha ho bolokoa ke motho ea letsitseng
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // POLOKEHO: maemo a tlameha ho bolokoa ke motho ea letsitseng
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // TSHIRELETSO: `new_size` ha se zero.Maemo a mang a tlameha ho bolokoa ke moletsi
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` mohlomong o batla `new_size <= old_layout.size()` kapa ntho e ts'oanang.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // TSHIRELETSO: hobane `new_size` e tlameha ho ba nyane ho feta kapa ho lekana le `old_layout.size()`,
            // Kabo ea mohopolo oa khale le e ncha e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tsa `new_size`.
            // Hape, hobane kabo ea khale e ne e so tsamaisoe, e ke ke ea feta `new_ptr`.
            // Kahoo, mohala oa `copy_nonoverlapping` o bolokehile.
            // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Morekisi oa litlhahiso tse ikhethang.
// Mosebetsi ona ha oa lokela ho phutholoha.Haeba e etsa joalo, MIR codegen e tla hloleha.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Senoeno sena se tlameha ho tšoana le `Box`, ho seng joalo ICE e tla etsahala.
// Ha parameter e eketsehileng ho `Box` e eketsoa (joalo ka `A: Allocator`), sena se tlameha ho eketsoa le mona.
// Mohlala haeba `Box` e fetotsoe ho `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, ts'ebetso ena e tlameha ho fetoloa ho `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` hape.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Kabo ea phoso ea kabelo

extern "Rust" {
    // Ena ke letšoao la boloi ho letsetsa mofani oa liphoso tsa kabelo ea lefats'e.
    // rustc ee etsa hore e letsetse `__rg_oom` haeba ho na le `#[alloc_error_handler]`, kapa ho letsetsa ts'ebetsong ea kamehla ka tlase ho (`__rdl_oom`) ho seng joalo.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Ntsha phoso ka phoso ea kabo ea memori kapa ho hloleha.
///
/// Batho ba letsetsang li-API tsa kabo ea mohopolo ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho bitsa ts'ebetso ena, ho fapana le ho hohela ka kotloloho `panic!` kapa e ts'oanang.
///
///
/// Boitšoaro bo sa feleng ba ts'ebetso ena ke ho hatisa molaetsa ho phoso e tloaelehileng le ho ntša tšebetso.
/// E ka nkeloa sebaka ke [`set_alloc_error_hook`] le [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Bakeng sa alloc test `std::alloc::handle_alloc_error` e ka sebelisoa ka kotloloho.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // e bitsoa ka `__rust_alloc_error_handler` e hlahisitsoeng

    // haeba ho se `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // haeba ho na le `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Khetheha li-clone mohopolong o seng o abetsoe, o sa qalisoang.
/// E sebelisoa ke `Box::clone` le `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ho fana ka *pele* ho ka lumella optimizer ho theha boleng bo kentsoeng sebakeng, e tlola ea lehae mme e tsamaee.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Kamehla re ka kopitsa sebakeng se seng ntle le ho kenyelletsa boleng ba lehae.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}