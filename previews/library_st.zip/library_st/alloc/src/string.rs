//! Khoele e kentsoeng ka khoutu ea UTF-8, e holang.
//!
//! Mojule ona o na le mofuta oa [`String`], [`ToString`] trait bakeng sa ho fetohela ho likhoele, le mefuta e mengata ea liphoso e ka bang teng ka lebaka la ho sebetsa le [`String`] s.
//!
//!
//! # Examples
//!
//! Ho na le mekhoa e mengata ea ho theha [`String`] e ncha ka khoele ea 'nete:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! O ka theha [`String`] e ncha ho e teng ka ho hokahana le
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Haeba u na le vector ea li-byte tse nepahetseng tsa UTF-8, u ka etsa [`String`] ka eona.Le uena u ka etsa se fapaneng.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Rea tseba hore li-byte tsena li nepahetse, ka hona re tla sebelisa `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Khoele e kentsoeng ka khoutu ea UTF-8, e holang.
///
/// Mofuta oa `String` ke mofuta o tloaelehileng ka ho fetisisa oa khoele o nang le beng ba ona ho feta se kahare ho khoele.E na le kamano e haufi le motsoalle oa eona ea alimiloeng, [`str`] ea khale.
///
/// # Examples
///
/// O ka etsa `String` ho tloha [a literal string][`str`] ka [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// U ka kenya [`char`] ho `String` ka mokhoa oa [`push`], 'me u hlomathise [`&str`] ka mokhoa oa [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Haeba u na le vector ea UTF-8 byte, u ka etsa `String` ho eona ka mokhoa oa [`from_utf8`]:
///
/// ```
/// // li-byte, ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Rea tseba hore li-byte tsena li nepahetse, ka hona re tla sebelisa `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Likhoele li lula li sebetsa UTF-8.Sena se na le litlamorao tse 'maloa, sa pele ke hore haeba o hloka khoele e seng UTF-8, nahana ka [`OsString`].Hoa tšoana, empa ntle le tšitiso ea UTF-8.Moelelo oa bobeli ke hore o ke ke oa kenella ho `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing e reretsoe ho ba ts'ebetso ea nako eohle, empa kh'outu ea UTF-8 ha e re lumelle ho etsa sena.Ntle le moo, ha ho hlake hore na index e lokela ho khutlisa ntho ea mofuta ofe: byte, codepoint, kapa sehlopha sa grapheme.
/// Mekhoa ea [`bytes`] le [`chars`] e khutlisa li-iterator holim'a tse peli tsa pele, ka ho latellana.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s kenya ts'ebetsong [`Deref`] `<Target=str>`, 'me kahoo o rue mekhoa eohle ea [`str`].Ntle le moo, sena se bolela hore o ka fetisa `String` ho ts'ebetso e nkang [`&str`] ka ho sebelisa ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Sena se tla theha [`&str`] ho tsoa ho `String` ebe se e fetisetsa ho eona. Phetoho ena e theko e tlase haholo, mme ka kakaretso, mesebetsi e tla amohela [`&str`] e le likhang ntle le haeba ba hloka `String` ka lebaka le itseng.
///
/// Maemong a mang Rust ha e na tlhaiso-leseling e lekaneng ho etsa phetoho ena, e tsejoang ka hore ke khatello ea [`Deref`].Mohlala o latelang khoele ea [`&'a str`][`&str`] e sebelisa trait `TraitExample`, mme ts'ebetso `example_func` e nka eng kapa eng e sebelisang trait.
/// Maemong ana Rust e tla hloka ho etsa liphetoho tse peli tse hlakileng, tseo Rust e se nang mokhoa oa ho e etsa.
/// Ka lebaka leo, mohlala o latelang o ke ke oa bokelloa.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ho na le likhetho tse peli tse ka sebetsang ho fapana.Ea pele e ne e tla ba ho fetola mohala `example_func(&example_string);` hore e be `example_func(example_string.as_str());`, a sebelisa mokhoa [`as_str()`] ho ntša ka ho hlaka selae sa khoele se nang le khoele.
/// Tsela ea bobeli e fetola `example_func(&example_string);` ho ea ho `example_func(&*example_string);`.
/// Maemong ana re qhekella `String` ho [`str`][`&str`], ebe re supa [`str`][`&str`] ho [`&str`].
/// Tsela ea bobeli e na le maele, empa ka bobeli ba sebeletsa ho etsa phetoho ka mokhoa o hlakileng ho fapana le ho itšetleha ka phetoho e hlakileng.
///
/// # Representation
///
/// `String` e entsoe ka likarolo tse tharo: sesupi ho li-byte tse ling, bolelele le bokhoni.Sesupi se supa sesebelisi sa ka hare sa `String` se bolokang lintlha tsa sona.Bolelele ke palo ea li-byte tse bolokiloeng hona joale ho buffer, 'me boholo ke boholo ba buffer ka li-byte.
///
/// Kahoo, bolelele bo tla lula bo le tlase ho kapa bo lekana le boholo.
///
/// Sesebelisoa sena se lula se bolokiloe qubu.
///
/// U ka li sheba ka mekhoa ea [`as_ptr`], [`len`], le [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Ntlafatsa sena ha vec_into_raw_parts e tsitsitse.
/// // Thibela ho lahla data ea String ka boiketsetso
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // Pale e na le li-byte tse leshome le metso e robong
/// assert_eq!(19, len);
///
/// // Re ka aha bocha String out of ptr, len, and capacity.
/// // Sena sohle ha se bolokehe hobane re na le boikarabello ba ho etsa bonnete ba hore likarolo li sebetsa hantle:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Haeba `String` e na le matla a lekaneng, ho e eketsa ka lintlha ho ke ke ha e abela hape.Mohlala, nahana ka lenaneo lena:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Sena se tla hlahisa tse latelang:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Qalong, ha re na mohopolo o abetsoeng ho hang, empa ha re ntse re hokella khoele, e eketsa bokhoni ba eona ka nepo.Haeba re sebelisa mokhoa oa [`with_capacity`] ho fana ka bokhoni bo nepahetseng qalong:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Re qetella re hlahisa tse ling tse fapaneng:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Mona, ha ho na lebaka la ho fana ka mohopolo o mong kahare.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Phoso e ka bang teng ha u fetola `String` ho tsoa ho UTF-8 byte vector.
///
/// Mofuta ona ke mofuta oa phoso bakeng sa mokhoa oa [`from_utf8`] ho [`String`].
/// E etselitsoe ka tsela e joalo ho qoba ka hloko ho fallisoa ka mokhoa o mong: mokhoa oa [`into_bytes`] o tla khutlisa byte vector e sebelisitsoeng boitekong ba ho sokoloha.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Mofuta oa [`Utf8Error`] o fanoeng ke [`std::str`] o emela phoso e ka etsahalang ha o fetola selae sa [`u8`] s ho [`&str`].
/// Ka kutloisiso ena, ke analoge ea `FromUtf8Error`, 'me u ka e fumana ho `FromUtf8Error` ka mokhoa oa [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// // li-byte tse sa sebetseng, ho vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Phoso e ka bang teng ha o fetola `String` ho tloha selae sa UTF-16 byte.
///
/// Mofuta ona ke mofuta oa phoso bakeng sa mokhoa oa [`from_utf16`] ho [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// E etsa `String` e ncha e se nang letho.
    ///
    /// Kaha `String` ha e na letho, sena se ke ke sa fana ka buffer ea pele.Le ha seo se bolela hore ts'ebetso ena ea pele ha e theko e tlase, e ka baka kabo e fetelletseng hamorao ha o eketsa data.
    ///
    /// Haeba u na le mohopolo oa hore na `String` e tla boloka data e kae, nahana ka mokhoa oa [`with_capacity`] ho thibela kabelo e fetelletseng.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// E theha `String` e se nang letho e nang le bokhoni bo itseng.
    ///
    /// `String`s e na le sesebelisoa se ka hare sa ho boloka lintlha tsa bona.
    /// Bolelele ke bolelele ba buffer eo, 'me bo ka botsoa ka mokhoa oa [`capacity`].
    /// Mokhoa ona o theha `String` e se nang letho, empa e na le buffer ea pele e ka ts'oereng li-byte tsa `capacity`.
    /// Sena se na le thuso ha o kanna oa kenya lethathamo la data ho `String`, o fokotsa palo ea libaka tseo o lokelang ho li etsa hape.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Haeba matla a fanoeng e le `0`, ha ho kabo e tla ba teng, 'me mokhoa ona o ts'oana le mokhoa oa [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Khoele ha e na chars, leha e na le matla a ho feta
    /// assert_eq!(s.len(), 0);
    ///
    /// // Tsena tsohle li etsoa ntle le ho fallisoa hape ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... empa sena se ka etsa hore khoele e fallisoe hape
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ka cfg(test) mokhoa oa tlhaho oa `[T]::to_vec`, o hlokehang bakeng sa tlhaloso ea mokhoa ona, ha o fumanehe.
    // Kaha ha re hloke mokhoa ona molemong oa liteko, ke tla o hlaba NB bona module ea slice::hack ho slice.rs bakeng sa tlhaiso-leseling e batsi
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// E fetola vector ea li-byte ho `String`.
    ///
    /// Thapo ([`String`]) e entsoe ka li-byte ([`u8`]), 'me vector ea li-byte ([`Vec<u8>`]) e entsoe ka li-byte, kahoo mosebetsi ona o fetoha pakeng tsa tse peli.
    /// Ha se likhechana tsohle tsa byte tse sebetsang `String`s, leha ho le joalo: `String` e hloka hore e sebetse UTF-8.
    /// `from_utf8()` licheke ho netefatsa hore li-byte li nepahetse UTF-8, ebe e etsa phetoho.
    ///
    /// Haeba u na le bonnete ba hore selae sa byte se nepahetse UTF-8, 'me ha u batle ho ba le sehlooho sa tlhahlobo e nepahetseng, ho na le mofuta o sa bolokehang oa ts'ebetso ena, [`from_utf8_unchecked`], e nang le boits'oaro bo ts'oanang empa e tlola cheke.
    ///
    ///
    /// Mokhoa ona o tla hlokomela hore o se ke oa kopitsa vector, molemong oa ts'ebetso.
    ///
    /// Haeba o hloka [`&str`] ho fapana le `String`, nahana ka [`str::from_utf8`].
    ///
    /// Tsela e fapaneng ea mokhoa ona ke [`into_bytes`].
    ///
    /// # Errors
    ///
    /// E khutlisa [`Err`] haeba selae ha se UTF-8 se nang le tlhaloso ea hore na hobaneng li-byte tse fanoeng e se UTF-8.vector eo u keneng ho eona e kenyelelitsoe.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte, ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Rea tseba hore li-byte tsena li nepahetse, ka hona re tla sebelisa `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Li-byte tse fosahetseng:
    ///
    /// ```
    /// // li-byte tse sa sebetseng, ho vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Bona litokomane tsa [`FromUtf8Error`] bakeng sa lintlha tse ling mabapi le seo u ka se etsang ka phoso ena.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// E fetola selae sa li-byte hore e be khoele, ho kenyeletsoa litlhaku tse sa sebetseng.
    ///
    /// Likhoele li entsoe ka li-byte ([`u8`]), 'me selae sa li-byte ([`&[u8]`][byteslice]) se entsoe ka li-byte, kahoo ts'ebetso ena e fetoha lipakeng tsa tse peli.Ha se likhechana tsohle tsa byte tse likhoele tse sebetsang, leha ho le joalo: likhoele li hlokahala hore li sebetse UTF-8.
    /// Nakong ea phetoho ena, `from_utf8_lossy()` e tla nkela tatellano efe kapa efe e fosahetseng ea UTF-8 ka [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], e shebahalang tjena:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Haeba u na le bonnete ba hore selae sa byte se nepahetse UTF-8, 'me ha u batle ho ba le phetoho e kholo, ho na le mofuta o sa bolokehang oa ts'ebetso ena, [`from_utf8_unchecked`], e nang le boits'oaro bo ts'oanang empa e tlola licheke.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Mosebetsi ona o khutlisa [`Cow<'a, str>`].Haeba selae sa rona sa byte se sa sebetse UTF-8, re tla hloka ho kenya litlhaku tse tla nkela sebaka sebaka, tse tla fetola boholo ba khoele, ka hona, e hloka `String`.
    /// Empa haeba e se e ntse e sebetsa UTF-8, ha re hloke kabo e ncha.
    /// Mofuta ona oa ho khutla o re lumella ho sebetsana le linyeoe ka bobeli.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte, ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Li-byte tse fosahetseng:
    ///
    /// ```
    /// // li-byte tse sa sebetseng
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Hlahloba UTF-16 - e kentsoeng vector `v` hore e be `String`, 'me e khutlise [`Err`] haeba `v` e na le lintlha tse fosahetseng.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Sena ha se etsoe ka ho bokella: : <Result<_, _>> () ka mabaka a ts'ebetso.
        // FIXME: mosebetsi o ka nolofatsoa hape ha #48994 e koetsoe.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Hlahloba selae se kentsoeng ka UTF-16-`v` hore e be `String`, o tlosa data e sa sebetseng ka [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ho fapana le [`from_utf8_lossy`] e khutlisetsang [`Cow<'a, str>`], `from_utf16_lossy` e khutlisa `String` kaha ho fetoha ha UTF-16 ho UTF-8 ho hloka karohano ea memori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// E bolaea `String` ka likarolo tsa eona tse tala.
    ///
    /// E khutlisetsa pointer e tala ho data e ka tlase, bolelele ba khoele (ka li-byte), le matla a abetsoeng data (ka li-byte).
    /// Tsena ke mabaka a tšoanang ka tatellano e tšoanang le likhang tsa [`from_raw_parts`].
    ///
    /// Kamora ho bitsa ts'ebetso ena, moletsi o ikarabella ho memori e neng e laoloa pele ke `String`.
    /// Mokhoa o le mong feela oa ho etsa sena ke ho fetolela sesupa se botala, bolelele le matla hore e be `String` ka ts'ebetso ea [`from_raw_parts`], e lumellang mosenyi hore a hloekise.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// E etsa `String` e ncha ho tloha bolelele, bokhoni le sesupa.
    ///
    /// # Safety
    ///
    /// Sena ha se bolokehe haholo, ka lebaka la palo ea lintho tse kenang tse sa hlahlojoeng:
    ///
    /// * Memori ea `buf` e hloka hore ebe e ne e fuoe pejana ke moabi a le mong eo laeborari e tloaelehileng e e sebelisang, ka tatellano e hlokahalang ea 1 hantle.
    /// * `length` e hloka ho ba ka tlase ho kapa ho lekana le `capacity`.
    /// * `capacity` e hloka ho ba boleng bo nepahetseng.
    /// * Li-byte tsa pele tsa `length` ho `buf` li hloka ho ba UTF-8 e nepahetseng.
    ///
    /// Ho tlola tsena ho ka baka mathata a joalo ka ho senya likarolo tsa data tsa kahare tsa morekisi.
    ///
    /// Botho ba `buf` bo fetisetsoa ho `String` ka katleho e ka tsamaisang, ea abela hape kapa ea fetola se kahare sa memori se supisitsoeng ke sesupi ka thato.
    /// Etsa bonnete ba hore ha ho letho le leng le sebelisang pointer kamora ho bitsa ts'ebetso ena.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Ntlafatsa sena ha vec_into_raw_parts e tsitsitse.
    ///     // Thibela ho lahla data ea String ka boiketsetso
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// E fetola vector ea li-byte ho `String` ntle le ho lekola hore khoele e na le UTF-8 e sebetsang.
    ///
    /// Bona mofuta o bolokehileng, [`from_utf8`], bakeng sa lintlha tse ling.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe hobane ha o hlahlobe hore li-byte tse fetisitsoeng ho oona li nepahetse UTF-8.
    /// Haeba bothata bona bo tlotsoe, bo ka baka mathata a ho se bolokehe mohopolong le basebelisi ba future ba `String`, joalo ka ha laeborari e ngoe e tloaelehileng e nka hore `String`s li nepahetse UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte, ka vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// E fetola `String` hore e be byte vector.
    ///
    /// Sena se sebelisa `String`, ka hona ha re hloke ho kopitsa litaba tsa eona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// E ntša selae sa khoele se nang le `String` kaofela.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// E fetola `String` hore e be selae sa khoele se ka fetohang.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// E kenya khoele ea thapo e fuoeng qetellong ea `String` ena.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// E khutlisa matla a `String`, ka li-byte.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// E netefatsa hore matla a `String` a bonyane li-byte tsa `additional` li kholo ho feta bolelele ba ona.
    ///
    /// Bokhoni bo ka eketsoa ka li-byte tse fetang `additional` haeba bo khetha, ho thibela ho fallisoa khafetsa.
    ///
    ///
    /// Haeba u sa batle boitšoaro bona ba "at least", bona mokhoa oa [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Sena se kanna sa se eketse bokhoni:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Hona joale e na le bolelele ba 2 le matla a 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kaha re se re ntse re na le bokhoni bo eketsehileng ba 8, re e bitsa ...
    /// s.reserve(8);
    ///
    /// // ... ha e hlile ha e eketsehe.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// E netefatsa hore matla a `String`a ke `additional` byte e kholo ho feta bolelele ba eona.
    ///
    /// Nahana ka ho sebelisa mokhoa oa [`reserve`] ntle le haeba o tseba hantle ho feta moabi.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta `usize`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Sena se kanna sa se eketse bokhoni:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // Hona joale e na le bolelele ba 2 le matla a 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kaha re se re ntse re na le bokhoni bo eketsehileng ba 8, re e bitsa ...
    /// s.reserve_exact(8);
    ///
    /// // ... ha e hlile ha e eketsehe.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// E leka ho boloka bokhoni ba bonyane likarolo tse ling tsa `additional` tse tla kenngoa ho `String` e fanoeng.
    /// Pokello e ka boloka sebaka se eketsehileng ho qoba ho fallisoa khafetsa.
    /// Kamora ho letsetsa `reserve`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo lekane.
    ///
    /// # Errors
    ///
    /// Haeba matla a khaphatseha, kapa morekisi a tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// E leka ho boloka bonyane matla bakeng sa lintlha tse ling tsa `additional` tse lokelang ho kenngoa ho `String` e fanoeng.
    ///
    /// Kamora ho letsetsa `reserve_exact`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo ntse bo lekane.
    ///
    /// Hlokomela hore morekisi a ka fa pokello sebaka se fetang seo a se kopileng.
    /// Ka hona, bokhoni bo ke ke ba ts'epahloa hore bo be tlase haholo.
    /// Khetha `reserve` haeba ho lebelletsoe kenyelletso ea future.
    ///
    /// # Errors
    ///
    /// Haeba matla a khaphatseha, kapa morekisi a tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// E fokotsa matla a `String` ena ho lekana bolelele ba eona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// E fokotsa matla a `String` ena ka mohala o tlase.
    ///
    /// Bokgoni bo tla lula bonyane bo le boholo bo bolelele le boleng bo fanoeng ka bobeli.
    ///
    ///
    /// Haeba matla a hajoale a le tlase ho moeli o tlase, hona ke ho se sebetse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// E kenya kopo [`char`] e fanoeng ho fihlela qetellong ea `String` ena.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// E khutlisa selae sa byte sa litaba tsa `String`.
    ///
    /// Tsela e fapaneng ea mokhoa ona ke [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// E khutsufatsa `String` ena ho ea bolelele bo boletsoeng.
    ///
    /// Haeba `new_len` e kholo ho feta bolelele ba khoele hona joale, sena ha se na phello.
    ///
    ///
    /// Hlokomela hore mokhoa ona ha o na matla ho matla a abiloeng a khoele
    ///
    /// # Panics
    ///
    /// Panics haeba `new_len` e sa thetse moeli oa [`char`].
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// E tlosa sebapali sa ho qetela khoeleng ea khoele ebe oa e khutlisa.
    ///
    /// E khutlisa [`None`] haeba `String` ena e sena letho.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// E tlosa [`char`] ho `String` ena sebakeng sa byte ebe oa e khutlisa.
    ///
    /// Ena ke ts'ebetso ea *O*(*n*), kaha e hloka ho kopitsa ntho e ngoe le e ngoe ka hara buffer.
    ///
    /// # Panics
    ///
    /// Panics haeba `idx` e kholo ho feta kapa e lekana le bolelele ba `String`, kapa haeba e sa lutse moeling oa [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Tlosa lipapali tsohle tsa `pat` ho `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Lipapaling li tla fumanoa 'me li tlosoe ka mokhoa o ts'oanang, kahoo maemong ao lipaterone li fetang, ho tla tlosoa mofuta oa pele feela:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // TŠIRELETSO: qalo le qetello li tla ba meeling ea utf8 byte ka
        // li-docs tsa Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// E boloka feela litlhaku tse boletsoeng ke lereho.
    ///
    /// Ka mantsoe a mang, tlosa litlhaku tsohle `c` hore `f(c)` e khutlise `false`.
    /// Mokhoa ona o sebetsa sebakeng se le seng, o etela sebapali ka seng hanngoe ka tatellano ea mantlha, mme o boloka tatellano ea litlhaku tse bolokiloeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Taelo e nepahetseng e kanna ea ba ea bohlokoa bakeng sa ho latela boemo ba kantle, joalo ka index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Supa idx ho char e latelang
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Kenya semelo ho `String` ena maemong a byte.
    ///
    /// Ena ke ts'ebetso ea *O*(*n*) kaha e hloka ho kopitsa ntho e ngoe le e ngoe ka hara buffer.
    ///
    /// # Panics
    ///
    /// Panics haeba `idx` e kholo ho feta bolelele ba `String`, kapa haeba e sa lutse moeling oa [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// E kenya selae sa khoele ho `String` ena maemong a byte.
    ///
    /// Ena ke ts'ebetso ea *O*(*n*) kaha e hloka ho kopitsa ntho e ngoe le e ngoe ka hara buffer.
    ///
    /// # Panics
    ///
    /// Panics haeba `idx` e kholo ho feta bolelele ba `String`, kapa haeba e sa lutse moeling oa [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// E khutlisetsa litšupiso tse ka fetoloang ho se ka hare ho `String` ena.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe hobane ha o hlahlobe hore li-byte tse fetisitsoeng ho oona li nepahetse UTF-8.
    /// Haeba bothata bona bo tlotsoe, bo ka baka mathata a ho se bolokehe mohopolong le basebelisi ba future ba `String`, joalo ka ha laeborari e ngoe e tloaelehileng e nka hore `String`s li nepahetse UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// E khutlisa bolelele ba `String` ena, ka li-byte, eseng [`char`] s kapa graphemes.
    /// Ka mantsoe a mang, e kanna eaba ha se seo motho a se nahanang ka bolelele ba khoele.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// E khutlisa `true` haeba `String` ena e na le bolelele ba zero, 'me `false` ha ho joalo.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// E arola khoele ka makhetlo a mabeli ho index ea byte e fanoeng.
    ///
    /// E khutlisa `String` e sa tsoa fuoa.
    /// `self` e na le li-byte `[0, at)`, 'me `String` e khutlisitsoeng e na le li-byte `[at, len)`.
    /// `at` e tlameha ho ba moeling oa ntlha ea UTF-8.
    ///
    /// Hlokomela hore matla a `self` ha a fetohe.
    ///
    /// # Panics
    ///
    /// Panics haeba `at` e se moeling oa khoutu ea `UTF-8`, kapa haeba e ka nqane ho ntlha ea khoutu ea ho qetela ea khoele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// E fokotsa `String` ena, e tlosa litaba tsohle.
    ///
    /// Le ha hona ho bolela hore `String` e tla ba le bolelele ba zero, ha e ame matla a eona.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// E etsa draining iterator e tlosang mefuta e boletsoeng ho `String` ebe e hlahisa `chars` e tlositsoeng.
    ///
    ///
    /// Note: Sehlopha sa elemente sea tlosoa le haeba iterator e sa sebelisoe ho fihlela qetellong.
    ///
    /// # Panics
    ///
    /// Panics haeba ntlha ea qalo kapa ntlha e sa qaleng e se moeling oa [`char`], kapa haeba e tsoa meeling.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Tlosa marang-rang ho fihlela β khoeleng
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Lethathamo le felletseng le hlakola khoele
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Polokeho ea memori
        //
        // Mofuta oa String oa Drain ha o na litaba tsa polokeho ea mohopolo tsa mofuta oa vector.
        // Lintlha li bonolo feela.
        // Hobane ho tlosoa ha mefuta ho etsahala ho Drop, haeba iterator ea Drain e lutsoe, ho tlosoa ho ke ke ha etsahala.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Nka mekoloto e 'meli ka nako e le ngoe.
        // Mohala oa &mut o ke ke oa fihlelloa ho fihlela phetiso e fela, ho Drop.
        let self_ptr = self as *mut _;
        // TŠIRELETSO: `slice::range` le `is_char_boundary` li etsa licheke tse loketseng.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// E tlosa moeli o boletsoeng khoeleng ebe oa e nkela ka khoele e fanoeng.
    /// Thapo e fanoeng ha e hloke ho lekana bolelele le boholo.
    ///
    /// # Panics
    ///
    /// Panics haeba ntlha ea qalo kapa ntlha e sa qaleng e se moeling oa [`char`], kapa haeba e tsoa meeling.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Tlosa sebaka ho fihlela β ho tloha khoeleng
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Polokeho ea memori
        //
        // Tlosa_range ha e na lintlha tsa polokeho ea memori ea vector Splice.
        // ea mofuta oa vector.Lintlha li bonolo feela.

        // TEMOSO: Ho hlakisa phapang ena ho ka ba kotsi (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // TEMOSO: Ho hlakisa phapang ena ho ka ba kotsi (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ho sebelisa `range` hape ho ne ho ke ke ha utloahala (#81138) Re nahana hore meeli e tlalehiloeng ke `range` e lula e tšoana, empa ts'ebetsong e khahlano le eona e ka fetoha lipakeng tsa mehala
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// E fetola `String` ena ho e etsa [`Box`]`<<"[`str`] `>`.
    ///
    /// Sena se tla lahla bokhoni bofe kapa bofe bo fetelletseng.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// E khutlisa selae sa li-[`u8`] s tse lekiloeng ho li fetolela ho `String`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte tse sa sebetseng, ho vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// E khutlisa li-byte tse lekiloeng ho fetolela ho `String`.
    ///
    /// Mokhoa ona o entsoe ka hloko ho qoba kabo.
    /// E tla qeta phoso, e tlose li-byte, e le hore kopi ea li-byte e se hloke ho etsoa.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte tse sa sebetseng, ho vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Lata `Utf8Error` ho fumana lintlha tse ling ka ho hloleha ho fetoha.
    ///
    /// Mofuta oa [`Utf8Error`] o fanoeng ke [`std::str`] o emela phoso e ka etsahalang ha o fetola selae sa [`u8`] s ho [`&str`].
    /// Ka kutloisiso ena, ke analoge ea `FromUtf8Error`.
    /// Bona litokomane tsa eona bakeng sa lintlha tse ling mabapi le ho e sebelisa.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // li-byte tse sa sebetseng, ho vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // byte ea pele ha e na thuso mona
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Hobane re ntse re pheta-pheta ka `String`s, re ka qoba bonyane kabo e le 'ngoe ka ho fumana khoele ea pele ho iterator ebe re e kenya ho likhoele tsohle tse latelang.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Hobane re ntse re pheta li-CoW, re ka qoba (potentially) bonyane kabo e le 'ngoe ka ho fumana ntho ea pele le ho e kenya ho eona lintho tsohle tse latelang.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Kamohelo e bonolo eo baemeli ba kenang ho eona bakeng sa `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// E etsa `String` e se nang letho.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// E sebelisa sesebelisoa sa `+` bakeng sa ho tiisa likhoele tse peli.
///
/// Sena se sebelisa `String` ka letsohong le letšehali ebe se sebelisa sesebelisoa sa sona (se se holisa ha ho hlokahala).
/// Sena se etsoa ho qoba ho aba `String` e ncha le ho kopitsa litaba tsohle tse teng ts'ebetsong e ngoe le e ngoe, e ka lebisang ho *O*(*n*^ 2) nako ea ho sebetsa ha o haha mohala oa *n*-byte ka concatenation e phetoang.
///
///
/// Khoele e letsohong le letona e alima feela;litaba tsa eona li kopitsoa ho `String` e khutlisitsoeng.
///
/// # Examples
///
/// Ho tiisa li-`String` tse peli ho nka ea pele ka boleng ebe e alima ea bobeli:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` e tsamaisoa mme ha e sa khona ho sebelisoa mona.
/// ```
///
/// Haeba u batla ho lula u sebelisa `String` ea pele, u ka e kopanya le ho hlomathisa clone ho fapana:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` e ntse e sebetsa mona.
/// ```
///
/// Ho kopanya likarolo tse `&str` ho ka etsoa ka ho fetola ea pele hore e be `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// E kenya ts'ebetso ea `+=` bakeng sa ho kenya kopo ho `String`.
///
/// Sena se na le boits'oaro bo ts'oanang le mokhoa oa [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Mofuta oa li-alias tsa [`Infallible`].
///
/// Mabitso ana a teng bakeng sa ts'ebelisano ea morao, mme a ka qetella a theotsoe.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait bakeng sa ho fetolela boleng ho `String`.
///
/// trait ena e sebelisoa ka boiketsetso bakeng sa mofuta ofe kapa ofe o sebelisang [`Display`] trait.
/// Kahoo, `ToString` ha ea lokela ho kengoa tšebetsong ka kotloloho:
/// [`Display`] e lokela ho kengoa tšebetsong, 'me u fumane ts'ebetsong ea `ToString` mahala.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// E fetola boleng bo fanoeng ho `String`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Ts'ebetsong ena, mokhoa oa `to_string` panics haeba ts'ebetsong ea `Display` e khutlisa phoso.
/// Sena se bontša ts'ebetso e fosahetseng ea `Display` kaha `fmt::Write for String` ha e sa khutlisa phoso ka boeona.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Tataiso e tloaelehileng ke hore u se ke ua beha mehala kahare ho mesebetsi e tloaelehileng.
    // Leha ho le joalo, ho tlosa `#[inline]` mokhoeng ona ho baka likhetho tse seng tsa bohlokoa.
    // Bona <https://github.com/rust-lang/rust/pull/74852>, teko ea hoqetela ea ho leka ho e tlosa.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// E fetola `&mut str` hore e be `String`.
    ///
    /// Sephetho se abeloa qubu.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: teko e hula ka libstd, e bakang liphoso mona
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// E fetola selae sa `str` se fuoeng boxed ho `String`.
    /// Hoa hlokomeleha hore selae sa `str` ke sa eona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// E fetola `String` e fanoeng ho selae sa `str` se nang le mabokose.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// E fetola selae sa khoele hore e be mofuta o fapaneng oa kalimo.
    /// Ha ho kabo ea qubu e etsoang, 'me khoele ha e qopitsoe.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// E fetola khoele hore e be ea mofuta o mong.
    /// Ha ho kabo ea qubu e etsoang, 'me khoele ha e qopitsoe.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// E fetola moelelo oa String hore e be mofuta o fapaneng oa Mokoloto.
    /// Ha ho kabo ea qubu e etsoang, 'me khoele ha e qopitsoe.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// E fetola `String` e fuoeng vector `Vec` e ts'oereng boleng ba mofuta `u8`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Sesebelisoa sa draining sa `String`.
///
/// Moralo ona o entsoe ke mokhoa oa [`drain`] ho [`String`].
/// Bona litokomane tsa eona bakeng sa tse ling.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// E tla sebelisoa e le&'a mut String ho mosenyi
    string: *mut String,
    /// Qala karolo ea ho tlosa
    start: usize,
    /// Qetellong ea karolo ea ho tlosa
    end: usize,
    /// Sebaka sa hona joale se setseng se lokelang ho tlosoa
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Sebelisa Vec::drain.
            // "Reaffirm" meeli e hlahloba ho qoba hore khoutu ea panic e kenngoe hape.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// E khutlisa khoele e setseng (sub) ea iterator ena e le selae.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef e kenya ka tlase ha e tsitsisa.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment ha u tsitsisa `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>bakeng sa Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> bakeng sa Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}