use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Tsebo e 'ngoe ea trait bakeng sa Vec::from_iter e hlokahalang ho beha lintho tse tlang pele ka ho khetheha ho bona ho khetheha ho bona [`SpecFromIter`](super::SpecFromIter) bakeng sa lintlha.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Tlosa phetiso ea pele, kaha vector e tla holisoa ka mokhoa ona maemong ohle ha ho khoneha ho se na letho, empa sekoaelo sa extend_desugared() se ke ke sa bona vector e tletse liketsahalong tse 'maloa tse latelang tsa loop.
        //
        // Kahoo re ba le betere ea branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // e tlameha ho fetisetsa ho spec_extend() ho tloha ha extend() ka boeona e le baemeli ho spec_from bakeng sa li-Vec tse se nang letho
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // e tlameha ho fetisetsa ho spec_extend() ho tloha ha extend() ka boeona e le baemeli ho spec_from bakeng sa li-Vec tse se nang letho
        //
        vector.spec_extend(iterator);
        vector
    }
}