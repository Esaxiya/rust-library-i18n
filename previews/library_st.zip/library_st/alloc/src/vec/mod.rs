//! Mofuta o kopaneng o ka holang o nang le likoto tse abetsoeng qubu, tse ngotsoeng `Vec<T>`.
//!
//! Vectors li na le li-index tsa `O(1)`, li sutumelitse `O(1)` (ho isa qetellong) le `O(1)` pop (ho tloha pheletsong).
//!
//!
//! Vectors li netefatsa hore ha ho mohla li fanang ka li-byte tse fetang `isize::MAX`.
//!
//! # Examples
//!
//! O ka hlahisa [`Vec`] ka ho hlaka le [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... kapa ka ho sebelisa [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // zero zero tse leshome
//! ```
//!
//! O ka beha boleng ba [`push`] qetellong ea vector (e tla holisa vector kamoo ho hlokahalang):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Litekanyetso tsa popping li sebetsa ka tsela e ts'oanang:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors hape e ts'ehetsa indexing (ka [`Index`] le [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Mofuta o kopaneng o holang, o ngotsoeng e le `Vec<T>` mme o phatlalatsa 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] macro e fanoe ho etsa hore qalo e be bonolo haholoanyane:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// E ka qala le karolo e ngoe le e ngoe ea `Vec<T>` ka boleng bo fanoeng.
/// Sena se ka sebetsa hantle ho feta ho etsa kabo le ho qala ka mehato e arohaneng, haholo ha ho qalisoa vector ea zeros:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Tse latelang lia lekana, empa li ka lieha haholo:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Bakeng sa tlhaiso-leseling e batsi, bona [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Sebelisa `Vec<T>` joalo ka pokello e sebetsang hantle:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // E hatisa 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Mofuta oa `Vec` o lumella ho fihlella boleng ka index, hobane e sebelisa [`Index`] trait.Mohlala o tla hlaka haholoanyane:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // e tla bonts'a '2'
/// ```
///
/// Leha ho le joalo hlokomela: haeba u leka ho fumana index e seng ho `Vec`, software ea hau e tla panic!U ke ke ua etsa sena:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Sebelisa [`get`] le [`get_mut`] haeba u batla ho sheba hore na index e teng ho `Vec`.
///
/// # Slicing
///
/// `Vec` e ka fetoha.Ka lehlakoreng le leng, lilae ke lintho tse baloang feela.
/// Ho fumana [slice][prim@slice], sebelisa [`&`].Mohlala:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... mme ke phetho!
/// // u ka e etsa joalo:
/// let u: &[usize] = &v;
/// // kapa tjena:
/// let u: &[_] = &v;
/// ```
///
/// Ho Rust, ho tloaelehile haholo ho fetisa lilae e le likhang ho fapana le vectors ha o batla feela ho fana ka phihlello ea ho bala.Ho joalo le ka [`String`] le [`&str`].
///
/// # Bokgoni le phalliso
///
/// Bokgoni ba vector ke palo ya sebaka se abetsweng dikarolo dife kapa dife tsa future tse tla eketswa ho vector.Sena ha sea lokela ho ferekanngoa le *bolelele* ba vector, e hlalosang palo ea lintho tsa 'nete kahare ho vector.
/// Haeba bolelele ba vector bo feta matla a eona, bokhoni ba eona bo tla eketsoa ka bo eona, empa likarolo tsa eona li tla tlameha ho fallisoa bocha.
///
/// Mohlala, vector e nang le boholo ba 10 le bolelele ba 0 e ka ba vector e se nang letho e nang le sebaka sa likarolo tse ling tse 10.Ho sututsa likarolo tse 10 kapa tse fokolang ho vector ho ke ke ha fetola bokhoni ba eona kapa ha etsa hore phalliso e etsahale.
/// Leha ho le joalo, haeba bolelele ba vector bo nyolohetse ho 11, bo tla tlameha ho fallisoa hape, bo ka liehang.Ka lebaka lena, ho kgothaletswa ho sebelisa [`Vec::with_capacity`] ha ho khonahala ho hlakisa hore na vector e lebelletsoe ho ba kholo hakae.
///
/// # Guarantees
///
/// Ka lebaka la tlhaho ea eona e makatsang, `Vec` e tiisa haholo ka boqapi ba eona.Sena se netefatsa hore e ka tlase-tlase ka hohle kamoo ho ka khonehang maemong a akaretsang, mme e ka sebelisoa ka nepo ka mekhoa ea khale ka khoutu e sa bolokehang.Hlokomela hore li-guaranteed tsena li bua ka `Vec<T>` e sa tšoaneleheng.
/// Haeba mefuta e meng ea mofuta e eketsoa (mohlala, ho ts'ehetsa baabi ba litloaelo), ho tlola liphoso tsa bona ho ka fetola boits'oaro.
///
/// Ha e le hantle, `Vec` e tla lula e le (pointer, capacity, length) triplet.Ha ho sa le joalo, ha ho joalo.Taelo ea libaka tsena ha e tsejoe ka botlalo, 'me u lokela ho sebelisa mekhoa e nepahetseng ho e fetola.
/// Pointer e ke ke ea hlola e sebetsa, ka hona mofuta ona o ntlafalitsoe.
///
/// Leha ho le joalo, sesupi se kanna sa se supe mohopolo o abetsoeng.
/// Ka ho khetheha, haeba u haha `Vec` e nang le 0 ka [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], kapa ka ho letsetsa [`shrink_to_fit`] ho Vec e se nang letho, e ke ke ea fana ka mohopolo.Ka mokhoa o ts'oanang, haeba u boloka mefuta e boholo ba zero kahare ho `Vec`, e ke ke ea ba fa sebaka.
/// *Hlokomela hore maemong ana `Vec` e kanna ea se tlalehe [`capacity`] ea 0*.
/// `Vec` re tla aba haeba feela haeba [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ka kakaretso, lintlha tsa kabo ea `Vec` li bohlale haholo-haeba u ikemiselitse ho fana ka memori u sebelisa `Vec` 'me ue sebelisetse ntho e ngoe (ekaba ho fetisetsa khoutu e sa bolokehang, kapa ho iketsetsa pokello ea hau e bolokang mohopolo), netefatsa ho tsamaisa mohopolo ona ka ho sebelisa `from_raw_parts` ho khutlisa `Vec` ebe oa e lahla.
///
/// Haeba `Vec` * e abetse mohopolo, memori eo e supang ho eona e holim'a qubu (joalo ka ha ho hlalositsoe ke monei Rust e hlophiselitsoe hore e e sebelise ka boiketsetso), 'me sesupi sa eona se supa ho [`len`] e qalileng, likarolo tse ikhethileng ka tatellano (seo o ka bona hore na ue qobelletse selae), e lateloa ke [`capacity`]`,`[`len`] ka mokhoa o utloahalang o sa qalisoa, likarolo tse ikopantseng.
///
///
/// vector e nang le likarolo `'a'` le `'b'` e nang le matla a 4 e ka bonoa ka tlase.Karolo e kaholimo ke sebopeho sa `Vec`, e na le sesupisi ho hlooho ea kabo ho qubu, bolelele le bokhoni.
/// Karolo e ka tlase ke kabo holim'a qubu, mohopolo o kopaneng oa memori.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** e emela mohopolo o sa qalisoang, bona [`MaybeUninit`].
/// - Note: ABI ha e tsitsitse mme `Vec` ha e fane ka tiiso mabapi le sebopeho sa memori ea eona (ho kenyeletsoa le tatellano ea libaka).
///
/// `Vec` e ke ke ea etsa "small optimization" moo likarolo li bolokiloeng mokotleng ka mabaka a mabeli:
///
/// * Ho ka thatafalletsa khoutu e sa bolokehang ho sebelisa `Vec` hantle.Likateng tsa `Vec` li ne li ke ke tsa ba le aterese e tsitsitseng haeba e ne e ka tsamaisoa feela, mme ho ka ba thata le ho feta ho tseba hore na `Vec` e hlile e abetse mohopolo.
///
/// * E ne e tla ahlola nyeoe e akaretsang, e hlahise branch e eketsehileng phihlelong e ngoe le e ngoe.
///
/// `Vec` e ke ke ea ikhula ka bo eona, leha e se na letho.Sena se tiisa hore ha ho na likabo tse sa hlokahaleng kapa liphallelo tse etsahalang.Ho ntsha `Vec` ebe o e tlatsa hape ho [`len`] e ts'oanang ha hoa lokela ho letsetsa moabi.Haeba o lakatsa ho lokolla memori e sa sebelisoeng, sebelisa [`shrink_to_fit`] kapa [`shrink_to`].
///
/// [`push`] mme [`insert`] le ka mohla (re) e ke ke ea aba haeba bokhoni bo tlalehiloeng bo lekane.[`push`] le [`insert`]*li tla*(re) abela haeba [`len`]```==`[` capacity`].Ka mantsoe a mang, matla a tlalehiloeng a nepahetse ka botlalo, 'me ho ka tšeptjoa.E ka sebelisoa ho lokolla mohopolo o fanoeng ke `Vec` haeba ho hlokahala.
/// Mekhoa ea ho kenya bongata * e kanna ea abeloa hape, leha ho sa hlokahale.
///
/// `Vec` ha e fane ka tiiso ea leano le itseng la kholo ha o fuoa kabelo e ngoe hape ha e tletse, leha [`reserve`] e bitsoa.Leano la hajoale ke la mantlha mme ho ka pakahala ho lakatseha ho sebelisa kholo e sa fetoheng.Leano le leng le le leng le sebelisitsoeng le tla netefatsa *O*(1) hore e ntlafatse [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, le [`Vec::with_capacity(n)`][`Vec::with_capacity`], kaofela li tla hlahisa `Vec` e nang le matla a kopiloeng hantle.
/// Haeba [`len`]`==`[`capacity`], (joalo ka ha ho le joalo bakeng sa [`vec!`] macro), ebe `Vec<T>` e ka fetoleloa ho le ho tloha ho [`Box<[T]>`][owned slice] ntle le ho fallisa kapa ho tsamaisa lintho.
///
/// `Vec` e ke ke ea hlakola data efe kapa efe e tlositsoeng ho eona, empa hape e ke ke ea e boloka ka kotloloho.Memori ea eona e sa qalisoang ke sebaka sa ho qala seo e ka se sebelisang leha e batla.Ka kakaretso e tla etsa eng kapa eng e sebetsang hantle kapa e seng bonolo ho e sebelisa.Se ke oa itšetleha ka data e tlositsoeng hore e hlakoloe molemong oa ts'ireletso.
/// Le ha o ka lahla `Vec`, buffer ea eona e ka sebelisoa hape ke `Vec` e ngoe.
/// Le ha o sa hopole mohopolo oa `Vec` pele, seo se kanna sa se etsahale hobane sebapali ha se nke sena e le litlamorao tse lokelang ho bolokoa.
/// Ho na le nyeoe e le 'ngoe eo re ke keng ra e roba, leha ho le joalo: ho sebelisa khoutu ea `unsafe` ho ngolla bokhoni bo fetelletseng, ebe re eketsa bolelele ho bapisa, ho lula ho nepahetse.
///
/// Hajoale, `Vec` ha e fane ka tiiso ea tatellano eo likarolo li oeloang ka eona.
/// Taelo e fetohile nakong e fetileng mme e kanna ea fetoha hape.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Mekhoa ea tlhaho
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// E theha `Vec<T>` e ncha, e se nang letho.
    ///
    /// vector e ke ke ea arolelana ho fihlela likarolo li sutumelloa ho eona.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// E theha `Vec<T>` e ncha, e se nang letho e nang le matla a boletsoeng.
    ///
    /// vector e tla khona ho ts'oara likarolo tsa `capacity` ntle le ho fallisoa hape.
    /// Haeba `capacity` e le 0, vector e ke ke ea aba.
    ///
    /// Ho bohlokoa ho hlokomela hore leha vector e khutlisitsoeng e na le "capacity *e boletsoeng, vector e tla ba le zero* bolelele *.
    ///
    /// Bakeng sa tlhaloso ea phapang lipakeng tsa bolelele le bokhoni, bona *[Matla le phalliso]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ha e na lintho, leha e na le matla a ho feta
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tsena tsohle li etsoa ntle le ho fallisoa hape ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... empa sena se ka etsa hore vector e fallisoe hape
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// E etsa `Vec<T>` ka kotloloho ho tsoa ho likarolo tse tala tsa vector e ngoe.
    ///
    /// # Safety
    ///
    /// Sena ha se bolokehe haholo, ka lebaka la palo ea lintho tse kenang tse sa hlahlojoeng:
    ///
    /// * `ptr` e hloka hore ebe e ne e abiloe pejana ka [`String`]/`Vec<T>`(bonyane, ho ka etsahala hore ebe e fosahetse haeba ho ne ho se joalo).
    /// * `T` e hloka ho ba le boholo le tatellano e tšoanang le eo `ptr` e abetsoeng eona.
    ///   (`T` e nang le tatellano e sa tenyetseheng ha ea lekana, tatellano e hlile e hloka ho lekana ho khotsofatsa tlhoko ea [`dealloc`] ea hore memori e lokela ho abuoa le ho tsamaisoa ka sebopeho se tšoanang.)
    ///
    /// * `length` e hloka ho ba ka tlase ho kapa ho lekana le `capacity`.
    /// * `capacity` e hloka hore e be bokhoni boo sesupi se abetsoeng sona.
    ///
    /// Ho tlola tsena ho ka baka mathata a joalo ka ho senya likarolo tsa data tsa kahare tsa morekisi.Mohlala ha ho ** sireletsehileng ho aha `Vec<u8>` ho tloha pointer ho ea ho X XXUMUMXX e bolelele ba `size_t`.
    /// Hape ha ho a bolokeha ho aha e 'ngoe ho tloha `Vec<u16>` le bolelele ba eona, hobane seabi se tsotella tatellano,' me mefuta ena e 'meli e na le tatellano e fapaneng.
    /// Buffer e ile ea abuoa ka tatellano ea 2 (bakeng sa `u16`), empa kamora ho e fetola `Vec<u8>` e tla tsamaisoa ka tatellano ea 1.
    ///
    /// Botho ba `ptr` bo fetisetsoa ho `Vec<T>` ka katleho e ka tsamaisang, ea abela hape kapa ea fetola se kahare sa memori se supisitsoeng ke sesupi ka thato.
    /// Etsa bonnete ba hore ha ho letho le leng le sebelisang pointer kamora ho bitsa ts'ebetso ena.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ntlafatsa sena ha vec_into_raw_parts e tsitsitse.
    ///     // Thibela tšenyo ea `v` ka hona re laola taolo ka botlalo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hula lintlha tse fapaneng tsa bohlokoa mabapi le `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Ngola mohopolo ka 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Khutlisetsa ntho e ngoe le e ngoe ho Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// E theha `Vec<T, A>` e ncha, e se nang letho.
    ///
    /// vector e ke ke ea arolelana ho fihlela likarolo li sutumelloa ho eona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// E theha `Vec<T, A>` e ncha, e se nang letho e nang le matla a boletsoeng le kabo e fanoeng.
    ///
    /// vector e tla khona ho ts'oara likarolo tsa `capacity` ntle le ho fallisoa hape.
    /// Haeba `capacity` e le 0, vector e ke ke ea aba.
    ///
    /// Ho bohlokoa ho hlokomela hore leha vector e khutlisitsoeng e na le "capacity *e boletsoeng, vector e tla ba le zero* bolelele *.
    ///
    /// Bakeng sa tlhaloso ea phapang lipakeng tsa bolelele le bokhoni, bona *[Matla le phalliso]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ha e na lintho, leha e na le matla a ho feta
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tsena tsohle li etsoa ntle le ho fallisoa hape ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... empa sena se ka etsa hore vector e fallisoe hape
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// E etsa `Vec<T, A>` ka kotloloho ho tsoa ho likarolo tse tala tsa vector e ngoe.
    ///
    /// # Safety
    ///
    /// Sena ha se bolokehe haholo, ka lebaka la palo ea lintho tse kenang tse sa hlahlojoeng:
    ///
    /// * `ptr` e hloka hore ebe e ne e abiloe pejana ka [`String`]/`Vec<T>`(bonyane, ho ka etsahala hore ebe e fosahetse haeba ho ne ho se joalo).
    /// * `T` e hloka ho ba le boholo le tatellano e tšoanang le eo `ptr` e abetsoeng eona.
    ///   (`T` e nang le tatellano e sa tenyetseheng ha ea lekana, tatellano e hlile e hloka ho lekana ho khotsofatsa tlhoko ea [`dealloc`] ea hore memori e lokela ho abuoa le ho tsamaisoa ka sebopeho se tšoanang.)
    ///
    /// * `length` e hloka ho ba ka tlase ho kapa ho lekana le `capacity`.
    /// * `capacity` e hloka hore e be bokhoni boo sesupi se abetsoeng sona.
    ///
    /// Ho tlola tsena ho ka baka mathata a joalo ka ho senya likarolo tsa data tsa kahare tsa morekisi.Mohlala ha ho ** sireletsehileng ho aha `Vec<u8>` ho tloha pointer ho ea ho X XXUMUMXX e bolelele ba `size_t`.
    /// Hape ha ho a bolokeha ho aha e 'ngoe ho tloha `Vec<u16>` le bolelele ba eona, hobane seabi se tsotella tatellano,' me mefuta ena e 'meli e na le tatellano e fapaneng.
    /// Buffer e ile ea abuoa ka tatellano ea 2 (bakeng sa `u16`), empa kamora ho e fetola `Vec<u8>` e tla tsamaisoa ka tatellano ea 1.
    ///
    /// Botho ba `ptr` bo fetisetsoa ho `Vec<T>` ka katleho e ka tsamaisang, ea abela hape kapa ea fetola se kahare sa memori se supisitsoeng ke sesupi ka thato.
    /// Etsa bonnete ba hore ha ho letho le leng le sebelisang pointer kamora ho bitsa ts'ebetso ena.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ntlafatsa sena ha vec_into_raw_parts e tsitsitse.
    ///     // Thibela tšenyo ea `v` ka hona re laola taolo ka botlalo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Hula lintlha tse fapaneng tsa bohlokoa mabapi le `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Ngola mohopolo ka 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Khutlisetsa ntho e ngoe le e ngoe ho Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// E bolaea `Vec<T>` ka likarolo tsa eona tse tala.
    ///
    /// E khutlisetsa pointer e tala ho data ea motheo, bolelele ba vector (ka likarolo), le matla a fanoeng a data (ka likarolo).
    /// Tsena ke mabaka a tšoanang ka tatellano e tšoanang le likhang tsa [`from_raw_parts`].
    ///
    /// Kamora ho bitsa ts'ebetso ena, moletsi o ikarabella ho memori e neng e laoloa pele ke `Vec`.
    /// Mokhoa o le mong feela oa ho etsa sena ke ho fetolela sesupa se botala, bolelele le matla hore e be `Vec` ka ts'ebetso ea [`from_raw_parts`], e lumellang mosenyi hore a hloekise.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ha joale re ka etsa liphetoho ho likarolo, joalo ka ho fetisetsa sesupa se tala ho mofuta o lumellanang.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// E bolaea `Vec<T>` ka likarolo tsa eona tse tala.
    ///
    /// E khutlisetsa pointer e tala ho data ea motheo, bolelele ba vector (ka likarolo), matla a fanoeng a data (ka likarolo), le mofani.
    /// Tsena ke mabaka a tšoanang ka tatellano e tšoanang le likhang tsa [`from_raw_parts_in`].
    ///
    /// Kamora ho bitsa ts'ebetso ena, moletsi o ikarabella ho memori e neng e laoloa pele ke `Vec`.
    /// Mokhoa o le mong feela oa ho etsa sena ke ho fetolela sesupa se botala, bolelele le matla hore e be `Vec` ka ts'ebetso ea [`from_raw_parts_in`], e lumellang mosenyi hore a hloekise.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ha joale re ka etsa liphetoho ho likarolo, joalo ka ho fetisetsa sesupa se tala ho mofuta o lumellanang.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// E khutlisa palo ea lisebelisoa tseo vector e ka li ts'oarang ntle le ho fallisoa hape.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// E boloka matla a bonyane lintho tse ling tsa `additional` tse tla kenngoa ho `Vec<T>` e fanoeng.
    /// Pokello e ka boloka sebaka se eketsehileng ho qoba ho fallisoa khafetsa.
    /// Kamora ho letsetsa `reserve`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo lekane.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta li-byte tsa `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// E boloka matla a bonyane bakeng sa lintlha tse ling tsa `additional` tse tla kenngoa ho `Vec<T>` e fanoeng.
    ///
    /// Kamora ho letsetsa `reserve_exact`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo ntse bo lekane.
    ///
    /// Hlokomela hore morekisi a ka fa pokello sebaka se fetang seo a se kopileng.
    /// Ka hona, bokhoni bo ke ke ba ts'epahloa hore bo be tlase haholo.
    /// Khetha `reserve` haeba ho lebelletsoe kenyelletso ea future.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// E leka ho boloka bokhoni ba bonyane likarolo tse ling tsa `additional` tse tla kenngoa ho `Vec<T>` e fanoeng.
    /// Pokello e ka boloka sebaka se eketsehileng ho qoba ho fallisoa khafetsa.
    /// Kamora ho letsetsa `try_reserve`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo lekane.
    ///
    /// # Errors
    ///
    /// Haeba matla a khaphatseha, kapa morekisi a tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // thatafetse haholo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// E leka ho boloka bonyane matla bakeng sa likarolo tsa `additional` hantle hore li kenngoe ho `Vec<T>` e fanoeng.
    /// Kamora ho letsetsa `try_reserve_exact`, matla a tla ba maholo ho feta kapa a lekana le `self.len() + additional` haeba e khutlisa `Ok(())`.
    ///
    /// Ha e etse letho haeba bokhoni bo se bo ntse bo lekane.
    ///
    /// Hlokomela hore morekisi a ka fa pokello sebaka se fetang seo a se kopileng.
    /// Ka hona, bokhoni bo ke ke ba ts'epahloa hore bo be tlase haholo.
    /// Khetha `reserve` haeba ho lebelletsoe kenyelletso ea future.
    ///
    /// # Errors
    ///
    /// Haeba matla a khaphatseha, kapa morekisi a tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // thatafetse haholo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// E fokotsa matla a vector ka hohle kamoo ho ka khonehang.
    ///
    /// E tla theoha haufi ka hohle kamoo ho ka khonehang bolelele empa mofani oa thepa a ntse a ka tsebisa vector hore ho na le sebaka sa likarolo tse ling tse 'maloa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Bokhoni ha bo ka tlase ho bolelele, 'me ha ho na letho le lokelang ho etsoa ha ba lekana, ka hona re ka qoba nyeoe ea panic ho `RawVec::shrink_to_fit` ka ho e letsetsa feela ka bokhoni bo boholo.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// E fokotsa matla a vector ka mohala o tlase.
    ///
    /// Bokgoni bo tla lula bonyane bo le boholo bo bolelele le boleng bo fanoeng ka bobeli.
    ///
    ///
    /// Haeba matla a hajoale a le tlase ho moeli o tlase, hona ke ho se sebetse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// E fetolela vector ho [`Box<[T]>`][owned slice].
    ///
    /// Hlokomela hore sena se tla lahla bokhoni bofe kapa bofe bo fetelletseng.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Bokhoni bofe kapa bofe bo fetelletseng bo tlosoa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// E khutsufatsa vector, e boloka likarolo tsa pele tsa `len` ebe e lahla tse ling kaofela.
    ///
    /// Haeba `len` e kholo ho feta bolelele ba hajoale ba vector, sena ha se na phello.
    ///
    /// Mokhoa oa [`drain`] o ka etsisa `truncate`, empa o baka hore likarolo tse fetelletseng li khutlisoe ho fapana le ho lahloa.
    ///
    ///
    /// Hlokomela hore mokhoa ona ha o na matla ho matla a abetsoeng vector.
    ///
    /// # Examples
    ///
    /// Ho fokotsa lintlha tse hlano vector ho likarolo tse peli:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ha ho truncation e etsahalang ha `len` e le kholo ho feta bolelele ba hajoale ba vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating ha `len == 0` e lekana le ho bitsa mokhoa oa [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Sena se bolokehile hobane:
        //
        // * selae se fetisitsoeng ho `drop_in_place` se nepahetse;nyeoe ea `len > self.len` e qoba ho theha selae se sa sebetseng, 'me
        // * `len` ea vector e fokotsehile pele e letsetsa `drop_in_place`, hore ho se be le boleng bo tla theoha habeli haeba `drop_in_place` e ne e ka ba panic hang (haeba e le panics habeli, lenaneo lea emisa).
        //
        //
        //
        unsafe {
            // Note: Ke ka boomo hore ena ke `>` eseng `>=`.
            //       Ho e fetolela ho `>=` ho ka ba le litlamorao tse mpe tsa ts'ebetso maemong a mang.
            //       Bona #78884 bakeng sa tse ling.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Se qhekella selae se nang le vector kaofela.
    ///
    /// E lekana le `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// E ntša selae se ka fetohang sa vector kaofela.
    ///
    /// E lekana le `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// E khutlisetsa sesupa se tala ho buffer ea vector.
    ///
    /// Moletsi o lokela ho netefatsa hore vector e feta senotlolo ha mosebetsi ona o khutla, ho seng joalo e tla qetella e supa litšila.
    /// Ho fetola vector ho ka etsa hore buffer ea eona e fallisoe hape, e leng ho tla etsa hore litlhahiso ho eona e se sebetse.
    ///
    /// Motho ea letsitseng o boetse o tlameha ho netefatsa hore memori eo pointer a e supang (non-transitively) e ke ke ea ngoloa ho eona (ntle le ka hare ho `UnsafeCell`) a sebelisa sesupi sena kapa sesupi sefe kapa sefe se tsoang ho sona.
    /// Haeba o hloka ho fetola likahare tsa selae, sebelisa [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Re koahela mokhoa oa selae sa lebitso le le leng ho qoba ho feta `deref`, e hlahisang sets'oants'o sa lipakeng.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// E khutlisetsa sesupi se sa bolokehang se ka fetoloang ho buffer ea vector.
    ///
    /// Moletsi o lokela ho netefatsa hore vector e feta senotlolo ha mosebetsi ona o khutla, ho seng joalo e tla qetella e supa litšila.
    ///
    /// Ho fetola vector ho ka etsa hore buffer ea eona e fallisoe hape, e leng ho tla etsa hore litlhahiso ho eona e se sebetse.
    ///
    /// # Examples
    ///
    /// ```
    /// // Abela vector e kholo ho lekana likarolo tsa 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Qala likarolo ka sesupa se tala oa ngola, ebe u beha bolelele.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Re koahela mokhoa oa selae sa lebitso le le leng ho qoba ho feta `deref_mut`, e hlahisang sets'oants'o sa lipakeng.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// E khutlisetsa ts'upiso ho mofani oa thepa ea mantlha.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// E qobella bolelele ba vector ho `new_len`.
    ///
    /// Ona ke ts'ebetso ea maemo a tlase e sa bolokeng lihlaseli tse tloaelehileng tsa mofuta ona.
    /// Ka tloaelo ho fetola bolelele ba vector ho etsoa ka ts'ebetso e sireletsehileng ho fapana le [`truncate`], [`resize`], [`extend`], kapa [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` e tlameha ho ba tlase ho kapa e lekane le [`capacity()`].
    /// - Lintlha tsa `old_len..new_len` li tlameha ho qalisoa.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Mokhoa ona o ka ba molemo bakeng sa maemo ao vector e sebeletsang ho ona bakeng sa khoutu e ngoe, haholoholo ho feta FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ona ke masapo a fokolang feela bakeng sa mohlala oa doc;
    /// # // se ke oa sebelisa sena e le qalo ea laeborari ea 'nete.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Ho latela litokomane tsa mokhoa oa FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // TŠIRELETSO: Ha `deflateGetDictionary` e khutlisa `Z_OK`, e tiisa hore:
    ///     // 1. `dict_length` likarolo li ile tsa qalisoa.
    ///     // 2.
    ///     // `dict_length` <=matla (32_768) a etsang hore `set_len` e bolokehe hore e ka letsetsoa.
    ///     unsafe {
    ///         // Etsa mohala oa FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... 'me u nchafatse bolelele ho ba se qalileng.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Le ha mohlala o latelang o utloahala, ho na le phallo ea memori ho tloha ha vectors e kahare e sa ka ea lokolloa pele ho mohala oa `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ha e na letho kahoo ha ho na likarolo tse hlokang ho qalisoa.
    /// // 2. `0 <= capacity` kamehla e ts'oara eng kapa eng ea `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Ka tloaelo, mona, motho o ne a ka sebelisa [`clear`] ho fapana le ho lahla se kahare ka nepo mme ka hona a se ke a lutla mohopolo.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// E tlosa ntho ho vector ebe ea e khutlisa.
    ///
    /// Karolo e tlositsoeng e nkeloa sebaka ke elemente ea ho qetela ea vector.
    ///
    /// Sena ha se boloke tatellano, empa ke O(1).
    ///
    /// # Panics
    ///
    /// Panics haeba `index` e tsoa meeling.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Re nka sebaka sa rona [index] ka ntlha ea hoqetela.
            // Hlokomela hore haeba ho lekoa ha meeli e kaholimo ho atleha ho tlameha hore ho be le elemente ea ho qetela (eo e ka bang eona [index] ka boyona).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// E kenya ntho maemong a `index` kahare ho vector, e fetisetsa likarolo tsohle kamora eona ho le letona.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // sebaka sa ntlha e ncha
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // e sa foseng Sebaka sa ho beha boleng bo bocha
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Tlosa tsohle ho etsa sebaka.
                // (Ho kopitsa ntlha ea `index` libakeng tse peli tse latellanang.)
                ptr::copy(p, p.offset(1), len - index);
                // E ngolle, u hlakole kopi ea pele ea `index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// E tlosa le ho khutlisa element sebakeng sa `index` kahare ho vector, e fetisetsa likarolo tsohle kamora eona ho le letšehali.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `index` e tsoa meeling.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // sebaka seo re nkang ho sona.
                let ptr = self.as_mut_ptr().add(index);
                // e kopise, ka mokhoa o sa bolokehang o na le khopi ea boleng ka mokotleng le ho vector ka nako e le 'ngoe.
                //
                ret = ptr::read(ptr);

                // Suthela tsohle ho tlatsa sebaka seo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// E boloka feela likarolo tse boletsoeng ke lereho.
    ///
    /// Ka mantsoe a mang, tlosa likarolo tsohle `e` hore `f(&e)` e khutlise `false`.
    /// Mokhoa ona o sebetsa sebakeng sa ona, o etela karolo ka 'ngoe hantle hang feela ka tatellano ea mantlha, mme o boloka tatellano ea likarolo tse bolokiloeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Hobane likarolo li eteloa hantle hanngoe ka tatellano ea pele, naha e kantle e ka sebelisoa ho etsa qeto ea hore na ho bolokoa likarolo life.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Qoba lerotholi habeli haeba molebeli a sa phethisoe, hobane re kanna ra etsa masoba nakong ea ts'ebetso.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-sebetswa len-> |^-haufi le ho hlahloba
        //                  | <-e hlakotsoe cnt-> |
        //      | <-qalong_len-> |E bolokiloe: Lintho tse boletsoeng esale pele li khutlela ho 'nete ka.
        //
        // Hole: Karolo ea elemente e fallisitsoeng kapa e oeleng.
        // E sa hlahlojoe: Ho sa hlahlojoe likarolo tse nepahetseng.
        //
        // Mohlokomeli enoa oa lerotholi o tla sebelisoa ha sebui kapa `drop` ea ntho e tšohile.
        // E fetola likarolo tse sa hlahlojoeng ho koahela masoba le `set_len` ho ea bolelele bo nepahetseng.
        // Maemong ha moemeli le `drop` ba sa tšohe, e tla ntlafatsoa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // TŠIRELETSO: Ho latela lintho tse sa hlahlojoang ho tlameha ho sebetsa hobane ha ho mohla re li amang.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // TSHIRELETSO: Kamora ho tlatsa masoba, lintho tsohle li mohopolong o kopaneng.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // POLOKEHO: Karolo e sa hlahlojoeng e tlameha ho sebetsa.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Tsoela pele kapele ho qoba lerotholi habeli haeba `drop_in_place` e tšohile.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // TSHIRELETSO: Ha re sa tla ama ntho ena hape kamora hore e we.
                unsafe { ptr::drop_in_place(cur) };
                // Re se re tsoetse pele khaontareng.
                continue;
            }
            if g.deleted_cnt > 0 {
                // POLOKEHO: `deleted_cnt`> 0, ka hona sekoti sa lesoba ha sea lokela ho kopana le ntho ea hajoale.
                // Re sebelisa kopi bakeng sa ho tsamaea, 'me ha ho mohla re tla ama ntho ena hape.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Lintho tsohle li sebetsoa.Sena se ka ntlafatsoa ho `set_len` ke LLVM.
        drop(g);
    }

    /// E tlosa tsohle ntle le tsa pele tsa likarolo tse latellanang ho vector tse ikemiselitseng ho senotlolo se le seng.
    ///
    ///
    /// Haeba vector e hlophisitsoe, sena se tlosa likhatiso tsohle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// E tlosa tsohle ntle le tsa pele tsa likarolo tse latellanang ho vector e khotsofatsang kamano e fanoeng ea tekano.
    ///
    /// Mosebetsi oa `same_bucket` o fetisitsoe ka litšupiso tsa likarolo tse peli tse tsoang ho vector mme o tlameha ho fumana hore na likarolo li bapisoa li lekana.
    /// Lintlha li fetisoa ka tatellano e fapaneng ho tloha ka tatellano ea tsona selae, kahoo haeba `same_bucket(a, b)` e khutlisa `true`, `a` e tlosoa.
    ///
    ///
    /// Haeba vector e hlophisitsoe, sena se tlosa likhatiso tsohle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// E kenya karolo e ka morao ea pokello.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta li-byte tsa `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Sena se tla panic kapa re ntše mpa haeba re ka abela> isize::MAX byte kapa haeba bolelele ba bolelele bo ka tlala ka mefuta ea boholo ba zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// E tlosa ntho ea hoqetela ho vector ebe ea e khutlisa, kapa [`None`] haeba e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// E tsamaisa likarolo tsohle tsa `other` ho `Self`, e siea `other` e se na letho.
    ///
    /// # Panics
    ///
    /// Panics haeba palo ea likarolo tsa vector e feta `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// E kenya likarolo ho `Self` ho tsoa ho buffer e ngoe.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// E theha sehlahlo sa draining se tlosang mefuta e boletsoeng ho vector ebe se hlahisa lintho tse tlositsoeng.
    ///
    /// Ha iterator **e** e theotsoe, likarolo tsohle tse lenaneng li tlosoa ho vector, le haeba iterator e ne e sa sebelisoe ka botlalo.
    /// Haeba iterator ** e sa theoleloa (ka mohlala, [`mem::forget`]), ha ho tsejoe hore na ho tlositsoe likarolo tse kae.
    ///
    /// # Panics
    ///
    /// Panics haeba qalo e kholo ho feta ntlha ea ho qetela kapa haeba ntlha ea qetello e kholo ho feta bolelele ba vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Lenane le felletseng le hlakola vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Polokeho ea memori
        //
        // Ha Drain e qala ho etsoa, e khutsufatsa bolelele ba mohloli vector ho etsa bonnete ba hore ha ho na lisebelisoa tse sa qalisoang kapa tse tlositsoeng tse fumanehang ho hang haeba sesenyi sa Drain se ke ke sa sebetsa.
        //
        //
        // Drain e tla tsoa ho ptr::read litekanyetso tseo u lokelang ho li tlosa.
        // Ha o qetile, mohatla o setseng oa vec o kopitsoa hape ho koahela lesoba, mme bolelele ba vector bo khutlisoa bolelele bo bocha.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // beha bolelele ba self.vec ho qala, ho bolokeha haeba Drain e ka tsoa
            self.set_len(start);
            // Sebelisa ho kalima ho IterMut ho bonts'a boits'oaro ba ho kalima ZerD00rain iterator eohle (joalo ka &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// E hloekisa vector, e tlosa litekanyetso tsohle.
    ///
    /// Hlokomela hore mokhoa ona ha o na matla ho matla a abetsoeng vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// E khutlisa palo ea likarolo tsa vector, eo hape e bitsoang 'length' ea eona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// E khutlisa `true` haeba vector e se na likarolo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// A arola pokello ka bobeli ho index e fanoeng.
    ///
    /// E khutlisa vector e sa tsoa fuoa e nang le likarolo tsa `[at, len)`.
    /// Kamora mohala, vector ea mantlha e tla sala e na le likarolo tsa `[0, at)` ka matla a eona a fetileng a sa fetohe.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector e ncha e ka nka buffer ea pele mme ea qoba kopi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // E sa sireletseha `set_len` 'me u kopise lintho ho `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// E nchafatsa `Vec` sebakeng sa eona e le hore `len` e lekane le `new_len`.
    ///
    /// Haeba `new_len` e kholo ho feta `len`, `Vec` e atolosoa ka phapang, mme slot e ngoe le e ngoe e tlatsitsoe ka sephetho sa ho bitsa ho koaloa `f`.
    ///
    /// Litekanyetso tsa ho khutla tse tsoang `f` li tla qetella li le `Vec` ka tatellano eo li hlahisitsoeng ka eona.
    ///
    /// Haeba `new_len` e ka tlase ho `len`, `Vec` e fokotsoe feela.
    ///
    /// Mokhoa ona o sebelisa ho koala ho theha boleng bo bocha tlhaselong e ngoe le e ngoe.Haeba u khetha [`Clone`] boleng bo fanoeng, sebelisa [`Vec::resize`].
    /// Haeba u batla ho sebelisa [`Default`] trait ho hlahisa boleng, u ka fetisa [`Default::default`] e le khang ea bobeli.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// E sebelisa le ho lutla `Vec`, e khutlisetsa ts'upiso e ka fetoloang ho tse ka hare, `&'a mut [T]`.
    /// Hlokomela hore mofuta oa `T` o tlameha ho phela nako e telele e khethiloeng ea `'a`.
    /// Haeba mofuta o na le litšupiso tse sa fetoheng, kapa ha o na tsona, ho ka khethoa hore e be `'static`.
    ///
    /// Ts'ebetso ena e ts'oana le ts'ebetso ea [`leak`][Box::leak] ho [`Box`] ntle le hore ha ho na mokhoa oa ho khutlisa memori e dutlileng.
    ///
    ///
    /// Ts'ebetso ena e bohlokoa haholo bakeng sa data e phelisang karolo e setseng ea bophelo ba lenaneo.
    /// Ho lahla tšupiso e khutlisitsoeng ho tla etsa hore memori e lutle.
    ///
    /// # Examples
    ///
    /// Ts'ebeliso e bonolo:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// E khutlisa matla a setseng a vector joalo ka selae sa `MaybeUninit<T>`.
    ///
    /// Selae se khutlisitsoeng se ka sebelisoa ho tlatsa vector ka data (mohlala
    /// ka ho bala ho tsoa faeleng) pele u tšoaea data e le e qalileng u sebelisa mokhoa oa [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Abela vector e kholo ho lekana likarolo tsa 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Tlatsa likarolo tsa pele tse 3.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Tšoaea likarolo tsa pele tse 3 tsa vector e le tse qalileng.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Mokhoa ona ha o sebelisoe ho latela `split_at_spare_mut`, ho thibela ho se sebetse ha litsupa ho buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// E khutlisa litaba tsa vector joalo ka selae sa `T`, hammoho le matla a setseng a vector joalo ka selae sa `MaybeUninit<T>`.
    ///
    /// Sekhechana sa matla a ho khutlisa se ka sebelisoa ho tlatsa vector ka data (mohlala, ka ho bala ho tsoa faeleng) pele u tšoaea data e le e qalileng u sebelisa mokhoa oa [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Hlokomela hore ena ke API ea maemo a tlase, e lokelang ho sebelisoa ka hloko bakeng sa ntlafatso.
    /// Haeba o hloka ho kenya data ho `Vec` o ka sebelisa [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] kapa [`resize_with`], ho latela litlhoko tsa hau.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Boloka sebaka se eketsehileng se lekaneng bakeng sa likarolo tse 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Tlatsa likarolo tse 4 tse latelang.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Tšoaea likarolo tsa 4 tsa vector e le tse qalileng.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len e hlokomolohuoa ka hona ha e fetohe
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Polokeho: phetoho e khutlisitsoeng .2 (&mut usize) e nkuoa e ts'oana le ho letsetsa `.set_len(_)`.
    ///
    /// Mokhoa ona o sebelisetsoa ho ba le phihlello e ikhethang ho likarolo tsohle tsa vec hang ka `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` e netefalitsoe hore e tla sebetsa bakeng sa likarolo tsa `len`
        // - `spare_ptr` e supa ntho e le 'ngoe e fetileng ho buffer, ka hona ha e tsamaellane le `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// E nchafatsa `Vec` sebakeng sa eona e le hore `len` e lekane le `new_len`.
    ///
    /// Haeba `new_len` e kholo ho feta `len`, `Vec` e atolosoa ka phapang, ka slot e ngoe le e ngoe e tlatsitsoeng ka `value`.
    ///
    /// Haeba `new_len` e ka tlase ho `len`, `Vec` e fokotsoe feela.
    ///
    /// Mokhoa ona o hloka `T` ho kenya ts'ebetsong [`Clone`], molemong oa ho khona ho kopanya boleng bo fetisitsoeng.
    /// Haeba o hloka ho fetoha habonolo (kapa u batla ho itšetleha ka [`Default`] ho fapana le [`Clone`]), sebelisa [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones mme e kenya likarolo tsohle ka selae ho ea ho `Vec`.
    ///
    /// E fetolela sekhechana sa `other`, e kopanya ntho ka 'ngoe ebe e e kenya ho `Vec` ena.
    /// `other` vector e haoloa ka tatellano.
    ///
    /// Hlokomela hore ts'ebetso ena e ts'oana le [`extend`] ntle le hore e khethehile ho sebetsa le lilae ho fapana.
    ///
    /// Haeba Rust e fumana boiphihlelo mosebetsi ona o kanna oa fokotsoa (empa o ntse o le teng).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// E kopitsa likarolo tsa `src` ho fihlela qetellong ea vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` E netefatsa hore mokoloko o fanoeng o nepahetse bakeng sa ho iketsa index
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Khoutu ena e akaretsa `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Eketsa vector ka litekanyetso tsa `n`, u sebelisa jenereithara e fanoeng.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Sebelisa SetLenOnDrop ho sebetsa haufi le kokoana-hloko moo moqapi a kanna a se hlokomele lebenkele ka `ptr` ho fihlela self.set_len() ha e na lebitso.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ngola likarolo tsohle ntle le ea ho qetela
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Eketsa bolelele mohatong o mong le o mong haeba next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Re ka ngola ntlha ea ho qetela ka kotloloho ntle le ho ikopanya ho sa hlokahale
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len e behiloeng ke balebeli ba bophara
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// E tlosa likarolo tse phetoang khafetsa ho vector ho latela ts'ebetso ea [`PartialEq`] trait.
    ///
    ///
    /// Haeba vector e hlophisitsoe, sena se tlosa likhatiso tsohle.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mekhoa le mesebetsi ea kahare
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` e hloka ho ba index e nepahetseng
    /// - `self.capacity() - self.len()` e tlameha ho ba `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len e eketseha feela kamora ho qala likarolo
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - baletsi ba li-guarate hore src ke index e nepahetseng
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element e sa tsoa qalisoa ka `MaybeUninit::write`, ka hona ho lokile ho eketsa len
            // - len e eketseha kamora 'ngoe le e' ngoe ea lintho ho thibela ho dutla (bona taba #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - baletsi ba li-guarate hore `src` ke index e nepahetseng
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Litlhahiso ka bobeli li entsoe ka litšupiso tse ikhethang tsa selae (`&mut [_]`) ka hona li nepahetse ebile ha li kopane.
            //
            // - Lintho ke: Kopitsa kahoo ho lokile ho li kopitsa, ntle le ho etsa letho ka litekanyetso tsa mantlha
            // - `count` e lekana le len ea `source`, ka hona mohloli o nepahetse bakeng sa ho baloa ha `count`
            // - `.reserve(count)` e tiisa hore `spare.len() >= count` e bolokiloeng joalo e nepahetse bakeng sa `count` ea ngola
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Lintho tsa motheo li sa tsoa qalisoa ke `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ts'ebetsong e tloaelehileng ea trait bakeng sa Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ka cfg(test) mokhoa oa tlhaho oa `[T]::to_vec`, o hlokehang bakeng sa tlhaloso ea mokhoa ona, ha o fumanehe.
    // Sebakeng seo sebelisa `slice::to_vec` function e fumanehang feela ka cfg(test) NB bona module ea slice::hack ho slice.rs bakeng sa tlhaiso-leseling e batsi
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // lahlela eng kapa eng e ke keng ea ngoloa
        self.truncate(other.len());

        // self.len <= other.len ka lebaka la truncate e kaholimo, ka hona, lilae tsa mona li lula li le moeling.
        //
        let (init, tail) = other.split_at(self.len());

        // sebelisa hape litekanyetso tse nang le allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// E theha sehlahlo se jang, ke hore, se tsamaisang boleng ka bong ho vector (ho tloha qalong ho isa qetellong).
    /// vector e ke ke ea sebelisoa kamora ho letsetsa sena.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s e na le mofuta oa String, eseng &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf mokhoa oo ts'ebetsong e fapaneng ea SpecFrom/SpecExtend e fanang ka ona ha o se na litokisetso tse ling tsa ho o sebelisa
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ena ke taba ea mohlahlobi oa kakaretso.
        //
        // Mosebetsi ona e lokela ho ba boitšoaro bo lekanang le:
        //
        //      bakeng sa ntho e ho iterator
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB e ka se khaphatsehe kaha re ka be re ile ra tlameha ho fana ka sebaka sa aterese
                self.set_len(len + 1);
            }
        }
    }

    /// E etsa sesebelisi se hlatsoang se nkang sebaka sa mofuta o boletsoeng ho vector le `replace_with` e fanoeng ka eona ebe se hlahisa lintho tse tlositsoeng.
    ///
    /// `replace_with` ha e hloke ho ba bolelele bo lekanang le `range`.
    ///
    /// `range` e tlosoa le haeba iterator e sa sebelisoe ho fihlela qetellong.
    ///
    /// Ha ho tsejoe hore na ho tlositsoe likarolo tse kae ho vector haeba boleng ba `Splice` bo lutla.
    ///
    /// Iterator ea ho kenya `replace_with` e sebelisoa feela ha boleng ba `Splice` bo theohile.
    ///
    /// Sena se nepahetse haeba:
    ///
    /// * Mohatla (likarolo tsa vector kamora `range`) ha o na letho,
    /// * kapa `replace_with` e hlahisa likarolo tse fokolang kapa tse lekanang ho feta bolelele ba `range"
    /// * kapa tlamo e tlase ea `size_hint()` ea eona e nepahetse.
    ///
    /// Ho seng joalo, vector ea nakoana e abiloe mme mohatla o tsamaisoa habeli.
    ///
    /// # Panics
    ///
    /// Panics haeba qalo e kholo ho feta ntlha ea ho qetela kapa haeba ntlha ea qetello e kholo ho feta bolelele ba vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// E etsa iterator e sebelisang ho koala ho fumana hore na ho na le ntho e lokelang ho tlosoa.
    ///
    /// Haeba ho koaloa ho khutla ka nnete, elemente e tla tlosoa ebe e fanoa.
    /// Haeba koalo e khutla e le leshano, elemente e tla lula ho vector mme e ke ke ea hlahisoa ke iterator.
    ///
    /// Ho sebelisa mokhoa ona ho lekana le khoutu e latelang:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // khoutu ea hau mona
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Empa `drain_filter` e bonolo ho e sebelisa.
    /// `drain_filter` e sebetsa hantle haholoanyane, hobane e ka sutumetsa likarolo tsa sehlopha ka bongata.
    ///
    /// Hlokomela hore `drain_filter` e boetse eu lumella ho fetolela ntho e ngoe le e ngoe ha ho koaloa sefahleho, ho sa tsotelehe hore na u khetha ho e boloka kapa ho e tlosa.
    ///
    ///
    /// # Examples
    ///
    /// Ho arola mefuta e mengata ka har'a mantsiboea le mathata, ho sebelisa kabelo ea mantlha:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Itebele khahlanong le rona hore re tsoe (ho phahamisa matla)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Eketsa ts'ebetsong e kopitsang likarolo ho tsoa litšupisong pele o li sutumelletsa ho Vec.
///
/// Ts'ebetso ena e khethehile bakeng sa li-iterator tsa selae, moo e sebelisang [`copy_from_slice`] ho kenya selae sohle hang-hang.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Lisebelisoa tsa papiso ea vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// E kenya ts'ebetsong ho odara ha vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // sebelisa lerotholi bakeng sa [T] sebelisa selae se tala ho supa likarolo tsa vector e le mofuta o fokolang o hlokahalang;
            //
            // e ka qoba lipotso tsa bonnete maemong a mang
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec e sebetsana le phetisetso
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// E etsa `Vec<T>` e se nang letho.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: teko e hula ka libstd, e bakang liphoso mona
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: teko e hula ka libstd, e bakang liphoso mona
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// E fumana likahare tsohle tsa `Vec<T>` ka bongata, haeba boholo ba eona bo lekana hantle le ba sehlopha se kopiloeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Haeba bolelele bo sa lumellane, kenyelletso e khutla ka `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Haeba o phetse hantle ka ho fumana feela sehlongwapele sa `Vec<T>`, o ka letsetsa [`.truncate(N)`](Vec::truncate) pele.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // TŠIRELETSO: `.set_len(0)` e lula e utloahala.
        unsafe { vec.set_len(0) };

        // TSHIRELETSO: Sesupi sa `Vec` se lula se hokahane hantle, 'me
        // peakanyo ea litlhoko tse fapaneng e ts'oana le lintho.
        // Re hlahlobile pejana hore na re na le lintho tse lekaneng.
        // Lintho li ke ke tsa theoha habeli ha `set_len` e bolella `Vec` hore le eona e se ke ea li lahla.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}