use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialization trait e sebelisetsoa Vec::from_iter
///
/// ## Kerafo ea moifo:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Nyeoe e tloaelehileng e fetisetsa vector hore e be ts'ebetso eo hang-hang e bokelloang hape ho vector.
        // Re ka etsa potoloho e khuts'oane haeba IntoIter e so tsoetse pele ho hang.
        // Ha e tsoetse pele Re ka boela ra sebelisa mohopolo hape ra fetisetsa data ka pele.
        // Empa re etsa joalo feela ha Vec e hlahisoang e ne e ke ke ea ba le matla a mangata a sa sebelisoeng ho feta ho e bopa ka ts'ebetso ea generic FromIterator.
        //
        // Phokotso eo ha e hlokahale ka matla kaha boits'oaro ba kabelo ea Vec ha bo tsejoe ka boomo.
        // Empa ke khetho e tloahelehileng.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // e tlameha ho fetisetsa ho spec_extend() ho tloha ha extend() ka boeona e le baemeli ho spec_from bakeng sa li-Vec tse se nang letho
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Sena se sebelisa `iterator.as_slice().to_vec()` kaha spec_extend e tlameha ho nka mehato e mengata ea ho beha mabaka ka bolelele ba bolelele ba matla + mme ka hona e etse mosebetsi o mongata.
// `to_vec()` ka kotloloho e aba chelete e nepahetseng ebe e e tlatsa hantle.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ka cfg(test) mokhoa oa tlhaho oa `[T]::to_vec`, o hlokehang bakeng sa tlhaloso ea mokhoa ona, ha o fumanehe.
    // Sebakeng seo sebelisa `slice::to_vec` function e fumanehang feela ka cfg(test) NB bona module ea slice::hack ho slice.rs bakeng sa tlhaiso-leseling e batsi
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}