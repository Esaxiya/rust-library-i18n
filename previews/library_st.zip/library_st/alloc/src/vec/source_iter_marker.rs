use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Letšoao la boiphihlelo bakeng sa ho bokella lipeipi tsa iterator ho Vec ha o ntse o sebelisa kabo ea mohloli hape, ke hore
/// ho etsa lipeipi sebakeng sa tsona.
///
/// Motsoali oa SourceIter trait oa hlokahala bakeng sa ts'ebetso e ikhethang ho fihlella kabo e tla sebelisoa bocha.
/// Empa ha hoa lekana hore boiphihlelo bo sebetse.
/// Bona meeli e meng ho impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-hare SourceIter/InPlaceIterable traits e sebelisoa feela ka liketane tsa Adapter <Adapter<Adapter<IntoIter>>> (tsohle e le tsa core/std).
// Meeli e meng ts'ebetsong ea li-adapter (ka nqane ho `impl<I: Trait> Trait for Adapter<I>`) e its'etleha feela ho tse ling tsa traits tse seng li tšoailoe e le tse khethehileng traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. lesupa ha lea itšetleha ka nako ea bophelo ea mefuta e fanoang ke mosebelisi.Modulo lesoba la Copy, leo litsebo tse ling tse 'maloa li seng li ntse li ipapisitse le lona.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Litlhoko tse ling tse ke keng tsa hlahisoa ka trait bound.Re itšetleha ka const eval ho fapana:
        // a) ha ho li-ZST kaha ho ne ho ke ke ha ba le kabelo ea ho sebelisoa bocha le ho supa lipalo e ne e tla ba panic b) papali ea boholo joalo ka ha ho hlokahala tumellanong le tumellano ea Alloc c)
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // khutlela ho ts'ebetsong tse ling tse tloaelehileng
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // sebelisa ho leka ho tloha ka nako eo
        // - e hlahisa hantle bakeng sa li-adapter tse ling tsa iterator
        // - ho fapana le mekhoa e mengata ea ho itlhahloba kahare, ho nka feela &mut
        // - e re lumella ho ts'oara sesupa sa ho ngola kahare ea eona ebe re e khutlisa qetellong
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration e atlehile, u se ke oa liha hlooho
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // netefatsa hore na konteraka ea SourceIter e tiisitsoe ka hloko: haeba li ne li se joalo re kanna ra se fihle le hona joale
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // hlahloba konteraka ea InPlaceIterable.Sena se ka etsahala feela haeba iterator e ntšetsa pele sesupi sa mohloli ho hang.
        // Haeba e sebelisa phihlello e sa hlahlojoeng ka TrustedRandomAccess joale sesupi sa mohloli se tla lula maemong a sona a pele 'me re ke ke ra se sebelisa
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // lahlela litekanyetso tse setseng mohatleng oa mohloli empa u thibele lerotholi la kabo ka boeona hang ha IntoIter e tsoa maemong haeba lerotholi la panics joale re boetse re lutla likarolo life kapa life tse bokelletsoeng ho dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // konteraka ea InPlaceIterable e ke ke ea netefatsoa hantle mona ho tloha ha try_fold e bua ka mokhoa o ikhethileng ho sesupa-mohloli seo re ka se etsang feela ke ho sheba hore na e ntse e le teng.
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}