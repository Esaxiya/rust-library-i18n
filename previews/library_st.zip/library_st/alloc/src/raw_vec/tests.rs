use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ho ngola teko ea kopanyo lipakeng tsa baabi ba mokha oa boraro le `RawVec` ke ntho e qhekellang hobane `RawVec` API ha e pepese mekhoa ea kabo e fosahetseng, ka hona re ke ke ra sheba se etsahalang ha morekisi a khathetse (ntle le ho fumana panic).
    //
    //
    // Sebakeng sena, ho sheba feela hore mekhoa ea `RawVec` bonyane e feta ho Allocator API ha e boloka polokelo.
    //
    //
    //
    //
    //

    // Morekisi ea semumu ea sebelisang palo e lekantsoeng ea mafura pele boiteko ba kabo bo qala ho hloleha.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (e baka ho fallisoa hape, ka hona ho sebelisoa li-unit tsa 50 + 150=200 tsa mafura)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Taba ea mantlha, `reserve` e abela joalo ka `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 e feta habeli ho 7, kahoo `reserve` e lokela ho sebetsa joalo ka `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 e ka tlase ho halofo ea 12, ka hona `reserve` e tlameha ho hola ka mokhoa o hlakileng.
        // Nakong ea ho ngola teko ena ea kholo e kholo ke 2, ka hona bokhoni bo bocha ke 24, leha ho le joalo, kholo ea 1.5 le eona e lokile.
        //
        // Kahoo `>= 18` e tiisa.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}