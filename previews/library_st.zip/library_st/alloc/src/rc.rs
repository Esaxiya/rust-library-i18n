//! Litlhahiso tsa ho bala litšupiso tse nang le khoele e le 'ngoe.'Rc' e emetse 'Reference
//! Counted'.
//!
//! Mofuta oa [`Rc<T>`][`Rc`] o fana ka boleng bo arolelanoeng ba boleng ba mofuta oa `T`, bo abetsoeng qubu.
//! Ho hohela [`clone`][clone] ho [`Rc`] ho hlahisa sesupisi se secha kabo e tšoanang qubu.
//! Ha sesupa sa ho qetela sa [`Rc`] se fanoeng se senyeha, boleng bo bolokiloeng kabo eo (bo atisang ho bitsoa "inner value") le bona boa theoha.
//!
//! Litemana tse arolelanoeng ho Rust ha li lumelle phetoho ka boiketsetso, 'me [`Rc`] ha e khetholle: ka kakaretso u ke ke ua fumana polelo e ka fetohang ea ntho e ka hare ho [`Rc`].
//! Haeba o hloka phetoho, kenya [`Cell`] kapa [`RefCell`] kahare ho [`Rc`];bona [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] e sebelisa palo ea litšupiso e seng ea athomo.
//! Sena se bolela hore bokaholimo bo tlase haholo, empa [`Rc`] e ke ke ea romelloa lipakeng tsa likhoele, ka lebaka leo [`Rc`] ha e sebelise [`Send`][send].
//! Ka lebaka leo, moqapi oa Rust o tla hlahloba *ka nako ea ho bokella* hore ha u romelle [`Rc`] s lipakeng tsa likhoele.
//! Haeba o hloka likhoele tse ngata, ho bala litšupiso tsa athomo, sebelisa [`sync::Arc`][arc].
//!
//! Mokhoa oa [`downgrade`][downgrade] o ka sebelisoa ho theha sesupa sa [`Weak`] seo e seng sa sona.
//! Sesupi sa [`Weak`] e ka ba [`ntlafatso`][ntlafatsa] d ho [`Rc`], empa sena se tla khutlisa [`None`] haeba boleng bo bolokiloeng kabo bo se bo theotsoe.
//! Ka mantsoe a mang, litsupa tsa `Weak` ha li boloke boleng bo ka hare ho kabo bo phela;leha ho le joalo, ba etsa * boloka kabelo (lebenkele le tšehetsang boleng ba kahare) e phela.
//!
//! Potoloho pakeng tsa lits'oants'o tsa [`Rc`] e ke ke ea hlola e tsamaisoa.
//! Ka lebaka lena, [`Weak`] e sebelisetsoa ho senya lipotoloho.
//! Mohlala, sefate se ka ba le lipontšo tse matla tsa [`Rc`] ho tloha linotong tsa motsoali ho isa ho bana, le litlhahiso tsa [`Weak`] ho tloha ho bana ba khutlela ho batsoali ba bona.
//!
//! `Rc<T>` e itlhalosa ka bo eona ho `T` (ka [`Deref`] trait), o tle o letse mekhoa ea `T` ka boleng ba mofuta oa [`Rc<T>`][`Rc`].
//! Ho qoba likhohlano tsa mabitso le mekhoa ea `T`, mekhoa ea [`Rc<T>`][`Rc`] ka boeona ke mesebetsi e amanang, e bitsoang ho sebelisa [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>Ts'ebetsong ea traits joalo ka `Clone` e kanna ea bitsoa ho sebelisa syntax e tšoanelehang ka botlalo.
//! Batho ba bang ba khetha ho sebelisa syntax e tšoanelehang ka botlalo, ha ba bang ba khetha ho sebelisa syntax ea mohala.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax ea mokhoa
//! let rc2 = rc.clone();
//! // Syntax e tšoanelehang ka botlalo
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ha e itlhahise ka ho iketsa `T`, hobane boleng ba kahare e kanna eaba e se e theohile.
//!
//! # Litšupiso tsa Cloning
//!
//! Ho theha sets'oants'o se secha ho kabo e ts'oanang le sesupa-palo se seng se ntse se baloa se etsoa ho sebelisoa `Clone` trait e kentsoeng [`Rc<T>`][`Rc`] le [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Li-syntax tse peli tse ka tlase lia lekana.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a le b ka bobeli ba supa sebaka se tšoanang sa memori le foo.
//! ```
//!
//! Phetolelo ea `Rc::clone(&from)` ke eona e hlalosang mantsoe ka ho fetisisa hobane e fetisa ka mokhoa o hlakileng moelelo oa khoutu.
//! Mohlala o kaholimo, syntax ena e nolofalletsa ho bona hore khoutu ena e theha tšupiso e ncha ho fapana le ho kopitsa litaba tsohle tsa foo.
//!
//! # Examples
//!
//! Nahana ka boemo ba moo sete ea `Gadget`s e leng ea `Owner` e fanoeng.
//! Re batla ho supa `Gadget` ea rona e supa `Owner` ea bona.Re ke ke ra etsa sena ka beng ba rona ba ikhethang, hobane lisebelisoa tse fetang se le seng e ka ba tsa `Owner` e tšoanang.
//! [`Rc`] e re lumella ho arolelana `Owner` lipakeng tsa `Gadget`s tse ngata, mme `Owner` e lule e abiloe ha feela ho na le lintlha tse `Gadget` ho eona.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... masimo a mang
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... masimo a mang
//! }
//!
//! fn main() {
//!     // Theha litšupiso tse baloang `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Theha `Gadget` ea `gadget_owner`.
//!     // Ho hlophisa `Rc<Owner>` ho re fa sesupa se secha ho kabelo e tšoanang ea `Owner`, ho eketsa palo ea litšupiso ts'ebetsong.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Lahla mefuta e fapaneng ea lehae ea `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Leha re lahlile `gadget_owner`, re ntse re khona ho hatisa lebitso la `Owner` la `Gadget`s.
//!     // Lebaka ke hobane re lahlile `Rc<Owner>` e le 'ngoe feela, eseng `Owner` eo e e supang.
//!     // Hafeela ho ntse ho na le `Rc<Owner>` e supang kabo e tšoanang ea `Owner`, e tla lula e phela.
//!     // Morero oa tšimo `gadget1.owner.name` oa sebetsa hobane `Rc<Owner>` e ikhula ka bo eona ho `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Qetellong ea ts'ebetso, `gadget1` le `gadget2` lia senyeha, 'me le tsona lipalo tsa ho qetela tse baloang ho `Owner` ea rona.
//!     // Gadget Man le eona ea timetsoa.
//!     //
//! }
//! ```
//!
//! Haeba litlhoko tsa rona li fetoha, 'me re hloka ho tseba ho haola ho tloha ho `Owner` ho ea ho `Gadget`, re tla ba le mathata.
//! Pointer ea [`Rc`] ho tloha `Owner` ho ea ho `Gadget` e hlahisa potoloho.
//! Sena se bolela hore lipalo tsa bona tsa litšupiso li ke ke tsa fihla ho 0, 'me kabelo e ke ke ea senngoa le ka mohla:
//! ho dutla hoa memori.Ho potoloha sena, re ka sebelisa lits'oants'o tsa [`Weak`].
//!
//! Rust ehlile e etsa hore ho be thata ho hlahisa loop ena pele.Bakeng sa ho qetella ka litekanyetso tse peli tse supaneng, e 'ngoe ea tsona e hloka ho fetoha.
//! Hona ho thata hobane [`Rc`] e tiisa polokeho ea memori ka ho fana ka litšupiso tse arolelanoeng tsa boleng boo e bo phutlang, 'me tsena ha li lumelle phetoho e tobileng.
//! Re hloka ho thatela karolo ea boleng boo re lakatsang ho bo fetola ka [`RefCell`], e fanang ka *phetoho ea kahare*: mokhoa oa ho fihlela phetoho ka ts'ebeliso e arolelanoeng.
//! [`RefCell`] e tiisa melao ea ho alima ea Rust ka nako ea ho matha.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... masimo a mang
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... masimo a mang
//! }
//!
//! fn main() {
//!     // Theha litšupiso tse baloang `Owner`.
//!     // Hlokomela hore re kentse vector ea `Owner 'ea` Gadget`s ka hare ho `RefCell` hore re tle re e fetole ka mokhoa o arolelanoeng.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Theha `Gadget` ea `gadget_owner`, joalo ka pele.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Kenya li-Gadget ho `Owner` ea bona.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` alima e matla e fella mona.
//!     }
//!
//!     // Iterate over `Gadget`ss ea rona, re hatisa lintlha tsa bona.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ke `Weak<Gadget>`.
//!         // Kaha lits'oants'o tsa `Weak` li ke ke tsa tiisa hore kabo e ntse e le teng, re hloka ho letsetsa `upgrade`, e khutlisetsang `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Maemong ana rea tseba hore kabo e ntse e le teng, ka hona re mpa re le `unwrap` the `Option`.
//!         // Lenaneong le rarahaneng ho feta, o kanna oa hloka phoso e ntle bakeng sa sephetho sa `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Qetellong ea ts'ebetso, `gadget_owner`, `gadget1`, le `gadget2` li senngoa.
//!     // Ha joale ha ho na litlhahiso tse matla tsa (`Rc`) ho lisebelisoa, ka hona lia senyeha.
//!     // Linomoro tsena tsa palo ea litšupiso ho Gadget Man, ka hona le eena oa timetsoa.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Hona ke bopaki ba repr(C) ho future khahlano le ho hlophisa bocha masimong, ho ka sitisang [into|from]_raw() e sireletsehileng ea mefuta e ka hare e fetisoang.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Sesupisi sa ho bala sa mohala o le mong.'Rc' e emetse 'Reference
/// Counted'.
///
/// Bona [module-level documentation](./index.html) bakeng sa lintlha tse ling.
///
/// Mekhoa ea tlhaho ea `Rc` kaofela ke mesebetsi e amanang, ho bolelang hore o tlameha ho ba bitsa joalo ka mohlala, [`Rc::get_mut(&mut value)`][get_mut] sebakeng sa `value.get_mut()`.
/// Sena se qoba likhohlano le mekhoa ea mofuta o ka hare `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ts'ireletso ena e lokile hobane ha Rc ena e ntse e phela re netefalitsoe hore sesupa-hare se nepahetse.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// E theha `Rc<T>` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Ho na le sesupi se fokolang se nang le litšupiso tsohle tse matla, se netefatsang hore mosenyi ea fokolang ha a lokolle kabelo ha mosenyi ea matla a ntse a sebetsa, leha sesupi se fokolang se bolokiloe kahare ho se matla.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// E theha `Rc<T>` e ncha e sebelisa lebitso le fokolang ho eona.
    /// Ho leka ho ntlafatsa litšupiso tse fokolang pele mosebetsi ona o khutla ho tla hlahisa boleng ba `None`.
    ///
    /// Leha ho le joalo, litšupiso tse fokolang li ka etsoa ka bolokolohi ebe li bolokoa hore li tle li sebelisoe hamorao.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... masimo a mang
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Theha bokantle seterekeng sa "uninitialized" ka mokhoa o le mong o fokolang.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Ho bohlokoa hore re se tlohele ho ba sesupi se fokolang, ho seng joalo mohopolo o kanna oa lokolloa ka nako ea `data_fn`.
        // Haeba re ne re hlile re batla ho fetisa beng, re ka iketsetsa sesupi se fokolang, empa sena se ka fella ka lintlafatso tse ling ho palo e fokolang ea litšupiso e kanna ea se hlokehe ka tsela e ngoe.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Litšupiso tse matla li lokela ho ba le litšupiso tse fokolang tse arolelanoeng, ka hona o se ke oa tsamaisa mosenyi bakeng sa ts'upiso ea rona ea khale e fokolang.
        //
        mem::forget(weak);
        strong
    }

    /// E theha `Rc` e ncha e nang le litaba tse sa qalisoang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// E theha `Rc` e ncha e nang le litaba tse sa qalisoang, mohopolo o tlatsoa ka li-byte tsa `0`.
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// E theha `Rc<T>` e ncha, e khutlisetsang phoso haeba kabo e sa atlehe
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Ho na le sesupi se fokolang se nang le litšupiso tsohle tse matla, se netefatsang hore mosenyi ea fokolang ha a lokolle kabelo ha mosenyi ea matla a ntse a sebetsa, leha sesupi se fokolang se bolokiloe kahare ho se matla.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// E theha `Rc` e ncha e nang le litaba tse sa qalisoang, e khutlisa phoso haeba kabo e sa atlehe
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// E theha `Rc` e ncha e nang le litaba tse sa qalisoang, mohopolo o tlatsitsoe ka li-byte tsa `0`, e khutlisa phoso haeba kabo e sa atlehe
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// E theha `Pin<Rc<T>>` e ncha.
    /// Haeba `T` e sa sebelise `Unpin`, `value` e tla manehoa mohopolong ebe e sitoa ho sisinyeha.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// E khutlisa boleng ba kahare, haeba `Rc` e na le ts'upiso e le 'ngoe e matla.
    ///
    /// Ho seng joalo, [`Err`] e khutlisoa le `Rc` e tšoanang e ileng ea fetisoa.
    ///
    ///
    /// Sena se tla atleha leha ho na le litšupiso tse fokolang tse fokolang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopitsa ntho e fuperoeng

                // Bontša Bafokoli hore ba ke ke ba phahamisoa ka ho fokotsa palo e matla, ebe ba tlosa sesupo sa "strong weak" ha ba ntse ba sebetsana le mohopolo oa ho lahla ka ho iqapela Bofokoli bo seng ba nnete.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// E theha selae se secha se baloang ka litšupiso se nang le litaba tse sa qalisoang.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// E theha selae se secha se baloang ka litšupiso se nang le litaba tse sa qalisoang, mohopolo o tlatsoa ka li-byte tsa `0`.
    ///
    ///
    /// Bona [`MaybeUninit::zeroed`][zeroed] bakeng sa mehlala ea ts'ebeliso e nepahetseng le e fosahetseng ea mokhoa ona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Fetolela ho `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Joalo ka [`MaybeUninit::assume_init`], ho ho motho ea letsitseng ho netefatsa hore boleng ba kahare bo maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlalosehang hanghang.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Fetolela ho `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Joalo ka [`MaybeUninit::assume_init`], ho ho motho ea letsitseng ho netefatsa hore boleng ba kahare bo maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlalosehang hanghang.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Qalo e khethiloeng:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// E sebelisa `Rc`, e khutlisa sesupa se phuthetsoeng.
    ///
    /// Ho qoba ho lutla ha mohopolo sesupi se tlameha ho khutlisetsoa ho `Rc` ho sebelisoa [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// E fana ka sesupa e tala ho data.
    ///
    /// Lipalo ha li amehe ka tsela efe kapa efe 'me `Rc` ha e sebelisoe.
    /// Sesupi se sebetsa ha feela ho na le lipalo tse matla ho `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // TSHIRELETSO: Sena se ke ke sa feta Deref::deref kapa Rc::inner hobane
        // sena se hlokahala ho boloka projeke ea raw/mut joalo ka mohlala
        // `get_mut` E ka ngola ka sesupa ka mor'a hore Rc e fole ka `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// E theha `Rc<T>` ho tsoa pointer e tala.
    ///
    /// Pointer e tala e tlameha ebe e ne e khutlisitsoe pejana ka mohala o eang ho [`Rc<U>::into_raw`][into_raw] moo `U` e tlamehang ho ba le boholo le tatellano e tšoanang le `T`.
    /// Sena ke 'nete haholo haeba `U` ke `T`.
    /// Hlokomela hore haeba `U` e se `T` empa e na le boholo le tatellano e ts'oanang, hona ho tšoana le ho fetisa litšupiso tsa mefuta e fapaneng.
    /// Bona [`mem::transmute`][transmute] bakeng sa tlhaiso-leseling e batsi mabapi le lithibelo life tse sebetsang ntlheng ena.
    ///
    /// Mosebelisi oa `from_raw` o tlameha ho etsa bonnete ba hore boleng bo itseng ba `T` bo theoha hanngoe feela.
    ///
    /// Mosebetsi ona ha o bolokehe hobane ts'ebeliso e fosahetseng e kanna ea etsa hore mohopolo o se bolokehe, leha `Rc<T>` e khutlisitsoeng e sa fihlelloe.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Fetolela ho `Rc` ho thibela ho dutla.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Mehala e meng e eang ho `Rc::from_raw(x_ptr)` e ka se bolokehe mohopolong.
    /// }
    ///
    /// // Memori e ile ea lokolloa ha `x` e tsoa boemong bo kaholimo, ka hona `x_ptr` e ntse e leketla!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Khutlisa offset ho fumana RcBox ea mantlha.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// E theha sesupisi se secha sa [`Weak`] kabo ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Etsa bonnete ba hore ha re thehe Bofokoli bo leketlileng
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// E fumana palo ea litlhahiso tsa [`Weak`] kabo ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// E fumana palo ea litlhahiso tse matla tsa (`Rc`) kabo ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// E khutlisa `true` haeba ho se na lits'oants'o tse ling tsa `Rc` kapa [`Weak`] kabo ena.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// E khutlisetsa ts'upiso e ka fetoloang ho `Rc` e fanoeng, haeba ho se na lits'oants'o tse ling tsa `Rc` kapa [`Weak`] kabo e tšoanang.
    ///
    ///
    /// E khutlisa [`None`] ho seng joalo, hobane ha ho bolokehe ho fetola boleng bo arolelanoeng.
    ///
    /// Bona hape [`make_mut`][make_mut], e tla [`clone`][clone] boleng ba kahare ha ho na le litsupa tse ling.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// E khutlisetsa ts'upiso e ka fetoloang ho `Rc` e fanoeng, ntle le cheke.
    ///
    /// Bona hape [`get_mut`], e bolokehileng mme e etsa licheke tse nepahetseng.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Litlhahiso tse ling tsa `Rc` kapa [`Weak`] tse abetsoeng kabo e tšoanang ha lia lokela ho hlalosoa bakeng sa nako ea kalimo e khutlisitsoeng.
    ///
    /// Hona ho joalo haeba ho se lits'oants'o tse joalo, mohlala hang kamora `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Re hlokolosi hore * * re se ke ra etsa sets'oants'o se koahelang likarolo tsa "count", kaha sena se tla hohlana le phihlello ea lipalo tsa litšupiso (mohlala.
        // (`Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// E khutlisa `true` haeba `Rc`s tse peli li supa kabo e tšoanang (ka mothapong o ts'oanang le [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// E etsa sets'oants'o se ka fetoloang ho `Rc` e fanoeng.
    ///
    /// Haeba ho na le lits'oants'o tse ling tsa `Rc` ho kabo e ts'oanang, `make_mut` e tla [`clone`] boleng ba ka hare ho kabo e ncha ho netefatsa hore ke beng ba eona.
    /// Sena se boetse se bitsoa clone-on-write.
    ///
    /// Haeba ho se na lits'oants'o tse ling tsa `Rc` kabo ena, lits'oants'o tsa [`Weak`] tsa kabo ena li tla tlohelloa.
    ///
    /// Bona hape [`get_mut`], e tla hloleha ho fapana le ho kopana.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // E ke ke ea kopanya letho
    /// let mut other_data = Rc::clone(&data);    // Ke ke clone ya data ka hare
    /// *Rc::make_mut(&mut data) += 1;        // Clones ya data ka hare
    /// *Rc::make_mut(&mut data) += 1;        // E ke ke ea kopanya letho
    /// *Rc::make_mut(&mut other_data) *= 2;  // E ke ke ea kopanya letho
    ///
    /// // Hona joale `data` le `other_data` li supa likabo tse fapaneng.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] lits'oants'o li tla ikarola:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // U se u batla ho utloisisa lintlha, ho na le li-Rcs tse ling.
            // Pele ho fana ka mohopolo ho lumella ho ngola boleng bo hlophisitsoeng ka kotloloho.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // U ka utsoa data, se setseng ke Mefokolo
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Tlosa bofokoli bo matla (ha ho na lebaka la ho etsa bofokoli bo fosahetseng mona-rea tseba hore Mefokolo e meng e ka re hloekisetsa)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ho se sireletsehe hona ho lokile hobane re netefalitsoe hore sesupi se khutlisitsoe ke sesupa feela * se tla busetsoa ho T.
        // Palo ea rona ea litšupiso e netefalitsoe hore e tla ba 1 hona joale, 'me re hloka hore `Rc<T>` ka boeona e be `mut`, ka hona re khutlisetsa tšupiso e le' ngoe feela e ka bang teng ho kabelo.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Leka ho theola `Rc<dyn Any>` ho mofuta oa konkreite.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// E aba `RcBox<T>` e nang le sebaka se lekaneng bakeng sa boleng ba ka hare bo sa lekanyetsoang moo boleng bo nang le sebopeho se fanoeng.
    ///
    /// Mosebetsi `mem_to_rcbox` o bitsoa ka pointer ea data mme o tlameha ho khutlisa sekontiri (se ka bang mafura) bakeng sa `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Sebetsa moralo ka ho sebelisa sebopeho se fanoeng sa boleng.
        // Pejana, sebopeho se ne se baloa polelong ea `&*(ptr as* const RcBox<T>)`, empa sena se thehile litšupiso tse fosahetseng (bona #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// E aba `RcBox<T>` e nang le sebaka se lekaneng bakeng sa boleng ba ka hare bo sa lekanyetsoang moo boleng bo nang le sebopeho se fanoeng, ho khutlisa phoso haeba kabo e sa atlehe.
    ///
    ///
    /// Mosebetsi `mem_to_rcbox` o bitsoa ka pointer ea data mme o tlameha ho khutlisa sekontiri (se ka bang mafura) bakeng sa `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Sebetsa moralo ka ho sebelisa sebopeho se fanoeng sa boleng.
        // Pejana, sebopeho se ne se baloa polelong ea `&*(ptr as* const RcBox<T>)`, empa sena se thehile litšupiso tse fosahetseng (bona #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Abela moralo.
        let ptr = allocate(layout)?;

        // Qala RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// E aba `RcBox<T>` e nang le sebaka se lekaneng bakeng sa boleng bo ka hare bo sa lekanyetsoang
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Abela `RcBox<T>` u sebelisa boleng bo fanoeng.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopitsa boleng joaloka li-byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Lokolla kabelo ntle le ho lahla litaba tsa eona
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// E aba `RcBox<[T]>` ka bolelele bo fanoeng.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopitsa likarolo ho selae ho ea ho Rc <\[T\]> e sa tsoa fuoa
    ///
    /// Ha e bolokehe hobane moletsi o tlameha ho nka beng kapa a tlame `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// E theha `Rc<[T]>` ho tsoa ho iterator e tsejoang e le ea boholo bo itseng.
    ///
    /// Boitšoaro ha bo hlalosehe ha boholo bo fosahetse.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic e itebela ha e ntse e kopanya likarolo tsa T.
        // Ketsahalong ea panic, likarolo tse ngolisitsoeng ho RcBox e ncha li tla tloheloa, ebe memori ea lokolloa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Supa ho ntlha ea pele
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tsohle li hlakile.Lebala molebeli hore a se ke a lokolla RcBox e ncha.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait e sebelisetsoa `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// E theola `Rc`.
    ///
    /// Sena se tla fokotsa palo e matla ea litšupiso.
    /// Haeba palo e matla ea litšupiso e fihla ho zero joale litšupiso tse ling feela (haeba li le teng) ke [`Weak`], ka hona re `drop` boleng ba kahare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ha e hatise letho
    /// drop(foo2);   // E hatisa "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // senya ntho e nang le eona
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // tlosa sesupo sa "strong weak" se totobetseng ha joale re sentse litaba.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// E etsa sesepa sa sesupa sa `Rc`.
    ///
    /// Sena se theha sesupa se seng ho kabo e ts'oanang, ho eketsa palo e matla ea litšupiso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// E etsa `Rc<T>` e ncha, e nang le boleng ba `Default` bakeng sa `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack ho lumella ho khetheha ka `Eq` leha `Eq` e na le mokhoa.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Re etsa boiphihlelo bona mona, eseng joalo ka ntlafatso e akaretsang ho `&T`, hobane ho ka eketsa litšenyehelo ho licheke tsohle tsa tekano ho Refs.
/// Re nahana hore `Rc`s e sebelisetsoa ho boloka litekanyetso tse kholo, tse liehang ho ts'oaroa, empa hape li boima ho lekola tekano, e leng se etsang hore litšenyehelo tsena li lefe habonolo.
///
/// Ho na le monyetla oa ho ba le li-clone tse peli tsa `Rc`, tse supang boleng bo lekanang, ho feta li-`&T`s tse peli.
///
/// Re ka etsa sena feela ha `T: Eq` joalo ka `PartialEq` e kanna ea se ts'oane ka boomo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Tekano bakeng sa `Rc`s tse peli.
    ///
    /// Li-Rc`s tse peli lia lekana haeba litekanyetso tsa tsona tsa ka hare li lekana, leha li bolokiloe ka likabelo tse fapaneng.
    ///
    /// Haeba `T` e boetse e sebelisa `Eq` (ho bolelang ho se fetohe hoa tekano), li-Rc tse peli tse supang kabo e ts'oanang li lula li lekana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ho se lekane ha `Rc`s tse peli.
    ///
    /// Li-R`` tse peli ha li lekane haeba boleng ba tsona ba ka hare bo sa lekana.
    ///
    /// Haeba `T` e boetse e sebelisa `Eq` (e bolelang ho se fetohe hoa tekano), li-Rc tse peli tse supang kabo e tšoanang ha ho mohla li lekanang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Papiso e sa reroang bakeng sa `Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `partial_cmp()` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ka tlase ho papiso ea `Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `<` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Papiso e ka tlase ho kapa e lekanang le' Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `<=` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// E kholo ho feta papiso ea `Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `>` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'E kholo ho feta kapa e lekana le' papiso ea li-Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `>=` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Papiso ea `Rc`s tse peli.
    ///
    /// Bobeli ba bapisoa ka ho letsetsa `cmp()` ka boleng ba bona ba kahare.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Abela selae se baliloeng 'me u se tlatse ka ho kopanya lintho tsa `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Abela selae sa khoele se baloang e le sa litšupiso ebe u kopitsa `v` ho sona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Abela selae sa khoele se baloang e le sa litšupiso ebe u kopitsa `v` ho sona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Tsamaisetsa ntho e mabokoseng ho kabelo e ncha, e baloang ka litšupiso.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Abela selae se baliloeng 'me u tsamaise lintho tsa `v` ho sona.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lumella Vec ho lokolla mohopolo oa eona, empa e se ke ea senya litaba tsa eona
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// E nka ntho e ngoe le e ngoe ho `Iterator` ebe ee bokella ho `Rc<[T]>`.
    ///
    /// # Litšobotsi tsa ts'ebetso
    ///
    /// ## Nyeoe e akaretsang
    ///
    /// Maemong a akaretsang, ho bokella `Rc<[T]>` ho etsoa ka ho qala ho bokelloa ho `Vec<T>`.Ka mantsoe a mang, ha u ngola tse latelang:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// sena se itšoara joalokaha eka re ngotse:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Sehlopha sa pele sa likabo se etsahala mona.
    ///     .into(); // Kabo ea bobeli ea `Rc<[T]>` e etsahala mona.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Sena se tla aba makhetlo a mangata kamoo ho hlokahalang bakeng sa ho aha `Vec<T>` mme e tla fana ka hanngoe bakeng sa ho fetola `Vec<T>` ho `Rc<[T]>`.
    ///
    ///
    /// ## Li-Iterator tsa bolelele bo tsebahalang
    ///
    /// Ha `Iterator` ea hau e kenya `TrustedLen` 'me e lekana hantle, ho tla etsoa kabelo e le' ngoe bakeng sa `Rc<[T]>`.Ka mohlala:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Kabo e le 'ngoe feela e etsahala mona.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Bokhoni ba trait bo sebelisetsoang ho bokella `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ho joalo bakeng sa sengoloa sa `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // TSHIRELETSO: Re hloka ho etsa bonnete ba hore iterator e na le bolelele bo nepahetseng mme re na le yona.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Khutlela ts'ebetsong e tloaelehileng.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` ke mofuta oa [`Rc`] o ts'oereng boits'oaro bo seng ba eona ho kabo e laoloang.Kabo e fumaneha ka ho letsetsa [`upgrade`] ho sesupa sa `Weak`, se khutlisetsang [`Option`]`<<[[Rc`] `<T>>``.
///
/// Kaha ts'ebetso ea `Weak` ha e itšetlehe ka beng ba eona, e ke ke ea thibela boleng bo bolokiloeng kabo hore bo se ke ba theoleloa, 'me `Weak` ka boeona ha e fane ka tiiso ea boleng bo ntseng bo le teng.
/// Kahoo e kanna ea khutlisa [`None`] ha [`ntlafatso`] d.
/// Hlokomela leha ho le joalo hore `Weak` reference * ha e thibele kabo ka boyona (lebenkele le tšehetsang) hore le se ke la tsamaisoa.
///
/// Pointer ea `Weak` e na le thuso bakeng sa ho boloka tšupiso ea nakoana ho kabo e laoloang ke [`Rc`] ntle le ho thibela boleng ba eona ba ka hare hore bo se ke ba liheloa.
/// E boetse e sebelisetsoa ho thibela litšupiso tse chitja lipakeng tsa litlhahiso tsa [`Rc`], hobane ho ba le litšupiso ka bobeli ho ke ke ha lumella [`Rc`] hore e liheloe.
/// Mohlala, sefate se ka ba le lipontšo tse matla tsa [`Rc`] ho tloha linotong tsa motsoali ho isa ho bana, le litlhahiso tsa `Weak` ho tloha ho bana ba khutlela ho batsoali ba bona.
///
/// Mokhoa o tloaelehileng oa ho fumana sesupa sa `Weak` ke ho letsetsa [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ena ke `NonNull` ho lumella ho ntlafatsa boholo ba mofuta ona ka li-enum, empa ha se hakaalo hore ke sesupi se nepahetseng.
    //
    // `Weak::new` e beha sena ho `usize::MAX` hore e se hloke ho fana ka sebaka qubung.
    // Seo ha se boleng ba pointer ea 'nete bo tla ba le eona hobane RcBox e hokahane le bonyane 2.
    // Sena se ka etsahala feela ha `T: Sized`;`T` e sa lekanyetsoang le ka mohla ha e thekesele.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// E theha `Weak<T>` e ncha, ntle le ho fana ka mohopolo.
    /// Ho letsetsa [`upgrade`] ka boleng ba ho khutla kamehla ho fa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Mofuta oa mothusi ho lumella ho fihlella lipalo tsa litšupiso ntle le ho tiisa mabapi le lefapha la data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// E khutlisetsa sesupi se tala ho ntho `T` e supiloeng ke `Weak<T>` ena.
    ///
    /// Sesupi se sebetsa ha feela ho na le litšupiso tse matla.
    /// Pointer e kanna ea leketla, e sa ts'oaroang kapa [`null`] ka tsela e ngoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ka bobeli li supa nthong e le 'ngoe
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Ba matla mona ba e boloka e phela, ka hona re ntse re ka fihlela ntho eo.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Empa eseng ho feta.
    /// // Re ka etsa weak.as_ptr(), empa ho fihlella pointer ho ka lebisa ho boits'oaro bo sa hlalosoang.
    /// // assert_eq! ("hello", ha e bolokehe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Haeba sesupa se leketlile, re khutlisetsa molebeli ka kotloloho.
            // Sena e keke ea ba aterese e nepahetseng ea tefo, hobane tefo ea tefo e hokahane joalo ka RcBox (usize).
            ptr as *const T
        } else {
            // TŠIRELETSO: haeba e_e leketlile e khutla e le leshano, joale sesupa-tsela ha se khonehe.
            // Meputso e kanna ea theoha hona joale, 'me re tlameha ho boloka projeke, ka hona sebelisa ts'ebeliso e mpe ea sesupa-tsela.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// E sebelisa `Weak<T>` ebe ee fetola sesupa se tala.
    ///
    /// Sena se fetola sesupi se fokolang hore e be sesupa se sa tsoakoang, ha se ntse se boloka boleng ba ts'upiso e le 'ngoe e fokolang (palo e fokolang ha e fetoloe ke ts'ebetso ena).
    /// E ka khutlisetsoa `Weak<T>` le [`from_raw`].
    ///
    /// Lithibelo tse tšoanang tsa ho fihlella sepheo sa sesupa joalo ka [`as_ptr`] lia sebetsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// E fetola sesupa se tala se neng se entsoe pele ke [`into_raw`] hape ho `Weak<T>`.
    ///
    /// Sena se ka sebelisoa ho fumana ts'upiso e matla (ka ho letsetsa [`upgrade`] hamorao) kapa ho tsamaisa palo e fokolang ka ho lahla `Weak<T>`.
    ///
    /// Ho nka mong'a tšupiso e le 'ngoe e fokolang (ntle le lits'oants'o tse entsoeng ke [`new`], kaha tsena ha li na letho; mokhoa ona o ntse o sebetsa ho bona).
    ///
    /// # Safety
    ///
    /// Pointer e tlameha ebe e tsoa ho [`into_raw`] mme e ntse e tlameha ho ba le eona litšupiso tse fokolang tse ka bang teng.
    ///
    /// Ho lumelloa hore palo e matla e be 0 ka nako ea ho letsetsa sena.
    /// Leha ho le joalo, sena se nka karolo ea ts'upiso e le 'ngoe e fokolang eo hajoale e emeloang e le sesupa se tala (palo e fokolang ha e fetoloe ke ts'ebetso ena) ka hona e tlameha ho tsamaisoa le mohala o fetileng ho [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Fokotsa palo ea ho qetela e fokolang.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Bona Weak::as_ptr bakeng sa moelelo oa hore na pointer ea ho kenya e tsoa joang.

        let ptr = if is_dangling(ptr as *mut T) {
            // Hona ke Bofokoli bo leketlileng.
            ptr as *mut RcBox<T>
        } else {
            // Ho seng joalo, re netefalitsoe hore sesupi se tsoa ho Motho ea fokolang ea fokolang.
            // TSHIRELETSO: data_offset e bolokehile ho ka letsetsoa, joalo ka ha ptr e supa T.
            let offset = unsafe { data_offset(ptr) };
            // Kahoo, re khutlisetsa offset ho fumana RcBox kaofela.
            // TŠIRELETSO: sesupi se simolohile ho ea fokolang, ka hona, mokhoa ona o bolokehile.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // TSHIRELETSO: re se re fumane sesupi sa mantlha se fokolang, ka hona re ka theha ba fokolang.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Boiteko ba ho ntlafatsa sesupa sa `Weak` ho ba [`Rc`], ho liehisa ho theoha hoa boleng ba ka hare haeba bo atlehile.
    ///
    ///
    /// E khutlisa [`None`] haeba boleng ba kahare bo se bo theohile.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Senya litlhahiso tsohle tse matla.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// E fumana palo ea litlhahiso tse matla tsa (`Rc`) tse supang kabo ena.
    ///
    /// Haeba `self` e entsoe ka [`Weak::new`], sena se tla khutla 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// E fumana palo ea litlhahiso tsa `Weak` tse supang kabo ena.
    ///
    /// Haeba ho se na litsupa tse matla tse setseng, sena se tla khutlisa lefela.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // tlosa ptr e fokolang
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// E khutlisa `None` ha sesupa se leketlile 'me ha ho na `RcBox` e abetsoeng, ke hore, ha `Weak` ena e ne e etsoa ke `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Re hlokolosi hore * * re se ke ra etsa sets'oants'o se koahelang tšimo ea "data", hobane tšimo e ka fetoha ka nako e le ngoe (mohlala, haeba `Rc` ea ho qetela e theotsoe, lefapha la data le tla lahleloa sebakeng).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// E khutlisa `true` haeba tse peli tsa `Bofokoli li supa kabo e tšoanang (e ts'oanang le [`ptr::eq`]), kapa haeba ka bobeli li sa supe kabo efe kapa efe (hobane e entsoe ka `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kaha sena se bapisa litlhahiso ho bolela hore `Weak::new()` e tla lekana, leha e sa supe kabo efe kapa efe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ho bapisa `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// E theola sesupa sa `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ha e hatise letho
    /// drop(foo);        // E hatisa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // palo e fokolang e qala ka 1, 'me e tla ea ho zero feela haeba litsupa tse matla li nyametse.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// E etsa leseli la sesupa sa `Weak` se supang kabo e tšoanang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// E theha `Weak<T>` e ncha, e fana ka memori bakeng sa `T` ntle le ho e qala.
    /// Ho letsetsa [`upgrade`] ka boleng ba ho khutla kamehla ho fa [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Re ile ra hlahloba_a eketsa mona ho sebetsana le mem::forget ka polokeho.Ka ho khetheha
// haeba u mem::forget Rcs (kapa Mefokolo), palo ea ref-count e ka phalla, ebe u ka lokolla kabelo ha li-Rcs tse sa lebelloang (kapa Mefokolo) li le teng.
//
// Re ntša mpa hobane ona ke boemo bo mpefalang hoo re sa tsotelleng se etsahalang-ha ho lenaneo la 'nete le lokelang ho ba le sena.
//
// Sena se lokela ho ba le lihlooho tse sa tsotelleng kaha ha ho hlokahale hore u li kenyelletse haholo ho Rust ka lebaka la beng ba tsona le li-semantics tsa bona tse tsamaeang.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Re batla ho ntša mpa ka ho khaphatseha ho fapana le ho theola boleng.
        // Palo ea litšupiso e ke ke ea hlola e eba lefela ha sena se bitsoa;
        // leha ho le joalo, re kenya mpa mona ho fana ka maikutlo a LLVM ka ntlafatso e seng e sa fumanehe.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Re batla ho ntša mpa ka ho khaphatseha ho fapana le ho theola boleng.
        // Palo ea litšupiso e ke ke ea hlola e eba lefela ha sena se bitsoa;
        // leha ho le joalo, re kenya mpa mona ho fana ka maikutlo a LLVM ka ntlafatso e seng e sa fumanehe.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Fumana phokotso kahare ho `RcBox` bakeng sa tefo ea moputso kamora sesupa.
///
/// # Safety
///
/// Sesupi se tlameha ho supa (le ho ba le metadata e sebetsang bakeng sa) mohlala o neng o sebetsa pele oa T, empa T e lumelloa ho theoloa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Lumellanya boleng bo sa lekanyetsoang qetellong ea RcBox.
    // Hobane RcBox ke repr(C), e tla lula e le tšimo ea ho qetela mohopolong.
    // TŠIRELETSO: kaha mefuta feela e sa lekanyetsoang e ka ba lilae, lintho tsa trait,
    // le mefuta ea kantle, tlhoko ea polokeho ea ho kenya letsoho ha joale e lekane ho khotsofatsa litlhoko tsa align_of_val_raw;ena ke lintlha tsa ts'ebetsong tsa puo e ka se tšepeloeng kantle ho std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}