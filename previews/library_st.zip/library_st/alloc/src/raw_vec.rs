#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Litaba tsa memori e ncha ha lia qalisoa.
    Uninitialized,
    /// Memori e ncha e netefalitsoe hore e tla ba zero.
    Zeroed,
}

/// Sesebelisoa sa maemo a tlase sa ho abela ergonomically ho feta, ho fallisa le ho tsamaisa mochini oa mohopolo qubu ntle le ho tšoenyeha ka linyeoe tsohle tsa sekhutlo tse amehang.
///
/// Mofuta ona o motle haholo bakeng sa ho aha likarolo tsa hau tsa data joalo ka Vec le VecDeque.
/// Ka ho khetheha:
///
/// * E hlahisa `Unique::dangling()` ka mefuta ea boholo ba zero.
/// * E hlahisa `Unique::dangling()` ka likabelo tse bolelele ba zero.
/// * E qoba ho lokolla `Unique::dangling()`.
/// * Ho ts'oaroa hohle ho tlala ka lipalo tsa bokhoni (ho li khothaletsa ho "capacity overflow" panics).
/// * Balebeli khahlanong le lits'ebetso tse 32-bit tse fanang ka li-byte tse fetang isize::MAX.
/// * Balebeli khahlanong le ho khaphatseha bolelele ba hau.
/// * Ho letsetsa `handle_alloc_error` bakeng sa likabo tse fosahetseng.
/// * E na le `ptr::Unique` mme ka hona e fa mosebelisi melemo eohle e amanang le eona.
/// * E sebelisa chelete e fetelletseng e khutlisitsoeng ho morekisi ho sebelisa boholo bo fumanehang.
///
/// Mofuta ona ha o hlahlobe mohopolo oo o o tsamaisang.Ha e lahloa * e tla lokolla mohopolo oa eona, empa e ke ke ea leka ho lahla litaba tsa eona.
/// Ho ho mosebelisi oa `RawVec` ho sebetsana le lintho tsa 'nete tse bolokiloeng kahare ho `RawVec`.
///
/// Hlokomela hore ho fetella ha mefuta ea boholo ba zero ho lula ho se na moeli, ka hona `capacity()` e khutlisa `usize::MAX` kamehla.
/// Sena se bolela hore o hloka ho ba hlokolosi ha o khopisa mofuta ona ka `Box<[T]>`, hobane `capacity()` e ke ke ea fana ka bolelele.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Sena se teng hobane `#[unstable]` const fn`s ha e hloke ho latela `min_const_fn` kahoo ba ke ke ba bitsoa ho `min_const_fn`s ebang.
    ///
    /// Haeba u fetola `RawVec<T>::new` kapa litšepiso, ka kopo hlokomela hore u se hlahise eng kapa eng e ka tlolang `min_const_fn` kannete.
    ///
    /// NOTE: Re ka qoba qhekello ena mme ra sheba ho lumellana le boleng ba `#[rustc_force_min_const_fn]` bo hlokang ho tsamaellana le `min_const_fn` empa ha bo lumelle ho e letsetsa ka `stable(...) const fn`/khoutu ea mosebelisi e sa lumelle `foo` ha `#[rustc_const_unstable(feature = "foo", issue = "01234")]` e le teng.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// E etsa `RawVec` e kholo ka ho fetisisa (qubung ea sistimi) ntle le ho e aba.
    /// Haeba `T` e na le boholo bo nepahetseng, joale sena se etsa `RawVec` e nang le boholo ba `0`.
    /// Haeba `T` e lekana le zero, joale e etsa `RawVec` e nang le `usize::MAX`.
    /// E na le thuso bakeng sa ho kenya tšebetsong kabo e liehang.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// E etsa `RawVec` (holima qubu ea sistimi) e nang le bokhoni le tatellano ea litlhoko tsa `[T; capacity]`.
    /// Sena se lekana le ho letsetsa `RawVec::new` ha `capacity` e le `0` kapa `T` e lekana le zero.
    /// Hlokomela hore haeba `T` e lekana le zero hona ho bolela hore o ke ke oa fumana `RawVec` ka matla a kopiloeng.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a kopiloeng a feta li-byte tsa `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ho OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Joalo ka `with_capacity`, empa e tiisa hore buffer ha e na thuso.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// E nchafatsa `RawVec` ho tsoa ho sesupa le matla.
    ///
    /// # Safety
    ///
    /// `ptr` e tlameha ho abuoa (qubu ea sistimi), le `capacity` e fanoeng.
    /// `capacity` e ke ke ea feta `isize::MAX` bakeng sa mefuta e boholo.(ho ameha feela ka litsamaiso tsa 32-bit).
    /// ZST vectors e kanna ea ba le bokhoni ba ho fihla ho `usize::MAX`.
    /// Haeba `ptr` le `capacity` li tsoa ho `RawVec`, joale sena se netefalitsoe.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Li-Vec tse nyane ha li tsebe ho bua.Fetela ho:
    // - 8 haeba boholo ba elemente e le 1, hobane baabi bohle ba likoto ba ka etsa kopo ea li-byte tse ka tlase ho tse 8 ho fihlela bonyane li-byte tse 8.
    //
    // - 4 haeba likarolo li le boholo bo itekanetseng (<=1 KiB).
    // - 1 ho seng joalo, ho qoba ho senya sebaka se ngata haholo bakeng sa li-Vec tse khuts'oane haholo.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Joalo ka `new`, empa e fetotsoe paramethara ka khetho ea moabi bakeng sa `RawVec` e khutlisitsoeng.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` e bolela "unallocated".Mefuta ea boholo ba zero ha e tsotelloe.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Joalo ka `with_capacity`, empa e fetotsoe paramethara ka khetho ea moabi bakeng sa `RawVec` e khutlisitsoeng.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Joalo ka `with_capacity_zeroed`, empa e fetotsoe paramethara ka khetho ea moabi bakeng sa `RawVec` e khutlisitsoeng.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// E fetola `Box<[T]>` hore e be `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// E fetola buffer eohle hore e be `Box<[MaybeUninit<T>]>` ka `len` e boletsoeng.
    ///
    /// Hlokomela hore sena se tla hlophisa ka nepo liphetoho life kapa life tsa `cap` tse kanna tsa etsoa.(Bona litlhaloso tsa mofuta bakeng sa lintlha.)
    ///
    /// # Safety
    ///
    /// * `len` e tlameha ho ba kholo ho feta kapa ho lekana le matla a sa tsoa kopuoa, mme
    /// * `len` e tlameha ho ba tlase ho kapa e lekane le `self.capacity()`.
    ///
    /// Hlokomela, hore matla ao a a kopileng le `self.capacity()` a ka fapana, kaha morekisi a ka arolelana le ho khutlisa memori e kholo ho feta kamoo a kopileng.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Hlahloba bohloeki halofo e 'ngoe ea tlhoko ea polokeho (re ke ke ra sheba halofo e' ngoe).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Re qoba `unwrap_or_else` mona hobane e thibela palo ea LLVM IR e hlahisitsoeng.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// E nchafatsa `RawVec` ho tsoa ho sesupi, matla le seabi.
    ///
    /// # Safety
    ///
    /// `ptr` e tlameha ho abuoa (ka moabi ea fuoeng `alloc`), le `capacity` e fanoeng.
    /// `capacity` e ke ke ea feta `isize::MAX` bakeng sa mefuta e boholo.
    /// (ho ameha feela ka litsamaiso tsa 32-bit).
    /// ZST vectors e kanna ea ba le bokhoni ba ho fihla ho `usize::MAX`.
    /// Haeba `ptr` le `capacity` li tsoa ho `RawVec` e entsoeng ka `alloc`, joale sena se netefalitsoe.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// E fumana sesupisi se tala ho qala ha kabo.
    /// Hlokomela hore ena ke `Unique::dangling()` haeba `capacity == 0` kapa `T` e lekana le zero.
    /// Boemong ba pele, o tlameha ho ba hlokolosi.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// E fumana matla a kabo.
    ///
    /// Sena e tla lula e le `usize::MAX` haeba `T` e lekana le zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// E khutlisetsa litšupiso tse arolelanoeng ho morekisi a tšehetsa `RawVec` ena.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Re na le sehopotso se abetsoeng, kahoo re ka feta cheke ea nako ea ho matha ho fumana sebopeho sa rona sa hajoale.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// E netefatsa hore buffer e na le bonyane sebaka se lekaneng ho tšoara likarolo tsa `len + additional`.
    /// Haeba e se na matla a lekaneng, e tla fana ka sebaka se lekaneng le sebaka se bobebe sa ho etsa boits'oaro ba O * (1).
    ///
    /// E tla lekanyetsa boitšoaro bona haeba e ka itlhahisa ho sa hlokahale ho panic.
    ///
    /// Haeba `len` e feta `self.capacity()`, sena se kanna sa hloleha ho fana ka sebaka se kopiloeng.
    /// Sena ha se hlile ha se bolokehe, empa khoutu e sa bolokehang * eo u e ngolang e itšetlehileng ka boits'oaro ba ts'ebetso ena e ka robeha.
    ///
    /// Sena se loketse ho kenya tšebetsong ts'ebetso ea bongata bo boholo joaloka `extend`.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta li-byte tsa `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ho OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // pokello e ka be e ntšitse mpa kapa ea tšoha haeba lense e feta `isize::MAX` ka hona sena se bolokehile hore se ka sebetsoa hona joale.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// E ts'oana le `reserve`, empa e khutla ka liphoso ho fapana le ho ts'oha kapa ho senya mpa.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// E netefatsa hore buffer e na le bonyane sebaka se lekaneng ho tšoara likarolo tsa `len + additional`.
    /// Haeba e se e ntse e le teng, e tla tsamaisa boholo ba memori e hlokahalang.
    /// Ka kakaretso sena e tla ba hantle feela mohopolo o hlokahalang, empa ha e le hantle moabi o lokolohile ho fana ka se fetang seo re se kopileng.
    ///
    ///
    /// Haeba `len` e feta `self.capacity()`, sena se kanna sa hloleha ho fana ka sebaka se kopiloeng.
    /// Sena ha se hlile ha se bolokehe, empa khoutu e sa bolokehang * eo u e ngolang e itšetlehileng ka boits'oaro ba ts'ebetso ena e ka robeha.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta li-byte tsa `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts ho OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// E ts'oana le `reserve_exact`, empa e khutla ka liphoso ho fapana le ho ts'oha kapa ho senya mpa.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// E fokotsa kabelo ho ea ho chelete e boletsoeng.
    /// Haeba palo e fanoeng e le 0, e hlile e sebetsana ka botlalo.
    ///
    /// # Panics
    ///
    /// Panics haeba bokaalo bo fanoeng bo le kholo ho * matla a hona joale.
    ///
    /// # Aborts
    ///
    /// Aborts ho OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// E khutlisa haeba buffer e hloka ho hola ho fihlela matla a eketsehileng a hlokahalang.
    /// Haholo-holo e sebelisetsoa ho thathamisa mehala ea pokello e ka khonehang ntle le ho thathamisa `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Mokhoa ona hangata o tiisoa hangata.Kahoo re batla hore e be nyane ka moo ho khonehang, ho ntlafatsa linako tsa ho bokella.
    // Empa re boetse re batla hore litaba tsa eona tse ngata li balehe ka mokhoa o khonehang, ho etsa hore khoutu e hlahisitsoeng e sebetse kapele.
    // Ka hona, mokhoa ona o ngotsoe ka hloko hore khoutu eohle e itšetlehileng ka `T` e ka hare ho eona, ha khoutu e ngata e sa itšetleheng ka `T` kamoo ho ka khonehang e mesebetsing e seng ea tlhaho ho feta `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Sena se netefatsoa ke maemo a ho letsetsa.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Kaha re khutlisa boholo ba `usize::MAX` ha `elem_size` e le
            // 0, ho fihla mona ho bolela hore `RawVec` e tletse haholo.
            return Err(CapacityOverflow);
        }

        // Ha ho na letho leo re ka le etsang ka licheke tsena, ka masoabi.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Sena se tiisa kholo ea kholo.
        // Ho pheta habeli ho ke ke ha phalla hobane `cap <= isize::MAX` le mofuta oa `cap` ke `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ha se ea tlhaho ho feta `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Litšitiso tsa mokhoa ona li ts'oana hantle le tsa `grow_amortized`, empa mokhoa ona hangata o tiisoa khafetsa kahoo ha o bohlokoa haholo.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Kaha re khutlisa boholo ba `usize::MAX` ha boholo ba mofuta bo le
            // 0, ho fihla mona ho bolela hore `RawVec` e tletse haholo.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ha se ea tlhaho ho feta `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ts'ebetso ena e kantle ho `RawVec` ho fokotsa linako tsa ho bokella.Bona maikutlo a kaholimo ho `RawVec::grow_amortized` bakeng sa lintlha.
// (`A` parameter ha e bohlokoa, hobane palo ea mefuta e fapaneng ea `A` e bonoang ts'ebetsong e nyane haholo ho feta palo ea mefuta ea `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Lekola phoso mona ho fokotsa boholo ba `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Morekisi o lekola tekatekano ea tatellano
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// E lokolla memori ea `RawVec`*ntle le* ho leka ho lahla litaba tsa eona.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Mosebetsi o bohareng oa ho sebetsana le liphoso.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Re hloka ho netefatsa tse latelang:
// * Ha ho mohla re abelang lintho tsa boholo ba `> isize::MAX` byte.
// * Ha re khaphatsehe `usize::MAX` mme ha e le hantle re aba e nyane haholo.
//
// Ho li-bit-64 re hloka feela ho lekola ho khaphatseha kaha ho leka ho aba li-`> isize::MAX` byte ho tla hloleha ruri.
// Ho li-32-bit le 16-bit re hloka ho eketsa tšireletso bakeng sa sena haeba re matha sethaleng se ka sebelisang 4GB kaofela sebakeng sa mosebelisi, mohlala, PAE kapa x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Mosebetsi o mong oa mantlha o ikarabellang bakeng sa bokhoni ba ho tlaleha oa tlala.
// Sena se tla netefatsa hore moloko oa khoutu o amanang le tsena panics o nyane kaha ho na le sebaka se le seng feela panics ho fapana le sehlopha ho pholletsa le module.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}