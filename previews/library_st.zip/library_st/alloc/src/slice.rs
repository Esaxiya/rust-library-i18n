//! Pono e boholo bo matla ka tatellano e kopaneng, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Likarolo ke pono ea mohopolo o emeloang e le sesupa le bolelele.
//!
//! ```
//! // ho slica Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ho qobella sehlopha ho selae
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Likarolo li ka fetoha kapa tsa arolelanoa.
//! Mofuta oa selae se arolelanoeng ke `&[T]`, ha mofuta oa selae se ka fetohang ke `&mut [T]`, moo `T` e emelang mofuta oa element.
//! Mohlala, o ka fetola mohopolo oo sengoathoana se ka fetohang se supang ho ona:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Mona ke lintho tse ling tse module ena e nang le tsona:
//!
//! ## Structs
//!
//! Ho na le litepisi tse 'maloa tse thusang lilae, joalo ka [`Iter`], e emelang iteration holim'a selae.
//!
//! ## Ts'ebetsong ea Trait
//!
//! Ho na le lits'ebetso tse 'maloa tsa traits tse tloaelehileng bakeng sa likhae.Mehlala e meng e kenyelletsa:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], bakeng sa likhechana tseo mofuta oa tsona e leng [`Eq`] kapa [`Ord`].
//! * [`Hash`] - bakeng sa likhae tse mofuta oa elemente e leng [`Hash`].
//!
//! ## Iteration
//!
//! Lilae li kenya ts'ebetsong `IntoIterator`.Iterator e hlahisa litšupiso tsa likarolo tsa selae.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Selae se ka fetohang se hlahisa litšupiso tse ka feto-fetohang ho maemo a leholimo:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iterator ena e hlahisa litšupiso tse ka feto-fetohang ho likarolo tsa selae, ka hona ha mofuta oa selae e le `i32`, mofuta oa iterator ke `&mut i32`.
//!
//!
//! * [`.iter`] le [`.iter_mut`] ke mekhoa e hlakileng ea ho khutlisa li-iterator tsa kamehla.
//! * Mekhoa e meng e khutlisetsang li-iterator ke [`.split`], [`.splitn`], [`.chunks`], [`.windows`] le tse ling.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Boholo ba tšebeliso ea module ena e sebelisoa feela molemong oa tlhahlobo.
// Ho hloekile ho tima feela ts'ebeliso e sa sebelisoeng_ho kenya ho e lokisa.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Mekhoa ea mantlha ea katoloso ea selae
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) e hlokahalang bakeng sa ho kenya tšebetsong XroX macro nakong ea liteko tsa NB, bona module ea `hack` faeleng ena bakeng sa lintlha tse ling.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) e hlokahalang bakeng sa ts'ebetsong ea `Vec::clone` nakong ea tlhahlobo ea NB, bona module ea `hack` faeleng ena bakeng sa lintlha tse ling.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Ha cfg(test) `impl [T]` e sa fumanehe, mesebetsi ena e meraro ke mekhoa e `impl [T]` empa e se ho `core::slice::SliceExt`, re hloka ho fana ka mesebetsi ena bakeng sa tlhahlobo ea `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Ha rea lokela ho eketsa mohopolo o inline ho sena kaha sena se sebelisoa haholo ho `vec!` macro mme se baka khatello ea sehlahisoa.
    // Bona #71204 bakeng sa lipuisano le liphetho tsa perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Lintho li ne li tšoailoe li qalisoa ka mokotleng o ka tlase
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) Ho hlokahala hore LLVM e tlose licheke tsa meeli mme e na le codegen e betere ho feta zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec e ile ea abuoa le ho qalisoa kaholimo ho bonyane bolelele bona.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // e fanoeng kaholimo ka matla a `s`, 'me u qalelle ho `s.len()` ho ptr::copy_to_non_overlapping ka tlase.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Hlopha selae.
    ///
    /// Mofuta ona o tsitsitse (ke hore, ha o hlophise bocha likarolo tse lekanang) le *O*(*n*\*log(* n*)) nyeoe e mpe ka ho fetesisa.
    ///
    /// Ha ho sebetsa, ho khethoa ho sa tsitsang ho khethoa hobane hangata ho potlaka ho feta ho hlopha ho tsitsitseng mme ha e fane ka mohopolo o thusang.
    /// Bona [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale ke mofuta o ikamahanyang, o kopanyang o phetoang o bululetsoeng ke [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// E etselitsoe hore e potlake haholo maemong ao selae se batlang se hlophisoa, kapa se entsoe ka tatellano e hlophiloeng habeli kapa ho feta e kopantsoeng ka tatellano.
    ///
    ///
    /// Hape, e fana ka polokelo ea nakoana halofo ea `self`, empa bakeng sa lilae tse khuts'oane mofuta oa kenyelletso o sa abeng o sebelisoa ho fapana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Hlophisa selae ka mosebetsi oa ho bapisa.
    ///
    /// Mofuta ona o tsitsitse (ke hore, ha o hlophise bocha likarolo tse lekanang) le *O*(*n*\*log(* n*)) nyeoe e mpe ka ho fetesisa.
    ///
    /// Mosebetsi oa ho bapisa o tlameha ho hlalosa tatellano eohle ea likarolo tsa selae.Haeba odara e sa fella, taelo ea lielemente ha e tsejoe.
    /// Taelo ke taelo e felletseng haeba e le (bakeng sa bohle `a`, `b` le `c`):
    ///
    /// * total and antisymmetric: hantle ke e le 'ngoe ea `a < b`, `a == b` kapa `a > b`,' me
    /// * e fetohang, `a < b` le `b < c` e bolela `a < c`.E ts'oanang e tlameha ho ts'oara `==` le `>`.
    ///
    /// Mohlala, ha [`f64`] e sa sebelise [`Ord`] hobane `NaN != NaN`, re ka sebelisa `partial_cmp` joalo ka mofuta oa rona ha re tseba hore selae ha se na `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Ha ho sebetsa, ho khethoa ho sa tsitsang ho khethoa hobane hangata ho potlaka ho feta ho hlopha ho tsitsitseng mme ha e fane ka mohopolo o thusang.
    /// Bona [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale ke mofuta o ikamahanyang, o kopanyang o phetoang o bululetsoeng ke [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// E etselitsoe hore e potlake haholo maemong ao selae se batlang se hlophisoa, kapa se entsoe ka tatellano e hlophiloeng habeli kapa ho feta e kopantsoeng ka tatellano.
    ///
    /// Hape, e fana ka polokelo ea nakoana halofo ea `self`, empa bakeng sa lilae tse khuts'oane mofuta oa kenyelletso o sa abeng o sebelisoa ho fapana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ho hlopha ka morao
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Hlophisa selae ka ts'ebetso ea senotlolo.
    ///
    /// Mofuta ona o tsitsitse (ke hore, ha o hlophise bocha likarolo tse lekanang) le *O*(*m*\* * n *\* log(*n*)) boemo bo bobe ka ho fetesisa, moo mosebetsi oa bohlokoa e leng *O*(*m*).
    ///
    /// Bakeng sa mesebetsi ea bohlokoa e turang (mohlala
    /// mesebetsi eo e seng phihlello ea thepa e bonolo kapa lits'ebetso tsa mantlha), [`sort_by_cached_key`](slice::sort_by_cached_key) e kanna ea potlaka haholo, kaha ha e busetse linotlolo tsa elemente.
    ///
    ///
    /// Ha ho sebetsa, ho khethoa ho sa tsitsang ho khethoa hobane hangata ho potlaka ho feta ho hlopha ho tsitsitseng mme ha e fane ka mohopolo o thusang.
    /// Bona [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale ke mofuta o ikamahanyang, o kopanyang o phetoang o bululetsoeng ke [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// E etselitsoe hore e potlake haholo maemong ao selae se batlang se hlophisoa, kapa se entsoe ka tatellano e hlophiloeng habeli kapa ho feta e kopantsoeng ka tatellano.
    ///
    /// Hape, e fana ka polokelo ea nakoana halofo ea `self`, empa bakeng sa lilae tse khuts'oane mofuta oa kenyelletso o sa abeng o sebelisoa ho fapana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Hlophisa selae ka ts'ebetso ea senotlolo.
    ///
    /// Nakong ea ho hlopha, mosebetsi oa bohlokoa o bitsoa hang feela ka ntlha e ngoe.
    ///
    /// Mofuta ona o tsitsitse (ke hore, ha o hlophise bocha likarolo tse lekanang) le *O*(*m*\*n* + *n*\*log(* n *)) boemo bo bobe ka ho fetesisa, moo mosebetsi oa bohlokoa e leng* O *(* m *) .
    ///
    /// Bakeng sa mesebetsi e bonolo ea bohlokoa (mohlala, mesebetsi e fihlellang thepa kapa ts'ebetso ea mantlha), [`sort_by_key`](slice::sort_by_key) e kanna ea potlaka.
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le [pattern-defeating quicksort][pdqsort] ea Orson Peters, e kopanyang nyeoe e potlakileng ea karolelano e potlakileng le boemo bo potlakileng ka ho fetesisa ba heapsort, ha e ntse e fihlela nako e lekanang lilomong ka mekhoa e meng.
    /// E sebelisa mekhoa e meng ho qoba maemo a senyehang, empa ka seed e sa fetoheng ho fana ka boits'oaro bo ikemiselitseng.
    ///
    /// Boemong bo bobe ka ho fetesisa, algorithm e fana ka polokelo ea nakoana ho `Vec<(K, usize)>` bolelele ba selae.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Mothusi macro oa ho etsa index ea vector ea rona ka mofuta o monyane ka ho fetisisa, ho fokotsa kabo.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Lintlha tsa `indices` li ikhethile, joalo ka ha li na le li-index, ka hona mofuta ofe kapa ofe o tla tsitsa mabapi le selae sa mantlha.
                // Re sebelisa `sort_unstable` mona hobane e hloka kabo e tlase ea memori.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// E kopitsa `self` ho `Vec` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Mona, `s` le `x` li ka fetoloa ka mokhoa o ikemetseng.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// E kopitsa `self` ho `Vec` e ncha le kabo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Mona, `s` le `x` li ka fetoloa ka mokhoa o ikemetseng.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, bona module ea `hack` faeleng ena bakeng sa lintlha tse ling.
        hack::to_vec(self, alloc)
    }

    /// E fetola `self` hore e be vector ntle le li-clone kapa kabo.
    ///
    /// vector e hlahisoang e ka fetoloa hore e be lebokose ka `Vec<T>Mokhoa oa `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` e ke ke ea hlola e sebelisoa hobane e fetotsoe `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, bona module ea `hack` faeleng ena bakeng sa lintlha tse ling.
        hack::into_vec(self)
    }

    /// E etsa vector ka ho pheta selae makhetlo a `n`.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla panic haeba bokhoni bo ka tlala.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ha e khaphatseha:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Haeba `n` e kholo ho feta zero, e ka aroloa ka `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` nomoro e emeloang ke karolo e setseng ea '1' ea `n`, 'me `rem` ke karolo e setseng ea `n`.
        //
        //

        // U sebelisa `Vec` ho fihlella `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ho pheta-pheta ho etsoa ka makhetlo a mabeli a `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Haeba `m > 0`, ho na le li-bits ho isa ho '1' e ka letsohong le letšehali.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` e na le matla a `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) Ho pheta-pheta ho etsoa ka ho kopitsa pheta-pheto ea pele ea `rem` ho tloha ho `buf` ka boyona.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Sena ha se kopane ho tloha `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` e lekana le `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens selae sa `T` ka boleng bo le bong `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens selae sa `T` hore e be boleng bo le bong `Self::Output`, e behe karohano e fanoeng lipakeng tsa e ngoe le e ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens selae sa `T` hore e be boleng bo le bong `Self::Output`, e behe karohano e fanoeng lipakeng tsa e ngoe le e ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// E khutlisa vector e nang le kopi ea selae sena moo byte e 'ngoe le e' ngoe e ngotsoe 'mapa oa eona o phahameng oa ASCII.
    ///
    ///
    /// Litlhaku tsa ASCII 'a' ho 'z' li ngotsoe ho 'A' ho 'Z', empa litlhaku tseo e seng tsa ASCII ha lia fetoha.
    ///
    /// Ho sebelisa boleng bo phahameng sebakeng sa eona, sebelisa [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// E khutlisa vector e nang le kopi ea selae sena moo byte e 'ngoe le e' ngoe e ngotsoe 'mapa oa eona o tlase oa ASCII.
    ///
    ///
    /// Litlhaku tsa ASCII 'A' ho 'Z' li ngotsoe ho 'a' ho 'z', empa litlhaku tseo e seng tsa ASCII ha lia fetoha.
    ///
    /// Ho fokotsa boleng sebakeng, sebelisa [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits bakeng sa lilae ho feta mefuta e itseng ea data
////////////////////////////////////////////////////////////////////////////////

/// Mothusi trait bakeng sa [`[T]: : concat`](selae::concat).
///
/// Note: mofuta oa `Item` ha o sebelisoe ho trait ena, empa e lumella li-impls hore li be tse tloaelehileng.
/// Ntle ho eona, re fumana phoso ena:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Lebaka ke hore ho ka ba le mefuta ea `V` e nang le li-impl tsa `Borrow<[_]>` tse ngata, joalo ka hore mefuta e mengata ea `T` e ka sebetsa:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Mofuta o hlahisoang kamora concatenation
    type Output;

    /// Ts'ebetsong ea [`[T]: : concat`](selae::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Mothusi trait bakeng sa [`[T]: : join`](selae::kopanya)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Mofuta o hlahisoang kamora concatenation
    type Output;

    /// Ts'ebetsong ea [`[T]: : join`](selae::kopanya)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ts'ebetsong e tloaelehileng ea trait bakeng sa lilae
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // lahlela ntho efe kapa efe moo e habiloeng e ke keng ea hatisoa
        target.truncate(self.len());

        // target.len <= self.len ka lebaka la truncate e kaholimo, ka hona, lilae tsa mona li lula li le moeling.
        //
        let (init, tail) = self.split_at(target.len());

        // sebelisa hape litekanyetso tse nang le allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// E kenya `v[0]` ka tatellano e hlophisitsoeng pele ho `v[1..]` hore `v[..]` kaofela e hlophisoe.
///
/// Ena ke karoloana ea bohlokoa ea mofuta oa kenyelletso.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Ho na le mekhoa e meraro ea ho kenya ts'ebeliso mona:
            //
            // 1. Fapanyetsana likarolo tse haufi ho fihlela ea pele e fihla moo e fihlang teng.
            //    Leha ho le joalo, ka tsela ena re kopitsa data ho feta kamoo ho hlokahalang.
            //    Haeba likarolo e le meaho e meholo (e theko e boima ho e kopitsa), mokhoa ona o tla lieha.
            //
            // 2. Itate ho fihlela sebaka se nepahetseng sa elemente ea pele se fumaneha.
            // Ebe u sutumetsa likarolo tse e hlahlamang ho e etsetsa sebaka 'me qetellong u li kenye ka mokoting o setseng.
            // Ona ke mokhoa o motle.
            //
            // 3. Kopitsa ntlha ea pele hore e fetohe ka nakoana.Itate ho fihlela sebaka se nepahetseng bakeng sa eona e fumanoa.
            // Ha re ntse re tsoela pele, kopitsa ntho e 'ngoe le e' ngoe e haulang ka har'a slot e ka pele ho eona.
            // Kamora nako, kopitsa data ho tloha mofuteng oa nakoana ho kena ka mokoting o setseng.
            // Mokhoa ona o motle haholo.
            // Lipontšo li bontšitse ts'ebetso e betere hofeta ka mokhoa oa bobeli.
            //
            // Mekhoa eohle e ne e lekantsoe, 'me ea boraro e bonts'a liphetho tse ntle.Kahoo re e khethile.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Boemo ba lipakeng tsa ts'ebetso ea ho kenya bo lula bo lateloa ke `hole`, e sebeletsang merero e 'meli:
            // 1. E sireletsa bots'epehi ba `v` ho panics ho `is_less`.
            // 2. E tlatsa sekoti se setseng ho `v` qetellong.
            //
            // Ts'ireletso ea Panic:
            //
            // Haeba `is_less` panics ka nako efe kapa efe nakong ea ts'ebetso, `hole` e tla theoha ebe e tlatsa lesoba la `v` ka `tmp`, ka hona e netefatsa hore `v` e ntse e tšoere ntho e ngoe le e ngoe eo e neng e e tšoere hang hang.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` oa theoha 'me kahoo o kopitsa `tmp` ka mokoting o setseng oa `v`.
        }
    }

    // Ha e liheloa, likopi ho tloha `src` ho ea ho `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// E kopanya meralo e sa fokotseheng ea `v[..mid]` le `v[mid..]` e sebelisa `buf` joalo ka polokelo ea nakoana, ebe e boloka sephetho ho `v[..]`.
///
/// # Safety
///
/// Lilae tse peli li tlameha hore ebe ha li na letho 'me `mid` e tlameha ho ba meeling.
/// Buffer `buf` e tlameha ho ba nako e telele ho lekana ho tšoara kopi ea selae se sekhutšoane.
/// Hape, `T` ha ea lokela ho ba mofuta oa boholo ba zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ts'ebetso ea ho kopanya e kopitsa likopi tse khuts'oane ho `buf`.
    // E ntan'o latela metha e sa tsoa kopitsoa le e telele ho ea pele (kapa morao), ho bapisa likarolo tsa bona tse latelang tse sa nahanoang le ho kopitsa e nyane (kapa e kholo) ho `v`.
    //
    // Hang ha lebelo le lekhuts'oane le sebelisoa ka botlalo, mohato o etsoa.Haeba nako e telele e fela pele, re tla tlameha ho kopitsa eng kapa eng e setseng ea nako e khuts'oane ho kena ka mokoting o setseng oa `v`.
    //
    // Boemo ba lipakeng tsa ts'ebetso bo lula bo lateloa ke `hole`, e sebeletsang merero e 'meli:
    // 1. E sireletsa bots'epehi ba `v` ho panics ho `is_less`.
    // 2. E tlatsa sekoti se setseng ho `v` haeba nako e telele e qala ho jeoa.
    //
    // Ts'ireletso ea Panic:
    //
    // Haeba `is_less` panics ka nako efe kapa efe nakong ea ts'ebetso, `hole` e tla theoha ebe e tlatsa sekoti ho `v` ka moeli o sa nkuoeng ho `buf`, ka hona ho netefatsa hore `v` e ntse e tšoere ntho e ngoe le e ngoe eo e neng e e tšoere hang hang.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ho matha ka ho le letšehali ho khutsuanyane.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Qalong, litsupa tsena li supa qalehong ea tatellano ea tsona.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Sebelisa lehlakore le lenyane.
            // Haeba e lekana, khetha lebelo le letšehali ho boloka botsitso.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Tsela e nepahetseng e khutšoanyane.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Qalong, litsupa tsena li supa lipheletsong tsa tatellano ea tsona.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Sebelisa lehlakore le leholo.
            // Haeba e lekana, khetha lebelo le nepahetseng ho boloka botsitso.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Qetellong, `hole` ea theoha.
    // Haeba lebelo le lekhuts'oane le sa sebelisoe ka botlalo, eng kapa eng e setseng e tla kopitsoa ka sekoting sa `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ha e lahliloe, e kopitsa mofuta oa `start..end` ho `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ha se mofuta oa zero, kahoo ho lokile ho arola ka boholo ba eona.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Mofuta ona oa kopanyo o alima mehopolo e meng (empa eseng kaofela) ho TimSort, e hlalositsoeng ka botlalo [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algorithm e supa methati e theohelang hantle le e sa theoheng, e bitsoang matha a tlhaho.Ho na le pokello ea li matha tse ntseng li lokela ho kopanngoa.
/// Motsamao o mong le o mong o sa tsoa fumanoa o sutumelletsoa ka mokotleng, ebe lipara tse ling tse haufi li kopantsoe ho fihlela bahlaseli bana ba babeli ba khotsofetse:
///
/// 1. bakeng sa `i` e ngoe le e ngoe ho `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. bakeng sa `i` e ngoe le e ngoe ho `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Lintho tse hlaselang li etsa bonnete ba hore nako eohle ea ho matha ke *O*(*n*\*log(* n*)) e mpe haholo.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Likarolo tsa bolelele bona li a hlophisoa ho sebelisoa mofuta oa kenyelletso.
    const MAX_INSERTION: usize = 20;
    // Ho matha hakhutšoanyane haholo ho atolosoa ho sebelisoa mofuta oa ho kenya ho fihlela bonyane likarolo tsena tse ngata.
    const MIN_RUN: usize = 10;

    // Ho hlopha ha ho na boits'oaro bo nang le moelelo ho mefuta ea boholo ba zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Likarolo tse khutšoane li hlophisoa kahare ka mokhoa oa ho kenya ho qoba likabo.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Fana ka buffer eo u ka e sebelisang joalo ka mohopolo oa ho qala.Re boloka bolelele ba 0 hore re tle re boloke ho eona likopi tse sa tebang tsa litaba tsa `v` ntle le ho beha batseteli ba tsamaeang likoping haeba `is_less` panics.
    //
    // Ha o kopanya li-run tse peli tse hlophiloeng, buffer ena e ts'oara kopi ea run e khuts'oane, e tla lula e le bolelele boholo ba `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Bakeng sa ho khetholla lintho tsa tlhaho tse tsamaeang ka `v`, rea li tšela morao.
    // Seo se ka utloahala e le qeto e makatsang, empa nahana ka taba ea hore ho kopana hangata ho ea ka lehlakoreng le fapaneng la (forwards).
    // Ho latela lipalo, ho kopana ho ea pele ho potlakile hanyane ho feta ho kopanya ka morao.
    // Ho phethela, ho khetholla matha ka ho leba morao ho ntlafatsa ts'ebetso.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Fumana ts'ebetso e latelang ea tlhaho, 'me ue khutlisetse morao haeba e theoha ka tieo.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Kenya likarolo tse ling hore li sebetse haeba e le khutšoane haholo.
        // Mofuta oa ho kenya o potlakile ho feta ho kopanya mofuta ka tatellano e khuts'oane, ka hona sena se ntlafatsa ts'ebetso haholo.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Sutumetsa sena ho matha.
        runs.push(Run { start, len: end - start });
        end = start;

        // Kopanya lipara tse ling tse haufi ho khotsofatsa tse hlaselang.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Kamora nako, tatellano e le 'ngoe e tlameha ho lula ka mokotleng.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // E hlahloba pokello ea limathi ebe e khetholla li-run tse latelang ho kopanya.
    // Haholo-holo, haeba `Some(r)` e khutlisitsoe, ho bolela hore `runs[r]` le `runs[r + 1]` li tlameha ho kopanngoa kamora moo.
    // Haeba algorithm e ka tsoelapele ho aha mokhoa o mocha ho fapana le moo, `None` ea khutlisoa.
    //
    // TimSort e tumme hampe ka ts'ebetsong ea eona ea kariki, joalo ka ha ho hlalositsoe mona:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Moko-taba oa pale ke hore: re tlameha ho tiisa lintho tse sa keneng maemong a mane a holimo ka har'a sethopo.
    // Ho ba qobella ho tse tharo feela tse holimo ha hoa lekana ho netefatsa hore bahlaseli ba ntse ba tšoarella bakeng sa li-run tsohle tsa * spaka.
    //
    // Ts'ebetso ena e hlahloba ka nepo lintho tse sa sebetseng bakeng sa matha a mane a holimo.
    // Ntle le moo, haeba ts'ebetso e holimo e qala ho index 0, e tla lula e batla ts'ebetso ea ho kopanya ho fihlela stack e putlame ka botlalo, ho phethela mofuta oo.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}