use core::marker::PhantomData;
use core::ptr::NonNull;

/// E etsa mohlala oa phokotso ea ts'upiso e ikhethileng, ha o tseba hore mokoloto le litloholo tsohle tsa ona (ke hore, litsupa tsohle le litšupiso tse tsoang ho ona) ha li sa tla sebelisoa ka nako e ngoe, kamora moo o batla ho sebelisa ts'upiso e ikhethang e ikhethang hape .
///
///
/// Ts'ebetso ea ho alima hangata e sebetsana le pokello ena ea mekoloto bakeng sa hau, empa phallo e 'ngoe ea taolo e fihlelang stacking ena e thata haholo hore moqapi a e latele.
/// `DormantMutRef` eu lumella ho lekola ho ikalima, ha u ntse u hlahisa sebopeho sa eona, 'me u akaretsa khoutu ea sesupisi e tala e hlokahalang ho etsa sena ntle le boits'oaro bo sa hlalosoang.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Tšoara mokoloto o ikhethang, 'me u o alime hang hang.
    /// Bakeng sa motlatsi, nako ea ts'ebeliso ea sets'oants'o se secha e ts'oana le nako ea ts'ebeliso ea mantlha, empa uena promise ho e sebelisa nako e khuts'oane.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // TSHIRELETSO: re tshwara kalimo hohle 'a ka `_marker`, mme rea pepesa
        // feela tšupiso ena, ka hona e ikhethile.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Khutlela mokolotong o ikhethang o hapiloeng qalong.
    ///
    /// # Safety
    ///
    /// Kamohelo ea chelete e tlameha ebe e felile, ke hore, litšupiso tse khutlisitsoeng ke `new` le lits'oants'o tsohle le litšupiso tse tsoang ho eona, ha lia lokela ho sebelisoa hape.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // TSHIRELETSO: maemo a rona a polokeho a bolela hore tshupiso ena e boetse e ikgethile.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;