use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// E kenya likarolo tsohle tsa boleng ba bohlokoa ho tloha bonngoeng ba li-iterator tse nyolohang tse peli, e eketsa phapang ea `length` tseleng.Ea morao-rao e nolofalletsa motho ea letsitseng ho qoba ho lutla ha motsamaisi oa lerotholi a tšoha.
    ///
    /// Haeba li-iterator ka bobeli li hlahisa senotlolo se le seng, mokhoa ona o theola bobeli ba bona ho tloha ho iterator ea leqeleng ebe o kenya ba babeli ho tloha ho iterator e nepahetseng.
    ///
    /// Haeba u batla hore sefate se qetelle ka tatellano e nyolohang haholo, joalo ka `BTreeMap`, li-iterator ka bobeli li lokela ho hlahisa linotlolo ka tatellano e nyolohang, e ngoe le e ngoe e kholo ho feta linotlolo tsohle tsa sefate, ho kenyeletsoa linotlolo life kapa life tse seng li le sefateng ha li kena.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Re itokisetsa ho kopanya `left` le `right` ka tatellano e hlophisitsoeng ka nako e lekanang.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Khabareng, re haha sefate ho tloha ka tatellano e hlophisitsoeng ka nako e lekanang.
        self.bulk_push(iter, length)
    }

    /// E sututsa lipara tsohle tsa boleng ba bohlokoa ho fihla qetellong ea sefate, e eketsa phapang ea `length` tseleng.
    /// Ea morao-rao e nolofalletsa motho ea letsitseng ho qoba ho lutla ha iterator e tšoha.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ikarola ka lipara tsohle tsa boleng ba bohlokoa, u li sutumetse ho li-node boemong bo nepahetseng.
        for (key, value) in iter {
            // Leka ho sututsa para ea boleng ba senotlolo ka har'a node ea lekhasi ea hajoale.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ha ho na sebaka se setseng, nyoloha 'me u sutumetse moo.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // U fumane node e nang le sebaka se setseng, sutumelletsa mona.
                                open_node = parent;
                                break;
                            } else {
                                // Nyoloha hape.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Re holimo, re theha node e ncha ea metso ebe re sutumetsa moo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Sutumelletsa para ea boleng ba senotlolo le karolo e ncha e ncha ea tokelo.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Theoha hape ho lekhasi le letona ka ho le letona hape.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Bolelele ba keketso e ngoe le e ngoe, ho etsa bonnete ba hore 'mapa o lahla likarolo tse kentsoeng le ha o ntse o ntšetsa pele iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator bakeng sa ho kopanya tatellano e hlophisitsoeng e le 'ngoe
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Haeba linotlolo tse peli li lekana, e khutlisa para ea boleng ba senotlolo ho tsoa mohloling o nepahetseng.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}