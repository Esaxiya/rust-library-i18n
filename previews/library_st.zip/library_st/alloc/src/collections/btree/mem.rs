use core::intrinsics;
use core::mem;
use core::ptr;

/// Sena se nkela boleng ba `v` bo ikhethang ka ho bitsa ts'ebetso e nepahetseng.
///
///
/// Haeba panic e etsahala ha `change` e koaloa, ts'ebetso eohle e tla ntšoa.
#[allow(dead_code)] // boloka joalo ka papiso le ts'ebeliso ea future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Sena se nka sebaka sa boleng bo ka morao ho `v` e ikhethang ka ho bitsa ts'ebetso e nepahetseng, 'me se khutlisa sephetho se fumanoeng tseleng.
///
///
/// Haeba panic e etsahala ha `change` e koaloa, ts'ebetso eohle e tla ntšoa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}