use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// E tlameha ho batloa ka kakaretso, joalo ka `Bound::Included(T)`.
    Included(T),
    /// Tlamo e ikhethileng eo u ka e batlang, joalo ka `Bound::Excluded(T)`.
    Excluded(T),
    /// Tlamo e kenyellelitsoeng tlasa maemo, joalo ka `Bound::Unbounded`.
    AllIncluded,
    /// Tlamo e ikhethileng e ikhethileng.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// E sheba senotlolo se fuoeng sefateng sa (sub) se etelletsoeng pele ke node, hape.
    /// E khutlisa `Found` ka mohele oa KV e tšoanang, haeba e teng.
    /// Ho seng joalo, e khutlisa `GoDown` ka mohele oa lekhasi edge moo senotlolo e leng sa eona.
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo, joalo ka sefate sa `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// E theohela node e haufinyane moo edge e bapisang moeli o ka tlase oa moeli e fapaneng le edge e ts'oanang le moeli o kaholimo, ke hore, node e haufinyane e nang le senotlolo bonyane se le seng se fumanehang mokokotlong.
    ///
    ///
    /// Haeba e fumanoe, e khutlisa `Ok` e nang le node eo, li-index tsa edge ho eona li fokotsa moeli, le meeli e lekanang ea ho ntšetsa pele lipatlisiso ho li-node tsa bana, haeba node e le kahare.
    ///
    /// Haeba e sa fumanoe, e khutlisa `Err` e nang le lekhasi la edge le lekanang le bophara bohle.
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Ha ho kenyelletsoa mefuta ena ho lokela ho qojoa.
        // Re nahana hore meeli e tlalehiloeng ke `range` e lula e tšoana, empa ts'ebetsong e khahlano le maemo e ka fetoha lipakeng tsa mehala ea (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// E fumana edge ka node e lekanyang moeli o tlase oa mofuta.
    /// E boetse e khutlisa tlamo e tlase e tla sebelisoa ho ntšetsa pele patlo sebakeng se ts'oanang sa bana, haeba `self` e le node ea ka hare.
    ///
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone ea `find_lower_bound_edge` ea mohala o kaholimo.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// E sheba senotlolo se fuoeng node, ntle le ho ipheta.
    /// E khutlisa `Found` ka mohele oa KV e tšoanang, haeba e teng.
    /// Ho seng joalo, e khutlisa `GoDown` ka mohele oa edge moo senotlolo se ka fumanoang (haeba node e le kahare) kapa moo senotlolo se ka kenngoang.
    ///
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo, joalo ka sefate sa `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// E khutlisa index ea KV sebakeng sa senotlolo seo senotlolo (kapa se lekanang le sona) se leng teng, kapa index ea edge moo senotlolo e leng sa eona.
    ///
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo, joalo ka sefate sa `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// E fumana index ea edge ka node e lekanyang moeli o tlase oa mofuta.
    /// E boetse e khutlisa tlamo e tlase e tla sebelisoa ho ntšetsa pele patlo sebakeng se ts'oanang sa bana, haeba `self` e le node ea ka hare.
    ///
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone ea `find_lower_bound_index` bakeng sa mohala o holimo.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}