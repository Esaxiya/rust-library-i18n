use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Motsoako oa iterator o kopanyang tlhahiso ea bapalami ba babeli ba nyolohang ka thata, ka mohlala mokhatlo kapa phapang e lumellanang.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Lipontšo li potlakile ho feta ho thatela li-iterator ka bobeli ho Peekable, mohlomong hobane re khona ho qobella FusedIterator.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// E theha mantlha e mocha bakeng sa iterator e kopanyang mehloli e 'meli.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// E khutlisa lintho tse peli tse latelang tse tsoang mehloling e meng e kopaneng.
    /// Haeba likhetho tse khutlisitsoeng ka bobeli li na le boleng, boleng boo bo lekana 'me bo hlaha mehloling ka bobeli.
    /// Haeba e 'ngoe ea likhetho tse khutlisitsoeng e na le boleng, boleng boo ha bo hlahe mohloling o mong (kapa mehloli ha e nyolohe ka tieo).
    ///
    /// Haeba ha ho khetho e khutlisitsoeng e nang le boleng, iteration e felile mme mehala e latelang e tla khutlisa para e tšoanang e se nang letho.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// E khutlisa meeli e kaholimo ea `size_hint` ea mohlahlobi oa hoqetela.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}