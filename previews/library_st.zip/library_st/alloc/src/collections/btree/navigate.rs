use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// E ntša nakoana e 'ngoe e lekanang le boholo bo tšoanang.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// E fumana makhasi a ikhethileng a khethollang moeli o boletsoeng sefateng.
    /// E khutlisetsa liphara tse fapaneng sefateng se le seng kapa likhetho tse se nang letho.
    ///
    /// # Safety
    ///
    /// Ntle le ha `BorrowType` e le `Immut`, se ke oa sebelisa likopi tse kopitsoang ho etela KV e tšoanang habeli.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// E lekana le `(root1.first_leaf_edge(), root2.last_leaf_edge())` empa e sebetsa hantle haholoanyane.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// O fumana mahlakore a mabeli a makhasi a khethollang moeli o itseng sefateng.
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo, joalo ka sefate sa `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // TŠIRELETSO: mofuta oa rona oa kalimo ha o fetohe.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// O fumana mahlakore a mabeli a makhasi a khethollang sefate kaofela.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// E arola litšupiso tse ikhethileng liparolong tsa makhasi a khethollang moeli o boletsoeng.
    /// Sephetho ke litšupiso tse ikhethileng tse lumellang phetoho ea (some), e lokelang ho sebelisoa ka hloko.
    ///
    /// Sephetho se na le moelelo ha feela sefate se laeloa ke senotlolo, joalo ka sefate sa `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Se ke oa sebelisa likopi tse kopitsoang ho etela KV e tšoanang habeli.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// E arola litšupiso tse ikhethileng liparolong tse peli tsa makhasi tse behang moeli o felletseng oa sefate.
    /// Liphetho ke litšupiso tse ikhethileng tse lumellang phetoho (ea boleng feela), ka hona e tlameha ho sebelisoa ka hloko.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Re kopitsa motso oa NodeRef mona-le ka mohla re ke ke ra etela KV e le 'ngoe habeli,' me ha ho mohla re tla qetella re na le litšupiso tse fetang tsa boleng.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// E arola litšupiso tse ikhethileng liparolong tse peli tsa makhasi tse behang moeli o felletseng oa sefate.
    /// Liphetho ke litšupiso tse sa ikhethileng tse lumellang phetoho e matla haholo, ka hona e tlameha ho sebelisoa ka hloko e kholo.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Re pheta motso oa NodeRef mona-re ke ke ra o fihlela ka tsela e fetang litemana tse fumanoeng motso.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Ha a fuoa lehare la edge, o khutlisa [`Result::Ok`] ka mohele ho KV ea boahelani ka lehlakoreng le letona, e ka bang node e le 'ngoe ea lekhasi kapa node ea baholo-holo.
    ///
    /// Haeba lekhasi la edge ke la ho qetela sefateng, le khutlisa [`Result::Err`] ka node ea motso.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Ha a fuoa lekhasi la edge, o khutlisa [`Result::Ok`] ka mohele ho KV ea boahelani ka lehlakoreng le letšehali, e ka bang node e le 'ngoe ea lekhasi kapa node ea baholo-holo.
    ///
    /// Haeba lekhasi la edge ke la pele sefateng, le khutlisa [`Result::Err`] ka node ea motso.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ha ho fanoa ka mohele oa ka hare oa edge, e khutlisa [`Result::Ok`] ka mohele ho KV ea boahelani ka lehlakoreng le letona, e ka bang node e le 'ngoe ea kahare kapa node ea baholo-holo.
    ///
    /// Haeba edge e ka hare e le ea ho qetela sefateng, e khutlisa [`Result::Err`] ka node ea motso.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ha o fuoa lekhasi la edge ka sefate se shoang, o khutlisa lekhasi le latelang la edge ka lehlakoreng le letona, le para ea boleng ba bohlokoa lipakeng, e ka hara node e le 'ngoe ea lekhasi, node ea baholo-holo, kapa ha e eo.
    ///
    ///
    /// Mokhoa ona o sebetsana le node(s) efe kapa efe ha e fihla qetellong ea.
    /// Sena se fana ka maikutlo a hore haeba ho se ho na le para ea boleng ba bohlokoa, karolo e setseng ea sefate e tla be e tsamaisitsoe mme ha ho na letho le setseng ho khutla.
    ///
    /// # Safety
    /// edge e fanoeng ha ea tlameha hore ebe e ne e khutlisitsoe pejana ke mphato `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Ha o fuoa lehlaka la edge sefateng se shoang, o khutlisa lekhasi le latelang la edge ka lehlakoreng le letšehali, le para ea boleng ba senotlolo e lipakeng, e ka bang node e le 'ngoe ea lekhasi, node ea baholo-holo, kapa ha e eo.
    ///
    ///
    /// Mokhoa ona o sebetsana le node(s) efe kapa efe ha e fihla qetellong ea.
    /// Sena se fana ka maikutlo a hore haeba ho se ho na le para ea boleng ba bohlokoa, karolo e setseng ea sefate e tla be e tsamaisitsoe mme ha ho na letho le setseng ho khutla.
    ///
    /// # Safety
    /// edge e fanoeng ha ea tlameha hore ebe e ne e khutlisitsoe pejana ke mphato `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// E tlosa qubu ea li-node ho tloha lekhasi ho ea motso.
    /// Ena ke eona feela tsela ea ho tsamaisa sefate se setseng kamora `deallocating_next` le `deallocating_next_back` li ntse li kokotletsa mahlakore ka bobeli a sefate, 'me ba fihlile edge e tšoanang.
    /// Joalokaha e reretsoe ho bitsoa feela ha linotlolo tsohle le litekanyetso li khutlisitsoe, ha ho hloekisoe e etsoang ho eng kapa eng ea linotlolo kapa litekanyetso.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// E tsamaisa lekhasi la edge ho lekhasi le latelang la edge ebe e khutlisetsa litšupiso ho senotlolo le boleng bo lipakeng.
    ///
    ///
    /// # Safety
    /// Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// E tsamaisa lekhasi la edge le le tsebang ho lekhasi le fetileng la edge ebe e khutlisetsa litšupiso ho senotlolo le boleng lipakeng.
    ///
    ///
    /// # Safety
    /// Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// E tsamaisa lekhasi la edge ho lekhasi le latelang la edge ebe e khutlisetsa litšupiso ho senotlolo le boleng bo lipakeng.
    ///
    ///
    /// # Safety
    /// Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ho etsa sena ho qetela ho potlakile, ho latela lipalo.
        kv.into_kv_valmut()
    }

    /// E tsamaisa lekhasi la edge ho lekhasi le fetileng ebe e khutlisetsa litšupiso ho senotlolo le boleng lipakeng.
    ///
    ///
    /// # Safety
    /// Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ho etsa sena ho qetela ho potlakile, ho latela lipalo.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// E tsamaisa lekhasi la edge ho lehlaku le latelang la edge ebe e khutlisa senotlolo le boleng lipakeng, e tsamaisa node efe kapa efe e setseng ha e ntse e siea edge e lekanang le node ea eona ea motsoali e leketlileng.
    ///
    /// # Safety
    /// - Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    /// - KV eo e ne e sa khutlisoe pele ke mphato `next_back_unchecked` ho kopi efe kapa efe ea lipalo tse neng li sebelisoa ho haola sefate.
    ///
    /// Mokhoa o le mong feela o bolokehileng oa ho tsoela pele ka mochini o ntlafalitsoeng ke ho o bapisa, ho o lahla, ho letsetsa mokhoa ona hape ho latela maemo a ona a polokeho, kapa ho letsetsa molekane `next_back_unchecked` ho latela maemo a eona a polokeho.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// E tsamaisa lekhasi la edge le leqebeng le fetileng la edge ebe e khutlisa senotlolo le boleng lipakeng, e tsamaisa node efe kapa efe e setseng ha e ntse e siea edge e lekanang le node ea eona ea motsoali e leketlileng.
    ///
    /// # Safety
    /// - Ho tlameha hore ho be le KV e ngoe ntlheng eo ba e tsamaileng.
    /// - Lekhasi leo edge le ne le sa khutlisoe ke mphato `next_unchecked` ho kopi efe kapa efe ea lipalo tse neng li sebelisoa ho haola sefate.
    ///
    /// Mokhoa o le mong feela o bolokehileng oa ho tsoela pele ka mochini o ntlafalitsoeng ke ho o bapisa, ho o lahla, ho letsetsa mokhoa ona hape ho latela maemo a ona a polokeho, kapa ho letsetsa molekane `next_unchecked` ho latela maemo a eona a polokeho.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// E khutlisetsa lekhasi le letšehali le edge kahare kapa ka tlasa node, ka mantsoe a mang, edge eo o e hlokang pele ha o fetela pele (kapa o qetela ha o leba morao).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// E khutlisetsa lekhasi le ka ho le letona la edge kahare kapa ka tlasa node, ka mantsoe a mang, edge eo o e hlokang ho qetela ha o fetela pele (kapa pele ha o leba morao).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// E etela li-node tsa makhapetla le li-KV tsa kahare ka tatellano ea linotlolo tse nyolohang, hape e etela li-node tsa kahare ka botlalo ka tatellano ea pele, ho bolelang hore li-node tsa ka hare li etella li-KV tsa bona ka bomong le li-node tsa bana.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// E lekanya palo ea likarolo tsa sefate sa (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// E khutlisetsa lekhasi edge haufi le KV bakeng sa ho fetela pele.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// E khutlisa lekhasi edge haufi le KV bakeng sa ho sesa morao.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}