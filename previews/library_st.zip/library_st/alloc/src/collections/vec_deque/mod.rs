//! Lethathamo le emisitsoeng habeli le kenngoe tšebelisong ea tšepe e holang.
//!
//! Lethathamo lena le na le *O*(1) ho kentsoe liphoso le ho tlosoa ho tsoa lipheletsong tse peli tsa setshelo.
//! E na le index ea *O*(1) joalo ka vector.
//! Lintho tse fumanehang ha li hlokehe hore li ka kopitsoa, 'me mokoloko o tla romelloa haeba mofuta o teng o ka romelloa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Matla a maholo ka ho fetisisa a mabeli

/// Lethathamo le emisitsoeng habeli le kenngoe tšebelisong ea tšepe e holang.
///
/// Ts'ebeliso ea "default" ea mofuta ona e le lethathamo ke ho sebelisa [`push_back`] ho eketsa lethathamong, mme [`pop_front`] ho e tlosa moleng.
///
/// [`extend`] le [`append`] e sutumelletsa mokokotlong ka mokhoa ona, 'me ho pheta-pheta ho feta `VecDeque` ho ea pele ho ea morao.
///
/// Kaha `VecDeque` ke sesebelisoa sa lesale, likarolo tsa eona ha se hakaalo hore li tšoarella mohopolong.
/// Haeba o batla ho fihlella likarolo joalo ka selae se le seng, joalo ka ho hlopha hantle, o ka sebelisa [`make_contiguous`].
/// E potoloha `VecDeque` e le hore likarolo tsa eona li se ke tsa phuthela, ebe e khutlisa selae se ka fetoloang ho tatellano e teng hona joale ea lintho.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // mohatla le hlooho ke litsupa ka hara buffer.
    // Mohatla o lula o supa ntlha ea pele e ka balloang, Hlooho e lula e supa moo data e lokelang ho ngoloa teng.
    //
    // Haeba mohatla==hlooho buffer ha e na letho.Bolelele ba ringbuffer bo hlalosoa e le sebaka se lipakeng tsa tse peli.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// E matha mosenyi bakeng sa lintho tsohle tse selae ha e theoha (ka tloaelo kapa nakong ea ho phomola).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // sebelisa lerotholi bakeng sa [T]
            ptr::drop_in_place(front);
        }
        // RawVec e sebetsana le phetisetso
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// E etsa `VecDeque<T>` e se nang letho.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Margin e bonolo haholoanyane
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Margin e bonolo haholoanyane
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Bakeng sa mefuta ea zero, re lula re le boemong bo phahameng
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Fetolela ptr selae
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Fetolela ptr ho selae sa mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// E tlosa ntho e tsoang kahare ea buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// O ngola ntho ka hara buffer, ae tsamaisa.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// E khutlisa `true` haeba buffer e se e le maemong a felletseng.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// E khutlisetsa index ho buffer ea mantlha bakeng sa index ea likarolo tse fanoeng.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// E khutlisetsa index ho buffer ea mantlha bakeng sa index e fanoeng ea logical element + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// E khutlisetsa index ho buffer ea mantlha bakeng sa index e fanoeng ea logical element, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// E kopitsa leqhubu la memori len e kopaneng ho tloha src ho isa ho dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// E kopitsa leqhubu la memori len e kopaneng ho tloha src ho isa ho dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// E kopitsa leqhubu la memori len e ka 'nang ea phuthela ho tloha src ho isa qetellong.
    /// (abs(dst - src) + len) ha ea tlameha ho ba kholo ho feta cap() (Ho tlameha hore ho be le sebaka se le seng se tsoelang pele se fetang se pakeng tsa src le dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src ha e phuthetse, dst ha e phuthele
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst pele ho src, src ha e phuthele, dst wraps
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src pele ho dst, src ha e phuthetse, ke wraps ea dst
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst pele src, src e thatela, dst ha e phuthele
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src pele ho dst, src e thatela, dst ha e phuthele
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst pele src, src e thatela, dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src pele ho dst, src e thatela, dst wraps
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs likarolo tsa hlooho le mohatla ho potoloha ho sebetsana le taba ea hore re sa tsoa aroloa hape.
    /// Ha e bolokehe hobane e ts'epa bokhoni ba khale.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Tsamaisa karolo e khuts'oane ka ho fetesisa ea sesepa sa TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              Mofuta oa HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// E etsa `VecDeque` e se nang letho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// E etsa `VecDeque` e se nang letho e nang le sebaka bakeng sa bonyane likarolo tsa `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ho tloha ha ringbuffer kamehla e siea sebaka se le seng se se na letho
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// E fana ka ts'upiso ea elemente ho index e fanoeng.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// E fana ka ts'upiso e ka feto-fetohang ho elemente ho index e fanoeng.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// E chencha likarolo ho li-indices `i` le `j`.
    ///
    /// `i` mme `j` e kanna ea lekana.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Panics
    ///
    /// Panics haeba index efe kapa efe e tsoa meeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// E khutlisa palo ea lisebelisoa tseo `VecDeque` e ka li ts'oarang ntle le ho fallisoa bocha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// E boloka matla a bonyane bakeng sa lintlha tse ling tsa `additional` tse tla kenngoa ho `VecDeque` e fanoeng.
    /// Ha e etse letho haeba bokhoni bo se bo ntse bo lekane.
    ///
    /// Hlokomela hore morekisi a ka fa pokello sebaka se fetang seo a se kopileng.
    /// Ka hona bokhoni bo ke ke ba ts'epahloa hore bo be tlase haholo.
    /// Khetha [`reserve`] haeba ho lebelletsoe kenyelletso ea future.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// E boloka matla a bonyane lintho tse ling tsa `additional` tse tla kenngoa ho `VecDeque` e fanoeng.
    /// Pokello e ka boloka sebaka se eketsehileng ho qoba ho fallisoa khafetsa.
    ///
    /// # Panics
    ///
    /// Panics haeba matla a macha a feta `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// E leka ho boloka bonyane matla bakeng sa lintlha tse ling tsa `additional` tse lokelang ho kenngoa ho `VecDeque<T>` e fanoeng.
    ///
    /// Kamora ho letsetsa `try_reserve_exact`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo ntse bo lekane.
    ///
    /// Hlokomela hore morekisi a ka fa pokello sebaka se fetang seo a se kopileng.
    /// Ka hona, bokhoni bo ke ke ba ts'epahloa hore bo be tlase haholo.
    /// Khetha `reserve` haeba ho lebelletsoe kenyelletso ea future.
    ///
    /// # Errors
    ///
    /// Haeba bokhoni bo khaphatseha `usize`, kapa monehi o tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM(Out-Of-Memory) bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // thatafetse haholo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// E leka ho boloka bokhoni ba bonyane likarolo tse ling tsa `additional` tse tla kenngoa ho `VecDeque<T>` e fanoeng.
    /// Pokello e ka boloka sebaka se eketsehileng ho qoba ho fallisoa khafetsa.
    /// Kamora ho letsetsa `try_reserve`, boholo bo tla ba boholo ho feta kapa bo lekana le `self.len() + additional`.
    /// Ha e etse letho haeba bokhoni bo se bo lekane.
    ///
    /// # Errors
    ///
    /// Haeba bokhoni bo khaphatseha `usize`, kapa monehi o tlaleha ho hloleha, phoso e tla khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Boloka mohopolo pele, o tsoe haeba re sa khone
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Joale rea tseba hore sena se ke ke sa OOM bohareng ba mosebetsi oa rona o rarahaneng
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // thatafetse haholo
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// E fokotsa matla a `VecDeque` ka hohle kamoo ho ka khonehang.
    ///
    /// E tla theoha haufi ka hohle kamoo ho ka khonehang ho ea bolelele empa moabi a ka 'na a tsebisa `VecDeque` hore ho na le sebaka sa likarolo tse ling tse' maloa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// E fokotsa matla a `VecDeque` ka mohala o tlase.
    ///
    /// Bokgoni bo tla lula bonyane bo le boholo bo bolelele le boleng bo fanoeng ka bobeli.
    ///
    ///
    /// Haeba matla a hajoale a le tlase ho moeli o tlase, hona ke ho se sebetse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Ha rea lokela ho tšoenyeha ka ho phalla ha `self.len()` kapa `self.capacity()` e ke ke ea hlola e e-ba `usize::MAX`.
        // +1 ha mohalaleli ea llang a lula a siea sebaka se le seng se se na letho.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Ho na le linyeoe tse tharo tsa thahasello:
            //   Lintlha tsohle li tsoa meeling e lakatsehang Lintlha lia kopaneha, 'me hlooho e tsoa meeling e lakatsehang Lintlha ha li tsebehale,' me mohatla ha o felle meeling eo u e batlang.
            //
            //
            // Ka linako tse ling tsohle, maemo a maemo ha a amehe.
            //
            // E bontša hore likarolo tse hloohong li lokela ho tsamaisoa.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Tlosa likarolo ho tsoa meeling e lakatsehang (maemo kamora ho target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// E khutsufatsa `VecDeque`, e boloka likarolo tsa pele tsa `len` ebe e lahla tse ling kaofela.
    ///
    ///
    /// Haeba `len` e kholo ho feta bolelele ba hajoale ba `VecDeque, sena ha se na phello.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// E matha mosenyi bakeng sa lintho tsohle tse selae ha e theoha (ka tloaelo kapa nakong ea ho phomola).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // E bolokehile hobane:
        //
        // * Selae sefe kapa sefe se fetisitsoeng ho `drop_in_place` sea sebetsa;nyeoe ea bobeli e na le `len <= front.len()` mme e khutlelang ho `len > self.len()` e netefatsa `begin <= back.len()` maemong a pele
        //
        // * Hlooho ea VecDeque e sisinyehile pele e letsetsa `drop_in_place`, ka hona ha ho boleng bo theohelang habeli haeba `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Etsa bonnete ba hore halofo ea bobeli e lahliloe leha a senyehile ho ea pele panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// E khutlisetsa iterator ea pele le ea morao.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// E khutlisetsa iterator e ka pele le ea morao e khutlisetsang litšupiso tse ka fetoloang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // TSHIRELETSO: Sesebelisoa sa ts'ireletso sa `IterMut` se kahare se thehiloe hobane
        // `ring` re e bopa ke selae se ke keng sa hlalosoa bakeng sa bophelo bohle '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// E khutlisa lilae tse nang le litaba tsa `VecDeque` ka tatellano.
    ///
    /// Haeba [`make_contiguous`] e ne e bitsoa pejana, likarolo tsohle tsa `VecDeque` li tla ba sekhahla sa pele ebe selae sa bobeli se tla be se se na letho.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// E khutlisa lilae tse nang le litaba tsa `VecDeque` ka tatellano.
    ///
    /// Haeba [`make_contiguous`] e ne e bitsoa pejana, likarolo tsohle tsa `VecDeque` li tla ba sekhahla sa pele ebe selae sa bobeli se tla be se se na letho.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// E khutlisa palo ea likarolo tsa `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// E khutlisa `true` haeba `VecDeque` e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// E theha iterator e koahelang sebaka se boletsoeng ho `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics haeba qalo e kholo ho feta ntlha ea ho qetela kapa haeba ntlha ea qetello e kholo ho feta bolelele ba vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Mefuta e felletseng e akaretsa litaba tsohle
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Referense e arolelanoeng eo re nang le eona ho &self e bolokiloe ho '_ ea Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// E theha iterator e koahelang mefuta e boletsoeng e ka fetohang ho `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics haeba qalo e kholo ho feta ntlha ea ho qetela kapa haeba ntlha ea qetello e kholo ho feta bolelele ba vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Mefuta e felletseng e akaretsa litaba tsohle
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // TSHIRELETSO: Sesebelisoa sa ts'ireletso sa `IterMut` se kahare se thehiloe hobane
        // `ring` re e bopa ke selae se ke keng sa hlalosoa bakeng sa bophelo bohle '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// E theha draerator e tlohang e tlosang mofuta o boletsoeng ho `VecDeque` ebe e fana ka lintho tse tlositsoeng.
    ///
    /// Tlhokomeliso 1: The range range e tlosoa le ha iterator e sa sebelisoe ho fihlela qetellong.
    ///
    /// Tlhokomeliso 2: Ha ho tsejoe hore na ho tlositsoe likarolo tse kae ho deque, haeba boleng ba `Drain` bo sa theoleloe, empa kalimo eo e nang le eona e felloa ke nako (mohlala, ka lebaka la `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba qalo e kholo ho feta ntlha ea ho qetela kapa haeba ntlha ea qetello e kholo ho feta bolelele ba vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Lenane le felletseng le hlakola litaba tsohle
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Polokeho ea memori
        //
        // Ha Drain e thehiloe ka lekhetlo la pele, deque ea mohloli e khutsufatsoa ho etsa bonnete ba hore ha ho na lisebelisoa tse sa qalisoang kapa tse tlositsoeng tse fumanehang ho hang haeba sesenyi sa Drain se ke ke sa sebetsa.
        //
        //
        // Drain e tla tsoa ho ptr::read litekanyetso tseo u lokelang ho li tlosa.
        // Ha e felile, data e setseng e tla kopitsoa hape ho koahela lesoba, mme boleng ba head/tail bo tla khutlisoa ka nepo.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Lintho tsa moreki li arotsoe likarolo tse tharo:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;T=drain_tail;h=drain_head
        //
        // Re boloka drain_tail e le self.head, le drain_head le self.head joaloka after_tail le after_head ka ho latellana ho Drain.
        // Sena se boetse se fokotsa sehlopha se sebetsang hantle hore haeba Drain e lutla, re lebetse ka litekanyetso tse ka fallisoang kamora ho qala ha drain.
        //
        //
        //        T H H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" ka makgabane kamora ho qala ha drain ho fihlela kamora hore drain e phethehe mme mosenyi oa Drain a sebetsoe.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ka bomalimabe, re theha litšupiso tse arolelanoeng ho tsoa ho `self` mona ebe re bala ho eona.
                // Ha re ngolle `self` ebile ha re boele re sebelise mokhoa o ka fetohang.
                // Kahoo sesupa se tala seo re se entseng kaholimo, bakeng sa `deque`, se lula se sebetsa.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// E hloekisa `VecDeque`, e tlosa litekanyetso tsohle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// E khutlisa `true` haeba `VecDeque` e na le ntho e lekanang le boleng bo fanoeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// E fana ka tšupiso ea ntho e ka pele, kapa `None` haeba `VecDeque` e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// E fana ka ts'upiso e ka fetoloang ho elemente e ka pele, kapa `None` haeba `VecDeque` e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// E fana ka tšupiso ea ntho ea morao, kapa `None` haeba `VecDeque` e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// E fana ka ts'upiso e ka fetoloang ho elemente e ka morao, kapa `None` haeba `VecDeque` e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// E tlosa ntho ea pele ebe ea e khutlisa, kapa `None` haeba `VecDeque` e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// E tlosa ntho ea ho qetela ho `VecDeque` ebe ea e khutlisa, kapa `None` haeba e se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// E hlophisa ntlha ho `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// E kenya karolo e ka morao ho `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Na re lokela ho nahana hore `head == 0` e bolela
        // hore `self` e ea hokahana?
        self.tail <= self.head
    }

    /// E tlosa ntho kae kapa kae ho `VecDeque` ebe ea e khutlisa, ee beha ka elemente ea pele.
    ///
    ///
    /// Sena ha se boloke tatellano, empa ke *O*(1).
    ///
    /// E khutlisa `None` haeba `index` e se na meeli.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// E tlosa ntho kae kapa kae ho `VecDeque` ebe ea e khutlisa, a e behe ka elemente ea ho qetela.
    ///
    ///
    /// Sena ha se boloke tatellano, empa ke *O*(1).
    ///
    /// E khutlisa `None` haeba `index` e se na meeli.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// O kenya ntho ho `index` kahare ho `VecDeque`, o fetisa likarolo tsohle tse nang le li-indices tse kholo ho feta kapa tse lekanang le `index` ka morao.
    ///
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Panics
    ///
    /// Panics haeba `index` e kholo ho feta bolelele ba `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Tsamaisa palo e nyane haholo ea likarolo tsa konopo ebe u kenya ntho e fanoeng
        //
        // Boholo ba len/2, lintho tse 1 li tla sisinyeha. O(min(n, n-i))
        //
        // Ho na le linyeoe tse tharo tsa mantlha:
        //  Lintho li kopane
        //      - nyeoe e ikhethang ha mohatla o le 0 Elements ha li na tsebo ebile kenyelletso e karolong ea mohatla Elements ha li na tsebo ebile kenyelletso e karolong ea hlooho
        //
        //
        // Bakeng sa e 'ngoe le e' ngoe ea tsona ho na le linyeoe tse ling tse peli:
        //  Insert e haufi le mohatla Insert e haufi le hlooho
        //
        // Senotlolo: H, self.head
        //      T, self.tail o, Element element I, Insertion element A, Element e lokelang ho ba kamora ntlha ea kenyelletso M, e supa elemente e fallisitsoe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // e ts'oanang, kenya haufi le mohatla:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // e ts'oanang, kenya haufi le mohatla le mohatla ke 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       Limilimithara

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Re se re tsamaisitse mohatla, ka hona re kopitsa feela likarolo tsa `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // e ts'oanang, kenya haufi le hlooho:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, kenya haufi le mohatla, karolo ea mohatla:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, kenya haufi le hlooho, karolo mohatla:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopitsa likarolo ho fihlela hloohong e ncha
                    self.copy(1, 0, self.head);

                    // kopitsa karolo ea ho qetela sebakeng se se nang letho ka tlase ho buffer
                    self.copy(0, self.cap() - 1, 1);

                    // tsamaisa likarolo ho tloha idx ho ea pele ho ea pele ho sa kenyelelloe ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert e haufi le mohatla, karolo ea hlooho, mme e sebakeng sa index zero ho buffer ea kahare:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopitsa likarolo ho fihlela mohatleng o mocha
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopitsa karolo ea ho qetela sebakeng se se nang letho ka tlase ho buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, kenya haufi le mohatla, hlooho karolo:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMMM

                    // kopitsa likarolo ho fihlela mohatleng o mocha
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopitsa karolo ea ho qetela sebakeng se se nang letho ka tlase ho buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // tsamaisa lintho ho tloha idx-1 ho ea pele ntle le ho kenyelletsa ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, kenya haufi le hlooho, karolo ea hlooho:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // tail e kanna ea fetoloa kahoo re hloka ho e bala hape
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// E tlosa le ho khutlisa element ho `index` ho `VecDeque`.
    /// Qetellong efe kapa efe e haufinyane le sebaka sa ho tlosa e tla fallisetsoa sebaka, 'me likarolo tsohle tse amehileng li tla fallisetsoa maemong a macha.
    ///
    /// E khutlisa `None` haeba `index` e se na meeli.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Ho na le linyeoe tse tharo tsa mantlha:
        //  Lintho li kopane Lintlha ha li na tsebo ebile ho tlosoa ho karolong ea mohatla Elements ha li na tsebo ebile ho tlosoa ho karolong ea hlooho
        //
        //      - nyeoe e ikhethileng ha likarolo li le ngata, empa self.head =0
        //
        // Bakeng sa e 'ngoe le e' ngoe ea tsona ho na le linyeoe tse ling tse peli:
        //  Insert e haufi le mohatla Insert e haufi le hlooho
        //
        // Senotlolo: H, self.head
        //      T, self.tail o, Element element x, Element e tšoaetsoeng ho tlosoa R, E bonts'a ntho e tlosoang M, e supa element e fallisitsoe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // e ts'oanang, tlosa haufi le mohatla:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // e ts'oanang, tlosa haufi le hlooho:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, tlosa haufi le mohatla, karolo ea mohatla:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontigigue, tlosa haufi le hlooho, karolo ea hlooho:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, tlosa haufi le hlooho, karolo ea mohatla:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // kapa quasi-discontiguous, tlosa haufi le hlooho, karolo ea mohatla:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // thala dikarolwana karolong ya mohatla
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // E thibela ho phalla.
                    if self.head != 0 {
                        // kopitsa elemente ea pele sebakeng se se nang letho
                        self.copy(self.cap() - 1, 0, 1);

                        // suthisetsa likarolo karolong ea hlooho morao
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontigigue, tlosa haufi le mohatla, karolo ea hlooho:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // hula likarolo ho fihlela idx
                    self.copy(1, 0, idx);

                    // kopitsa elemente ea ho qetela sebakeng se se nang letho
                    self.copy(0, self.cap() - 1, 1);

                    // tsamaisa lintho ho tloha mohatleng ho isa qetellong ho ea pele, ntle le ea ho qetela
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// E arola `VecDeque` habeli ho index e fanoeng.
    ///
    /// E khutlisa `VecDeque` e sa tsoa fuoa.
    /// `self` e na le likarolo `[0, at)`, 'me `VecDeque` e khutlisitsoeng e na le likarolo `[at, len)`.
    ///
    /// Hlokomela hore matla a `self` ha a fetohe.
    ///
    /// Element ho index 0 ke bokapele ba lethathamo.
    ///
    /// # Panics
    ///
    /// Panics haeba `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` e lutse karolong ea pele.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // nka feela halofo eohle ea bobeli.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` e lutse halofong ea bobeli, re hloka ho nahana ka lintho tseo re li tlotseng halofo ea pele.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Hloekisa moo lipheletsong tsa li-buffers li leng teng
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// E tsamaisa likarolo tsohle tsa `other` ho `self`, e siea `other` e se na letho.
    ///
    /// # Panics
    ///
    /// Panics haeba palo e ncha ea likarolo ka boeona e feta `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// E boloka feela likarolo tse boletsoeng ke lereho.
    ///
    /// Ka mantsoe a mang, tlosa likarolo tsohle `e` hoo `f(&e)` e khutlang e fosahetse.
    /// Mokhoa ona o sebetsa sebakeng sa ona, o etela karolo ka 'ngoe hantle hang feela ka tatellano ea mantlha, mme o boloka tatellano ea likarolo tse bolokiloeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Taelo e nepahetseng e kanna ea ba ea bohlokoa bakeng sa ho latela boemo ba kantle, joalo ka index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Sena se kanna sa panic kapa sa ntša mpa
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Pheta boholo ba buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// E fetola `VecDeque` sebakeng sa eona e le hore `len()` e lekane le `new_len`, ekaba ka ho tlosa likarolo tse fetelletseng ka morao kapa ka ho kenya lisebelisoa tse hlahisitsoeng ka ho letsetsa `generator` ka morao.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// E hlophisa bocha polokelo ea kahare ea mokhabiso ona hore e be selae se le seng se kopaneng, se ntoo khutlisoa.
    ///
    /// Mokhoa ona ha o abele ebile ha o fetole tatellano ea likarolo tse kentsoeng.Ha e khutlisa selae se ka feto-fetohang, sena se ka sebelisoa ho hlophisa terata.
    ///
    /// Hang ha polokelo ea kahare e se e kopane, mekhoa ea [`as_slices`] le [`as_mut_slices`] e tla khutlisa litaba tsohle tsa `VecDeque` selae se le seng.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ho hlophisa litaba tsa terata.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ho hlopha mabotho
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ho e hlopha ka tatellano e khutlelang morao
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ho fumana mokhoa o sa fetoheng oa selae se kopaneng.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // Joale re ka kholiseha hore `slice` e na le likarolo tsohle tsa moreki, ha re ntse re na le phihlello e sa fetoheng ea `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ho na le sebaka se lekaneng sa ho kopitsa mohatla ka nako e le 'ngoe, sena se bolela hore re qala ho sututsa hlooho ho ea morao, ebe re kopitsa mohatla sebakeng se nepahetseng.
            //
            //
            // ho tloha: DEFGH .... ABC
            // ho: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Hajoale ha re nahane .... ABCDEFGH
            // ho ts'oaroa hobane `head` e ka ba `0` ntlheng ena.
            // Ha re ntse re batla ho fetola sena ha se ntho e nyane kaha libaka tse 'maloa li lebelletse hore `is_contiguous` e bolele hore re ka arola feela re sebelisa `buf[tail..head]`.
            //
            //

            // ho na le sebaka se lekaneng sa ho kopitsa hlooho hang, sena se bolela hore re qala ka ho fetisetsa mohatla pele, ebe re kopitsa hlooho ho ea boemong bo nepahetseng.
            //
            //
            // ho tloha: FGH .... ABCDE
            // ho: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // mahala e nyane ho feta hlooho le mohatla ka bobeli, sena se bolela hore re tlameha ho butle butle "swap" mohatla le hlooho.
            //
            //
            // ho tloha ho: EFGHI ... ABCD kapa HIJK.ABCDEFG
            // ho: ABCDEFGHI ... kapa ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Bothata bo akaretsang bo shebahala joalo ka GHIJKLM ... ABCDEF, pele ho swaps ABCDEFM ... GHIJKL, kamora ho feta ha 1 swaps ABCDEFGHIJM ... KL, swap ho fihlela edge e leqeleng e fihla lebenkeleng la tempele.
                //                  - joale qala bocha algorithm ka lebenkele le lecha la (smaller) Ka linako tse ling lebenkele la tempele le fihlelloa ha edge e nepahetseng e le qetellong ea buffer, sena se bolela hore re fihlile ka tatellano e nepahetseng ka li-swaps tse fokolang!
                //
                // E.g
                // EF..ABCD ABCDEF .., kamora ho chencha tse nne feela
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// E fetola libaka tse emang habeli `mid` ka lehlakoreng le letšehali.
    ///
    /// Equivalently,
    /// - E fetisetsa ntho ea `mid` boemong ba pele.
    /// - E khetha lintho tsa pele tsa `mid` ebe e li sutumetsa ho fihlela qetellong.
    /// - E fetola libaka tsa `len() - mid` ka ho le letona.
    ///
    /// # Panics
    ///
    /// Haeba `mid` e kholo ho feta `len()`.
    /// Hlokomela hore `mid == len()` e etsa _not_ panic mme ke chenchana e sa sebetseng.
    ///
    /// # Complexity
    ///
    /// E nka nako ea `*O*(min(mid, len() - mid))` mme ha ho na sebaka se seng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// E fetola libaka tse emang habeli `k` ka lehlakoreng le letona.
    ///
    /// Equivalently,
    /// - E fetisetsa ntho ea pele boemong ba `k`.
    /// - Pops lintho tsa ho qetela tsa `k` ebe o li sutumelletsa ka pele.
    /// - E fetola libaka tsa `len() - k` ka ho le letšehali.
    ///
    /// # Panics
    ///
    /// Haeba `k` e kholo ho feta `len()`.
    /// Hlokomela hore `k == len()` e etsa _not_ panic mme ke chenchana e sa sebetseng.
    ///
    /// # Complexity
    ///
    /// E nka nako ea `*O*(min(k, len() - k))` mme ha ho na sebaka se seng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // TSHIRELETSO: mekgwa e mmedi e latelang e hloka hore palo ya potoloho
    // e be ka tlase ho halofo ea bolelele ba mokete.
    //
    // `wrap_copy` e hloka hore `min(x, cap() - x) + copy_len <= cap()`, empa ho feta `min` ha ho mohla e fetang halofo ea bokhoni, ho sa tsotelehe x, ka hona ho utloahala ho letsetsa mona hobane re letsetsa ka ho hong ho ka tlase ho halofo ea bolelele, bo sa phahameleng halofo ea bokhoni.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary e phenyekolla `VecDeque` e hlophisitsoeng bakeng sa ntho e fanoeng.
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.
    /// Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'ne.
    /// Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Haeba u batla ho kenya ntho ho `VecDeque` e hlophisitsoeng, ha u ntse u boloka tatellano ea mofuta:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary e batlisisa `VecDeque` e hlophisitsoeng ka ts'ebetso ea papiso.
    ///
    /// Mosebetsi oa papiso o lokela ho kenya tšebetsong tatellano e lumellanang le mofuta oa mofuta oa `VecDeque`, e khutlisetse khoutu ea odara e bonts'ang hore na ngangisano ea eona ke `Less`, `Equal` kapa `Greater` ho feta sepheo se lebelletsoeng.
    ///
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'ne.Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary e batlisisa `VecDeque` e hlophisitsoeng ka ts'ebetso ea senotlolo.
    ///
    /// E nka hore `VecDeque` e hlophisitsoe ka senotlolo, ka mohlala le [`make_contiguous().sort_by_key()`](#method.make_contiguous) e sebelisa ts'ebetso e tšoanang ea senotlolo.
    ///
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.
    /// Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'nè selae sa lipara tse hlophiloeng ke likarolo tsa tsona tsa bobeli.
    /// Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// E fetola `VecDeque` sebakeng sa eona e le hore `len()` e lekane le new_len, ekaba ka ho tlosa likarolo tse fetelletseng ka morao kapa ka ho kenya li-clone tsa `value` ka morao.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// E khutlisetsa index ho buffer ea mantlha bakeng sa index ea likarolo tse fanoeng.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // boholo bo lula bo le matla a 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Bala palo ea likarolo tse setseng hore li baloe ka har'a buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // boholo bo lula bo le matla a 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // E lula e aroloa ka likarolo tse tharo, mohlala: self: [a b c|d e f] e ngoe: [0 1 2 3|4 5] ka pele=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Ha ho khonehe ho sebelisa Hash::hash_slice ho lilae tse khutlisitsoeng ke as_slices mokhoa kaha bolelele ba tsona bo ka fapana ka mekhahlelo e meng e ts'oanang.
        //
        //
        // Hasher e tiisa feela ho lekana bakeng sa mehala e ts'oanang ea mehala ho mekhoa ea eona.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// E sebelisa `VecDeque` ho iterator e ka pele-ea-morao e hlahisang likarolo ka boleng.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Mosebetsi ona e lokela ho ba boitšoaro bo lekanang le:
        //
        //      bakeng sa ntlha ho iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Fetola [`Vec<T>`] hore e be [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Sena se qoba ho fallisoa moo ho ka khonehang, empa maemo a seo a thata, 'me a ka fetoha, ka hona ha ea lokela ho ts'epahloa ntle le haeba `Vec<T>` e tsoa `From<VecDeque<T>>` mme e sa abeloa hape.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Ha ho na kabo ea 'nete bakeng sa li-ZST ho tšoenyeha ka boholo, empa `VecDeque` ha e khone ho sebetsana le bolelele bo lekana le `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Re hloka ho etsa boholo haeba matla e se matla a mabeli, a manyane haholo kapa a sena sebaka se le seng sa mahala.
            // Re etsa sena ha e ntse e le `Vec` hore lintho li theohe ho panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Fetola [`VecDeque<T>`] hore e be [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Sena ha se hloke ho abeloa hape, empa se hloka ho etsa motsamao oa data oa *O*(*n*) haeba buffer e chitja e se qalong ea kabo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Enoa ke *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // E hloka ho hlophisoa bocha.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}