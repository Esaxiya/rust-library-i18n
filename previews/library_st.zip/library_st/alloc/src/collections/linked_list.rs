//! Lenane le hokahaneng habeli le linomoro tse nang le lona.
//!
//! `LinkedList` e lumella ho sutumetsa le ho hlahisa likarolo maemong afe kapa afe ka nako e sa fetoheng.
//!
//! NOTE: Ho batla ho le molemo kamehla ho sebelisa [`Vec`] kapa [`VecDeque`] hobane lijana tse nang le mefuta e mengata hangata li potlakile, li boloka mohopolo hantle ebile li sebelisa hamolemo cache ea CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Lenane le hokahaneng habeli le linomoro tse nang le lona.
///
/// `LinkedList` e lumella ho sutumetsa le ho hlahisa likarolo maemong afe kapa afe ka nako e sa fetoheng.
///
/// NOTE: Ho batla ho le molemo kamehla ho sebelisa `Vec` kapa `VecDeque` hobane lijana tse nang le mefuta e mengata hangata li potlakile, li boloka mohopolo hantle ebile li sebelisa hamolemo cache ea CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Iterator holim'a likarolo tsa `LinkedList`.
///
/// `struct` ena e entsoe ke [`LinkedList::iter()`].
/// Bona litokomane tsa eona bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Tlosa molemong oa `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Seterata se ka fetohang holim'a likarolo tsa `LinkedList`.
///
/// `struct` ena e entsoe ke [`LinkedList::iter_mut()`].
/// Bona litokomane tsa eona bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // Ha re na lethathamo lena kaofela mona, litšupiso tsa node ea `element` li fanoe ke iterator!Kahoo hlokomela ha u sebelisa sena;mekhoa e bitsitsoeng e tlameha ho hlokomela hore ho ka ba le litsupa tse khethollang `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Iterator ea ho ba le thepa ea `LinkedList`.
///
/// `struct` ena e entsoe ka mokhoa oa [`into_iter`] ho [`LinkedList`] (e fanoeng ke `IntoIterator` trait).
/// Bona litokomane tsa eona bakeng sa tse ling.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// mekhoa ea lekunutu
impl<T> LinkedList<T> {
    /// E eketsa node e fanoeng ka pele ho lenane.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ka feto-fetohang ho li-node tsohle, ho boloka bonnete ba lits'oants'o tsa aliasing ho `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Ha e thehe litšupiso tse ncha tse ka fetoloang tsa (unique!) tse fetang `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// E tlosa le ho khutlisa node e ka pele ho lenane.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ka feto-fetohang ho li-node tsohle, ho boloka bonnete ba lits'oants'o tsa aliasing ho `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Ha e thehe litšupiso tse ncha tse ka fetoloang tsa (unique!) tse fetang `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// E eketsa node e fanoeng ka morao lenaneng.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ka feto-fetohang ho li-node tsohle, ho boloka bonnete ba lits'oants'o tsa aliasing ho `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Ha e thehe litšupiso tse ncha tse ka fetoloang tsa (unique!) tse fetang `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// E tlosa le ho khutlisa node ka morao lenaneng.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ka feto-fetohang ho li-node tsohle, ho boloka bonnete ba lits'oants'o tsa aliasing ho `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Ha e thehe litšupiso tse ncha tse ka fetoloang tsa (unique!) tse fetang `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// E hokahanya node e boletsoeng lenaneng la hajoale.
    ///
    /// Tlhokomeliso: sena se ke ke sa netefatsa hore node e fanoeng ke ea lenane la hajoale.
    ///
    /// Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ka fetohang ho `element`, ho boloka bonnete ba litsupa tsa aliasing.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ena ke ea rona hona joale, re ka theha &mut.

        // Ha e thehe litšupiso tse ncha tse ka fetoloang tsa (unique!) tse fetang `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // node ena ke hlooho ea hlooho
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // node ena ke noute ea mohatla
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Splices letoto la li-node lipakeng tsa li-node tse peli tse teng.
    ///
    /// Tlhokomeliso: sena se ke ke sa netefatsa hore node e fanoeng ke ea mathathamo a mabeli a seng a ntse a le teng.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Mokhoa ona o ela hloko hore o se hlahise litšupiso tse ngata tse ka fetohang ho li-node tsohle ka nako e le ngoe, ho boloka bonnete ba litsupa tsa aliasing ho `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// E tlosa li-node tsohle ho tsoa lenaneng le hokahaneng joalo ka letoto la li-node.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Node e arohaneng ke hlooho e ncha ea hlooho ea karolo ea bobeli
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Lokisa hlooho ptr ea karolo ea bobeli
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Node e arohaneng ke node e ncha ea mohatla ea karolo ea pele mme e na le hlooho ea karolo ea bobeli.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Lokisa mohatla ptr oa karolo ea pele
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// E etsa `LinkedList<T>` e se nang letho.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// E etsa `LinkedList` e se nang letho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// E tsamaisa likarolo tsohle ho tloha `other` ho isa qetellong ea lenane.
    ///
    /// Sena se sebelisa li-node tsohle ho tloha `other` ebe se li isa ho `self`.
    /// Kamora ts'ebetso ena, `other` ha e na letho.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1) le memori ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` ho lokile mona hobane re na le phihlello e ikhethang ea lenane lena ka bobeli.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// E tsamaisa likarolo tsohle ho tloha `other` ho ea qalong ea lenane.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` ho lokile mona hobane re na le phihlello e ikhethang ea lenane lena ka bobeli.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// E fana ka sehlahlobi sa pele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// E fana ka sehatisi sa pele se nang le litšupiso tse ka fetoloang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// E fana ka labeler ka karolo ea pele.
    ///
    /// Sebele se supa "ghost" eo e seng element haeba lenane le se na letho.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// E fana ka lesupi ka ts'ebetso ea ho hlophisa karolong e ka pele.
    ///
    /// Sebele se supa "ghost" eo e seng element haeba lenane le se na letho.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// E fana ka labeler ka morao element.
    ///
    /// Sebele se supa "ghost" eo e seng element haeba lenane le se na letho.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// E fana ka lesupi le ts'ebetso ea ho hlophisa karolong ea morao.
    ///
    /// Sebele se supa "ghost" eo e seng element haeba lenane le se na letho.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// E khutlisa `true` haeba `LinkedList` e se na letho.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// E khutlisa bolelele ba `LinkedList`.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// E tlosa likarolo tsohle ho `LinkedList`.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// E khutlisa `true` haeba `LinkedList` e na le ntho e lekanang le boleng bo fanoeng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// E fana ka tšupiso ea ntho e ka pele, kapa `None` haeba lenane le se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// E fana ka ts'upiso e ka fetoloang ho elemente e ka pele, kapa `None` haeba lenane le se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// E fana ka tšupiso ea karolo ea morao, kapa `None` haeba lenane le se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// E fana ka ts'upiso e ka fetoloang ho karolo ea morao, kapa `None` haeba lenane le se na letho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// E eketsa ntlha pele lenaneng.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// E tlosa ntho ea pele ebe oa e khutlisa, kapa `None` haeba lenane le se na letho.
    ///
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// E kenya karolo e ka morao lenaneng.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// E tlosa ntho ea ho qetela lenaneng ebe oa e khutlisa, kapa `None` haeba e se na letho.
    ///
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// E arola lethathamo ka bobeli ho index e fanoeng.
    /// E khutlisa tsohle ka mora index e fanoeng, ho kenyeletsoa index.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics haeba `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Ka tlase, re ea holimo ho `n-1`th node, ekaba ho tloha qalong kapa qetellong, ho latela hore na ke efe e tla potlaka.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // sebakeng sa ho tlola re sebelisa .skip() (e hlahisang sebopeho se secha), re tlola ka letsoho hore re tsebe ho fihlela tšimo ea hlooho ntle le ho latela lintlha tsa ts'ebetsong tsa Skip
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // betere ho qala qetellong
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// E tlosa karolo ho index e fanoeng ebe oa e khutlisa.
    ///
    /// Ts'ebetso ena e lokela ho sebetsoa ka nako ea *O*(*n*).
    ///
    /// # Panics
    /// Panics haeba>> len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Ka tlase, re lekola node ho index e fanoeng, ekaba ho tloha qalong kapa qetellong, ho latela hore na ke efe e tla potlaka.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// E etsa iterator e sebelisang ho koala ho fumana hore na ho na le ntho e lokelang ho tlosoa.
    ///
    /// Haeba ho koaloa ho khutla ka nnete, elemente e tla tlosoa ebe e fanoa.
    /// Haeba koalo e khutla e le leshano, elemente e tla lula lethathamong mme e ke ke ea hlahisoa ke mohlahlobi.
    ///
    /// Hlokomela hore `drain_filter` eu lumella ho fetola ntho e ngoe le e ngoe ha ho koaloa sefahleho, ho sa tsotelehe hore na u khetha ho e boloka kapa ho e tlosa.
    ///
    ///
    /// # Examples
    ///
    /// Ho arola lethathamo le leng le le leng le mathata, ho sebelisa lenane la mantlha:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // qoba litaba tsa kalimo.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Tsoela pele ka mokhoa o tšoanang oo re o etsang ka tlase.Sena se sebetsa feela ha mosenyi a tšohile.
                // Haeba e 'ngoe panics sena se tla ntša mpa.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // U hloka bophelo bohle bo sa lefelloeng ho fumana 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // U hloka bophelo bohle bo sa lefelloeng ho fumana 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // U hloka bophelo bohle bo sa lefelloeng ho fumana 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // U hloka bophelo bohle bo sa lefelloeng ho fumana 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Lenaneo le fetang `LinkedList`.
///
/// `Cursor` e tšoana le iterator, ntle le hore e ka batla ho khutlela morao le ho tsoa ka bolokolohi.
///
/// Liroholi li lula li phomola lipakeng tsa likarolo tse peli tse lenaneng, le index ka tsela e utloahalang e chitja.
/// Ho amohela sena, ho na le "ghost" e seng element e hlahisang `None` lipakeng tsa hlooho le mohatla oa lenane.
///
///
/// Ha e etsoa, li-cursor li qala kapele ho lenane, kapa "ghost" e seng element haeba lenane le se na letho.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Sebopeho sa `LinkedList` se nang le ts'ebetso ea ho hlophisa.
///
/// `Cursor` e tšoana le iterator, ntle le hore e ka batla ho ea koana le koana ka bolokolohi, 'me e ka fetola lenane ka mokhoa o sireletsehileng nakong ea iteration.
/// Lebaka ke hobane nako ea bophelo ea litšupiso tse hlahisitsoeng e hokahane le nako ea eona ea bophelo, ho fapana le lethathamo la mantlha feela.
/// Sena se bolela hore li-cursor ha li khone ho hlahisa likarolo tse ngata ka nako e le ngoe.
///
/// Liroholi li lula li phomola lipakeng tsa likarolo tse peli tse lenaneng, le index ka tsela e utloahalang e chitja.
/// Ho amohela sena, ho na le "ghost" e seng element e hlahisang `None` lipakeng tsa hlooho le mohatla oa lenane.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// E khutlisa index ea boemo ba sekhoele kahare ho `LinkedList`.
    ///
    /// Sena se khutlisa `None` haeba haele moo sekhutlo hona joale se supa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// E fetisetsa sekhutlo ho karolo e latelang ea `LinkedList`.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, sena se tla se fetisetsa karolong ea pele ea `LinkedList`.
    /// Haeba e supa karolo ea ho qetela ea `LinkedList` joale e tla e fetisetsa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Re ne re sena element ea hajoale;sekhutlo se ne se lutse maemong a qalang Ntho e latelang e lokela ho ba hlooho ea lenane
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Re bile le elemente e fetileng, kahoo ha re eeng ho e latelang
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// E tsamaisa sekhutlo ho karolo ea pejana ea `LinkedList`.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, sena se tla se fetisetsa karolong ea ho qetela ea `LinkedList`.
    /// Haeba e supa karolo ea pele ea `LinkedList` joale e tla e fetisetsa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ha ho na hona joale.Re qalong ea lenane.Inehela Haho le emong ho fihlela qetellong.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Eba le selelekela.E hlahise 'me u ee ho elemente e fetileng.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// E khutlisetsa litšupiso ho elemente eo sethopo se supang ho sona hajoale.
    ///
    /// Sena se khutlisa `None` haeba haele moo sekhutlo hona joale se supa ho "ghost" eo e seng element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// E khutlisetsa ts'upiso ho elemente e latelang.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale sena se khutlisa karolo ea pele ea `LinkedList`.
    /// Haeba e supa karolo ea ho qetela ea `LinkedList` joale sena se khutlisa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// E khutlisetsa tšupiso ho elemente e fetileng.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale sena se khutlisa karolo ea ho qetela ea `LinkedList`.
    /// Haeba e supa karolo ea pele ea `LinkedList` joale sena se khutlisa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// E khutlisa index ea boemo ba sekhoele kahare ho `LinkedList`.
    ///
    /// Sena se khutlisa `None` haeba haele moo sekhutlo hona joale se supa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// E fetisetsa sekhutlo ho karolo e latelang ea `LinkedList`.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, sena se tla se fetisetsa karolong ea pele ea `LinkedList`.
    /// Haeba e supa karolo ea ho qetela ea `LinkedList` joale e tla e fetisetsa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // Re ne re sena element ea hajoale;sekhutlo se ne se lutse maemong a qalang Ntho e latelang e lokela ho ba hlooho ea lenane
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // Re bile le elemente e fetileng, kahoo ha re eeng ho e latelang
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// E tsamaisa sekhutlo ho karolo ea pejana ea `LinkedList`.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, sena se tla se fetisetsa karolong ea ho qetela ea `LinkedList`.
    /// Haeba e supa karolo ea pele ea `LinkedList` joale e tla e fetisetsa ho "ghost" eo e seng element.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ha ho na hona joale.Re qalong ea lenane.Inehela Haho le emong ho fihlela qetellong.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Eba le selelekela.E hlahise 'me u ee ho elemente e fetileng.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// E khutlisetsa litšupiso ho elemente eo sethopo se supang ho sona hajoale.
    ///
    /// Sena se khutlisa `None` haeba haele moo sekhutlo hona joale se supa ho "ghost" eo e seng element.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// E khutlisetsa ts'upiso ho elemente e latelang.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale sena se khutlisa karolo ea pele ea `LinkedList`.
    /// Haeba e supa karolo ea ho qetela ea `LinkedList` joale sena se khutlisa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// E khutlisetsa tšupiso ho elemente e fetileng.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale sena se khutlisa karolo ea ho qetela ea `LinkedList`.
    /// Haeba e supa karolo ea pele ea `LinkedList` joale sena se khutlisa `None`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// E khutlisa sekhutlo se balang feela se supang ho elemente ea hona joale.
    ///
    /// Nako ea bophelo ea `Cursor` e khutlisitsoeng e tlamahane le ea `CursorMut`, ho bolelang hore e ke ke ea phela ho feta `CursorMut` le hore `CursorMut` e hoamisitsoe bakeng sa bophelo bohle ba `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Hona joale lenane la ho hlophisa mesebetsi

impl<'a, T> CursorMut<'a, T> {
    /// E kenya ntho e ncha ho `LinkedList` kamora ea hajoale.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, elemente e ncha e kentsoe kapele ho `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Lenane la "ghost" e seng la element le fetohile.
                self.index = self.list.len;
            }
        }
    }

    /// E kenya ntho e ncha ho `LinkedList` pele ho ea hajoale.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, elemente e ncha e kentsoe qetellong ea `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// E tlosa karolo ea hajoale ho `LinkedList`.
    ///
    /// The element e tlositsoeng ea khutlisoa, 'me serethe se tlosoa ho supa ntho e latelang ho `LinkedList`.
    ///
    ///
    /// Haeba mots'oants'o ha joale o supa "ghost" eo e seng element, ha ho na elemente e tlosoang ebe `None` ea khutlisoa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// E tlosa ntho ea hona joale ho `LinkedList` ntle le ho tsamaisa node ea lenane.
    ///
    /// Node e tlositsoeng e khutlisoa e le `LinkedList` e ncha e nang le node ena feela.
    /// Sebopeho se tsamaisoa ho supa ntlha e latelang ho `LinkedList` ea joale.
    ///
    /// Haeba mots'oants'o ha joale o supa "ghost" eo e seng element, ha ho na elemente e tlosoang ebe `None` ea khutlisoa.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// E kenya likarolo ho tsoa ho `LinkedList` e fuoeng kamora ea hajoale.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, likaroloana tse ncha li kentsoe qalong ea `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Lenane la "ghost" e seng la element le fetohile.
                self.index = self.list.len;
            }
        }
    }

    /// E kenya likarolo ho tsoa ho `LinkedList` e fanoeng pele ho ena ea hajoale.
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, lintho tse ncha li tla kenngoa qetellong ea `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// E arola lenane ka makhetlo a mabeli kamora 'elemente ea hajoale.
    /// Sena se tla khutlisa lethathamo le lecha le nang le ntho e ngoe le e ngoe kamora khetsi, ka lenane la mantlha le bolokileng tsohle pele.
    ///
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale litaba tsohle tsa `LinkedList` lia sisinyeha.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Index ea "ghost" e seng ea element e fetohile ho 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// E arola lethathamo ka likarolo tse peli pele ho ntlha ea hona joale.
    /// Sena se tla khutlisa lethathamo le lecha le nang le ntho e ngoe le e ngoe ka pele ho sekhutlo, ka lenane la mantlha le bolokang tsohle kamora moo.
    ///
    ///
    /// Haeba sesupisi se supa ho "ghost" eo e seng element, joale litaba tsohle tsa `LinkedList` lia sisinyeha.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Sesebelisoa se hlahisitsoeng ka ho letsetsa `drain_filter` ho LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` ho lokile ka ho qhekella litšupiso tsa `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// E sebelisa lenane ho hlahisa likarolo tsa tlhahiso ea iterator ka boleng.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Netefatsa hore `LinkedList` le li-iterator tsa eona tsa ho bala feela li khethile maemo a mofuta oa tsona.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}