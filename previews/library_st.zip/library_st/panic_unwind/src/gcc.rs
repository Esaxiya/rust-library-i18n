//! Ts'ebetsong ea panics e tšehelitsoeng ke libgcc/libunwind (ka mokhoa o mong).
//!
//! Bakeng sa semelo sa ho sebetsana ka mokhoa o ikhethileng le ho ts'oara ha o kotulla ka kopo sheba "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) le litokomane tse hokahantsoeng le eona.
//! Tsena ke li ballo tse ntle:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Kakaretso e khuts'oane
//!
//! Ts'ebetso e ikhethang e etsahala ka mekhahlelo e 'meli: mohato oa ho batla le mohato oa tlhoekiso.
//!
//! Likarolong tsena ka bobeli mekhahlelo e sa utluoang e tsoang holimo ho ea tlase e sebelisa tlhaiso-leseling e tsoang mekotong ea likarolo tsa li-module tsa hona joale ("module" mona e bua ka module ea OS, ke hore, laeborari e ka sebetsoang kapa e matla).
//!
//!
//! Bakeng sa foreimi e ngoe le e ngoe ea pokello, e kopa "personality routine" e amanang le eona, eo aterese ea eona e bolokiloeng karolong ea leseli la ho phutholoha.
//!
//! Mokhahlelong oa ho batla, mosebetsi oa tloaelo ea botho ke ho lekola ntho e lahleloang ntle le ho nka qeto ea hore na e lokela ho ts'oaroa setulong seo.Hang ha foreimi ea motsamaisi e se e fumanoe, karolo ea tlhoekiso ea qala.
//!
//! Mokhahlelong oa ho hloekisa, motho ea sa sebetseng o kopa mokhoa o mong le o mong oa botho hape.
//! Lekhetlong lena e etsa qeto ea hore na ke khoutu efe (haeba e le teng) ea ho hloekisa e hlokang ho sebetsoa bakeng sa foreimi ea hajoale ea stack.Haeba ho joalo, taolo e fetisetsoa ho branch e khethehileng 'meleng oa ts'ebetso, "landing pad", e bitsang basenyi, e lokollang mohopolo, jj.
//! Qetellong ea sethala sa ho lula, taolo e fetisetsoa ho e ts'oanelang le ho phomola.
//!
//! Hang ha pokello e se e sa theoleloa boemong ba foreimi ea motsamaisi, ho phomola ho emisa mme mokhoa oa ho qetela oa botho o fetisetsa taolo ho block block.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Sekhetho sa sehlopha se ikhethileng sa Rust.
// Sena se sebelisoa ke litloaelo tsa botho ho bona hore na mokhelo o lahliloe ke nako ea bona ea ho matha.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-morekisi, puo
    0x4d4f5a_00_52555354
}

// Li-ID tsa ngoliso li tlositsoe ho XLUMX ea LLVM le TargetLowering::getExceptionSelectorRegister() bakeng sa meralo e meng le e meng, ebe li etsoa 'mapa ho linomoro tsa ngoliso ea DWARF ka litafole tsa litlhaloso<arch>RegisterInfo.td, batla "DwarfRegNum").
//
// Bona hape http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Khoutu e latelang e ipapisitse le litloaelo tsa botho ba GCC's C le C++ .Bakeng sa litšupiso, bona:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Tloaelo ea botho ba EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS e sebelisa mokhoa o ikhethileng ho fapana le moo e sebelisang SjLj e phomotse.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Lits'oants'o tse morao tsa ARM li tla letsetsa tloaelo ea semelo ka state==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Maemong ao re batla ho tsoelapele ho notlolla mothapo, ho seng joalo mekokotlo eohle ea rona e ka fella ka __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Sekhahla sa DWARF se nka hore_Unwind_Context e ts'oere lintho tse kang ts'ebetso le lits'oants'o tsa LSDA, leha ho le joalo ARM EHABI e li beha nthong e ikhethileng.
            // Ho boloka lipontšo tsa mesebetsi e kang _Unwind_GetLanguageSpecificData(), e nkang feela sesupi sa moelelo, litloaelo tsa botho tsa GCC li hlakisa sesupa ho khetholla_boko moelelong, ho sebelisoa sebaka se boloketsoeng "scratch register" (r12) ea ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Mokhoa o nang le melao-motheo e mengata e tla ba ho fana ka tlhaloso e felletseng ea ARM's_Unwind_Context ho libound tsa rona tsa libunwind le ho lata data e hlokahalang ho tloha moo ka kotloloho, ho feta mesebetsi ea ts'ebelisano ea DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI e hloka tloaelo ea botho ho nchafatsa boleng ba SP ho cache ea mokoallo ea ntho e ikhethileng.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Ho ARM EHABI tloaelo ea botho e ikarabella bakeng sa ho notlolla foreimi e le 'ngoe pele e khutla (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // e hlalosoa ka libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Tloaelo ea boits'oaro, e sebelisoang ka kotloloho ho liphofu tse ngata le ka kotloloho ho Windows x86_64 ka SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Ho liphofu tsa x86_64 MinGW, sesebelisoa sa ho phomola ke SEH leha ho le joalo data e sa phutholohang (aka LSDA) e sebelisa kh'outu e lumellanang ea GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Tloaelo ea botho bakeng sa lipheo tsa rona tse ngata.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Aterese ea ho khutla e supa 1 byte e fetileng taelo ea mohala, e ka bang sebakeng se latelang sa IP tafoleng ea LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Foreime ngoliso ea leseli la ho phutholoha
//
// Setšoantšo se seng le se seng sa module se na le karolo ea leseli la ho phutholoha (hangata ".eh_frame").Ha module e le loaded/unloaded ts'ebetsong, ts'ehetso e tlameha ho tsebisoa ka sebaka sa karolo ena mohopolong.Mekhoa ea ho fihlela seo e fapana ka sethala.
// Ho tse ling (mohlala, Linux), unwinder a ka iphumanela likarolo tsa leseli ka boeona (ka ho bala ka mokhoa o matla li-module tse jariloeng hajoale ka dl_iterate_phdr() API and finding their ".eh_frame" sections); Ba bang, joalo ka Windows, ba hloka li-module ho ngolisa likarolo tsa bona tsa leseli ka tsela e sa sebetseng ka API e sa ts'oaneng.
//
//
// Mojulu ona o hlalosa matšoao a mabeli a boletsoeng mme a bitsoa ho tloha rsbegin.rs ho ngolisa tlhaiso-leseling ea rona ka nako ea ho sebetsa ea GCC.
// Ts'ebetsong ea ho bokellana ha li-stack ke (hajoale) e fetiselitsoeng ho libgcc_eh, leha ho le joalo Rust crates e sebelisa lintlha tsena tse kenang tsa Rust ho qoba likhohlano tse ka bang teng le nako efe kapa efe ea GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}