//! Windows SEH
//!
//! Ho Windows (hajoale e ho MSVC feela), mokhoa o ikhethileng oa ho sebetsana le mekhahlelo ke Structured Exception Handling (SEH).
//! Sena se fapane hole le ho sebetsana le mekhelo e thehiloeng ho Dwarf (mohlala, li-platform life tse ling tsa unix li sebelisa) ho latela basebetsi ba likhokahanyo, ka hona LLVM e hlokahala hore e be le tšehetso e ngata bakeng sa SEH.
//!
//! Ka bokhutšoanyane, se etsahalang mona ke:
//!
//! 1. Mosebetsi oa `panic` o bitsa mosebetsi o tloaelehileng oa Windows `_CxxThrowException` ho lahlela C++ -joalo ka mokhelo, ho baka ts'ebetso ea ho phomola.
//! 2.
//! Lisebelisoa tsohle tsa ho lisa tse hlahisitsoeng ke compiler li sebelisa sebopeho sa `__CxxFrameHandler3`, ts'ebetso ho CRT, mme khoutu e sa phutholoheng ea Windows e tla sebelisa ts'ebetso ena ea botho ho etsa khoutu eohle ea tlhoekiso ka har'a sethala.
//!
//! 3. Mehala eohle e hlahisitsoeng ke khomphutha ho `invoke` e na le sebaka se emisitsoeng joalo ka taelo ea `cleanuppad` LLVM, e bonts'ang qalo ea tloaelo ea ho hloekisa.
//! Botho (mohatong oa 2, o hlalositsoeng ho CRT) bo ikarabella bakeng sa ho tsamaisa mekhoa ea ho hloekisa.
//! 4. Qetellong khoutu ea "catch" ka `try` ea tlhaho (e hlahisoang ke moqapi) ea phethoa mme e bonts'a hore taolo e lokela ho khutlela ho Rust.
//! Sena se etsoa ka `catchswitch` hammoho le taelo ea `catchpad` ka mantsoe a LLVM IR, qetellong e khutlisetsa taolo e tloaelehileng lenaneong ka taelo ea `catchret`.
//!
//! Liphapang tse ikhethileng ho tsoa ho ts'ebetso e ikhethileng ea gcc ke:
//!
//! * Rust ha e na tšebetso ea botho, empa e lula e le * `__CxxFrameHandler3`.Ntle le moo, ha ho na tlhotlo e eketsehileng e etsoang, kahoo re qetella re tšoere mekhelo efe kapa efe ea C++ e etsahalang e shebahala joalo ka mofuta oo re o lahlang.
//! Hlokomela hore ho lahlela khethollo ho Rust ke boits'oaro bo sa hlalosoang, ka hona sena se lokela ho ba hantle.
//! * Re na le tlhaiso-leseling eo re lokelang ho e fetisa moeling o sa tlamang, haholo-holo `Box<dyn Any + Send>`.Joalo ka mekhelo e Mengata litsupa tsena tse peli li bolokoa e le mojaro ntle le ona.
//! Ho MSVC, leha ho le joalo, ha ho na tlhoko ea kabo e eketsehileng ea qubu hobane mohala oa mohala o bolokiloe ha mesebetsi ea sefahla e ntse e etsoa.
//! Sena se bolela hore litsupa li fetisetsoa ka kotlolloho ho `_CxxThrowException` e ntan'o khutlisoa ts'ebetsong ea sefahla e lokelang ho ngoloa mohahong oa pokello ea karolo ea `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Sena se hloka ho ba Khetho hobane re fumana khethollo ka ho supa mme mosenyi oa eona o etsoa ke nako ea C++ ea ho matha.
    // Ha re ntša Lebokose ka ntle ho mokhelo, re hloka ho siea mokhelo maemong a nepahetseng hore mosireletsi oa ona a sebetse ntle le ho lahlela Lebokose habeli.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Ntlha ea pele, litlhaloso tse ngata tsa mofuta.Ho na le li-oddities tse 'maloa tse ikhethang sethaleng mona, le tse ngata tse kopilitsoeng ka mokhoa o hlakileng ho tsoa LLVM.Morero oa sena sohle ke ho kenya tšebetsong mosebetsi oa `panic` ka tlase ka ho letsetsa `_CxxThrowException`.
//
// Mosebetsi ona o nka mabaka a mabeli.Ea pele ke sesupisi ho data eo re e fetisang, eo hona joale e leng ntho ea rona ea trait.Ho bonolo ho e fumana!E latelang, leha ho le joalo, e thata ho feta.
// Sena ke sesupi sa sebopeho sa `_ThrowInfo`, 'me ka kakaretso se etselitsoe feela ho hlalosa mokhelo o lahleloang.
//
// Hajoale tlhaloso ea mofuta ona [1] e na le boea bo bonyenyane, 'me ntho e makatsang (le phapang ho tsoa sengoloeng sa inthanete) ke hore ho li-32-bit litsupa ke litsupa empa ho 64-bit lits'oants'o li hlahisoa e le li-offsets tse 32 tse tsoang ho Letšoao la `__ImageBase`.
//
// `ptr_t` le `ptr!` macro li-module tse ka tlase li sebelisetsoa ho hlalosa sena.
//
// Boholo ba litlhaloso tsa mofuta le bona bo latela haufi-ufi se hlahisoang ke LLVM bakeng sa ts'ebetso ea mofuta ona.Mohlala, haeba u ngola khoutu ena ea C++ ho MSVC ebe u ntša LLVM IR:
//
//      #include <stdint.h>
//
//      sebopeho rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      lefeela foo() { rust_panic a = {0, 1};
//          lahlela;}
//
// Ke seo re lekang ho se etsisa.Boholo ba litekanyetso tse sa fetoheng tse ka tlase li ne li kopitsoa feela ho tsoa ho LLVM,
//
// Leha ho le joalo, meaho ena kaofela e hahiloe ka mokhoa o ts'oanang, 'me e batla e le leetsi ho rona.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Hlokomela hore ka boomo re hlokomoloha melao ea mangling mona: ha re batle hore C++ e tsebe ho ts'oara Rust panics ka ho phatlalatsa `struct rust_panic` feela.
//
//
// Ha o fetola, etsa bonnete ba hore mofuta oa thapo ea lebitso o tšoana hantle le o sebelisitsoeng ho `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Sepheo sa `\x01` se etellang pele mona ha e le hantle ke lets'oao la boloi ho LLVM ho *se* sebelise mangling afe kapa afe a mang joaloka prefixing le `_`.
    //
    //
    // Letšoao lena ke vtable e sebelisoang ke C++ 's `std::type_info`.
    // Lintho tsa mofuta oa `std::type_info`, mofuta oa litlhaloso, li na le sesupa tafoleng ena.
    // Litlhaloso tsa mofuta li boletsoe ke li-C++ EH tse hlalositsoeng kaholimo le tseo re li hahang ka tlase.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Mofuta oa mofuta ona o sebelisoa feela ha ho lahleloa mokhelo.
// Karolo ea ho tšoasa e sebetsoa ke try intrinsic, e iketsetsang TypeDescriptor ea eona.
//
// Sena se lokile kaha nako ea ho matha ea MSVC e sebelisa papiso ea likhoele lebitsong la mofuta ho bapisa TypeDescriptors ho fapana le tekano ea pointer.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Mosenyi o sebelisitse haeba khoutu ea C++ e nka qeto ea ho nka mokhelo ebe oa e lahla ntle le ho e phatlalatsa.
// Karolo ea ho ts'oasa ea try intrinsic e tla beha lentsoe la pele la ntho e khethollang ho 0 hore e tloloe ke mosenyi.
//
// Hlokomela hore x86 Windows e sebelisa kopano ea ho letsetsa "thiscall" bakeng sa mesebetsi ea litho tsa C++ ho fapana le kopano ea ho letsetsa ea "C".
//
// Mosebetsi oa exception_copy o batla o khethehile mona: o sebelisoa ke nako ea ho matha ea MSVC tlasa block ea try/catch le panic eo re e hlahisang mona e tla sebelisoa e le sephetho sa kopi e ikhethang.
//
// Sena se sebelisoa ke nako ea C++ ea ho matha ho ts'ehetsa ho nka likarolo ntle le std::exception_ptr, eo re sitoang ho e tšehetsa hobane Box<dyn Any>ha e khonehe.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException e sebetsa ka ho felletseng mohahong ona oa stack, ka hona ha ho na lebaka la ho fetisetsa `data` ho qubu.
    // Re mpa re fetisa sesupa-tsela bakeng sa mosebetsi ona.
    //
    // ManuallyDrop e ea hlokahala mona kaha ha re batle hore mokhelo o tloheloe ha o phutholoha.
    // Sebakeng seo e tla akheloa ka khethollo_cleanup e kenyelletsoang ke C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Sena ... se ka bonahala se makatsa, 'me ho utloahala joalo.Ho li-32-bit MSVC litsupa lipakeng tsa sebopeho sena ke feela, litsupa.
    // Ho li-64-bit MSVC, leha ho le joalo, litsupa lipakeng tsa meaho li hlahisoa joalo ka li-32-bit tse tsoang `__ImageBase`.
    //
    // Ka lebaka leo, ho 32-bit MSVC re ka phatlalatsa litsupa tsena kaofela ho `static`s kaholimo.
    // Ho li-MSVC tse 64-bit, re tla tlameha ho bonts'a lits'oants'o tsa lits'oants'o, tseo Rust e sa li lumelleng hajoale, ka hona re ke ke ra etsa joalo.
    //
    // Ntho e latelang e ntle ka ho fetisisa ke ho tlatsa meaho ena ka nako ea ho matha (ho tšoha e se e ntse e le "slow path" leha ho le joalo).
    // Kahoo mona re fetolela libaka tsena tsohle tsa pointer e le li-integer tse 32-bit ebe re boloka boleng bo nepahetseng ho eona (atomically, joalo ka ha panics e le 'ngoe e kanna ea etsahala).
    //
    // Ha e le hantle, nako ea ho matha e kanna ea bala likarolo tsena tse seng tsa atomic, empa ka khopolo ha ho mohla ba balileng boleng ba * phoso kahoo ha ea lokela ho ba mpe haholo ...
    //
    // Leha ho le joalo, re hloka ho etsa ntho e kang ena ho fihlela re ka hlahisa ts'ebetso e ngoe ho statics (mme re kanna ra se khone ho khona).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Ho pataloa ha NULL mona ho bolela hore re fihlile mona ka lebaka la ho ts'oaroa ha (...) ea __rust_try.
    // Sena se etsahala ha mokhelo o seng oa Rust oa kantle ho naha o ts'oaroa.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Sena se hlokoa ke moqapi hore a be teng (mohlala, ke ntho ea lang), empa ha e so ka e bitsoa ke moqapi hobane __C_specific_handler kapa_except_handler3 ke ts'ebetso ea botho e sebelisoang khafetsa.
//
// Kahoo sena ke feela kutu e senyehang.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}