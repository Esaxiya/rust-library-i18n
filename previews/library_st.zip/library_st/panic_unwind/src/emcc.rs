//! Ho phomola bakeng sa sepheo sa * emscripten.
//!
//! Le ha ts'ebetsong e tloaelehileng ea Rust bakeng sa li-platform tsa Unix e letsetsa li-API tsa libunwind ka kotloloho, ho Emscripten ho e-na le hoo re letsetsa li-API tsa C++ tse sa phutholoheng.
//! Sena ke molemo feela kaha nako ea Emscripten ea ho sebetsa e lula e sebelisa li-API tseo ebile ha e sebelise libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Sena se tsamaisana le sebopeho sa std::type_info ho C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Sepheo sa `\x01` se etellang pele mona ha e le hantle ke lets'oao la boloi ho LLVM ho *se* sebelise mangling afe kapa afe a mang joaloka prefixing le `_`.
    //
    //
    // Letšoao lena ke vtable e sebelisoang ke C++ 's `std::type_info`.
    // Lintho tsa mofuta oa `std::type_info`, mofuta oa litlhaloso, li na le sesupa tafoleng ena.
    // Litlhaloso tsa mofuta li boletsoe ke li-C++ EH tse hlalositsoeng kaholimo le tseo re li hahang ka tlase.
    //
    // Hlokomela hore boholo ba nnete bo boholo ho feta ts'ebeliso ea 3, empa re hloka feela hore re khone ho supa ntlha ea boraro.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info bakeng sa sehlopha sa mafome_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Ka tloaelo re ne re sebelisa .as_ptr().add(2) empa sena ha se sebetse maemong a const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Sena ka boomo ha se sebelise lebitso le tloaelehileng la mangling scheme hobane ha re batle hore C++ e tsebe ho hlahisa kapa ho ts'oasa Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Sena sea hlokahala hobane khoutu ea C++ e ka ts'oara ts'ebetso ea rona ka std::exception_ptr mme ea e khutlisa makhetlo a mangata, mohlomong le ka khoele e ngoe.
    //
    //
    caught: AtomicBool,

    // Sena se hloka ho ba Khetho hobane nako ea bophelo ea ntho e latela li-semantiki tsa C++ : ha catch_unwind e tlosa Lebokose ntle le mokhelo e tlameha ho tlohela ntho e ikhethileng e le maemong a nepahetseng hobane mosenyi oa eona o ntse a tla bitsoa ke __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try ehlile e re fa sesupi mohahong ona.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Kaha cleanup() ha e lumelloe ho panic, re mpa re ntša mpa feela.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}