//! Ho koahela panics bakeng sa Miri.
use alloc::boxed::Box;
use core::any::Any;

// Mofuta oa tefo eo enjine ea Miri e e phatlalatsang ka ho re hlohlolela.
// E tlameha ho ba boholo ba sesupa.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri e fanoeng ke Miri extern e qala ho notlolla.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Tefo eo re e fetisetsang ho `miri_start_panic` e tla ba khang eo re e fumanang ho `cleanup` ka tlase.
    // Kahoo re e kenya mabokoseng hanngoe, ho fumana ho hong ho lekaneng.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Fumana hape `Box` ea mantlha.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}