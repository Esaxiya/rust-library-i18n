//! Ho phomola bakeng sa sepheo sa *wasm32*.
//!
//! Hona joale ha re tšehetse sena, ka hona sena ke li-stubs feela.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}