//! Ts'ebetsong ea panics ka mokhoa oa ho koalla
//!
//! crate ena ke ts'ebetsong ea panics ho Rust ho sebelisa "most native" stack unwinding mechanism ea sethala sena se hlophiselitsoeng.
//! Sena se arotsoe ka mekotla e meraro hajoale:
//!
//! 1. Lits'oants'o tsa MSVC li sebelisa SEH ho file ea `seh.rs`.
//! 2. Emscripten e sebelisa mekhelo ea C++ ho file ea `emcc.rs`.
//! 3. Lipheo tse ling kaofela li sebelisa libunwind/libgcc ho file ea `gcc.rs`.
//!
//! Litokomane tse ling mabapi le ts'ebetsong e ngoe le e ngoe li ka fumanoa mojuleng o fapaneng.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ha e sebelisoe le Miri, ka hona khutsa litemoso.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Lintho tsa ho qala tsa Rust li qala ka matšoao ana, kahoo li etse sechaba.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Lipheo tse sa tšehetseng ho phomola.
        // - arch=wasm32
        // - os=none ("bare metal" liphofu)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Sebelisa nako ea ho matha ea Miri.
        // Re ntse re hloka ho kenya nako e tloaelehileng e kaholimo, joalo ka ha rustc e lebelletse hore lintho tse ling tsa lang tse tsoang moo li hlalosoe.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Sebelisa nako ea 'nete ea ho matha.
        use real_imp as imp;
    }
}

extern "C" {
    /// Sebelisi sa libstd se bitsitsoeng ha ntho ea panic e theoleloa kantle ho `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler ka libstd e bitsoa ha mokhelo oa kantle ho naha o ts'oaroa.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Sebaka sa ho kena bakeng sa ho hlahisa mokhelo, ke baemeli feela ts'ebetsong e ikhethang ea sethala.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}