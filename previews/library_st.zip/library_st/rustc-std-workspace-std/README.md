# `rustc-std-workspace-std` crate

Bona litokomane tsa `rustc-std-workspace-core` crate.