# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Laeborari ea ho fumana mekokotlo ka nako ea nako ea Rust.
Laeborari ena e ikemiselitse ho ntlafatsa ts'ehetso ea laeborari e tloaelehileng ka ho fana ka sebopeho sa lenaneo leo u ka sebetsang le lona, empa e ts'ehetsa feela ho hatisa mokokotlo o teng ha joale joaloka panics ea libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ho ts'oara mokokotlo le ho lieha ho sebetsana le eona ho fihlela nako e tlang, o ka sebelisa mofuta oa `Backtrace` oa boemo bo holimo.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Haeba, leha ho le joalo, o ka rata phihlello e tala ho ts'ebetso ea ts'ebetso ea 'nete, o ka sebelisa `trace` le `resolve` ka kotloloho.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Rarolla sesupa-taelo sena se lebitsong la lebitso
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // tswela pele ho foreime e latelang
    });
}
```

# License

Morero ona o filoe laesense tlasa e ngoe ea

 * Laesense ea Apache, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) kapa http://www.apache.org/licenses/LICENSE-2.0)
 * Laesense ea MIT ([LICENSE-MIT](LICENSE-MIT) kapa http://opensource.org/licenses/MIT)

ka khetho ea hau.

### Contribution

Ntle le haeba o bolela ka ho hlaka, monehelo ofe kapa ofe o rometsoeng ka boomo bakeng sa ho kenyelletsoa morao-rao ke uena, joalo ka ha ho hlalositsoe ho laesense ea Apache-2.0, e tla ba le laesense e habeli joalo kaholimo, ntle le lipehelo kapa lipehelo tse ling.







