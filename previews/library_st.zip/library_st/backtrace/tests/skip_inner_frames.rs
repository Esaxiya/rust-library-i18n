use backtrace::Backtrace;

// Teko ena e sebetsa feela lipulong tse nang le ts'ebetso ea `symbol_address` ea liforeimi tse tlalehang aterese e qalang ea lets'oao.
// Ka lebaka leo e nolofalitsoe feela lipulong tse 'maloa.
//
const ENABLED: bool = cfg!(all(
    // Windows ha e so ka e lekoa, 'me OSX ha e tšehetse ho fumana mochini o koetsoeng, ka hona thibela ena
    //
    target_os = "linux",
    // Ho ARM ho fumana ts'ebetso e koetsoeng ke ho khutlisa ip ka boeona.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}