//! Mojule oa ho thusa ho sebetsana le litlamo tsa dbghelp ho Windows
//!
//! Li-backtraces tsa Windows (bonyane bakeng sa MSVC) li tsamaisoa haholo ka `dbghelp.dll` le mesebetsi e fapaneng eo e nang le eona.
//! Mesebetsi ena hajoale e laetsoe *ka matla* ho fapana le ho hokahana le `dbghelp.dll` ka lipalo.
//! Hona joale ho etsoa ke laeborari e tloaelehileng (mme ho latela khopolo e hlokehang moo), empa ke boiteko ba ho thusa ho fokotsa maemo a stll dll a laeboraring kaha mekokotlo ea morao e tloaetse ho ikhethela.
//!
//! Ha ho boleloa, `dbghelp.dll` hangata e jara ka katleho ho Windows.
//!
//! Hlokomela leha e le hore kaha re ntse re kenya ts'ehetso ena eohle ka matla re ke ke ra sebelisa litlhaloso tse tala ho `winapi`, empa ho e-na le hoo re hloka ho hlalosa mefuta ea sesupa-mosebetsi ka borona le ho e sebelisa.
//! Ha re hlile ha re batle ho ba khoebong ea ho kopitsa winapi, ka hona re na le sebopeho sa Cargo `verify-winapi` se tiisang hore litlamo tsohle li tsamaellana le winapi mme karolo ena e lumelloa ho CI.
//!
//! Qetellong, o tla hlokomela mona hore dll ea `dbghelp.dll` ha e laolloe, 'me hona joale ke ka boikemisetso.
//! Monahano ke hore re ka o boloka le ho o sebelisa lipakeng tsa mehala e eang ho API, re qoba loads/unloads e turang.
//! Haeba ena ke bothata bakeng sa li-detectors tse dutlang kapa ntho e joalo re ka tšela borokho ha re fihla moo.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Sebetsa ho pota `SymGetOptions` le `SymSetOptions` u se teng ho winapi ka boeona.
// Ho seng joalo sena se sebelisoa ha feela re hlahloba mefuta e 'meli khahlano le winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ha e hlalosoe ka winapi hajoale
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Sena se hlalosoa ka winapi, empa ha sea nepahala (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ha e hlalosoe ka winapi hajoale
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Macro ena e sebelisetsoa ho hlalosa sebopeho sa `Dbghelp` se ka hare se nang le lits'oants'o tsohle tsa tšebetso tseo re ka li jarang.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL e laetsoeng bakeng sa `dbghelp.dll`
            dll: HMODULE,

            // Sesupo se seng le se seng sa tšebetso bakeng sa ts'ebetso ka 'ngoe eo re ka e sebelisang
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Qalong ha rea kenya DLL
            dll: 0 as *mut _,
            // Qala mesebetsi eohle e behiloe ho zero ho re e hloka ho jarisoa ka matla.
            //
            $($name: 0,)*
        };

        // Mofuta o bonolo oa typedef bakeng sa mofuta o mong le o mong oa tšebetso.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Boiteko ba ho bula `dbghelp.dll`.
            /// E khutlisa katleho haeba e sebetsa kapa phoso haeba `LoadLibraryW` e hloleha.
            ///
            /// Panics haeba laeborari e se e ntse e laetsoe.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Mosebetsi oa mokhoa o mong le o mong oo re ka ratang ho o sebelisa.
            // Ha e bitsoa e kanna ea bala pointer ea ts'ebetso e bolokiloeng kapa ea e jarisa ebe e khutlisa boleng bo laetsoeng.
            // Mejaro e tiisoa hore e atlehe.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy e bonolo ea ho sebelisa liloko tsa tlhoekiso ho supa lits'ebetso tsa dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Qala ts'ehetso eohle e hlokahalang ho fihlella mesebetsi ea `dbghelp` API ho tsoa ho crate.
///
///
/// Hlokomela hore ts'ebetso ena e bolokehile **, ka hare e na le khokahano ea eona.
/// Hape hlokomela hore ho bolokehile ho bitsa ts'ebetso ena makhetlo a mangata ho pheta-pheta.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Ntho ea pele eo re hlokang ho e etsa ke ho hokahanya mosebetsi ona.Sena se ka bitsoa ka nako e le ngoe ho tsoa likhoeleng tse ling kapa ka mokhoa o phetoang kahare ho khoele e le 'ngoe.
        // Hlokomela hore ho thata ho feta moo hobane seo re se sebelisang mona, `dbghelp`, * le sona se hloka ho hokahanngoa le batho bohle ba letsetsang `dbghelp` ts'ebetsong ena.
        //
        // Ka tloaelo ha ho na mehala e mengata ho `dbghelp` ka mokhoa o ts'oanang mme mohlomong re ka nahana hore ke rona feela ba e fumanang.
        // Leha ho le joalo, ho na le mosebelisi e mong oa mantlha eo re tlamehang ho tšoenyeha ka eona ke rona ka bohona, empa laeboraring e tloaelehileng.
        // Laeborari e tloaelehileng ea Rust e ipapisitse le crate ena bakeng sa tšehetso ea backtrace, mme crate ena le eona e teng ho crates.io.
        // Sena se bolela hore haeba laeborari e tloaelehileng e ntse e hatisa mokokotlo oa panic e kanna ea matha le crate ena e tsoang crates.io, e baka likhetho.
        //
        // Ho thusa ho rarolla bothata bona ba khokahano re sebelisa leqheka le ikhethileng la Windows mona (ka mora moo, ke thibelo e ikhethileng ea Windows mabapi le khokahano).
        // Re theha seboka sa lehae * se bitsoang mutex ho sireletsa mohala ona.
        // Morero mona ke hore laeborari e tloaelehileng le crate ha lia tlameha ho arolelana li-API tsa boemo ba Rust ho hokahanya mona empa li ka sebetsa ka morao ho etsa bonnete ba hore lia lumellana.
        //
        // Ka tsela eo ha ts'ebetso ena e bitsoa ka laeboraring e tloaelehileng kapa ka crates.io re ka kholiseha hore ho buuoa le limx e tšoanang.
        //
        // Kahoo tsohle ke ho re ntho ea pele eo re e etsang mona ke hore ka tlhaho re thehe `HANDLE` e bitsoang mutex ho Windows.
        // Re hokahanya hanyane le likhoele tse ling tse arolelanang ts'ebetso ena ka kotloloho mme re netefatsa hore ho etsoa mohala o le mong feela ka mohlala oa mosebetsi ona.
        // Hlokomela hore mochini ha o koaloe hang ha o bolokiloe lefats'eng.
        //
        // Kamora hore re tsamaee re notlele, re e fumane feela, 'me mochini oa rona oa `Init` oo re o fang o tla ba le boikarabello ba ho o tlohela qetellong.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ho lokile, phew!Kaha joale kaofela re hokahantsoe ka polokeho, ha re qaleng ho sebetsana le ntho e ngoe le e ngoe.
        // Pele re hloka ho netefatsa hore `dbghelp.dll` e hlile e laetsoe ts'ebetsong ena.
        // Re etsa sena ka matla ho qoba ho ipapisa le maemo.
        // Sena haesale se etsoa ho sebetsana le mathata a hokahanyang a makatsang mme se reretsoe ho etsa hore li-binaries li nkehe habonolo ho tloha ha sena e le ts'ebeliso e mpe ea mathata feela.
        //
        //
        // Hang ha re se re butse `dbghelp.dll` re hloka ho bitsa mesebetsi e meng ea ho qala ho eona, 'me e hlalositsoe ka tlase mona.
        // Re etsa sena hang feela, leha ho le joalo, ka hona re na le boolean ea lefats'e e bonts'ang hore na re qetile kapa che.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Netefatsa hore folakha ea `SYMOPT_DEFERRED_LOADS` e behiloe, hobane ho latela litokomane tsa MSVC ka sena: "This is the fastest, most efficient way to use the symbol handler.", ha re etseng joalo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ha e le hantle qala matšoao ka MSVC.Hlokomela hore sena se ka hloleha, empa rea se hlokomoloha.
        // Ha ho na thane ea bonono ba pele bakeng sa sena ka bonngoe, empa LLVM kahare e bonahala e iphapanyetsa boleng ba ho khutla mona 'me e' ngoe ea lilaeborari tsa sanitizer ho LLVM e hatisa tlhokomeliso e tšosang haeba sena se hloleha empa ha e le hantle se e hlokomoloha qetellong.
        //
        //
        // Nyeoe e le 'ngoe e hlahang haholo bakeng sa Rust ke hore laeborari e tloaelehileng le crate ena ho crates.io ka bobeli li batla ho qothisana lehlokoa le `SymInitializeW`.
        // Laeborari e tloaelehileng eo khale e neng e batla ho e qala ebe e hloekisa boholo ba nako, empa joale ha e sebelisa crate ho bolela hore motho e mong o tla qala pele ebe e mong o tla qala.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}