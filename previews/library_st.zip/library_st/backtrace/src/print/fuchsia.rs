use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr e nka mohala o tla amohela dl_phdr_info pointer bakeng sa DSO e ngoe le e ngoe e hokahantsoeng le ts'ebetso.
    // dl_iterate_phdr e boetse e netefatsa hore sehokelo sa matla se notletsoe ho tloha qalong ho fihlela qetellong ea iteration.
    // Haeba mohala oa ho khutlisa o khutlisa boleng bo seng ba zero, iteration e emisoa kapele.
    // 'data' e tla fetisoa e le ngangisano ea boraro ho ho khutlisetsoa mohala mohala ka mong.
    // 'size' e fana ka boholo ba dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Re hloka ho bala ID ea moaho le lintlha tse ling tsa sehlooho tsa lenaneo tse bolelang hore le rona re hloka lintho tse ling ho tsoa ho ELF spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Joale re tlameha ho pheta, hanyane hanyane, sebopeho sa dl_phdr_info mofuta o sebelisoang ke sehokelo sa hona joale se matla sa fuchsia.
// Chromium e boetse e na le moeli ona oa ABI hammoho le "crashpad".
// Qetellong re ka rata ho tsamaisa linyeoe tsena ho sebelisa patlo ea elf empa re tla hloka ho fana ka seo ho SDK mme seo ha se so etsahale.
//
// Kahoo re (le bona) re ts'oeroe ke ho sebelisa mokhoa ona o kenyang khokahano e thata le fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ha re na mokhoa oa ho tseba ho hlahloba haeba e_phoff le e_phnum li nepahetse.
    // libc e lokela ho netefatsa sena bakeng sa rona empa ho bolokehile ho theha selae mona.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr e emela hlooho ea lenaneo la ELF la li-64-bit molemong oa meralo ea sepheo.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr e emela sehlooho se nepahetseng sa lenaneo la ELF le litaba tsa eona.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ha re na mokhoa oa ho lekola hore na p_addr kapa p_memsz li nepahetse.
    // Libc ea Fuchsia e hlakola lintlha pele empa ka lebaka la ho ba mona lihlooho tsena li tlameha ho sebetsa.
    //
    // NoteIter ha e hloke hore data ea mantlha e sebetse empa e hloka hore meeli e sebetse.
    // Rea tšepa hore libc e netefalitse hore ho ba joalo ho rona mona.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Mofuta oa noutu bakeng sa li-ID tsa ho aha.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr e emela sehlooho sa lintlha tsa ELF ho endianness ea sepheo.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Noutu e emetse lengolo la ELF (lihlooho + tsa litaba).
// Lebitso le setse e le selae sa u8 hobane ha se khaoloe kamehla ebile rust e etsa hore ho be bonolo ho lekola hore na li-byte lia tšoana na.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter eu lumella ho itlhakisa ka mokhoa o sireletsehileng holim'a karolo ea noutu.
// E emisa hang ha phoso e hlaha kapa ha ho sa na lintlha.
// Haeba u ka bala lintlha tse sa sebetseng, e tla sebetsa joalo ka ha ho se lintlha tse fumanoeng.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ke ntho e sa fetoheng ea ts'ebetso eo sesupa le boholo bo fuoeng li bonts'a mefuta e nepahetseng ea li-byte eo bohle ba ka e balang.
    // Litaba tsa li-byte tsena e ka ba eng kapa eng haese hore mefuta e tlameha ho sebetsa hore sena se bolokehe.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligns 'x' to 'to'-byte alignment assassing 'to' ke matla a 2.
// Sena se latela paterone e tloaelehileng ho kh'outu ea C/C ++ ELF moo (x + ho, 1)&-to e sebelisoang.
// Rust ha eu lumelle hore u sebelise boholo ba tšebeliso eo ke e sebelisang
// 2's-complement phetoho ho etsa seo hape.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 e sebelisa li-byte tse tsoang selae (haeba li le teng) hape e netefatsa hore selae sa ho qetela se hokahane hantle.
// Haeba palo ea li-byte e kopiloeng e kholo haholo kapa selae se ke ke sa hlophisoa bocha kamora moo ka lebaka la li-byte tse setseng tse teng, Ha ho na e khutlisitsoeng mme selae ha se fetoloe.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Mosebetsi ona ha o na lintho tse hlaselang tsa nnete tseo motho ea letsitseng a lokelang ho li tšehetsa ntle le hore 'bytes' e lokela ho hokahanngoa le ts'ebetso (le ho nepahala ha meralo e meng).
// Litekanyetso masimong a Elf_Nhdr e kanna ea ba lefeela empa ts'ebetso ena ha e netefatse ntho e joalo.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Sena se bolokehile ha feela ho na le sebaka se lekaneng mme re sa tsoa tiisa hore polelong e kaholimo ka hona sena ha sea lokela ho ba kotsi.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Hlokomela hore sice_of: :<Elf_Nhdr>() e lula e tsamaellane ka li-byte tse 4.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Lekola hore na re fihlile pheletsong.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Re fetisa nhdr empa re nahana ka hloko ka sebopeho sa sephetho.
        // Ha re tšepe namesz kapa descsz mme ha re etse liqeto tse sa bolokehang ho latela mofuta.
        //
        // Kahoo leha re ka lahla lithōle tse felletseng re ntse re lokela ho bolokeha.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// E bontša hore karolo e ka phethahatsoa.
const PERM_X: u32 = 0b00000001;
/// E bontša hore karolo e ka ngoloa.
const PERM_W: u32 = 0b00000010;
/// E bontša hore karolo e ka baloa.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// E emela karolo ea ELF ka nako ea ho matha.
struct Segment {
    /// E fana ka aterese ea nako ea ho matha ea likahare tsa karolo ena.
    addr: usize,
    /// E fana ka boholo ba mohopolo oa litaba tsa karolo ena.
    size: usize,
    /// E fana ka aterese ea module ea karolo ena le file ea ELF.
    mod_rel_addr: usize,
    /// E fana ka litumello tse fumanehang ho file ea ELF.
    /// Litumello tsena ha se hakaalo litumello tse teng ka nako ea tšebetso leha ho le joalo.
    flags: Perm,
}

/// Etsa hore e be e lekantsoeng holim'a Likarolo tse tsoang DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// E emela ELF DSO (Dynamic Shared Object).
/// Mofuta ona o supa data e bolokiloeng ho DSO ea sebele ho fapana le ho iketsetsa eona.
struct Dso<'a> {
    /// Linker e matla e lula e re fa lebitso, leha lebitso le se na letho.
    /// Tabeng ea motho ea ka sehloohong ea ka sebelisoang lebitso lena le tla ba lefeela.
    /// Tabeng ea ntho e arolelanoeng e tla ba soname (sheba DT_SONAME).
    name: &'a str,
    /// Ho Fuchsia hoo e batlang e le li-binaries tsohle li na le li-ID empa sena ha se tlhoko e tiileng.
    /// Ha ho na mokhoa oa ho bapisa tlhaiso-leseling ea DSO le faele ea 'nete ea ELF kamora moo haeba ho se na li-build_id kahoo re hloka hore DSO e ngoe le e ngoe e be le eona mona.
    ///
    /// Li-DSO tse se nang li-build_id lia hlokomolohuoa.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// E khutlisetsa iterator holim'a Likarolo tsa DSO ena.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Liphoso tsena li kenyelletsa litaba tse hlahang ha ho ntse ho batloa leseli ka DSO ka 'ngoe.
///
enum Error {
    /// NameError e bolela hore phoso e etsahetse ha ho fetoloa khoele ea setaele sa C hore e be khoele ea rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError e bolela hore ha rea fumana ID ea kaho.
    /// Sena se ka etsahala hobane DSO e ne e sena ID ea kaho kapa hobane karolo e nang le ID ea kaho e ne e sa sebetse hantle.
    ///
    BuildIDError,
}

/// E letsetsa 'dso' kapa 'error' bakeng sa DSO ka 'ngoe e hokahaneng le ts'ebetso ka sehokela se matla.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter e tla ba le e 'ngoe ea mekhoa ea ho ja e bitsoang foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr e netefatsa hore info.name e tla supa sebaka se nepahetseng.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Mosebetsi ona o hatisa letšoao la tšoantšetso la Fuchsia bakeng sa tlhaiso-leseling eohle e fumanehang ho DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}