//! Ts'ehetso ea tšoantšetso e sebelisa `gimli` crate ho crates.io
//!
//! Ena ke ts'ebetsong ea ts'ebeliso ea mantlha ea Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'bophelo bo tsitsitseng ke leshano la ho qhekella ho haelloa ke tšehetso bakeng sa boitlhopho ba boitlhopho.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Fetolela ho 'bophelo bo sa fetoheng' hobane lipontšo li lokela ho alima `map` le `stash` feela 'me re li boloka ka tlase.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Bakeng sa ho kenya lilaeborari tsa matsoalloa a Windows, bona puisano ho rust-lang/rust#71060 bakeng sa maano a fapaneng mona.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Lilaebrari tsa MinGW ha joale ha li tšehetse ASLR (rust-lang/rust#16514), empa li-DLL li ntse li ka fallisetsoa sebakeng sa aterese.
            // Ho bonahala eka liaterese tse fumanehang ho leseli la bothata ke tsohle haeba laeborari ena e laetsoe ho "image base" ea eona, e leng tšimo ho lihlooho tsa eona tsa faele tsa COFF.
            // Kaha sena ke seo debuginfo e bonahala e se thathamisa re bala tafole ea matšoao le liaterese tsa lebenkele joalokaha eka laeborari e laetsoe le "image base".
            //
            // Laeborari e kanna ea se ke ea laeloa ho "image base", leha ho le joalo.
            // (mohlomong ho na le ho hong ho ka laeloang moo?) Mona ke moo tšimo ea `bias` e kenang, 'me re hloka ho fumana boleng ba `bias` mona.Ka bomalimabe leha ho sa hlaka hore na u ka e fumana joang mojuleng o laetsoeng.
            // Seo re nang le sona, leha ho le joalo, ke aterese ea 'nete ea mojaro (`modBaseAddr`).
            //
            // Ha re ntse re le kopitsa hajoale re faola mmapa, re bala tlhaiso-leseling ea hlooho, ebe o lahlela mmap.Hona ho senya hobane re kanna ra bula mmap hamorao, empa sena se lokela ho sebetsa hantle ho fihlela joale.
            //
            // Hang ha re se re na le `image_base` (sebaka seo re se batlang sa mojaro) le `base_addr` (sebaka sa 'nete sa mojaro) re ka tlatsa `bias` (phapang lipakeng tsa se hlileng se lakatsehang) ebe aterese e boletsoeng ea karolo ka' ngoe ke `image_base` kaha ke seo faele e se buang.
            //
            //
            // Hajoale ho bonahala eka ho fapana le ELF/MachO re ka ikamahanya le karolo e le 'ngoe ka laeboraring, re sebelisa `modBaseSize` ka boholo bohle.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS e sebelisa sebopeho sa faele sa Mach-O mme e sebelisa li-API tse ikhethileng tsa DYLD ho kenya lenane la lilaeborari tsa matsoalloa tseo e leng karolo ea ts'ebeliso.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Lata lebitso la laeborari ena le lumellanang le tsela ea ho e jarisa hape.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Laola hlooho ea setšoantšo sa laeborari ena 'me u abele `object` ho bala litaelo tsohle tsa mojaro hore re tsebe ho fumana likarolo tsohle tse amehang mona.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iketsetse likarolo 'me u ngolise libaka tse tsebahalang bakeng sa likarolo tseo re li fumanang.
            // Ntle le moo rekota likarolo tsa sengoloa sa tlhaiso-leseling bakeng sa ho sebetsoa hamorao, bona litlhaloso ka tlase.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Fumana "slide" bakeng sa laeborari ena e qetellang e le leeme leo re le sebelisang ho fumana hore na lintho tsa memori li laoloa kae.
            // Ena ke pokello e makatsang leha ho le joalo ebile ke litholoana tsa ho leka lintho tse 'maloa naheng le ho bona se khomarelang.
            //
            // Mohopolo o akaretsang ke hore `bias` hammoho le karolo ea `stated_virtual_memory_address` e tla ba moo karolo ea bolulo e lulang teng.
            // Ntho e 'ngoe eo re itšetlehileng ka eona ke hore aterese ea' nete e tlosa `bias` ke lenane la ho sheba tafoleng ea matšoao le debuginfo.
            //
            // Hoa etsahala, leha ho le joalo, hore lilaebraring tse laetsoeng ke sistimi lipalo tsena ha lia nepahala.Bakeng sa phethahatso ea matsoalloa, leha ho le joalo, e bonahala e nepahetse.
            // Ho phahamisa mohopolo ho tsoa mohloling oa LLDB ho na le mokhoa o ikhethileng bakeng sa karolo ea pele ea `__TEXT` e tsoang ho file offset 0 ka boholo ba nonzero.
            // Ka lebaka lefe kapa lefe ha sena se le teng ho bonahala ho bolela hore tafole ea matšoao e amana feela le vmaddr slide ea laeboraring.
            // Haeba ha e eo * tafoleng ea matšoao e amana le vmaddr slide hammoho le aterese e boletsoeng ea karolo eo.
            //
            // Ho sebetsana le boemo bona haeba re sa fumane karolo ea sengoloa ho file offset zero ebe re eketsa leeme ka aterese e boletsoeng ea likarolo tsa pele ebe re fokotsa liaterese tsohle tse boletsoeng ka chelete eo hape.
            //
            // Ka tsela eo tafole ea tšoantšetso e lula e hlaha ho latela bongata ba leeme la laeborari.
            // Sena se bonahala se na le liphetho tse nepahetseng bakeng sa ho tšoantšetsa ka tafole ea matšoao.
            //
            // Ka 'nete ha ke na bonnete ba hore na sena se nepahetse kapa ho na le ho hong ho lokelang ho bonts'a mokhoa oa ho etsa sena.
            // Hajoale leha sena se bonahala se sebetsa hantle ka ho lekana (?) mme re lokela ho lula re khona ho e pheta ha nako e ntse e feta ha ho hlokahala.
            //
            // Bakeng sa tlhaiso-leseling e batsi bona #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Tse ling Unix (mohlala
        // Linux) liforomo li sebelisa ELF e le sebopeho sa faele ea ntho mme hangata li kenya ts'ebetsong API e bitsoang `dl_iterate_phdr` ho kenya lilaeborari tsa lehae.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` e lokela ho ba litsupa tse nepahetseng.
        // `vec` e lokela ho ba sesupa se nepahetseng ho `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ha e tšehetse ka tlhaho tlhaiso-leseling ea bothata, empa sistimi ea kaho e tla beha leseli la bothata tseleng ea `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ntho e ngoe le e ngoe e lokela ho sebelisa ELF, empa ha e tsebe ho kenya lilaeborari tsa lehae.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Lilaebrari tsohle tse tsebahalang tse arolelanoeng tse laetsoeng.
    libraries: Vec<Library>,

    /// Mappings cache moo re bolokang tlhaiso-leseling e patiloeng
    ///
    /// Lethathamo lena le na le matla a tsitsitseng bakeng sa nako eohle ea bophelo eo ho seng mohla e eketsehang.
    /// Karolo ea `usize` ea para ka 'ngoe ke index ho `libraries` kaholimo moo `usize::max_value()` e emelang se ka sebetsoang hajoale.
    ///
    /// `Mapping` e tsamaisana le tlhaiso-leseling e patiloeng e hlakileng.
    ///
    /// Hlokomela hore hona haele hantle ke polokelo ea LRU mme re tla be re fetola lintho mona ha re ntse re tšoantšetsa liaterese.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Likarolo tsa laeborari ena li kentsoe mohopolong, le moo li laetsoeng teng.
    segments: Vec<LibrarySegment>,
    /// "bias" ea laeborari ena, hangata moo e kenngoang mohopolong.
    /// Boleng bona bo eketsoa atereseng e boletsoeng ea karolo ka 'ngoe ho fumana aterese ea' nete ea memori eo karolo eo e kenngoeng ho eona.
    /// Ntle le moo leeme lena le tlosoa ho liaterese tsa 'nete tsa memori ho ea ho index ho debuginfo le tafoleng ea matšoao.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Aterese e boletsoeng ea karolo ena faeleng ea ntho.
    /// Mona ha se moo karolo e laoloang, empa aterese ena hammoho le `bias` ea laeborari ke moo u ka e fumanang.
    ///
    stated_virtual_memory_address: usize,
    /// Boholo ba karolo ea ths mohopolong.
    len: usize,
}

// e sa bolokeha hobane ho hlokahala hore e lumellane ka ntle
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // e sa bolokeha hobane ho hlokahala hore e lumellane ka ntle
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Pokello ea LRU e nyane haholo, e bonolo haholo bakeng sa tlhaiso-leseling ea tlhaiso-leseling.
        //
        // Sekhahla sa lipalo se lokela ho ba se phahameng haholo, hobane pokello e tloaelehileng ha e tšele pakeng tsa lilaebrari tse ngata tse arolelanoeng.
        //
        // Meaho ea `addr2line::Context` e theko e boima haholo ho e etsa.
        // Litsenyehelo tsa eona li lebelletsoe ho fokotsoa ka lipotso tse latelang tsa `locate`, tse matlafatsang meaho e hahiloeng ha ho ahoa `addr2line: : Context`s ho fumana li-speedups tse ntle.
        //
        // Haeba re ne re se na polokelo ena, phokotso eo ea matlafalo e ne e ke ke ea etsahala, 'me litšoantšetso tse ka morao e ka ba ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Pele, etsa liteko haeba `lib` ena e na le karolo efe kapa efe e nang le `addr` (e sebetsana le phalliso).Haeba cheke ena e feta joale re ka tsoelapele ka tlase mme ra fetolela aterese.
                //
                // Hlokomela hore re sebelisa `wrapping_add` mona ho qoba ho hlahloba ho feta.Ho bonoe naheng ha komporo ea SVMA + ea leeme e khaphatseha.
                // Ho bonahala ho makatsa ho ka etsahalang empa ha ho na chelete e ngata eo re ka e etsang ka eona ntle le hore re ka iphapanya likarolo tseo hobane li kanna tsa supa sepakapakeng.
                //
                // Sena se qalile ka rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Kaha joale re tseba hore `lib` e na le `addr`, re ka sebetsana le leeme ho fumana aterese ea memori ea virutal e boletsoeng.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // E sa fetoheng: kamora hore maemo ana a phethe ntle le ho khutla kapele
        // ho tloha phoso, ho kenella ha cache bakeng sa tsela ena ho index 0.

        if let Some(idx) = idx {
            // Ha 'mapa o se o le sebakeng sa polokelo, e fetisetse ka pele.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Ha 'mapa o se sebakeng sa polokelo, theha' mapa o mocha, o o kenye ka pele ho cache ebe o leleka sebaka sa khale sa cache ha ho hlokahala.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // u se ke oa lutla nako ea bophelo ea `'static`, etsa bonnete ba hore e iphumanetse rona feela
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Eketsa nako ea bophelo ba `sym` ho isa ho `'static` kaha ka bomalimabe ho hlokahala hore re fihle mona, empa ho lula ho le joalo ka ha ho buuoa ka hona ha ho moo ho buuoang ka eona ho lokelang ho phehelloa ho feta foreimi ena.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Kamora nako, fumana 'mapa o bolokiloeng ka marang-rang kapa u iketsetse' mapa o mocha oa faele ena, 'me u lekole leseli la DWARF ho fumana file/line/name bakeng sa aterese ena.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Re atlehile ho fumana leseli la foreimi bakeng sa letshwao lena, 'me foreimi ea `addr2line' kahare e na le lintlha tsohle tse khahlisang.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ha re fumane tlhahisoleseling ea bothata, empa re e fumane tafoleng ea matšoao ea elf e ka sebetsoang.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}