// e sebelisoa feela ho Linux hajoale, kahoo lumella khoutu e shoeleng kae kapa kae
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Kabelo e bonolo ea arena bakeng sa li-buffers tsa byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// E aba buffer ea boholo bo boletsoeng ebe e khutlisetsa ts'upiso e ka fetohang ho eona.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // TŠIRELETSO: ona ke oona feela mosebetsi o kileng oa khona ho fetoha
        // ho buuoa ka `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // TSHIRELETSO: ha ho mohla re tlosang likarolo ho `self.buffers`, ka hona, ke referense
        // ho data e kahare ho buffer efe kapa efe e tla phela ha feela `self` e phela.
        &mut buffers[i]
    }
}