use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::pe::{ImageDosHeader, ImageSymbol};
use object::read::pe::{ImageNtHeaders, ImageOptionalHeader, SectionTable};
use object::read::StringTable;
use object::{Bytes, LittleEndian as LE};

#[cfg(target_pointer_width = "32")]
type Pe = object::pe::ImageNtHeaders32;
#[cfg(target_pointer_width = "64")]
type Pe = object::pe::ImageNtHeaders64;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

pub struct Object<'a> {
    data: Bytes<'a>,
    sections: SectionTable<'a>,
    symbols: Vec<(usize, &'a ImageSymbol)>,
    strings: StringTable<'a>,
}

pub fn get_image_base(data: &[u8]) -> Option<usize> {
    let data = Bytes(data);
    let dos_header = ImageDosHeader::parse(data).ok()?;
    let (nt_headers, _, _) = dos_header.nt_headers::<Pe>(data).ok()?;
    usize::try_from(nt_headers.optional_header().image_base()).ok()
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = Bytes(data);
        let dos_header = ImageDosHeader::parse(data).ok()?;
        let (nt_headers, _, nt_tail) = dos_header.nt_headers::<Pe>(data).ok()?;
        let sections = nt_headers.sections(nt_tail).ok()?;
        let symtab = nt_headers.symbols(data).ok()?;
        let strings = symtab.strings();
        let image_base = usize::try_from(nt_headers.optional_header().image_base()).ok()?;

        // Bokella matšoao ohle ho vector ea lehae e hlophisitsoeng ka aterese mme e na le data e lekaneng ho ithuta ka lebitso la lets'oao.
        // Hlokomela hore re sheba feela matšoao a ts'ebetso hape re hlokomela hore likarolo li na le li-index tse 1 hobane karolo ea zero e khethehile (apparently).
        //
        //
        //
        let mut symbols = Vec::new();
        let mut i = 0;
        let len = symtab.len();
        while i < len {
            let sym = symtab.symbol(i).ok()?;
            i += 1 + sym.number_of_aux_symbols as usize;
            let section_number = sym.section_number.get(LE);
            if sym.derived_type() != object::pe::IMAGE_SYM_DTYPE_FUNCTION || section_number == 0 {
                continue;
            }
            let addr = usize::try_from(sym.value.get(LE)).ok()?;
            let section = sections
                .section(usize::try_from(section_number).ok()?)
                .ok()?;
            let va = usize::try_from(section.virtual_address.get(LE)).ok()?;
            symbols.push((addr + va + image_base, sym));
        }
        symbols.sort_unstable_by_key(|x| x.0);
        Some(Object {
            data,
            sections,
            strings,
            symbols,
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        Some(
            self.sections
                .section_by_name(self.strings, name.as_bytes())?
                .1
                .pe_data(self.data)
                .ok()?
                .0,
        )
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // Hlokomela hore ho fapana le mefuta e meng COFF ha e kenye boholo ba lets'oao ka leng.
        // E le boiteko ba ho qetela ba ho batla lets'oao le haufi haholo atereseng e itseng ebe o le khutlisa.
        // Sena se fumana wonky hantle hang ha matšoao a qala ho tlosoa hobane matšoao a khutlisitsoeng mona a ka ba a fosahetse ka ho felletseng, empa ha re na mohopolo oa ho tseba ho o tseba.
        //
        //
        //
        let addr = usize::try_from(addr).ok()?;
        let i = match self.symbols.binary_search_by_key(&addr, |p| p.0) {
            Ok(i) => i,
            // hangata `addr` ha e maemong, empa `i` ke moo re ka e kenyang teng, ka hona boemo ba pejana bo tlameha ho ba kholo ka tlase ho `addr`
            //
            //
            Err(i) => i.checked_sub(1)?,
        };
        self.symbols[i].1.name(self.strings).ok()
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}