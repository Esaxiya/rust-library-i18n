//! Leano la tšoantšetso le sebelisa khoutu ea ho khetholla DWARF ho libbacktrace.
//!
//! Laeborari ea libbacktrace C, eo hangata e ajoang le gcc, ha e tšehetse feela ho hlahisa mokokotlo (oo re sa o sebeliseng hantle) empa hape e tšoantšetsa mokokotlo le ho sebetsana le tlhaiso-leseling e fokolang ea bothata mabapi le lintho tse kang liforeimi tse thathamisitsoeng le eng.
//!
//!
//! Sena se batla se rarahane ka lebaka la mathata a mangata a fapaneng mona, empa mohopolo oa mantlha ke:
//!
//! * Pele re bitsa `backtrace_syminfo`.Sena se fumana leseli la matšoao ho tsoa tafoleng e matla ea matšoao haeba re khona.
//! * E latelang re letsetsa `backtrace_pcinfo`.Sena se tla hlahloba litafole tsa debuginfo haeba li le teng 'me li re lumelle ho fumana tlhaiso-leseling ka liforeimi tse inline, mabitso a lifilimi, linomoro tsa mohala, jj.
//!
//! Ho na le mano a mangata mabapi le ho kenya litafole tse nyane ho libbacktrace, empa ka ts'epo ha se pheletso ea lefats'e mme e hlakile ka ho lekana ha u bala ka tlase.
//!
//! Ona ke leano la kamehla la tšoantšetso bakeng sa sethala se seng sa MSVC le se seng sa OSX.Ho libstd leha ona e le leano la kamehla la OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Haeba ho khonahala khetha lebitso la `function` le tsoang ho debuginfo mme hangata le ka nepahala bakeng sa liforeimi tse inline ka mohlala.
                // Haeba seo ha se eo leha o ka khutlela lebitsong la tafole ea lets'oao le boletsoeng ho `symname`.
                //
                // Hlokomela hore ka linako tse ling `function` e ka ikutloa e sa nepahala hanyane, ka mohlala ho thathamisoa e le `try<i32,closure>` isntead of `std::panicking::try::do_call`.
                //
                // Ha ho hlake hantle hore na hobaneng, empa ka kakaretso lebitso la `function` le bonahala le nepahetse.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // u se ke oa etsa letho hajoale
}

/// Mofuta oa sesupa sa `data` o fetetse ho `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Hang ha callback ena e sebelisoa ho tloha ho `backtrace_syminfo` ha re qala ho rarolla re ea pele ho letsetsa `backtrace_pcinfo`.
    // Mosebetsi oa `backtrace_pcinfo` o tla sheba tlhaiso-leseling ea bothata le ho leka ho etsa lintho tse kang ho fumana leseli la file/line hammoho le liforeimi tse manehiloeng.
    // Hlokomela leha `backtrace_pcinfo` e ka hloleha kapa ea se ke ea etsa ho hongata haeba ho se na leseli la bothata, kahoo haeba seo se etsahala re na le bonnete ba hore re tla letsetsa callback bonyane letshwao le le leng ho tloha ho `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Mofuta oa sesupa sa `data` o fetetse ho `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API e ts'ehetsa ho theha naha, empa ha e tšehetse ho senya mmuso.
// Ka bonna ke nka hore sena se bolela hore mmuso o reretsoe ho theoa ebe o phela ka ho sa feleng.
//
// Ke kopa ho ngodisa motsamaisi oa at_exit() ea hloekisang naha ena, empa libbacktrace ha e fane ka mokhoa oa ho etsa joalo.
//
// Ka lithibelo tsena, mosebetsi ona o na le boemo bo bolokiloeng ka palo bo baloang lekhetlo la pele ha sena se kopuoa.
//
// Hopola hore ho chechela morao hohle ho etsahala ka tatellano (senotlolo se le seng sa lefats'e).
//
// Hlokomela ho haella ha khokahano mona ho bakoa ke tlhoko ea hore `resolve` e hokahantsoe kantle.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Se ke oa ikoetlisa ka bokhoni ba ho khutlisa marang-rang kaha re lula re e bitsa ka mokhoa o lumellanang.
        //
        0,
        error_cb,
        ptr::null_mut(), // ha ho na data e eketsehileng
    );

    return STATE;

    // Hlokomela hore bakeng sa libbacktrace hore e sebetse ho hang e hloka ho fumana leseli la DWARF la bothata bakeng sa se ka sebetsoang hajoale.E etsa joalo ka mekhoa e mengata ho kenyelletsa, empa e sa felle feela ho:
    //
    // * /proc/self/exe ka lipolanete tse tšehelitsoeng
    // * Lebitso la file le fetisitsoe ka ho hlaka ha le theha naha
    //
    // Laeborari ea libbacktrace ke wad e kholo ea khoutu ea C.Sena ka tlhaho se bolela hore se na le ts'ireletso ea ts'ireletso ea mohopolo, haholo ha o sebetsana le debuginfo e nang le bothata.
    // Libstd o bile le bongata ba tsena nalaneng.
    //
    // Haeba /proc/self/exe e sebelisoa joale ka tloaelo re ka e hlokomoloha ha re ntse re nahana hore libbacktrace ke "mostly correct" mme ha ho joalo ha e etse lintho tse makatsang ka lintlha tsa "attempted to be correct" tsa bothata ba bothata.
    //
    //
    // Haeba re feta ka lebitso la file, leha ho le joalo, ho ka etsahala ho li-platform tse ling (joalo ka li-BSD) moo sebapali se kotsi se ka etsang hore faele e hatelloang e beoe sebakeng seo.
    // Sena se bolela hore haeba re bolella libbacktrace mabapi le lebitso la file e kanna ea ba e sebelisa faele e hatellang, mohlomong e baka likhetho.
    // Haeba re sa bolelle libbacktrace letho leha ho le joalo e ke ke ea etsa letho ho sethala se sa tšehetseng litsela tse kang /proc/self/exe!
    //
    // Ka lebaka la sohle seo re lekang ka hohle kamoo ho ka khonehang ho *se* feta ka lebitso la file, empa re tlameha ho li-platform tse sa tšeheng /proc/self/exe ho hang.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Hlokomela hore re ka sebelisa `std::env::current_exe`, empa re ke ke ra hloka `std` mona.
            //
            // Sebelisa `_NSGetExecutablePath` ho kenya tsela ea hona joale e ka sebelisoang sebakeng se tsitsitseng (eo haeba e le nyane haholo tlohella feela).
            //
            //
            // Hlokomela hore re ts'epa libbacktrace mona ka matla hore re se ke ra shoa ho ba bolailoeng ba bolileng, empa ehlile e joalo ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows E na le mokhoa oa ho bula lifaele moo ka mor'a hore e bule e ke keng ea hlakoloa.
            // Ka kakaretso ke seo re se batlang mona hobane re batla ho etsa bonnete ba hore se ka sebetsoang ha se fetohe ho tloha tlasa rona kamora hore re se fetisetse ho libbacktrace, ka ts'epo re fokotsa bokhoni ba ho fetisa tlhaiso-leseling e kenang ho libbacktrace (e kanna ea tšoaroa hampe).
            //
            //
            // Kaha re tants'a mona ho leka ho fumana mofuta oa senotlolo setšoantšong sa rona:
            //
            // * Fumana sesebedisoa molemong oa hona joale, laela lebitso la eona la lebitso.
            // * Bula faele lebitsong leo ka lifolakha tse nepahetseng.
            // * Khutlisetsa lebitso la lebitso la ts'ebetso hona joale, ho etsa bonnete ba hore lea tšoana
            //
            // Haeba tsohle li feta ka mohopolo re hlile re butse file ea ts'ebetso ea rona mme re netefalitsoe hore e ke ke ea fetoha.FWIW sehlopha sa sena se kopilitsoe ho tsoa libstd nalaneng, ka hona ena ke eona tlhaloso ea ka e ntle ea se neng se etsahala.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Sena se phela ka sehopotso sa static hore re tle re se khutlise ..
                static mut BUF: [i8; N] = [0; N];
                // ... 'me sena se lula mokhoeng kaha ke oa nakoana
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ka boomo ho lutla `handle` mona hobane ho e bula ho lokela ho boloka senotlolo sa rona lebitsong lena la faele.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Re batla ho khutlisa selae se felisitsoeng, kahoo haeba ntho e ngoe le e ngoe e tlatsitsoe 'me e lekana le bolelele bohle joale e lekane ho hloleha.
                //
                //
                // Ho seng joalo ha u khutla katleho etsa bonnete ba hore nul byte e kenyellelitsoe selae.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Liphoso tsa backtrace hajoale li fietsoe tlasa mmete
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Letsetsa `backtrace_syminfo` API eo (ho tloha ha u bala khoutu) e lokelang ho letsetsa `syminfo_cb` hang hang (kapa ho hloleha ka phoso mohlomong).
    // Ebe re sebetsana le tse ling kahare ho `syminfo_cb`.
    //
    // Hlokomela hore re etsa sena ho tloha ha `syminfo` e tla sheba tafoleng ea matšoao, e fumane mabitso a matšoao le haeba ho se na leseli la bothata ka binary.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}