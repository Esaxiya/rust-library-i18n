use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Rarolla aterese ho lets'oao, u fetisetse lets'oao ho koaloa ho boletsoeng.
///
/// Ts'ebetso ena e tla sheba aterese e fanoeng libakeng tse joalo ka tafole ea matšoao ea lehae, tafole e matla ea matšoao, kapa tlhaiso-leseling ea DWARF debug (ho latela ts'ebetsong e kentsoeng tšebetsong) ho fumana matšoao a ho hlahisa.
///
///
/// Ho koaloa ho kanna ha se ke hoa bitsoa haeba qeto e ne e ke ke ea etsoa, hape e ka bitsoa makhetlo a fetang a le mong ha ho na le mesebetsi e manehiloeng.
///
/// Matšoao a hlahisitsoeng a emetse ts'ebetso ho `addr` e boletsoeng, a khutlisa lipara tsa file/line bakeng sa aterese eo (haeba e teng).
///
/// Hlokomela hore haeba u na le `Frame` ho kgothaletswa hore o sebelise mosebetsi oa `resolve_frame` ho fapana le ona.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
/// # Panics
///
/// Mosebetsi ona o loanela hore le ka mohla o se ke oa ba panic, empa haeba `cb` e fane ka panics joale lipolanete tse ling li tla qobella panic habeli ho ntša tšebetso.
/// Lipolanete tse ling li sebelisa laeborari ea C eo kahare e sebelisang litšitiso tse ke keng tsa senyeha, ka hona ho ts'oha `cb` ho ka baka ts'ebetso ea ho ntša mpa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // sheba feela foreime holimo
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Rarolla foreime e nkiloeng pele ho lets'oao, u fetise lets'oao ho koaloa ho boletsoeng.
///
/// Functin ena e etsa mosebetsi o ts'oanang le `resolve` ntle le hore e nka `Frame` e le khang sebakeng sa aterese.
/// Sena se ka lumella ts'ebetsong e 'ngoe ea sethala sa marang-rang ho fana ka tlhaiso-leseling e nepahetseng ea matšoao kapa tlhaiso-leseling ka liforeimi tse inline ka mohlala.
///
/// Ho kgothaletswa ho sebelisa sena ha o khona.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
/// # Panics
///
/// Mosebetsi ona o loanela hore le ka mohla o se ke oa ba panic, empa haeba `cb` e fane ka panics joale lipolanete tse ling li tla qobella panic habeli ho ntša tšebetso.
/// Lipolanete tse ling li sebelisa laeborari ea C eo kahare e sebelisang litšitiso tse ke keng tsa senyeha, ka hona ho ts'oha `cb` ho ka baka ts'ebetso ea ho ntša mpa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // sheba feela foreime holimo
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Litekanyetso tsa IP ho tsoa ho liforeimi tse bokellaneng hangata ke (always?) taelo *kamora* mohala oo e leng 'ona mokhoa oa' nete oa pokello.
// Ho tšoantšetsa sena ho etsa hore nomoro ea filename/line e be e 'ngoe pele mme mohlomong e kene lefeela haeba e se e le haufi le pheletso ea mosebetsi.
//
// Hona ho bonahala ho lula ho le joalo lipulong tsohle, ka hona re lula re tlosa e le 'ngoe ho ip e rarollotsoeng ho e rarolla taelong ea mohala o fetileng ho fapana le hore taelo e khutlisetsoe.
//
//
// Ka nepo re ke ke ra etsa sena.
// Ka nepo re ka hloka hore batho ba letsetsang li-API tsa `resolve` mona ba etse -1 ka letsoho ebe ba ikarabella hore ba batla tlhaiso-leseling ea sebaka bakeng sa taelo ea * pejana, eseng ea hajoale.
// Ka nepo re ka boela ra pepesa `Frame` haeba kannete re aterese ea taelo e latelang kapa ea hajoale.
//
// Hajoale leha sena e le kameho e ntle ea marang-rang kahoo re lula re tlosa e le 'ngoe kahare.
// Bareki ba lokela ho lula ba sebetsa le ho fumana litholoana tse ntle haholo, ka hona re lokela ho ba ba lekaneng.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// E ts'oana le `resolve`, feela e sa bolokeha kaha ha e lumellane.
///
/// Mosebetsi ona ha o na li-guarentee tsa khokahano empa oa fumaneha ha karolo ea `std` ea crate ena e sa hlophisoa.
/// Bona mosebetsi oa `resolve` bakeng sa litokomane tse ling le mehlala.
///
/// # Panics
///
/// Bona tlhahisoleseling ho `resolve` bakeng sa mahaha a `cb` ho tšoha.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// E ts'oana le `resolve_frame`, feela e sa bolokeha kaha ha e lumellane.
///
/// Mosebetsi ona ha o na li-guarentee tsa khokahano empa oa fumaneha ha karolo ea `std` ea crate ena e sa hlophisoa.
/// Bona mosebetsi oa `resolve_frame` bakeng sa litokomane tse ling le mehlala.
///
/// # Panics
///
/// Bona tlhahisoleseling ho `resolve_frame` bakeng sa mahaha a `cb` ho tšoha.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait e emelang qeto ea lets'oao faeleng.
///
/// trait ena e hlahisoa e le ntho ea trait ho koalo e fuoeng ts'ebetso ea `backtrace::resolve`, 'me e romelloa ka mokhoa o sa tsejoeng hore na ke ts'ebetsong efe e kamora eona.
///
///
/// Letšoao le ka fana ka tlhaiso-leseling e mabapi le ts'ebetso, mohlala lebitso, filename, nomoro ea mohala, aterese e nepahetseng, jj.
/// Ha se tlhaiso-leseling eohle e fumanehang ka linako tsohle ka letshwao, leha ho le joalo, mekhoa eohle e khutlisa `Option`.
///
///
pub struct Symbol {
    // TODO: tlamo ena ea bophelo bohle e hloka ho phehelloa qetellong ho fihlela `Symbol`,
    // empa hajoale ke phetoho e senyehang.
    // Hajoale sena se bolokehile kaha `Symbol` e fuoa feela ka litšupiso ebile e ke ke ea etsoa ka mokhoa o le mong.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// E khutlisa lebitso la ts'ebetso ena.
    ///
    /// Sebopeho se khutlisitsoeng se ka sebelisoa ho botsa thepa e fapaneng ka lebitso la letshwao:
    ///
    ///
    /// * Ts'ebetso ea `Display` e tla hatisa lets'oao le sentsoeng.
    /// * Boleng ba `str` bo botala ba lets'oao bo ka fihlelleha (haeba e nepahetse utf-8).
    /// * Li-byte tse tala tsa lebitso la lets'oao li ka fumaneha.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// E khutlisa aterese e qalang ea tšebetso ena.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// E khutlisa lebitso la file e tala e le selae.
    /// Sena se thusa haholo bakeng sa libaka tsa `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// E khutlisetsa nomoro ea kholomo bakeng sa moo letšoao lena le sebetsang hona joale.
    ///
    /// Ke feela gimli hajoale e fanang ka boleng mona le ha ho le joalo ha `filename` e khutlisa `Some`, ka hona ka lebaka leo e tlasa lithibelo tse tšoanang.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// E khutlisetsa nomoro ea mohala moo letshwao lena le sebetsang hona joale.
    ///
    /// Boleng bona ba ho khutlisa hangata ke `Some` haeba `filename` e khutlisa `Some`, 'me ka lebaka leo e tlas'a litemoso tse tšoanang.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// E khutlisetsa lebitso la faele moo tšebetso ena e hlalositsoeng.
    ///
    /// Hona joale ho fumaneha feela ha libbacktrace kapa gimli e ntse e sebelisoa (mohlala
    /// unix lipolanete tse ling) le ha binary e hlophisoa le debuginfo.
    /// Haeba le ha e le efe ea lipehelo tsena e sa fihlelloe, e kanna ea khutla `None`.
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mohlomong lets'oao la C++ le arotsoeng, haeba ho hlakola lets'oao le nang le mangled joalo ka Rust ho hloleha.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Etsa bonnete ba hore o boloka boholo ba zero ena, hore karolo ea `cpp_demangle` e se ke ea ba le litšenyehelo ha e holofetse.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Sekoahelo se potileng lebitso la letšoao ho fana ka li-ergonomic accessers lebitsong le sentsoeng, li-byte tse tala, khoele e tala, jj.
///
// Lumella khoutu e shoeleng ha karolo ea `cpp_demangle` e sa lumelloa.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// E theha lebitso le lecha la letšoao ho tsoa ho li-byte tse tala tse tala.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// E khutlisa lebitso la lets'oao la (mangled) e le `str` haeba letshwao le nepahetse utf-8.
    ///
    /// Sebelisa ts'ebetsong ea `Display` haeba u batla mofuta o sentsoeng.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// E khutlisa lebitso la lets'oao le tala e le lenane la li-byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Sena se kanna sa hatisoa haeba lets'oao le tlotsitsoeng le sa sebetse, ka hona sebetsana le phoso mona ka bokhabane ka ho se e phatlalatse kantle.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Leka ho khutlisa mohopolo o bolokiloeng o sebelisitsoeng ho tšoantšetsa liaterese.
///
/// Mokhoa ona o tla leka ho lokolla likarolo life kapa life tsa lefats'e tse bolokiloeng ka mokhoa o fapaneng lefats'eng ka bophara kapa ka khoele e emelang tlhaiso-leseling ea DWARF kapa e ts'oanang.
///
///
/// # Caveats
///
/// Le ha mosebetsi ona o lula o le teng ha o hlile ha o etse letho ts'ebetsong e ngata.
/// Lilaeborari tse kang dbghelp kapa libbacktrace ha li fane ka lisebelisoa tsa ho tsamaisa mmuso le ho tsamaisa mohopolo o fanoeng.
/// Hajoale karolo ea `gimli-symbolize` ea crate ke eona feela tšobotsi eo mosebetsi ona o nang le tšusumetso ho eona.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}