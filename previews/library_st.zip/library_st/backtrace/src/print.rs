#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Moqapi oa li-backtraces.
///
/// Mofuta ona o ka sebelisoa ho hatisa mokokotlo ho sa tsotelehe hore na backtrace ka boeona e tsoa kae.
/// Haeba u na le mofuta oa `Backtrace` joale ts'ebetsong ea eona ea `Debug` e se e ntse e sebelisa mofuta ona oa khatiso.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Mekhoa ea khatiso eo re ka e hatisang
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// E hatisa mokokotlo oa terser o nang le tlhaiso-leseling e nepahetseng feela
    Short,
    /// Hatisa mokokotlo o nang le tlhaiso-leseling eohle e ka bang teng
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Theha `BacktraceFmt` e ncha e tla ngola tlhahiso ho `fmt` e fanoeng.
    ///
    /// Khang ea `format` e tla laola mokhoa oo mokokotlo o hatisitsoeng ka oona, 'me khang ea `print_path` e tla sebelisoa ho hatisa liketsahalo tsa `BytesOrWideString` tsa li-filename.
    /// Mofuta ona ka boeona ha o hatise mabitso a lifilimi, empa ho hlokahala hore u khutlisoe hape.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Hatisa selelekela sa mokokotlo o mothating oa ho hatisoa.
    ///
    /// Sena se hlokahala ho li-platform tse ling tsa li-backtraces hore li tšoantšetsoe ka botlalo hamorao, ho seng joalo ena e lokela ho ba mokhoa oa pele oo u o bitsang kamora ho theha `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// E eketsa foreimi ho tlhahiso ea backtrace.
    ///
    /// Boitlamo bona bo khutlisetsa mohlala oa RAII oa `BacktraceFrameFmt` o ka sebelisoang ho hatisa foreimi, 'me ts'enyehong e tla eketsa k'haontara ea foreimi.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// E phethela tlhahiso ea mokokotlo.
    ///
    /// Hona joale ha ho na op-op empa e kenyellelitsoe ts'ebetsong ea future le lifomate tsa backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Hajoale ha ho na op-ho kenyelletsa sena hook ho lumella likeketso tsa future.
        Ok(())
    }
}

/// Sebopeho sa foreimi e le 'ngoe feela ea mokokotlo.
///
/// Mofuta ona o entsoe ke ts'ebetso ea `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// E hatisa `BacktraceFrame` ka fomate ena ea foreimi.
    ///
    /// Sena se tla hatisa ka makhetlo-khetlo maemo ohle a `BacktraceSymbol` kahare ho `BacktraceFrame`.
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// E hatisa `BacktraceSymbol` kahare ho `BacktraceFrame`.
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: sena ha se monate hore ebe ha re qetelle re hatisa letho
            // ka mabitso a se nang utf8.
            // Ka lehlohonolo hoo e batlang e le ntho e ngoe le e ngoe ke utf8 kahoo sena ha sea lokela ho ba mpe haholo.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// E hatisa `Frame` le `Symbol` e tala, hangata e tsoang kahare ho likoli tse sa sebetseng tsa crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// E eketsa foreimi e tala ho tlhahiso ea backtrace.
    ///
    /// Mokhoa ona, ho fapana le o fetileng, o nka likhang tse tala haeba li tsoa libakeng tse fapaneng.
    /// Hlokomela hore sena se ka bitsoa makhetlo a mangata bakeng sa foreimi e le 'ngoe.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// E eketsa foreimi e tala ho tlhahiso ea backtrace, ho kenyelletsa le tlhaiso-leseling ea kholomo.
    ///
    /// Mokhoa ona, joalo ka oa pejana, o nka likhang tse tala haeba li ka tsoa libakeng tse fapaneng.
    /// Hlokomela hore sena se ka bitsoa makhetlo a mangata bakeng sa foreimi e le 'ngoe.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ha e khone ho tšoantšetsa ts'ebetsong ka hona e na le sebopeho se ikhethang se ka sebelisoang ho tšoantšetsa hamorao.
        // Hatisa seo ho fapana le ho hatisa liaterese ka sebopeho sa rona mona.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ha ho na tlhoko ea ho hatisa liforeimi tsa "null", ha e le hantle ho bolela feela hore backtrace ea sistimi e ne e labalabela ho fumana morao haholo.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ho fokotsa boholo ba TCB sebakeng sa Sgx, ha re batle ho kenya tšebetsong ts'ebetso ea tharollo ea matšoao.
        // Ho fapana le moo, re ka hatisa offset ea aterese mona, e ka 'nang ea etsoa' mapa hamorao ho lokisa tšebetso.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Hatisa index ea foreimi hammoho le sesupa-tsela sa boikhethelo sa foreimi.
        // Haeba re fetile lets'oao la pele la foreimi ena leha re ntse re hatisa sebaka se tšoeu sa tšoeu.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ka mor'a moo ngola lebitso la letšoao, u sebelisa mokhoa o mong oa ho fomata bakeng sa tlhaiso-leseling e batsi haeba re le mokokotlo o felletseng.
        // Mona re boetse re sebetsana le matšoao a se nang lebitso,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Qetellong, hatisa nomoro ea filename/line haeba e fumaneha.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line li hatisitsoe meleng e ka tlasa lebitso la lets'oao, ka hona, hatisa sebaka se tšoeu se loketseng ho itlhophisa hantle.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Abela motho eo re mo letsetsang kahare ho hatisa lebitso la file ebe o printa nomoro ea mohala.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Kenya nomoro ea kholomo, haeba e teng.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Re tsotella feela letšoao la pele la foreimi
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}