use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Boemeli ba mokokotlo o nang le thepa le o nang le eona.
///
/// Sebopeho sena se ka sebelisoa ho ts'oara mokokotlo lintlheng tse fapaneng lenaneong mme hamorao sa sebelisoa ho lekola mokokotlo o neng o le ka nako eo.
///
///
/// `Backtrace` e ts'ehetsa khatiso e ntle ea li-backtrace ka ts'ebetsong ea eona ea `Debug`.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Liforeimi mona li thathamisitsoe ho tloha holimo ho isa tlase ea mokotla
    frames: Vec<BacktraceFrame>,
    // Lenane leo re lumelang hore ke lona qalo ea mokokotlo, re tlohella liforeimi tse kang `Backtrace::new` le `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Mofuta o hapuoeng oa foreimi mokokotlong.
///
/// Mofuta ona o khutlisoa e le lenane ho tsoa ho `Backtrace::frames` mme o emetse foreimi e le 'ngoe ea pokello mokokotlong o hapiloeng.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Mofuta o nkiloeng oa lets'oao ka mokokotlo.
///
/// Mofuta ona o khutlisoa e le lenane ho tsoa `BacktraceFrame::symbols` mme o emela metadata ea letshwao mokokotlong.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// E hapa mokokotlo litsing tsa mohala tsa ts'ebetso ena, e khutlisetsang boemeli ba eona.
    ///
    /// Mosebetsi ona o na le thuso bakeng sa ho emela mokokotlo oa morao e le ntho ho Rust.Boleng bona bo khutlisitsoeng bo ka romelloa ka likhoele ebe bo hatisoa kae kapa kae, 'me sepheo sa boleng bona ke ho ba teng ka botlalo.
    ///
    /// Hlokomela hore lipolaneteng tse ling ho fumana mokokotlo o felletseng le ho li rarolla ho ka ba theko e boima haholo.
    /// Haeba theko e le ngata haholo bakeng sa ts'ebeliso ea hau, ho kgothaletswa hore o sebelise `Backtrace::new_unresolved()` e qobang mohato oa tharollo ea matšoao (eo hangata o nkang nako e telele ka ho fetesisa) mme o lumella ho e beha morao hamorao.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // batla ho etsa bonnete ba hore ho na le foreimi mona ho e tlosa
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// E ts'oana le `new` ntle le hore sena ha se rarolle matšoao afe kapa afe, sena se nka feela mokokotlo e le lenane la liaterese.
    ///
    /// Hamorao mosebetsi oa `resolve` o ka bitsoa ho rarolla matšoao a mokokotlo ona ka mabitso a balehang.
    /// Mosebetsi ona o teng hobane ka linako tse ling mohato oa tharollo o ka nka nako e ngata empa moelelo o le mong oa morao o ka hatisoa ka seoelo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // haho mabitso a matshwao
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // mabitso a tšoantšetso a teng hona joale
    /// ```
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    ///
    #[inline(never)] // batla ho etsa bonnete ba hore ho na le foreimi mona ho e tlosa
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// E khutlisa liforeimi ho tloha ha mokokotlo ona o hapuoe.
    ///
    /// Keno ea pele ea selae sena e kanna ea ba mosebetsi `Backtrace::new`, mme foreimi ea ho qetela e kanna ea ba ho hong ka hore na khoele ena kapa mosebetsi o ka sehloohong o qalile joang.
    ///
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Haeba mokokotlo ona o entsoe ho tloha `new_unresolved`, ts'ebetso ena e tla rarolla liaterese tsohle tse ka morao ho mabitso a tsona a tšoantšetso.
    ///
    ///
    /// Haeba mokokotlo ona o kile oa rarolloa pejana kapa oa etsoa ka `new`, ts'ebetso ena ha e etse letho.
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// E ts'oana le `Frame::ip`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// E ts'oana le `Frame::symbol_address`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// E ts'oana le `Frame::module_base_address`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// E khutlisa lenane la matšoao leo foreimi ena e tsamaellanang le lona.
    ///
    /// Ka tloaelo ho na le letšoao le le leng feela ka foreime, empa ka linako tse ling haeba mesebetsi e mengata e tšoaetsoe ka foreimi e le 'ngoe ho tla khutlisoa matšoao a mangata.
    /// Letšoao la pele le thathamisitsoeng ke "innermost function", athe letšoao la hoqetela ke la kantle ho motho (ea letsitseng la ho qetela).
    ///
    /// Hlokomela hore haeba foreimi ena e tsoa mokokotlong o sa rarolloang joale sena se tla khutlisa lenane le se nang letho.
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// E ts'oana le `Symbol::name`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// E ts'oana le `Symbol::addr`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// E ts'oana le `Symbol::filename`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// E ts'oana le `Symbol::lineno`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// E ts'oana le `Symbol::colno`
    ///
    /// # Lintho tse hlokahalang
    ///
    /// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ha re hatisa litsela re leka ho hlobolisa cwd haeba e le teng, ho seng joalo re hatisa tsela eo e leng ka eona.
        // Hlokomela hore le rona re etsa sena feela bakeng sa fomate e khuts'oane, hobane haeba e tletse re kanna ra batla ho hatisa tsohle.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}