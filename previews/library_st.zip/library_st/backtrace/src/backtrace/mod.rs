use core::ffi::c_void;
use core::fmt;

/// E hlahloba pokello ea mohala ea hajoale, e fetisa liforeimi tsohle tse kenang ho koalo e fanoeng ho fumana tšalo-morao.
///
/// Mosebetsi ona ke mosebetsi oa laeborari ena ha ho baloa litselana tsa lenaneo.Ho koaloa ho fanoeng ha `cb` ho hlahisitsoe ke `Frame` e emelang tlhaiso-leseling ka foreimi ea mohala ka har'a sethala.
/// Ho koaloa ho hlahisitsoe liforeimi ka feshene e holimo haholo (e sa tsoa bitsoa mesebetsi pele).
///
/// Boleng ba ho khutla ba ho koaloa ke sesupo sa hore na mokokotlo o lokela ho tsoela pele.Boleng ba ho khutlisa ba `false` bo tla emisa mokokotlo ebe bo khutla hanghang.
///
/// Hang ha `Frame` e fumaneha u tla batla ho letsetsa `backtrace::resolve` ho fetolela `ip` (pointer ea tataiso) kapa aterese ea letšoao ho `Symbol` eo lebitso le/kapa filename/nomoro ea mohala e ka ithutoang.
///
///
/// Hlokomela hore ona ke mosebetsi o maemong a tlase mme haeba o ka rata, ho etsa mohlala, ho ts'oara mokokotlo o tla hlahlojoa hamorao, mofuta oa `Backtrace` o kanna oa nepahala.
///
/// # Lintho tse hlokahalang
///
/// Ts'ebetso ena e hloka hore karolo ea `std` ea `backtrace` crate e lumelloe, 'me karolo ea `std` e lumelloe ka boiketsetso.
///
/// # Panics
///
/// Mosebetsi ona o loanela hore le ka mohla o se ke oa ba panic, empa haeba `cb` e fane ka panics joale lipolanete tse ling li tla qobella panic habeli ho ntša tšebetso.
/// Lipolanete tse ling li sebelisa laeborari ea C eo kahare e sebelisang litšitiso tse ke keng tsa senyeha, ka hona ho ts'oha `cb` ho ka baka ts'ebetso ea ho ntša mpa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ntšetsa pele mokokotlo
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// E ts'oana le `trace`, feela e sa bolokeha kaha ha e lumellane.
///
/// Mosebetsi ona ha o na li-guarentee tsa khokahano empa oa fumaneha ha karolo ea `std` ea crate ena e sa hlophisoa.
/// Bona mosebetsi oa `trace` bakeng sa litokomane tse ling le mehlala.
///
/// # Panics
///
/// Bona tlhahisoleseling ho `trace` bakeng sa mahaha a `cb` ho tšoha.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait e emelang foreimi e le 'ngoe ea mokokotlo, e fane ka ts'ebetso ea `trace` ea crate.
///
/// Ho koaloa ha mosebetsi oa tšalo-morao e tla ba liforeimi tse hlahisitsoeng, 'me foreimi e romelloa joalo ka ha ts'ebetsong ea motheo e sa tsejoe kamehla ho fihlela nako ea ts'ebetso.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// E khutlisa sesupisi sa hajoale sa foreimi ena.
    ///
    /// Ka tloaelo ena ke taelo e latelang eo u lokelang ho e etsa kahara foreimi, empa ha se lits'ebetso tsohle tse thathamisang sena ka ho nepahala ka 100% (empa hangata e haufi haholo).
    ///
    ///
    /// Ho kgothaletswa ho fetisetsa boleng bona ho `backtrace::resolve` ho e fetola lebitso la letšoao.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// E khutlisa sesupa-nako sa hona joale sa sethala sa foreimi ena.
    ///
    /// Maemong a hore mokokotlo o sitoa ho khutlisa sesupa-hlooho bakeng sa foreimi ena, sesupi se sa sebetseng sea khutlisoa.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// E khutlisetsa aterese ea lets'oao la qalo ea foreimi ea tšebetso ena.
    ///
    /// Sena se tla leka ho khutlisetsa morao sesupa-taelo se khutlisitsoeng ke `ip` qalong ea ts'ebetso, ho khutlisa boleng boo.
    ///
    /// Maemong a mang, leha ho le joalo, morao-rao o tla khutlisa `ip` ho tsoa mosebetsing ona.
    ///
    /// Ka linako tse ling boleng bo khutlisitsoeng bo ka sebelisoa haeba `backtrace::resolve` e sa atlehe ho `ip` e fanoeng kaholimo.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// E khutlisetsa aterese ea mantlha ea module eo foreimi e leng ea eona.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Sena se hloka ho tla pele, ho netefatsa hore Miri o etelletsa pele sethaleng sa moamoheli
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // e sebelisoa feela ho tšoantšetsa dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}