#![feature(no_core)]
#![no_core]

// Bona rustc-std-workspace-core ea hore na hobaneng crate e hlokahala.

// Reha crate rename ho qoba ho thulana le module ea module e liballoc.
extern crate alloc as foo;

pub use foo::*;