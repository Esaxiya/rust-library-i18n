use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Sena ha se sebaka se tsitsitseng, empa se thusa ho boloka `?` e le theko e tlase lipakeng tsa bona, le ha LLVM e sa khone ho e sebelisa hona joale.
    //
    // (Ka masoabi Sephetho le Khetho ha li lumellane, ka hona ControlFlow e ke ke ea tšoana ka bobeli.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}