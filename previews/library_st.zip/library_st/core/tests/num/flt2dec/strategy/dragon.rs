use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri o lieha haholo
fn exact_sanity_test() {
    // Teko ena e qetella e sebetsa ka seo nka nahanang feela hore ke khetsi ea `exp2` ea laeborari, e hlalositsoeng ho nako efe kapa efe ea C eo re e sebelisang.
    // Ho VS 2013 ts'ebetso ena ho bonahala e ne e na le bothata ha tlhahlobo ena e hloleha ha e hokahantsoe, empa ka VS 2015 kokoana-hloko e bonahala e tsitsitse ha tlhahlobo e ntse e sebetsa hantle.
    //
    // Bokhopo bo bonahala e le phapang ea boleng bo khutlang ba `exp2(-1057)`, moo VS 2013 e khutlisang habeli ka paterone 0x2 mme ho VS 2015 e khutlisa 0x20000.
    //
    //
    // Hajoale, hlokomoloha teko ena ka botlalo ho MSVC kaha e lekoa kae kapa kae mme ha re na tjantjello e kholo ea ho leka ts'ebetsong e ngoe le e ngoe ea exp2 ea sethala.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}