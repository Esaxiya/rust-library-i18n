#![stable(feature = "core_hint", since = "1.27.0")]

//! Malebela a ho bokella a amang tsela eo khoutu e lokelang ho ntšoa kapa ho ntlafatsoa ka eona.
//! Malebela e ka ba ho bokella nako kapa nako ea ho matha.

use crate::intrinsics;

/// E tsebisa moqapi hore ntlha ena ea khoutu ha e fihlellehe, e nolofalletsa lintlafatso tse ling.
///
/// # Safety
///
/// Ho fihlella ts'ebetso ena ke boits'oaro bo sa hlalosoang ka botlalo * (UB).Ka ho khetheha, motlatsi o nka hore UB ha ea lokela ho etsahala le ka mohla, ka hona e tla felisa makala ohle a fihlelang pitso ho `unreachable_unchecked()`.
///
/// Joalo ka maemo ohle a UB, haeba mohopolo ona o ka fosahetse, ke hore, mohala oa `unreachable_unchecked()` o ka fihlelleha hara phallo eohle e ka bang teng ea taolo, mohokisi o tla sebelisa leano le fosahetseng la ntlafatso, mme ka linako tse ling a ka ba a senya khoutu e bonahalang e sa amane ho rarolla mathata.
///
///
/// Sebelisa ts'ebetso ena ha feela u ka paka hore khoutu eo e ke ke ea e bitsa.
/// Ho seng joalo, nahana ka ho sebelisa [`unreachable!`] macro, e sa lumelleng ho ntlafatsa empa e tla panic ha e bolaoa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` e lula e na le tšepo (eseng zero), ka hona `checked_div` ha e sa tla khutla `None`.
/////
///     // Ka hona, branch e ngoe ha e fumanehe.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // TSHIRELETSO: konteraka ya polokeho ya `intrinsics::unreachable` e tlameha
    // tshoareloa ke ya letsitseng.
    unsafe { intrinsics::unreachable() }
}

/// E fana ka taelo ea mochini ho tšoaea processor hore e ntse e sebetsa ka mokhoa o maphathaphathe oa ho emisa spin ("spin lock").
///
/// Ha e amohela lets'oao la spin-loop processor e ka ntlafatsa boits'oaro ba eona, ka mohlala, ho boloka matla kapa ho chencha likhoele tsa hyper.
///
/// Mosebetsi ona o fapane le [`thread::yield_now`] e fanang ka kotloloho ho kemiso ea sistimi, athe `spin_loop` ha e sebelisane le sistimi e sebetsang.
///
/// Nyeoe e tloaelehileng ea ts'ebeliso bakeng sa `spin_loop` e kenya tšebetsong ts'epo e nang le ts'epo molemong oa CAS ho li-primitives tsa khokahano.
/// Ho qoba mathata a kang ho khelosoa hoa mantlha, ho khothaletsoa ka matla hore spin ea loop e emisoe kamora ho phetoa ho lekantsoeng mme ho entsoe syscall e loketseng.
///
///
/// **Tlhokomeliso**: Lipulatifomong tse sa tšehetseng ho amohela lintlha tsa spin-loop, ts'ebetso ena ha e etse letho ho hang.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Boleng bo arolelanoeng ba athomo boo likhoele li tla bo sebelisa ho hokahanya
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Ka khoele e ka morao re tla beha boleng
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Etsa mosebetsi o itseng, ebe o etsa hore boleng bo phele
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Ha re khutlela khoeleng ea rona ea hajoale, re emela hore boleng bo beoe
/// while !live.load(Ordering::Acquire) {
///     // Loop spin e fana ka maikutlo ho CPU eo re e emetseng, empa mohlomong eseng halelele haholo
/////
///     hint::spin_loop();
/// }
///
/// // Hona joale boleng bo behiloe
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // TSHIRELETSO: kgogedi ya `cfg` e netefatsa hore re etsa sena feela ho dipehelo tsa x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // TSHIRELETSO: kgogedi ya `cfg` e netefatsa hore re etsa sena feela hodima dinepo tsa x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // TSHIRELETSO: kgogedi ya `cfg` e netefatsa hore re etsa sena feela hodima dinepo tsa aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // TSHIRELETSO: `cfg` attr e netefatsa hore re etsa sena feela ka liphofu tsa letsoho
            // ka tšehetso ea karolo ea v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Mosebetsi oa boitsebahatso oo __ a fanang ka leseli __ * ho moqapi ho ba le tšepo e felletseng ka seo `black_box` e ka se etsang.
///
/// Ho fapana le [`std::convert::identity`], moqapi oa Rust o khothaletsoa ho nahana hore `black_box` e ka sebelisa `dummy` ka tsela efe kapa efe e nepahetseng eo khoutu ea Rust e lumelloang ho eona ntle le ho hlahisa boits'oaro bo sa hlalosoang khoutu ea mohala.
///
/// Setša sena se etsa hore `black_box` e sebetse bakeng sa ho ngola khoutu moo ho sa batloeng ntlafatso e itseng, joalo ka lipalo.
///
/// Hlokomela leha ho le joalo, `black_box` e fanoa feela (mme e ka fuoa feela) ka "best-effort".Boholo boo bo ka thibelang ts'ebetso ho eona bo ka fapana ho latela sethala le kh'out-gen backend e sebelisitsoeng.
/// Mananeo a ke ke a itšetleha ka `black_box` bakeng sa *ho nepahala* ka tsela efe kapa efe.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Re hloka ho "use" khang ka tsela e 'ngoe LLVM e ke ke ea tsebahala,' me lipakaneng tse e tšehetsang re ka sebelisa mokoka o kenelletseng ho etsa sena.
    // Tlhaloso ea LLVM ea kopano e ka hare ke hore ke lebokose le letšo.
    // Hona ha se ts'ebetso e kholo ka ho fetesisa kaha mohlomong e etsa deoptimize ho feta kamoo re batlang, empa ho fihlela joale e nepahetse ka ho lekana.
    //
    //

    #[cfg(not(miri))] // Sena ke tlhahiso feela, ka hona ho hotle ho tlola Miri.
    // TŠIRELETSO: kopano e kenelletseng ha e sebetse.
    unsafe {
        // FIXME: Ha e khone ho sebelisa `asm!` hobane ha e tšehetse MIPS le meralo e meng.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}