//! Khokahano ea tlhaho.
//!
//! Litlhaloso tse tsamaellanang li ho `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ts'ebetso e lumellanang ea const e ho `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Lintho tsa tlhaho tsa Const
//!
//! Note: Liphetoho leha e le life ho matla a tlhaho li lokela ho tšohloa le sehlopha sa puo.
//! Sena se kenyelletsa liphetoho botsitso ba sehlopha.
//!
//! Bakeng sa ho etsa hore ts'ebeliso ea tlhaho e sebelisoe ka nako ea ho bokella, motho o hloka ho kopitsa ts'ebetsong ho tloha <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ho isa ho `compiler/rustc_mir/src/interpret/intrinsics.rs` ebe o eketsa `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ho ea tlhaho.
//!
//!
//! Haeba se ka hare se lokela ho sebelisoa ho tsoa ho `const fn` se nang le semelo sa `rustc_const_stable`, semelo sa kahare se tlameha ho ba `rustc_const_stable`, le sona.
//! Phetoho e joalo ha ea lokela ho etsoa ntle le puisano ea T-lang, hobane e baka tšobotsi puong e ke keng ea phetoa ka khoutu ea mosebelisi ntle le ts'ehetso ea ho bokella.
//!
//! # Volatiles
//!
//! Lits'ebetso tse sa tsitsang li fana ka lits'ebetso tse reretsoeng ho sebetsa mohopolong oa I/O, o netefalitsoeng hore o ke ke oa hlophisoa bocha ke motlatsi ho li-intrinsics tse ling tse sa tsitsang.Bona litokomane tsa LLVM ho [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Li-intrinsics tsa athomo li fana ka ts'ebetso e tloaelehileng ea athomo mantsoeng a mochini, ka tatellano e ngata ea memori.Ba mamela li-semantiki tse tšoanang le C++ 11.Bona litokomane tsa LLVM ho [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ho khatholla kapele mabapi le ho otara memori:
//!
//! * Fumana, mokoallo oa ho fumana senotlolo.Ho bala le ho ngola ho latelang ho etsahala kamora tšitiso.
//! * Lokolla, mokoallo bakeng sa ho lokolla loko.Ho bala le ho ngola pele ho etsahala pele ho tšitiso.
//! * Ts'ebetso e lumellanang ka tatellano, e latellanang ka tatellano e netefalitsoe hore e tla etsahala ka tatellano.Ona ke mokhoa o tloaelehileng oa ho sebetsana le mefuta ea athomo ebile o lekana le `volatile` ea Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Litheko tsena li sebelisetsoa ho nolofatsa lihokela tsa intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // TSHIRELETSO: bona `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, li-intrinsics tsena li nka lits'oants'o tse tala hobane li fetola mohopolo o fapaneng, o sa sebetseng bakeng sa `&` kapa `&mut`.
    //

    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::SeqCst`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::Acquire`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::Release`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::AcqRel`] joalo ka `success` le [`Ordering::Acquire`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::Relaxed`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::SeqCst`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::SeqCst`] joalo ka `success` le [`Ordering::Acquire`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::Acquire`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange` ka ho fetisa [`Ordering::AcqRel`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::SeqCst`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::Acquire`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::Release`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::AcqRel`] joalo ka `success` le [`Ordering::Acquire`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::Relaxed`] joalo ka lipehelo tsa `success` le `failure`.
    ///
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::SeqCst`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::SeqCst`] joalo ka `success` le [`Ordering::Acquire`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::Acquire`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// E boloka boleng haeba boleng ba hona joale bo lekana le boleng ba `old`.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `compare_exchange_weak` ka ho fetisa [`Ordering::AcqRel`] joalo ka `success` le [`Ordering::Relaxed`] joalo ka litekanyo tsa `failure`.
    /// Ka mohlala, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// E jarisa boleng ba hona joale ba sesupa.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `load` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// E jarisa boleng ba hona joale ba sesupa.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `load` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// E jarisa boleng ba hona joale ba sesupa.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `load` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// E boloka boleng sebakeng se boletsoeng sa memori.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `store` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// E boloka boleng sebakeng se boletsoeng sa memori.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `store` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// E boloka boleng sebakeng se boletsoeng sa memori.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `store` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// E boloka boleng sebakeng se boletsoeng sa memori, e khutlisa boleng ba khale.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `swap` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// E boloka boleng sebakeng se boletsoeng sa memori, e khutlisa boleng ba khale.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `swap` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// E boloka boleng sebakeng se boletsoeng sa memori, e khutlisa boleng ba khale.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `swap` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E boloka boleng sebakeng se boletsoeng sa memori, e khutlisa boleng ba khale.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `swap` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E boloka boleng sebakeng se boletsoeng sa memori, e khutlisa boleng ba khale.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `swap` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_add` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_add` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_add` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_add` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_add` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tlosa boleng ba hona joale, 'me u khutlise boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_sub` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tlosa boleng ba hona joale, 'me u khutlise boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_sub` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tlosa boleng ba hona joale, 'me u khutlise boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_sub` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tlosa boleng ba hona joale, 'me u khutlise boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_sub` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Tlosa boleng ba hona joale, 'me u khutlise boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_sub` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hanyane ka hanyane le ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_and` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane ka hanyane le ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_and` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane ka hanyane le ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_and` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane ka hanyane le ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_and` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane ka hanyane le ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_and` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand e nang le boleng ba hona joale, e khutlisang boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mofuta oa [`AtomicBool`] ka mokhoa oa `fetch_nand` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand e nang le boleng ba hona joale, e khutlisang boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mofuta oa [`AtomicBool`] ka mokhoa oa `fetch_nand` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand e nang le boleng ba hona joale, e khutlisang boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mofuta oa [`AtomicBool`] ka mokhoa oa `fetch_nand` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand e nang le boleng ba hona joale, e khutlisang boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mofuta oa [`AtomicBool`] ka mokhoa oa `fetch_nand` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand e nang le boleng ba hona joale, e khutlisang boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mofuta oa [`AtomicBool`] ka mokhoa oa `fetch_nand` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hanyane kapa ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_or` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane kapa ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_or` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane kapa ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_or` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane kapa ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_or` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyane kapa ka boleng ba hajoale, ho khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_or` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hanyenyane xor le boleng ba hajoale, e khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_xor` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyenyane xor le boleng ba hajoale, e khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_xor` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyenyane xor le boleng ba hajoale, e khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_xor` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyenyane xor le boleng ba hajoale, e khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_xor` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hanyenyane xor le boleng ba hajoale, e khutlisa boleng bo fetileng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka mefuta ea [`atomic`] ka mokhoa oa `fetch_xor` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Boholo le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hona joale.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e saennweng.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e saennoeng ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e sa ngolisoang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e sa ngolisoang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e sa ngolisoang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e sa ngolisoang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bonyane le boleng ba hajoale ho sebelisoa papiso e sa ngolisoang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_min` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Boholo le boleng ba hajoale ho sebelisoa papiso e sa saeneloang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e sa saeneloang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e sa saeneloang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e sa saeneloang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Boholo le boleng ba hajoale ho sebelisoa papiso e sa saeneloang.
    ///
    /// Mofuta oa botsitso oa semelo sena se fumanehang ka mefuta ea [`atomic`] e sa ngolisoang ka mokhoa oa `fetch_max` ka ho fetisa [`Ordering::Relaxed`] joalo ka `order`.
    /// Ka mohlala, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Tlhahiso ea `prefetch` ea mantlha ke tlhahiso ho jenereithara ea khoutu ho kenya thuto ea preetch haeba e tšehetsoa;ho seng joalo, ke no-op.
    /// Li-prefetches ha li na tšusumetso ho boits'oaro ba lenaneo empa li ka fetola litšobotsi tsa eona tsa ts'ebetso.
    ///
    /// Khang ea `locality` e tlameha ho ba palo e sa fetoheng 'me ke sebui sa sebaka sa nakoana ho tloha (0), ha ho sebaka, ho isa ho (3), se bolokiloeng sebakeng sa heno haholo.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Tlhahiso ea `prefetch` ea mantlha ke tlhahiso ho jenereithara ea khoutu ho kenya thuto ea preetch haeba e tšehetsoa;ho seng joalo, ke no-op.
    /// Li-prefetches ha li na tšusumetso ho boits'oaro ba lenaneo empa li ka fetola litšobotsi tsa eona tsa ts'ebetso.
    ///
    /// Khang ea `locality` e tlameha ho ba palo e sa fetoheng 'me ke sebui sa sebaka sa nakoana ho tloha (0), ha ho sebaka, ho isa ho (3), se bolokiloeng sebakeng sa heno haholo.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Tlhahiso ea `prefetch` ea mantlha ke tlhahiso ho jenereithara ea khoutu ho kenya thuto ea preetch haeba e tšehetsoa;ho seng joalo, ke no-op.
    /// Li-prefetches ha li na tšusumetso ho boits'oaro ba lenaneo empa li ka fetola litšobotsi tsa eona tsa ts'ebetso.
    ///
    /// Khang ea `locality` e tlameha ho ba palo e sa fetoheng 'me ke sebui sa sebaka sa nakoana ho tloha (0), ha ho sebaka, ho isa ho (3), se bolokiloeng sebakeng sa heno haholo.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Tlhahiso ea `prefetch` ea mantlha ke tlhahiso ho jenereithara ea khoutu ho kenya thuto ea preetch haeba e tšehetsoa;ho seng joalo, ke no-op.
    /// Li-prefetches ha li na tšusumetso ho boits'oaro ba lenaneo empa li ka fetola litšobotsi tsa eona tsa ts'ebetso.
    ///
    /// Khang ea `locality` e tlameha ho ba palo e sa fetoheng 'me ke sebui sa sebaka sa nakoana ho tloha (0), ha ho sebaka, ho isa ho (3), se bolokiloeng sebakeng sa heno haholo.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Terata ea athomo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::fence`] ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Terata ea athomo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::fence`] ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Terata ea athomo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::fence`] ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Terata ea athomo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::fence`] ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Thibelo ea mohopolo feela oa ho bokella.
    ///
    /// Ho fihlella ha memori ho ke ke ha hlophisoa bocha kahare ho mokoallo ona ke moqapi, empa ha ho litaelo tse tla fanoa bakeng sa eona.
    /// Sena se loketse ts'ebetso ea khoele e ts'oanang e ka etsoang pele, joalo ka ha o sebelisana le batsamaisi ba lipontšo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::compiler_fence`] ka ho fetisa [`Ordering::SeqCst`] joalo ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Thibelo ea mohopolo feela oa ho bokella.
    ///
    /// Ho fihlella ha memori ho ke ke ha hlophisoa bocha kahare ho mokoallo ona ke moqapi, empa ha ho litaelo tse tla fanoa bakeng sa eona.
    /// Sena se loketse ts'ebetso ea khoele e ts'oanang e ka etsoang pele, joalo ka ha o sebelisana le batsamaisi ba lipontšo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::compiler_fence`] ka ho fetisa [`Ordering::Acquire`] joalo ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Thibelo ea mohopolo feela oa ho bokella.
    ///
    /// Ho fihlella ha memori ho ke ke ha hlophisoa bocha kahare ho mokoallo ona ke moqapi, empa ha ho litaelo tse tla fanoa bakeng sa eona.
    /// Sena se loketse ts'ebetso ea khoele e ts'oanang e ka etsoang pele, joalo ka ha o sebelisana le batsamaisi ba lipontšo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::compiler_fence`] ka ho fetisa [`Ordering::Release`] joalo ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Thibelo ea mohopolo feela oa ho bokella.
    ///
    /// Ho fihlella ha memori ho ke ke ha hlophisoa bocha kahare ho mokoallo ona ke moqapi, empa ha ho litaelo tse tla fanoa bakeng sa eona.
    /// Sena se loketse ts'ebetso ea khoele e ts'oanang e ka etsoang pele, joalo ka ha o sebelisana le batsamaisi ba lipontšo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena se fumanehang ka [`atomic::compiler_fence`] ka ho fetisa [`Ordering::AcqRel`] joalo ka `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Matla a boselamose a fumanang moelelo oa ona ho tsoa ho litšobotsi tse amanang le mosebetsi.
    ///
    /// Mohlala, dataflow e sebelisa sena ho kenya lipolelo tse sa fetoheng e le hore `rustc_peek(potentially_uninitialized)` e hlahlobe habeli hore phallo ea data e hlile e hakanya hore ha e qalisoe ka nako eo phallo ea taolo.
    ///
    ///
    /// Ts'ebetso ena ea tlhaho ha ea lokela ho sebelisoa kantle ho moqapi.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// E tlohela ts'ebetso ea ts'ebetso.
    ///
    /// Mofuta o bonolo oa ts'ebeliso ena o sebetsang habonolo ebile o tsitsitse ke [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// E tsebisa optimizer hore ntlha ena ea khoutu ha e fihlellehe, e nolofalletsa ntlafatso e eketsehileng.
    ///
    /// NB, sena se fapane haholo le `unreachable!()` macro: Ho fapana le macro, eo panics ha e etsoa, ke *boits'oaro bo sa hlalosoang* ho fihlela khoutu e tšoailoeng ka ts'ebetso ena.
    ///
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// E tsebisa optimizer hore boemo bo lula bo le nnete.
    /// Haeba boemo bo fosahetse, boits'oaro ha bo na lebitso.
    ///
    /// Ha ho khoutu e hlahisoang bakeng sa tlhaho ena, empa optimizer e tla leka ho e boloka (le boemo ba eona) lipakeng tsa lipasa, tse ka sitisang ntlafatso ea khoutu e potileng le ho fokotsa ts'ebetso.
    /// Ha ea lokela ho sebelisoa haeba se sa fetoheng se ka fumanoa ke seboholi ka botsona, kapa haeba se sa lumelle ntlafatso efe kapa efe ea bohlokoa.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Litlhahiso ho moqapi hore boemo ba branch e kanna ea ba 'nete.
    /// E khutlisa boleng bo fetisitsoeng ho eona.
    ///
    /// Ts'ebeliso efe kapa efe ntle le lipolelo tsa `if` e kanna ea se be le phello.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Litlhahiso ho moqapi hore boemo ba branch bo kanna ba ba leshano.
    /// E khutlisa boleng bo fetisitsoeng ho eona.
    ///
    /// Ts'ebeliso efe kapa efe ntle le lipolelo tsa `if` e kanna ea se be le phello.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// E etsa leraba la ho phatloha, bakeng sa ho hlahlojoa ke moitlami.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn breakpoint();

    /// Boholo ba mofuta oa li-byte.
    ///
    /// Haholo-holo sena ke setlankane sa li-byte lipakeng tsa lintho tse latellanang tsa mofuta o ts'oanang, ho kenyeletsoa le tatellano ea katoloso.
    ///
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Peakanyo e nyane ea mofuta.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Tsamaiso e khethiloeng ea mofuta.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Boholo ba boleng bo boletsoeng ka li-byte.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Tsamaiso e hlokahalang ea boleng bo supiloeng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// E fumana selae sa thapo se emeng se nang le lebitso la mofuta.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// E fumana sesupahale se ikhethileng ka bophara ho mofuta o boletsoeng.
    /// Ts'ebetso ena e tla khutlisa boleng bo tšoanang bakeng sa mofuta ho sa tsotelehe hore na e sebelisoa ho le hokae crate.
    ///
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Molebeli oa mesebetsi e sa bolokehang e ke keng ea etsoa haeba `T` e se na baahi:
    /// Hona ho tla latela panic, kapa ho se etse letho.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Molebeli oa mesebetsi e sa bolokehang e ke keng ea etsoa haeba `T` e sa lumelle ts'ebetso ea zero: Sena se tla ba panic, kapa se etse letho.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn assert_zero_valid<T>();

    /// Molebeli oa mesebetsi e sa bolokehang e ke keng ea etsoa haeba `T` e na le lipaterone tse sa sebetseng: Hona ho tla latela panic, kapa ho se etse letho.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn assert_uninit_valid<T>();

    /// E fumana ho buuoa ka static `Location` e bonts'a moo e neng e bitsoa teng.
    ///
    /// Nahana ka ho sebelisa [`core::panic::Location::caller`](crate::panic::Location::caller) ho fapana.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// E tlosa boleng kantle ho sekhomaretsi.
    ///
    /// Sena se teng feela bakeng sa [`mem::forget_unsized`];`forget` e tloaelehileng e sebelisa `ManuallyDrop` ho fapana.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// E fetolela biti ea boleng ba mofuta o mong e le mofuta o mong.
    ///
    /// Mefuta ka bobeli e tlameha ho ba le boholo bo lekanang.
    /// Leha e le eona ea mantlha, kapa sephetho, ekaba [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` e tšoana hantle le motsamao o monyane oa mofuta o mong ho o mong.E kopitsa likotoana tsa boleng ba mohloli ho boleng ba sebaka, ebe e lebala ea mantlha.
    /// E lekana le C's `memcpy` tlasa hood, joalo ka `transmute_copy`.
    ///
    /// Hobane `transmute` ke ts'ebetso ea boleng, ho hokahana ha boleng bo fetisitsoeng ka bo bona * ha se taba.
    /// Joalo ka ts'ebetso efe kapa efe, moqapi o se a ntse a netefatsa hore `T` le `U` li hokahane hantle.
    /// Leha ho le joalo, ha ho fetisoa boleng bo supang libakeng tse ling * (joalo ka litsupa, litšupiso, mabokose…), moletsi o tlameha ho netefatsa hore ho tsamaellana hantle le litekanyetso tse supisitsoeng.
    ///
    /// `transmute` e sa bolokeha ** ha e bolokehe.Ho na le mekhoa e mengata ea ho baka [undefined behavior][ub] ka ts'ebetso ena.`transmute` e lokela ho ba khetho ea hoqetela.
    ///
    /// [nomicon](../../nomicon/transmutes.html) e na le litokomane tse ling.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ho na le lintho tse 'maloa tseo `transmute` e sebeletsang ho tsona.
    ///
    /// Ho fetola sesupi hore e be sesupa sa mosebetsi.Sena ha se nkehe habonolo ho mechini moo lits'oants'o tsa ts'ebetso le litsupa tsa data li nang le boholo bo fapaneng.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ho eketsa nako ea bophelo bohle, kapa ho khutsufatsa bophelo bo sa fetoheng.Sena se tsoetse pele, ha se bolokehe Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Se ke oa nyahama: ts'ebeliso e ngata ea `transmute` e ka fihlelleha ka mekhoa e meng.
    /// Ka tlase ke likopo tse tloaelehileng tsa `transmute` tse ka nkeloang sebaka ke lihaho tse sireletsehileng.
    ///
    /// Ho fetola bytes(`&[u8]`) e tala ho `u32`, `f64`, jj.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // sebelisa `u32::from_ne_bytes` ho fapana
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // kapa sebelisa `u32::from_le_bytes` kapa `u32::from_be_bytes` ho hlakisa endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ho fetola sesupa hore e be `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sebelisa samente ea `as` ho fapana
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ho fetola `*mut T` hore e be `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sebelisa mokoloto ho fapana
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ho fetola `&mut T` hore e be `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Joale, kopanya `as` le ho khutlisa hape, hlokomela ho tlanngoa ha `as` `as` ha ho fetohe
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Ho fetola `&str` hore e be `&[u8]`:
    ///
    /// ```
    /// // ena ha se tsela e ntle ea ho etsa sena.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // U ka sebelisa `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Kapa, sebelisa khoele ea byte, haeba u na le taolo holim'a khoele ka mokhoa oa sebele
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ho fetola `Vec<&T>` hore e be `Vec<Option<&T>>`.
    ///
    /// Ho fetisa mofuta o ka hare oa se ka har'a setshelo, o tlameha ho etsa bonnete ba hore o se ke oa tlola lihlaseli tsa setshelo.
    /// Bakeng sa `Vec`, sena se bolela hore boholo *le tatellano* ea mefuta e ka hare e tlameha ho tšoana.
    /// Lijana tse ling li kanna tsa itšetleha ka boholo ba mofuta, tatellano, kapa le `TypeId`, moo ho fetisang maemo ho neng ho ke ke ha khoneha ho hang ntle le ho roba lihlaseli tsa setshelo.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // khopisa vector ha re ntse re tla li sebelisa hamorao
    /// let v_clone = v_orig.clone();
    ///
    /// // Ho sebelisa transmute: sena se itšetleha ka sebopeho sa data se sa hlalosoang sa `Vec`, e leng mohopolo o mobe ebile o ka baka boits'oaro bo sa hlalosoang.
    /////
    /// // Leha ho le joalo, ha ho kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ena ke tsela e khothalelitsoeng, e bolokehileng.
    /// // E kopitsa vector kaofela, leha ho le joalo, hore e be sehlopha se secha.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ena ke tsela e nepahetseng ea ho se kopise, e sa bolokehang ea "transmuting" le `Vec`, ntle le ho itšetleha ka sebopeho sa data.
    /// // Sebakeng sa ho letsetsa `transmute` ka nepo, re etsa sesepa sa pointer, empa mabapi le ho fetolela mofuta oa mantlha oa ka hare (`&i32`) ho o mocha (`Option<&i32>`), sena se na le lithibelo tse tšoanang.
    /////
    /// // Ntle le tlhaiso-leseling e fanoeng kaholimo, sheba le litokomane tsa [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ntlafatsa sena ha vec_into_raw_parts e tsitsitse.
    ///     // Netefatsa hore vector ea mantlha ha e theoloe.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Ho kenya ts'ebetsong `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ho na le mekhoa e mengata ea ho etsa sena, 'me ho na le mathata a mangata ka tsela e latelang ea (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pele: transmute ha e mofuta o bolokehileng;tsohle tseo e li lekolang ke hore T le
    ///         // U li boholo bo lekanang.
    ///         // Taba ea bobeli ke hore mona u na le litšupiso tse peli tse ka fetoloang tse supang mohopolong o le mong.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Sena se felisa mathata a mofuta oa polokeho;`&mut *`* e tla u fa `&mut T` feela ho tsoa ho `&mut T` kapa `*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // leha ho le joalo, o ntse o na le litšupiso tse peli tse ka feto-fetohang tse supang mohopolong o le mong.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ena ke tsela eo laeborari e tloaelehileng e e etsang.
    /// // Ena ke mokhoa o motlehali, haeba o hloka ho etsa ntho e kang ena
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Hona joale ho na le litšupiso tse tharo tse ka feto-fetohang tse supang mohopolong o le mong.`slice`, rvalue ret.0, le rvalue ret.1.
    ///         // `slice` ha e sebelisoe kamora `let ptr = ...`, ka hona motho a ka e nka e le "dead", ka hona, o na le likhechana tse peli feela tsa 'nete tse ka feto-fetohang.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Le ha hona ho etsa hore kahare const e tsitsitse, re na le khoutu e itseng ea tloaelo ho const fn
    // licheke tse thibelang ts'ebeliso ea eona kahare ho `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// E khutlisa `true` haeba mofuta oa 'nete o fanoeng e le `T` o hloka sekhomaretsi;e khutlisa `false` haeba mofuta oa 'nete o fanoe bakeng sa lisebelisoa tsa `T` `Copy`.
    ///
    ///
    /// Haeba mofuta oa 'nete ha o hloke sekhomaretsi kapa o sebelisa `Copy`, boleng ba ts'ebetso ea ts'ebetso ena ha bo tsejoe.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// E sebetsa ka palo ho tloha sesupa-tsela.
    ///
    /// Sena se kenngwa tšebetsong e le ntho ea tlhaho ho qoba ho fetohela ho le ho tsoa ho palo e felletseng, kaha tšokoloho e ne e tla lahla leseli la aliasing.
    ///
    /// # Safety
    ///
    /// Sesupa sa ho qala le se hlahisang se tlameha ho ba ka har'a meeli kapa ka nakoana e le 'ngoe ho feta pheletsong ea ntho e abetsoeng.
    /// Haeba sesupi leha e le sefe se tsoa meeling kapa phallo ea lipalo e etsahala, ts'ebeliso efe kapa efe ea boleng bo khutlisitsoeng e tla fella ka boits'oaro bo sa hlalosoang.
    ///
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// E sebetsa ka palo ho tloha sesupa-tsela, e ka phuthela.
    ///
    /// Sena se kengoa tšebetsong e le ntho ea tlhaho ho qoba ho fetohela ho kapa ho tsoa ho palo e kholo, kaha phetoho e thibela likhakanyo tse itseng.
    ///
    /// # Safety
    ///
    /// Ho fapana le tlhaho ea `offset`, semelo sena sa tlhaho ha se thibele sesupisi se hlahisang kapa byte e le 'ngoe ho feta qetellong ea ntho e abuoeng,' me se koaheloa ke lipalo tse peli tse tlatselletsang.
    /// Boleng bo hlahisoang ha se hakaalo hore bo ka sebelisoa ho fihlella mohopolo.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// E lekana le tlhaho e loketseng ea `llvm.memcpy.p0i8.0i8.*`, ka boholo ba `count`*`size_of::<T>()` le tatellano ea
    ///
    /// `min_align_of::<T>()`
    ///
    /// Mochini o sa fetoheng o hlophiselitsoe ho `true`, ka hona o ke ke oa ntlafatsoa ntle le haeba boholo bo lekana le zero.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// E lekana le tlhaho ea `llvm.memmove.p0i8.0i8.*` e loketseng, ka boholo ba `count* size_of::<T>()` le tatellano ea
    ///
    /// `min_align_of::<T>()`
    ///
    /// Mochini o sa fetoheng o hlophiselitsoe ho `true`, ka hona o ke ke oa ntlafatsoa ntle le haeba boholo bo lekana le zero.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// E lekana le `llvm.memset.p0i8.*` ea tlhaho e loketseng, ka boholo ba `count* size_of::<T>()` le tatellano ea `min_align_of::<T>()`.
    ///
    ///
    /// Mochini o sa fetoheng o hlophiselitsoe ho `true`, ka hona o ke ke oa ntlafatsoa ntle le haeba boholo bo lekana le zero.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// E etsa mojaro o sa tsitsang ho tsoa sesoleng sa `src`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// E etsa lebenkele le sa tsitsang ho sesupa sa `dst`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// E etsa mojaro o sa tsitsang ho tsoa ho sesupa sa `src` Sesupa ha se hlokehe hore se hokahane.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// E etsa lebenkele le sa tsitsang ho sesupa sa `dst`.
    /// Pointer ha e hlokehe hore e hokahane.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// E khutlisa motso o sekwere oa `f32`
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// E khutlisa motso o sekwere oa `f64`
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// E phahamisa `f32` ho matla a felletseng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// E phahamisa `f64` ho matla a felletseng.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// E khutlisa sine ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// E khutlisa sine ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// E khutlisa cosine ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// E khutlisa cosine ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// E phahamisa `f32` ho matla a `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// E phahamisa `f64` ho matla a `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// E khutlisa exponential ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// E khutlisa exponential ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// E khutlisa 2 e phahamiselitsoeng matleng a `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// E khutlisa 2 e phahamiselitsoeng matleng a `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// E khutlisa logarithm ea tlhaho ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// E khutlisa logarithm ea tlhaho ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// E khutlisetsa logarithm ea mantlha ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// E khutlisetsa logarithm ea mantlha ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// E khutlisetsa logarithm ea 2 ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// E khutlisetsa logarithm ea 2 ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// E khutlisa `a * b + c` bakeng sa boleng ba `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// E khutlisa `a * b + c` bakeng sa boleng ba `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// E khutlisa boleng bo felletseng ba `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// E khutlisa boleng bo felletseng ba `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// E khutlisa bonyane ba litekanyetso tse peli tsa `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// E khutlisa bonyane ba litekanyetso tse peli tsa `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// E khutlisa boholo ba litekanyetso tse peli tsa `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// E khutlisa boholo ba litekanyetso tse peli tsa `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// E kopitsa lets'oao ho tloha `y` ho isa ho `x` bakeng sa boleng ba `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// E kopitsa lets'oao ho tloha `y` ho isa ho `x` bakeng sa boleng ba `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// E khutlisa palo e kholohali ka tlase ho kapa e lekana le `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// E khutlisa palo e kholohali ka tlase ho kapa e lekana le `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// E khutlisa palo e nyane haholo ho feta kapa e lekana le `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// E khutlisa palo e nyane haholo ho feta kapa e lekana le `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// E khutlisa karolo e felletseng ea `f32`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// E khutlisa karolo e felletseng ea `f64`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// E khutlisetsa palo e haufinyane ho `f32`.
    /// E kanna ea phahamisa phapang ea ntlha e sa nepahalo haeba khang e se palo e felletseng.
    pub fn rintf32(x: f32) -> f32;
    /// E khutlisetsa palo e haufinyane ho `f64`.
    /// E kanna ea phahamisa phapang ea ntlha e sa nepahalo haeba khang e se palo e felletseng.
    pub fn rintf64(x: f64) -> f64;

    /// E khutlisetsa palo e haufinyane ho `f32`.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn nearbyintf32(x: f32) -> f32;
    /// E khutlisetsa palo e haufinyane ho `f64`.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn nearbyintf64(x: f64) -> f64;

    /// E khutlisetsa palo e haufinyane ho `f32`.E bokella linyeoe tsa halofo ea tsela hole le zero.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// E khutlisetsa palo e haufinyane ho `f64`.E bokella linyeoe tsa halofo ea tsela hole le zero.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Tlatsetso ea float e lumellang ntlafatso e ipapisitse le melao ea algebraic.
    /// E kanna ea re litlatsetso li felile.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ho ntša phaphametse ho lumellang ntlafatso ho ipapisitsoe le melao ea algebraic.
    /// E kanna ea re litlatsetso li felile.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Katiso ea float e lumellang ntlafatso e ipapisitse le melao ea algebraic.
    /// E kanna ea re litlatsetso li felile.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Karohano ea metsi e lumellang ntlafatso e ipapisitse le melao ea algebraic.
    /// E kanna ea re litlatsetso li felile.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sala e setseng e lumellang ntlafatso e ipapisitse le melao ea algebraic.
    /// E kanna ea re litlatsetso li felile.
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Fetolela ka XLUMX ea LLVM, e ka khutlisang undef bakeng sa litekanyetso tse fapaneng
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// E tsitsitse joalo ka [`f32::to_int_unchecked`] le [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// E khutlisa palo ea likotoana tse behiloeng ka bongata ba mofuta oa `T`
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `count_ones`.
    /// Ka mohlala,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// E khutlisa palo ea liketane tse isang pele tse sa hlophisoang (zeroes) ka mofuta o felletseng oa `T`.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `leading_zeros`.
    /// Ka mohlala,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` e nang le boleng `0` e tla khutlisa bophara ba `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Joalo ka `ctlz`, empa e sa bolokeha haholo ha e khutlisa `undef` ha e fuoa `x` e nang le boleng ba `0`.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// E khutlisa palo ea lits'oants'o tse sa sebetseng (zeroes) ka mofuta o felletseng oa `T`.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `trailing_zeros`.
    /// Ka mohlala,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` e nang le boleng `0` e tla khutlisa bophara ba `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Joalo ka `cttz`, empa e sa bolokeha haholo ha e khutlisa `undef` ha e fuoa `x` e nang le boleng ba `0`.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// E khutlisetsa li-byte ka mofuta o lekanang oa `T`.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `swap_bytes`.
    /// Ka mohlala,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// E khutlisa likotoana ka mofuta o le mong oa `T`.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `reverse_bits`.
    /// Ka mohlala,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// E etsa tlatsetso ea palo e felletseng.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `overflowing_add`.
    /// Ka mohlala,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// E etsa ho tlosa palo e felletseng
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `overflowing_sub`.
    /// Ka mohlala,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// E etsa katiso e kholo ea palo
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `overflowing_mul`.
    /// Ka mohlala,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// E etsa karohano e nepahetseng, e hlahisang boits'oaro bo sa hlalosoang moo `x % y != 0` kapa `y == 0` kapa `x == T::MIN && y == -1`
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// E etsa karohano e sa hlahlojoeng, e hlahisang boits'oaro bo sa hlalosoang moo `y == 0` kapa `x == T::MIN && y == -1`
    ///
    ///
    /// Li-wrappers tse sireletsehileng bakeng sa semelo sena sa tlhaho lia fumaneha ho li-primitives tse felletseng ka mokhoa oa `checked_div`.
    /// Ka mohlala,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// E khutlisa karolo e setseng ea karohano e sa hlahlojoeng, e hlahisang boits'oaro bo sa hlalosoang ha `y == 0` kapa `x == T::MIN && y == -1`
    ///
    ///
    /// Li-wrappers tse sireletsehileng bakeng sa semelo sena sa tlhaho lia fumaneha ho li-primitives tse felletseng ka mokhoa oa `checked_rem`.
    /// Ka mohlala,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// E etsa phetoho e sa hlahlojoeng ea leqele, e hlahisang boits'oaro bo sa hlalosoang ha `y < 0` kapa `y >= N`, moo N e leng bophara ba T ka likotoana.
    ///
    ///
    /// Li-wrappers tse sireletsehileng bakeng sa semelo sena sa tlhaho lia fumaneha ho li-primitives tse felletseng ka mokhoa oa `checked_shl`.
    /// Ka mohlala,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// E etsa phetoho e sa koaloang ka nepo, e hlahisang boits'oaro bo sa hlalosoang ha `y < 0` kapa `y >= N`, moo N e leng bophara ba T ka likotoana.
    ///
    ///
    /// Li-wrappers tse sireletsehileng bakeng sa semelo sena sa tlhaho lia fumaneha ho li-primitives tse felletseng ka mokhoa oa `checked_shr`.
    /// Ka mohlala,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// E khutlisa sephetho sa keketso e sa hlahlojoeng, e hlahisang boits'oaro bo sa hlalosoang ha `x + y > T::MAX` kapa `x + y < T::MIN`.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// E khutlisa sephetho sa ho tlosa ho sa hlahlojoeng, ho hlahisang boits'oaro bo sa hlalosoang ha `x - y > T::MAX` kapa `x - y < T::MIN`.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// E khutlisa sephetho sa katiso e sa hlahlojoeng, e hlahisang boits'oaro bo sa hlalosoang ha `x *y > T::MAX` kapa `x* y < T::MIN`.
    ///
    ///
    /// Sena sa tlhaho ha se na molekane ea tsitsitseng.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// E etsa potoloha ka ho le letšehali.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `rotate_left`.
    /// Ka mohlala,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// E etsa potoloha hantle.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `rotate_right`.
    /// Ka mohlala,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) mod 2 <sup>N</sup>, moo N e leng bophara ba T ka likotoana.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `wrapping_add`.
    /// Ka mohlala,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a, b) mod 2 <sup>N</sup>, moo N e leng bophara ba T ka likotoana.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `wrapping_sub`.
    /// Ka mohlala,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// E khutlisa (a * b) mod 2 <sup>N</sup>, moo N e leng bophara ba T ka likotoana.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `wrapping_mul`.
    /// Ka mohlala,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// E bala `a + b`, e khotsofatsa ka meeli ea linomoro.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `saturating_add`.
    /// Ka mohlala,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// E bala `a - b`, e khotsofatsa ka meeli ea linomoro.
    ///
    /// Mefuta e tsitsitseng ea tlhaho ena ea tlhaho e fumaneha ho li-primitives tse felletseng ka mokhoa oa `saturating_sub`.
    /// Ka mohlala,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// E khutlisa boleng ba khethollo bakeng sa mofuta o fapaneng oa 'v';
    /// haeba `T` e sena khethollo, e khutlisa `0`.
    ///
    /// Mofuta o tsitsitseng oa semelo sena sa tlhaho ke [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// E khutlisetsa palo ea mefuta e fapaneng ea mofuta oa `T` ho `usize`;
    /// haeba `T` e se na mefuta e fapaneng, e khutlisa `0`.Mefuta e sa lekanyetsoang ea baahi e tla baloa.
    ///
    /// Mofuta o lokelang ho tsitsisoa oa semelo sena sa tlhaho ke [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" e hahang e kenyang pointer ea ts'ebetso `try_fn` ka sesupa sa data `data`.
    ///
    /// Khang ea boraro ke mosebetsi o bitsoang haeba panic e etsahala.
    /// Mosebetsi ona o nka sesupi sa data le sesupa ho sepheo se ikhethileng se ikhethileng se hapiloeng.
    ///
    /// Bakeng sa tlhaiso-leseling e batsi bona mohloli oa moqapi hammoho le ts'ebetso ea ts'ebetso ea std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// E hlahisa lebenkele la `!nontemporal` ho latela LLVM (bona li-docs tsa bona).
    /// Mohlomong e ke ke ea tsitsa.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Bona litokomane tsa `<*const T>::offset_from` bakeng sa lintlha.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Bona litokomane tsa `<*const T>::guaranteed_eq` bakeng sa lintlha.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Bona litokomane tsa `<*const T>::guaranteed_ne` bakeng sa lintlha.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Fana ka nako ea ho bokella.Ha ea lokela ho bitsoa ka nako ea ho matha.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Mesebetsi e meng e hlalositsoe mona hobane ka phoso e ile ea fumaneha mojuleng ona setaleng.
// Bona <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` le eona e oela sehlopheng sena, empa e ke ke ea phutoa ka lebaka la cheke ea hore `T` le `U` li na le boholo bo lekanang.)
//

/// E hlahloba hore na `ptr` e hokahane hantle mabapi le `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Likopi tsa `count *size_of::<T>()` byte ho tloha `src` ho isa ho `dst`.Mohloli le sebaka seo u eang ho sona ha lia tlameha ho* tsamaellana.
///
/// Bakeng sa libaka tsa mohopolo tse ka fetang, sebelisa [`copy`] ho fapana.
///
/// `copy_nonoverlapping` e batla e lekana le C's [`memcpy`], empa ka taelo ea ngangisano e fetotsoe.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `src` e tlameha ho ba [valid] bakeng sa li-byte tsa `count * size_of::<T>()`.
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola ka li-byte tsa `count * size_of::<T>()`.
///
/// * Ka bobeli `src` le `dst` li tlameha ho hokahanngoa hantle.
///
/// * Sebaka sa memori se qalang ka `src` ka boholo ba `count *
///   size_of: :<T>() `byte ha ea lokela ho * kopana le sebaka sa memori ho qala ka `dst` ka boholo bo lekanang.
///
/// Joalo ka [`read`], `copy_nonoverlapping` e etsa kopi ea `T` hanyane hanyane, ho sa tsotelehe `T` ke [`Copy`].
/// Haeba `T` ha se [`Copy`], ho sebelisoa *ka bobeli boleng ho sebaka se qalang ho `* src` mme sebaka se qalang ka `*dst` se ka ba [violate memory safety][read-ownership].
///
///
/// Hlokomela hore leha boholo bo kopilitsoe hantle (`count * size_of: :<T>()`) ke `0`, lits'oants'o ha lia lokela ho ba NULL mme li hokahane hantle.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Kenya letsoho [`Vec::append`] ka letsoho:
///
/// ```
/// use std::ptr;
///
/// /// E tsamaisa likarolo tsohle tsa `src` ho `dst`, e siea `src` e se na letho.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Netefatsa hore `dst` e na le matla a lekaneng ho ts'oara `src` kaofela.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Pitso ea offset e lula e sireletsehile hobane `Vec` e ke ke ea fana ka li-byte tse fetang `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` ntle le ho lahla litaba tsa eona.
///         // Re etsa sena pele, ho qoba mathata haeba ho ka ba le ho hong hape tlase panics.
///         src.set_len(0);
///
///         // Libaka tsena tse peli li ke ke tsa kopana hobane litšupiso tse fetohang ha li na mabitso, 'me vectors tse peli tse fapaneng ha li na mohopolo o tšoanang.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Tsebisa `dst` hore e se e tšoere litaba tsa `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Etsa licheke tsena feela ka nako ea ho matha
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ha re tšohe ho boloka tšusumetso ea codegen e nyane.
        abort();
    }*/

    // TSHIRELETSO: konteraka ya polokeho ya `copy_nonoverlapping` e tlameha ho ba
    // ho tshoaroa ke ya letsitseng.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Likopi tsa `count * size_of::<T>()` byte ho tloha `src` ho isa ho `dst`.Mohloli le moo o eang teng li ka kopana.
///
/// Haeba mohloli le sebaka seo u eang ho sona li ke ke tsa hlola li kopana, [`copy_nonoverlapping`] e ka sebelisoa ho fapana.
///
/// `copy` e batla e lekana le C's [`memmove`], empa ka taelo ea ngangisano e fetotsoe.
/// Ho kopitsa ho etsahala joalo ka ha eka li-byte li ne li kopitsoa ho tloha ho `src` ho ea ho tse ling tsa nakoana ebe li kopitsoa ho tloha lenaneng ho ea ho `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `src` e tlameha ho ba [valid] bakeng sa li-byte tsa `count * size_of::<T>()`.
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola ka li-byte tsa `count * size_of::<T>()`.
///
/// * Ka bobeli `src` le `dst` li tlameha ho hokahanngoa hantle.
///
/// Joalo ka [`read`], `copy` e etsa kopi ea `T` hanyane hanyane, ho sa tsotelehe `T` ke [`Copy`].
/// Haeba `T` ha se [`Copy`], ho sebelisoa boleng ka bobeli tikolohong e qalang ka `*src` mme sebaka se qalang ka `* dst` se ka ba [violate memory safety][read-ownership].
///
///
/// Hlokomela hore leha boholo bo kopilitsoe hantle (`count * size_of: :<T>()`) ke `0`, lits'oants'o ha lia lokela ho ba NULL mme li hokahane hantle.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Theha hantle Rust vector ho tsoa ho buffer e sa bolokehang:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` e tlameha ho hokahanngoa ka nepo bakeng sa mofuta oa eona le e seng zero.
/// /// * `ptr` e tlameha ho ba e nepahetseng bakeng sa ho baloa ha likarolo tsa `elts` tse fapaneng tsa mofuta `T`.
/// /// * Lintlha tseo ha lia lokela ho sebelisoa kamora ho bitsa ts'ebetso ena ntle le `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // TS'ireletso: Boemo ba rona ba pele bo tiisa hore mohloli o hokahane ebile oa sebetsa,
///     // mme `Vec::with_capacity` e netefatsa hore re na le sebaka se ka sebelisoang sa ho li ngola.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // TŠIRELETSO: Re e qalile ka matla a mangata pejana,
///     // mme `copy` e fetileng e qalile likarolo tsena.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Etsa licheke tsena feela ka nako ea ho matha
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ha re tšohe ho boloka tšusumetso ea codegen e nyane.
        abort();
    }*/

    // TSHIRELETSO: konteraka ya polokeho ya `copy` e tlameha ho bolokwa ke moletsi.
    unsafe { copy(src, dst, count) }
}

/// E beha li-byte tsa `count * size_of::<T>()` tsa memori ho qala ka `dst` ho isa ho `val`.
///
/// `write_bytes` e ts'oana le C's [`memset`], empa e beha `count * size_of::<T>()` byte ho `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola ka li-byte tsa `count * size_of::<T>()`.
///
/// * `dst` e tlameha ho hokahana hantle.
///
/// Ntle le moo, moletsi o tlameha ho netefatsa hore ho ngola li-byte tsa `count * size_of::<T>()` ho sebaka se fanoeng sa memori ho fella ka boleng bo nepahetseng ba `T`.
/// Ho sebelisa sebaka sa mohopolo se ngotsoeng e le `T` se nang le boleng bo sa sebetseng ba `T` ke boits'oaro bo sa hlalosoang.
///
/// Hlokomela hore leha boholo bo kopilitsoe hantle (`count * size_of: :<T>()`) ke `0`, sesupi se tlameha ho ba se seng sa NULL mme se hokahane hantle.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ho theha boleng bo sa sebetseng:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // E lutla boleng bo neng bo tšoaretsoe pejana ka ho ngola `Box<T>` ka pointer e sa sebetseng.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Hona joale, ho sebelisa kapa ho lahla `v` ho hlahisa boitšoaro bo sa hlalosoang.
/// // drop(v); // ERROR
///
/// // Le ha e dutla `v` "uses" eona, ka hona ke boits'oaro bo sa hlalosoang.
/// // mem::forget(v); // ERROR
///
/// // Ebile, `v` ha e na thuso ho latela mefuta ea mantlha ea sebopeho sa mofuta, ka hona ts'ebetso efe kapa efe e e amang ha e na boits'oaro.
/////
/// // tlohela v2 =v;//PHOSO
///
/// unsafe {
///     // A re ke re beheng boleng bo nepahetseng
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Joale lebokose le hantle
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // TSHIRELETSO: konteraka ya polokeho ya `write_bytes` e tlameha ho bolokwa ke moletsi.
    unsafe { write_bytes(dst, val, count) }
}