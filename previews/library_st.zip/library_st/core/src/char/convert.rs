//! Liphetoho tsa botho.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// E fetola `u32` ho ea ho `char`.
///
/// Hlokomela hore tsohle [`char`] s li nepahetse [`u32`] s, 'me li ka akheloa ho e le' ngoe ka
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Leha ho le joalo, se fapaneng ha se nnete: ha se tsohle tse sebetsang [`u32`] s tse sebetsang [`char`] s.
/// `from_u32()` e tla khutlisa `None` haeba kenyelletso e se boleng bo nepahetseng bakeng sa [`char`].
///
/// Bakeng sa mofuta o sa bolokehang oa ts'ebetso ena e hlokomolohang licheke tsena, bona [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Ho khutlisa `None` ha kenyelletso e se [`char`] e sebetsang:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// E fetola `u32` ho ea ho `char`, e sa natse bonnete.
///
/// Hlokomela hore tsohle [`char`] s li nepahetse [`u32`] s, 'me li ka akheloa ho e le' ngoe ka
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Leha ho le joalo, se fapaneng ha se nnete: ha se tsohle tse sebetsang [`u32`] s tse sebetsang [`char`] s.
/// `from_u32_unchecked()` e tla iphapanyetsa sena, ebe e lahlela [`char`] ka bofofu, mohlomong e ka baka e sa sebetseng.
///
///
/// # Safety
///
/// Mosebetsi ona ha o bolokehe, kaha o ka aha boleng bo sa sebetseng ba `char`.
///
/// Bakeng sa mofuta o bolokehileng oa ts'ebetso ena, bona ts'ebetso ea [`from_u32`].
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `i` ke boleng ba char bo sebetsang.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// E fetola [`char`] hore e be [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// E fetola [`char`] hore e be [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Chate e lahleloa boleng ba khoutu, ebe zero-atolosetsoa ho 64 bit.
        // Bona [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// E fetola [`char`] hore e be [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Chate e lahleloa boleng ba khoutu, ebe zero-atolosetsoa ho 128 bit.
        // Bona [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// 'Mapa oa byte ka 0x00 ..=0xFF ho ea ho `char` eo khoutu ea eona ea khoutu e nang le boleng bo lekanang, ho U + 0000 ..=U + 00FF.
///
/// Unicode e etselitsoe joalo hore e atlehe ho khetholla li-byte tse nang le sebopeho sa kh'outu seo IANA e se bitsang ISO-8859-1.
/// Kh'outu ena e tsamaellana le ASCII.
///
/// Hlokomela hore sena se fapane le ISO/IEC 8859-1 aka
/// ISO 8859-1 (ka mohopolo o le mong o fokolang), e tlohelang li-"blanks", litekanyetso tsa byte tse sa fuoang motho ofe kapa ofe.
/// ISO-8859-1 (IANA one) e li abela likhoutu tsa taolo tsa C0 le C1.
///
/// Hlokomela hore sena le sona * se fapane le Windows-1252 aka
/// khoutu ea leqephe 1252, e leng superset ISO/IEC 8859-1 e fanang ka likheo (eseng kaofela!) tsa matšoao a puo le litlhaku tse fapaneng tsa Selatine.
///
/// Ho ferekanya lintho ho ea pele, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, le `windows-1252` kaofela ke likhakanyo tsa superset ea Windows-1252 e tlatsang likheo tse setseng ka likhoutu tsa C0 le C1 tse tsamaellanang.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// E fetola [`u8`] hore e be [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Phoso e ka khutlisoang ha ho etsoa char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // TŠIRELETSO: ho hlahlojoe hore ke boleng ba unicode ea molao
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Mofuta oa phoso o khutlile ha phetoho e tsoang ho u32 ho ea char e hloleha.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// E fetola nomoro ho radix e fanoeng hore e be `char`.
///
/// 'radix' mona ka linako tse ling e boetse e bitsoa 'base'.
/// Radix ea tse peli e bonts'a palo ea binary, radix ea leshome, decimal, le radix ea leshome le metso e ts'eletseng, hexadecimal, ho fana ka litekanyetso tse tšoanang.
///
/// Li-radices tse hatellang li tšehetsoa.
///
/// `from_digit()` e tla khutlisa `None` haeba kenyelletso e se nomoro ho radix e fanoeng.
///
/// # Panics
///
/// Panics haeba e fuoe radix e kholo ho feta 36.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimal 11 ke palo e le 'ngoe ho base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Ho khutlisa `None` ha ho kenyelletsoa ha se linomoro:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Ho fetisa radix e kholo, ho baka panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}