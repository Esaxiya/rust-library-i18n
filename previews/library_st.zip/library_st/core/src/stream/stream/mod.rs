use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Sebopeho sa ho sebetsana le batšehetsi ba asynchronous.
///
/// Ona ke molapo o moholo oa trait.
/// Ho fumana lintlha tse ling ka mohopolo oa melapo ka kakaretso, ka kopo sheba [module-level documentation].
/// Haholo-holo, o kanna oa batla ho tseba ho etsa [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Mofuta oa lintho tse hlahisitsoeng ke molapo.
    type Item;

    /// Leka ho hula boleng bo latelang ba molapo ona, ho ngolisa mosebetsi oa hajoale oa ho tsosa haeba boleng bo e-so fumanehe, le ho khutlisa `None` haeba molapo o felile.
    ///
    /// # Khutlisa boleng
    ///
    /// Ho na le litekanyetso tse 'maloa tsa ho khutla tse ka bang teng, e' ngoe le e 'ngoe e bontša boemo ba molapo o ikhethileng:
    ///
    /// - `Poll::Pending` e bolela hore boleng bo latelang ba molapo ona ha bo so lokele.Ts'ebetsong e tla netefatsa hore mosebetsi oa hajoale o tla tsebisoa ha boleng bo latelang bo se bo lokile.
    ///
    /// - `Poll::Ready(Some(val))` e bolela hore molapo o hlahisitse ka katleho boleng, `val`, mme o ka hlahisa boleng bo eketsehileng ho mehala e latelang ea `poll_next`.
    ///
    /// - `Poll::Ready(None)` e bolela hore molapo o emisitse, 'me `poll_next` ha ea lokela ho sebelisoa hape.
    ///
    /// # Panics
    ///
    /// Hang ha molatsoana o qetile (o khutlisitse `Ready(None)` from `poll_next`), o letsetsa mokhoa oa oona oa `poll_next` hape panic, e ka thiba ka ho sa feleng, kapa ea baka mathata a mang; `Stream` trait ha e hloke litlamorao tsa mohala o joalo.
    ///
    /// Leha ho le joalo, ha mokhoa oa `poll_next` o sa tšoauoa `unsafe`, melao e tloaelehileng ea Rust ea sebetsa: mehala ha ea lokela ho baka boits'oaro bo sa hlaloseheng (bobolu ba memori, ts'ebeliso e fosahetseng ea mesebetsi ea `unsafe`, kapa tse ling tse joalo), ho sa natse boemo ba molapo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// E khutlisa meeli boleleleng bo setseng ba molapo.
    ///
    /// Ka ho khetheha, `size_hint()` e khutlisa tuple moo elemente ea pele e leng moeli o tlase, 'me ntlha ea bobeli e tlamiloe ka holimo.
    ///
    /// Halofo ea bobeli ea Sehlooho se khutlisitsoeng ke [`Khetho`]`<<`[usize`]`> `.
    /// [`None`] mona e bolela hore ekaba ha ho na libaka tse tsebahalang tse holimo, kapa karolo e holimo e kholo ho feta [`usize`].
    ///
    /// # Lintlha tsa ho kenya ts'ebetsong
    ///
    /// Ha e qobelloe hore ts'ebetso ea molatsoana e hlahisa palo e boletsoeng ea likarolo.Molatsoana oa kariki o ka hlahisa tlase ho moeli o tlase kapa ho feta karolo e kaholimo ea likarolo.
    ///
    /// `size_hint()` e etselitsoe haholo-holo ho sebelisoa bakeng sa ho ntlafatsa joaloka ho boloka sebaka sa likarolo tsa molatsoana, empa ha ea lokela ho tšeptjoa ho etsa mohlala, tlohela meeli ea licheke ka khoutu e sa bolokehang.
    /// Ts'ebetso e fosahetseng ea `size_hint()` ha ea lokela ho lebisa tlolong ea polokeho ea memori.
    ///
    /// Seo se boletse, ts'ebetsong e lokela ho fana ka tekanyetso e nepahetseng, hobane ho seng joalo e tla ba tlolo ea melaoana ea trait.
    ///
    /// Ts'ebetso ea kamehla e khutlisa `(0,` [`None`]`)`e nepahetseng bakeng sa molatsoana ofe kapa ofe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}