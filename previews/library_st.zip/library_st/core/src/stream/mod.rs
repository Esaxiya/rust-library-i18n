//! Iteration e sa tloaelehang ea asynchronous.
//!
//! Haeba futures e le boleng ba asynchronous, joale melapo ke li-iterator tse isynchronous.
//! Haeba u iphumane u na le pokello e ikhethileng ea mofuta o itseng, 'me u hloka ho etsa opereishene linthong tsa pokello e boletsoeng, u tla potlakela ho 'streams'.
//! Melatsoana e sebelisoa haholo ho khoutu ea Rust ea maiketsetso, ka hona ho bohlokoa ho e tseba.
//!
//! Pele re hlalosa ho feta, ha re bue ka hore module ena e hlophisitsoe joang:
//!
//! # Organization
//!
//! Mojule ona o hlophisitsoe haholo ke mofuta:
//!
//! * [Traits] ke karolo ea mantlha: tsena traits li hlalosa hore na ho na le melapo ea mofuta ofe le hore na u ka etsa eng ka eona.Mekhoa ea traits e bohlokoa ho beha nako e eketsehileng ea ho ithuta ho.
//! * Mesebetsi e fana ka litsela tse ling tse thusang ho theha melapo ea mantlha.
//! * Structs hangata ke mefuta e khutlang ea mekhoa e fapaneng ho module ena ea traits.Hangata o tla batla ho sheba mokhoa o etsang `struct`, ho fapana le `struct` ka boeona.
//! Ho fumana lintlha ka botlalo mabapi le hore na hobaneng, bona '[Implementing Stream](#implementation-stream)'.
//!
//! [Traits]: #traits
//!
//! Ho felile ke lehlohonolo!Ha re chekeng linokeng.
//!
//! # Stream
//!
//! Pelo le moea oa module ena ke [`Stream`] trait.Motsoako oa [`Stream`] o shebahala tjena:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ho fapana le `Iterator`, `Stream` e etsa phapang lipakeng tsa mokhoa oa [`poll_next`] o sebelisoang ha ho sebelisoa `Stream`, le mokhoa oa (to-be-implemented) `next` o sebelisoang ha ho sebelisoa molatsoana.
//!
//! Bareki ba `Stream` ba hloka feela ho nahana ka `next`, eo ha e bitsoa, e khutlisetsang future e hlahisang `Option<Stream::Item>`.
//!
//! future e khutlisitsoeng ke `next` e tla hlahisa `Some(Item)` ha feela ho na le likarolo, 'me hang ha li felile, li tla hlahisa `None` ho bonts'a hore iteration e felile.
//! Haeba re emetse ho hong ho ikemiselitseng ho rarolla, future e tla ema ho fihlela molatsoana o se o loketse ho hlahisa hape.
//!
//! Melapo ka bomong e kanna ea khetha ho qala ho pheta-pheta, ka hona ho letsetsa `next` hape e kanna ea se ke ea hlahisa `Some(Item)` hape ka nako e 'ngoe.
//!
//! Tlhaloso e felletseng ea "Stream`] e kenyelletsa mekhoa e meng e mengata hape, empa ke mekhoa ea kamehla, e hahiloeng holim'a [`poll_next`], ka hona o li fumana mahala.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ho kenya Ts'ebetsong
//!
//! Ho iketsetsa molapo oa hau ho kenyelletsa mehato e 'meli: ho theha `struct` ho ts'oara boemo ba molapo, ebe o kenya ts'ebetsong [`Stream`] bakeng sa `struct` eo.
//!
//! Ha re etseng molapo o bitsoang `Counter` o balang ho tloha `1` ho isa ho `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Taba ea mantlha, sebopeho:
//!
//! /// Molapo o balang ho tloha ho le leng ho isa ho la bohlano
//! struct Counter {
//!     count: usize,
//! }
//!
//! // re batla hore palo ea rona e qale ka bonngoe, kahoo ha re kenye mokhoa oa new() ho thusa.
//! // Sena ha se hlile ha se hlokahale, empa se bonolo.
//! // Hlokomela hore re qala `count` ka zero, re tla bona hore na hobaneng ts'ebetsong ea `poll_next()`'s ka tlase.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ebe re kenya `Stream` bakeng sa `Counter` ea rona:
//!
//! impl Stream for Counter {
//!     // re tla be re bala le usize
//!     type Item = usize;
//!
//!     // poll_next() ke eona feela mokhoa o hlokoang
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Eketsa palo ea rona.Ke kahoo re qalileng ho zero.
//!         self.count += 1;
//!
//!         // Lekola ho bona hore na re qetile ho bala kapa che.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Melapo e *botsoa*.Sena se bolela hore ho theha molapo ha ho _do_ haholo.Ha ho letho le etsahalang ho fihlela o letsetsa `next`.
//! Ka linako tse ling hona ke mohloli oa pherekano ha o theha molatsoana feela bakeng sa litlamorao tsa ona.
//! Moqapi o tla re lemosa ka mofuta ona oa boitšoaro:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;