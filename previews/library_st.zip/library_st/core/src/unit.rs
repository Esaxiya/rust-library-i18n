use crate::iter::FromIterator;

/// E koala lintho tsohle tsa yuniti ho tloha ho iterator ho ea ho e le 'ngoe.
///
/// Sena se thusa haholo ha se kopantsoe le mekhahlelo e phahameng, joalo ka ho bokella ho `Result<(), E>` moo o tsotellang liphoso feela:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}