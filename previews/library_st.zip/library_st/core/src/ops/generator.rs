use crate::marker::Unpin;
use crate::pin::Pin;

/// Phello ea ts'ebetso ea jenereithara.
///
/// Enum ena e khutlisoa ka mokhoa oa `Generator::resume` mme e bonts'a litekanyetso tse ka khutlang tsa jenereithara.
/// Hajoale sena se tsamaellana le ntlha ea ho emisoa (`Yielded`) kapa sebaka sa ho emisa (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jenereithara e emisitsoe ka boleng.
    ///
    /// Mmuso ona o supa hore jenereithara e emisitsoe, mme hangata e tsamaellana le polelo ea `yield`.
    /// Boleng bo fanoeng mofuteng ona bo tsamaellana le polelo e fetisitsoeng ho `yield` mme e lumella lijenereithara ho fana ka boleng nako le nako ha li hlahisa.
    ///
    ///
    Yielded(Y),

    /// Jenereithara e phethetsoe ka boleng ba ho khutlisa.
    ///
    /// Mmuso ona o bonts'a hore jenereithara e qetile ho etsa ka boleng bo fanoeng.
    /// Hang ha jenereithara e khutlisitse `Complete` ho nkuoa e le phoso ea moqapi ho letsetsa `resume` hape.
    ///
    Complete(R),
}

/// trait e kenngoe tšebetsong ke mefuta ea lijenereitara tse hahiloeng.
///
/// Lijenereithara, tse tsejoang hape e le coroutines, hajoale ke karolo ea puo ea liteko ho Rust.
/// E kentsoe ho lijenereithara tsa [RFC 2033] hajoale li reretsoe ho fana ka moaho oa li-syntax tsa async/await empa e kanna ea atoloha ho fana ka tlhaloso ea ergonomic bakeng sa li-iterator le lintho tse ling tsa pele.
///
///
/// Syntax le semantics bakeng sa lijenereithara ha lia tsitsa ebile li tla hloka RFC e ngoe bakeng sa botsitso.Leha ho le joalo, ka nako ena syntax e tšoana le ho koaloa:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Litokomane tse ling tsa lijenereithara li ka fumanoa bukeng e sa tsitsang.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Mofuta oa boleng o hlahisoang ke jenereithara ena.
    ///
    /// Mofuta ona o amanang o tsamaellana le polelo ea `yield` le boleng bo lumelloang ho khutlisoa nako le nako ha lihlahisoa tsa jenereithara.
    ///
    /// Mohlala iterator-as-a-jenereithara e kanna ea ba le mofuta ona joalo ka `T`, mofuta o ntseng o phetoa.
    ///
    type Yield;

    /// Mofuta oa boleng oo jenereithara ena e o khutlisetsang.
    ///
    /// Sena se tsamaellana le mofuta o khutlisitsoeng ho jenereithara ka polelo ea `return` kapa ka mokhoa o hlakileng e le polelo ea hoqetela ea jenereithara ea 'nete.
    /// Mohlala futures e ka sebelisa sena joalo ka `Result<T, E>` kaha e emetse future e phethiloeng.
    ///
    ///
    type Return;

    /// E qala ts'ebetso ea jenereithara ena.
    ///
    /// Mosebetsi ona o tla qala ts'ebetsong ea jenereithara kapa o qale ho etsoa haeba o se o ntse o le joalo.
    /// Mohala ona o tla khutlela ntlheng ea ho emisa ea jenereithara ea hoqetela, ho qala ts'ebetsong ho tsoa `yield` ea morao-rao.
    /// Jenereithara e tla tsoelapele ho sebetsa ho fihlela e hlahisa kapa e khutla, ka nako eo mosebetsi ona o tla khutla.
    ///
    /// # Khutlisa boleng
    ///
    /// Enum ea `GeneratorState` e khutlileng mosebetsing ona e bontša hore na jenereithara e maemong afe ha e khutla.
    /// Haeba mofuta oa `Yielded` o khutlisoa joale jenereithara e fihlile ntlheng ea ho emisoa 'me boleng bo hlahisitsoe.
    /// Lijenereithara tsa setereke sena li teng bakeng sa ho qala hape hamorao.
    ///
    /// Haeba `Complete` e khutlisoa joale jenereithara e qetile ka botlalo ka boleng bo fanoeng.Ha e na thuso hore jenereithara e ka qalelisoa hape.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e kanna ea ba panic haeba e bitsoa kamora hore mofuta oa `Complete` o khutlisoe pejana.
    /// Le ha lingoliloeng tsa jenereithara ka puo li netefalitsoe ho panic ho qala hape kamora `Complete`, sena ha se netefatsoe bakeng sa ts'ebetsong eohle ea `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}