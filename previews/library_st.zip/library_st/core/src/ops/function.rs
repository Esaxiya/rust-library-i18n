/// Mofuta wa molaodi wa mehala ya nkang seamohedi se sa fetoheng.
///
/// Mehlala ea `Fn` e ka bitsoa khafetsa ntle le ho fetoha ha naha.
///
/// *trait (`Fn`) ena ha ea lokela ho ferekanngoa le [function pointers] (`fn`).*
///
/// `Fn` e kenngwa tšebetsong ka bo eona ka ho koaloa ho nkang feela litšupiso tse sa fetoheng ho mefuta e hapuoeng kapa ho sa nke letho ho hang, hammoho le (safe) [function pointers] (ka li-caveats, bona litokomane tsa bona bakeng sa lintlha tse ling)
///
/// Ntle le moo, bakeng sa mofuta ofe kapa ofe `F` e sebelisang `Fn`, `&F` e kenya `Fn`, le eona.
///
/// Kaha bobeli ba [`FnMut`] le [`FnOnce`] ke li-supertraits tsa `Fn`, mohlala ofe kapa ofe oa `Fn` o ka sebelisoa e le paramethara moo ho lebelletsoeng [`FnMut`] kapa [`FnOnce`].
///
/// Sebelisa `Fn` e le tlamo ha u batla ho amohela paramethara ea mofuta o ts'oanang le ts'ebetso mme u hloka ho e letsetsa khafetsa ntle le ho fetola boemo (mohlala, ha u e bitsa ka nako e le ngoe).
/// Haeba o sa hloke litlhoko tse thata joalo, sebelisa [`FnMut`] kapa [`FnOnce`] joalo ka meeli.
///
/// Bona [chapter on closures in *The Rust Programming Language*][book] bakeng sa tlhaiso-leseling e batsi ka taba ena.
///
/// Hape hoa hlokomeleha ke syntax e khethehileng ea `Fn` traits (mohlala
/// `Fn(usize, bool) -> sebelisa``).Ba thahasellang lintlha tsa tekheniki ea sena ba ka bua ka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ho letsa ho koaloa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Ho sebelisa parameter ea `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // e le hore regex e tšepe `&str: !FnMut` eo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// E etsa ts'ebetso ea mohala.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Mofuta oa mofani oa mehala ea nkang seamohedi se ka fetohang.
///
/// Mehlala ea `FnMut` e ka bitsoa khafetsa mme e ka fetoha maemong.
///
/// `FnMut` e kenngwa ts'ebetsong ka bo eona ka ho koala ho nkang litšupiso tse ka fetoloang ho mefuta e hapuoeng, hammoho le mefuta eohle e sebelisang [`Fn`], mohlala, (safe) [function pointers] (kaha `FnMut` ke supertrait ea [`Fn`]).
/// Ntle le moo, bakeng sa mofuta ofe kapa ofe `F` e sebelisang `FnMut`, `&mut F` e kenya `FnMut`, le eona.
///
/// Kaha [`FnOnce`] ke supertrait ea `FnMut`, mohlala ofe kapa ofe oa `FnMut` o ka sebelisoa moo [`FnOnce`] e lebelletsoeng, 'me kaha [`Fn`] ke sekhukhu sa `FnMut`, mohlala ofe kapa ofe oa [`Fn`] o ka sebelisoa moo `FnMut` e lebelletsoeng.
///
/// Sebelisa `FnMut` e le tlamo ha u batla ho amohela paramethara ea mofuta o ts'oanang le ts'ebetso mme u hloka ho e letsetsa khafetsa, ha u ntse ue lumella hore e fetole boemo.
/// Haeba u sa batle hore parameter e fetole boemo, sebelisa [`Fn`] e le tlamo;haeba u sa hloke ho e letsetsa khafetsa, sebelisa [`FnOnce`].
///
/// Bona [chapter on closures in *The Rust Programming Language*][book] bakeng sa tlhaiso-leseling e batsi ka taba ena.
///
/// Hape hoa hlokomeleha ke syntax e khethehileng ea `Fn` traits (mohlala
/// `Fn(usize, bool) -> sebelisa``).Ba thahasellang lintlha tsa tekheniki ea sena ba ka bua ka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ho letsetsa ho koaloa ka mokhoa o feto-fetohang
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Ho sebelisa parameter ea `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // e le hore regex e tšepe `&str: !FnMut` eo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// E etsa ts'ebetso ea mohala.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Mofuta oa mofani oa mehala ea nkang seamohedi sa boleng.
///
/// Mehlala ea `FnOnce` e ka bitsoa, empa e kanna ea se khone ho letsetsoa makhetlo a mangata.Ka lebaka la sena, haeba ntho feela e tsebahalang ka mofuta ke hore e sebelisa `FnOnce`, e ka bitsoa hang feela.
///
/// `FnOnce` e kenngwa ts'ebetsong ka bo eona ka ho koaloa ho ka jang mefuta e hapuoeng, hammoho le mefuta eohle e sebelisang [`FnMut`], mohlala, (safe) [function pointers] (kaha `FnOnce` ke supertrait ea [`FnMut`]).
///
///
/// Kaha [`Fn`] le [`FnMut`] ke likaroloana tsa `FnOnce`, mohlala ofe kapa ofe oa [`Fn`] kapa [`FnMut`] o ka sebelisoa moo ho lebelletsoeng `FnOnce`.
///
/// Sebelisa `FnOnce` e le tlamo ha u batla ho amohela paramethara ea mofuta o ts'oanang le ts'ebetso mme u hloka feela ho e letsetsa hang.
/// Haeba o hloka ho letsetsa parameter khafetsa, sebelisa [`FnMut`] e le tlamo;haeba u e hloka hore u se ke ua fetola boemo, sebelisa [`Fn`].
///
/// Bona [chapter on closures in *The Rust Programming Language*][book] bakeng sa tlhaiso-leseling e batsi ka taba ena.
///
/// Hape hoa hlokomeleha ke syntax e khethehileng ea `Fn` traits (mohlala
/// `Fn(usize, bool) -> sebelisa``).Ba thahasellang lintlha tsa tekheniki ea sena ba ka bua ka [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ho sebelisa parameter ea `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` e sebelisa mefuta-futa ea eona e hapuoeng, ka hona e ke ke ea sebetsoa hangata.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ho leka ho kopa `func()` hape ho tla lahlela phoso ea `use of moved value` bakeng sa `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` e ke ke ea hlola e sebelisoa nakong ena
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // e le hore regex e tšepe `&str: !FnMut` eo
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Mofuta o khutlisitsoeng kamora hore opareitara e sebelise.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// E etsa ts'ebetso ea mohala.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}