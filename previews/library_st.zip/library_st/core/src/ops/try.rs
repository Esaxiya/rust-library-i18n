/// trait bakeng sa ho itšoara ka mokhoa o ikhethileng oa mosebelisi oa `?`.
///
/// Mofuta o sebelisang `Try` ke o nang le tsela ea kananelo ea ho o sheba ho latela success/failure dichotomy.
/// trait ena e lumella ho ntša boleng ba katleho kapa ho hloleha boemong bo seng bo ntse bo le teng le ho theha mohlala o mocha ho tloha katlehong kapa boleng ba ho hloleha.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Mofuta oa boleng bona ha o nkuoa o atlehile.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Mofuta oa boleng bona ha o nkuoa o hloleha.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// E kenya ts'ebetso ea "?".Ho khutla ha `Ok(t)` ho bolela hore ts'ebetso e lokela ho tsoelapele ka mokhoa o tloaelehileng, 'me sephetho sa `?` ke boleng ba `t`.
    /// Ho khutla ha `Err(e)` ho bolela hore ho bolaoa ho lokela hore branch e kenelle hare ka hare ho `catch`, kapa e khutle mosebetsing.
    ///
    /// Haeba sephetho sa `Err(e)` se khutlisoa, boleng ba `e` e tla ba "wrapped" ka mofuta oa ho khutla oa sebaka se koetsoeng (se lokelang ho kenya ts'ebetsong `Try`).
    ///
    /// Ka ho khetheha, boleng ba `X::from_error(From::from(e))` boa khutlisoa, moo `X` e leng mofuta oa ho khutlisa oa mosebetsi o koetsoeng.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Phuthela boleng ba phoso ho theha sephetho se kopaneng.
    /// Mohlala, `Result::Err(x)` le `Result::from_error(x)` lia lekana.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Koahela boleng ba OK ho theha sephetho se kopaneng.
    /// Mohlala, `Result::Ok(x)` le `Result::from_ok(x)` lia lekana.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}