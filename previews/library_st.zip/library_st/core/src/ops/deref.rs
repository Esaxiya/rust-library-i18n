/// E sebelisetsoa ts'ebetso e sa fetoheng ea ho hlakola, joalo ka `*v`.
///
/// Ntle le ho sebelisoa bakeng sa ts'ebetso e hlakileng ea ho tlosa litšupiso le (unary) `*` ka maemo a sa fetoheng, `Deref` e boetse e sebelisoa ka botlalo ke motlatsi maemong a mangata.
/// Mochini ona o bitsoa ['`Deref` coercion'][more].
/// Maemong a ka fetohang, [`DerefMut`] ea sebelisoa.
///
/// Ho kenya ts'ebetsong `Deref` bakeng sa litlhahiso tse bohlale ho etsa hore ho fihlella data e ka morao ho bona e be bonolo, ke ka lebaka leo ba sebelisang `Deref`.
/// Ka lehlakoreng le leng, melao e mabapi le `Deref` le [`DerefMut`] e ne e etselitsoe ka kotlolloho ho amohela litlhahiso tse bohlale.
/// Ka lebaka la sena, ** `Deref` e lokela ho kengoa ts'ebetsong feela bakeng sa litsupa tse bohlale ho qoba pherekano.
///
/// Ka mabaka a tšoanang,**trait ena ha ea lokela ho hloleha**.Ho hloleha nakong ea ho hlakoloa ho ka ferekanya haholo ha `Deref` e sebelisoa ka botlalo.
///
/// # Ho eketsehileng ka ho qobelloa ha `Deref`
///
/// Haeba `T` e sebelisa `Deref<Target = U>`, 'me `x` ke boleng ba mofuta oa `T`, joale:
///
/// * Maemong a sa fetoheng, `*x` (moo `T` e seng sesupiso kapa sesupa se tala) e lekana le `* Deref::deref(&x)`.
/// * Litekanyetso tsa mofuta oa `&T` li qobelloa ho latela boleng ba mofuta oa `&U`
/// * `T` e sebelisa ka botlalo mekhoa eohle ea (immutable) ea mofuta `U`.
///
/// Bakeng sa lintlha tse ling, etela [the chapter in *The Rust Programming Language*][book] hammoho le likarolo tsa litšupiso ho [the dereference operator][ref-deref-op], [method resolution] le [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Moralo o nang le tšimo e le 'ngoe e ka fihlelloang ka ho hlakola sebopeho sa moralo.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Mofuta o hlahisoang kamora ho hlakola.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// E khetholla boleng.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// E sebelisetsoa ts'ebetso ea ho hlakola e ka feto-fetohang, joalo ka `*v = 1;`.
///
/// Ntle le ho sebelisoa bakeng sa ts'ebetso e hlakileng ea ho tlosa litšupiso le (unary) `*` ka maemo a ka fetohang, `DerefMut` e sebelisoa ka mokhoa o felletseng ke motlatsi maemong a mangata.
/// Mochini ona o bitsoa ['`Deref` coercion'][more].
/// Maemong a sa fetoheng, [`Deref`] ea sebelisoa.
///
/// Ho kenya ts'ebetsong `DerefMut` bakeng sa litlhahiso tse bohlale ho etsa hore data e ka morao ea bona e fetohe habonolo, ke ka lebaka leo ba sebelisang `DerefMut`.
/// Ka lehlakoreng le leng, melao e mabapi le [`Deref`] le `DerefMut` e ne e etselitsoe ka kotlolloho ho amohela litlhahiso tse bohlale.
/// Ka lebaka la sena, ** `DerefMut` e lokela ho kengoa ts'ebetsong feela bakeng sa litsupa tse bohlale ho qoba pherekano.
///
/// Ka mabaka a tšoanang,**trait ena ha ea lokela ho hloleha**.Ho hloleha nakong ea ho hlakoloa ho ka ferekanya haholo ha `DerefMut` e sebelisoa ka botlalo.
///
/// # Ho eketsehileng ka ho qobelloa ha `Deref`
///
/// Haeba `T` e sebelisa `DerefMut<Target = U>`, 'me `x` ke boleng ba mofuta oa `T`, joale:
///
/// * Maemong a ka fetohang, `*x` (moo `T` e seng sets'oants'o kapa sesupa se tala) e lekana le `* DerefMut::deref_mut(&mut x)`.
/// * Litekanyetso tsa mofuta oa `&mut T` li qobelloa ho latela boleng ba mofuta oa `&mut U`
/// * `T` e sebelisa ka botlalo mekhoa eohle ea (mutable) ea mofuta `U`.
///
/// Bakeng sa lintlha tse ling, etela [the chapter in *The Rust Programming Language*][book] hammoho le likarolo tsa litšupiso ho [the dereference operator][ref-deref-op], [method resolution] le [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Moralo o nang le tšimo e le 'ngoe e ka fetoloang ka ho hlakola sebopeho sa struct.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ka mokhoa o ts'oanang, e hlahisa boleng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// E bontša hore sebopeho se ka sebelisoa e le mokhoa oa ho amohela, ntle le karolo ea `arbitrary_self_types`.
///
/// Sena se kengoa tšebetsong ke mefuta ea pointer ea stdlib joalo ka `Box<T>`, `Rc<T>`, `&T`, le `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}