use crate::marker::Unsize;

/// Trait e bonts'ang hore sena ke sesupa kapa sekoahelo bakeng sa se le seng, moo ho sa sisinyeheng ho ka etsoang ho pointee.
///
/// Bona [DST coercion RFC][dst-coerce] le [the nomicon entry on coercion][nomicon-coerce] bakeng sa lintlha tse ling.
///
/// Bakeng sa mefuta ea pointer ea pointer, litsupa ho `T` li tla qobella litsupa ho `U` haeba `T: Unsize<U>` ka ho fetola sesupa se tšesaane ho isa sesupa sa mafura.
///
/// Bakeng sa mefuta ea moetlo, ho qobelloa mona ho sebetsa ka ho qobella `Foo<T>` ho `Foo<U>` ha feela XLUM `CoerceUnsized<Foo<U>> for Foo<T>` e le teng.
/// Tlhahiso e joalo e ka ngoloa feela haeba `Foo<T>` e na le tšimo e le 'ngoe feela eo e seng ea phantomdata e kenyelletsang `T`.
/// Haeba mofuta oa tšimo eo ke `Bar<T>`, ts'ebetso ea `CoerceUnsized<Bar<U>> for Bar<T>` e tlameha ho ba teng.
/// Ho qobelloa ho tla sebetsa ka ho qobella tšimo ea `Bar<T>` ho `Bar<U>` le ho tlatsa masimo a mang ho tloha `Foo<T>` ho theha `Foo<U>`.
/// Sena se tla fella hantle tšimong ea pointer le ho qobella seo.
///
/// Ka kakaretso, bakeng sa litlhahiso tse bohlale o tla kenya ts'ebetsong `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ka khetho ea `?Sized` e tlameletsoeng ho `T` ka boeona.
/// Bakeng sa mefuta e koahelang ka kotloloho `T` joalo ka `Cell<T>` le `RefCell<T>`, o ka kenya `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ka kotloloho.
///
/// Sena se tla lumella likhakanyo tsa mefuta e kang `Cell<Box<T>>` hore e sebetse.
///
/// [`Unsize`][unsize] e sebelisoa ho tšoaea mefuta e ka qobelloang ho DSTs haeba e le ka morao ho litsupa.E kengoa tšebetsong ka boiketsetso ke motlatsi.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// phetoho mut-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mofuta T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* sehlopha sa U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Sena se sebelisetsoa polokeho ea ntho, ho netefatsa hore na mofuta oa moamoheli o ka romelloa ho ona.
///
/// Mohlala oa ho kenya tšebetsong trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* sehlopha sa U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// phetoho mut-> * mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}