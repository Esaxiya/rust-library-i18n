/// Khoutu ea moetlo kahare ho mosenyi.
///
/// Ha boleng bo se bo sa hlokahale, Rust e tla tsamaisa "destructor" ka boleng boo.
/// Mokhoa o tloaelehileng haholo oa hore boleng ha bo sa hlokahala ke ha o tsoa maemong.Bahlaseli ba ntse ba ka sebetsa maemong a mang, empa re tla shebana le boholo ba mehlala mona.
/// Ho ithuta ka tse ling tsa linyeoe tse ling, ka kopo bona karolo ea [the reference] ho basenyi.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Mosenyi enoa o na le likarolo tse peli:
/// - Ho letsetsa `Drop::drop` bakeng sa boleng boo, haeba `Drop` trait ena e kengoang tšebetsong e sebelisetsoa mofuta oa eona.
/// - "drop glue" e iketselitseng ka boeona e bitsang basenyi ba likarolo tsohle tsa boleng bona.
///
/// Ha Rust e ipitsa ka boeona batšosi ba likarolo tsohle tse nang le lintho, ha ua tlameha ho kenya `Drop` maemong a mangata.
/// Empa ho na le maemo a mang moo ho leng bohlokoa, mohlala bakeng sa mefuta e laolang sesebelisoa ka kotloloho.
/// Sesebelisoa seo e ka ba memori, ekaba se hlalosang faele, ekaba sekoti sa netweke.
/// Hang ha boleng ba mofuta oo bo se bo sa sebelisoe, e lokela ho sebelisa sesebelisoa sa eona sa "clean up" ka ho lokolla memori kapa ho koala faele kapa socket.
/// Ona ke mosebetsi oa mosenyi, ka hona ke mosebetsi oa `Drop::drop`.
///
/// ## Examples
///
/// Ho bona batšosi ba sebetsa, ha re shebeng lenaneo le latelang:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust e tla letsetsa `Drop::drop` bakeng sa `_x` ebe bakeng sa `_x.one` le `_x.two`, ho bolelang hore ho tsamaisa sena ho tla hatisa
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Leha re tlosa ts'ebetsong ea `Drop` bakeng sa `HasTwoDrop`, basenyi ba masimo a eona ba ntse ba bitsoa.
/// Sena se ka fella ka
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## U ke ke ua letsetsa `Drop::drop` u le mong
///
/// Hobane `Drop::drop` e sebelisetsoa ho hloekisa boleng, ho ka ba kotsi ho sebelisa boleng bona kamora hore mokhoa o bitsoe.
/// Kaha `Drop::drop` ha e nke karolo ea eona, Rust e thibela tšebeliso e mpe ka ho se u lumelle ho letsetsa `Drop::drop` ka kotloloho.
///
/// Ka mantsoe a mang, haeba u leka ho letsetsa `Drop::drop` ka ho hlaka mohlaleng o kaholimo, u tla fumana phoso ea ho bokella.
///
/// Haeba u ka rata ho letsetsa mosenyi oa boleng ka ho hlaka, [`mem::drop`] e ka sebelisoa ho fapana.
///
/// [`mem::drop`]: drop
///
/// ## Lahlela otara
///
/// Ke le leng la marotholi a rona a mabeli a `HasDrop` pele, leha ho le joalo?Bakeng sa li-structs, ke tatellano e tšoanang eo ba phatlalatsoang ka eona: pele `one`, ebe `two`.
/// Haeba u ka rata ho itlhahloba, u ka fetola `HasDrop` kaholimo ho ba le lintlha, joalo ka palo e kholo, ebe u e sebelisa ho `println!` kahare ho `Drop`.
/// Boitšoaro bona bo netefalitsoe ke puo.
///
/// Ho fapana le li-structs, mefuta-futa ea lehae e lahloa ka tatellano e fapaneng:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Sena se tla hatisa
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Ka kopo bona [the reference] bakeng sa melao e felletseng.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` le `Drop` li ikhethile
///
/// U ke ke ua kenya tšebetsong [`Copy`] le `Drop` ka mofuta o le mong.Mefuta e `Copy` e kopitsoa ka mokhoa o hlakileng ke moqapi, ho etsa hore ho be thata haholo ho tseba esale pele hore na basenyi ba tla bolaoa hangata hakae.
///
/// Kahoo, mefuta ena e ke ke ea ba le batšosi.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// E phethisa moferefere oa mofuta ona.
    ///
    /// Mokhoa ona o bitsoa ka mokhoa o hlakileng ha boleng bo tsoa boemong, 'me bo ke ke ba bitsoa ka mokhoa o hlakileng (ena ke phoso ea ho kopanya [E0040]).
    /// Leha ho le joalo, mosebetsi oa [`mem::drop`] ho prelude o ka sebelisoa ho bitsa ts'ebetsong ea `Drop` ea ngangisano.
    ///
    /// Ha mokhoa ona o se o bitsoa, `self` ha e so tsamaisoe.
    /// Seo se etsahala feela kamora hore mokhoa o fele.
    /// Haeba ho ne ho se joalo, `self` e ne e tla ba tšupiso e leketlileng.
    ///
    /// # Panics
    ///
    /// Kaha [`panic!`] e tla letsetsa `drop` ha e phutholoha, [`panic!`] efe kapa efe ts'ebetsong ea `drop` e kanna ea senyeha.
    ///
    /// Hlokomela hore le ha panics ena, boleng bo nkuoa bo theotsoe;
    /// ha ua tlameha ho etsa hore `drop` e letsoe hape.
    /// Hangata sena se sebetsoa ka boiketsetso ke motlatsi, empa ha o sebelisa khoutu e sa bolokehang, ka linako tse ling e ka hlaha e se ka boikemisetso, haholoholo ha o sebelisa [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}