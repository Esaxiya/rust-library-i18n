//! Lijana tse arolelanoang tse ka fetoloang.
//!
//! Ts'ireletso ea memori ea Rust e ipapisitse le molao ona: Ha u fuoa ntho `T`, ho ka etsahala feela hore u be le e 'ngoe ea tse latelang:
//!
//! - Ho ba le litšupiso tse 'maloa tse sa fetoheng (`&T`) nthong (e tsejoang hape e le **aliasing**).
//! - Ho ba le ts'upiso e le 'ngoe e ka feto-fetohang (`&mut T`) ho ntho (eo hape e tsejoang e le **mutability**).
//!
//! Sena se qobelloa ke moqapi oa Rust.Leha ho le joalo, ho na le maemo moo molao ona o sa fetoheng habonolo.Ka linako tse ling ho hlokahala hore ho be le litšupiso tse ngata ho ntho empa oe fetole.
//!
//! Lijana tse arolelanoang tse ka arolelanoang li teng bakeng sa ho lumella phetoho ka mokhoa o laoloang, leha o le teng.Ka bobeli [`Cell<T>`] le [`RefCell<T>`] li lumella ho etsa sena ka tsela e le 'ngoe.
//! Leha ho le joalo, ha ho `Cell<T>` kapa `RefCell<T>` e sireletsehileng ka khoele (ha e sebelise [`Sync`]).
//! Haeba o hloka ho khetholla le ho fetoha lipakeng tsa likhoele tse ngata ho ka etsahala hore o sebelise mefuta ea [`Mutex<T>`], [`RwLock<T>`] kapa [`atomic`].
//!
//! Litekanyetso tsa mefuta ea `Cell<T>` le `RefCell<T>` li ka fetoloa ka litšupiso tse arolelanoeng (ke hore
//! mofuta o tloaelehileng oa `&T`), athe mefuta e mengata ea Rust e ka fetoloa feela ka litšupiso tse ikhethang (`&mut T`).
//! Re re `Cell<T>` le `RefCell<T>` li fana ka 'phetoho ea kahare', ho fapana le mefuta e tloaelehileng ea Rust e bonts'ang 'ho fetoha ho futsitsoeng'.
//!
//! Mefuta ea lisele e na le litatso tse peli: `Cell<T>` le `RefCell<T>`.`Cell<T>` e kenya ts'ebetsong phetoho ea kahare ka ho tsamaisa litekanyetso le ho tsoa ho `Cell<T>`.
//! Ho sebelisa litšupiso ho fapana le litekanyetso, motho o tlameha ho sebelisa mofuta oa `RefCell<T>`, a iphumanele senotlolo sa ho ngola pele a fetoha.`Cell<T>` e fana ka mekhoa ea ho fumana le ho fetola boleng ba hajoale ba kahare:
//!
//!  - Bakeng sa mefuta e sebelisang [`Copy`], mokhoa oa [`get`](Cell::get) o fumana boleng ba hajoale ba kahare.
//!  - Bakeng sa mefuta e sebelisang [`Default`], mokhoa oa [`take`](Cell::take) o nkela boleng ba hona joale ba hare sebaka ka [`Default::default()`] mme o khutlisa boleng bo nkeloeng sebaka.
//!  - Bakeng sa mefuta eohle, mokhoa oa [`replace`](Cell::replace) o nka sebaka sa boleng ba hajoale ba kahare mme o khutlisa boleng bo nchafalitsoeng mme mokhoa oa [`into_inner`](Cell::into_inner) o sebelisa `Cell<T>` mme o khutlisa boleng ba hare.
//!  Ntle le moo, mokhoa oa [`set`](Cell::set) o nka sebaka sa boleng ba kahare, o theola boleng bo nkeloeng sebaka.
//!
//! `RefCell<T>` e sebelisa nako ea bophelo ea Rust ho kenya ts'ebetsong 'ho kalima ka matla', ts'ebetso eo ka eona motho a ka batlang phihlello ea nakoana, e ikhethileng, e ka fetoloang ho boleng ba kahare
//! E kalima bakeng sa `RefCell<T>`s's tracked 'at runtime', Ho fapana le mefuta ea Rust ea tlhaiso-leseling e lateloang ka botlalo, ka nako ea ho bokella.
//! Hobane mekoloto ea `RefCell<T>` e matla ho a khonahala ho leka ho alima boleng bo seng bo alimiloe ka mokhoa o ts'oanang;ha sena se etsahala se fella ka khoele panic.
//!
//! # Nako ea ho khetha phetoho ea kahare
//!
//! Ho fetoha ho tloaelehileng ho futsitsoeng, moo motho a tlamehang ho ba le phihlello e ikhethang ea ho fetola boleng, ke e 'ngoe ea lintlha tsa bohlokoa tsa puo tse nolofalletsang Rust ho beha mabaka ka matla mabapi le ho hlaba pointer, ho thibela lipalo tsa likotsi.
//! Ka lebaka leo, phetoho ea lefutso e ratoa haholo, 'me ho fetoha hoa kahare ke ntho ea hoqetela.
//! Kaha mefuta ea lisele e nolofalletsa ho fetoha moo e neng e ke ke ea lumelloa leha ho le joalo, ho na le linako tseo phetoho ea kahare e ka bang e loketseng, kapa esita le * e tlameha ho sebelisoa, mohlala
//!
//! * Ho hlahisa phetoho 'inside' ea ntho e sa fetoheng
//! * Lintlha tsa ho kenya ts'ebetsong mekhoa e sa fetoheng.
//! * Ho fetola ts'ebetsong ea [`Clone`].
//!
//! ## Ho hlahisa phetoho 'inside' ea ntho e sa fetoheng
//!
//! Mefuta e mengata ea li-pointer tse bohlale, ho kenyeletsoa [`Rc<T>`] le [`Arc<T>`], li fana ka lijana tse ka koptjoang le ho arolelanoa lipakeng tsa mekha e mengata.
//! Hobane boleng bo ka ba teng, bo ka alima feela ka `&` eseng `&mut`.
//! Ntle le lisele ho ka se khonehe ho fetisetsa data kahare ho litlhahiso tsena tse bohlale ho hang.
//!
//! Ho tloaelehile haholo ka nako eo ho beha `RefCell<T>` kahare ho mefuta ea pointer e arolelanoeng ho hlahisa phetoho.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Theha block e ncha ho fokotsa boholo ba kalimo e matla
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Hlokomela hore haeba re ne re sa lumelle mokoloto o fetileng oa cache hore o se ke oa oela, kalimo e latelang e ka baka khoele e matla panic.
//!     //
//!     // Ena ke kotsi e kholo ea ho sebelisa `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Hlokomela hore mohlala ona o sebelisa `Rc<T>` eseng `Arc<T>`.Refell<T>`s ke tsa maemo a likhoele a le mong.Nahana ka ho sebelisa [`RwLock<T>`] kapa [`Mutex<T>`] haeba u hloka phetoho e arolelanoeng maemong a mangata.
//!
//! ## Lintlha tsa ho kenya ts'ebetsong mekhoa e sa fetoheng
//!
//! Nako le nako ho ka ba hotle hore o se ke oa pepesa ho API hore ho na le phetoho e etsahalang "under the hood".
//! Sena se ka bakoa ke hore ka mokhoa o utloahalang ts'ebetso e ke ke ea fetoha, empa mohlala, caching e qobella ts'ebetsong ho etsa phetoho;kapa hobane o tlameha ho sebelisa phetoho ho kenya ts'ebetsong mokhoa oa trait o neng o hlalosoa qalong ho nka `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Khomphutha e turang e ea mona
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Ho fetola ts'ebetsong ea `Clone`
//!
//! Ena ke ketsahalo e khethehileng feela, empa e le e tloaelehileng ea tse fetileng: ho pata ho fetoha ha ts'ebetso ea lits'ebetso tse bonahalang li sa fetohe.
//! Mokhoa oa [`clone`](Clone::clone) o lebelletsoe hore o se fetole boleng ba mohloli, mme ho phatlalatsoa hore o nka `&self`, eseng `&mut self`.
//! Ka hona, phetoho efe kapa efe e etsahalang ka `clone` e tlameha ho sebelisa mefuta ea sele.
//! Mohlala, [`Rc<T>`] e boloka palo ea eona ea litšupiso kahare ho `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Sebaka sa memori se ka fetohang.
///
/// # Examples
///
/// Mohlala ona, u ka bona hore `Cell<T>` e thusa phetoho kahare ho sebopeho se sa fetoheng.
/// Ka mantsoe a mang, e nolofalletsa "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // PHOSO: `my_struct` ha e fetohe
/// // my_struct.regular_field =boleng bo bocha;
///
/// // MOSEBETSI: leha `my_struct` e sa fetohe, `special_field` ke `Cell`,
/// // e ka fetoloang kamehla
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// E etsa `Cell<T>`, e nang le boleng ba `Default` bakeng sa T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// E etsa `Cell` e ncha e nang le boleng bo fanoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// E beha boleng bo fuperoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// E fetola boleng ba Lisele tse peli.
    /// Phapang le `std::mem::swap` ke hore mosebetsi ona ha o hloke ho buuoa ka `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // TSHIRELETSO: Sena se ka ba kotsi ha o ka bitswa ka dikgwele tse arohaneng, empa `Cell`
        // ke `!Sync` kahoo sena se ke ke sa etsahala.
        // Sena hape se ke ke sa etsa litlhahiso life kapa life ho tloha ha `Cell` e etsa bonnete ba hore ha ho letho le leng le tla supa ho e 'ngoe ea `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// E khutlisa boleng bo nang le `val`, ebe e khutlisa boleng ba khale bo nang le eona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // TSHIRELETSO: Sena se ka baka merabe ea data haeba e bitsoa ho tsoa khoeleng e arohaneng,
        // empa `Cell` ke `!Sync` kahoo sena se ke ke sa etsahala.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// E notlolla boleng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// E khutlisa kopi ea boleng bo nang le eona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // TSHIRELETSO: Sena se ka baka merabe ea data haeba e bitsoa ho tsoa khoeleng e arohaneng,
        // empa `Cell` ke `!Sync` kahoo sena se ke ke sa etsahala.
        unsafe { *self.value.get() }
    }

    /// E ntlafatsa boleng bo nang le ts'ebeliso ka ts'ebetso mme e khutlisa boleng bo bocha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// E khutlisetsa sesupi se sa hlahisoang ho data e ka seleng ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// E khutlisetsa ts'upiso e ka feto-fetohang ho data ea mantlha.
    ///
    /// Mohala ona o kalima `Cell` ka mokhoa o feto-fetohang (ka nako ea ho bokella) e netefatsang hore re na le ts'upiso feela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// E khutlisa `&Cell<T>` ho tloha `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // TSHIRELETSO: `&mut` e netefatsa phihlello e ikhethang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// E nka boleng ba sele, e siea `Default::default()` sebakeng sa eona.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// E khutlisa `&[Cell<T>]` ho tloha `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // TŠIRELETSO: `Cell<T>` e na le sebopeho sa memori se tšoanang le `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Sebaka sa memori se ka feto-fetohang se nang le melao e hlahlojoang ka matla
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Phoso e khutlisitsoeng ke [`RefCell::try_borrow`]
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Phoso e khutlisitsoeng ke [`RefCell::try_borrow_mut`]
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Litekanyetso tse ntle li emela palo ea `Ref` e sebetsang.Litekanyetso tse fosahetseng li emela palo ea `RefMut` e sebetsang.
// `RefMut`s tse ngata li ka sebetsa ka nako e le 'ngoe haeba li bua ka likarolo tse khethollang, tse sa hlakang tsa `RefCell` (mohlala, mekhahlelo e fapaneng ea selae).
//
// `Ref` le `RefMut` ka bobeli ke mantsoe a mabeli ka boholo, ka hona ho kanna ha se ke ha ba le `Ref`s kapa`RefMut`s tse lekaneng ho phalla halofo ea mokoloko oa X01.
// Kahoo, `BorrowFlag` mohlomong e ke ke ea phalla kapa ea koaheloa.
// Leha ho le joalo, sena ha se tiiso, hobane lenaneo la ts'oaetso le ka theha khafetsa ebe mem::forget `Ref`s kapa`RefMut`s.
// Ka hona, khoutu eohle e tlameha ho hlahloba ka ho hlaka hore na e khaphatseha le ho tlala e le ho qoba ho se sireletsehe, kapa bonyane ho itšoara hantle ha ho ka etsahala hore ho phalla kapa ho phalla (mohlala, bona BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// E etsa `RefCell` e ncha e nang le `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// E sebelisa `RefCell`, e khutlisa boleng bo phuthetsoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Kaha mosebetsi ona o nka `self` (`RefCell`) ka boleng, mokopanyi o netefatsa hore ha e alingoe hona joale.
        //
        self.value.into_inner()
    }

    /// E khutlisa boleng bo phuthetsoeng ka e ncha, e khutlisa boleng ba khale, ntle le ho hlakola e 'ngoe ea tsona.
    ///
    ///
    /// Mosebetsi ona o tsamaellana le [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics haeba boleng bo alingoe hajoale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// E khutlisetsa boleng bo phuthetsoeng ka e ncha e ngotsoeng ho tloha `f`, e khutlisa boleng ba khale, ntle le ho hlakola e le 'ngoe.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba boleng bo alingoe hajoale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// E chencha boleng bo phuthetsoeng ba `self` le boleng bo phuthetsoeng ba `other`, ntle le ho hlakola e le 'ngoe.
    ///
    ///
    /// Mosebetsi ona o tsamaellana le [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// O alima boleng bo phuthetsoeng.
    ///
    /// Mokoloto o tšoarella ho fihlela `Ref` e khutlisitsoeng e tsoa.
    /// Likalimo tse ngata tse sa fetoheng li ka nkuoa ka nako e le ngoe.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng hona joale bo alimiloe ka mokhoa o lumellanang.
    /// Bakeng sa phapang e sa ts'oenyeheng, sebelisa [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Mohlala oa panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// O alima boleng bo phuthetsoeng, o khutlisa phoso haeba boleng hona joale bo alimiloe.
    ///
    ///
    /// Mokoloto o tšoarella ho fihlela `Ref` e khutlisitsoeng e tsoa.
    /// Likalimo tse ngata tse sa fetoheng li ka nkuoa ka nako e le ngoe.
    ///
    /// Ena ke phapang e sa ts'oenyeheng ea [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // TSHIRELETSO: `BorrowRef` e netefatsa hore ho na le phihlello e sa fetoheng feela
            // ho boleng ha o ntse o alimiloe.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Ka bobeli li alima boleng bo phuthetsoeng.
    ///
    /// Mokoloto o tšoarella ho fihlela `RefMut` e khutlisitsoeng kapa `RefMut`s kaofela e tsoang ho eona.
    ///
    /// Boleng bo ke ke ba kalima ha kalimo ena e ntse e sebetsa.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng bo alingoe hajoale.
    /// Bakeng sa phapang e sa ts'oenyeheng, sebelisa [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Mohlala oa panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Ka mokhoa o ts'oanang o alima boleng bo phuthetsoeng, o khutlisa phoso haeba boleng bo se bo alimiloe hona joale.
    ///
    ///
    /// Mokoloto o tšoarella ho fihlela `RefMut` e khutlisitsoeng kapa `RefMut`s kaofela e tsoang ho eona.
    /// Boleng bo ke ke ba kalima ha kalimo ena e ntse e sebetsa.
    ///
    /// Ena ke phapang e sa ts'oenyeheng ea [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // TSHIRELETSO: `BorrowRef` e netefatsa phihlello e ikhethang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// E khutlisetsa sesupi se sa hlahisoang ho data e ka seleng ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// E khutlisetsa ts'upiso e ka feto-fetohang ho data ea mantlha.
    ///
    /// Mohala ona o alima `RefCell` ka mokhoa o feto-fetohang (ka nako ea ho bokella) ka hona ha ho na tlhoko ea licheke tse matla.
    ///
    /// Leha ho le joalo e-ba hlokolosi: mokhoa ona o lebelletse hore `self` e ka fetoha, eo hangata ho seng joalo ha u sebelisa `RefCell`.
    ///
    /// Sheba mokhoa oa [`borrow_mut`] haeba `self` e sa fetohe.
    ///
    /// Hape, ka kopo hlokomela hore mokhoa ona ke oa maemo a ikhethileng feela mme ha se seo o se batlang.
    /// Haeba o belaela, sebelisa [`borrow_mut`] ho fapana.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Fetola litlamorao tsa balebeli ba lutlang ka boemo ba kalimo ba `RefCell`.
    ///
    /// Mohala ona o ts'oana le [`get_mut`] empa o khethehile haholo.
    /// E alima `RefCell` ka mokhoa o ts'oanang ho netefatsa hore ha ho na mekoloto e teng ebe e hlophisa bocha likoloto tse arolelanoeng tsa mmuso.
    /// Sena se bohlokoa haeba mekoloto e meng ea `Ref` kapa `RefMut` e lutsoe.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// O alima boleng bo phuthetsoeng, o khutlisa phoso haeba boleng hona joale bo alimiloe.
    ///
    /// # Safety
    ///
    /// Ho fapana le `RefCell::borrow`, mokhoa ona ha o bolokehe hobane ha o khutlise `Ref`, ka hona o siea folakha e alimiloeng e sa angoa.
    /// Ho alima `RefCell` ka mokhoa o ts'oanang ha ts'upiso e khutlisitsoeng ke mokhoa ona e ntse e phela ke boits'oaro bo sa hlalosoang.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // TSHIRELETSO: Re netefatsa hore ha ho na motho ea ngolang ka mafolofolo hona joale, empa ho joalo
            // Boikarabello ba moletsi ho netefatsa hore ha ho motho ea ngolang ho fihlela lengolo le khutlisitsoeng ha le sa sebelisoa.
            // Hape, `self.value.get()` e bua ka boleng ba `self` mme ka hona e netefalitsoe hore e tla sebetsa bakeng sa bophelo bohle ba `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// E nka boleng bo phuthetsoeng, e siea `Default::default()` sebakeng sa eona.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng bo alingoe hajoale.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics haeba boleng hona joale bo alimiloe ka mokhoa o lumellanang.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// E etsa `RefCell<T>`, e nang le boleng ba `Default` bakeng sa T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics haeba boleng ba `RefCell` e se bo alimiloe hona joale.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Ho eketsa mokoloto ho ka baka boleng ba ho se bale (<=0) maemong ana:
            // 1. E ne e le <0, ke hore ho na le mekoloto e ngolang, ka hona re ke ke ra lumella ho balloa ho baloa ka lebaka la melao ea ts'ebeliso ea Rust
            // 2.
            // E ne e le isize::MAX (boholo ba likalimo tsa ho bala) mme e ile ea phalla ho isize::MIN (palo e kholo ea ho kalima ho ngola) ka hona re ka se lumelle ho bala ho eketsehileng hobane kalimo e ke ke ea emela likalimo tse ngata tsa batho ba balang (sena se ka etsahala feela haeba uena mem::forget ho feta palo e nyane ea li-Ref, e seng tloaelo e ntle)
            //
            //
            //
            //
            None
        } else {
            // Ho eketsa mokoloto ho ka baka boleng ba ho bala (> 0) maemong ana:
            // 1. E ne e le=0, ke hore e ne e sa alingoe, mme re nka kalimo ea pele e baliloeng
            // 2. E ne e le> 0 le <isize::MAX, ke hore
            // ho ne ho baliloe likalimo, 'me isize e kholo ho lekana ho emela hore ho bala e le ngoe hape
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Kaha Ref ena e teng, rea tseba hore folakha e alimiloeng ke kalimo ea ho bala.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Thibela khaontara ea kalimo hore e se ke ea phalla ho fihlela e le kalimo ea ho ngola.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Phutha tšupiso e alimiloeng ea boleng lebokoseng la `RefCell`.
/// Mofuta oa sekoahelo sa boleng bo alimiloeng bo sa fetoheng ho `RefCell<T>`.
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// E kopitsa `Ref`.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o sa fetoheng, kahoo sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `Ref::clone(...)`.
    /// Ts'ebetso ea `Clone` kapa mokhoa o ka sitisa ts'ebeliso e pharalletseng ea `r.borrow().clone()` ho kopanya litaba tsa `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// E etsa `Ref` e ncha bakeng sa karolo ea data e alimiloeng.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o sa fetoheng, kahoo sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `Ref::map(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// E etsa `Ref` e ncha bakeng sa karolo ea boikhethelo ea data e alimiloeng.
    /// Molebeli oa mantlha o khutlisoa e le `Err(..)` haeba ho koaloa ho khutlisa `None`.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o sa fetoheng, kahoo sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `Ref::filter_map(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// E arola `Ref` ho li-Ref tse ngata bakeng sa likarolo tse fapaneng tsa data e alimiloeng.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o sa fetoheng, kahoo sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `Ref::map_split(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Fetolela moo ho buuoang ka data ea mantlha.
    ///
    /// `RefCell` ea mantlha e ke ke ea alima ka mokhoa o feto-fetohang hape 'me e tla lula e bonahala e se e alimiloe ka mokhoa o sa fetoheng.
    ///
    /// Ha se mohopolo o motle ho dutla ho feta palo ea litšupiso tse sa fetoheng.
    /// `RefCell` e ka alima ka mokhoa o sa fetoheng haeba ho bile le palo e nyane feela ea ho dutla ho etsahetseng ka botlalo.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `Ref::leak(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ka ho lebala Ref ena re netefatsa hore khaontara ea kalimo ho RefCell e ke ke ea khutlela UNUSED nakong ea bophelo ba `'b`.
        // Ho hlophisa boemo ba ts'ebeliso ea litšupiso ho ka hloka hore ho sebelisoe ireferense e ikhethileng ea RefCell e alimiloeng.
        // Ha ho na litšupiso tse ling tse ka fetoloang tse ka tsoang seleng ea mantlha.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// E etsa `RefMut` e ncha bakeng sa karolo ea data e alimiloeng, mohlala, mofuta o fapaneng oa enum.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o ts'oanang, ka hona sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `RefMut::map(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): lokisa ho alima-cheka
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// E etsa `RefMut` e ncha bakeng sa karolo ea boikhethelo ea data e alimiloeng.
    /// Molebeli oa mantlha o khutlisoa e le `Err(..)` haeba ho koaloa ho khutlisa `None`.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o ts'oanang, ka hona sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `RefMut::filter_map(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): lokisa ho alima-cheka
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // TSHIRELETSO: Tshebetso e tshwere tshupiso e ikgethang ya nako eo
        // ea mohala oa eona ka `orig`, 'me sesupi se hlakisoa feela kahare ho mohala oa ts'ebetso ha o lumelle hore ho buuoe ka bohona feela.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // TSHIRELETSO: go tshwana le fa godimo.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// E arola `RefMut` ho ea ho `RefMut`s tse ngata bakeng sa likarolo tse fapaneng tsa data e alimiloeng.
    ///
    /// `RefCell` ea mantlha e tla lula e alimiloe ka mokhoa o ts'oanang ho fihlela li khutlisitsoe `RefMut`s li sa sebetse.
    ///
    /// `RefCell` e se e alimiloe ka mokhoa o ts'oanang, ka hona sena se ke ke sa hloleha.
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `RefMut::map_split(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Fetolela ho sesupo sa data e ka fetoloang.
    ///
    /// `RefCell` ea mantlha e ke ke ea alingoa hape mme e tla lula e bonahala e se e alimiloe ka mokhoa o ts'oanang, e etsa hore sets'oants'o se khutlisitsoeng e be sona feela se kahare.
    ///
    ///
    /// Ona ke mosebetsi o amanang le ona o hlokang ho sebelisoa e le `RefMut::leak(...)`.
    /// Mokhoa o ka sitisa mekhoa ea lebitso le le leng ho litaba tsa `RefCell` tse sebelisitsoeng ka `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ka ho lebala BorrowRefMut ena re netefatsa hore khaontara ea kalimo ho RefCell e ke ke ea khutlela UNUSED nakong ea bophelo ba `'b`.
        // Ho hlophisa boemo ba ts'ebeliso ea litšupiso ho ka hloka hore ho sebelisoe ireferense e ikhethileng ea RefCell e alimiloeng.
        // Ha ho na litšupiso tse ling tse ka hlahisoang ho tloha seleng ea mantlha nakong eo ea bophelo, ho etsa hore hajoale ho alima tšupiso e le 'ngoe bakeng sa bophelo bo setseng.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ho fapana le BorrowRefMut::clone, ho bitsoa new ho theha ea pele
        // referense e ka feto-fetohang, ka hona ha hoa lokela hore hajoale ho se be le litšupiso tse teng.
        // Kahoo, ha clone e eketsa palo e ka fetohang, mona re lumella feela ho tloha UNUSED ho ea UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // E kopanya `BorrowRefMut`.
    //
    // Sena se sebetsa feela haeba `BorrowRefMut` ka 'ngoe e sebelisetsoa ho lekola tšupiso e ka feto-fetohang ho mofuta o ikhethileng, o sa hlakoleng oa ntho ea mantlha.
    //
    // Sena ha se ho Clone impl hore khoutu e se bitse sena ka botlalo.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Thibela khaontara ea kalimo hore e se ke ea khaphatseha.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Mofuta oa sekoahelo sa boleng bo alimiloeng bo fetohileng ho `RefCell<T>`.
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Motsoako oa khale oa phetoho ea kahare ho Rust.
///
/// Haeba u na le referense `&T`, ka tloaelo ho Rust moqapi o etsa likhakanyo ho latela tsebo ea hore `&T` e supa lintlha tse sa fetoheng.Ho fetola data eo, ka mohlala ka li-alias kapa ka ho fetisetsa `&T` ho `&mut T`, ho nkuoa e le boits'oaro bo sa hlalosoang.
/// `UnsafeCell<T>` ho tsoa ho netefatso ea ho se fetohe bakeng sa `&T`: referense e arolelanoeng `&UnsafeCell<T>` e kanna ea supa data e fetotsoeng.Sena se bitsoa "interior mutability".
///
/// Mefuta eohle e meng e lumellang phetoho ea kahare, joalo ka `Cell<T>` le `RefCell<T>`, e sebelisa `UnsafeCell` ka hare ho phuthela lintlha tsa bona.
///
/// Hlokomela hore feela tiiso ea ho se fetohe bakeng sa litšupiso tse arolelanoang e angoa ke `UnsafeCell`.Tiisetso e ikhethang ea litšupiso tse ka fetoloang ha e amehe.Ha ho na * mokhoa oa molao oa ho fumana aliasing `&mut`, leha e le `UnsafeCell<T>`.
///
/// `UnsafeCell` API ka boeona e bonolo haholo: [`.get()`] eu fa sesupa se tala `*mut T` ho litaba tsa eona.Ho fihla ho _you_ joalo ka moqapi oa sengoloa sa ho sebelisa sesupa se tala ka nepo.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Melao e tobileng ea Rust e batlang e fetoha, empa lintlha tsa mantlha ha li na likhang:
///
/// - Haeba u theha tšupiso e bolokehileng ka `'a` ea bophelo bohle (ekaba `&T` kapa `&mut T` reference) e fumanehang ka khoutu e bolokehileng (mohlala, hobane u e khutlisitse), ha ua lokela ho fihlella data ka tsela efe kapa efe e hananang le ts'upiso ea masalla Ea `'a`.
/// Mohlala, sena se bolela hore haeba o nka `*mut T` ho `UnsafeCell<T>` ebe o e lahlela ho `&T`, data e ho `T` e tlameha ho lula e sa fetohe (modulo efe kapa efe ea `UnsafeCell` e fumanoeng ka har'a `T`, ehlile) ho fihlela nako ea bophelo ba motho eo e felloa ke nako.
/// Ka mokhoa o ts'oanang, haeba u theha tšupiso ea `&mut T` e lokiselitsoeng khoutu e bolokehileng, ha ua lokela ho fihlella data ka har'a `UnsafeCell` ho fihlela lengolo leo le fela.
///
/// - Ka linako tsohle, o tlameha ho qoba merabe ea data.Haeba likhoele tse ngata li khona ho fumana `UnsafeCell` e ts'oanang, mangolo ohle a tlameha ho ba le se etsahetseng hantle pele a amana le phihlello e ngoe (kapa sebelisa liathomo).
///
/// Ho thusa ka moralo o nepahetseng, maemo a latelang a phatlalatsoa ka ho hlaka hore a molaong bakeng sa khoutu e nang le khoele e le 'ngoe:
///
/// 1. Referense ea `&T` e ka lokolloa hore e be le khoutu e bolokehileng mme moo e ka ba teng le litšupiso tse ling tsa `&T`, empa eseng le `&mut T`
///
/// 2. Tlhaloso ea `&mut T` e ka lokolloa ho khoutu e bolokehileng haeba `&mut T` kapa `&T` e se teng le eona.`&mut T` e tlameha ho lula e ikhethile.
///
/// Hlokomela hore ha o ntse o fetola litaba tsa `&UnsafeCell<T>` (leha li-`&UnsafeCell<T>` tse ling li bua ka sele) li lokile (ha feela o ka qobella bahlaseli ba kaholimo ka tsela e ngoe), e ntse e le boits'oaro bo sa hlaloseheng ho ba le likhechana tse ngata tsa `&mut UnsafeCell<T>`.
/// Ka mantsoe a mang, `UnsafeCell` ke sekoaelo se etselitsoeng ho sebelisana ka mokhoa o khethehileng le _shared_ accesses (_i.e._, ka mokhoa oa `&UnsafeCell<_>`);ha ho na boselamose leha e le bofe ha u sebetsana le _exclusive_ accesses (_e.g._, ka `&mut UnsafeCell<_>`): ha ho sele kapa boleng bo phuthetsoeng bo ka khetholloang ka nako eo `&mut` e alima ka eona.
///
/// Sena se bontšoa ke sebui sa [`.get_mut()`], e leng _safe_ getter e hlahisang `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Mohlala ke ona o bonts'ang mokhoa oa ho fetola ka nepo se ka hare ho `UnsafeCell<_>` leha ho na le litšupiso tse 'maloa tse hlalosang sele:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Fumana litšupiso tse ngata/tse tšoanang/tse arolelanoeng ho `x` e tšoanang.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // TSHIRELETSO: kahara sebaka sena ha ho na litšupiso tse ling tsa litaba tsa `x`,
///     // kahoo ea rona e ikhethile ka nepo.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- alima-+
///     *p1_exclusive += 27; // |
/// } // <---------- e ke ke ea feta ntlha ena -------------------+
///
/// unsafe {
///     // TSHIRELETSO: mo maemong ano ga go ope yo o solofetseng go nna le phitlhelelo ee kgethegileng ya diteng tsa `x,
///     // kahoo re ka ba le liphihlelo tse ngata tse arolelanoeng ka nako e le ngoe.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Mohlala o latelang o bonts'a taba ea hore phihlello e khethehileng ho `UnsafeCell<T>` e bolela phihlello e ikhethileng ho `T` ea eona:
///
/// ```rust
/// #![forbid(unsafe_code)] // ka phihlello e ikhethileng,
///                         // `UnsafeCell` ke sekoaelo se bonaletsang se sa bonahaleng, ka hona ha ho na tlhoko ea `unsafe` mona.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Fumana litšupiso tse ikhethileng tsa nako ea ho bokella tse amanang le `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Ka ts'upiso e ikhethileng, re ka fetola litaba tsa mahala.
/// *p_unique.get_mut() = 0;
/// // Kapa, ka ho lekana:
/// x = UnsafeCell::new(0);
///
/// // Ha re na le boleng, re ka ntša likateng tsa mahala.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// E theha mohlala o mocha oa `UnsafeCell` o tla phuthela boleng bo boletsoeng.
    ///
    ///
    /// Phihlello eohle ea boleng ba kahare ka mekhoa ke `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// E notlolla boleng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// E fumana sesupa se fetohang ho boleng bo phuthetsoeng.
    ///
    /// Sena se ka lahleloa ho sesupisi sa mofuta ofe kapa ofe.
    /// Netefatsa hore phihlello e ikhethile (ha ho na litšupiso tse sebetsang, tse ka fetoloang kapa che) ha u lahlela `&mut T`, 'me u netefatse hore ha ho na liphetoho kapa liphapang tse ka feto-fetohang ha u ntse u lahlela `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Re ka lahla sesupa feela ho tloha `UnsafeCell<T>` ho ea ho `T` ka lebaka la #[repr(transparent)].
        // Sena se sebelisa boemo bo ikhethileng ba libstd, ha ho na tiiso bakeng sa khoutu ea mosebelisi ea hore sena se tla sebetsa liphetolelong tsa moqapi oa future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// E khutlisetsa ts'upiso e ka feto-fetohang ho data ea mantlha.
    ///
    /// Mohala ona o alima `UnsafeCell` ka mokhoa o feto-fetohang (ka nako ea ho bokella) e netefatsang hore re na le ts'upiso feela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// E fumana sesupa se fetohang ho boleng bo phuthetsoeng.
    /// Phapang ho [`get`] ke hore ts'ebetso ena e amohela sesupa se tala, se leng molemo ho qoba ho theoa ha litšupiso tsa nakoana.
    ///
    /// Sephetho se ka lahleloa ho sesupisi sa mofuta ofe kapa ofe.
    /// Netefatsa hore phihlello e ikhethile (ha ho na litšupiso tse sebetsang, tse ka fetoloang kapa che) ha u lahlela `&mut T`, 'me u netefatse hore ha ho na liphetoho kapa liphapang tse ka feto-fetohang ha u ntse u lahlela `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Ho qala `UnsafeCell` butle-butle ho hloka `raw_get`, joalo ka ha ho letsetsa `get` ho ka hloka hore ho etsoe tšupiso ea data e sa qalisoang:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Re ka lahla sesupa feela ho tloha `UnsafeCell<T>` ho ea ho `T` ka lebaka la #[repr(transparent)].
        // Sena se sebelisa boemo bo ikhethileng ba libstd, ha ho na tiiso bakeng sa khoutu ea mosebelisi ea hore sena se tla sebetsa liphetolelong tsa moqapi oa future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// E etsa `UnsafeCell`, e nang le boleng ba `Default` bakeng sa T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}