//! # Laeborari ea mantlha ea Rust
//!
//! Laeborari ea mantlha ea Rust ke motheo o sa itšetlehang ka batho ba itšetlehileng ka [^ mahala] oa [The Rust Standard Library](../std/index.html).
//! Ke sekhomaretsi se nkehang habobebe lipakeng tsa puo le lilaebrari tsa eona, se hlalosang likarolo tsa kahare le tsa khale tsa khoutu eohle ea Rust.
//!
//! Ha e hokahane le lilaebrari tse holimo, ha ho na lilaebrari tsa sistimi ebile ha ho na libc.
//!
//! [^free]: Strictly ho bua, ho na le matšoao a mang a hlokahalang empa
//!          ha se kamehla li hlokahalang.
//!
//! Laeborari ea mantlha e na le *bonyane*: ha e tsebe le kabelo ea qubu, ebile ha e fane ka concurrency kapa I/O.
//! Lintho tsena li hloka ho hokahanngoa ha sethala, 'me laeborari ena ke platform-agnostic.
//!
//! # Mokhoa oa ho sebelisa laebrari ea mantlha
//!
//! Ka kopo hlokomela hore lintlha tsena kaofela ha li nkuoe li tsitsitse hajoale.
//!
//!
//!
// FIXME: Tlatsa ka lintlha tse qaqileng ha sebopeho se rarolla
//! Laeborari ena e hahiloe ka mohopolo oa matšoao a seng makae a teng:
//!
//! * `memcpy`, `memcmp`, `memset`, Tsena ke mekhoa ea mantlha ea ho hopola eo hangata e hlahisoang ke LLVM.
//! Ntle le moo, laeborari ena e ka letsetsa mesebetsi ena ka mokhoa o hlakileng.
//! Ho saena ha bona ho tšoana le ho C.
//!   Mesebetsi ena hangata e fanoa ke sistimi ea libc, empa e ka fanoa hape ke [compiler-builtins crate](https://crates.io/crates/compiler_builtins).
//!
//!
//! * `rust_begin_panic` - Mosebetsi ona o nka mabaka a mane, `fmt::Arguments`, `&'static str`, le `u32 'tse peli.
//! Mabaka ana a mane a laela molaetsa oa panic, faele eo panic e neng e sebelisoa ho eona, le mola le kholomo kahare ho faele.
//! Ho ho bareki ba laeborari ena ea mantlha ho hlalosa ts'ebetso ena ea panic;ho hlokahala feela hore o seke oa hlola o khutla.
//! Sena se hloka semelo sa `lang` se bitsoang `panic_impl`.
//!
//! * `rust_eh_personality` - e sebelisoa ke mekhoa ea ho hloleha ha moqapi.
//! Hangata sena se etsoa 'meleng oa tšebetso ea botho ba GCC, empa crates e sa qholotseng panic e ka tiisetsoa hore ts'ebetso ena ha e bitsoe.
//! Tšobotsi ea `lang` e bitsoa `eh_personality`.
//!
//!
//!

// Kaha libcore e hlalosa lintho tse ngata tsa mantlha tsa lang, liteko tsohle li lula crate, libcoretest, ho qoba litaba tse makatsang.
//
// Mona re hlakile#[cfg]-ka sena kaofela crate ha re etsa liteko.
// Haeba re sa etse sena, sesebelisoa sa liteko se hlahisitsoeng le bolokolohi bo hokahaneng (bo kenyelletsang ka mokhoa o fetelletseng ho kenyelletsa libcore) ka bobeli li tla hlalosa sehlopha se le seng sa li-lang, mme sena se tla baka phoso ea E0152 "found duplicate lang item".
//
// Bona puisano ho #50466 bakeng sa lintlha.
//
// Cfg ena e ke ke ea ama liteko tsa doc.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // Bona #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: ha e hloke ho ba setjhaba
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// Hula ho `core_arch` crate ka kotloloho ho libcore.Likateng tsa `core_arch` li polokelong e fapaneng: rust-lang/stdarch.
//
// `core_arch` ho latela libcore, empa likahare tsa module ena li hlophisitsoe ka tsela eo ka eona e e hulang ka kotloloho mona e sebetsang joalo ka ha crate e sebelisa crate ena e le libcore ea eona.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Tlhaloso ena e lokela ho fallisetsoa ho rust-lang/stdarch kamora hore clashing_extern_declarations e
// kopantsoe.Hajoale ha e khone hobane bootstrap e hloleha kaha lint ha e so hlalosoe.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;