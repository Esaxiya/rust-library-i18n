//! Li-macros tse sebelisoang ke li-iterator tsa selae.

// Inlining is_empty mme len e etsa phapang e kholo ea ts'ebetso
macro_rules! is_empty {
    // Tsela eo re kenyang bolelele ba sehlahlobi sa ZST, e sebetsa bakeng sa ZST le eo e seng ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ho tlosa licheke tse ling tsa meeli (bona `position`), re bala bolelele ka tsela e sa lebelloang.
// (E lekoa ke `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ka linako tse ling re sebelisoa kahare ho sebaka se sa bolokehang

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ ena e sebelisa `unchecked_sub` hobane re its'etleha ka ho phuthela ho emela bolelele ba li-iterator tsa ZST tse telele.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Rea tseba hore `start <= end`, ka hona e ka sebetsa hantle ho feta `offset_from`, e hlokang ho sebetsana le e saennweng.
            // Ka ho beha lifolakha tse loketseng mona re ka bolella LLVM sena, se e thusang ho tlosa licheke tsa meeli.
            // TSHIRELETSO: Ka mofuta o sa fetoheng, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ka ho bolella LLVM hape hore litlhahiso li arohane ka boholo ba mofuta oa mofuta, li ka ntlafatsa `len() == 0` ho fihlela `start == end` sebakeng sa `(end - start) < size`.
            //
            // TSHIRELETSO: Ka mofuta o sa fetoheng, litsupa li hokahantsoe kahoo
            //         Sebaka se pakeng tsa bona e tlameha ho ba boholo ba boholo ba li-pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Tlhaloso e arolelanoeng ea li-iterator tsa `Iter` le `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // E khutlisa ntho ea pele ebe e tsamaisa qalo ea eona ho ea pele ka 1.
        // E ntlafatsa ts'ebetso haholo ha e bapisoa le ts'ebetso e manehiloeng.
        // Iterator ha ea lokela ho ba e se nang letho.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // E khutlisa karolo ea hoqetela ebe e suthisetsa pheletso ea eona morao ka 1.
        // E ntlafatsa ts'ebetso haholo ha e bapisoa le ts'ebetso e manehiloeng.
        // Iterator ha ea lokela ho ba e se nang letho.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Fokotsa iterator ha T e le ZST, ka ho suthisa pheletso ea iterator morao ka `n`.
        // `n` ha ea lokela ho feta `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Ts'ebetso ea mothusi bakeng sa ho theha selae ho tsoa ho iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // TŠIRELETSO: iterator e entsoe ka selae se nang le sesupi
                // `self.ptr` le bolelele `len!(self)`.
                // Sena se tiisa hore lintho tsohle tse hlokahalang bakeng sa `from_raw_parts` lia phethahala.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Ts'ebetso ea mothusi ea ho tsamaisa qalo ea iterator pele ka likarolo tsa `offset`, ho khutlisa qalo ea khale.
            //
            // Ha e sa bolokeha hobane chelete e koaloang ha ea lokela ho feta `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // TSHIRELETSO: moletsi o tiisa hore `offset` ha e fete `self.len()`,
                    // ka hona sesupi sena se secha se ka hare ho `self` mme ka hona se netefalitsoe hore ha se na thuso.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Ts'ebetso ea mothusi bakeng sa ho suthisetsa pheletso ea iterator morao ka likarolo tsa `offset`, ho khutlisa pheletso e ncha.
            //
            // Ha e sa bolokeha hobane chelete e koaloang ha ea lokela ho feta `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // TSHIRELETSO: moletsi o tiisa hore `offset` ha e fete `self.len()`,
                    // e netefalitsoeng hore e ke ke ea phalla `isize`.
                    // Hape, pointer e hlahisoang e meeling ea `slice`, e phethahatsang litlhoko tse ling tsa `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // e ka kengoa ts'ebetsong ka likhae, empa sena se qoba ho lekoa meeli

                // TSHIRELETSO: Mehala ea `assume` e bolokehile ho tloha ha sesupa-tsela se qala
                // ha ea lokela ho ba null, 'me lilae tse fetang li-ZSTs le tsona li tlameha ho ba le sesupa-pono se sa sebetseng.
                // Mohala oa `next_unchecked!` o bolokehile kaha re sheba hore na iterator ha e na letho pele.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Sesebelisoa sena ha se na letho.
                    if mem::size_of::<T>() == 0 {
                        // Re tlameha ho e etsa ka tsela ena kaha `ptr` e kanna ea se be 0, empa `end` e kanna ea ba (ka lebaka la ho phuthela).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // TŠIRELETSO: qetello e ka se be 0 haeba T e se ZST hobane ptr ha e 0 le end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // TSHIRELETSO: Re mo molelwaneng.`post_inc_start` e etsa ntho e nepahetseng le bakeng sa li-ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            // Hape, `assume` e qoba ho hlahloba meeli.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // TSHIRELETSO: Re netefaditswe hore re tla ba meeding ke sehlophisi se kenang:
                        // ha `i >= n`, `self.next()` e khutlisa `None` 'me sekheo se robeha.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Re fetela ts'ebetsong ea kamehla, e sebelisang `try_fold`, hobane ts'ebetsong ena e bonolo e hlahisa LLVM IR e nyane mme e potlakile ho hlophisoa.
            // Hape, `assume` e qoba ho hlahloba meeli.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // TSHIRELETSO: `i` e tlameha ho ba tlase ho `n` ho tloha ha e qala ka `n`
                        // mme e ea fokotseha feela.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `i` e meeling ea
                // selae sa mantlha, ka hona `i` e ke ke ea khaphatseha `isize`, 'me litšupiso tse khutlisitsoeng li netefalitsoe hore li bua ka karolo ea selae mme ka hona li netefalitsoe hore li nepahetse.
                //
                // Hape hlokomela hore moletsi o boetse o tiisa hore ha ho mohla re tla bitsoa ka index e tšoanang hape, le hore ha ho mekhoa e meng e tla fihlella subslice ena e bitsoang, ka hona e nepahetse bakeng sa ts'upiso e khutlisitsoeng hore e ka fetoha maemong a
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // e ka kengoa ts'ebetsong ka likhae, empa sena se qoba ho lekoa meeli

                // TSHIRELETSO: Mehala ya `assume` e bolokehile ho tloha ha sesupa-tsela sa qalo se tlameha ho ba se sa sebetseng,
                // 'Me lilae tse fetang li-ZSTs le tsona li tlameha ho ba le sesupa-pono se sa sebetseng.
                // Mohala oa `next_back_unchecked!` o bolokehile kaha re sheba hore na iterator ha e na letho pele.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Sesebelisoa sena ha se na letho.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // TSHIRELETSO: Re mo molelwaneng.`pre_dec_end` e etsa ntho e nepahetseng le bakeng sa li-ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}