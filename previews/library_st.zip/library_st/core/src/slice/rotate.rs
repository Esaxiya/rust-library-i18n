// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// E fetola molumo `[mid-left, mid+right)` hoo ntho ea `mid` e bang ntho ea pele.Ka mokhoa o ts'oanang, e potoloha likarolo tsa `left` ka ho le letšehali kapa likarolo tsa `right` ka ho le letona.
///
/// # Safety
///
/// Mefuta e boletsoeng e tlameha ho ba e nepahetseng bakeng sa ho bala le ho ngola.
///
/// # Algorithm
///
/// Algorithm 1 e sebelisetsoa litekanyetso tse nyane tsa `left + right` kapa `T` e kholo.
/// Lintlha li fallisetsoa maemong a tsona a ho qetela ka nako e le 'ngoe ho qala ka `mid - left` le ho hatela pele ka `right` mehato ea modulo `left + right`, joalo ka hore ho hlokahala nakoana e le' ngoe feela.
/// Qetellong, re fihla `mid - left`.
/// Leha ho le joalo, haeba `gcd(left + right, right)` e se 1, mehato e kaholimo e tloletse likarolo.
/// Ka mohlala:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ka lehlohonolo, palo ea likarolo tse tlolotsoeng lipakeng tsa likarolo tse phethetsoeng e lula e lekana, ka hona re ka emisa boemo ba rona ba ho qala ebe re etsa mekhahlelo e meng (palo ea lipota ke `gcd(left + right, right)` value).
///
/// Sephetho ke hore likarolo tsohle li phetheloa hang le hanngoe feela.
///
/// Algorithm 2 e sebelisoa haeba `left + right` e le kholo empa `min(left, right)` e nyane ka ho lekana hore e lekane holim'a sephutheloana sa stack.
/// Lintho tsa `min(left, right)` li kopitsoa holim'a buffer, `memmove` e sebelisoa ho tse ling, 'me tse ho buffer li khutlisetsoa ka sekoting ka lehlakoreng le leng la moo li simolohileng teng.
///
/// Li-algorithms tse ka ntlafatsoang li feta tse boletsoeng ka holimo hang ha `left + right` e ba kholo ka ho lekana.
/// Algorithm 1 e ka etsoa vectorized ka ho qhekella le ho etsa mekoloko e mengata ka nako e le ngoe, empa ho na le mekhahlelo e fokolang haholo ka karolelano ho fihlela `left + right` e le kholo haholo, 'me boemo bo bobe ka ho fetesisa ba kamehla bo lula bo le teng.
/// Sebakeng seo, algorithm 3 e sebelisa ho chencha khafetsa ha lintho tsa `min(left, right)` ho fihlela bothata bo bonyenyane ba potoloho bo setse.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ha `left < right` swapping e etsahala ho tloha ka letsohong le letšehali ho fapana.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. lits'ebetso tse ka tlase li ka hloleha haeba linyeoe tsena li sa hlahlojoe
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks e bonts'a hore ts'ebetso e tloaelehileng ea liphetoho tse sa reroang e betere ho fihlela hoo e ka bang `left + right == 32`, empa ts'ebetso e mpe ka ho fetesisa e robeha le ho pota 16.
            // 24 e khethiloe e le sebaka se bohareng.
            // Haeba boholo ba `T` bo boholo ho feta `usize`s tse 4, algorithm ena e boetse e feta lits'ebetso tse ling.
            //
            //
            let x = unsafe { mid.sub(left) };
            // qalo ea potoloho ea pele
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` e ka fumanoa pele ho letsoho ka ho bala `gcd(left + right, right)`, empa e potlakile ho etsa sekonopo se le seng se lekanyang gcd e le litlamorao, ebe o etsa karolo e setseng ea chunk
            //
            //
            let mut gcd = right;
            // lipontšo li senola hore ho potlakile ho chencha litempele ho ea pele ho e-na le ho bala nakoana ha 'ngoe, ho kopitsa morao, ebe o ngola nakoana nakoana qetellong.
            // Sena se ka etsahala ka lebaka la hore ho fapanyetsana kapa ho nkela litempele sebaka ho sebelisa aterese e le 'ngoe feela ea mohopolo sebakeng sa ho hloka ho laola tse peli.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // sebakeng sa ho eketsa `i` ebe re sheba hore na e kantle ho meeli, re sheba hore na `i` e tla tsoa kantle ho meeli keketsehong e latelang.
                // Sena se thibela ho phuthetsoa hoa litsupa kapa `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // pheletso ea potoloho ea pele
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // maemo ana a tlameha ho ba mona haeba `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // qeta chunk ka mekoloko e mengata
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ha se mofuta oa zero, kahoo ho lokile ho arola ka boholo ba eona.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 `[T; 0]` mona ke ho netefatsa hore sena se hokahane hantle bakeng sa T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Ho na le mokhoa o mong oa ho fapanyetsana o kenyelletsang ho fumana moo phetoho ea ho qetela ea algorithm ena e ka bang teng, le ho fapanya o sebelisa sekotoana sa ho qetela ho fapana le ho fapanya likarolo tse haufi joalo ka algorithm ena, empa ka tsela ena e ntse e potlaka.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Tlhaloso ea 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}