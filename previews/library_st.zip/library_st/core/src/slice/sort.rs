//! Ho hlophisa selae
//!
//! Mojule ona o na le algorithm ea ho hlophisa e ipapisitse le mohlala oa Orson Peters o hlolang quicksort, o phatlalalitsoeng ho: <https://github.com/orlp/pdqsort>
//!
//!
//! Ho hlophisa ho sa tsitsang ho tsamaisana le libcore hobane ha e fane ka mohopolo, ho fapana le ts'ebetso ea rona ea ho hlophisa e tsitsitseng.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ha e liheloa, likopi ho tloha `src` ho ea ho `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // TŠIRELETSO: Sena ke sehlopha sa bathusi.
        //          Ka kopo sheba ts'ebeliso ea eona bakeng sa ho nepahala.
        //          Ka mokhoa o ts'oanang, motho o tlameha ho netefatsa hore `src` le `dst` ha li kopane joalo ka ha ho hlokoa ke `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// E fetisetsa ntlha ea pele ka ho le letona ho fihlela e kopana le ntho e kholo kapa e lekanang.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TSHIRELETSO: Tshebetso e sa bolokehang ka tlase e kenyelletsa ho etsa li-index ntle le cheke e tlamang (`get_unchecked` le `get_unchecked_mut`)
    // le ho kopitsa memori (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Re lekotse boholo ba sehlopha ho>=2.
    //  2. Lintlha tsohle tseo re tla li etsa li lula lipakeng tsa {0 <= index < len} haholo.
    //
    // b.Ho kopitsa memori
    //  1. Re fumana lits'oants'o tsa litšupiso tse netefalitsoeng hore li nepahetse.
    //  2. Li ke ke tsa kopana hobane re fumana litsupa tsa likarolo tse fapaneng tsa selae.
    //     E leng, `i` le `i-1`.
    //  3. Haeba selae se hokahane hantle, likarolo li hokahane hantle.
    //     Ke boikarabello ba motho ea letsitseng ho etsa bonnete ba hore selae se hokahane hantle.
    //
    // Bona litlhaloso tse ka tlase bakeng sa lintlha tse ling.
    unsafe {
        // Haeba likarolo tse peli tsa pele li felile-ntle ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Bala ntlha ea pele ka phapano e abuoeng ka stack.
            // Haeba ts'ebetso e latelang ea papiso panics, `hole` e tla theoha ebe e ngola karolo eo ka bo eona serekeng.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Tsamaea `i`-th ntho e le 'ngoe ka ho le letšehali, ka hona o sutumetsa lesoba ka ho le letona.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` oa theoha 'me kahoo o kopitsa `tmp` ka mokoting o setseng oa `v`.
        }
    }
}

/// E fetisetsa karolo ea ho qetela ka letsohong le letšehali ho fihlela e kopana le ntho e nyane kapa e lekanang.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TSHIRELETSO: Tshebetso e sa bolokehang ka tlase e kenyelletsa ho etsa li-index ntle le cheke e tlamang (`get_unchecked` le `get_unchecked_mut`)
    // le ho kopitsa memori (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Re lekotse boholo ba sehlopha ho>=2.
    //  2. Lintlha tsohle tseo re tla li etsa li lula lipakeng tsa `0 <= index < len-1` haholo.
    //
    // b.Ho kopitsa memori
    //  1. Re fumana lits'oants'o tsa litšupiso tse netefalitsoeng hore li nepahetse.
    //  2. Li ke ke tsa kopana hobane re fumana litsupa tsa likarolo tse fapaneng tsa selae.
    //     E leng, `i` le `i+1`.
    //  3. Haeba selae se hokahane hantle, likarolo li hokahane hantle.
    //     Ke boikarabello ba motho ea letsitseng ho etsa bonnete ba hore selae se hokahane hantle.
    //
    // Bona litlhaloso tse ka tlase bakeng sa lintlha tse ling.
    unsafe {
        // Haeba likarolo tse peli tsa ho qetela li feletsoe ke nako ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Bala ntlha ea hoqetela ka phapano e abuoeng ka stack.
            // Haeba ts'ebetso e latelang ea papiso panics, `hole` e tla theoha ebe e ngola karolo eo ka bo eona serekeng.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Tsamaea `i`-th sebaka se le seng ka ho le letona, ka hona o sutumetsa lesoba ka ho le letšehali.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` oa theoha 'me kahoo o kopitsa `tmp` ka mokoting o setseng oa `v`.
        }
    }
}

/// Hlahloba selae ka mokhoa o itseng ka ho suthisa likarolo tse 'maloa tse tsoileng taolong ho potoloha.
///
/// E khutlisa `true` haeba selae se hlophisitsoe qetellong.Mosebetsi ona ke ona o mpe ka ho fetesisa *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Palo e kahodimodimo ea lipara tse seng li hlophisehile tse tlang ho fetoloa.
    const MAX_STEPS: usize = 5;
    // Haeba selae se le khutsuanyane ho feta sena, u se ke ua suthisa lintho.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // TSHIRELETSO: Re se ntse re hlakisitse tlamo ka ho hlaka le `i < len`.
        // Likarolo tsohle tsa rona tse latelang li fumaneha feela ho `0 <= index < len`
        unsafe {
            // Fumana lipara tse latelang tse haufi le tsa kantle ho nako.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Na re qetile?
        if i == len {
            return true;
        }

        // Se ke oa chencha lintho ka tatellano e khutšoane, e nang le litšenyehelo tsa ts'ebetso.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Fetola lintho tse fumanehang.Sena se li beha ka tatellano e nepahetseng.
        v.swap(i - 1, i);

        // Tlosa karolo e nyane ka ho le letšehali.
        shift_tail(&mut v[..i], is_less);
        // Tlosa karolo e kholo ho ea ka ho le letona.
        shift_head(&mut v[i..], is_less);
    }

    // Ha ea atleha ho hlophisa selae ka mehato e fokolang.
    false
}

/// E hlophisa selae o sebelisa mofuta oa kenyelletso, e leng boemo ba "O *(* n * ^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// E khetha `v` e sebelisa heapsort, e netefatsang boemo ba O *(* n *\* log(*n*)).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Qubu ena ea binary e hlompha `parent >= child` e sa fetoheng.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Bana ba `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Khetha ngoana e moholo.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Emisa haeba ea sa fetoheng a ts'oara `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Fapanya `node` le ngoana e moholo, suthela mohato o le mong ebe u tsoela pele ho sefa.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Haha qubu ka nako e lekanang.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Lintho tse kholo tsa Pop tse tsoang qubung.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Likarolo `v` ho likarolo tse nyane ho `pivot`, li lateloa ke likarolo tse kholo ho feta kapa tse lekanang le `pivot`.
///
///
/// E khutlisa palo ea likaroloana tse nyane ho `pivot`.
///
/// Karohano e etsoa block-by-block molemong oa ho fokotsa litšenyehelo tsa ts'ebetso ea makala.
/// Mohopolo ona o hlahisoa pampiring ea [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Palo ea likarolo tsa "block" e tloaelehileng.
    const BLOCK: usize = 128;

    // Algorithm ea ho arola e pheta mehato e latelang ho fihlela e phetheloa:
    //
    // 1. Hlahloba boloko ho tloha lehlakoreng le letšehali ho khetholla likarolo tse kholo ho feta kapa tse lekanang le pivot.
    // 2. Hlahloba boloko ho tloha lehlakoreng le letona ho khetholla likarolo tse nyane ho feta pivot.
    // 3. Fapanyetsana likarolo tse khethiloeng lipakeng tsa lehlakore le letšehali le le letona.
    //
    // Re boloka mefuta e latelang bakeng sa likarolo tsa likarolo:
    //
    // 1. `block` - Palo ea likarolo tsa boloko.
    // 2. `start` - Qala sesupisi ka har'a sehlopha sa `offsets`.
    // 3. `end` - End pointer ho sehlopha sa `offsets`.
    // 4. `liphoso, li-indices tsa lintho tse tsoileng molaong ka har'a block.

    // Sebaka sa hajoale ka lehlakoreng le letšehali (ho tloha `l` ho isa ho `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Sebaka sa hajoale se ka lehlakoreng le letona (ho tloha `r.sub(block_r)` to `r`).
    // TSHIRELETSO: Tokomane ya .add() e bolela ka ho otloloha hore `vec.as_ptr().add(vec.len())` e bolokehile kamehla
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ha re fumana li-VLA, leka ho theha bolelele bo le bong `min(v.len(), 2 * BLOCK) `ho fapana
    // ho feta bolelele bo boholo ba bolelele ba `BLOCK`.Li-VLA li kanna tsa sebetsa hantle ho feta cache.

    // E khutlisa palo ea likarolo lipakeng tsa litsupa `l` (inclusive) le `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Re qetile ka ho arola block-by-block ha `l` le `r` ba atamela haholo.
        // Ebe re etsa mosebetsi oa ho kopanya likarolo tse setseng lipakeng.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Palo ea likarolo tse setseng (e ntse e sa bapisoe le pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Fetola boholo ba litene e le hore le literata tse ka letsohong le letšehali le le letona li se ke tsa kopana, empa li hokahane hantle ho koahela lekhalo le setseng.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Batla likarolo tsa `block_l` ho tloha ka lehlakoreng le letšehali.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // TSHIRELETSO: Tshebetso e sa sireletsehang ka tlase e kenyelletsa ts'ebeliso ea `offset`.
                //         Ho latela maemo a hlokoang ke ts'ebetso, rea a khotsofatsa hobane:
                //         1. `offsets_l` e abiloe ka bongata, ka hona e nkuoa e le ntho e arotsoeng ka thoko.
                //         2. Mosebetsi `is_less` o khutlisa `bool`.
                //            Ho lahla `bool` ho ke ke ha hlola ho tlala `isize`.
                //         3. Re netefalitse hore `block_l` e tla ba `<= BLOCK`.
                //            Hape, `end_l` e ne e hlophiselitsoe qalong ea pointer ea `offsets_` e ileng ea phatlalatsoa ka mokotleng.
                //            Kahoo, rea tseba hore le maemong a mabe ka ho fetesisa (likopo tsohle tsa `is_less` li khutla li fosahetse) re tla be re le 1 byte feela re fetisa pheletso.
                //        Ts'ebetso e 'ngoe e sa sireletsehang mona ke ho se hlophise `elem`.
                //        Leha ho le joalo, `elem` qalong e ne e le sesupa-tsela sa selae se lulang se sebetsa kamehla.
                unsafe {
                    // Papiso e se nang lekala.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Batla likarolo tsa `block_r` ho tloha lehlakoreng le letona.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // TSHIRELETSO: Tshebetso e sa sireletsehang ka tlase e kenyelletsa ts'ebeliso ea `offset`.
                //         Ho latela maemo a hlokoang ke ts'ebetso, rea a khotsofatsa hobane:
                //         1. `offsets_r` e abiloe ka bongata, ka hona e nkuoa e le ntho e arotsoeng ka thoko.
                //         2. Mosebetsi `is_less` o khutlisa `bool`.
                //            Ho lahla `bool` ho ke ke ha hlola ho tlala `isize`.
                //         3. Re netefalitse hore `block_r` e tla ba `<= BLOCK`.
                //            Hape, `end_r` e ne e hlophiselitsoe qalong ea pointer ea `offsets_` e ileng ea phatlalatsoa ka mokotleng.
                //            Kahoo, rea tseba hore le maemong a mabe ka ho fetesisa (likopo tsohle tsa `is_less` li khutla e le 'nete) re tla be re le bonyane hanyane ka hora ho feta qetellong.
                //        Ts'ebetso e 'ngoe e sa sireletsehang mona ke ho se hlophise `elem`.
                //        Leha ho le joalo, `elem` qalong e ne e le `1 *sizeof(T)` ho feta qetellong mme re e fokotsa ka `1* sizeof(T)` pele re e fumana.
                //        Hape, `block_r` e ile ea tiisoa hore e ka tlase ho `BLOCK` mme `elem` ka hona e tla be e supa qalo ea selae.
                unsafe {
                    // Papiso e se nang lekala.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Palo ea likarolo tse tsoileng tseleng tsa ho fapanyetsana pakeng tsa lehlakore le letšehali le le letona.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Sebakeng sa ho chencha para e le 'ngoe ka nako eo, ho sebetsa hantle haholo ho etsa tumello ea cyclic.
            // Sena ha se tšoane hantle le ho fapanyetsana, empa se hlahisa sephetho se ts'oanang ho sebelisa ts'ebetso ea memori e fokolang.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Lintho tsohle tse tsoileng taolong ka lebokoseng le letšehali li ile tsa fallisoa.Fetela sebakeng se latelang.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Lintho tsohle tse tsoileng taolong ka lebokoseng le letona li ile tsa fallisoa.Eya sebakeng se fetileng.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Lintho tsohle tse setseng hajoale li na le block e le 'ngoe (ekaba ka ho le letšehali kapa ka ho le letona) e nang le likarolo tsa kantle ho tatellano tse hlokang ho tsamaisoa.
    // Lintho tse joalo tse setseng li ka fetisetsoa qetellong ho li-block tsa bona.
    //

    if start_l < end_l {
        // Karolo e ka letsohong le letšehali e sala.
        // Tsamaisa likarolo tsa eona tse setseng tsa odara ka letsohong le letona.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Sebaka se nepahetseng se sala.
        // Tsamaisa likarolo tsa eona tse setseng tsa odara ka letsohong le letšehali.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ha ho na letho le leng leo re lokelang ho le etsa, re qetile.
        width(v.as_mut_ptr(), l)
    }
}

/// Likarolo `v` ho likarolo tse nyane ho `v[pivot]`, li lateloa ke likarolo tse kholo ho feta kapa tse lekanang le `v[pivot]`.
///
///
/// E khutlisa palo ea:
///
/// 1. Palo ea likaroloana tse nyane ho `v[pivot]`.
/// 2. Ke 'nete haeba `v` e ne e se e arotsoe.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Beha pivot qalong ea selae.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Bala pivot hore e be phapano e fanoeng ka moroalo bakeng sa ts'ebetso.
        // Haeba ts'ebetso e latelang ea papiso panics, pivot e tla ngoloa ka boeona hape selae.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Fumana lintlha tse peli tsa pele tse sa tsoaneng.
        let mut l = 0;
        let mut r = v.len();

        // TSHIRELETSO: Ho hloka polokeho ka tlase ho kenyelletsa ho etsa index ea lethathamo.
        // Ea pele: Re se re ntse re etsa meeli e shebang mona le `l < r`.
        // Bakeng sa ea bobeli: Qalong re ne re na le `l == 0` le `r == v.len()` mme re ile ra sheba `l < r` eo ts'ebetsong e ngoe le e ngoe ea indexing.
        //                     Ho tloha mona rea tseba hore `r` e tlameha ho ba bonyane `r == l` e bonts'itsoeng hore e nepahetse ho tloha ho ea pele.
        unsafe {
            // Fumana ntho ea pele e kholo ho feta kapa e lekana le pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Fumana karolo ea ho qetela e nyane ho feta eo pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` o tsoa maemong mme o ngola pivot (e leng phapano e abuoeng ka stack) ho khutlela selaeteng moo e neng e le teng qalong.
        // Mohato ona o bohlokoa ho netefatsa polokeho!
        //
    };

    // Beha sekhahla pakeng tsa likarolo tse peli.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Likarolo `v` ho likarolo tse lekanang le `v[pivot]` li lateloa ke likarolo tse kholo ho feta `v[pivot]`.
///
/// E khutlisa palo ea likarolo tse lekanang le pivot.
/// Ho nahanoa hore `v` ha e na likarolo tse nyane ho feta pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Beha pivot qalong ea selae.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Bala pivot hore e be phapano e fanoeng ka moroalo bakeng sa ts'ebetso.
    // Haeba ts'ebetso e latelang ea papiso panics, pivot e tla ngoloa ka boeona hape selae.
    // TSHIRELETSO: Sesupi mona sea sebetsa hobane se fumanoe ho buuoa ka selae.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Hona joale arola selae.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // TSHIRELETSO: Ho hloka polokeho ka tlase ho kenyelletsa ho etsa index ea lethathamo.
        // Ea pele: Re se re ntse re etsa meeli e shebang mona le `l < r`.
        // Bakeng sa ea bobeli: Qalong re ne re na le `l == 0` le `r == v.len()` mme re ile ra sheba `l < r` eo ts'ebetsong e ngoe le e ngoe ea indexing.
        //                     Ho tloha mona rea tseba hore `r` e tlameha ho ba bonyane `r == l` e bonts'itsoeng hore e nepahetse ho tloha ho ea pele.
        unsafe {
            // Fumana ntho ea pele ho feta pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Fumana karolo ea ho qetela e lekanang le pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Na re qetile?
            if l >= r {
                break;
            }

            // Fapanya lintho tse fumanoeng li sa hlophisehe.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Re fumane likarolo tsa `l` tse lekana le pivot.Kenya 1 ho ikarabella bakeng sa pivot ka boeona.
    l + 1

    // `_pivot_guard` o tsoa maemong mme o ngola pivot (e leng phapano e abuoeng ka stack) ho khutlela selaeteng moo e neng e le teng qalong.
    // Mohato ona o bohlokoa ho netefatsa polokeho!
}

/// E hasanya likarolo tse ling ho leka ho senya mekhoa e ka bakang likarolo tse sa leka-lekanang ho quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nomoro ea jenereithara e tsoang pampiring ea "Xorshift RNGs" ea George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Nka linomoro tse sa reroang tsa nomoro ena.
        // Nomoro e lekana le `usize` hobane `len` ha e kholo ho feta `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Bakhethoa ba bang ba pivot ba tla ba haufi le index ena.A re ke re li hlophise ka tsela e fapaneng.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Hlahisa nomoro ea modulo `len` e sa reroang.
            // Leha ho le joalo, molemong oa ho qoba ts'ebetso e turang re qala ka ho e nka modulo matla a mabeli, ebe re theoha ka `len` ho fihlela e lekana le `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ho netefalitsoe hore e tla ba tlase ho `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// E khetha pivot ho `v` ebe e khutlisa index le `true` haeba selae se kanna sa hlophisoa.
///
/// Lintho tsa `v` li ka hlophisoa bocha ha li ntse li tsoela pele.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bonyane ba bolelele ba ho khetha mokhoa oa batho ba mahareng.
    // Lilae tse khuts'oane li sebelisa mokhoa o bonolo o bohareng ba boraro.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Palo e kaholimo ea li-swaps tse ka etsoang mosebetsing ona.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Li-indices tse tharo haufi le moo re tla khetha pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // E bala palo ea li-swaps tseo re leng haufi le ho li etsa ha re ntse re hlophisa li-indices.
    let mut swaps = 0;

    if len >= 8 {
        // Ho chencha li-indices e le hore `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ho chencha li-indices e le hore `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // O fumana bohareng ba `v[a - 1], v[a], v[a + 1]` mme o boloka index ho `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Fumana bo-ramatsete libakeng tse haufi tsa `a`, `b`, le `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Fumana bohareng ba `a`, `b`, le `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Palo e phahameng ea li-swaps e ile ea etsoa.
        // Menyetla ke hore selae se a theoha kapa boholo ba sona sea theoha, ka hona ho fetoha se ka thusa ho se hlopha kapele.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Mofuta oa `v` o pheta-pheta.
///
/// Haeba selae se ne se na le selelekela ka tatellano ea pele, se hlalosoa e le `pred`.
///
/// `limit` ke palo ea likarolo tse sa lekanyetsoang tse lumelloang pele o fetela ho `heapsort`.
/// Haeba e le zero, mosebetsi ona o tla fetohela ho heapsort hanghang.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Likarolo tsa bolelele bona li a hlophisoa ho sebelisoa mofuta oa kenyelletso.
    const MAX_INSERTION: usize = 20;

    // Ke 'nete haeba karohano ea hoqetela e ne e leka-lekane ka nepo.
    let mut was_balanced = true;
    // Ke 'nete haeba karohano ea hoqetela e sa ts'oane le likarolo (selae se ne se se se arotsoe).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Lilae tse khutšoane haholo lia hlophisoa ho sebelisoa mofuta oa kenyelletso.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Haeba ho entsoe likhetho tse ngata tse mpe, o mpe o khutlele ho heapsort molemong oa ho netefatsa `O(n * log(n))` nyeoe e mpe ka ho fetesisa.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Haeba karohano ea hoqetela e ne e sa leka-lekana, leka ho roba mekhahlelo selae ka ho sotha likarolo tse ling ho e potoloha.
        // Rea ts'epa hore re tla khetha pivot e betere lekhetlong lena.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Khetha sekhahla 'me u leke ho hakanya hore na selae se se se hlophiloe.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Haeba karohano ea hoqetela e ne e leka-lekane hantle 'me e sa fapanya likarolo,' me haeba khetho ea pivot e bolela esale pele hore selae se kanna sa hlophisoa ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Leka ho khetholla likarolo tse 'maloa tse tsoileng tseleng le ho li sutumelletsa maemong a nepahetseng.
            // Haeba selae se qetella se hlophisitsoe ka botlalo, re qetile.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Haeba pivot e khethiloeng e lekana le ea pele ho eona, ke ntho e nyane ka ho fetisisa selae.
        // Arola selae ka likarolo tse lekanang le likarolo tse kholo ho feta pivot.
        // Nyeoe ena hangata e otloa ha selae se na le likarolo tse ngata tse kopilitsoeng.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Tsoela pele ho hlophisa likarolo tse kholo ho feta sekhahla.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Arola selae.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Arola selae ho `left`, `pivot`, le `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Khutlela ka lehlakoreng le lekhuts'oane feela molemong oa ho fokotsa palo e felletseng ea mehala e iphetang le ho sebelisa sebaka se fokolang haholo.
        // Ebe u tsoelapele ka lehlakore le lelelele (hona ho tšoana le ho pheta-pheta mohatla).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// E hlophisa `v` e sebelisa mofuta o potlakileng o hlolang mohlala, e leng *O*(*n*\*log(* n*))-case e mpe ka ho fetisisa.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ho hlopha ha ho na boits'oaro bo nang le moelelo ho mefuta ea boholo ba zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Fokotsa palo ea likarolo tse sa lekanang ho `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Bakeng sa likhae tse fihlang bolelele bona mohlomong ho potlaka ho li hlophisa.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Khetha pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Haeba pivot e khethiloeng e lekana le ea pele ho eona, ke ntho e nyane ka ho fetisisa selae.
        // Arola selae ka likarolo tse lekanang le likarolo tse kholo ho feta pivot.
        // Nyeoe ena hangata e otloa ha selae se na le likarolo tse ngata tse kopilitsoeng.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Haeba re fetisitse lenane la rona, re hantle.
                if mid > index {
                    return;
                }

                // Ho seng joalo, tsoelapele ho hlophisa likarolo tse kholo ho feta sekoti.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Arola selae ho `left`, `pivot`, le `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Haeba mid==index, re tla be re qetile, kaha partition() e netefalitse hore likarolo tsohle kamora bohareng li kholo ho feta kapa li lekana le bohareng.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ho hlopha ha ho na boits'oaro bo nang le moelelo ho mefuta ea boholo ba zero.Se ke oa etsa letho.
    } else if index == v.len() - 1 {
        // Fumana lintlha tse ngata 'me u li behe maemong a hoqetela.
        // Re lokolohile ho sebelisa `unwrap()` mona hobane rea tseba hore v ha ea lokela ho ba e se nang letho.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Fumana 'min element' 'me u e behe boemong ba pele ba tatellano.
        // Re lokolohile ho sebelisa `unwrap()` mona hobane rea tseba hore v ha ea lokela ho ba e se nang letho.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}