//! Mesebetsi ea mahala ho theha `&[T]` le `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// E etsa selae ho tloha sesupa-nako le bolelele.
///
/// Khang ea `len` ke palo ea **lintho**, eseng palo ea li-byte.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `data` e tlameha ho ba [valid] bakeng sa ho baloa bakeng sa `len * mem::size_of::<T>()` li-byte tse ngata, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
///
///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.Bona [below](#incorrect-usage) bakeng sa mohlala ka phoso u sa nahane ka sena.
///     * `data` ha ea lokela ho ba null mme e hokahane le bakeng sa likotoana tsa bolelele ba zero.
///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
///
/// * `data` E tlameha ho supa `len` ka ho latellana litekanyetso tse qalileng hantle tsa mofuta `T`.
///
/// * Memori e boletsoeng ke selae se khutlisitsoeng ha ea lokela ho fetoha nako eohle ea bophelo ba `'a`, ntle le kahare ho `UnsafeCell`.
///
/// * Boholo ba `len * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
///   Bona litokomane tsa polokeho ea [`pointer::offset`].
///
/// # Caveat
///
/// Nako ea bophelo ea selae se khutlisitsoeng e thehiloe ts'ebelisong ea eona.
/// Ho thibela tšebeliso e mpe ea ka phoso, ho khothalletsoa ho tlama bophelo bohle ho ea ka mohloli ofe kapa ofe oa bophelo o bolokehileng maemong, joalo ka ho fana ka ts'ebetso ea mothusi ho nka boleng ba moamoheli bakeng sa selae, kapa ka polelo e hlakileng.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bonahatsa selae bakeng sa ntho e le 'ngoe
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Tšebeliso e fosahetseng
///
/// Mosebetsi o latelang oa `join_slices` ke **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Polelo e kaholimo e netefatsa hore `fst` le `snd` lia hokahana, empa li kanna tsa ba li teng ka har'a _different allocated objects_, moo ho etsa selae sena e seng boitšoaro bo sa hlalosoang.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` mme `b` ke dintho tse fapaneng tse abetsweng ...
///     let a = 42;
///     let b = 27;
///     // ... eo leha ho le joalo e ka behoang ka mokhoa o ts'oanang mohopolong: |e |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// E etsa ts'ebetso e ts'oanang le [`from_raw_parts`], ntle le hore selae se ka fetohang sea khutlisoa.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `data` e tlameha ho ba [valid] bakeng sa babali ka bobeli ebile e ngolla `len * mem::size_of::<T>()` li-byte tse ngata, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
///
///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.
///     * `data` ha ea lokela ho ba null mme e hokahane le bakeng sa likotoana tsa bolelele ba zero.
///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
///
///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
///
/// * `data` E tlameha ho supa `len` ka ho latellana litekanyetso tse qalileng hantle tsa mofuta `T`.
///
/// * Khopotso e boletsoeng ke selae se khutlisitsoeng ha ea lokela ho fihlelleha ka sesupi se seng (se sa nkiloeng ho boleng ba ho khutlisa) nako eohle ea bophelo ba `'a`.
///   Bobeli ho bala le ho ngola ho fihlella ha hoa lumelloa.
///
/// * Boholo ba `len * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
///   Bona litokomane tsa polokeho ea [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// E fetolela ho T ho selae sa bolelele ba 1 (ntle le ho kopitsa).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// E fetolela ho T ho selae sa bolelele ba 1 (ntle le ho kopitsa).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}