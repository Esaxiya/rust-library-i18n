// ignore-tidy-filelength

//! Tsamaiso ea selae le ho qhekella.
//!
//! Bakeng sa lintlha tse ling bona [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ts'ebetso e hloekileng ea rust memchr, e nkiloeng ho rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Mosebetsi ona o fumaneha sechabeng feela hobane ha ho na mokhoa o mong oa heapsort ea teko ea yuniti.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// E khutlisa palo ea likarolo tsa selae.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // TSHIRELETSO: const modumo hobane re fetisa sebaka sa bolelele e le usize (e tlameha ho ba)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // TŠIRELETSO: sena se bolokehile hobane `&[T]` le `FatPtr<T>` li na le sebopeho se tšoanang.
            // Ke `std` feela e ka etsang tiiso ena.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Kenya sebaka ka `crate::ptr::metadata(self)` ha seo se tsitsitse.
            // Ha sena se ntse se ngoloa sena se baka phoso ea "Const-stable functions can only call other const-stable functions".
            //

            // TSHIRELETSO: Ho fihlella boleng ho mokgatlo wa `PtrRepr` ho bolokehile ho tloha ha * const T
            // le PtrComponents<T>na le mekhoa ea ho hopola e tšoanang.
            // Ke std feela e ka etsang tiiso ena.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// E khutlisa `true` haeba selae se na le bolelele ba 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// E khutlisa karolo ea pele ea selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// E khutlisetsa sesupi se ka fetohang nthong ea pele ea selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// E khutlisa likarolo tsa pele tsa selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// E khutlisa likarolo tsa pele tsa selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// E khutlisa likarolo tsa ho qetela tsa selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// E khutlisa likarolo tsa ho qetela tsa selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// E khutlisa karolo ea ho qetela ea selae, kapa `None` haeba e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// E khutlisetsa sesupisi se ka fetohang nthong ea ho qetela selae.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// E khutlisetsa litšupiso ho elemente kapa subslice ho latela mofuta oa index.
    ///
    /// - Haeba e fuoe boemo, e khutlisetsa tšupiso ho elemente e maemong ao kapa `None` haeba e le ka ntle ho meeli.
    ///
    /// - Haeba e fuoe mokoloko, e khutlisetsa subslice e tsamaellanang le mokoloko oo, kapa `None` haeba e le ka ntle ho meeli.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// E khutlisetsa ts'upiso e ka fetohang ho elemente kapa subslice ho latela mofuta oa index (bona [`get`]) kapa `None` haeba index e tsoa meeling.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// E khutlisetsa ts'upiso ho elemente kapa subslice, ntle le ho lekola meeli.
    ///
    /// Bakeng sa mokhoa o mong o bolokehileng bona [`get`].
    ///
    /// # Safety
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli ke *[boits'oaro bo sa hlalosoang]* leha ts'ebeliso e hlahang e sa sebelisoe.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // TSHIRELETSO: moletsi o tlameha ho boloka boholo ba litlhokahalo tsa polokeho bakeng sa `get_unchecked`;
        // selae ha se sa tlholeha hobane `self` ke ts'upiso e bolokehileng.
        // Pointer e khutlisitsoeng e bolokehile hobane lits'oants'o tsa `SliceIndex` li tlameha ho netefatsa hore e teng.
        unsafe { &*index.get_unchecked(self) }
    }

    /// E khutlisetsa ts'upiso e ka fetohang ho elemente kapa subslice, ntle le ho lekola meeli.
    ///
    /// Bakeng sa mokhoa o mong o bolokehileng bona [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli ke *[boits'oaro bo sa hlalosoang]* leha ts'ebeliso e hlahang e sa sebelisoe.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // TSHIRELETSO: moletsi o tlameha ho boloka litlhokahalo tsa polokeho bakeng sa `get_unchecked_mut`;
        // selae ha se sa tlholeha hobane `self` ke ts'upiso e bolokehileng.
        // Pointer e khutlisitsoeng e bolokehile hobane lits'oants'o tsa `SliceIndex` li tlameha ho netefatsa hore e teng.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// E khutlisetsa sesupisi se tala ho sesepa sa selae.
    ///
    /// Motho ea letsitseng o tlameha ho netefatsa hore selae se feta sephumane ts'ebetsong ena, kapa ho seng joalo se tla qetella se supa litšila.
    ///
    /// Motho ea letsitseng o boetse o tlameha ho netefatsa hore memori eo pointer a e supang (non-transitively) e ke ke ea ngoloa ho eona (ntle le ka hare ho `UnsafeCell`) a sebelisa sesupi sena kapa sesupi sefe kapa sefe se tsoang ho sona.
    /// Haeba o hloka ho fetola likahare tsa selae, sebelisa [`as_mut_ptr`].
    ///
    /// Ho fetola setshelo se boletsoeng ke selae sena ho ka etsa hore buffer ea sona e fallisoe hape, e leng ho tla etsa hore litlhahiso ho eona e se sebetse.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// E khutlisetsa sesupisi se sa sireletsehang se ka fetoloang ho buffer ea selae.
    ///
    /// Motho ea letsitseng o tlameha ho netefatsa hore selae se feta sephumane ts'ebetsong ena, kapa ho seng joalo se tla qetella se supa litšila.
    ///
    /// Ho fetola setshelo se boletsoeng ke selae sena ho ka etsa hore buffer ea sona e fallisoe hape, e leng ho tla etsa hore litlhahiso ho eona e se sebetse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// E khutlisa litšupiso tse peli tse tala tse harelaneng le selae.
    ///
    /// Lebelo le khutlisitsoeng le bulehile ka halofo, ho bolelang hore sesupa-qetellong se supa e 'ngoe e fetileng * ntlha ea ho qetela ea selae.
    /// Ka tsela ena, selae se se nang letho se emeloa ke litsupa tse peli tse lekanang, 'me phapang lipakeng tsa litsupa tse peli e emetse boholo ba selae.
    ///
    /// Bona [`as_ptr`] bakeng sa litemoso mabapi le ho sebelisa litsupa tsena.Sesupa sa ho qetela se hloka tlhokomeliso e eketsehileng, hobane ha se supe ntho e sebetsang selae.
    ///
    /// Mosebetsi ona o bohlokoa bakeng sa ho sebelisana le li-interface tsa kantle ho naha tse sebelisang litsupa tse peli ho supa mefuta e mengata ea mohopolo, joalo ka ha ho tloaelehile ho C++ .
    ///
    ///
    /// Ho ka ba molemo hape ho hlahloba hore na sesupa-hloko sa ntho e bua ka karolo ea selae sena:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // TSHIRELETSO: `add` mona e bolokehile, hobane:
        //
        //   - Litlhahiso ka bobeli ke karolo ea ntho e ts'oanang, joalo ka ha ho supa ka kotloloho ho feta ntho le eona ho bohlokoa.
        //
        //   - Boholo ba selae ha bo mohla bo boholo ho feta li-byte tsa isize::MAX, joalo ka ha ho boletsoe mona:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Ha ho na ho phuthela ka hohle ho amehang, kaha likhae ha li phuthele ho feta qetellong ea sebaka sa aterese.
        //
        // Bona litokomane tsa pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// E khutlisa lits'oants'o tse peli tse sa bolokehang tse ka fetoloang.
    ///
    /// Lebelo le khutlisitsoeng le bulehile ka halofo, ho bolelang hore sesupa-qetellong se supa e 'ngoe e fetileng * ntlha ea ho qetela ea selae.
    /// Ka tsela ena, selae se se nang letho se emeloa ke litsupa tse peli tse lekanang, 'me phapang lipakeng tsa litsupa tse peli e emetse boholo ba selae.
    ///
    /// Bona [`as_mut_ptr`] bakeng sa litemoso mabapi le ho sebelisa litsupa tsena.
    /// Sesupa sa ho qetela se hloka tlhokomeliso e eketsehileng, hobane ha se supe ntho e sebetsang selae.
    ///
    /// Mosebetsi ona o bohlokoa bakeng sa ho sebelisana le li-interface tsa kantle ho naha tse sebelisang litsupa tse peli ho supa mefuta e mengata ea mohopolo, joalo ka ha ho tloaelehile ho C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // TSHIRELETSO: Bona as_ptr_range() ka hodimo hore hobaneng `add` mona e bolokehile.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// E chencha likarolo tse peli selae.
    ///
    /// # Arguments
    ///
    /// * a, Lenane la ntlha ea mantlha
    /// * b, Lenane la ntlha ea bobeli
    ///
    /// # Panics
    ///
    /// Panics haeba `a` kapa `b` li felile.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ha u khone ho nka mekoloto e 'meli e ka feto-fetohang ho vector e le' ngoe, ka hona sebelisa litsupa tse tala.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // TŠIRELETSO: `pa` le `pb` li entsoe ka litšupiso tse sireletsehileng tse ka fetoloang le ho fetisoa
        // ho likarolo tsa selae ka hona li netefalitsoe hore li tla sebetsa le ho hokahana.
        // Hlokomela hore ho fihlella likarolo tse ka morao ho `a` le `b` ho hlahlojoa mme ho tla ba panic ha e tsoa meeling.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// E khutlisetsa tatellano ea likarolo selae, sebakeng sa eona.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Bakeng sa mefuta e menyenyane haholo, motho ka mong ea balang ka tsela e tloaelehileng ha a sebetse hantle.
        // Re ka etsa betere, ha re fuoa load/store e sa sebetsanang hantle, ka ho kenya chunk e kholo le ho khutlisa rejista.
        //

        // Ka nepo LLVM e ka re etsetsa sena, kaha e tseba hantle ho feta kamoo re tsebang hore na ho bala ho sa ngolisoang hantle ho sebetsa hantle (hobane liphetoho tseo lipakeng tsa mefuta e fapaneng ea ARM, mohlala) le hore na boholo ba chunk bo ka ba joang.
        // Ka bomalimabe, ho tloha ka LLVM 4.0 (2017-05) e bula feela senotlolo, ka hona re hloka ho iketsetsa sena.
        // (Khopolo-taba: ho khutlela morao hoa khathatsa hobane mahlakore a ka hokahana ka tsela e fapaneng-a tla ba teng, ha bolelele bo sa makatsa-ka hona ha ho na mokhoa oa ho ntša li-pre-and postludes tsa ho sebelisa SIMD e tsamaellaneng ka botlalo bohareng.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Sebelisa tlhaho ea llvm.bswap ho khutlisa li-u8 ka usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // POLOKEHO: Ho na le lintho tse 'maloa tseo u lokelang ho li hlahloba mona:
                //
                // - Hlokomela hore `chunk` e kanna ea ba 4 kapa 8 ka lebaka la cheke ea cfg e kaholimo.Kahoo `chunk - 1` e nepahetse.
                // - Ho indexing le index `i` ho nepahetse ha cheke ea loop e tiisa
                //   `i + chunk - 1 < ln / 2`
                //   <00> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Ho indexing le index `ln - i - chunk = ln - (i + chunk)` ho nepahetse:
                //   - `i + chunk > 0` ke 'nete e fokolang.
                //   - Cheke ea lupu e tiisa:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ka hona ho tlosa ha ho phalle.
                // - Mehala ea `read_unaligned` le `write_unaligned` e hantle:
                //   - `pa` e supa index ea `i` moo `i < ln / 2 - (chunk - 1)` (bona kaholimo) le `pb` e supa index ea `ln - i - chunk`, ka hona bobeli ba tsona ke bonyane `chunk` li-byte tse ngata hole le pheletso ea `self`.
                //
                //   - Memori efe kapa efe e qalileng e nepahetse `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Sebelisa rotate-by-16 ho khutlisa li-u16 ka u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // POLOKEHO: u32 e sa buloang e ka baloa ho tloha ho `i` haeba `i + 1 < ln`
                // ('me ho hlakile hore ke `i < ln`), hobane karolo ka' ngoe ke li-byte tse 2 'me re bala tse 4.
                //
                // `i + chunk - 1 < ln / 2` # ha boemo
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Kaha e ka tlase ho bolelele bo arotsoeng ke 2, joale e tlameha ho ba meeling.
                //
                // Sena se boetse se bolela hore boemo ba `0 < i + chunk <= ln` bo lula bo hlomphuoa, ho netefatsa hore sesupa sa `pb` se ka sebelisoa ka polokeho.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // POLOKEHO: `i` e tlase ho halofo ea bolelele ba selae kahoo
            // ho fihlella `i` le `ln - i - 1` ho bolokehile (`i` e qala ka 0 mme e ke ke ea feta `ln / 2 - 1`).
            // Lintlha tse hlahisoang `pa` le `pb` ka hona li nepahetse ebile li hokahane, 'me li ka baloa ho tloha le ho ngoloa ho.
            //
            //
            unsafe {
                // Ho chencha ho sa bolokehang ho qoba meeli ho lekola phapanyetsano e bolokehileng.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// E khutlisetsa iterator holim'a selae.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// E khutlisetsa iterator e lumellang ho fetola boleng bo bong le bo bong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// E khutlisetsa iterator holim'a bolelele bohle ba windows ba bolelele ba `size`.
    /// windows ea kopana.
    /// Haeba selae se le khutsuanyane ho feta `size`, iterator ha e khutlise boleng.
    ///
    /// # Panics
    ///
    /// Panics haeba `size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Haeba selae se le khuts'oane ho `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke lilae 'me ha li kopane.Haeba `chunk_size` e sa arola bolelele ba selae, chunk ea ho qetela e ke ke ea ba le bolelele ba `chunk_size`.
    ///
    /// Bona [`chunks_exact`] bakeng sa phapano ea iterator ena e khutlisang likarolo tsa lintho tsa `chunk_size` kamehla, le [`rchunks`] bakeng sa iterator e tšoanang empa e qala qetellong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke lilae tse ka feto-fetohang, 'me ha li kopane.Haeba `chunk_size` e sa arola bolelele ba selae, chunk ea ho qetela e ke ke ea ba le bolelele ba `chunk_size`.
    ///
    /// Bona [`chunks_exact_mut`] bakeng sa phapano ea iterator ena e khutlisang likarolo tsa lintho tsa `chunk_size` kamehla, le [`rchunks_mut`] bakeng sa iterator e tšoanang empa e qala qetellong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke lilae 'me ha li kopane.
    /// Haeba `chunk_size` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `chunk_size-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `remainder` ea iterator.
    ///
    ///
    /// Ka lebaka la chunk ka 'ngoe e nang le likarolo tsa `chunk_size` hantle, motlatsi o ka ntlafatsa khoutu e hlahisoang hantle ho feta ea [`chunks`].
    ///
    /// Bona [`chunks`] bakeng sa phapano ea iterator ena e khutlisang karolo e setseng joalo ka chunk e nyane, le [`rchunks_exact`] bakeng sa iterator e ts'oanang empa e qala qetellong ea selae.
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke lilae tse ka feto-fetohang, 'me ha li kopane.
    /// Haeba `chunk_size` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `chunk_size-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `into_remainder` ea iterator.
    ///
    ///
    /// Ka lebaka la chunk ka 'ngoe e nang le likarolo tsa `chunk_size` hantle, motlatsi o ka ntlafatsa khoutu e hlahisoang hantle ho feta ea [`chunks_mut`].
    ///
    /// Bona [`chunks_mut`] bakeng sa phapano ea iterator ena e khutlisang karolo e setseng joalo ka chunk e nyane, le [`rchunks_exact_mut`] bakeng sa iterator e ts'oanang empa e qala qetellong ea selae.
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// E arola selae ka selae sa `N`-element arrays, ho nka hore ha ho na letho le setseng.
    ///
    ///
    /// # Safety
    ///
    /// Sena se ka bitsoa feela neng
    /// - Sekhahla se arohana hantle ho ba `N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // TŠIRELETSO: Li-chunks tse 1 ha li na li setseng
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // TSHIRELETSO: Bolelele ba selae (6) ke bongata ba 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Tsena li ne li ke ke tsa utloahala:
    /// // tlohella likotoana: &[[_ _;5]]= slice.as_chunks_unchecked()//Bolelele ba selae ha se mefuta e 5 ea li-chunks:&[[_;0]]= slice.as_chunks_unchecked()//Likoto tse bolelele ba Zero ha li lumelloe le ka mohla
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // TSHIRELETSO: Boemo ba rona ba pele ke bona bo hlokehang ho bitsa sena
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // TŠIRELETSO: Re lahlela selae sa likarolo tsa `new_len * N` ho
        // selae sa `new_len` likaroloana tse ngata tsa `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Arola selae ka selae sa `N`-element arrays, ho qala qalong ea selae, le selae se setseng se bolelele bo ka tlase ho `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // TSHIRELETSO: Re se ntse re tshohile bakeng sa lefela, mme re netefaditswe ke kaho
        // hore bolelele ba subslice ke makhetlo a mangata a N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Arola selae ka selae sa `N`-element arrays, ho qala qetellong ea selae, le selae se setseng se bolelele bo ka tlase ho `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // TSHIRELETSO: Re se ntse re tshohile bakeng sa lefela, mme re netefaditswe ke kaho
        // hore bolelele ba subslice ke makhetlo a mangata a N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `N` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke litšupiso tse fapaneng 'me ha li kopane.
    /// Haeba `N` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `N-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `remainder` ea iterator.
    ///
    ///
    /// Mokhoa ona ke const generic e lekanang le [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// E arola selae ka selae sa `N`-element arrays, ho nka hore ha ho na letho le setseng.
    ///
    ///
    /// # Safety
    ///
    /// Sena se ka bitsoa feela neng
    /// - Sekhahla se arohana hantle ho ba `N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // TŠIRELETSO: Li-chunks tse 1 ha li na li setseng
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // TSHIRELETSO: Bolelele ba selae (6) ke bongata ba 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Tsena li ne li ke ke tsa utloahala:
    /// // tlohella likotoana: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//Bolelele ba selae ha se mefuta e 5 ea li-chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Likoto tse bolelele ba Zero ha li lumelloe le ka mohla
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // TSHIRELETSO: Boemo ba rona ba pele ke bona bo hlokehang ho bitsa sena
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // TŠIRELETSO: Re lahlela selae sa likarolo tsa `new_len * N` ho
        // selae sa `new_len` likaroloana tse ngata tsa `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Arola selae ka selae sa `N`-element arrays, ho qala qalong ea selae, le selae se setseng se bolelele bo ka tlase ho `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // TSHIRELETSO: Re se ntse re tshohile bakeng sa lefela, mme re netefaditswe ke kaho
        // hore bolelele ba subslice ke makhetlo a mangata a N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Arola selae ka selae sa `N`-element arrays, ho qala qetellong ea selae, le selae se setseng se bolelele bo ka tlase ho `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // TSHIRELETSO: Re se ntse re tshohile bakeng sa lefela, mme re netefaditswe ke kaho
        // hore bolelele ba subslice ke makhetlo a mangata a N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `N` tsa selae ka nako, ho qala qalong ea selae.
    ///
    /// Li-chunks ke litšupiso tse ngata tse fetohang 'me ha li kopane.
    /// Haeba `N` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `N-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `into_remainder` ea iterator.
    ///
    ///
    /// Mokhoa ona ke const generic e lekanang le [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics haeba `N` ke 0. Cheke ena e kanna ea fetoloa hore e be phoso ea nako ea ho bokella pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// E khutlisetsa iterator e fetang holim'a windows ea likarolo tsa `N` tsa selae, ho qala qalong ea selae.
    ///
    ///
    /// Ena ke const generic e lekanang le [`windows`].
    ///
    /// Haeba `N` e feta boholo ba selae, e ke ke ea khutlisa windows.
    ///
    /// # Panics
    ///
    /// Panics haeba `N` e le 0.
    /// Cheke ena e kanna ea fetoloa hore e be phoso ea nako e kopaneng pele mokhoa ona o tsitsisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qetellong ea selae.
    ///
    /// Li-chunks ke lilae 'me ha li kopane.Haeba `chunk_size` e sa arola bolelele ba selae, chunk ea ho qetela e ke ke ea ba le bolelele ba `chunk_size`.
    ///
    /// Bona [`rchunks_exact`] bakeng sa phapano ea iterator ena e khutlisetsang likarolo tsa lintho tsa `chunk_size` kamehla, le [`chunks`] bakeng sa iterator e ts'oanang empa e qala qalong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qetellong ea selae.
    ///
    /// Li-chunks ke lilae tse ka feto-fetohang, 'me ha li kopane.Haeba `chunk_size` e sa arola bolelele ba selae, chunk ea ho qetela e ke ke ea ba le bolelele ba `chunk_size`.
    ///
    /// Bona [`rchunks_exact_mut`] bakeng sa phapano ea iterator ena e khutlisetsang likarolo tsa lintho tsa `chunk_size` kamehla, le [`chunks_mut`] bakeng sa iterator e ts'oanang empa e qala qalong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qetellong ea selae.
    ///
    /// Li-chunks ke lilae 'me ha li kopane.
    /// Haeba `chunk_size` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `chunk_size-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `remainder` ea iterator.
    ///
    /// Ka lebaka la chunk ka 'ngoe e nang le likarolo tsa `chunk_size` hantle, motlatsi o ka ntlafatsa khoutu e hlahisoang hantle ho feta ea [`chunks`].
    ///
    /// Bona [`rchunks`] bakeng sa phapano ea iterator ena e khutlisang karolo e setseng joalo ka chunk e nyane, le [`chunks_exact`] bakeng sa iterator e ts'oanang empa e qala qalong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a likarolo tsa `chunk_size` tsa selae ka nako, ho qala qetellong ea selae.
    ///
    /// Li-chunks ke lilae tse ka feto-fetohang, 'me ha li kopane.
    /// Haeba `chunk_size` e sa arola bolelele ba selae, ho tla siuoa likarolo tsa ho qetela ho fihlela ho `chunk_size-1` mme li ka nkuoa ho tsoa ts'ebetsong ea `into_remainder` ea iterator.
    ///
    /// Ka lebaka la chunk ka 'ngoe e nang le likarolo tsa `chunk_size` hantle, motlatsi o ka ntlafatsa khoutu e hlahisoang hantle ho feta ea [`chunks_mut`].
    ///
    /// Bona [`rchunks_mut`] bakeng sa phapano ea iterator ena e khutlisang karolo e setseng joalo ka chunk e nyane, le [`chunks_exact_mut`] bakeng sa iterator e ts'oanang empa e qala qalong ea selae.
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `chunk_size` e le 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// E khutlisetsa iterator holim'a selae se hlahisang likarolo tsa lintho tse sa keneng tse sebelisang selelekela ho li arola.
    ///
    /// Moemedi o bitswa ka dielemente tse pedi tse di latelang, ho bolela hore moemedi o bitswa `slice[0]` le `slice[1]` ebe ho `slice[1]` le `slice[2]` jwalojwalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mokhoa ona o ka sebelisoa ho ntša lipeeletso tse hlophisitsoeng:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a selae se hlahisang likarolo tse sa fetoleng tsa lintho tse ka sebelisoang ho sebelisa poleloana ho li arola.
    ///
    /// Moemedi o bitswa ka dielemente tse pedi tse di latelang, ho bolela hore moemedi o bitswa `slice[0]` le `slice[1]` ebe ho `slice[1]` le `slice[2]` jwalojwalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mokhoa ona o ka sebelisoa ho ntša lipeeletso tse hlophisitsoeng:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Arola selae se le seng ho tse peli ka index.
    ///
    /// Ea pele e tla ba le li-indices tsohle tse tsoang ho `[0, mid)` (ntle le index ea `mid` ka boeona) 'me ea bobeli e tla ba le li-indices tsohle tse tsoang ho `[mid, len)` (ntle le index ea `len` ka boyona).
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // TSHIRELETSO: `[ptr; mid]` le `[mid; len]` di ka hare ho `self`, e leng
        // e phethahatsa litlhoko tsa `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Arola selae se le seng se ka fetoloang habeli ka index.
    ///
    /// Ea pele e tla ba le li-indices tsohle tse tsoang ho `[0, mid)` (ntle le index ea `mid` ka boeona) 'me ea bobeli e tla ba le li-indices tsohle tse tsoang ho `[mid, len)` (ntle le index ea `len` ka boyona).
    ///
    ///
    /// # Panics
    ///
    /// Panics haeba `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // TSHIRELETSO: `[ptr; mid]` le `[mid; len]` di ka hare ho `self`, e leng
        // e phethahatsa litlhoko tsa `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Arola selae se le seng ho tse peli ka index, ntle le ho lekola meeli.
    ///
    /// Ea pele e tla ba le li-indices tsohle tse tsoang ho `[0, mid)` (ntle le index ea `mid` ka boeona) 'me ea bobeli e tla ba le li-indices tsohle tse tsoang ho `[mid, len)` (ntle le index ea `len` ka boyona).
    ///
    ///
    /// Bakeng sa mokhoa o mong o bolokehileng bona [`split_at`].
    ///
    /// # Safety
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli ke *[boits'oaro bo sa hlalosoang]* leha ts'ebeliso e hlahang e sa sebelisoe.Moletsi o tlameha ho netefatsa hore `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // TSHIRELETSO: Moletsi o lokela ho hlahloba `0 <= mid <= self.len()` eo
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Arola selae se le seng se ka fetoloang habeli ka index, ntle le ho lekola meeli.
    ///
    /// Ea pele e tla ba le li-indices tsohle tse tsoang ho `[0, mid)` (ntle le index ea `mid` ka boeona) 'me ea bobeli e tla ba le li-indices tsohle tse tsoang ho `[mid, len)` (ntle le index ea `len` ka boyona).
    ///
    ///
    /// Bakeng sa mokhoa o mong o bolokehileng bona [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli ke *[boits'oaro bo sa hlalosoang]* leha ts'ebeliso e hlahang e sa sebelisoe.Moletsi o tlameha ho netefatsa hore `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // TSHIRELETSO: Moletsi o lokela ho hlahloba `0 <= mid <= self.len()` eo.
        //
        // `[ptr; mid]` 'me `[mid; len]` ha e kopane, kahoo ho khutlisa litšupiso tse ka feto-fetohang ho lokile.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// E khutlisa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred`.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Haeba ntlha ea pele e tsamaellana, selae se se nang letho e tla ba ntho ea pele e khutlisoang ke sehlahlobi.
    /// Ka mokhoa o ts'oanang, haeba ntlha ea hoqetela siling e ts'oana, selae se se nang letho e tla ba ntho ea ho qetela e khutlisitsoeng ke motsamaisi.
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Haeba likarolo tse peli tse tšoanang li bapile ka kotloloho, selae se se nang letho se tla ba teng lipakeng tsa bona:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse fetohang tse arohaneng le likarolo tse tšoanang le `pred`.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// E khutlisa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred`.
    /// Karolo e tsamaellanang e fumaneha qetellong ea subslice e fetileng e le terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Haeba ntlha ea ho qetela ea selae e ts'oana, karolo eo e tla nkuoa e le terminator ea selae se fetileng.
    ///
    /// Selae seo e tla ba ntho ea hoqetela e khutlisitsoeng ke sehlahlobi.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse fetohang tse arohaneng le likarolo tse tšoanang le `pred`.
    /// Karolo e tsamaellanang e fumaneha ho subslice e fetileng e le terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred`, ho qala qetellong ea selae le ho sebetsa morao.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Joalo ka `split()`, haeba ntlha ea pele kapa ea ho qetela e tsamaellana, selae se se nang letho e tla ba ntho ea pele (kapa ea ho qetela) e khutlisoang ke sehlahlobi.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse fetohang tse arohaneng le likarolo tse tšoanang le `pred`, ho qala qetellong ea selae le ho sebetsa morao.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred`, e lekanyelitsoeng ho khutlisetsa boholo ba lintho tsa `n`.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// Karolo ea ho qetela e khutlisitsoeng, haeba e teng, e tla ba le selae se setseng.
    ///
    /// # Examples
    ///
    /// Hatisa selae se arohaneng hang ka linomoro tse arohanngoang ke 3 (ke hore, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred`, e lekanyelitsoeng ho khutlisetsa boholo ba lintho tsa `n`.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// Karolo ea ho qetela e khutlisitsoeng, haeba e teng, e tla ba le selae se setseng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred` e lekanyelitsoeng ho khutlisetsa boholo ba lintho tsa `n`.
    /// Sena se qala qetellong ea selae ebe se sebetsa morao.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// Karolo ea ho qetela e khutlisitsoeng, haeba e teng, e tla ba le selae se setseng.
    ///
    /// # Examples
    ///
    /// Hatisa selae se arohaneng hang, ho qala qetellong, ka linomoro tse arohanngoang ke 3 (ke hore, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// E khutlisetsa iterator holim'a lipeeletso tse arotsoeng ke likarolo tse tšoanang le `pred` e lekanyelitsoeng ho khutlisetsa boholo ba lintho tsa `n`.
    /// Sena se qala qetellong ea selae ebe se sebetsa morao.
    /// Karolo e tsamaellanang ha e eo ho licheleteng.
    ///
    /// Karolo ea ho qetela e khutlisitsoeng, haeba e teng, e tla ba le selae se setseng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// E khutlisa `true` haeba selae se na le ntho e nang le boleng bo fanoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Haeba u sena `&T`, empa u na le `&U` hoo `T: Borrow<U>` (mohlala
    /// Khoele: Alima<str>U ka sebelisa `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // selae sa `String`
    /// assert!(v.iter().any(|e| e == "hello")); // batla ka `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// E khutlisa `true` haeba `needle` e le ketapele ea selae.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Kamehla e khutlisa `true` haeba `needle` e le selae se se nang letho:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// E khutlisa `true` haeba `needle` e le sengoathoana sa selae seo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Kamehla e khutlisa `true` haeba `needle` e le selae se se nang letho:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// E khutlisetsa lekhetho le tlositsoeng qalo.
    ///
    /// Haeba selae se qala ka `prefix`, se khutlisetsa sekhahla ka morao ho sehlongwapele, se phuthetsoe ka `Some`.
    /// Haeba `prefix` e se na letho, khutlisa selae sa mantlha.
    ///
    /// Haeba selae ha se qale ka `prefix`, se khutlisa `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ts'ebetso ena e tla hloka ho ngoloa bocha haeba SlicePattern e ba e tsoetseng pele le ha e le.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// E khutlisetsa subslice ha ho tlosoa sehlomathiso.
    ///
    /// Haeba selae se fela ka `suffix`, se khutlisetsa sekhahla pele ho sehlong, se phuthetsoe ka `Some`.
    /// Haeba `suffix` e se na letho, khutlisa selae sa mantlha.
    ///
    /// Haeba selae ha se felle ka `suffix`, se khutlisa `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ts'ebetso ena e tla hloka ho ngoloa bocha haeba SlicePattern e ba e tsoetseng pele le ha e le.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary e batlisisa selae sena se hlophisitsoeng bakeng sa ntho e fanoeng.
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.
    /// Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    ///
    /// Bona hape [`binary_search_by`], [`binary_search_by_key`], le [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'ne.
    /// Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Haeba u batla ho kenya ntho ho vector e hlophisitsoeng, ha u ntse u boloka tatellano ea mofuta:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary e batlisisa selae sena se hlophisitsoeng ka mosebetsi oa papiso.
    ///
    /// Mosebetsi oa papiso o lokela ho kenya tšebetsong taelo e lumellanang le mofuta oa selae se ka tlase, e khutlisetse khoutu ea odara e bonts'ang hore na ngangisano ea eona ke `Less`, `Equal` kapa `Greater` sepheo se lakatsehang.
    ///
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    /// Bona hape [`binary_search`], [`binary_search_by_key`], le [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'ne.Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // TSHIRELETSO: mohala o etswa o bolokehile ke bahlaseli ba latelang:
            // - `mid >= 0`
            // - `mid < size`: `mid` e lekantsoe ke `[left; right)` e tlamiloeng.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Lebaka leo ka lona re sebelisang phallo ea taolo ea if/else ho fapana le papali ke hobane ts'ebetso ea papiso ea li-reorder, e leng bonolo ho feta.
            //
            // Ena ke x86 asm bakeng sa u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary e batlisisa selae sena se hlophisitsoeng ka ts'ebetso ea senotlolo.
    ///
    /// E nka hore selae se hlophisitsoe ka senotlolo, ka mohlala le [`sort_by_key`] e sebelisa ts'ebetso e tšoanang ea senotlolo.
    ///
    /// Haeba boleng bo fumanoe joale [`Result::Ok`] ea khutlisoa, e nang le index ea ntho e tšoanang.
    /// Haeba ho na le lipapali tse ngata, ho ka ba le e 'ngoe ea tsona e ka khutlisoang.
    /// Haeba boleng bo sa fumanoe joale [`Result::Err`] ea khutlisoa, e nang le index moo ho ka kenyelletsoang ntho e tšoanang ha e ntse e boloka tatellano.
    ///
    ///
    /// Bona hape [`binary_search`], [`binary_search_by`], le [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// E sheba letoto la likarolo tse 'nè selae sa lipara tse hlophiloeng ke likarolo tsa tsona tsa bobeli.
    /// Ea pele e fumanoa, ka boemo bo ikhethileng bo ikhethang;ea bobeli le ea boraro ha li fumanoe;ea bone e ka tšoana le boemo bofe kapa bofe ho `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links e lumelloa ka ha `slice::sort_by_key` e crate `alloc`, 'me ha e eo ha e sa le teng ha ho ntse ho ahoa `core`.
    //
    // likhokahano ho crate e tlase nokeng: #74481.Kaha li-primitives li ngotsoe feela ka libstd (#73423), hona ha ho mohla ho lebisang ho lihokelo tse robehileng ts'ebetsong.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// E hlophisa selae, empa e kanna ea se boloke tatellano ea likarolo tse lekanang.
    ///
    /// Mofuta ona ha oa tsitsa (ke hore, o ka hlophisa bocha likarolo tse lekanang), sebakeng (ke hore, ha o abele), le *O*(*n*\*log(* n*)) nyeoe e mpe ka ho fetisisa.
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le [pattern-defeating quicksort][pdqsort] ea Orson Peters, e kopanyang nyeoe e potlakileng ea karolelano e potlakileng le boemo bo potlakileng ka ho fetesisa ba heapsort, ha e ntse e fihlela nako e lekanang lilomong ka mekhoa e meng.
    /// E sebelisa mekhoa e meng ho qoba maemo a senyehang, empa ka seed e sa fetoheng ho fana ka boits'oaro bo ikemiselitseng.
    ///
    /// E tloaetse ho potlaka ho feta ho hlophisa ka mokhoa o tsitsitseng, ntle le maemong a 'maloa a ikhethang, mohlala, ha selae se na le tatellano e hlophisitsoeng e hlophisitsoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// E hlophisa selae ka mosebetsi o bapisang, empa e kanna ea se boloke tatellano ea likarolo tse lekanang.
    ///
    /// Mofuta ona ha oa tsitsa (ke hore, o ka hlophisa bocha likarolo tse lekanang), sebakeng (ke hore, ha o abele), le *O*(*n*\*log(* n*)) nyeoe e mpe ka ho fetisisa.
    ///
    /// Mosebetsi oa ho bapisa o tlameha ho hlalosa tatellano eohle ea likarolo tsa selae.Haeba odara e sa fella, taelo ea lielemente ha e tsejoe.Taelo ke taelo e felletseng haeba e le (bakeng sa bohle `a`, `b` le `c`):
    ///
    /// * total and antisymmetric: hantle ke e le 'ngoe ea `a < b`, `a == b` kapa `a > b`,' me
    /// * e fetohang, `a < b` le `b < c` e bolela `a < c`.E ts'oanang e tlameha ho ts'oara `==` le `>`.
    ///
    /// Mohlala, ha [`f64`] e sa sebelise [`Ord`] hobane `NaN != NaN`, re ka sebelisa `partial_cmp` joalo ka mofuta oa rona ha re tseba hore selae ha se na `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le [pattern-defeating quicksort][pdqsort] ea Orson Peters, e kopanyang nyeoe e potlakileng ea karolelano e potlakileng le boemo bo potlakileng ka ho fetesisa ba heapsort, ha e ntse e fihlela nako e lekanang lilomong ka mekhoa e meng.
    /// E sebelisa mekhoa e meng ho qoba maemo a senyehang, empa ka seed e sa fetoheng ho fana ka boits'oaro bo ikemiselitseng.
    ///
    /// E tloaetse ho potlaka ho feta ho hlophisa ka mokhoa o tsitsitseng, ntle le maemong a 'maloa a ikhethang, mohlala, ha selae se na le tatellano e hlophisitsoeng e hlophisitsoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ho hlopha ka morao
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// E hlophisa selae ka ts'ebetso ea senotlolo, empa e kanna ea se boloke tatellano ea likarolo tse lekanang.
    ///
    /// Mofuta ona ha oa tsitsa (ke hore, o ka hlophisa bocha likarolo tse lekanang), sebakeng (ke hore, ha o abele), le *O*(m\* * n *\* log(*n*)) boemo bo bobe ka ho fetesisa, moo mosebetsi oa bohlokoa e leng *O*(* limithara).
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le [pattern-defeating quicksort][pdqsort] ea Orson Peters, e kopanyang nyeoe e potlakileng ea karolelano e potlakileng le boemo bo potlakileng ka ho fetesisa ba heapsort, ha e ntse e fihlela nako e lekanang lilomong ka mekhoa e meng.
    /// E sebelisa mekhoa e meng ho qoba maemo a senyehang, empa ka seed e sa fetoheng ho fana ka boits'oaro bo ikemiselitseng.
    ///
    /// Ka lebaka la leano la eona la bohlokoa la ho letsetsa, [`sort_unstable_by_key`](#method.sort_unstable_by_key) e kanna ea lieha ho feta [`sort_by_cached_key`](#method.sort_by_cached_key) maemong ao mosebetsi oa bohlokoa o turang.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Beakanya selae hore setheo sa `index` se maemong a sona a ho qetela.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Beakanya selae ka mosebetsi oa ho bapisa hoo ntho ea `index` e leng boemong ba eona ba ho qetela bo hlophisitsoeng.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Beakanya selae ka ts'ebetso ea senotlolo e le hore karolo ea `index` e maemong a eona a hoqetela.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Beakanya selae hore setheo sa `index` se maemong a sona a ho qetela.
    ///
    /// Ho hlophisa bocha hona ho na le thepa ea tlatsetso eo boleng bofe kapa bofe boemong ba `i < index` bo tla ba tlase ho kapa bo lekanang le boleng bofe kapa bofe boemong ba `j > index`.
    /// Ntle le moo, ho hlophisa bocha hona ha hoa tsitsa (ke hore
    /// palo efe kapa efe ea likarolo tse lekanang e ka qetella e le maemong a `index`), sebakeng sa eona (ke hore
    /// ha e abele), le *O*(*n*) e mpe ka ho fetisisa.
    /// Mosebetsi ona o boetse o tsejoa e le "kth element" lilaebraring tse ling.
    /// E khutlisa triplet ea litekanyetso tse latelang: likarolo tsohle tse ka tlase ho e le 'ngoe ho index e fanoeng, boleng ho index e fanoeng, le likarolo tsohle tse kholo ho feta tse fumanehang ho index.
    ///
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le karolo e potlakileng ea khetho ea algorithm e tšoanang ea quicksort e sebelisitsoeng bakeng sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ha `index >= len()`, ho bolelang hore kamehla panics ka likhae tse se nang letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fumana ea bohareng
    /// v.select_nth_unstable(2);
    ///
    /// // Re tiiselitsoe feela hore selae e tla ba se seng sa tse latelang, ho ipapisitsoe le tsela eo re hlophisang ka index e boletsoeng.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Beakanya selae ka mosebetsi oa ho bapisa hoo ntho ea `index` e leng boemong ba eona ba ho qetela bo hlophisitsoeng.
    ///
    /// Ho hlophisa bocha hona ho na le thepa ea tlatsetso ea hore boleng bofe kapa bofe bo maemong a `i < index` bo tla ba tlase kapa bo lekane le boleng bofe kapa bofe boemong ba `j > index` ho sebelisoa mosebetsi oa papiso.
    /// Ntle le moo, ho hlophisa bocha hona ha hoa tsitsa (ke hore, palo efe kapa efe ea likarolo tse lekanang e ka qetella e le maemong a `index`), sebakeng (ke hore ha e abele), le boemo bo bobe ka ho fetisisa ba *O*(*n*).
    /// Mosebetsi ona o tsejoa hape e le "kth element" lilaebraring tse ling.
    /// E khutlisa katatulo ea litekanyetso tse latelang: likarolo tsohle tse ka tlase ho e le 'ngoe ho index e fanoeng, boleng ho index e fanoeng, le likarolo tsohle tse kholo ho feta e leng ho index e fanoeng, ho sebelisoa mosebetsi oa papiso.
    ///
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le karolo e potlakileng ea khetho ea algorithm e tšoanang ea quicksort e sebelisitsoeng bakeng sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ha `index >= len()`, ho bolelang hore kamehla panics ka likhae tse se nang letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Fumana motho ea bohareng joalo ka ha eka selae se hlophiloe ka tatellano.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Re tiiselitsoe feela hore selae e tla ba se seng sa tse latelang, ho ipapisitsoe le tsela eo re hlophisang ka index e boletsoeng.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Beakanya selae ka ts'ebetso ea senotlolo e le hore karolo ea `index` e maemong a eona a hoqetela.
    ///
    /// Ho hlophisa bocha hona ho na le thepa ea tlatsetso eo boleng bofe kapa bofe bo maemong a `i < index` bo tla ba tlase ho kapa bo lekanang le boleng bofe kapa bofe boemong ba `j > index` ho sebelisoa ts'ebetso ea senotlolo.
    /// Ntle le moo, ho hlophisa bocha hona ha hoa tsitsa (ke hore, palo efe kapa efe ea likarolo tse lekanang e ka qetella e le maemong a `index`), sebakeng (ke hore ha e abele), le boemo bo bobe ka ho fetisisa ba *O*(*n*).
    /// Mosebetsi ona o tsejoa hape e le "kth element" lilaebraring tse ling.
    /// E khutlisa triplet ea litekanyetso tse latelang: likarolo tsohle tse ka tlase ho e le 'ngoe ho index e fanoeng, boleng ho index e fanoeng, le likarolo tsohle tse kholo ho feta tse fumanehang ho index, ho sebelisoa ts'ebetso ea senotlolo e fanoeng.
    ///
    ///
    /// # Ts'ebetsong ea hajoale
    ///
    /// Algorithm ea hajoale e ipapisitse le karolo e potlakileng ea khetho ea algorithm e tšoanang ea quicksort e sebelisitsoeng bakeng sa [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ha `index >= len()`, ho bolelang hore kamehla panics ka likhae tse se nang letho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Khutlisa bohare joalokaha eka sehlopha se hlophisitsoe ho latela boleng bo felletseng.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Re tiiselitsoe feela hore selae e tla ba se seng sa tse latelang, ho ipapisitsoe le tsela eo re hlophisang ka index e boletsoeng.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// E tsamaisa likarolo tsohle tse latellanang khafetsa ho fihlela qetellong ea selae ho latela ts'ebetso ea [`PartialEq`] trait.
    ///
    ///
    /// E khutlisa likarolo tse peli.Ea pele ha e na likarolo tse phetoang tse phetoang.
    /// Ea bobeli e na le likopi tse fapaneng ka tatellano e boletsoeng.
    ///
    /// Haeba selae se hlophiloe, selae sa pele se khutlisitsoeng ha se na likopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// E tsamaisa tsohle ntle le tsa pele tsa likarolo tse latellanang ho fihlela qetellong ea selae e khotsofatsa kamano e fanoeng ea tekano.
    ///
    /// E khutlisa likarolo tse peli.Ea pele ha e na likarolo tse phetoang tse phetoang.
    /// Ea bobeli e na le likopi tse fapaneng ka tatellano e boletsoeng.
    ///
    /// Mosebetsi oa `same_bucket` o fetisitsoe ka litšupiso tsa likarolo tse peli tsa selae mme o tlameha ho bona hore na likarolo li bapisoa li lekana
    /// Lintlha li fetisoa ka tatellano e fapaneng ho tloha ka tatellano ea tsona selae, kahoo haeba `same_bucket(a, b)` e khutlisa `true`, `a` e sisinngoa qetellong ea selae.
    ///
    ///
    /// Haeba selae se hlophiloe, selae sa pele se khutlisitsoeng ha se na likopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Leha re na le litšupiso tse ka fetoloang ho `self`, re ke ke ra etsa liphetoho * ka mokhoa o ikhethileng.Mehala ea `same_bucket` e ka ba panic, ka hona re tlameha ho netefatsa hore selae se maemong a nepahetseng ka linako tsohle.
        //
        // Tsela eo re sebetsanang le sena ka eona ke ka ho sebelisa swaps;re ts'oarella holim'a likarolo tsohle, re fapanyetsana ha re ntse re tsamaea hore qetellong likarolo tseo re lakatsang ho li boloka li le ka pele, mme bao re lakatsang ho ba hana ba ka morao.
        // Joale re ka arola selae.
        // Ts'ebetso ena e ntse e le `O(n)`.
        //
        // Mohlala: Re qala seterekeng sena, moo `r` e emelang "latelang
        // bala "mme `w` e emetse" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ha re ipapisa le self[r] khahlanong le uena [w-1], sena ha se lefahla, ka hona re chencha self[r] le self[w] (ha ho na phello e le r==w) ebe re e eketsa r le w, re siea le:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ha re bapisa self[r] le "self-w-1", boleng bona ke lefahla, kahoo re eketsa `r` empa re tlohela ntho e ngoe le e ngoe e sa fetohe:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ho ipapisa le self[r] khahlanong le uena [w-1], sena ha se lefahla, ka hona fapanyetsana self[r] le self[w] ebe u tsoela pele r le w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Eseng lefahla, pheta:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Pheta, advance r. End ea selae.Arohane ho w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // POLOKEHO: boemo ba `while` bo tiisa `next_read` le `next_write`
        // li ka tlase ho `len`, ka hona li ka hare ho `self`.
        // `prev_ptr_write` e supa ntho e le 'ngoe pele ho `ptr_write`, empa `next_write` e qala ka 1, ka hona `prev_ptr_write` ha e tlase ho 0 mme e kahare ho selae.
        // Sena se phethahatsa litlhoko tsa ho hlakola `ptr_read`, `prev_ptr_write` le `ptr_write`, le bakeng sa ho sebelisa `ptr.add(next_read)`, `ptr.add(next_write - 1)` le `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` e eketsoa hangata hang ka kotloloho ho bolelang hore ha ho na ntho e tlosoang ha ho ka hlokahala hore e fuoe.
        //
        // `ptr_read` mme `prev_ptr_write` ha ho mohla e supang ntho e tšoanang.Sena sea hlokahala hore `&mut *ptr_read`, `&mut* prev_ptr_write` e bolokehe.
        // Tlhaloso e mpa e le hore `next_read >= next_write` e lula e le 'nete, ka hona `next_read > next_write - 1` le eona e joalo.
        //
        //
        //
        //
        //
        unsafe {
            // Qoba licheke tsa meeli ka ho sebelisa litsupa tse tala.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// E tsamaisa tsohle ntle le tsa pele tsa likarolo tse latellanang ho fihlela qetellong ea selae se ikemiselitseng ho senotlolo se le seng.
    ///
    ///
    /// E khutlisa likarolo tse peli.Ea pele ha e na likarolo tse phetoang tse phetoang.
    /// Ea bobeli e na le likopi tse fapaneng ka tatellano e boletsoeng.
    ///
    /// Haeba selae se hlophiloe, selae sa pele se khutlisitsoeng ha se na likopi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// E fetola selae sebakeng sa eona hoo likarolo tsa pele tsa `mid` tsa selae li tsamaeang ho fihlela qetellong ha likarolo tsa ho qetela tsa `self.len() - mid` li fetela ka pele.
    /// Kamora ho letsetsa `rotate_left`, elemente pejana ho index `mid` e tla fetoha ntho ea pele selae.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla panic haeba `mid` e kholo ho feta bolelele ba selae.Hlokomela hore `mid == self.len()` e etsa _not_ panic ebile ke chenchana e sa sebetseng.
    ///
    /// # Complexity
    ///
    /// E nka linear (ka `self.len()`) nako.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Ho potoloha subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // TSHIRELETSO: Lebaka la `[p.add(mid) - mid, p.add(mid) + k)` ha le na thuso
        // e nepahetse bakeng sa ho bala le ho ngola, joalo ka ha ho hlokoa ke `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// E fetola selae sebakeng sa eona hoo likarolo tsa pele tsa `self.len() - k` tsa selae li tsamaeang ho fihlela qetellong ha likarolo tsa ho qetela tsa `k` li fetela ka pele.
    /// Kamora ho letsetsa `rotate_right`, elemente pejana ho index `self.len() - k` e tla fetoha ntho ea pele selae.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla panic haeba `k` e kholo ho feta bolelele ba selae.Hlokomela hore `k == self.len()` e etsa _not_ panic ebile ke chenchana e sa sebetseng.
    ///
    /// # Complexity
    ///
    /// E nka linear (ka `self.len()`) nako.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Fetola selotho:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // TSHIRELETSO: Lebaka la `[p.add(mid) - mid, p.add(mid) + k)` ha le na thuso
        // e nepahetse bakeng sa ho bala le ho ngola, joalo ka ha ho hlokoa ke `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// E tlatsa `self` ka likarolo ka ho kopanya `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// E tlatsa `self` ka likarolo tse khutlisitsoeng ka ho bitsa ho koaloa khafetsa.
    ///
    /// Mokhoa ona o sebelisa ho koala ho theha litekanyetso tse ncha.Haeba u khetha [`Clone`] boleng bo fanoeng, sebelisa [`fill`].
    /// Haeba u batla ho sebelisa [`Default`] trait ho hlahisa boleng, u ka fetisa [`Default::default`] e le khang.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// E kopitsa likarolo tsa `src` ho `self`.
    ///
    /// Bolelele ba `src` bo tlameha ho tšoana le `self`.
    ///
    /// Haeba `T` e sebelisa `Copy`, e ka sebetsa hantle ho feta [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla ba panic haeba likhae tse peli li na le bolelele bo fapaneng.
    ///
    /// # Examples
    ///
    /// Ho kopanya likarolo tse peli ho tloha selae ho ea ho se seng:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Hobane likhae li tlameha ho lekana ka bolelele, re arola selae sa mohloli ho tloha ho likarolo tse 'ne ho isa ho tse peli.
    /// // E tla ba panic haeba re sa etse sena.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust e tiisa hore ho ka ba le ts'upiso e le 'ngoe feela e ka fetoloang ntle le litšupiso tse sa fetoheng karolong e itseng ea data maemong a itseng.
    /// Ka lebaka la sena, ho leka ho sebelisa `clone_from_slice` selae se le seng ho tla baka ho hloleha ho bokella:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ho sebetsana le sena, re ka sebelisa [`split_at_mut`] ho etsa likhechana tse peli tse arohaneng ho selae:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// E kopitsa likarolo tsohle ho tloha `src` ho ea `self`, u sebelisa memcpy.
    ///
    /// Bolelele ba `src` bo tlameha ho tšoana le `self`.
    ///
    /// Haeba `T` e sa sebelise `Copy`, sebelisa [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla ba panic haeba likhae tse peli li na le bolelele bo fapaneng.
    ///
    /// # Examples
    ///
    /// Ho etsisa likarolo tse peli ho tloha selae ho ea ho se seng:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Hobane likhae li tlameha ho lekana ka bolelele, re arola selae sa mohloli ho tloha ho likarolo tse 'ne ho isa ho tse peli.
    /// // E tla ba panic haeba re sa etse sena.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust e tiisa hore ho ka ba le ts'upiso e le 'ngoe feela e ka fetoloang ntle le litšupiso tse sa fetoheng karolong e itseng ea data maemong a itseng.
    /// Ka lebaka la sena, ho leka ho sebelisa `copy_from_slice` selae se le seng ho tla baka ho hloleha ho bokella:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ho sebetsana le sena, re ka sebelisa [`split_at_mut`] ho etsa likhechana tse peli tse arohaneng ho selae:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Tsela ea khoutu ea panic e kentsoe tšebetsong e batang hore e se ke ea thibela sebaka sa mehala.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // POLOKEHO: `self` e sebetsa bakeng sa likarolo tsa `self.len()` ka tlhaloso, 'me `src` e ne e le joalo
        // hlahloba ho ba le bolelele bo lekanang.
        // Lilae ha li khone ho kopana hobane litšupiso tse ka feto-fetohang ha li khethehe.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// E kopitsa likarolo ho tloha karolong e 'ngoe ea selae ho ea karolong e' ngoe ea eona, e sebelisa memmove.
    ///
    /// `src` ke moeli o ka hare ho `self` oo u ka o kopitsang ho oona.
    /// `dest` ke index e qalang ea bohare bo ka hare ho `self` ho e kopitsa, e tla ba le bolelele bo lekanang le `src`.
    /// Likarolo tse peli li ka kopana.
    /// Lipheletsong tsa mekhahlelo e 'meli li tlameha ho ba tlase ho kapa ho lekana le `self.len()`.
    ///
    /// # Panics
    ///
    /// Mosebetsi ona o tla ba panic haeba mefuta e fapaneng e feta pheletso ea selae, kapa haeba pheletso ea `src` e le pele ho qalo.
    ///
    ///
    /// # Examples
    ///
    /// Ho kopitsa li-byte tse 'nè ka selae:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // TSHIRELETSO: maemo a `ptr::copy` kaofela a se a hlahlobilwe kaholimo,
        // joalo ka tsa `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// E fetola likarolo tsohle tsa `self` le tse ho `other`.
    ///
    /// Bolelele ba `other` bo tlameha ho tšoana le `self`.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla ba panic haeba likhae tse peli li na le bolelele bo fapaneng.
    ///
    /// # Example
    ///
    /// Ho sesa likarolo tse peli ka lilae:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust e tiisa hore ho ka ba le ts'upiso e le 'ngoe feela e ka fetoloang karolong e itseng ea data maemong a itseng.
    ///
    /// Ka lebaka la sena, ho leka ho sebelisa `swap_with_slice` selae se le seng ho tla baka ho hloleha ho bokella:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ho sebetsana le sena, re ka sebelisa [`split_at_mut`] ho etsa likaroloana tse peli tse arohaneng tse ka feto-fetohang selae:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // POLOKEHO: `self` e sebetsa bakeng sa likarolo tsa `self.len()` ka tlhaloso, 'me `src` e ne e le joalo
        // hlahloba ho ba le bolelele bo lekanang.
        // Lilae ha li khone ho kopana hobane litšupiso tse ka feto-fetohang ha li khethehe.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Mosebetsi oa ho bala bolelele ba selae se bohareng le se morao bakeng sa `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Seo re tla se etsa ka `rest` ke ho tseba hore na ke li ``U` tse kae tseo re ka li kenyang palo e tlase ka ho fetisisa ea `T`s.
        //
        // Mme re hloka li-T tse kae bakeng sa "multiple" ka 'ngoe.
        //
        // Nahana ka mohlala T=u8 U=u16.Ebe joale re ka beha 1 U ho 2 Ts.E bonolo.
        // Joale, nahana ka mohlala nyeoe moo size_of: :<T>=16, size_of::<U>=24.</u>
        // Re ka beha 2 Us sebakeng sa 3 Ts e ngoe le e ngoe selae sa `rest`.
        // Ho thata le ho feta.
        //
        // Foromo ea ho bala sena ke:
        //
        // Rona= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // E atolositsoe ebile e nolofalitsoe:
        //
        // Rona=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) =kholo_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Ka lehlohonolo kaha sena sohle se hlahlojoa khafetsa ... ts'ebetso mona ha e na taba!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterative stein's algorithm Re ntse re lokela ho etsa `const fn` ena (le ho khutlela ho algorithm e iphetang haeba re e etsa) hobane ho itšetleha ka llvm ho tiisa sena sohle ke…hantle, ho etsa hore ke se phutholohe.
            //
            //

            // TSHIRELETSO: `a` le `b` di lekolwa hore ke boleng bo seng ba zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // tlosa lintlha tsohle tsa 2 ho b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // POLOKEHO: `b` e hlahlojoa hore ha e lefifi.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Re hlometse ka tsebo ena, re ka fumana hore na ke li `U`s tse kae tseo re ka li lekanang!
        let us_len = self.len() / ts * us;
        // 'Me li T`s tse ngata li tla ba teng selae se latelang!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Fetisetsa selae ho selae sa mofuta o mong, ho netefatsa hore mefuta ea mefuta e ea bolokeha.
    ///
    /// Mokhoa ona o arola selae ka likotoana tse tharo tse arohaneng: sehlongwapele, selae se bohareng se hokahantsoeng ka nepo sa mofuta o mocha, le selae sa suffix.
    /// Mokhoa ona o ka etsa hore selae se bohareng se be bolelele bo boholo ho mofuta o fanoeng le selae sa ho kenya, empa ts'ebetso ea algorithm ea hau e lokela ho itšetleha ka seo, eseng ho nepahala ha eona.
    ///
    /// Ho lumelloa hore data eohle ea ho kenya e khutlisoe e le sehlongwapele kapa sekhechana sa suffix.
    ///
    /// Mokhoa ona ha o na morero ha karolo ea `T` kapa tlhahiso ea `U` e le boholo ba zero mme e tla khutlisa selae sa mantlha ntle le ho arola letho.
    ///
    /// # Safety
    ///
    /// Mokhoa ona ha e le hantle ke `transmute` mabapi le likarolo tsa selae se bohareng se khutlisitsoeng, ka hona litemoso tsohle tse tloaelehileng tse amanang le `transmute::<T, U>` le tsona lia sebetsa mona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Hlokomela hore boholo ba ts'ebetso ena bo tla hlahlojoa khafetsa,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // sebetsana le li-ZST ka ho khetheha, e leng-u se ke oa li sebetsana ho hang.
            return (self, &[], &[]);
        }

        // Taba ea mantlha, fumana hore na ke moo re arohaneng pakeng tsa selae sa pele le sa bobeli.
        // Ho bonolo ka ptr.align_offset.
        let ptr = self.as_ptr();
        // POLOKEHO: Bona mokhoa oa `align_to_mut` bakeng sa maikutlo a qaqileng mabapi le polokeho.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // TSHIRELETSO: ha jwale `rest` e matahane, ka hona `from_raw_parts` e ka tlase e lokile,
            // kaha moletsi o tiisa hore re ka fetisa `T` ho ea ho `U` re bolokehile.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Fetisetsa selae ho selae sa mofuta o mong, ho netefatsa hore mefuta ea mefuta e ea bolokeha.
    ///
    /// Mokhoa ona o arola selae ka likotoana tse tharo tse arohaneng: sehlongwapele, selae se bohareng se hokahantsoeng ka nepo sa mofuta o mocha, le selae sa suffix.
    /// Mokhoa ona o ka etsa hore selae se bohareng se be bolelele bo boholo ho mofuta o fanoeng le selae sa ho kenya, empa ts'ebetso ea algorithm ea hau e lokela ho itšetleha ka seo, eseng ho nepahala ha eona.
    ///
    /// Ho lumelloa hore data eohle ea ho kenya e khutlisoe e le sehlongwapele kapa sekhechana sa suffix.
    ///
    /// Mokhoa ona ha o na morero ha karolo ea `T` kapa tlhahiso ea `U` e le boholo ba zero mme e tla khutlisa selae sa mantlha ntle le ho arola letho.
    ///
    /// # Safety
    ///
    /// Mokhoa ona ha e le hantle ke `transmute` mabapi le likarolo tsa selae se bohareng se khutlisitsoeng, ka hona litemoso tsohle tse tloaelehileng tse amanang le `transmute::<T, U>` le tsona lia sebetsa mona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Hlokomela hore boholo ba ts'ebetso ena bo tla hlahlojoa khafetsa,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // sebetsana le li-ZST ka ho khetheha, e leng-u se ke oa li sebetsana ho hang.
            return (self, &mut [], &mut []);
        }

        // Taba ea mantlha, fumana hore na ke moo re arohaneng pakeng tsa selae sa pele le sa bobeli.
        // Ho bonolo ka ptr.align_offset.
        let ptr = self.as_ptr();
        // TSHIRELETSO: Mona re netefatsa hore re tla sebedisa matshwao a tsamaellanang bakeng sa U bakeng sa
        // mokhoa o setseng.Sena se etsoa ka ho fetisetsa sesupa ho&[T] ka tatellano e etselitsoeng U.
        // `crate::ptr::align_offset` e bitsoa ka sesupa-tsela se hokahantsoeng ka nepo le se nepahetseng `ptr` (e tsoa bukeng ea `self`) mme e na le boholo bo nang le matla a mabeli (kaha e tsoa ho tatellano ea U), e khotsofatsa lithibelo tsa eona tsa polokeho.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Re ke ke ra sebelisa `rest` hape kamora mona, e ka etsang hore lebitso la eona la `mut_ptr` le se sebetse!TŠIRELETSO: bona litlhaloso bakeng sa `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// E hlahloba haeba likarolo tsa selae sena li hlophisitsoe.
    ///
    /// Ka mantsoe a mang, bakeng sa elemente e ngoe le e ngoe `a` le karolo ea eona e latelang `b`, `a <= b` e tlameha ho ts'oara.Haeba selae se hlahisa zero hantle kapa ntho e le 'ngoe, `true` ea khutlisoa.
    ///
    /// Hlokomela hore haeba `Self::Item` e le `PartialOrd` feela, empa e se `Ord`, tlhaloso e kaholimo e bolela hore ts'ebetso ena e khutlisa `false` haeba ho na le lintho tse peli tse latellanang tse sa bapisoang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// E hlahloba haeba likarolo tsa selae sena li hlophisitsoe ho sebelisoa mosebetsi o fanoeng oa papiso.
    ///
    /// Sebakeng sa ho sebelisa `PartialOrd::partial_cmp`, ts'ebetso ena e sebelisa ts'ebetso e fanoeng ea `compare` ho fumana tlhophiso ea likarolo tse peli.
    /// Ntle le moo, e lekana le [`is_sorted`];bona litokomane tsa eona bakeng sa tlhaiso-leseling e batsi.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// E hlahloba haeba likarolo tsa selae sena li hlophisitsoe ho sebelisoa ts'ebetso ea senotlolo e fanoeng.
    ///
    /// Sebakeng sa ho bapisa likarolo tsa selae ka kotloloho, mosebetsi ona o bapisa linotlolo tsa likarolo, joalo ka ha ho khethiloe ke `f`.
    /// Ntle le moo, e lekana le [`is_sorted`];bona litokomane tsa eona bakeng sa tlhaiso-leseling e batsi.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// E khutlisa index ea ntlha ea karohano ho latela se boletsoeng (index ea elemente ea pele ea karohano ea bobeli).
    ///
    /// Selae se nahanoa hore se tla aroloa ho latela se boletsoeng.
    /// Sena se bolela hore likarolo tsohle tseo moemeli a khutlelang ho tsona ke qalong ea selae mme likarolo tsohle tseo moemeli a khutlelang bohata ho tsona ke qetellong.
    ///
    /// Mohlala, [7, 15, 3, 5, 4, 12, 6] e arotsoe ka tlasa moemeli x% 2!=0 (linomoro tsohle tse makatsang li qalong, kaofela esita le qetellong).
    ///
    /// Haeba selae sena se sa aroloa, sephetho se khutlisitsoeng ha se tsejoe ebile ha se na moelelo, kaha mokhoa ona o etsa mofuta oa patlo ea binary.
    ///
    /// Bona hape [`binary_search`], [`binary_search_by`], le [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // TSHIRELETSO: Ha `left < right`, `left <= mid < right`.
            // Ka hona `left` e lula e eketseha 'me `right` e lula e fokotseha,' me e 'ngoe ea tsona e khethiloe.Maemong ka bobeli `left <= right` e khotsofetse.Ka hona haeba `left < right` mohatong, `left <= right` e khotsofetse mohatong o latelang.
            //
            // Ka hona ha feela `left != right`, `0 <= left < right <= len` e khotsofetse mme haeba nyeoe ena `0 <= mid < len` le eona e khotsofetse.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Re hloka ho li arola ka mokhoa o hlakileng ka bolelele bo lekanang
        // ho etsa hore ho be bonolo bakeng sa sebatli se ntlafatsang ho hlahloba meeli.
        // Empa kaha e ke ke ea tšeptjoa re boetse re na le tsebo e hlakileng ea T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// E theha selae se se nang letho.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// E theha selae se se nang letho se ka fetoloang.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Mefuta ea likarolo, hajoale, e sebelisoa feela ke `strip_prefix` le `strip_suffix`.
/// Sebakeng sa future, re ts'epa ho etsa `core::str::Pattern` (eo ka nako ea ho ngola e lekanyelitsoeng ho `str`) ho likotoana, ebe trait ena e tla nkeloa sebaka kapa e felisoe.
///
pub trait SlicePattern {
    /// Mofuta oa karolo ea selae se bapisoang.
    type Item;

    /// Hajoale, bareki ba `SlicePattern` ba hloka selae.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}