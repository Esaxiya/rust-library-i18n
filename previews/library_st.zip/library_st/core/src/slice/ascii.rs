//! Ts'ebetso ho ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// E hlahloba hore na li-byte tsohle tsa selae sena li kahara lehare la ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ho hlahlojoa hore na likhae tse peli ke papali e sa tsotelleng ea ASCII.
    ///
    /// E ts'oana le `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, empa e sa arole le ho kopitsa litempele.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// E fetola selae sena hore se be boemong ba sona ba boemo bo holimo ba ASCII.
    ///
    /// Litlhaku tsa ASCII 'a' ho 'z' li ngotsoe ho 'A' ho 'Z', empa litlhaku tseo e seng tsa ASCII ha lia fetoha.
    ///
    /// Ho khutlisa boleng bo bocha bo phahameng ntle le ho fetola e teng, sebelisa [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// E fetolela selae sena ho ea ho ASCII ea eona e maemong a tlase.
    ///
    /// Litlhaku tsa ASCII 'A' ho 'Z' li ngotsoe ho 'a' ho 'z', empa litlhaku tseo e seng tsa ASCII ha lia fetoha.
    ///
    /// Ho khutlisa boleng bo bocha bo tlase ntle le ho fetola e teng, sebelisa [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// E khutlisa `true` haeba ho na le byte ka lentsoe `v` ke nonascii (>=128).
/// Snarfed ho tloha `../str/mod.rs`, e etsang ntho e ts'oanang le netefatso ea utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Teko e ntlafalitsoeng ea ASCII e tla sebelisa ts'ebeliso ea at-a-a-time ho fapana le ts'ebetso ea byte-at-a-time (ha ho khonahala).
///
/// Algorithm eo re e sebelisang mona e bonolo haholo.Haeba `s` e khuts'oane haholo, re sheba feela e 'ngoe le e' ngoe ebe rea e qeta.Ho seng joalo:
///
/// - Bala lentsoe la pele ka mojaro o sa lekanyetsoang.
/// - Lumella sesupa-bala, bala mantsoe a latelang ho fihlela qetellong ka mejaro e tsamaellaneng.
/// - Bala `usize` ea ho qetela ho tloha `s` ka mojaro o sa lekanyetsoang.
///
/// Haeba efe kapa efe ea mejaro ena e hlahisa ho hong hoo `contains_nonascii` (above) e khutlelang e le 'nete, re tla tseba hore karabo ke leshano.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Haeba re ne re ke ke ra fumana letho ho tsoa ts'ebetsong ea lentsoe-ka-nako, re khutlela mokokotlong oa scalar.
    //
    // Re boetse re etsa sena bakeng sa meralo ea kaho moo `size_of::<usize>()` e sa lumellaneng hantle le `usize`, hobane ke nyeoe e makatsang ea edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Re lula re bala lentsoe la pele unaligned, ho bolelang hore `align_offset` ke
    // 0, re ka bala boleng bo tšoanang hape bakeng sa ho tsamaisoa ho tsamaisitsoe.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // POLOKEHO: Re netefatsa `len < USIZE_SIZE` kaholimo.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Re hlahlobile sena kaholimo, ka mokhoa o hlakileng.
    // Hlokomela hore `offset_to_aligned` ke `align_offset` kapa `USIZE_SIZE`, ka bobeli li hlahlobiloe kaholimo kaholimo.
    //
    debug_assert!(offset_to_aligned <= len);

    // TŠIRELETSO: word_ptr ke (e hokahane hantle) usize ptr eo re e sebelisang ho bala
    // sekoto se bohareng sa selae.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ke index ea byte ea `word_ptr`, e sebelisetsoang ho hlahloba lupu end.
    let mut byte_pos = offset_to_aligned;

    // Ho hlahloba paranoia mabapi le tatellano, hobane re mothating oa ho etsa meroalo e mengata e sa lumellaneng.
    // Ka ts'ebetso ena ha hoa lokela ho thibela kokoanyana ho `align_offset` leha ho le joalo.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Bala mantsoe a latelang ho fihlela lentsoe le hokahantsoeng la hoqetela, ho sa kenyeletsoe lentsoe la ho hokahanya la hoqetela le lokelang ho etsoa mohatong oa mohatla hamorao, ho netefatsa hore mohatla o lula o le `usize` haholo ho feta branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Hlahloba boits'oaro hore na 'mali o meeling
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Le hore likhopolo tsa rona mabapi le `byte_pos` lia tšoarella.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // TSHIRELETSO: Re a tseba `word_ptr` e matahantswe hantle (ka lebaka la
        // `align_offset`), 'me rea tseba hore re na le li-byte tse lekaneng lipakeng tsa `word_ptr` le qetellong
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // TSHIRELETSO: Re tseba `byte_pos <= len - USIZE_SIZE` eo, ho bolelang hore
        // kamora `add` ena, `word_ptr` e tla ba haholo-holo ho feta.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ho hlahloba bohloeki ho netefatsa hore ho setse `usize` e le 'ngoe feela.
    // Sena se lokela ho netefatsoa ke boemo ba rona ba lupu.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // TSHIRELETSO: Sena se itshetlehile ka `len >= USIZE_SIZE`, eo re e hlahlobang qalong.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}