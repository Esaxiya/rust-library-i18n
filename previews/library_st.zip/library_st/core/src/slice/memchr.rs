// Ts'ebetso ea mantlha e nkuoeng ho rust-memchr.
// Copyright 2015 Andrew Gallant, bluss le Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Sebelisa truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// E khutlisa `true` haeba `x` e na le zero byte.
///
/// Ho tsoa ho *Litaba tsa Khomphutha*, J. Arndt:
///
/// "Morero ke ho tlosa e le 'ngoe ea li-byte ebe re batla li-byte moo mokoloto a phatlalalitseng ho ea fihla ho ea bohlokoa ka ho fetesisa
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// E khutlisa index ea pele e ts'oanang le byte `x` ho `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Tsela e potlakileng ea likhae tse nyane
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Batla boleng bo le bong ka ho bala mantsoe a mabeli a `usize` ka nako.
    //
    // Arola `text` ka likarolo tse tharo
    // - karolo e sa lekanyetsoang ea pele, pele ho aterese e lumellanang le lentsoe pele
    // - 'mele, scan ka mantsoe a mabeli ka nako
    // - karolo ea ho qetela e setseng, <2 size size

    // batla ho fihlela moeli o tsamaellaneng
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // batla mmele wa sengolwa
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // TSHIRELETSO: leemedi la hajwale le netefatsa sebaka sa bonyane 2 * usize_byte
        // lipakeng tsa offset le pheletso ea selae.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // roba haeba ho na le byte e tšoanang
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Fumana sekhahla ka mor'a ntlha eo lupu ea 'mele e emeng ka eona.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// E khutlisa index ea ho qetela e tsamaellanang le byte `x` ho `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Batla boleng bo le bong ka ho bala mantsoe a mabeli a `usize` ka nako.
    //
    // Arola `text` ka likarolo tse tharo:
    // - mohatla o sa lekanyetsoang, ka mor'a aterese ea ho qetela e lumellanang le mantsoe,
    // - 'mele, e hlahlojoe ke mantsoe a 2 ka nako,
    // - li-byte tsa pele tse setseng, <2 size size.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Re bitsa sena ho fumana bolelele ba sehlongwapele le sehlongwapele.
        // Bohareng re lula re sebetsana le likarolo tse peli ka nako e le ngoe.
        // TSHIRELETSO: ho fetisa `[u8]` ho ya ho `[usize]` ho bolokehile ntle le diphapang tsa boholo tse sebetswang ke `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Batla 'mele oa mongolo, etsa bonnete ba hore ha re tšele min_aligned_offset.
    // Offset e lula e hokahane, ka hona, ho lekola `>` ho lekane ebile ho qoba ho khaphatseha ho ka bang teng.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // TSHIRELETSO: offset e qala ka len, suffix.len(), ha feela e le kholo ho feta
        // min_aligned_offset (prefix.len()) sebaka se setseng bonyane 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Roba haeba ho na le "byte" e tsamaellanang.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Fumana sekhahla pele ntlha e fihla.
    text[..offset].iter().rposition(|elt| *elt == x)
}