#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Lisebelisoa li amana le likhokahano tsa (FFI) tsa kantle ho naha.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// E lekana le mofuta oa C's `void` ha e sebelisoa e le [pointer].
///
/// Ha e le hantle, `*const c_void` e lekana le C's `const void*` mme `*mut c_void` e lekana le C's `void*`.
/// Seo se boletse, sena ha se * ts'oane le mofuta oa C's `void` oa ho khutla, e leng mofuta oa Rust oa `()`.
///
/// Ho etsa lits'oants'o tsa mefuta ea opaque ho FFI, ho fihlela `extern type` e tsitsitse, ho kgothaletswa ho sebelisa sekoaelo sa newtype ho potoloha lethathamo le se nang letho la byte.
///
/// Bona [Nomicon] bakeng sa lintlha.
///
/// Motho a ka sebelisa `std::os::raw::c_void` haeba ba batla ho ts'ehetsa komporo ea khale ea Rust ho fihlela 1.1.0.
/// Kamora Rust 1.30.0, e ile ea romeloa kantle ho naha hape ke tlhaloso ena.
/// Bakeng sa tlhaiso-leseling e batsi, ka kopo bala [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, bakeng sa LLVM ho amohela mofuta oa pointer o se nang letho le ka mesebetsi ea katoloso joalo ka malloc(), re hloka hore e emeloe joalo ka i8 * ho bitcode ea LLVM.
// Enum e sebelisitsoeng mona e netefatsa sena mme e thibela tšebeliso e mpe ea mofuta oa "raw" ka ho ba le mefuta e fapaneng ea lekunutu.
// Re hloka mefuta e 'meli, hobane moqapi o tletleba ka tšobotsi ea repr ho seng joalo mme re hloka bonyane phapang e le' ngoe kaha ho seng joalo enum e ne e ke ke ea lula batho mme bonyane ho hlakola lits'oants'o tse joalo e ka ba UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Ts'ebetso ea mantlha ea `va_list`.
// Lebitso ke WIP, o sebelisa `VaListImpl` hajoale.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // E sa fetoheng ho feta `'f`, ka hona ntho e ngoe le e ngoe ea `VaListImpl<'f>` e tlameletsoe sebakeng sa ts'ebetso eo e hlalositsoeng ho eona
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Ts'ebetso ea ABI ea `va_list`.
/// Bona [AArch64 Procedure Call Standard] bakeng sa lintlha tse ling.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Ts'ebetso ea ABI ea `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Ts'ebetso ea ABI ea `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Sekoahelo sa `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Fetolela `VaListImpl` hore e be `VaList` e tsamaellanang le binary le C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Fetolela `VaListImpl` hore e be `VaList` e tsamaellanang le binary le C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait e hloka ho sebelisoa libakeng tsa sechaba, leha ho le joalo, trait ka boeona ha ea lokela ho lumelloa ho sebelisoa kantle ho module ena.
// Ho lumella basebelisi ho kenya ts'ebetsong trait bakeng sa mofuta o mocha (ka hona ho lumella va_arg intrinsic ho sebelisoa mofuteng o mocha) ho kanna ha baka boits'oaro bo sa hlaloseheng.
//
// FIXME(dlrobertson): Bakeng sa ho sebelisa VaArgSafe trait khokahanong ea sechaba empa hape le ho netefatsa hore e ke ke ea sebelisoa kae kapa kae, trait e hloka ho ba sechabeng ka har'a module ea poraefete.
// Hang ha RFC 2145 e kentsoe tšebetsong sheba ho e ntlafatsa.
//
//
//
//
mod sealed_trait {
    /// Trait e lumellang mefuta e lumelletsoeng ho sebelisoa le [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tsoela pele ho arg e latelang.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `va_arg`.
        unsafe { va_arg(self) }
    }

    /// E kopitsa `va_list` sebakeng sa hona joale.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // TSHIRELETSO: re ngolla `MaybeUninit`, ka hona ea qalwa mme `assume_init` e molaong
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: sena se lokela ho letsetsa `va_end`, empa ha ho na mokhoa o hloekileng oa ho
        // netefatsa hore `drop` e lula e kenella ho motho ea e letsitseng, kahoo `va_end` e tla bitsoa ka kotloloho ho tsoa ts'ebetsong e ts'oanang le `va_copy` e tsamaellanang.
        // `man va_end` e re C e hloka sena, mme LLVM ha e le hantle e latela semantiki ea C, ka hona re hloka ho etsa bonnete ba hore `va_end` e lula e bitsoa ho tsoa ts'ebetsong e ts'oanang le `va_copy`.
        //
        // Bakeng sa lintlha tse ling, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Sena se sebetsa hajoale, kaha `va_end` ha e sebetse ho liphofu tsohle tsa LLVM tsa hajoale.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Senya arglist `ap` kamora ho qala ka `va_start` kapa `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// E kopitsa sebaka sa hajoale sa arglist `src` ho arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// E jara ngangisano ea mofuta `T` ho tloha ho `va_list` `ap` mme e eketsa khang ea `ap` ho isa ho.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}