use crate::{iter::FusedIterator, ops::Try};

/// Iterator e pheta ka ho sa feleng.
///
/// `struct` ena e entsoe ka mokhoa oa [`cycle`] ho [`Iterator`].
/// Bona litokomane tsa eona bakeng sa tse ling.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // iterator ea potoloho ha e na letho kapa ha e na moeli
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // pheta ka botlalo seterator sa hajoale.
        // sena sea hlokahala hobane `self.iter` e kanna ea se na letho le ha `self.orig` e se joalo
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // phethela potoloho e felletseng, o boloka tlaleho ea hore na iterator ea baesekele ha e na letho kapa che.
        // re hloka ho khutla kapele haeba ho na le iterator e se nang letho ho thibela sekhahla se sa feleng
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Ha ho `fold` e fetang, hobane `fold` ha e utloisisehe haholo ka `Cycle`, 'me re ke ke ra etsa letho le betere ho feta la kamehla.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}