use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait ena e fana ka phihlello e fetohang ea sethala sa mohloli ka har'a lipeipi tsa li-adapter tlasa maemo a hore
/// * mohloli oa eona oa iterator `S` ka boeona o kenya ts'ebetsong `SourceIter<Source = S>`
/// * ho na le ts'ebetso ea ho abela ba trait ena bakeng sa adaptara e ngoe le e ngoe e lipeipeng lipakeng tsa mohloli le moreki oa lipeipi.
///
/// Ha mohloli o na le iterator struct (eo hangata e bitsoang `IntoIter`) joale sena se ka ba molemo bakeng sa ho etsa ts'ebetso ea [`FromIterator`] kapa ho hlaphoheloa likarolo tse setseng kamora hore iterator e felletsoe ke karoloana.
///
///
/// Hlokomela hore ts'ebetsong ha ea tlameha ho fana ka phihlello mohloling o kahare-hare oa pompo.Adapter e bohareng e bohareng e kanna ea lekola karolo ea phaephe ka cheseho mme ea pepesa polokelo ea eona ea kahare e le mohloli.
///
/// trait ha e bolokehe hobane baphethahatsi ba tlameha ho boloka litšobotsi tse ling tsa polokeho.
/// Bona [`as_inner`] bakeng sa lintlha.
///
/// # Examples
///
/// Ho fumana mohloli o sebelisitsoeng hanyane:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Sethala sa mohloli ka har'a lipeipi tsa iterator.
    type Source: Iterator;

    /// Khutlisa mohloli oa lipeipi tsa iterator.
    ///
    /// # Safety
    ///
    /// Ts'ebetsong ea eona e tlameha ho khutlisa ts'upiso e tšoanang e ka feto-fetohang bophelong bohle ba bona, ntle le haeba e nkuoe ke moletsi.
    /// Batho ba letsetsang ba ka nka sebaka sa litšupiso ha ba emisa ho pheta-pheta ebe ba lahla lipeipi tsa iterator kamora ho ntša mohloli.
    ///
    /// Sena se bolela hore li-adapter tsa iterator li ka ts'epa mohloli o sa fetoheng nakong ea phepelo empa ba ke ke ba o ts'epa ts'ebetsong ea bona ea Drop.
    ///
    /// Ho kenya tšebetsong mokhoa ona ho bolela li-adapters tse tlohelang phihlello ea lekunutu feela mohloling oa tsona mme li ka itšetleha feela ka li-guaranteed tse entsoeng ho ipapisitsoe le mefuta ea liamoheli.
    /// Khaello ea phihlello e thibetsoeng e boetse e hloka hore li-adapters li tlameha ho tšehetsa API ea sechaba ea mohloli leha ba na le phihlello ho basebetsi ba eona.
    ///
    /// Batho ba letsitseng le bona ba tlameha ho lebella hore mohloli o tla ba maemong afe kapa afe a lumellanang le API ea ona ea sechaba hobane li-adapters tse lutseng pakeng tsa eona le mohloli li na le phihlello e tšoanang.
    /// Haholo-holo adapta e kanna ea ja likarolo tse ngata ho feta ka moo ho hlokahalang.
    ///
    /// Morero oa litlhoko tsena ke ho tlohella moreki hore a sebelise lipeipi
    /// * eng kapa eng e setseng mohloling kamora hore phetiso e emise
    /// * mohopolo o seng o sa sebelisoe ka ho nts'etsapele sehlahlo se jang
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adapter adapter e hlahisang sehlahisoa ha feela mochini o ka sehloohong o hlahisa boleng ba `Result::Ok`.
///
///
/// Haeba ho na le phoso, iterator ea emisa ebe phoso e ea bolokoa.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Sebetsa iterator e fuoeng joalo ka ha eka e hlahisitse `T` sebakeng sa `Result<T, _>`.
/// Liphoso life kapa life li tla emisa sehlahlo sa kahare mme sephetho ka kakaretso e tla ba phoso.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}