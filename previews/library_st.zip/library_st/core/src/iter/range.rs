use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Lintho tse nang le mohopolo oa ts'ebetso ea *mohlahlami* le *pele ho ts'ebetso*.
///
/// Tshebetso ya *mohlahlami* e leba ho boleng bo bapisang bo boholo.
/// Ts'ebetso ea "pele" e fetela ho boleng bo bapisoang le bonyenyane.
///
/// # Safety
///
/// trait ena ke `unsafe` hobane ts'ebetsong ea eona e tlameha ho nepahala bakeng sa ts'ireletseho ea ts'ebetsong ea `unsafe trait TrustedLen`, 'me liphetho tsa ho sebelisa trait ka tsela e' ngoe li ka tšeptjoa ke khoutu ea `unsafe` hore e nepahale le ho phetha boitlamo bo thathamisitsoeng.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// E khutlisa palo ea *mohlahlami* mehato e hlokahalang ho tloha `start` ho ea `end`.
    ///
    /// E khutlisa `None` haeba palo ea mehato e ka phalla `usize` (kapa ha e na moeli, kapa haeba `end` e ne e ke ke ea fihlelleha).
    ///
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a`, `b`, le `n` efe kapa efe:
    ///
    /// * `steps_between(&a, &b) == Some(n)` haeba feela `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` haeba feela `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` ha feela `a <= b`
    ///   * 'Nete: `steps_between(&a, &b) == Some(0)` haeba feela `a == b`
    ///   * Hlokomela hore `a <= b` ha _not_ e bolela `steps_between(&a, &b) != None`;
    ///     ho joalo ha ho tla hloka mehato e fetang `usize::MAX` ho fihla `b`
    /// * `steps_between(&a, &b) == None` haeba `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// E khutlisa boleng bo ka fumanoang ka ho nka *mohlahlami* oa linako tse `self` `count`.
    ///
    /// Haeba sena se ka khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`, e khutlisa `None`.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a`, `n`, le `m` efe kapa efe:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Bakeng sa `a`, `n`, le `m` efe kapa efe moo `n + m` e sa phalleng:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Bakeng sa `a` le `n` efe kapa efe:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// E khutlisa boleng bo ka fumanoang ka ho nka *mohlahlami* oa linako tse `self` `count`.
    ///
    /// Haeba sena se ka khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`, ts'ebetso ena e lumelloa ho panic, ho phuthela, kapa ho tlala.
    ///
    /// Boitšoaro bo khothalelitsoeng ke ho panic ha lipolelo tsa ho etsa phoso li lumelloa, le ho thatela kapa ho khotsofatsa ka tsela e ngoe.
    ///
    /// Khoutu e sa bolokehang ha ea lokela ho itšetleha ka ho nepahala ha boits'oaro kamora ho khaphatseha.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a` efe kapa efe, `n`, le `m`, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Bakeng sa `a` le `n` efe kapa efe, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// E khutlisa boleng bo ka fumanoang ka ho nka *mohlahlami* oa linako tse `self` `count`.
    ///
    /// # Safety
    ///
    /// Ke boits'oaro bo sa hlalosoang ba ts'ebetso ena ho khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`.
    /// Haeba o sa khone ho netefatsa hore sena se ke ke sa phalla, sebelisa `forward` kapa `forward_checked` ho fapana.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a` efe kapa efe:
    ///
    /// * haeba ho na le `b` joalo ka `b > a`, ho bolokehile ho letsetsa `Step::forward_unchecked(a, 1)`
    /// * haeba ho na le `b`, `n` joalo ka `steps_between(&a, &b) == Some(n)`, ho bolokehile ho letsetsa `Step::forward_unchecked(a, m)` bakeng sa `m <= n` efe kapa efe.
    ///
    ///
    /// Bakeng sa `a` le `n` efe kapa efe, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::forward_unchecked(a, n)` e lekana le `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// E khutlisa boleng bo ka fumanoang ka ho nka *pele ho eena* makhetlo a `self` `count`.
    ///
    /// Haeba sena se ka khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`, e khutlisa `None`.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a`, `n`, le `m` efe kapa efe:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Bakeng sa `a` le `n` efe kapa efe:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// E khutlisa boleng bo ka fumanoang ka ho nka *pele ho eena* makhetlo a `self` `count`.
    ///
    /// Haeba sena se ka khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`, ts'ebetso ena e lumelloa ho panic, ho phuthela, kapa ho tlala.
    ///
    /// Boitšoaro bo khothalelitsoeng ke ho panic ha lipolelo tsa ho etsa phoso li lumelloa, le ho thatela kapa ho khotsofatsa ka tsela e ngoe.
    ///
    /// Khoutu e sa bolokehang ha ea lokela ho itšetleha ka ho nepahala ha boits'oaro kamora ho khaphatseha.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a` efe kapa efe, `n`, le `m`, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Bakeng sa `a` le `n` efe kapa efe, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// E khutlisa boleng bo ka fumanoang ka ho nka *pele ho eena* makhetlo a `self` `count`.
    ///
    /// # Safety
    ///
    /// Ke boits'oaro bo sa hlalosoang ba ts'ebetso ena ho khaphatseha mefuta ea litekanyetso tse tšehelitsoeng ke `Self`.
    /// Haeba o sa khone ho netefatsa hore sena se ke ke sa phalla, sebelisa `backward` kapa `backward_checked` ho fapana.
    ///
    /// # Invariants
    ///
    /// Bakeng sa `a` efe kapa efe:
    ///
    /// * haeba ho na le `b` joalo ka `b < a`, ho bolokehile ho letsetsa `Step::backward_unchecked(a, 1)`
    /// * haeba ho na le `b`, `n` joalo ka `steps_between(&b, &a) == Some(n)`, ho bolokehile ho letsetsa `Step::backward_unchecked(a, m)` bakeng sa `m <= n` efe kapa efe.
    ///
    ///
    /// Bakeng sa `a` le `n` efe kapa efe, moo ho sa phalleheng ho hlahang:
    ///
    /// * `Step::backward_unchecked(a, n)` e lekana le `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Tsena li ntse li hlahisoa ka bongata hobane lingoliloeng tse felletseng li rarolla mefuta e fapaneng.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `start + n` ha e phalle.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `start - n` ha e phalle.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Ha litšitiso li aha, qholotsa panic ha e khaphatseha.
            // Sena se lokela ho ntlafatsa ka ho felletseng kahong ea tokollo.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Etsa lipalo tsa ho phuthela ho lumella mohlala `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Ha litšitiso li aha, qholotsa panic ha e khaphatseha.
            // Sena se lokela ho ntlafatsa ka ho felletseng kahong ea tokollo.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Etsa lipalo tsa ho phuthela ho lumella mohlala `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Sena se itšetleha ka $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // haeba n e tsoa hole, `unsigned_start + n` le eona e joalo
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // haeba n e tsoa hole, `unsigned_start - n` le eona e joalo
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Sena se itšetleha ka $i_narrower <=usize
                        //
                        // Ho lahlela ka boholo ho eketsa bophara empa ho boloka lets'oao.
                        // Sebelisa ho phuthela_sub ka sebaka sa isize ebe u se lahlela ho se sebelisa ho lekanya phapang e ka 'nang ea se ke ea lekana kahare ho isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Ho phethela linyeoe tse kang `Step::forward(-120_i8, 200) == Some(80_i8)`, leha 200 e le hole le i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Keketso e ile ea khaphatseha
                            }
                        }
                        // Haeba n e fapane le mohlala
                        // u8, joale e kholo ho feta mefuta eohle ea i8 e pharaletse kahoo `any_i8 + n` e hlile e khaphatseha i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Ho phethela linyeoe tse kang `Step::forward(-120_i8, 200) == Some(80_i8)`, leha 200 e le hole le i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Ho tlosa ho ile ha tlala
                            }
                        }
                        // Haeba n e fapane le mohlala
                        // u8, joale e kholo ho feta mefuta eohle ea i8 e pharaletse kahoo `any_i8 - n` e hlile e khaphatseha i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Haeba phapang e kholo haholo bakeng sa mohlala
                            // i128, e tla ba kholo haholo hore e ka sebelisoa ka likotoana tse fokolang.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // TŠIRELETSO: res ke scalar e sebetsang ea unicode
            // (ka tlase 0x110000 eseng ho 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // TŠIRELETSO: res ke scalar e sebetsang ea unicode
        // (ka tlase 0x110000 eseng ho 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore sena ha se phalle
        // mefuta ea litekanyetso tsa char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // TSHIRELETSO: moletsi o tlameha ho netefatsa hore sena ha se phalle
            // mefuta ea litekanyetso tsa char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // TSHIRELETSO: ka lebaka la konteraka e fetileng, sena se netefaditswe
        // ka moletsi ho ba char e nepahetseng.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore sena ha se phalle
        // mefuta ea litekanyetso tsa char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // TSHIRELETSO: moletsi o tlameha ho netefatsa hore sena ha se phalle
            // mefuta ea litekanyetso tsa char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // TSHIRELETSO: ka lebaka la konteraka e fetileng, sena se netefaditswe
        // ka moletsi ho ba char e nepahetseng.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Li-macro tsena li hlahisa li-impl tsa `ExactSizeIterator` bakeng sa mefuta e fapaneng ea mefuta.
//
// * `ExactSizeIterator::len` ho hlokahala hore o khutlise `usize` kamehla, ka hona ha ho na mefuta e ka ba telele ho feta `usize::MAX`.
//
// * Bakeng sa mefuta e felletseng ea `Range<_>` ho joalo bakeng sa mefuta e fokolang ho feta kapa e pharalletseng joaloka `usize`.
//   Bakeng sa mefuta e felletseng ea `RangeInclusive<_>` ho joalo bakeng sa mefuta * e patisane haholo ho feta `usize` ho tloha ka mohlala
//   `(0..=u64::MAX).len()` e ka ba `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Tsena ha lia nepahala ho latela monahano o kaholimo, empa ho li tlosa e ka ba phetoho e kholo ha li ntse li tsitsisoa ho Rust 1.0.0.
    // Kahoo, mohlala
    // `(0..66_000_u32).len()` mohlala e tla bokella ntle le phoso kapa litemoso ho li-platform tsa 16-bit, empa u tsoele pele ho fana ka sephetho se fosahetseng.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Tsena ha lia nepahala ho latela monahano o kaholimo, empa ho li tlosa e ka ba phetoho e kholo ha li ntse li tsitsisoa ho Rust 1.26.0.
    // Kahoo, mohlala
    // `(0..=u16::MAX).len()` mohlala e tla bokella ntle le phoso kapa litemoso ho li-platform tsa 16-bit, empa u tsoele pele ho fana ka sephetho se fosahetseng.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // TSHIRELETSO: ho hlahlobilwe maemo a pele feela
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}