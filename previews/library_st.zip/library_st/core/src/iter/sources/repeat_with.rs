use crate::iter::{FusedIterator, TrustedLen};

/// E theha sebatli se secha se pheta likarolo tsa mofuta oa `A` ka ho sa feleng ka ho sebelisa koalo e fanoeng, e phetang, `F: FnMut() -> A`.
///
/// Mosebetsi oa `repeat_with()` o bitsa motho ea o phetang khafetsa.
///
/// Li-iterator tse sa feleng tse kang `repeat_with()` hangata li sebelisoa le li-adapter tse kang [`Iterator::take()`], ho li etsa hore li fele.
///
/// Haeba mofuta oa iterator eo u e hlokang o sebelisa [`Clone`], 'me ho lokile ho boloka mohloli oa mohloli mohopolong, o lokela ho sebelisa [`repeat()`].
///
///
/// Iterator e hlahisitsoeng ke `repeat_with()` ha se [`DoubleEndedIterator`].
/// Haeba o hloka `repeat_with()` ho khutlisa [`DoubleEndedIterator`], ka kopo bula sengolo sa GitHub se hlalosang nyeoe ea hau ea ts'ebeliso.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::iter;
///
/// // ha re nahane hore re na le boleng ba mofuta o seng `Clone` kapa o sa batleng ho o hopola hobane o theko e phahameng:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // boleng bo itseng ka ho sa feleng:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Ho sebelisa phetoho le ho fela:
///
/// ```rust
/// use std::iter;
///
/// // Ho tloha ho zeroth ho isa matla a boraro a tse peli:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... 'me joale re qetile
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator e pheta likarolo tsa mofuta `A` ka ho sa feleng ka ho sebelisa koalo e fanoeng ea `F: FnMut() -> A`.
///
///
/// `struct` ena e entsoe ke mosebetsi oa [`repeat_with()`].
/// Bona litokomane tsa eona bakeng sa tse ling.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}