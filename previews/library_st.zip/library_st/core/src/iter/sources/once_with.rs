use crate::iter::{FusedIterator, TrustedLen};

/// E etsa iterator eo ka botsoa e hlahisang boleng hang hang ka ho kopa koalo e fanoeng.
///
/// Sena se tloaetse ho sebelisoa ho fetolela jenereithara ea boleng bo le bong ho [`chain()`] ea mefuta e meng ea iteration.
/// Mohlomong u na le iterator e koahelang hoo e batlang e le ntho e ngoe le e ngoe, empa u hloka nyeoe e khethehileng.
/// Mohlomong u na le ts'ebetso e sebetsang ho li-iterator, empa u hloka feela ho sebetsana le boleng bo le bong.
///
/// Ho fapana le [`once()`], ts'ebetso ena e tla hlahisa boleng ka kopo.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::iter;
///
/// // e le 'ngoe ke palo e bolutu ka ho fetisisa
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // e le 'ngoe feela, ke sona feela seo re se fumanang
/// assert_eq!(None, one.next());
/// ```
///
/// Ho kopanya hammoho le iterator e 'ngoe.
/// Ha re re re batla ho lekola holim'a file e ngoe le e ngoe ea sesebelisoa sa `.foo`, empa hape le faele ea phetolo,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // re hloka ho fetolela ho tloha ho iterator ea DirEntry-s ho ea ho iterator ea PathBufs, ka hona re sebelisa 'mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // hona joale, iterator ea rona bakeng sa faele ea rona ea konopo
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kopanya li-iterator tse peli hore e be iterator e le 'ngoe e kholo
/// let files = dirs.chain(config);
///
/// // sena se tla re fa lifaele tsohle tsa .foo hammoho le .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Sesebelisoa se hlahisang ntho e le 'ngoe ea mofuta oa `A` ka ho sebelisa koalo e fanoeng ea `F: FnOnce() -> A`.
///
///
/// `struct` ena e entsoe ke mosebetsi oa [`once_with()`].
/// Bona litokomane tsa eona bakeng sa tse ling.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}