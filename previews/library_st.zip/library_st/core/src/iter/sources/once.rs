use crate::iter::{FusedIterator, TrustedLen};

/// E theha sehlahlo se hlahisang ntlha hantle hang.
///
/// Sena se tloaetse ho sebelisoa ho fetolela boleng bo le bong ho [`chain()`] ea mefuta e meng ea iteration.
/// Mohlomong u na le iterator e koahelang hoo e batlang e le ntho e ngoe le e ngoe, empa u hloka nyeoe e khethehileng.
/// Mohlomong u na le ts'ebetso e sebetsang ho li-iterator, empa u hloka feela ho sebetsana le boleng bo le bong.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::iter;
///
/// // e le 'ngoe ke palo e bolutu ka ho fetisisa
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // e le 'ngoe feela, ke sona feela seo re se fumanang
/// assert_eq!(None, one.next());
/// ```
///
/// Ho kopanya hammoho le iterator e 'ngoe.
/// Ha re re re batla ho lekola holim'a file e ngoe le e ngoe ea sesebelisoa sa `.foo`, empa hape le faele ea phetolo,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // re hloka ho fetolela ho tloha ho iterator ea DirEntry-s ho ea ho iterator ea PathBufs, ka hona re sebelisa 'mapa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // hona joale, iterator ea rona bakeng sa faele ea rona ea konopo
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // kopanya li-iterator tse peli hore e be iterator e le 'ngoe e kholo
/// let files = dirs.chain(config);
///
/// // sena se tla re fa lifaele tsohle tsa .foo hammoho le .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Sesebelisoa se hlahisang ntho hang hang.
///
/// `struct` ena e entsoe ke mosebetsi oa [`once()`].Bona litokomane tsa eona bakeng sa tse ling.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}