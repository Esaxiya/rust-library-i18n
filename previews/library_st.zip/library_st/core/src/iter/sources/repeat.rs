use crate::iter::{FusedIterator, TrustedLen};

/// E theha sebapali se secha se phetang ntho e le 'ngoe ka ho sa feleng.
///
/// Mosebetsi oa `repeat()` o pheta boleng bo le bong khafetsa.
///
/// Li-iterator tse sa feleng tse kang `repeat()` hangata li sebelisoa le li-adapter tse kang [`Iterator::take()`], ho li etsa hore li fele.
///
/// Haeba mofuta oa iterator eo o e hlokang o sa sebelise `Clone`, kapa haeba o sa batle ho boloka se phetoang mohopolong, o ka sebelisa [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::iter;
///
/// // palo ea bone 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Ee, re ntse re le bane
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ho ea qetellong le [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // mohlala oo oa ho qetela e ne e le tse 'ne haholo.Ha rebe le bone feela.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... 'me joale re qetile
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterator e pheta ntho e sa feleng.
///
/// `struct` ena e entsoe ke mosebetsi oa [`repeat()`].Bona litokomane tsa eona bakeng sa tse ling.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}