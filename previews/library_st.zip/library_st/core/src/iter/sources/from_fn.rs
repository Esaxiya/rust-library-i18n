use crate::fmt;

/// E theha iterator e ncha moo iteration e ngoe le e ngoe e bitsang ho koaloa ho fanoeng `F: FnMut() -> Option<T>`.
///
/// Sena se lumella ho theha mohatelli oa moetlo ka boits'oaro bofe kapa bofe ntle le ho sebelisa syntax e eketsehileng ea ho bopa mofuta o inehetseng le ho kenya ts'ebetsong [`Iterator`] trait bakeng sa ona.
///
/// Hlokomela hore `FromFn` iterator ha e nahane ka boits'oaro ba ho koaloa, ka hona ka mokhoa o ts'oanelang ha e sebelise [`FusedIterator`], kapa e hatella [`Iterator::size_hint()`] ho tsoa ho `(0, None)` ea eona ea mantlha.
///
///
/// Ho koaloa ho ka sebelisa litšoantšo le tikoloho ea tsona ho lekola maemo ho potoloha le maemo.Ho ipapisitse le hore na iterator e sebelisoa joang, sena se ka hloka ho hlakisa lebitso la sehlooho la [`move`] ha ho koaloa.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ha re e sebeliseng bocha iterator ea [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Eketsa palo ea rona.Ke kahoo re qalileng ho zero.
///     count += 1;
///
///     // Lekola ho bona hore na re qetile ho bala kapa che.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator moo lenane le leng le le leng le bitsang koalo e fanoeng `F: FnMut() -> Option<T>`.
///
/// `struct` ena e entsoe ke mosebetsi oa [`iter::from_fn()`].
/// Bona litokomane tsa eona bakeng sa tse ling.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}