//! Iteration e kantle e ka bapisoang.
//!
//! Haeba u iphumane u na le pokello ea mofuta o itseng, 'me u hloka ho etsa opereishene linthong tsa pokello e boletsoeng, u tla potlakela ho 'iterators'.
//! Li-Iterator li sebelisoa haholo ho khoutu ea Rust ea maiketsetso, ka hona ho bohlokoa ho e tseba.
//!
//! Pele re hlalosa ho feta, ha re bue ka hore module ena e hlophisitsoe joang:
//!
//! # Organization
//!
//! Mojule ona o hlophisitsoe haholo ke mofuta:
//!
//! * [Traits] ke karolo ea mantlha: tsena traits li hlalosa hore na ke li-iterator tsa mofuta ofe le hore na u ka li etsa joang.Mekhoa ea traits e bohlokoa ho beha nako e eketsehileng ea ho ithuta ho.
//! * [Functions] fana ka litsela tse ling tse thusang ho theha lingoloa tsa mantlha.
//! * [Structs] hangata ke mefuta ea ho khutlisa ea mekhoa e fapaneng ho module ena ea traits.Hangata o tla batla ho sheba mokhoa o etsang `struct`, ho fapana le `struct` ka boeona.
//! Ho fumana lintlha ka botlalo mabapi le hore na hobaneng, bona '[Ho kenya ts'ebetsong Iterator](#e kenya tšebetsong-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ho felile ke lehlohonolo!Ha re chekeng ho li-iterator.
//!
//! # Iterator
//!
//! Pelo le moea oa module ena ke [`Iterator`] trait.Motsoako oa [`Iterator`] o shebahala tjena:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Mohlophisi o na le mokhoa, [`next`], oo ha o bitsoa o khutlisetsang [`Khetho`]`<Item>`.
//! [`next`] e tla khutlisa [`Some(Item)`] ha feela ho na le likarolo, 'me hang ha li felile kaofela, e tla khutlisa `None` ho bonts'a hore iteration e felile.
//! Batšehetsi ka bomong ba kanna ba khetha ho qalella ho pheta-pheta, ka hona ho letsetsa [`next`] hape ho kanna ha qetella ho qalile ho khutlisa [`Some(Item)`] hape ka nako e ngoe (mohlala, bona [`TryIter`]).
//!
//!
//! Tlhaloso e felletseng ea [`Iterator`] e kenyelletsa mekhoa e meng e mengata hape, empa ke mekhoa ea kamehla, e hahiloeng holim'a [`next`], ka hona o e fumana mahala.
//!
//! Li-Iterator le tsona lia hlophiseha, 'me ho tloaelehile ho li tlama hammoho ho etsa mefuta e rarahaneng ea ts'ebetso.Bona karolo ea [Adapters](#adapters) ka tlase bakeng sa lintlha tse ling.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Mefuta e meraro ea ho pheta-pheta
//!
//! Ho na le mekhoa e meraro e tloaelehileng e ka hlahisang li-iterator ho tsoa pokellong:
//!
//! * `iter()`, e potolohang ho feta `&T`.
//! * `iter_mut()`, e potolohang ho feta `&mut T`.
//! * `into_iter()`, e potolohang ho feta `T`.
//!
//! Lintho tse fapaneng laeboraring e tloaelehileng li ka kenya tšebetsong e le 'ngoe kapa ho feta ho tse tharo, moo ho loketseng.
//!
//! # Ho kenya tšebetsong Iterator
//!
//! Ho iketsetsa iterator ea hau ho kenyelletsa mehato e 'meli: ho theha `struct` ho ts'oara boemo ba eona, ebe o kenya ts'ebetsong [`Iterator`] bakeng sa `struct` eo.
//! Ke ka hona ho nang le `struct`s tse ngata mojuleng ona: ho na le e le 'ngoe bakeng sa iterator e ngoe le e ngoe ea iterator adaptara.
//!
//! Ha re etseng iterator e bitsoang `Counter` e balang ho tloha `1` ho isa ho `5`:
//!
//! ```
//! // Taba ea mantlha, sebopeho:
//!
//! /// Iterator e balang ho tloha ho la pele ho isa ho la bohlano
//! struct Counter {
//!     count: usize,
//! }
//!
//! // re batla hore palo ea rona e qale ka bonngoe, kahoo ha re kenye mokhoa oa new() ho thusa.
//! // Sena ha se hlile ha se hlokahale, empa se bonolo.
//! // Hlokomela hore re qala `count` ka zero, re tla bona hore na hobaneng ts'ebetsong ea `next()`'s ka tlase.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ebe re kenya `Iterator` bakeng sa `Counter` ea rona:
//!
//! impl Iterator for Counter {
//!     // re tla be re bala le usize
//!     type Item = usize;
//!
//!     // next() ke eona feela mokhoa o hlokoang
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Eketsa palo ea rona.Ke kahoo re qalileng ho zero.
//!         self.count += 1;
//!
//!         // Lekola ho bona hore na re qetile ho bala kapa che.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Mme joale re ka e sebelisa!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Ho letsetsa [`next`] ka tsela ena ho pheta-pheta.Rust e na le moaho o ka letsetsang [`next`] ho iterator ea hau, ho fihlela e fihla `None`.Ha re feteng se latelang.
//!
//! Hape hlokomela hore `Iterator` e fana ka ts'ebetsong ea mekhoa e kang `nth` le `fold` e bitsang `next` ka hare.
//! Leha ho le joalo, ho a khonahala ho ngola ts'ebetso e tloahelehileng ea mekhoa e kang `nth` le `fold` haeba iterator e ka li bala hantle ntle le ho letsetsa `next`.
//!
//! # `for` likonopo le `IntoIterator`
//!
//! Rust's `for` loop syntax ha e le hantle ke tsoekere bakeng sa li-iterator.Mona ke mohlala oa mantlha oa `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Sena se tla hatisa linomoro ho tloha ho la bohlano, e 'ngoe le e' ngoe moleng oa eona.Empa u tla hlokomela ho hong mona: ha ho mohla re kileng ra bitsa letho ho vector ea rona ho hlahisa sehlahlobi.Ke eng e fanang?
//!
//! Ho na le trait ka har'a laeborari e tloaelehileng ea ho fetola ntho e ngoe ho ba iterator: [`IntoIterator`].
//! trait ena e na le mokhoa o le mong, [`into_iter`], e fetolang ntho e sebelisang [`IntoIterator`] hore e be iterator.
//! Ha re shebeng lupu eo ea `for` hape, le hore na moqapi o e fetola eng:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-tsoekere ho etsa sena:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pele, re bitsa `into_iter()` ka boleng.Ka mor'a moo, re bapisa ho iterator e khutlang, re letsetsa [`next`] khafetsa ho fihlela re bona `None`.
//! Ka nako eo, re le `break`, 'me re qetile ho e pheta.
//!
//! Ho na le ntho e 'ngoe e poteletseng mona: laeborari e tloaelehileng e na le ts'ebetsong e khahlisang ea [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ka mantsoe a mang, bohle [`Iterator`] ba kenya ts'ebetsong [`IntoIterator`], ka ho ipusetsa.Sena se bolela lintho tse peli:
//!
//! 1. Haeba u ngola [`Iterator`], u ka e sebelisa ka sekonopo sa `for`.
//! 2. Haeba o theha pokello, ho kenya ts'ebetsong [`IntoIterator`] bakeng sa eona ho tla lumella pokello ea hau ho sebelisoa le loop ea `for`.
//!
//! # Ho qala ka ho buoa
//!
//! Kaha [`into_iter()`] e nka `self` ka boleng, ho sebelisa `for` loop ho iterate holima pokello e sebelisa pokello eo.Khafetsa, o kanna oa batla ho pheta pokello ntle le ho e qeta.
//! Likoleke tse ngata li fana ka mekhoa e fanang ka li-iterator ho latela litšupiso, tseo ka tloaelo li bitsoang `iter()` le `iter_mut()` ka ho latellana:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` e ntse e le ea mosebetsi ona.
//! ```
//!
//! Haeba mofuta oa pokello `C` o fana ka `iter()`, hangata o sebelisa `IntoIterator` bakeng sa `&C`, ka ts'ebetsong e bitsang `iter()` feela.
//! Ka mokhoa o ts'oanang, pokello ea `C` e fanang ka `iter_mut()` ka kakaretso e sebelisa `IntoIterator` bakeng sa `&mut C` ka ho e fa `iter_mut()`.Sena se nolofalletsa khutsufatso e loketseng:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // e ts'oanang le `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // e ts'oanang le `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Le ha likoleke tse ngata li fana ka `iter()`, ha se tsohle tse fanang ka `iter_mut()`.
//! Mohlala, ho fetola linotlolo tsa [`HashSet<T>`] kapa [`HashMap<K, V>`] ho ka beha pokello maemong a sa lumellaneng haeba senotlolo se potlakile se fetoha, ka hona likoleke tsena li fana ka `iter()` feela.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Mesebetsi e nkang [`Iterator`] ebe e khutlisa [`Iterator`] e ngoe hangata e bitsoa 'iterator adapters', kaha ke mofuta oa 'adapta
//! pattern'.
//!
//! Li-adapter tse tloaelehileng tsa iterator li kenyelletsa [`map`], [`take`], le [`filter`].
//! Bakeng sa tse ling, bona litokomane tsa bona.
//!
//! Haeba adaptara ea iterator panics, iterator e tla ba maemong a sa tsejoeng (empa e bolokehile ka memori).
//! Mmuso ona ha o na ts'episo ea ho lula o ts'oana ho mefuta eohle ea Rust, ka hona o lokela ho qoba ho itšetleha ka boleng bo nepahetseng bo khutlisitsoeng ke iterator e tšohileng.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Li-Iterator (le iterator [adapters](#adapters)) li *botsoa*. Sena se bolela hore ho theha iterator feela ha ho _do_ haholo. Ha ho letho le etsahalang ho fihlela o letsetsa [`next`].
//! Ka linako tse ling hona ke mohloli oa pherekano ha o theha iterator feela bakeng sa litla-morao tsa eona.
//! Mohlala, mokhoa oa [`map`] o bitsa ho koaloa nthong e 'ngoe le e' ngoe eo e fetang ka eona.
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Sena se ke ke sa hatisa litekanyetso life kapa life, joalo ka ha re thehile iterator feela, ho fapana le ho e sebelisa.Moqapi o tla re lemosa ka mofuta ona oa boitšoaro:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Tsela ea mahlale ea ho ngola [`map`] bakeng sa litla-morao tsa eona ke ho sebelisa senotlolo sa `for` kapa ho letsetsa mokhoa oa [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Mokhoa o mong o tloaelehileng oa ho hlahloba iterator ke ho sebelisa mokhoa oa [`collect`] ho hlahisa pokello e ncha.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Li-terterter ha lia lokela ho ba le moeli.Mohlala, sebaka se bulehileng ke sebali se sa feleng:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ho tloaelehile ho sebelisa adaptara ea [`take`] iterator ho fetola iterator e sa feleng hore e be e felletseng:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Sena se tla hatisa linomoro `0` ho ea ho `4`, e 'ngoe le e' ngoe e le moleng oa eona.
//!
//! Hopola hore mekhoa ho li-iterator tse sa feleng, le tseo sephetho sa tsona li ka lekanyetsoang ka lipalo ka nako e lekanyelitsoeng, li kanna tsa se khaotse.
//! Ka ho khetheha, mekhoa e joalo ka [`min`], eo ka kakaretso e hlokang ho haola ntho e ngoe le e ngoe ho iterator, e kanna ea se khutle ka katleho bakeng sa li-iterator tse sa feleng.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Che, ha ho joalo!Lupu e sa feleng!
//! // `ones.min()` baka sekoele se sa feleng, ka hona re ke ke ra fihlela ntlha ena!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;