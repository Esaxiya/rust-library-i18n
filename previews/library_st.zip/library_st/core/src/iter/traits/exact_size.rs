/// Iterator e tsebang bolelele ba eona hantle.
///
/// Ba bangata [`Iterator`] ha ba tsebe hore na ba tla pheta makhetlo a makae, empa ba bang ba a tseba.
/// Haeba iterator e tseba hore na e ka pheta makhetlo a makae, ho fana ka phihlello boitsebisong boo ho ka ba molemo.
/// Mohlala, haeba u batla ho khutlela morao, qalo e ntle ke ho tseba hore na pheletso e kae.
///
/// Ha o kenya `ExactSizeIterator`, o tlameha ho kenya ts'ebetsong [`Iterator`].
/// Ha o etsa joalo, ts'ebetsong ea [`Iterator::size_hint`] * e tlameha ho khutlisa boholo ba iterator hantle.
///
/// Mokhoa oa [`len`] o na le ts'ebetsong ea kamehla, ka hona hangata ha oa lokela ho o kenya tšebetsong.
/// Leha ho le joalo, o kanna oa khona ho fana ka ts'ebetso e sebetsang ho feta ea mantlha, ka hona ho e beha maemong ana hoa utloahala.
///
///
/// Hlokomela hore trait ena ke trait e sireletsehileng 'me ka hona ha e *tiisetse*' me * e ke ke ea tiisa hore bolelele bo khutlisitsoeng bo nepahetse.
/// Sena se bolela hore khoutu ea `unsafe` ** ha ea lokela ho itšetleha ka ho nepahala ha [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait e sa tsitsang le e sa bolokehang e fana ka tiiso ena e eketsehileng.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// // mefuta e fapaneng e tseba hantle hore na e tla pheta makhetlo a makae
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ka [module-level docs], re kentse tšebetsong [`Iterator`], `Counter`.
/// Ha re e sebelisetseng `ExactSizeIterator` hape:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Re ka bala habonolo palo e setseng ea liphetho.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Mme joale re ka e sebelisa!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// E khutlisa bolelele bo nepahetseng ba iterator.
    ///
    /// Ts'ebetsong e netefatsa hore iterator e tla khutla hantle ka makhetlo a `len()` ka boleng ba [`Some(T)`], pele e khutlisa [`None`].
    ///
    /// Mokhoa ona o na le ts'ebetsong ea kamehla, kahoo hangata ha oa lokela ho o kenya ka kotloloho.
    /// Leha ho le joalo, haeba u ka fana ka ts'ebetso e sebetsang haholoanyane, u ka etsa joalo.
    /// Bona litokomane tsa [trait-level] ka mohlala.
    ///
    /// Ts'ebetso ena e na le ts'ireletso e ts'oanang le ts'ireletso ea [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // mefuta e fapaneng e tseba hantle hore na e tla pheta makhetlo a makae
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Polelo ena e itšireletsa ka mokhoa o fetelletseng, empa e hlahloba e sa fetoheng
        // e netefalitsoe ke trait.
        // Haeba trait ena e ne e le rust-ka hare, re ka sebelisa debug_assert !;tiisa_eq!e tla lekola ts'ebetsong eohle ea basebelisi ba Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// E khutlisa `true` haeba iterator e se na letho.
    ///
    /// Mokhoa ona o na le ts'ebetsong ea kamehla o sebelisa [`ExactSizeIterator::len()`], ka hona ha ho hlokahale hore o o kenye ts'ebetsong.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}