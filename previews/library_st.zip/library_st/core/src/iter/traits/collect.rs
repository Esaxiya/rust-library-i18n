/// Phetoho e tsoang ho [`Iterator`].
///
/// Ka ho kenya ts'ebetsong `FromIterator` bakeng sa mofuta, o hlalosa hore na e tla etsoa joang ho tsoa ho iterator.
/// Sena se tloaelehile bakeng sa mefuta e hlalosang pokello ea mofuta o itseng.
///
/// [`FromIterator::from_iter()`] ha e bitsoe ka mokhoa o hlakileng, 'me e sebelisoa ka mokhoa oa [`Iterator::collect()`].
///
/// Bona litokomane tsa [`Iterator::collect()`]'s bakeng sa mehlala e meng.
///
/// Bona hape: [`IntoIterator`].
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ho sebelisa [`Iterator::collect()`] ho sebelisa `FromIterator` ka botlalo:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ho kenya ts'ebetsong `FromIterator` bakeng sa mofuta oa hau:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Mohlala oa pokello, ke feela e koahelang Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ha re e fe mekhoa e meng hore re e qale re be re e ekelletse lintho.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 'me re tla kenya tšebetsong FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Joale re ka etsa iterator e ncha ...
/// let iter = (0..5).into_iter();
///
/// // ... 'me u etse MyCollection ka eona
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // bokella sebetsa hape!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// E theha boleng ho tsoa ho iterator.
    ///
    /// Bona [module-level documentation] bakeng sa tse ling.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Phetoho ho [`Iterator`].
///
/// Ka ho kenya ts'ebetsong `IntoIterator` bakeng sa mofuta, o hlalosa hore na e tla fetoloa joang ho iterator.
/// Sena se tloaelehile bakeng sa mefuta e hlalosang pokello ea mofuta o itseng.
///
/// Molemo o mong oa ho kenya ts'ebetsong `IntoIterator` ke hore mofuta oa hau o tla [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Bona hape: [`FromIterator`].
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Ho kenya ts'ebetsong `IntoIterator` bakeng sa mofuta oa hau:
///
/// ```
/// // Mohlala oa pokello, ke feela e koahelang Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ha re e fe mekhoa e meng hore re e qale re be re e ekelletse lintho.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // 'me re tla kenya ts'ebetsong IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Joale re ka etsa pokello e ncha ...
/// let mut c = MyCollection::new();
///
/// // ... eketsa lintho tse ling ho eona ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ebe oe fetola Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Ho tloaelehile ho sebelisa `IntoIterator` joalo ka trait bound.Sena se lumella mofuta oa pokello ea kenyelletso hore o fetohe, ha feela e ntse e le iterator.
/// Meeli e meng e ka boleloa ka ho thibela
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Mofuta oa likarolo tse ntseng li phetoa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Re fetolela mofuta ofe oa iterator?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// E theha iterator ho tloha boleng.
    ///
    /// Bona [module-level documentation] bakeng sa tse ling.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Eketsa pokello ka litaba tsa iterator.
///
/// Li-Iterator li hlahisa letoto la litekanyetso, 'me likoleke li ka nkuoa hape e le letoto la litekanyetso.
/// `Extend` trait e koala lekhalo lena, e u lumella ho holisa pokello ka ho kenyelletsa litaba tsa iterator eo.
/// Ha o atolosa pokello ka senotlolo se seng se ntse se le teng, kenyelletso eo ea ntlafatsoa kapa, maemong a likoleke tse lumellang litlatsetso tse ngata tse nang le linotlolo tse lekanang, kenyelletso eo ea kenngoa.
///
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// // O ka holisa khoele ka likhechana tse ling:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Ho kenya ts'ebetsong `Extend`:
///
/// ```
/// // Mohlala oa pokello, ke feela e koahelang Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ha re e fe mekhoa e meng hore re e qale re be re e ekelletse lintho.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kaha MyCollection e na le lenane la li-i32s, re kenya ts'ebetsong Extend bakeng sa i32
/// impl Extend<i32> for MyCollection {
///
///     // Hona ho batla ho le bonolo ha ho saennoe mofuta oa konkreite: re ka letsetsa ho atoloha ho eng kapa eng e ka fetoloang Iterator e re fang i32s.
///     // Hobane re hloka li-i32 ho kenya MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Ts'ebetsong e otlolohile haholo: lata ka iterator, 'me add() elemente e ngoe le e ngoe e ea ho rona.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ha re atoloseng pokello ea rona ka linomoro tse ling tse tharo
/// c.extend(vec![1, 2, 3]);
///
/// // Re kentse likarolo tsena qetellong
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// E atolosa pokello ka litaba tsa iterator.
    ///
    /// Kaha ena ke eona feela mokhoa o hlokahalang bakeng sa trait ena, litokomane tsa [trait-level] li na le lintlha tse ling hape.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // O ka holisa khoele ka likhechana tse ling:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// E atolosa pokello ka ntho e le 'ngoe.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// E boloka matla pokellong bakeng sa palo e fuoeng ea likarolo tse ling.
    ///
    /// Ts'ebetso ea kamehla ha e etse letho.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}