use crate::ops::{ControlFlow, Try};

/// Sesebelisoa se khona ho hlahisa likarolo ho tsoa lipheletsong ka bobeli.
///
/// Ho hong ho sebelisang `DoubleEndedIterator` ho na le bokhoni bo bong bo fetang ba ntho e sebelisang [`Iterator`]: bokhoni ba ho nka le `Item`s ka morao, le ka pele.
///
///
/// Ho bohlokoa ho hlokomela hore ka bobeli le morao li sebetsa moeling o le mong, 'me u se ke oa tšela: iteration e felile ha li kopana bohareng.
///
/// Ka mokhoa o ts'oanang le protocol ea [`Iterator`], hang ha `DoubleEndedIterator` e khutlisa [`None`] ho tsoa ho [`next_back()`], ee letsetse hape e kanna ea se ke ea khutlisa [`Some`] hape.
/// [`next()`] le [`next_back()`] lia fapanyetsana molemong ona.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// E tlosa le ho khutlisa ntho ho tloha pheletsong ea iterator.
    ///
    /// E khutlisa `None` ha ho se na likarolo.
    ///
    /// Litokomane tsa [trait-level] li na le lintlha tse ling hape.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Lintho tse hlahisitsoeng ke mekhoa ea `DoubleEndedIterator` li ka fapana le tse hlahisitsoeng ke mekhoa ea [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// E ntšetsa pele iterator ka morao ka likarolo tsa `n`.
    ///
    /// `advance_back_by` ke mofuta o fapaneng oa [`advance_by`].Mokhoa ona o tla tlola ka cheseho likarolo tsa `n` ho tloha ka morao ka ho letsetsa [`next_back`] ho fihlela makhetlo a `n` ho fihlela [`None`] e kopana.
    ///
    /// `advance_back_by(n)` e tla khutlisa [`Ok(())`] haeba iterator e atleha ka katleho ka likarolo tsa `n`, kapa [`Err(k)`] haeba [`None`] e kopane le eona, moo `k` e leng palo ea likarolo tseo iterator e tsoetseng pele ka tsona pele e felloa ke likarolo (ke hore.
    /// bolelele ba sehlahlo).
    /// Hlokomela hore `k` e lula e le tlase ho `n`.
    ///
    /// Ho letsetsa `advance_back_by(0)` ha ho sebelise likarolo leha e le life 'me kamehla ho khutlisa [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ke `&3` feela e ileng ea tlotsoa
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// E khutlisa karolo ea `n`th ho tloha pheletsong ea iterator.
    ///
    /// Ha e le hantle ena ke mofuta o fetotsoeng oa [`Iterator::nth()`].
    /// Le ha ho le joalo ka ts'ebetso e ngata ea ho etsa li-index, palo e qala ho tloha ho zero, kahoo `nth_back(0)` e khutlisa boleng ba pele ho tloha qetellong, `nth_back(1)` ea bobeli, joalo-joalo.
    ///
    ///
    /// Hlokomela hore likarolo tsohle tse lipakeng tsa pheletso le tse khutlisitsoeng li tla sebelisoa, ho kenyeletsoa le ntho e khutlisitsoeng.
    /// Sena se boetse se bolela hore ho letsetsa `nth_back(0)` makhetlo a mangata ho iterator e tšoanang ho tla khutlisa likarolo tse fapaneng.
    ///
    /// `nth_back()` e tla khutlisa [`None`] haeba `n` e feta kapa e lekana le bolelele ba iterator.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Ho letsetsa `nth_back()` makhetlo a mangata ha ho khutlisetse morao ho iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Ho khutlisa `None` haeba ho na le likarolo tse ka tlase ho `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ena ke mofuta o fapaneng oa [`Iterator::try_fold()`]: ho nka likarolo ho tloha ka morao ho iterator.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Hobane e khutšoanyane, li-element tse setseng li ntse li fumaneha ka iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Mokhoa oa iterator o fokotsang likarolo tsa iterator ho boleng bo le bong, ba hoqetela, ho qala ka morao.
    ///
    /// Ena ke mofuta o fapaneng oa [`Iterator::fold()`]: ho nka likarolo ho tloha ka morao ho iterator.
    ///
    /// `rfold()` e nka mabaka a mabeli: boleng ba pele, le ho koaloa ka mabaka a mabeli: 'accumulator', le element.
    /// Ho koaloa ho khutlisa boleng boo pokello e lokelang ho ba le bona bakeng sa phetiso e latelang.
    ///
    /// Boleng ba pele ke boleng boo pokello e tla ba le bona pitsong ea pele.
    ///
    /// Kamora ho sebelisa ho koaloa hona nthong e ngoe le e ngoe ea iterator, `rfold()` e khutlisa pokello.
    ///
    /// Ts'ebetso ena ka linako tse ling e bitsoa 'reduce' kapa 'inject'.
    ///
    /// Ho phutha ho bohlokoa neng kapa neng ha u na le pokello ea ho hong, 'me u batla ho hlahisa boleng bo le bong ho eona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kakaretso ea likarolo tsohle tsa a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Mohlala ona o theha khoele, ho qala ka boleng ba mantlha mme o tsoelapele ka ntho e ngoe le e ngoe ho tloha ka morao ho ea pele:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ho phenyekolla ntho ea iterator e tsoang ka morao e khotsofatsang lereho.
    ///
    /// `rfind()` e koala e khutlisetsang `true` kapa `false`.
    /// E sebetsa ho koaloa hona ho karolo e ngoe le e ngoe ea iterator, ho qala qetellong, 'me haeba ho na le ba khutlisang `true`, `rfind()` e khutlisa [`Some(element)`].
    /// Haeba kaofela ba khutlisa `false`, e khutlisa [`None`].
    ///
    /// `rfind()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho sebetsa hang ha ho koaloa ho khutla `true`.
    ///
    /// Hobane `rfind()` e nka litšupiso, 'me lingoli tse ngata li pheta-pheta litšupiso, hona ho lebisa boemong bo ka ferekanyang moo khang e buang ka makhetlo a mabeli.
    ///
    /// U ka bona phello ena mehlaleng e ka tlase, ka `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Ho emisa `true` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}