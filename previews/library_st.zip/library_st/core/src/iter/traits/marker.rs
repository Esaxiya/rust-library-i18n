/// Iterator e lulang e tsoela pele ho hlahisa `None` ha e khathetse.
///
/// Ho letsetsa latelang ho iterator e fusitsoeng e khutlisitseng `None` hang ho netefalitsoe ho khutlisa [`None`] hape.
/// trait ena e lokela ho kengoa tšebetsong ke mahlahana ohle a itšoarang ka tsela ena hobane e lumella ho ntlafatsa [`Iterator::fuse()`].
///
///
/// Note: Ka kakaretso, ha ua lokela ho sebelisa `FusedIterator` ka meeli ea generic haeba u hloka sehlahlo se fused.
/// Sebakeng seo, o lokela ho letsetsa [`Iterator::fuse()`] ho iterator.
/// Haeba iterator e se e kopantsoe, sekoaelo se seng sa [`Fuse`] e tla ba no-op ntle le kotlo ea ts'ebetso.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator e tlaleha bolelele bo nepahetseng e sebelisa size_hint.
///
/// Iterator e tlaleha ntlha ea boholo moo e tobileng teng (tlamo e tlase e lekana le e holimo), kapa e holimo ke [`None`].
///
/// Moeli o kaholimo o tlameha ho ba [`None`] feela haeba bolelele ba iterator bo boholo ho feta [`usize::MAX`].
/// Maemong a joalo, tlamo e tlase e tlameha ho ba [`usize::MAX`], e hlahisang [`Iterator::size_hint()`] ea `(usize::MAX, None)`.
///
/// Mohlahlobi o tlameha ho hlahisa hantle feela palo ea likarolo tseo a li tlalehileng kapa a li khelohileng pele a fihla pheletsong.
///
/// # Safety
///
/// trait ena e tlameha ho kengoa tšebetsong ha konteraka e tiisoa feela.
/// Bareki ba trait ena ba tlameha ho hlahloba [`Iterator::size_hint()`]’s e phahameng.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterator ha e hlahisa ntho e tla be e nkile bonyane ntho e le 'ngoe ho tsoa ho [`SourceIter`] ea eona.
///
/// Ho letsetsa mokhoa ofe kapa ofe o ntšetsang pele iterator, mohlala
/// [`next()`] kapa [`try_fold()`], e tiisa hore mohatong o mong le o mong bonyane boleng bo le bong ba mohloli o ka sehloohong oa iterator bo tlositsoe 'me sephetho sa ketane ea iterator se ka kenngoa sebakeng sa eona, ka lebaka la mathata a sebopeho sa mohloli a lumellang kenyelletso e joalo.
///
/// Ka mantsoe a mang trait ena e bonts'a hore phaepe ea iterator e ka bokelloa sebakeng sa eona.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}