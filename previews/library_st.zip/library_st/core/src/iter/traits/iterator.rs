// hlokomoloha-bohloeki-filelength Faele ena e batla e na le tlhaloso ea `Iterator` feela.
// Re ke ke ra e arola ka lifaele tse ngata.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Sebopeho sa ho sebetsana le iterators.
///
/// Ena ke eona iterator e kholo trait.
/// Ho fumana lintlha tse ling ka mohopolo oa li-iterator ka kakaretso, ka kopo sheba [module-level documentation].
/// Haholo-holo, o kanna oa batla ho tseba ho etsa [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Mofuta oa likarolo tse ntseng li phetoa.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// E ntshetsa pele sehlophisi ebe e khutlisa boleng bo latelang.
    ///
    /// E khutlisa [`None`] ha iteration e felile.
    /// Ts'ebetsong ea iterator ka bomong e kanna ea khetha ho qala ts'ebetso hape, ka hona ho letsetsa `next()` hape ho kanna ha qetella ho qalile ho khutlisa [`Some(Item)`] hape ka nako e ngoe.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Pitso ho next() e khutlisa boleng bo latelang ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... 'me joale Ha ho letho ha le fetile.
    /// assert_eq!(None, iter.next());
    ///
    /// // Mehala e meng e ka khutlisa `None` kapa ea se ke ea e khutlisa.Mona, ba tla lula ba le teng.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// E khutlisa meeli botelele bo setseng ba iterator.
    ///
    /// Ka ho khetheha, `size_hint()` e khutlisa tuple moo elemente ea pele e leng moeli o tlase, 'me ntlha ea bobeli e tlamiloe ka holimo.
    ///
    /// Halofo ea bobeli ea Sehlooho se khutlisitsoeng ke [`Khetho`]`<<`[usize`]`> `.
    /// [`None`] mona e bolela hore ekaba ha ho na libaka tse tsebahalang tse holimo, kapa karolo e holimo e kholo ho feta [`usize`].
    ///
    /// # Lintlha tsa ho kenya ts'ebetsong
    ///
    /// Ha e qobelloe hore ts'ebetso ea iterator e hlahisa palo e boletsoeng ea likarolo.Sesebelisoa sa kariki se ka hlahisa tlase ho tlamo e tlase kapa ho feta karolo e holimo ea likarolo.
    ///
    /// `size_hint()` e etselitsoe haholo-holo ho sebelisetsoa likhakanyo tse kang ho boloka sebaka bakeng sa likarolo tsa iterator, empa ha ea lokela ho tšeptjoa ho mohlala, tlohela meeli ea licheke ka khoutu e sa bolokehang.
    /// Ts'ebetso e fosahetseng ea `size_hint()` ha ea lokela ho lebisa tlolong ea polokeho ea memori.
    ///
    /// Seo se boletse, ts'ebetsong e lokela ho fana ka tekanyetso e nepahetseng, hobane ho seng joalo e tla ba tlolo ea melaoana ea trait.
    ///
    /// Ts'ebetso ea kamehla e khutlisa `(0,` [`None`]`)`e nepahetseng bakeng sa sebali se seng le se seng.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Mohlala o rarahaneng ho feta:
    ///
    /// ```
    /// // Linomoro tse lekanang ho tloha ho zero ho isa ho leshome.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Re ka tloha ho tloha ho zero ho isa makhetlo a leshome.
    /// // Ho tseba hore tse hlano hantle ho ne ho ke ke ha khonahala ntle le ho etsa filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ha re kenye linomoro tse ling tse hlano ka chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // hona joale meeli ka bobeli e eketsehile ka tse hlano
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Ho khutlisa `None` molemong o kaholimo:
    ///
    /// ```
    /// // iterator e sa feleng ha e na tlamo e kaholimo le bophahamo bo kaholimo bo khonehang bo tlamang
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// E sebelisa iterator, ho bala palo ea liphetolelo le ho e khutlisa.
    ///
    /// Mokhoa ona o tla letsetsa [`next`] khafetsa ho fihlela [`None`] e kopana le eona, e khutlise palo ea makhetlo ao e boneng [`Some`] ka oona.
    /// Hlokomela hore [`next`] e tlameha ho bitsoa bonyane hanngoe le ha iterator e sena likarolo.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Boitšoaro bo khaphatsehang
    ///
    /// Mokhoa ona ha o itšireletse khafetsa, ka hona ho bala likarolo tsa iterator tse nang le likarolo tse fetang [`usize::MAX`] ho ka hlahisa sephetho se fosahetseng kapa panics.
    ///
    /// Haeba lipolelo tsa ho etsa bothata li lumelloa, panic e netefalitsoe.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e kanna ea ba panic haeba iterator e na le likarolo tse fetang [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// E sebelisa iterator, e khutlisa element ea ho qetela.
    ///
    /// Mokhoa ona o tla hlahloba iterator ho fihlela e khutlisa [`None`].
    /// Ha e ntse e etsa joalo, e boloka tšalo-morao ea karolo ea hajoale.
    /// Kamora hore [`None`] e khutlisoe, `last()` e tla khutlisa karolo ea hoqetela eo e e boneng.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// E nts'etsapele iterator ka likarolo tsa `n`.
    ///
    /// Mokhoa ona o tla tlola likarolo tsa `n` ka ho letsetsa [`next`] ho fihlela makhetlo a `n` ho fihlela [`None`] e kopana.
    ///
    /// `advance_by(n)` e tla khutlisa [`Ok(())`][Ok] haeba iterator e atleha ka katleho ka likarolo tsa `n`, kapa [`Err(k)`][Err] haeba [`None`] e kopane le eona, moo `k` e leng palo ea likarolo tseo iterator e tsoetseng pele ka eona pele e felloa ke likarolo (ke hore.
    /// bolelele ba sehlahlo).
    /// Hlokomela hore `k` e lula e le tlase ho `n`.
    ///
    /// Ho letsetsa `advance_by(0)` ha ho sebelise likarolo leha e le life 'me kamehla ho khutlisa [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // ke `&4` feela e ileng ea tlotsoa
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// E khutlisa karolo ea `n`th ea iterator.
    ///
    /// Joalo ka lits'ebetso tse ngata tsa indexing, palo e qala ho tloha ho zero, kahoo `nth(0)` e khutlisa boleng ba pele, `nth(1)` ea bobeli, joalo-joalo.
    ///
    /// Hlokomela hore likarolo tsohle tse fetileng, hammoho le ntho e khutlisitsoeng, li tla sebelisoa ho tsoa ho iterator.
    /// Seo se bolela hore likarolo tse fetileng li tla lahloa, mme ho letsetsa `nth(0)` makhetlo a mangata ho iterator e tšoanang ho tla khutlisa likarolo tse fapaneng.
    ///
    ///
    /// `nth()` e tla khutlisa [`None`] haeba `n` e feta kapa e lekana le bolelele ba iterator.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ho letsetsa `nth()` makhetlo a mangata ha ho khutlisetse morao ho iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Ho khutlisa `None` haeba ho na le likarolo tse ka tlase ho `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// E etsa iterator ho qala ka nako e ts'oanang, empa e feta ka palo e fanoeng ho iteration e ngoe le e ngoe.
    ///
    /// Tlhokomeliso 1: Elemente ea pele ea iterator e tla lula e khutlisoa, ho sa tsotelehe mohato o fanoeng.
    ///
    /// Tlhokomeliso 2: Nako eo lintho tse sa tsotelleng li huloang ka eona ha e ea ts'oaroa.
    /// `StepBy` itšoara joalo ka tatellano ea `next(), nth(step-1), nth(step-1),…`, empa hape e lokolohile ho itšoara joalo ka tatellano
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Ke tsela efe e sebelisoang e ka fetohang ho ba bang ba iterator ka mabaka a ts'ebetso.
    /// Mokhoa oa bobeli o tla ntšetsa pele iterator pejana mme o ka ja lintho tse ling.
    ///
    /// `advance_n_and_return_first` e lekana le:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Mokhoa o tla panic haeba mohato o fanoeng ke `0`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// E nka li-iterator tse peli ebe e theha iterator e ncha ka bobeli ka tatellano.
    ///
    /// `chain()` e tla khutlisetsa sehlophisi se secha se tla qala ho lekola boleng ho tsoa ho iterator ea pele ebe se fetisa boleng ho tsoa ho iterator ea bobeli.
    ///
    /// Ka mantsoe a mang, e hokahanya li-iterator tse peli hammoho, ka ketane.🔗
    ///
    /// [`once`] e sebelisoa haholo ho fetolela boleng bo le bong ho ketane ea mefuta e meng ea iteration.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kaha khang ea `chain()` e sebelisa [`IntoIterator`], re ka fetisa eng kapa eng e ka fetoloang [`Iterator`], eseng [`Iterator`] ka boeona.
    /// Mohlala, lilae (`&[T]`) li kenya ts'ebetsong [`IntoIterator`], ka hona li ka fetisetsoa ho `chain()` ka kotloloho:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haeba o sebetsa le Windows API, o kanna oa lakatsa ho fetolela [`OsStr`] ho `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'E penya' baphatlalatsi ba babeli ho iterator e le 'ngoe ea lipara.
    ///
    /// `zip()` e khutlisetsa iterator e ncha e tla iterate ho feta li-iterator tse ling tse peli, e khutlise tuple moo elemente ea pele e tsoang ho iterator ea pele, ebe element ea bobeli e tsoa ho iterator ea bobeli.
    ///
    ///
    /// Ka mantsoe a mang, e kenya li-iterator tse peli hammoho hore e be ntho e le 'ngoe.
    ///
    /// Haeba iterator e khutlisa [`None`], [`next`] e tsoang ho ziper iterator e tla khutlisa [`None`].
    /// Haeba iterator ea pele e khutlisa [`None`], `zip` e tla potoloha ha nakoana mme `next` e ke ke ea bitsoa ho iterator ea bobeli.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kaha khang ea `zip()` e sebelisa [`IntoIterator`], re ka fetisa eng kapa eng e ka fetoloang [`Iterator`], eseng [`Iterator`] ka boeona.
    /// Mohlala, lilae (`&[T]`) li kenya ts'ebetsong [`IntoIterator`], ka hona li ka fetisetsoa ho `zip()` ka kotloloho:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` e sebelisoa khafetsa ho pheta iterator e sa feleng ho ea qetellong.
    /// Sena se sebetsa hobane mohatelli ea felletseng o tla khutlisa [`None`], a qetelle ka zipper.Ho kenella ka `(0..)` ho ka shebahala joalo ka [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// E etsa sesupisi se secha se behang kopi ea `separator` lipakeng tsa lintho tse haufi tsa iterator ea mantlha.
    ///
    /// Haeba `separator` e sa sebelise [`Clone`] kapa e hloka ho balelloa nako le nako, sebelisa [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Ntho ea pele e tsoang ho `a`.
    /// assert_eq!(a.next(), Some(&100)); // Karohano.
    /// assert_eq!(a.next(), Some(&1));   // Karolo e latelang e tsoang ho `a`.
    /// assert_eq!(a.next(), Some(&100)); // Karohano.
    /// assert_eq!(a.next(), Some(&2));   // Karolo ea ho qetela e tsoang `a`.
    /// assert_eq!(a.next(), None);       // Iterator e felile.
    /// ```
    ///
    /// `intersperse` ho ka ba molemo haholo ho kenella linthong tsa iterator u sebelisa ntho e tloaelehileng:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// E etsa sesupisi se secha se behang ntho e hlahisitsoeng ke `separator` lipakeng tsa lintho tse haufi tsa iterator ea mantlha.
    ///
    /// Ho koaloa ho tla bitsoa hang hang ha ntho e beoa pakeng tsa lintho tse peli tse haufi ho tsoa ho iterator ea eona;
    /// ka ho khetheha, ho koaloa ha ho bitsoe haeba mohloekisi oa eona oa mantlha a fana ka lintho tse ka tlase ho tse peli mme kamora hore ntho ea ho qetela e hlahisoe.
    ///
    ///
    /// Haeba ntho ea iterator e sebelisa [`Clone`], ho ka ba bonolo ho e sebelisa [`intersperse`].
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Ntho ea pele e tsoang ho `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Karohano.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Karolo e latelang e tsoang ho `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Karohano.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Karolo ea ho qetela e tsoang ho `v`.
    /// assert_eq!(it.next(), None);               // Iterator e felile.
    /// ```
    ///
    /// `intersperse_with` e ka sebelisoa maemong ao karohano e hlokang ho balelloa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ho koaloa ka mokhoa o fetohileng ho alima moelelo oa eona ho hlahisa ntho.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// E koaloa ebe e theha iterator e bitsang ho koaloa nthong ka 'ngoe.
    ///
    /// `map()` e fetola mongolo o mong ho o mong ka khang ea eona:
    /// ntho e sebelisang [`FnMut`].E hlahisa iterator e ncha e bitsang ho koaloa hona ho karolo ka 'ngoe ea iterator ea mantlha.
    ///
    /// Haeba u tseba ho nahana ka mefuta, u ka nahana ka `map()` e kang ena:
    /// Haeba u na le iterator eu fang likarolo tsa mofuta o itseng `A`, 'me u batla iterator ea mofuta o mong `B`, u ka sebelisa `map()`, u fetisa koalo e nkang `A` ebe e khutlisa `B`.
    ///
    ///
    /// `map()` e ts'oana le mohopolo oa [`for`].Leha ho le joalo, kaha `map()` e botsoa, e sebelisoa hamolemo ha o se o ntse o sebetsa le li-iterator tse ling.
    /// Haeba u ntse u loka bakeng sa litla-morao, ho nkuoa ho le bohlale ho sebelisa [`for`] ho feta `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haeba u etsa mofuta o itseng oa litla-morao, khetha [`for`] ho `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // u se ke ua etsa sena:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // e ke ke ea e phethisa, kaha e botsoa.Rust e tla u lemosa ka sena.
    ///
    /// // Sebakeng seo, sebelisa bakeng sa:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// E letsetsa ho koaloa nthong e ngoe le e ngoe ea iterator.
    ///
    /// Sena se lekana le ho sebelisa senotlolo sa [`for`] ho iterator, leha `break` le `continue` li sa khonehe ho tloha ha ho koaloa.
    /// Ka kakaretso ho bohlale ho sebelisa senotlolo sa `for`, empa `for_each` e ka ba bonolo haholoanyane ha e sebetsana le lintho qetellong ea liketane tse telele tsa iterator.
    ///
    /// Maemong a mang `for_each` e kanna ea potlaka ho feta sekgoqetsane, hobane e tla sebelisa phetiso ea kahare ho li-adapter tse kang `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Bakeng sa mohlala o monyane joalo, `for` loop e kanna ea hloeka, empa `for_each` e kanna ea khetha ho boloka setaele se sebetsang le li-iterator tse telele.
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// E etsa iterator e sebelisang ho koala ho fumana hore na ho na le ntho e lokelang ho hlahisoa.
    ///
    /// Ha ho fanoa ka karolo e 'ngoe ho koaloa ho tlameha ho khutlisa `true` kapa `false`.Iterator e khutlisitsoeng e tla hlahisa feela likarolo tseo ho koaloa ho khutlang e le 'nete.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hobane ho koaloa ho fetisitsoeng ho `filter()` ho nka moelelo, 'me boholo ba eona bo pheta-pheta ka litšupiso, sena se lebisa boemong bo ka ferekanyang, moo mofuta oa ho koala o supang habeli:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // hloka tse peli * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ho tloaelehile hore ho e-na le hoo u sebelise mokhoa oa ho senya khang ho tlosa e le 'ngoe:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ka bobeli&*
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// kapa ka bobeli:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // &s tse peli
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// tsa likarolo tsena.
    ///
    /// Hlokomela hore `iter.filter(f).next()` e lekana le `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// E etsa iterator e hlophisang le limmapa ka bobeli.
    ///
    /// Iterator e khutlisitsoeng e hlahisa feela `boleng`s boo koalo e fanoeng e boelang `Some(value)`.
    ///
    /// `filter_map` e ka sebelisoa ho etsa liketane tsa [`filter`] le [`map`] ho feta.
    /// Mohlala o ka tlase o bonts'a hore na `map().filter().map()` e ka khutsufatsoa joang hore e be mohala o le mong ho `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mohlala o tšoanang ke ona, empa ka [`filter`] le [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// E etsa iterator e fanang ka palo ea hona joale ea iteration hammoho le boleng bo latelang.
    ///
    /// Iterator e khutlisitse lihlahisoa ka bobeli `(i, val)`, moo `i` e leng index ea hona joale ea iteration mme `val` ke boleng bo khutlisitsoeng ke iterator.
    ///
    ///
    /// `enumerate()` e boloka palo ea eona e le [`usize`].
    /// Haeba o batla ho bala ka palo e fapaneng e fapaneng, mosebetsi oa [`zip`] o fana ka ts'ebetso e ts'oanang.
    ///
    /// # Boitšoaro bo khaphatsehang
    ///
    /// Mokhoa ona ha o itebele khahlanong le ho phalla, kahoo ho bala likarolo tse fetang [`usize::MAX`] ho ka hlahisa sephetho se fosahetseng kapa panics.
    /// Haeba lipolelo tsa ho etsa bothata li lumelloa, panic e netefalitsoe.
    ///
    /// # Panics
    ///
    /// Iterator e khutlisitsoeng e kanna ea ba panic haeba index e lokelang ho khutlisoa e ka phalla [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// E etsa iterator e ka sebelisang [`peek`] ho sheba element e latelang ea iterator ntle le ho e sebelisa.
    ///
    /// E eketsa mokhoa oa [`peek`] ho iterator.Bona litokomane tsa eona bakeng sa tlhaiso-leseling e batsi.
    ///
    /// Hlokomela hore iterator ea mantlha e ntse e tsoela pele ha [`peek`] e bitsoa lekhetlo la pele: E le ho fumana ntho e latelang, [`next`] e bitsoa mohlohlobi oa eona, ka hona litlamorao (ke hore.
    ///
    /// eng kapa eng ntle le ho lata boleng bo latelang) ba mokhoa oa [`next`] o tla etsahala.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() re lumelle hore re bone future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // re ka peek() makhetlo a mangata, iterator e ke ke ea tsoela pele
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // kamora hore iterator e fele, ho joalo le ka peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// E theha mongolo o reng [`skip`] likarolo tse ipapisitseng le lereho.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` e nka ho koala e le khang.E tla bitsa ho koaloa hona karolong e ngoe le e ngoe ea iterator, 'me u hlokomolohe likarolo ho fihlela e khutlisa `false`.
    ///
    /// Kamora hore `false` e khutlisoe, mosebetsi oa `skip_while()`'s o felile, 'me likarolo tse ling kaofela lia hlahisoa.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hobane ho koaloa ho fetisitsoeng ho `skip_while()` ho supa, 'me lingoli tse ngata li pheta-pheta litšupiso, hona ho lebisa boemong bo ka ferekanyang, moo mofuta oa ngangisano ea ho koala o buuoang habeli:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // hloka tse peli * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ho emisa kamora `false` ea pele:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ha sena e ne e tla be e le leshano, kaha re se re ntse re e-na le leshano, skip_while() ha e sa sebelisoa hape
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// E theha sehlahlo se hlahisang likarolo tse ipapisitseng le lereho.
    ///
    /// `take_while()` e nka ho koala e le khang.E tla bitsa ho koaloa hona karolong e ngoe le e ngoe ea iterator, 'me e hlahise likarolo ha e khutlisa `true`.
    ///
    /// Ka mor'a hore `false` e khutlisoe, mosebetsi oa `take_while()`'s o felile, 'me likarolo tse ling kaofela lia hlokomolohuoa.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hobane ho koaloa ho fetisitsoeng ho `take_while()` ho nka moelelo, 'me boholo ba eona bo pheta-pheta ka litšupiso, sena se lebisa boemong bo ka ferekanyang, moo mofuta oa ho koala o supang habeli:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // hloka tse peli * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ho emisa kamora `false` ea pele:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Re na le likarolo tse ngata tse ka tlase ho zero, empa kaha re se re fumane leshano, take_while() ha e sa sebelisoa hape
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hobane `take_while()` e hloka ho sheba boleng ho bona hore na e lokela ho kenyelletsoa kapa che, basebelisi ba e jang ba tla bona hore e tlositsoe:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ha e sa le moo, hobane e ne e jeoa ho bona hore na iteration e lokela ho emisa, empa ha ea ka ea khutlisetsoa ho iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// E etsa sehlahlo seo ka bobeli se hlahisang likarolo tse ipapisitseng le lereho le limmapa.
    ///
    /// `map_while()` e nka ho koala e le khang.
    /// E tla bitsa ho koaloa hona karolong e ngoe le e ngoe ea iterator, 'me e hlahise likarolo ha e khutlisa [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mohlala o tšoanang ke ona, empa ka [`take_while`] le [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ho emisa kamora [`None`] ea pele:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Re na le likarolo tse ling tse ka lekanang ho u32 (4, 5), empa `map_while` e khutlisitse `None` bakeng sa `-3` (joalo ka ha `predicate` e khutlisitse `None`) le `collect` e emisa qalong ea `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Hobane `map_while()` e hloka ho sheba boleng ho bona hore na e lokela ho kenyelletsoa kapa che, basebelisi ba e jang ba tla bona hore e tlositsoe:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ha e sa le moo, hobane e ne e jeoa ho bona hore na iteration e lokela ho emisa, empa ha ea ka ea khutlisetsoa ho iterator.
    ///
    /// Hlokomela hore ho fapana le [`take_while`] sesupisi sena ha se ** fapantsoe.
    /// Ha ho tsejoe hape hore na iterator ena e khutlisa eng kamora hore [`None`] ea pele e khutlisoe.
    /// Haeba o hloka iterator e fusitsoeng, sebelisa [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// E etsa sehlahlo se tlolang likarolo tsa pele tsa `n`.
    ///
    /// Kamora hore li sebelisoe, likarolo tse ling kaofela li ea hlahisoa.
    /// Sebakeng sa ho hatella mokhoa ona ka kotloloho, ho fapana le ho fetisa mokhoa oa `nth`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// E theha sehlahlo se hlahisang likarolo tsa sona tsa pele tsa `n`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` hangata e sebelisoa le iterator e sa feleng, ho e etsa hore e fele.
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Haeba likarolo tse ka tlase ho `n` li fumaneha, `take` e tla ipehela moeling oa boholo ba iterator ea mantlha:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapter ea iterator e ts'oanang le [`fold`] e ts'oereng boemo ba kahare mme e hlahisa iterator e ncha.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` e nka mabaka a mabeli: boleng ba mantlha bo jalang boemo ba kahare, le ho koaloa ka mabaka a mabeli, ea pele e le polelo e ka fetoloang ho boemo ba kahare mme ea bobeli e le element ea iterator.
    ///
    /// Ho koaloa ho ka abela naha ea kahare ho arolelana boemo lipakeng tsa liphetho.
    ///
    /// Ho iteration, ho koaloa ho tla sebelisoa nthong e 'ngoe le e' ngoe ea iterator le boleng ba ho khutla ho tsoa ho koalo, [`Option`], e hlahisoa ke iterator.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // e mong le e mong o pheta-pheta, re tla atisa mmuso ka elemente
    ///     *state = *state * x;
    ///
    ///     // joale, re tla fana ka bohlanya ba mmuso
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// E etsa iterator e sebetsang joalo ka 'mapa, empa e thehile sebopeho sa sehlaha.
    ///
    /// Sesebelisoa sa [`map`] se thusa haholo, empa ke feela ha khang ea ho koala e hlahisa boleng.
    /// Haeba e hlahisa iterator ho fapana, ho na le karolo e 'ngoe ea tataiso.
    /// `flat_map()` e tla tlosa lera lena le eketsehileng ka bolona.
    ///
    /// U ka nahana ka `flat_map(f)` joalo ka semantic e lekanang le [`map`] ping, ebe ["e batalatsa"] joalo ka `map(f).flatten()`.
    ///
    /// Mokhoa o mong oa ho nahana ka `flat_map()`: [`map`] ho koaloa ho khutlisa ntho e le 'ngoe bakeng sa ntho ka' ngoe, 'me ho koaloa ha `flat_map()`'s ho khutlisa iterator nthong ka' ngoe.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() e khutlisetsa sengoloa
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// E theha sehlahlo se pharalletseng sebopeho sa sehlaha.
    ///
    /// Sena se na le thuso ha u na le iterator ea li-iterator kapa iterator ea lintho tse ka fetoloang ho ba iterator mme o batla ho tlosa boemo bo le bong ba boits'oaro.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Ho etsa 'mapa ebe oa batalatsa:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() e khutlisetsa sengoloa
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// U ka ngola sena hape ho latela [`flat_map()`], e leng khetho e ntle ntlheng ena kaha e hlahisa sepheo ka ho hlaka:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() e khutlisetsa sengoloa
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ho batalatsa feela ho tlosa boemo bo le bong ba sehlaha ka nako.
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Mona rea bona hore `flatten()` ha e etse sephara sa "deep".
    /// Sebakeng seo, ho tlosoa boemo bo le bong feela ba sehlaha.Ka mantsoe a mang, haeba u le `flatten()` ka mekhahlelo e meraro, sephetho se tla ba mahlakore a mabeli eseng lehlakore le le leng.
    /// Ho fumana sebopeho se le seng, o tlameha ho `flatten()` hape.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// E etsa iterator e qetellang kamora [`None`] ea pele.
    ///
    /// Kamora hore iterator e khutlise [`None`], li-call tsa future li kanna tsa se hlahise [`Some(T)`] hape.
    /// `fuse()` e fetola iterator, e netefatsa hore kamora hore [`None`] e fanoe, e tla khutlisa [`None`] kamehla.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // iterator e fapanyang pakeng tsa Tse ling le Che
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // haeba e bile, Some(i32), ha ho letho le le leng
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // re khona ho bona mohlahlobi oa eona a ea koana le koana
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // leha ho le joalo, hang ha re e fuse ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // e tla lula e khutla `None` kamora lekhetlo la pele.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// E etsa ho hong ka ntlha e ngoe le e ngoe ea iterator, e fetisang boleng ho.
    ///
    /// Ha u sebelisa li-iterator, hangata o tla kopanya tse 'maloa tsa tsona hammoho.
    /// Ha o ntse o sebetsana le khoutu e joalo, o kanna oa batla ho sheba se etsahalang likarolong tse fapaneng tsa phaephe.Ho etsa joalo, kenya mohala ho `inspect()`.
    ///
    /// Ho tloaelehile haholo hore `inspect()` e sebelisoe e le sesebelisoa sa ho lokisa bothata ho fapana le ho ba teng khoutu ea hau ea hoqetela, empa lits'ebetso li ka e fumana e le bohlokoa maemong a mang ha liphoso li hloka ho kenoa pele li lahloa.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // tatellano ena ea iterator e thata.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ha re kenyelleng mehala ea inspect() ho fuputsa se etsahalang
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Sena se tla hatisa:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Liphoso tsa ho rema lifate pele u li lahla:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Sena se tla hatisa:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// E alima sebapali, ho fapana le ho e sebelisa.
    ///
    /// Sena se bohlokoa ho lumella li-adapter tsa iterator ha li ntse li sebelisoa ha o ntse o boloka beng ba eona.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // haeba re leka ho e sebelisa hape, e ke ke ea sebetsa.
    /// // Mohala o latelang o fana ka "phoso: ts'ebeliso ea boleng bo fallisitsoeng: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ha re leke seo hape
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ho fapana le moo, re kenya ka .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // hona joale ho lokile:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// E fetola iterator hore e be pokello.
    ///
    /// `collect()` e ka nka ntho efe kapa efe e makatsang, 'me ea e fetola pokello e loketseng.
    /// Ona ke o mong oa mekhoa e matla ho feta laeboraring e tloaelehileng, e sebelisoang maemong a fapaneng.
    ///
    /// Mokhoa oa mantlha ka ho fetisisa oo `collect()` e sebelisoang ka ona ke ho fetolela pokello e ngoe ho e ngoe.
    /// O nka pokello, o letsetsa [`iter`] ho eona, o etsa liphetoho tse ngata, ebe o re `collect()` qetellong.
    ///
    /// `collect()` e ka boela ea theha maemo a mefuta eo e seng pokello e tloaelehileng.
    /// Mohlala, [`String`] e ka hahuoa ho tsoa ho "`char`] s, 'me iterator ea lintho tsa [`Result<T, E>`][`Result`] e ka bokelloa ho `Result<Collection<T>, E>`.
    ///
    /// Bona mehlala e ka tlase bakeng sa tse ling.
    ///
    /// Hobane `collect()` e atile haholo, e ka baka mathata ka mofuta oa mofuta.
    /// Kahoo, `collect()` ke e 'ngoe ea linako tse' maloa moo u tla bona syntax e tsejoang ka lerato e le 'turbofish': `::<>`.
    /// Sena se thusa algorithm ea inference ho utloisisa ka kotloloho pokello efe eo o lekang ho e bokella.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Hlokomela hore re hloka `: Vec<i32>` ka letsohong le letšehali.Lebaka ke hobane re ka bokella ho etsa mohlala, [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Ho sebelisa 'turbofish' ho fapana le ho ngola `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Hobane `collect()` e tsotella feela seo o se bokellang, o ntse o ka sebelisa tlhahiso ea mofuta o itseng, `_`, ka turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// U sebelisa `collect()` ho etsa [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Haeba u na le lethathamo la [`Sephetho<T, E>`][`Result`] s, o ka sebelisa `collect()` ho bona hore na ho na le e sa atlehang:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // e re fa phoso ea pele
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // e re fa lenane la likarabo
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// E sebelisa iterator, e theha pokello tse peli ho eona.
    ///
    /// Sephetho se fetiselitsoeng ho `partition()` se ka khutlisa `true`, kapa `false`.
    /// `partition()` e khutlisetsa para, likarolo tsohle tseo e khutliselitseng `true` ho tsona, le likarolo tsohle tseo e khutliselitseng `false` ho tsona.
    ///
    ///
    /// Bona hape [`is_partitioned()`] le [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// E khutlisetsa likarolo tsa iterator * ena sebakeng sa eona ho latela poleloana e fanoeng, hore bohle ba khutlisang `true` ba etelle pele bohle ba khutlisang `false`.
    ///
    /// E khutlisa palo ea likarolo tsa `true` tse fumanoeng.
    ///
    /// Taelo e lekanyelitsoeng ea lintho tse arotsoeng ha e bolokoe.
    ///
    /// Bona hape [`is_partitioned()`] le [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Karohano e pakeng tsa evens le mathata
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: na re lokela ho tšoenyeha ka palo e phallang?Mokhoa feela oa ho ba le tse fetang
        // `usize::MAX` Litlhaloso tse ka feto-fetohang li na le li-ZST, tse se nang thuso ho arola ...

        // Ts'ebetso tsena tsa ho koala "factory" li teng ho qoba tlhaho ho `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Khafetsa fumana `false` ea pele ebe u e chencha le `true` ea ho qetela.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// E hlahloba haeba likarolo tsa iterator ena li arotsoe ho latela se boletsoeng, joalo ka hore bohle ba khutlisang `true` ba etelle pele bohle ba khutlisang `false`.
    ///
    ///
    /// Bona hape [`partition()`] le [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ebang lintho tsohle li leka `true`, kapa poleloana ea pele e emisa ho `false` mme re sheba hore ha ho sa na lintho tsa `true` kamora moo.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Mokhoa oa iterator o sebetsang ha feela o khutla ka katleho, o hlahisa boleng bo le bong, ba ho qetela.
    ///
    /// `try_fold()` e nka mabaka a mabeli: boleng ba pele, le ho koaloa ka mabaka a mabeli: 'accumulator', le element.
    /// Ho koaloa ho ka khutla ka katleho, ka boleng boo accumulator e lokelang ho ba le bona bakeng sa iteration e latelang, kapa e khutlisa ho hloleha, ka boleng ba phoso bo phatlalalitsoeng ho letsetsa hang hang (short-circuiting).
    ///
    ///
    /// Boleng ba pele ke boleng boo pokello e tla ba le bona pitsong ea pele.Haeba ho sebelisa ho koala ho atlehile khahlano le ntho e ngoe le e ngoe ea iterator, `try_fold()` e khutlisa pokello ea ho qetela e le katleho.
    ///
    /// Ho phutha ho bohlokoa neng kapa neng ha u na le pokello ea ho hong, 'me u batla ho hlahisa boleng bo le bong ho eona.
    ///
    /// # Tlhokomeliso ho ba kenya tšebetsong
    ///
    /// Mekhoa e meng e 'maloa ea (forward) e na le ts'ebetsong ea kamehla ho latela ena, ka hona leka ho kenya ts'ebetsong sena ka ho hlaka haeba e ka etsa ho hong ho betere ho feta ts'ebetsong ea `for` ea loop.
    ///
    /// Haholo-holo, leka ho ba le mohala ona `try_fold()` likarolong tse ka hare tseo mohlophisi enoa a qapiloeng ka tsona.
    /// Haeba ho hlokahala mehala e mengata, mosebelisi oa `?` a kanna a ba bonolo bakeng sa ho koalla boleng ba pokello hammoho, empa hlokomela bahlaseli ba sa hlokeng ho ts'oaroa pele ba khutla kapele.
    /// Ena ke mokhoa oa `&mut self`, ka hona iteration e hloka ho ts'oaroa hape kamora ho otla phoso mona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kakaretso e lekiloeng ea likarolo tsohle tsa sehlopha
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Kakaretso ena ea khaphatseha ha o eketsa karolo ea 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Hobane e khutšoanyane, li-element tse setseng li ntse li fumaneha ka iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Mokhoa oa iterator o sebelisang ts'ebetso e fosahetseng nthong e ngoe le e ngoe ho iterator, o emisa phoso ea pele ebe o khutlisa phoso eo.
    ///
    ///
    /// Sena se ka nahanoa hape e le mofuta o fosahetseng oa [`for_each()`] kapa e le mofuta o se nang palo oa [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // E khutšoanyane, ka hona, lintho tse setseng li ntse li le ho iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// E menahanya ntho e ngoe le e ngoe ka har'a pokello ka ho etsa ts'ebetso, e khutlisa sephetho sa hoqetela
    ///
    /// `fold()` e nka mabaka a mabeli: boleng ba pele, le ho koaloa ka mabaka a mabeli: 'accumulator', le element.
    /// Ho koaloa ho khutlisa boleng boo pokello e lokelang ho ba le bona bakeng sa phetiso e latelang.
    ///
    /// Boleng ba pele ke boleng boo pokello e tla ba le bona pitsong ea pele.
    ///
    /// Kamora ho sebelisa ho koaloa hona nthong e ngoe le e ngoe ea iterator, `fold()` e khutlisa pokello.
    ///
    /// Ts'ebetso ena ka linako tse ling e bitsoa 'reduce' kapa 'inject'.
    ///
    /// Ho phutha ho bohlokoa neng kapa neng ha u na le pokello ea ho hong, 'me u batla ho hlahisa boleng bo le bong ho eona.
    ///
    /// Note: `fold()`, le mekhoa e ts'oanang e haolang iterator kaofela, e kanna ea se khaotse ho li-iterator tse sa feleng, leha e le ho traits eo sephetho sa eona se ka fumanoang ka nako e lekanyelitsoeng.
    ///
    /// Note: [`reduce()`] e ka sebelisoa ho sebelisa element ea pele joalo ka boleng ba mantlha, haeba mofuta oa pokello le mofuta oa ntho li tšoana.
    ///
    /// # Tlhokomeliso ho ba kenya tšebetsong
    ///
    /// Mekhoa e meng e 'maloa ea (forward) e na le ts'ebetsong ea kamehla ho latela ena, ka hona leka ho kenya ts'ebetsong sena ka ho hlaka haeba e ka etsa ho hong ho betere ho feta ts'ebetsong ea `for` ea loop.
    ///
    ///
    /// Haholo-holo, leka ho ba le mohala ona `fold()` likarolong tse ka hare tseo mohlophisi enoa a qapiloeng ka tsona.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kakaretso ea likarolo tsohle tsa sehlopha
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ha re tsamaee mohato o mong le o mong oa iteration mona:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Kahoo, sephetho sa rona sa hoqetela, `6`.
    ///
    /// Ho tloaelehile hore batho ba e-s'o sebelise li-iterator haholo ho sebelisa `for` loop ka lenane la lintho ho theha sephetho.Tsena li ka fetoloa `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // bakeng sa lupu:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // baa tšoana
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// E fokotsa likarolo ho e le 'ngoe, ka ho sebelisa ts'ebetso e fokotsang khafetsa.
    ///
    /// Haeba iterator e se na letho, e khutlisa [`None`];ho seng joalo, e khutlisa sephetho sa phokotso.
    ///
    /// Bakeng sa li-iterator tse nang le bonyane ntlha e le 'ngoe, sena se ts'oana le [`fold()`] le elemente ea pele ea iterator joalo ka boleng ba pele, e mena ntho e ngoe le e ngoe e latelang ho eona.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Fumana boleng bo phahameng ka ho fetisisa:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Liteko haeba karolo e ngoe le e ngoe ea iterator e tšoana le lepetjo.
    ///
    /// `all()` e koala e khutlisetsang `true` kapa `false`.E sebetsa ho koaloa hona ho karolo e ngoe le e ngoe ea iterator, 'me haeba kaofela ba khutlisa `true`, le `all()` e joalo.
    /// Haeba mang kapa mang oa bona a khutlisa `false`, e khutlisa `false`.
    ///
    /// `all()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho e sebetsa hang ha e fumana `false`, hobane ho sa tsotelehe se etsahalang hape, sephetho le sona e tla ba `false`.
    ///
    ///
    /// Sesebelisoa se se nang letho se khutlisa `true`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ho emisa `false` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Liteko haeba ho na le karolo ea iterator e ts'oanang le lereho.
    ///
    /// `any()` e koala e khutlisetsang `true` kapa `false`.E sebetsa ho koaloa hona ho karolo e ngoe le e ngoe ea iterator, 'me haeba ho na le ba khutlisang `true`, le `any()` e joalo.
    /// Haeba kaofela ba khutlisa `false`, e khutlisa `false`.
    ///
    /// `any()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho e sebetsa hang ha e fumana `true`, hobane ho sa tsotelehe se etsahalang hape, sephetho le sona e tla ba `true`.
    ///
    ///
    /// Sesebelisoa se se nang letho se khutlisa `false`.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ho emisa `true` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ho phenyekolla karolo ea iterator e khotsofatsang lereho.
    ///
    /// `find()` e koala e khutlisetsang `true` kapa `false`.
    /// E sebetsa ho koaloa hona ho karolo ka 'ngoe ea iterator,' me haeba ho na le ba khutlisang `true`, `find()` e khutlisa [`Some(element)`].
    /// Haeba kaofela ba khutlisa `false`, e khutlisa [`None`].
    ///
    /// `find()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho sebetsa hang ha ho koaloa ho khutla `true`.
    ///
    /// Hobane `find()` e nka litšupiso, 'me lingoli tse ngata li pheta-pheta litšupiso, hona ho lebisa boemong bo ka ferekanyang moo khang e buang ka makhetlo a mabeli.
    ///
    /// U ka bona phello ena mehlaleng e ka tlase, ka `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ho emisa `true` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Hlokomela hore `iter.find(f)` e lekana le `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// E sebetsa ho likarolo tsa iterator ebe e khutlisa sephetho sa pele se seng.
    ///
    ///
    /// `iter.find_map(f)` e lekana le `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// E sebetsa ho likarolo tsa iterator ebe e khutlisa sephetho sa 'nete sa pele kapa phoso ea pele.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Ho batlisisa ntho ho iterator, ho khutlisa index ea eona.
    ///
    /// `position()` e koala e khutlisetsang `true` kapa `false`.
    /// E sebetsa ho koaloa hona ho karolo ka 'ngoe ea iterator,' me haeba e 'ngoe ea tsona e khutlisa `true`, `position()` e khutlisa [`Some(index)`].
    /// Haeba kaofela ha tsona li khutlisa `false`, e khutlisa [`None`].
    ///
    /// `position()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho e sebetsa hang ha e fumana `true`.
    ///
    /// # Boitšoaro bo khaphatsehang
    ///
    /// Mokhoa ona ha o itšireletse ho phallang, kahoo haeba ho na le lintho tse fetang [`usize::MAX`] tse sa amaneng, e ka hlahisa sephetho se fosahetseng kapa panics.
    ///
    /// Haeba lipolelo tsa ho etsa bothata li lumelloa, panic e netefalitsoe.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e kanna ea ba panic haeba iterator e na le likarolo tse fetang `usize::MAX` tse sa amaneng.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ho emisa `true` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Lenane le khutlisitsoeng le ipapisitse le mmuso oa iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Ho batlisisa ntho ho iterator ho tloha ka ho le letona, ho khutlisa index ea eona.
    ///
    /// `rposition()` e koala e khutlisetsang `true` kapa `false`.
    /// E sebetsa ho koaloa hona ho karolo e ngoe le e ngoe ea iterator, ho qala qetellong, 'me haeba e' ngoe ea tsona e khutlisa `true`, `rposition()` e khutlisa [`Some(index)`].
    ///
    /// Haeba kaofela ha tsona li khutlisa `false`, e khutlisa [`None`].
    ///
    /// `rposition()` e potoloha ka nakoana;ka mantsoe a mang, e tla emisa ho e sebetsa hang ha e fumana `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ho emisa `true` ea pele:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // re ntse re ka sebelisa `iter`, kaha ho na le likarolo tse ling.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ha ho hlokahale cheke ea ho khaphatseha mona, hobane `ExactSizeIterator` e fana ka maikutlo a hore palo ea likarolo e lekana le `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// E khutlisa palo e kholo ea iterator.
    ///
    /// Haeba likarolo tse 'maloa li lekana ka ho lekana, ntlha ea ho qetela ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// E khutlisa bonyane ba elemente ea sehlahlo.
    ///
    /// Haeba likarolo tse 'maloa li lekana ka mokhoa o lekanang, ntlha ea pele ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// E khutlisa ntho e fanang ka boleng bo phahameng ho tsoa ts'ebetsong e boletsoeng.
    ///
    ///
    /// Haeba likarolo tse 'maloa li lekana ka ho lekana, ntlha ea ho qetela ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// E kgutlisa elemente e fanang ka boleng bo hodimo mabapi le tshebetso e boletsweng ya papiso.
    ///
    ///
    /// Haeba likarolo tse 'maloa li lekana ka ho lekana, ntlha ea ho qetela ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// E khutlisetsa elemente e fanang ka boleng bo tlase ho tsoa ts'ebetsong e boletsoeng.
    ///
    ///
    /// Haeba likarolo tse 'maloa li lekana ka mokhoa o lekanang, ntlha ea pele ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// E khutlisa elemente e fanang ka boleng bo tlase mabapi le ts'ebetso e boletsoeng e bapisoang.
    ///
    ///
    /// Haeba likarolo tse 'maloa li lekana ka mokhoa o lekanang, ntlha ea pele ea khutlisoa.
    /// Haeba iterator e se na letho, [`None`] ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// E khutlisetsa morao tataiso ea iterator.
    ///
    /// Hangata, li pheta-pheta ho tloha ka letsohong le letšehali ho ea ho le letona.
    /// Kamora ho sebelisa `rev()`, iterator e tla iterate ho tloha ho le letona ho ea ho le letšehali.
    ///
    /// Sena se ka khonahala feela haeba iterator e na le pheletso, kahoo `rev()` e sebetsa feela ho [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// E fetola iterator ea lipara ka har'a lijana.
    ///
    /// `unzip()` e sebelisa iterator e felletseng ea lipara, e hlahisa likoleke tse peli: e le 'ngoe e tsoa linthong tsa leqele tsa lipara,' me e 'ngoe e tsoa linthong tse nepahetseng
    ///
    ///
    /// Mosebetsi ona ka tsela e itseng o fapane le [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// E theha sebapali se kopitsang likarolo tsohle tsa eona.
    ///
    /// Sena se na le thuso ha o na le iterator e fetang `&T`, empa o hloka iterator ho feta `T`.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopitsoa ho tšoana le .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// E theha sehlahlo seo [`clone`] se nang le likarolo tsohle tsa sona.
    ///
    /// Sena se na le thuso ha o na le iterator e fetang `&T`, empa o hloka iterator ho feta `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned e ts'oana le .map(|&x| x), bakeng sa linomoro
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// E pheta iterator ka ho sa feleng.
    ///
    /// Sebakeng sa ho emisa [`None`], iterator e tla qala hape, ho tloha qalong.Kamora ho pheta hape, e tla qala qalong hape.Mme hape.
    /// Mme hape.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// E akaretsa likarolo tsa sehlahlobi.
    ///
    /// E nka ntho ka 'ngoe, ea e kopanya ebe e khutlisa sephetho.
    ///
    /// Sesebelisoa se se nang letho se khutlisa boleng ba zero ba mofuta oo.
    ///
    /// # Panics
    ///
    /// Ha o letsetsa `sum()` mme mofuta oa khale oa linomoro o ntse o khutlisoa, mokhoa ona o tla panic haeba komporo e khaphatseha le lipolelo tsa ho etsa phoso e lumelloa.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates holim'a iterator eohle, e atisa likarolo tsohle
    ///
    /// Sesebelisoa se se nang letho se khutlisa boleng bo le bong ba mofuta.
    ///
    /// # Panics
    ///
    /// Ha o letsetsa `product()` mme mofuta oa khale oa khale o khutlisoa, mokhoa o tla panic haeba komporo e khaphatseha le lipolelo tsa ho etsa phoso e lumelloa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bapisa likarolo tsa [`Iterator`] le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bapisa likarolo tsa [`Iterator`] ena le tsa e ngoe mabapi le ts'ebetso e boletsoeng e bapisoang.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bapisa likarolo tsa [`Iterator`] le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bapisa likarolo tsa [`Iterator`] ena le tsa e ngoe mabapi le ts'ebetso e boletsoeng e bapisoang.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// E khetholla haeba likarolo tsa [`Iterator`] ena li lekana le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// E khetholla hore na likarolo tsa [`Iterator`] tsena li lekana le tsa e ngoe mabapi le ts'ebetso e lekantsoeng ea tekano.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// E etsa qeto ea hore na likarolo tsa [`Iterator`] tsena ha li tšoane le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// E khetholla haeba likarolo tsa [`Iterator`] li le [lexicographically](Ord#lexicographical-comparison) ka tlase ho tse ling.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// E khetholla haeba likarolo tsa [`Iterator`] li le [lexicographically](Ord#lexicographical-comparison) tlase kapa li lekana le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// E khetholla haeba likarolo tsa [`Iterator`] tsena li [lexicographically](Ord#lexicographical-comparison) ho feta tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// E khetholla haeba likarolo tsa [`Iterator`] tsena li [lexicographically](Ord#lexicographical-comparison) ho feta kapa ho lekana le tsa e 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// E hlahloba haeba likarolo tsa iterator ena li hlophisitsoe.
    ///
    /// Ka mantsoe a mang, bakeng sa elemente e ngoe le e ngoe `a` le karolo ea eona e latelang `b`, `a <= b` e tlameha ho ts'oara.Haeba iterator e hlahisa zero hantle kapa ntho e le 'ngoe, `true` ea khutlisoa.
    ///
    /// Hlokomela hore haeba `Self::Item` e le `PartialOrd` feela, empa e se `Ord`, tlhaloso e kaholimo e bolela hore ts'ebetso ena e khutlisa `false` haeba ho na le lintho tse peli tse latellanang tse sa bapisoang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// E hlahloba hore na likarolo tsa iterator tsena li hlophisitsoe ho sebelisoa mosebetsi o fanoeng oa papiso.
    ///
    /// Sebakeng sa ho sebelisa `PartialOrd::partial_cmp`, ts'ebetso ena e sebelisa ts'ebetso e fanoeng ea `compare` ho fumana tlhophiso ea likarolo tse peli.
    /// Ntle le moo, e lekana le [`is_sorted`];bona litokomane tsa eona bakeng sa tlhaiso-leseling e batsi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// E hlahloba haeba likarolo tsa iterator ena li hlophisitsoe ho sebelisoa ts'ebetso ea senotlolo e fanoeng.
    ///
    /// Sebakeng sa ho bapisa likarolo tsa iterator ka kotloloho, mosebetsi ona o bapisa linotlolo tsa likarolo, joalo ka ha ho khethiloe ke `f`.
    /// Ntle le moo, e lekana le [`is_sorted`];bona litokomane tsa eona bakeng sa tlhaiso-leseling e batsi.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Bona [TrustedRandomAccess]
    // Lebitso le sa tloaelehang ke ho qoba ho thulana ha mabitso tharollong ea mekhoa bona #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}