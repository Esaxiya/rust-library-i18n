//! `Clone` trait ea mefuta e ke keng ea 'kopitsoa ka botlalo'.
//!
//! Ho Rust, mefuta e meng e bonolo ke "implicitly copyable" mme ha o e abela kapa o e fetisa e le likhang, moamoheli o tla fumana kopi, a siee boleng ba mantlha bo le teng.
//! Mefuta ena ha e hloke kabo ea ho e kopitsa ebile ha e na ba phethelang (ke hore, ha e na mabokose a nang le thepa kapa e kenya [`Drop`]), ka hona, moqapi o e nka e le theko e tlase ebile e bolokehile ho e kopitsa.
//!
//! Bakeng sa mefuta e meng likopi li tlameha ho etsoa ka mokhoa o hlakileng, ka ho kenya tšebetsong [`Clone`] trait le ho bitsa mokhoa oa [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Mohlala oa ts'ebeliso ea mantlha:
//!
//! ```
//! let s = String::new(); // Mofuta oa likhoele o sebelisa Clone
//! let copy = s.clone(); // kahoo re ka khona ho e etsa
//! ```
//!
//! Ho kenya ts'ebetsong habonolo Clone trait, o ka sebelisa `#[derive(Clone)]`.Mohlala:
//!
//! ```
//! #[derive(Clone)] // re eketsa Clone trait ho Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // 'me joale re ka e kopanya!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait e tloaelehileng bakeng sa bokhoni ba ho etsisa ntho ka mokhoa o hlakileng.
///
/// E fapana le [`Copy`] ka hore [`Copy`] ha e na moelelo ebile e theko e tlase haholo, ha `Clone` e lula e hlakile ebile e kanna ea ba theko e tlase.
/// Bakeng sa ho tiisa litšobotsi tsena, Rust ha eu lumelle ho kenya [`Copy`] botjha, empa u ka kenya `Clone` hape 'me u tsamaise khoutu e hatellang.
///
/// Kaha `Clone` e akaretsa haholo ho feta [`Copy`], o ka etsa eng kapa eng [`Copy`] hore e be `Clone` hape.
///
/// ## Derivable
///
/// trait ena e ka sebelisoa le `#[derive]` haeba likarolo tsohle e le `Clone`.Ts'ebetso ea `derive`d ea [`Clone`] e letsetsa [`clone`] lebaleng ka leng.
///
/// [`clone`]: Clone::clone
///
/// Bakeng sa sebopeho sa generic, `#[derive]` e kenya `Clone` maemong ka ho eketsa tlamo `Clone` ka lipalo tse tloaelehileng.
///
/// ```
/// // `derive` lisebelisoa Clone bakeng sa ho bala<T>ha T e le Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Nka kenya `Clone` joang?
///
/// Mefuta e [`Copy`] e lokela ho ba le ts'ebetsong e nyane ea `Clone`.Ka mokhoa o tloaelehileng:
/// haeba `T: Copy`, `x: T`, le `y: &T`, `let x = y.clone();` e lekana le `let x = *y;`.
/// Ts'ebetsong ea letsoho e lokela ho ba hlokolosi ho ts'ehetsa se sa fetoheng sena;leha ho le joalo, khoutu e sa bolokehang ha ea lokela ho itšetleha ka eona ho netefatsa polokeho ea memori.
///
/// Mohlala ke sebopeho sa generic se tšoereng sesupa-mosebetsi.Maemong ana, ts'ebetsong ea `Clone` e ke ke ea etsoa `, empa e ka kengoa ts'ebetsong joalo ka:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Batlatsi ba bang
///
/// Ntle le [implementors listed below][impls], mefuta e latelang e kenya ts'ebetsong `Clone`:
///
/// * Mefuta ea lintho tsa mosebetsi (ke hore, mefuta e ikhethileng e hlalositsoeng bakeng sa tšebetso ka 'ngoe)
/// * Mefuta ea sesupi sa mosebetsi (mohlala, `fn() -> i32`)
/// * Mefuta ea mefuta, bakeng sa boholo bohle, haeba mofuta oa ntho le eona e sebelisa `Clone` (mohlala, `[i32; 123456]`)
/// * Mefuta ea Tuple, haeba karolo ka 'ngoe e sebelisa `Clone` (mohlala, `()`, `(i32, bool)`)
/// * Mefuta ea ho koala, haeba e sa fumane boleng ba tikoloho kapa haeba litekanyetso tsohle tse hapuoeng li kenya tšebetsong `Clone` ka botsona.
///   Hlokomela hore mefuta-futa e hapuoeng ke litšupiso tse arolelanoang e kenya ts'ebetsong `Clone` (le haeba sebapali se sa etse joalo), ha mefuta e hapuoeng ke litšupiso tse ka fetohang e sa sebelise `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// E khutlisa kopi ea boleng.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str lisebelisoa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// E etsa kopi-kabelo ho tloha `source`.
    ///
    /// `a.clone_from(&b)` e lekana le `a = b.clone()` ts'ebetsong, empa e ka hatelloa ho sebelisa lisebelisoa tsa `a` ho qoba likabo tse sa hlokahaleng.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Fumana tlhahiso e kholo ea trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): li-structs tsena li sebelisoa feela ke#[derive] ho tiisa hore karolo e ngoe le e ngoe ea mofuta e sebelisa Clone kapa Copy.
//
//
// Li-structs tsena ha lia lokela ho hlaha ka khoutu ea mosebelisi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ts'ebetsong ea `Clone` bakeng sa mefuta ea khale.
///
/// Ts'ebetsong e ke keng ea hlalosoa ho Rust e kenngwa ts'ebetsong ho `traits::SelectionContext::copy_clone_conditions()` ho `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Litšupiso tse arolelanoeng li ka hlophisoa, empa litšupiso tse ka feto-fetohang * li ke ke tsa khona!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Litšupiso tse arolelanoeng li ka hlophisoa, empa litšupiso tse ka feto-fetohang * li ke ke tsa khona!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}