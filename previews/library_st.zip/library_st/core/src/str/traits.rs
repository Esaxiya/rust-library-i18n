//! Ts'ebetsong ea Trait bakeng sa `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// E sebelisa ho odara ha likhoele.
///
/// Likhoele li laeloa [lexicographically](Ord#lexicographical-comparison) ka litekanyetso tsa bona tsa byte.
/// Sena se laela lintlha tsa khoutu ea Unicode ho latela maemo a bona lichate tsa khoutu.
/// Sena ha se hlile ha se tšoane le tatellano ea "alphabetical", e fapaneng ka puo le sebaka.
/// Ho hlophisa likhoele ho latela maemo a amoheloang ke moetlo ho hloka tlhaiso-leseling e ikhethileng ea lehae e kantle ho mofuta oa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// E sebelisa ts'ebetso ea papiso ka likhoele.
///
/// Likhoele li bapisoa le [lexicographically](Ord#lexicographical-comparison) ka litekanyetso tsa tsona tsa byte.
/// Sena se bapisa lintlha tsa khoutu ea Unicode ho latela maemo a tsona lichate tsa khoutu.
/// Sena ha se hlile ha se tšoane le tatellano ea "alphabetical", e fapaneng ka puo le sebaka.
/// Ho bapisa likhoele ho latela maemo a amoheloang ke moetlo ho hloka lintlha tse ikhethileng tsa sebaka seo se kantle ho mofuta oa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// E sebelisa substring slicing ka syntax `&self[..]` kapa `&mut self[..]`.
///
/// E khutlisa selae sa khoele eohle, ke hore, e khutlisa `&self` kapa `&mut self`.E lekana le `&self [0 ..
/// len] `kapa`&mut self [0 ..
/// len]`.
/// Ho fapana le lits'ebetso tse ling tsa indexing, hona ho ke ke ha hlola ho e-ba le panic.
///
/// Ts'ebetso ena ke *O*(1).
///
/// Pele ho 1.20.0, lits'ebetso tsena tsa li-index li ne li ntse li tšehelitsoe ke ho kenya tšebetsong ka kotloloho `Index` le `IndexMut`.
///
/// E lekana le `&self[0 .. len]` kapa `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// E sebelisa substring slicing ka syntax `&self[begin .. end]` kapa `&mut self[begin .. end]`.
///
/// E khutlisa selae sa khoele e fanoeng ho tloha ho li-byte [`qala`, `end`).
///
/// Ts'ebetso ena ke *O*(1).
///
/// Pele ho 1.20.0, lits'ebetso tsena tsa li-index li ne li ntse li tšehelitsoe ke ho kenya tšebetsong ka kotloloho `Index` le `IndexMut`.
///
/// # Panics
///
/// Panics haeba `begin` kapa `end` ha e supe qalo ea sebapali e qalang (joalo ka ha e hlalositsoe ke `is_char_boundary`), haeba `begin > end`, kapa `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // tsena li tla panic:
/// // byte 2 e bua ka hare ho `ö`:
/// // &s [2 ..3];
///
/// // byte 8 e bua leshano ka hare ho `老`&s [1 ..
/// // 8];
///
/// // byte 100 e kantle ho khoele&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TŠIRELETSO: o sa tsoa sheba hore `start` le `end` li moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            // Re boetse re hlahlobile meeli ea char, ka hona ena ke UTF-8 e sebetsang.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TŠIRELETSO: o sa tsoa sheba hore `start` le `end` li moeling oa char.
            // Rea tseba hore sesupi se ikhethile hobane re se fumane ho `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // TSHIRELETSO: moletsi o tiisa hore `self` e meeling ea `slice`
        // e khotsofatsang maemo ohle a `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // TŠIRELETSO: bona litlhaloso bakeng sa `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary e lekola hore index e ho [0, .len()] ha e khone ho sebelisa `get` joalo kaholimo, ka lebaka la bothata ba NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // TŠIRELETSO: o sa tsoa sheba hore `start` le `end` li moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// E sebelisa substring slicing ka syntax `&self[.. end]` kapa `&mut self[.. end]`.
///
/// E khutlisetsa selae sa khoele e fanoeng ho tloha ho li-byte [`0`, `end`).
/// E lekana le `&self[0 .. end]` kapa `&mut self[0 .. end]`.
///
/// Ts'ebetso ena ke *O*(1).
///
/// Pele ho 1.20.0, lits'ebetso tsena tsa li-index li ne li ntse li tšehelitsoe ke ho kenya tšebetsong ka kotloloho `Index` le `IndexMut`.
///
/// # Panics
///
/// Panics haeba `end` e sa supe khakanyo e qalang ea sebapali (joalo ka ha e hlalositsoe ke `is_char_boundary`), kapa haeba `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // TŠIRELETSO: o sa tsoa sheba hore `end` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // TŠIRELETSO: o sa tsoa sheba hore `end` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // TŠIRELETSO: o sa tsoa sheba hore `end` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// E sebelisa substring slicing ka syntax `&self[begin ..]` kapa `&mut self[begin ..]`.
///
/// E khutlisa selae sa khoele e fanoeng ho tloha ho li-byte [`qala`, `len`).E lekana le `&self [qala ..
/// len] `kapa`&mut self [qala ..
/// len]`.
///
/// Ts'ebetso ena ke *O*(1).
///
/// Pele ho 1.20.0, lits'ebetso tsena tsa li-index li ne li ntse li tšehelitsoe ke ho kenya tšebetsong ka kotloloho `Index` le `IndexMut`.
///
/// # Panics
///
/// Panics haeba `begin` e sa supe khakanyo e qalang ea sebapali (joalo ka ha e hlalositsoe ke `is_char_boundary`), kapa haeba `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // TŠIRELETSO: o sa tsoa sheba hore `start` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // TŠIRELETSO: o sa tsoa sheba hore `start` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // TSHIRELETSO: moletsi o tiisa hore `self` e meeling ea `slice`
        // e khotsofatsang maemo ohle a `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // TŠIRELETSO: e ts'oanang le `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // TŠIRELETSO: o sa tsoa sheba hore `start` e moeling oa char,
            // 'me re fetisa moo ho buuoang ka mokhoa o sireletsehileng, ka hona boleng ba ho khutlisa le bona bo tla ba mong.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// E sebelisa substring slicing ka syntax `&self[begin ..= end]` kapa `&mut self[begin ..= end]`.
///
/// E khutlisa selae sa khoele e fanoeng ho tloha ho li-byte [`begin`, `end`].E lekana le `&self [begin .. end + 1]` kapa `&mut self[begin .. end + 1]`, ntle le haeba `end` e na le boleng bo holimo bakeng sa `usize`.
///
/// Ts'ebetso ena ke *O*(1).
///
/// # Panics
///
/// Panics haeba `begin` e sa supe moetso o qalang oa motho (joalo ka ha ho hlalositsoe ke `is_char_boundary`), haeba `end` e sa supe moelelo o felang oa sebapali (`end + 1` ekaba ke offset ea byte e qalang kapa e lekana le `len`), haeba `begin > end`, kapa haeba `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// E sebelisa substring slicing ka syntax `&self[..= end]` kapa `&mut self[..= end]`.
///
/// E khutlisa selae sa khoele e fanoeng ho tloha ho li-byte [0, `end`].
/// E lekana le `&self [0 .. end + 1]`, ntle le haeba `end` e na le boleng bo holimo bakeng sa `usize`.
///
/// Ts'ebetso ena ke *O*(1).
///
/// # Panics
///
/// Panics haeba `end` e sa supe pheletso ea motho (`end + 1` e ka ba offset e qalang joalokaha e hlalositsoe ke `is_char_boundary`, kapa e lekana le `len`), kapa haeba `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Bapisa boleng ho tloha khoeleng
///
/// Mokhoa oa [`from_str`] o tsoang hoStr o sebelisoa khafetsa, ka mokhoa oa [`str`] oa [`parse`].
/// Bona litokomane tsa [`parse`] bakeng sa mehlala.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ha e na parameter ea bophelo bohle, ka hona o ka hlahisa mefuta feela e se nang parameter ea bophelo bohle.
///
/// Ka mantsoe a mang, o ka bala `i32` le `FromStr`, empa eseng `&i32`.
/// O ka bala sebopeho se nang le `i32`, empa eseng se nang le `&i32`.
///
/// # Examples
///
/// Ts'ebetso ea mantlha ea `FromStr` ka mohlala mofuta oa `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Phoso e amanang le eona e ka khutlisoang ho tloha ho paring.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ho hlakola khoele `s` ho khutlisa boleng ba mofuta ona.
    ///
    /// Haeba ho hlophisa ho atleha, khutlisa boleng kahare ho [`Ok`], ho seng joalo ha thapo e sa hlophisoa hantle e khutlise phoso e ikhethang kahare ho [`Err`].
    /// Mofuta oa phoso o totobetse ts'ebetsong ea trait.
    ///
    /// # Examples
    ///
    /// Tšebeliso ea mantlha le [`i32`], mofuta o sebelisang `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Hlahloba `bool` ho tloha khoeleng.
    ///
    /// E hlahisa `Result<bool, ParseBoolError>`, hobane `s` e kanna ea tsebahala kapa e kanna ea se bonahale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Hlokomela, maemong a mangata, mokhoa oa `.parse()` ho `str` o nepahetse ho feta.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}