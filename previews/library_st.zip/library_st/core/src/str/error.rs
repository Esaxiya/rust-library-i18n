//! E hlalosa mofuta oa phoso ea utf8.

use crate::fmt;

/// Liphoso tse ka etsahalang ha u leka ho toloka tatellano ea [`u8`] joalo ka khoele.
///
/// Kahoo, lelapa la `from_utf8` la mesebetsi le mekhoa ea bona ka bobeli [`String`] s le [`&str`] ba sebelisa phoso ena, mohlala.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Mekhoa ea mofuta ona oa phoso e ka sebelisoa ho theha ts'ebetso e ts'oanang le `String::from_utf8_lossy` ntle le ho fana ka mohopolo oa qubu:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// E khutlisa index ka khoele e fanoeng ho fihlela UTF-8 e netefalitsoeng.
    ///
    /// Ke index e phahameng haholo hoo `from_utf8(&input[..index])` e ka khutlang `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// use std::str;
    ///
    /// // li-byte tse sa sebetseng, ho vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 e khutlisa Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // byte ea bobeli ha e na thuso mona
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// E fana ka tlhaiso-leseling e batsi ka ho hloleha:
    ///
    /// * `None`: pheletso ea kenyelletso e fihlelletsoe ho sa lebelloa.
    ///   `self.valid_up_to()` ke li-byte tse 1 ho isa ho tse 3 ho tloha pheletsong ea kenyelletso.
    ///   Haeba molatsoana oa byte (joalo ka faele kapa sokisi ea netweke) o ntse o khethoa hofeta, sena ekaba `char` e sebetsang eo tatellano ea eona ea UTF-8 e fetang likaroloana tse ngata.
    ///
    ///
    /// * `Some(len)`: ho ile ha teana le byte e sa lebelloang.
    ///   Bolelele bo fanoeng ke ba tatellano ea li-byte e sa sebetseng e qalang ho index e fanoeng ke `valid_up_to()`.
    ///   Ho khetholla ho lokela ho qalella kamora tatellano eo (kamora ho kenya [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) haeba ho ka senyeha khetho.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Phoso e khutlisitsoe ha ho hlakoloa `bool` e sebelisa [`from_str`] e hloleha
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}