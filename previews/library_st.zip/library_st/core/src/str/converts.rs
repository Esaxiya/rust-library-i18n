//! Litsela tsa ho theha `str` ho tsoa ho li-byte.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// E fetola selae sa li-byte hore e be khoele ea khoele.
///
/// Selae sa khoele ([`&str`]) se entsoe ka li-byte ([`u8`]), 'me selae sa byte ([`&[u8]`][byteslice]) se entsoe ka li-byte, kahoo ts'ebetso ena e fetoha lipakeng tsa tse peli.
/// Ha se likhechana tsohle tsa byte tse nang le likotoana tsa likhoele tse sebetsang, leha ho le joalo: [`&str`] e hloka hore e sebetse UTF-8.
/// `from_utf8()` licheke ho netefatsa hore li-byte li nepahetse UTF-8, ebe e etsa phetoho.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Haeba u na le bonnete ba hore selae sa byte se nepahetse UTF-8, 'me ha u batle ho ba le sehlooho sa tlhahlobo e nepahetseng, ho na le mofuta o sa bolokehang oa ts'ebetso ena, [`from_utf8_unchecked`], e nang le boits'oaro bo ts'oanang empa e tlola cheke.
///
///
/// Haeba o hloka `String` ho fapana le `&str`, nahana ka [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Hobane o ka kenya `[u8; N]` ka bongata, 'me o ka nka [`&[u8]`][byteslice] ea eona, mosebetsi ona ke tsela e le' ngoe ea ho ba le khoele e abetsoeng stack.Ho na le mohlala oa sena karolong ea mehlala e ka tlase.
///
/// [byteslice]: slice
///
/// # Errors
///
/// E khutlisa `Err` haeba selae ha se UTF-8 se nang le tlhaloso ea hore na hobaneng selae se fanoeng e se UTF-8.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::str;
///
/// // li-byte, ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Rea tseba hore li-byte tsena li nepahetse, kahoo sebelisa `unwrap()` feela.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Li-byte tse fosahetseng:
///
/// ```
/// use std::str;
///
/// // li-byte tse sa sebetseng, ho vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Bona litokomane tsa [`Utf8Error`] bakeng sa lintlha tse ling mabapi le mefuta ea liphoso tse ka khutlisoang.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // li-byte tse ling, ka bongata bo arotsoeng ka bongata
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Rea tseba hore li-byte tsena li nepahetse, kahoo sebelisa `unwrap()` feela.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // TSHIRELETSO: Ho netefatsa feela.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// E fetola selae se ka feto-fetohang sa sengoathoana sa khoele.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" joalo ka vector e fetohang
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Joalokaha re tseba li-byte tsena li nepahetse, re ka sebelisa `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Li-byte tse fosahetseng:
///
/// ```
/// use std::str;
///
/// // Li-byte tse sa sebetseng ho vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Bona litokomane tsa [`Utf8Error`] bakeng sa lintlha tse ling mabapi le mefuta ea liphoso tse ka khutlisoang.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // TSHIRELETSO: Ho netefatsa feela.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// E fetola selae sa li-byte mohaleng oa khoele ntle le ho netefatsa hore khoele e na le UTF-8 e sebetsang.
///
/// Bona mofuta o bolokehileng, [`from_utf8`], bakeng sa tlhaiso-leseling e batsi.
///
/// # Safety
///
/// Mosebetsi ona ha o bolokehe hobane ha o hlahlobe hore li-byte tse fetisitsoeng ho oona li nepahetse UTF-8.
/// Haeba thibelo ena e tloloa, boitšoaro bo sa hlaloseheng bo hlahisa litholoana, joalo ka ha Rust kaofela e nka hore [`&str`] s li nepahetse UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::str;
///
/// // li-byte, ka vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore li-byte `v` li nepahetse UTF-8.
    // E boetse e itšetleha ka `&str` le `&[u8]` e nang le sebopeho se tšoanang.
    unsafe { mem::transmute(v) }
}

/// E fetola selae sa li-byte mohaleng oa khoele ntle le ho lekola hore khoele e na le UTF-8 e sebetsang;Mofuta o ka fetohang.
///
///
/// Bona mofuta o sa fetoheng, [`from_utf8_unchecked()`] bakeng sa tlhaiso-leseling e batsi.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore li-byte `v`
    // li nepahetse UTF-8, ka hona, samente ho `*mut str` e bolokehile.
    // Hape, litšupiso tsa pointer li bolokehile hobane sesupa-tsela seo se tsoa bukaneng e netefalitsoeng hore e nepahetse bakeng sa ho ngola.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}