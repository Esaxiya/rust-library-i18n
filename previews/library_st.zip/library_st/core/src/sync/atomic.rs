//! Mefuta ea Atomic
//!
//! Mefuta ea athomo e fana ka puisano ea khale ea mohopolo o arolelanoang pakeng tsa likhoele, 'me ke litšiea tsa mefuta e meng e tšoanang.
//!
//! Mojule ona o hlalosa mefuta ea khale ea liatomic, ho kenyelletsa [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], jj.
//! Mefuta ea Atomic e hlahisa tšebetso eo ha e sebelisoa ka nepo e lumellanang lintlafatso lipakeng tsa likhoele.
//!
//! Mokhoa o mong le o mong o nka [`Ordering`] e emelang matla a mokoallo oa mohopolo oa ts'ebetso eo.Liodara tsena li ts'oana le [C++20 atomic orderings][1].Bakeng sa tlhaiso-leseling e batsi bona [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Mefuta-futa ea liathomo e bolokehile ho arolelanoa lipakeng tsa likhoele (li kenya ts'ebetsong [`Sync`]) empa ha tsona ka botsona li fana ka mochini oa ho arolelana le ho latela [threading model](../../../std/thread/index.html#the-threading-model) ea Rust.
//!
//! Mokhoa o tloaelehileng haholo oa ho arolelana phapano ea athomo ke ho o kenya ka [`Arc`][arc] (sesupa-palo se arolelanoang se sebetsanang le atomiki).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Mefuta ea Atomic e ka bolokoa ka mefuta e fapaneng, e qalileng ho sebelisoa li-initializers tse sa fetoheng joaloka [`AtomicBool::new`].Hangata li-statics tsa athomo li sebelisoa bakeng sa ho qala lefatše ka botsoa.
//!
//! # Portability
//!
//! Mefuta eohle ea athomo mojulung ona e netefalitsoe hore e tla ba [lock-free] haeba e fumaneha.Sena se bolela hore kahare ha ba fumane limmx tsa lefats'e.Mefuta le ts'ebetso ea athomo ha e netefatsoe hore e ke ke ea emela.
//! Sena se bolela hore ts'ebetso e kang `fetch_or` e ka kengoa tšebetsong ka lupu ea papiso-le-ho fapanyetsana.
//!
//! Ts'ebetso ea athomo e ka kengoa tšebetsong mokatong oa litaelo ka liathomiki tse boholo bo boholo.Mohlala, liforomo tse ling li sebelisa litaelo tsa 4-byte atomic ho kenya ts'ebetsong `AtomicI8`.
//! Hlokomela hore emulation ena ha ea lokela ho ba le tšusumetso ho nepahala ha khoutu, ke ntho eo u lokelang ho e tseba.
//!
//! Mefuta ea athomo mojuleng ona e kanna ea se fumanehe lipulong tsohle.Mefuta ea athomo mona kaofela e fumaneha hohle, leha ho le joalo, 'me ka kakaretso ho ka itšetleha ka e teng.Likhetho tse ling tse tsebahalang ke:
//!
//! * PowerPC le li-platform tsa MIPS tse nang le litsupa tse 32-bit ha li na mefuta ea `AtomicU64` kapa `AtomicI64`.
//! * ARM liforomo tse kang `armv5te` tseo e seng tsa Linux li fana feela ka ts'ebetso ea `load` le `store`, 'me ha li tšehetse ho bapisa le ho chencha ts'ebetso ea (CAS), joalo ka `swap`, `fetch_add`, jj.
//! Ntle le moo ho Linux, ts'ebetso ena ea CAS e kengoa tšebetsong ka [operating system support], e ka tlisoang ke kotlo ea ts'ebetso.
//! * ARM liphofu tse nang le `thumbv6m` li fana feela ka ts'ebetso ea `load` le `store`, 'me ha e tšehetse mesebetsi ea Bapisa le ho Fapanya (CAS), joalo ka `swap`, `fetch_add`, jj.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Hlokomela hore li-platform tsa future li ka eketsoa hape ha li na ts'ehetso bakeng sa ts'ebetso e itseng ea athomo.Khoutu e nkehang habonolo e tla batla ho ba hlokolosi hore na ho sebelisoa mefuta efe ea athomo.
//! `AtomicUsize` 'me `AtomicIsize` ka kakaretso ke tsona tse nkehang habonolo, empa leha ho le joalo ha li fumanehe kae kapa kae.
//! Bakeng sa litšupiso, laebrari ea `std` e hloka liathomo tse boholo bo supang, leha `core` e sa e batle.
//!
//! Hajoale o tla hloka ho sebelisa `#[cfg(target_arch)]` haholoholo ho hlophisa khoutu le liathomiki.Ho na le `#[cfg(target_has_atomic)]` e sa tsitsang hape e ka tsitsisoang future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Sesebelisoa se bonolo:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Emela khoele e 'ngoe ho lokolla senotlolo
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Boloka palo ea lefatše ea likhoele tse phelang:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Mofuta oa boolean o ka arolelanoang ka polokeho lipakeng tsa likhoele.
///
/// Mofuta ona o na le setšoantšo se ts'oanang sa mohopolo joalo ka [`bool`].
///
/// **Tlhokomeliso**: Mofuta ona o fumaneha feela lipulong tse tšehetsang mejaro ea athomo le mabenkele a `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// E etsa `AtomicBool` e qalileng ho `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Romela e kentsoe ts'ebetsong bakeng sa AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Mofuta oa sesupa se tala o ka arolelanoang ka polokeho lipakeng tsa likhoele.
///
/// Mofuta ona o na le setšoantšo se ts'oanang sa mohopolo joalo ka `*mut T`.
///
/// **Tlhokomeliso**: Mofuta ona o fumaneha feela lipulong tse tšehetsang meroalo ea athomo le mabenkele a litsupa.
/// Boholo ba eona bo latela boholo ba sesupi sa sepheo.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// E theha n00 `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Litlhophiso tsa memori ea Atomic
///
/// Litlhophiso tsa memori li hlakisa tsela eo ts'ebetso ea athomo e hokahanyang memori.
/// Ho [`Ordering::Relaxed`] ea eona e fokolang, ke memori e amiloeng ka kotloloho ke ts'ebetso e lumellanang.
/// Ka lehlakoreng le leng, para ea mojaro oa lebenkele ea [`Ordering::SeqCst`] e hokahanya mohopolo o mong ha o ntse o boloka tatellano ea ts'ebetso e joalo ho likhoele tsohle.
///
///
/// Li-memory tsa Rust ke [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Bakeng sa tlhaiso-leseling e batsi bona [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ha ho na lithibelo tsa ho odara, ke ts'ebetso ea athomo feela.
    ///
    /// E tsamaellana le [`memory_order_relaxed`] ho C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Ha li kopantsoe le lebenkele, lits'ebetso tsohle tse fetileng li laeloa pele ho mojaro ofe kapa ofe oa boleng bona ka odara ea [`Acquire`] (kapa e matla ho feta).
    ///
    /// Ka ho khetheha, lingoloa tsohle tse fetileng li ka bonahala ho likhoele tsohle tse etsang mojaro oa [`Acquire`] (kapa o matla ho feta) oa boleng bona.
    ///
    /// Hlokomela hore ho sebelisa odara ena bakeng sa ts'ebetso e kopanyang mejaro le mabenkele ho lebisa ts'ebetsong ea mojaro oa [`Relaxed`]!
    ///
    /// Taelo ena e sebetsa feela bakeng sa ts'ebetso e ka etsang lebenkele.
    ///
    /// E tsamaellana le [`memory_order_release`] ho C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ha e kopantsoe le mojaro, haeba boleng bo laetsoeng bo ngotsoe ke ts'ebetso ea lebenkele ka taelo ea [`Release`] (kapa e matla ho feta), lits'ebetso tsohle tse latelang li tla laeloa kamora lebenkele leo.
    /// Ka ho khetheha, mejaro eohle e latelang e tla bona data e ngotsoe pele ho lebenkele.
    ///
    /// Hlokomela hore ho sebelisa odara ena bakeng sa ts'ebetso e kopanyang mejaro le mabenkele ho lebisa ts'ebetsong ea lebenkele la [`Relaxed`]!
    ///
    /// Taelo ena e sebetsa feela bakeng sa ts'ebetso e ka jarang.
    ///
    /// E tsamaellana le [`memory_order_acquire`] ho C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// E na le litlamorao tsa [`Acquire`] le [`Release`] hammoho:
    /// Bakeng sa mejaro e sebelisa ho odara [`Acquire`].Bakeng sa mabenkele e sebelisa tatellano ea [`Release`].
    ///
    /// Hlokomela hore maemong a `compare_and_swap`, ho ka etsahala hore ts'ebetso e qetelle e sa etse lebenkele lefe kapa lefe ka hona e na le taelo ea [`Acquire`] feela.
    ///
    /// Leha ho le joalo, `AcqRel` e ke ke ea etsa phihlello ea [`Relaxed`].
    ///
    /// Ho odara hona ho sebetsa feela bakeng sa ts'ebetso e kopanyang mejaro le mabenkele ka bobeli.
    ///
    /// E tsamaellana le [`memory_order_acq_rel`] ho C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Jwalo ka [`Acquire`]/[`Release`]/[`AcqRel`](for load, store, and load-with-store operations, ngokulandelanang) le netefatso e tlatselletsang ea hore likhoele tsohle li bona mesebetsi eohle e lumellanang ka tatellano e le 'ngoe .
    ///
    ///
    /// E tsamaellana le [`memory_order_seq_cst`] ho C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] e qalile ho `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// E theha `AtomicBool` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// E khutlisetsa ts'upiso e ka fetoloang ho [`bool`] ea mantlha.
    ///
    /// Sena se bolokehile hobane ts'upiso e ka fetohang e tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e tšoanang data ea athomo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // TSHIRELETSO: referense e ka fetohang e tiisa ho ba mong ka mokhoa o ikhethileng.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Fumana phihlello ea athomo ho `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // TSHIRELETSO: referense e ka fetohang e tiisa ho ba mong, mme
        // ho tsamaellana ha `bool` le `Self` ke 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// E sebelisa athomo ebe e khutlisa boleng bo nang le eona.
    ///
    /// Sena se bolokehile hobane ho fetisa `self` ka boleng ho tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e le ngoe data ea athomo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// E jara boleng ho tsoa ho bool.
    ///
    /// `load` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Litekanyetso tse ka bang teng ke [`SeqCst`], [`Acquire`] le [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haeba `order` ke [`Release`] kapa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // TŠIRELETSO: merabe efe kapa efe ea data e thibeloa ke liathomo tsa tlhaho le tse tala
        // sesupi se fetisitsoeng sea sebetsa hobane re se fumane ho tsoa ho litšupiso.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// E boloka boleng ho bool.
    ///
    /// `store` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Litekanyetso tse ka bang teng ke [`SeqCst`], [`Release`] le [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haeba `order` ke [`Acquire`] kapa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // TŠIRELETSO: merabe efe kapa efe ea data e thibeloa ke liathomo tsa tlhaho le tse tala
        // sesupi se fetisitsoeng sea sebetsa hobane re se fumane ho tsoa ho litšupiso.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// E boloka boleng ho bool, e khutlise boleng ba pejana.
    ///
    /// `swap` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// E boloka boleng ho [`bool`] haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Nako ea ho khutlisa e lula e le boleng bo fetileng.Haeba e lekana le `current`, boleng bo tla ntlafatsoa.
    ///
    /// `compare_and_swap` hape e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Hlokomela hore leha o sebelisa [`AcqRel`], ts'ebetso e kanna ea hloleha mme ka hona etsa feela mojaro oa `Acquire`, empa o se na semantiki sa `Release`.
    /// Ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`] haeba e etsahala, 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Ho fallela `compare_exchange` le `compare_exchange_weak`
    ///
    /// `compare_and_swap` e lekana le `compare_exchange` ka 'mapa o latelang oa tatellano ea memori:
    ///
    /// Ea pele |Katleho |Ho hloleha
    /// -------- | ------- | -------
    /// Phomolo |Phomolo |Fumana Phomolo |Fumana |Fumana Phatlalatso |Lokolla |Phomolo AcqRel |AcqRel |Fumana SeqCst |SeqCst |SEQCst
    ///
    /// `compare_exchange_weak` e lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e lumellang moqapi hore a hlahise khoutu e ntle ea kopano ha ho bapisoa le ho fapanyetsana ho sebelisoa moleng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// E boloka boleng ho [`bool`] haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
    /// Ho katleho katleho ena e netefalitsoe hore e lekana le `current`.
    ///
    /// `compare_exchange` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
    /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
    ///
    /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// E boloka boleng ho [`bool`] haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Ho fapana le [`AtomicBool::compare_exchange`], ts'ebetso ena e lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e ka hlahisang khoutu e sebetsang hantle ho feta lipulong tse ling.
    ///
    /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
    ///
    /// `compare_exchange_weak` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
    /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
    /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" e nang le boleng ba boolean.
    ///
    /// E etsa ts'ebetso e utloahalang ea "and" ka boleng ba hona joale le khang ea `val`, 'me e beha boleng bo bocha ho sephetho.
    ///
    /// E khutlisa boleng bo fetileng.
    ///
    /// `fetch_and` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" e nang le boleng ba boolean.
    ///
    /// E etsa ts'ebetso e utloahalang ea "nand" ka boleng ba hona joale le khang ea `val`, 'me e beha boleng bo bocha ho sephetho.
    ///
    /// E khutlisa boleng bo fetileng.
    ///
    /// `fetch_nand` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Re ke ke ra sebelisa atomic_nand mona hobane e ka fella ka bool e nang le boleng bo sa sebetseng.
        // Sena se etsahala hobane ts'ebetso ea athomo e etsoa ka 8-bit integer kahare, e ka behang li-bits tse 7 tse kaholimo.
        //
        // Kahoo re sebelisa fetch_xor kapa swap ho fapana.
        if val {
            // (x&true)== !x Re tlameha ho khelosa bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&bohata)=='nete Re tlameha ho beha bool hore e be' nete.
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" e nang le boleng ba boolean.
    ///
    /// E etsa ts'ebetso e utloahalang ea "or" ka boleng ba hona joale le khang ea `val`, 'me e beha boleng bo bocha ho sephetho.
    ///
    /// E khutlisa boleng bo fetileng.
    ///
    /// `fetch_or` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" e nang le boleng ba boolean.
    ///
    /// E etsa ts'ebetso e utloahalang ea "xor" ka boleng ba hona joale le khang ea `val`, 'me e beha boleng bo bocha ho sephetho.
    ///
    /// E khutlisa boleng bo fetileng.
    ///
    /// `fetch_xor` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// E khutlisetsa sesupa se ka fetohang ho [`bool`] e ka tlase.
    ///
    /// Ho bala se seng sa athomo le ho ngola ho lenane le hlahisoang e ka ba peiso ea data.
    /// Mokhoa ona o sebetsa haholo ho FFI, moo saena ea ts'ebetso e ka sebelisang `*mut bool` sebakeng sa `&AtomicBool`.
    ///
    /// Ho khutlisa sesupa sa `*mut` ho tloha moo ho buuoang ka atomic ena ho bolokehile hobane mefuta ea athomo e sebetsa ka ho fetoha ha kahare.
    /// Liphetoho tsohle tsa athomo li fetola boleng ka ts'ebeliso e arolelanoeng, 'me li ka li etsa ka polokeho ha feela li sebelisa ts'ebetso ea athomo.
    /// Ts'ebeliso efe kapa efe ea pointer e khutlisitsoeng e sa hlakoang e hloka `unsafe` block mme e ntse e tlameha ho boloka thibelo e ts'oanang: ts'ebetso ho eona e tlameha ho ba athomo.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// E nka boleng, ebe e sebelisa tšebetso ho eona e khutlisang boleng bo bocha bo ikhethileng.E khutlisa `Result` ea `Ok(previous_value)` haeba ts'ebetso e khutlisitse `Some(_)`, ha ho na le `Err(previous_value)`.
    ///
    /// Note: Sena se ka bitsa ts'ebetso makhetlo a mangata haeba boleng bo fetotsoe ho tsoa ho likhoele tse ling hajoale, ha feela mosebetsi o khutlisa `Some(_)`, empa ts'ebetso e tla be e sebelisitsoe hang feela ho boleng bo bolokiloeng.
    ///
    ///
    /// `fetch_update` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// Ea pele e hlalosa taelo e hlokehang ea hore na ts'ebetso e tla qetella e atlehile ha ea bobeli e hlalosa taelo e hlokahalang ea mejaro.
    /// Tsena li tsamaellana le katleho le tatellano ea [`AtomicBool::compare_exchange`] ka tatellano.
    ///
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro oa ho qetela o atlehileng [`Relaxed`].
    /// Taelo ea (failed) ea mojaro e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// E theha `AtomicPtr` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// E khutlisetsa ts'upiso e ka fetohang ho sesupa sa mantlha.
    ///
    /// Sena se bolokehile hobane ts'upiso e ka fetohang e tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e tšoanang data ea athomo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Fumana phihlello ea athomo ho sesupa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - tšupiso e ka fetohang e tiisa ho ba mong ka mokhoa o ikhethang.
        //  - ho tsamaellana ha `*mut T` le `Self` hoa tšoana lipapaling tsohle tse tšehelitsoeng ke rust, joalo ka ha ho netefalitsoe kaholimo.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// E sebelisa athomo ebe e khutlisa boleng bo nang le eona.
    ///
    /// Sena se bolokehile hobane ho fetisa `self` ka boleng ho tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e le ngoe data ea athomo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// E kenya boleng ho tsoa ho sesupa.
    ///
    /// `load` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Litekanyetso tse ka bang teng ke [`SeqCst`], [`Acquire`] le [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haeba `order` ke [`Release`] kapa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// E boloka boleng ho sesupa.
    ///
    /// `store` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Litekanyetso tse ka bang teng ke [`SeqCst`], [`Release`] le [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics haeba `order` ke [`Acquire`] kapa [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// E boloka boleng ho sesupa, e khutlisa boleng ba pejana.
    ///
    /// `swap` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
    /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo litsing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// E boloka boleng ho sesupa haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Nako ea ho khutlisa e lula e le boleng bo fetileng.Haeba e lekana le `current`, boleng bo tla ntlafatsoa.
    ///
    /// `compare_and_swap` hape e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
    /// Hlokomela hore leha o sebelisa [`AcqRel`], ts'ebetso e kanna ea hloleha mme ka hona etsa feela mojaro oa `Acquire`, empa o se na semantiki sa `Release`.
    /// Ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`] haeba e etsahala, 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo litsing.
    ///
    /// # Ho fallela `compare_exchange` le `compare_exchange_weak`
    ///
    /// `compare_and_swap` e lekana le `compare_exchange` ka 'mapa o latelang oa tatellano ea memori:
    ///
    /// Ea pele |Katleho |Ho hloleha
    /// -------- | ------- | -------
    /// Phomolo |Phomolo |Fumana Phomolo |Fumana |Fumana Phatlalatso |Lokolla |Phomolo AcqRel |AcqRel |Fumana SeqCst |SeqCst |SEQCst
    ///
    /// `compare_exchange_weak` e lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e lumellang moqapi hore a hlahise khoutu e ntle ea kopano ha ho bapisoa le ho fapanyetsana ho sebelisoa moleng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// E boloka boleng ho sesupa haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
    /// Ho katleho katleho ena e netefalitsoe hore e lekana le `current`.
    ///
    /// `compare_exchange` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
    /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
    ///
    /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo litsing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// E boloka boleng ho sesupa haeba boleng ba hona joale bo lekana le boleng ba `current`.
    ///
    /// Ho fapana le [`AtomicPtr::compare_exchange`], ts'ebetso ena e lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e ka hlahisang khoutu e sebetsang hantle ho feta lipulong tse ling.
    ///
    /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
    ///
    /// `compare_exchange_weak` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
    /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
    /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo litsing.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TSHIRELETSO: Ts'ebetso ena ea tlhaho ha e bolokehe hobane e sebetsa ka sesupi se tala
        // empa re tseba ehlile hore sesupi se nepahetse (re sa tsoa se fumana ho `UnsafeCell` eo re nang le eona ka ts'upiso) mme ts'ebetso ea athomo ka boeona e re lumella ho fetola litaba tsa `UnsafeCell` ka polokeho.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// E nka boleng, ebe e sebelisa tšebetso ho eona e khutlisang boleng bo bocha bo ikhethileng.E khutlisa `Result` ea `Ok(previous_value)` haeba ts'ebetso e khutlisitse `Some(_)`, ha ho na le `Err(previous_value)`.
    ///
    /// Note: Sena se ka bitsa ts'ebetso makhetlo a mangata haeba boleng bo fetotsoe ho tsoa ho likhoele tse ling hajoale, ha feela mosebetsi o khutlisa `Some(_)`, empa ts'ebetso e tla be e sebelisitsoe hang feela ho boleng bo bolokiloeng.
    ///
    ///
    /// `fetch_update` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
    /// Ea pele e hlalosa taelo e hlokehang ea hore na ts'ebetso e tla qetella e atlehile ha ea bobeli e hlalosa taelo e hlokahalang ea mejaro.
    /// Tsena li tsamaellana le katleho le tatellano ea [`AtomicPtr::compare_exchange`] ka tatellano.
    ///
    /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro oa ho qetela o atlehileng [`Relaxed`].
    /// Taelo ea (failed) ea mojaro e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
    ///
    /// **Note:** Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo litsing.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// E fetola `bool` hore e be `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Macro ena e qetella e sa sebelisoe meahong e meng ea meralo.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Mofuta o lekanang o ka arolelanoang ka polokeho lipakeng tsa likhoele.
        ///
        /// Mofuta ona o na le setšoantšo se ts'oanang sa mohopolo joalo ka mofuta oa mantlha, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Ho fumana lintlha tse ling ka phapang lipakeng tsa mefuta ea athomo le e seng ea atomiki hammoho le tlhaiso-leseling ka ho khoneha ha mofuta ona, ka kopo bona [module-level documentation].
        ///
        ///
        /// **Note:** Mofuta ona o fumaneha feela lipulong tse tšehetsang mejaro ea athomo le mabenkele a [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Nomoro ea atomic e qalileng ho `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Romela e kentsoe tšebetsong ka botlalo.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// E theha palo e ncha ea athomo.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// E khutlisetsa litšupiso tse ka fetoloang ho palo e akaretsang.
            ///
            /// Sena se bolokehile hobane ts'upiso e ka fetohang e tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e tšoanang data ea athomo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// tlohella tse ling_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// tiisa_eq! (tse ling_e, tse 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - tšupiso e ka fetohang e tiisa ho ba mong ka mokhoa o ikhethang.
                //  - ho tsamaellana ha `$int_type` le `Self` hoa tšoana, joalo ka ha ho ts'episitsoe ke $cfg_align mme ho netefalitsoe kaholimo.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// E sebelisa athomo ebe e khutlisa boleng bo nang le eona.
            ///
            /// Sena se bolokehile hobane ho fetisa `self` ka boleng ho tiisa hore ha ho na likhoele tse ling tse fihlelang ka nako e le ngoe data ea athomo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// E jara boleng ho tsoa ho palo ea athomo.
            ///
            /// `load` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
            /// Litekanyetso tse ka bang teng ke [`SeqCst`], [`Acquire`] le [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics haeba `order` ke [`Release`] kapa [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// E boloka boleng ho palo ea athomo.
            ///
            /// `store` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
            ///  Litekanyetso tse ka bang teng ke [`SeqCst`], [`Release`] le [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics haeba `order` ke [`Acquire`] kapa [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// E boloka boleng ho palo ea athomo, e khutlise boleng ba pejana.
            ///
            /// `swap` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// E boloka boleng ho palo ea athomo haeba boleng ba hona joale bo lekana le boleng ba `current`.
            ///
            /// Nako ea ho khutlisa e lula e le boleng bo fetileng.Haeba e lekana le `current`, boleng bo tla ntlafatsoa.
            ///
            /// `compare_and_swap` hape e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.
            /// Hlokomela hore leha o sebelisa [`AcqRel`], ts'ebetso e kanna ea hloleha mme ka hona etsa feela mojaro oa `Acquire`, empa o se na semantiki sa `Release`.
            ///
            /// Ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`] haeba e etsahala, 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Ho fallela `compare_exchange` le `compare_exchange_weak`
            ///
            /// `compare_and_swap` e lekana le `compare_exchange` ka 'mapa o latelang oa tatellano ea memori:
            ///
            /// Ea pele |Katleho |Ho hloleha
            /// -------- | ------- | -------
            /// Phomolo |Phomolo |Fumana Phomolo |Fumana |Fumana Phatlalatso |Lokolla |Phomolo AcqRel |AcqRel |Fumana SeqCst |SeqCst |SEQCst
            ///
            /// `compare_exchange_weak` e lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e lumellang moqapi hore a hlahise khoutu e ntle ea kopano ha ho bapisoa le ho fapanyetsana ho sebelisoa moleng.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// E boloka boleng ho palo ea athomo haeba boleng ba hona joale bo lekana le boleng ba `current`.
            ///
            /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
            /// Ho katleho katleho ena e netefalitsoe hore e lekana le `current`.
            ///
            /// `compare_exchange` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
            /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
            /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
            /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
            ///
            /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// E boloka boleng ho palo ea athomo haeba boleng ba hona joale bo lekana le boleng ba `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// mosebetsi ona o lumelloa ho hloleha ka mokhoa o makatsang leha papiso e atleha, e ka hlahisang khoutu e sebetsang hantle ho feta lipulong tse ling.
            /// Boleng ba ho khutlisa ke sephetho se bonts'ang hore na boleng bo bocha bo ngotsoe ebile bo na le boleng bo fetileng.
            ///
            /// `compare_exchange_weak` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
            /// `success` e hlalosa tatellano e hlokahalang bakeng sa ts'ebetso ea ho bala-ea ho ngola e etsahalang ha papiso le `current` e atleha.
            /// `failure` e hlalosa taelo e hlokahalang bakeng sa ts'ebetso ea mojaro e etsahalang ha papiso e hloleha.
            /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro o atlehileng [`Relaxed`].
            ///
            /// Taelo ea ho hloleha e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// tlohela khale= val.load(Ordering::Relaxed);
            /// sekgoqetsane {let new=old * 2;
            ///     papali val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// E eketsoa ho boleng ba hajoale, e khutlisa boleng ba pejana.
            ///
            /// Ts'ebetso ena e potoloha ka bongata.
            ///
            /// `fetch_add` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Ho huloa boleng ba hona joale, ho khutlisa boleng bo fetileng.
            ///
            /// Ts'ebetso ena e potoloha ka bongata.
            ///
            /// `fetch_sub` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" e nang le boleng ba hona joale.
            ///
            /// E etsa ts'ebetso ea "and" hanyane ka hanyane ho boleng ba hona joale le khang ea `val`, ebe e beha boleng bo bocha ho sephetho.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_and` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" e nang le boleng ba hona joale.
            ///
            /// E etsa ts'ebetso ea "nand" hanyane ka hanyane ho boleng ba hona joale le khang ea `val`, ebe e beha boleng bo bocha ho sephetho.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_nand` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13 le 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" e nang le boleng ba hona joale.
            ///
            /// E etsa ts'ebetso ea "or" hanyane ka hanyane ho boleng ba hona joale le khang ea `val`, ebe e beha boleng bo bocha ho sephetho.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_or` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" e nang le boleng ba hona joale.
            ///
            /// E etsa ts'ebetso ea "xor" hanyane ka hanyane ho boleng ba hona joale le khang ea `val`, ebe e beha boleng bo bocha ho sephetho.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_xor` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// E nka boleng, ebe e sebelisa tšebetso ho eona e khutlisang boleng bo bocha bo ikhethileng.E khutlisa `Result` ea `Ok(previous_value)` haeba ts'ebetso e khutlisitse `Some(_)`, ha ho na le `Err(previous_value)`.
            ///
            /// Note: Sena se ka bitsa ts'ebetso makhetlo a mangata haeba boleng bo fetotsoe ho tsoa ho likhoele tse ling hajoale, ha feela mosebetsi o khutlisa `Some(_)`, empa ts'ebetso e tla be e sebelisitsoe hang feela ho boleng bo bolokiloeng.
            ///
            ///
            /// `fetch_update` Ho nka mabaka a mabeli a [`Ordering`] ho hlalosa tatellano ea memori ea ts'ebetso ena.
            /// Ea pele e hlalosa taelo e hlokehang ea hore na ts'ebetso e tla qetella e atlehile ha ea bobeli e hlalosa taelo e hlokahalang ea mejaro.Tsena li tsamaellana le tatellano ea katleho le ho hloleha ha
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Ho sebelisa [`Acquire`] e le katleho ea ho odara ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro oa ho qetela o atlehileng [`Relaxed`].
            /// Taelo ea (failed) ea mojaro e ka ba [`SeqCst`], [`Acquire`] kapa [`Relaxed`] feela mme e tlameha ho lekana kapa ho fokola ho feta ho odara katleho.
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// tiisa_eq! (x.fetch_update (Ho laela: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// tiisa_eq! (x.fetch_update (Ho laela: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Boholo le boleng ba hona joale.
            ///
            /// E fumana boholo ba boleng ba hajoale le ngangisano `val`, ebe e beha boleng bo bocha ho sephetho.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_max` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// lumella max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// tiisa! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Bonyane le boleng ba hona joale.
            ///
            /// E fumana bonyane ba boleng ba hajoale le ngangisano `val`, ebe e beha boleng bo bocha sephethong.
            ///
            /// E khutlisa boleng bo fetileng.
            ///
            /// `fetch_min` e nka ngangisano ea [`Ordering`] e hlalosang tatellano ea memori ea ts'ebetso ena.Mekhoa eohle ea ho odara e ea khonahala.
            /// Hlokomela hore ho sebelisa [`Acquire`] ho etsa hore lebenkele e be karolo ea ts'ebetso ena [`Relaxed`], 'me ho sebelisa [`Release`] ho etsa mojaro karolo ea [`Relaxed`].
            ///
            ///
            /// **Hlokomela**: Mokhoa ona o fumaneha feela lipulong tse tšehetsang ts'ebetso ea athomo ho
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// tlohella min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// tiisa (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // TŠIRELETSO: merabe ea data e thibeloa ke liathomo tsa tlhaho.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// E khutlisetsa sesupa se ka fetohang ho palo e kholo.
            ///
            /// Ho bala se seng sa athomo le ho ngola ho lenane le hlahisoang e ka ba peiso ea data.
            /// Mokhoa ona o bohlokoa haholo bakeng sa FFI, moo saena ea ts'ebetso e ka sebelisang
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ho khutlisa sesupa sa `*mut` ho tloha moo ho buuoang ka atomic ena ho bolokehile hobane mefuta ea athomo e sebetsa ka ho fetoha ha kahare.
            /// Liphetoho tsohle tsa athomo li fetola boleng ka ts'ebeliso e arolelanoeng, 'me li ka li etsa ka polokeho ha feela li sebelisa ts'ebetso ea athomo.
            /// Ts'ebeliso efe kapa efe ea pointer e khutlisitsoeng e sa hlakoang e hloka `unsafe` block mme e ntse e tlameha ho boloka thibelo e ts'oanang: ts'ebetso ho eona e tlameha ho ba athomo.
            ///
            ///
            /// # Examples
            ///
            /// `` hlokomoloha (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// kantle "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // TSHIRELETSO: Ho bolokehile ha feela `my_atomic_op` e le athomo.
            /// sireletseha {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// E khutlisa boleng ba pejana (joalo ka __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// E khutlisa boleng ba pejana (joalo ka __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// e khutlisa boleng ba max (papiso e saennweng)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// e khutlisa boleng ba min (papiso e saennweng)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// e khutlisa boleng ba max (papiso e sa saeneloang)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// e khutlisa boleng ba min (papiso e sa saeneloang)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Terata ea athomo.
///
/// Ho latela tatellano e boletsoeng, terata e thibela moqapi le CPU ho hlophisa mefuta e meng ea ts'ebetso ea memori ho e potoloha.
/// Seo se theha khokahano-le likamano lipakeng tsa eona le ts'ebetso ea athomo kapa terata ea likhoele tse ling.
///
/// Terata 'A' e nang le (bonyane) [`Release`] ea ho laela semantics, e lumellanang le terata 'B' le (bonyane) [`Acquire`] semantics, haeba feela haeba ho na le ts'ebetso X le Y, ka bobeli li sebetsa nthong e 'ngoe ea athomo 'M' joalo ka hore A e hlophisitsoe pele X, Y e hokahantsoe pele B le Y ba bona phetoho ho M.
/// Sena se fana ka se etsahalang pele ho ts'epahalo lipakeng tsa A le B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Ts'ebetso ea athomo e nang le [`Release`] kapa [`Acquire`] semantics le eona e ka hokahana le terata.
///
/// Terata e nang le taelo ea [`SeqCst`], ntle le ho ba le li-semantics tsa [`Acquire`] le [`Release`], e nka karolo lenaneong la lefats'e la lits'ebetso tse ling tsa [`SeqCst`] le/kapa terata.
///
/// E amohela [`Acquire`], [`Release`], [`AcqRel`] le [`SeqCst`].
///
/// # Panics
///
/// Panics haeba `order` ke [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Kheletso e kopanetsoeng ea khale e ipapisitse le spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Emela ho fihlela boleng ba khale e le `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Terata ena e hokahanya-le lebenkele ho `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // TSHIRELETSO: ho sebedisa terata ya athomo ho bolokehile.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Terata ea mohopolo oa sehokelo.
///
/// `compiler_fence` ha e hlahise khoutu efe kapa efe ea mochini, empa e thibela mefuta ea memori e hlophisang bocha moqapi e lumelletsoeng ho e etsa.Haholo-holo, ho latela li-semantics tsa [`Ordering`] tse fuoeng, moqapi a ka haneloa ho tsamaisa ho bala kapa ho ngola ho tloha pele kapa kamora mohala ho ea lehlakoreng le leng la mohala ho `compiler_fence`.Hlokomela hore ha e **thibela** lisebelisoa tsa ho etsa li-odara tse joalo.
///
/// Hona ha se bothata mohaleng o le mong, oa ts'ebetso, empa ha likhoele tse ling li ka fetola memori ka nako e ts'oanang, ho hlokahala li-primitization tse matla tsa khokahano tse kang [`fence`].
///
/// Ho hlophisa bocha ho thibetsoeng ke li-semantics tse fapaneng tsa ho odara ke:
///
///  - ka [`SeqCst`], ha ho na odara e ncha ea ho bala le ho ngola ho pholletsa le ntlha ena e lumelletsoeng.
///  - ka [`Release`], ho bala le ho ngola ho fetileng ho ke ke ha sisinyeha nakong e fetileng ha a ngola.
///  - ka [`Acquire`], lipalo tse latelang le ho ngola li ke ke tsa fetisoa pele ho lipalo tse fetileng.
///  - ka [`AcqRel`], melao ka bobeli e boletsoeng kaholimo e ea qobelloa.
///
/// `compiler_fence` hangata e thusa feela ho thibela khoele ho matha *ka boeona*.Ka mantsoe a mang, haeba khoele e fanoeng e sebelisa khoutu e le 'ngoe, ebe e sitisoa, ebe e qala ho etsa khoutu kae kae (ha e ntse e le khoeleng e le' ngoe, 'me ka mohopolo e ntse e le ntlheng e le ngoe).Mananeo a setso, sena se ka etsahala feela ha motsamaisi oa lipontšo a ngolisitsoe.
/// Ka khoutu ea boemo bo tlase haholo, maemo a joalo a ka hlaha hape ha o sebetsana le litšitiso, ha o kenya ts'ebetsong likhoele tse tala ka pele ho mochini, jj.
/// Babali ba nang le tjantjello ba khothaletsoa ho bala puisano ea Linux kernel ea [memory barriers].
///
/// # Panics
///
/// Panics haeba `order` ke [`Relaxed`].
///
/// # Examples
///
/// Ntle le `compiler_fence`, `assert_eq!` ka khoutu e latelang ha e netefatsoe hore e tla atleha, leha tsohle li etsahala ka khoele e le 'ngoe.
/// Ho bona hore na hobaneng, hopola hore moqapi o na le bolokolohi ba ho fapanyetsana mabenkele ho `IMPORTANT_VARIABLE` le `IS_READ` kaha ka bobeli ke `Ordering::Relaxed`.Haeba e etsa joalo, 'me motsamaisi oa lets'oao o ipiletsa hang kamora hore `IS_READY` e ntlafatsoe, motsamaisi oa lets'oao o tla bona `IS_READY=1`, empa `IMPORTANT_VARIABLE=0`.
/// Ho sebelisa pheko ea `compiler_fence` boemo bona.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // thibela pejana ho ngola hore e se ke ea tlosoa ntlheng ena
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // TSHIRELETSO: ho sebedisa terata ya athomo ho bolokehile.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// E tšoaea processor hore e kahare ho spin-loop e phathahaneng ("spin lock").
///
/// Mosebetsi ona o nyenyefalitsoe molemong oa [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}