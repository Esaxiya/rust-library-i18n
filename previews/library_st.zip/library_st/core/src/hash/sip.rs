//! Ts'ebetsong ea SipHash.

#![allow(deprecated)] // mefuta ea module ena e theotsoe

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Ts'ebetsong ea SipHash 1-3.
///
/// Hona joale ke ts'ebetso ea hashing ea kamehla e sebelisoang ke laeborari e tloaelehileng (mohlala, `collections::HashMap` ee sebelisa ka boiketsetso).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Ts'ebetsong ea SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Ts'ebetsong ea SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash ke mosebetsi o akaretsang oa sepheo: o sebetsa ka lebelo le letle (oa tlholisano le Spooky le Motse) mme o lumella _keyed_ hashing e matla.
///
/// Sena se o lumella ho khetha litafole tsa hau tsa hashi ho tsoa ho RNG e matla, joalo ka [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Le ha algorithm ea SipHash e nkuoa e le matla ka kakaretso, ha ea etsetsoa sepheo sa ho ngola.
/// Kahoo, lits'ebeliso tsohle tsa ts'ebetso ea ts'ebetso ena ke _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // re sebetsane le li-byte tse kae
    state: State,  // Naha ea hash
    tail: u64,     // li-byte tse sa sebetsoang le
    ntail: usize,  // ke li-byte tse kae mohatleng tse sebetsang
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 le v1, v3 li hlaha ka bobeli ho algorithm, mme ts'ebetsong ea simd ea SipHash e tla sebelisa vectors ea v02 le v13.
    //
    // Ka ho li beha ka tatellano ena mohahong, mohokisi o ka nka lintlafatso tse seng kae feela tsa simd ka botsona.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// E kenya palo e kholo ea mofuta o batlang ho tsoa molapong oa byte, ka tatellano ea LE.
/// E sebelisa `copy_nonoverlapping` ho lumella moqapi hore a hlahise mokhoa o nepahetseng haholo oa ho e kenya ho tsoa atereseng e sa ngolisoang hantle.
///
///
/// Ha e bolokehe hobane: indexing e sa hlahlojoang ho i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// E jara u64 e sebelisa li-byte tse ka bang 7.
/// E shebahala e maketse empa mehala ea `copy_nonoverlapping` e etsahalang (ka `load_int_le!`) kaofela li na le boholo bo sa fetoheng 'me li qoba ho letsetsa `memcpy`, e loketseng lebelo.
///
///
/// Ha e bolokehe hobane: indexing e sa hlahlojoang qalong.. qala + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // index ea hona joale ea byte (e tsoang ho LSB) ho tlhahiso ea u64
    let mut out = 0;
    if i + 3 < len {
        // TSHIRELETSO: `i` e ka se be kholo ho `len`, mme moletsi o tlameha ho netefatsa
        // hore index e qala..start + len e meeling.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // TSHIRELETSO: go tshwana le fa godimo.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // TSHIRELETSO: go tshwana le fa godimo.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// E etsa `SipHasher` e ncha ka linotlolo tse peli tsa pele tse behiloeng ho 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// E etsa `SipHasher` e notlelletsoeng linotlolo tse fanoeng.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// E etsa `SipHasher13` e ncha ka linotlolo tse peli tsa pele tse behiloeng ho 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// E etsa `SipHasher13` e notlelletsoeng linotlolo tse fanoeng.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: ha ho mekhoa e mengata ea hashing (`write_u *`, `write_i*`) e hlalositsoeng
    // bakeng sa mofuta ona.
    // Re ka li eketsa, ra kopitsa ts'ebetsong ea `short_write` ho librustc_data_structures/sip128.rs, mme ra eketsa mekhoa ea `write_u *`/`write_i*` ho `SipHasher`, `SipHasher13`, le `DefaultHasher`.
    //
    // Sena se ka potlakisa tšubuhlellano e kholo ea li-hasher, ka litšenyehelo tsa ho fokotsa butle butle ho bokella lebelo ho li-benchmark tse ling.
    // Bona #69152 bakeng sa lintlha.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // POLOKEHO: `cmp::min(length, needed)` e netefalitsoe hore e ke ke ea feta `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Mohatla o koahetsoeng o se o fepetsoe, sebetsana le ho kenya lintlha tse ncha.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // TŠIRELETSO: hobane `len - left` ke palo e kholo ka ho fetisisa ea 8 tlasa
            // `len`, mme hobane `i` e qala ho `needed` moo `len` e leng `length - needed`, `i + 8` e netefalitsoe hore e ka tlase ho kapa e lekana le `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // TSHIRELETSO: `i` ha jwale ke `needed + len.div_euclid(8) * 8`,
        // kahoo `i + left` = `needed + len` = `length`, e leng ka tlhaloso e lekanang le `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// E etsa `Hasher<S>` ka linotlolo tse peli tsa pele tse behiloeng ho 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}