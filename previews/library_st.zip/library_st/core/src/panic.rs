//! Ts'ehetso ea Panic ho laeborari e tloaelehileng.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Sebopeho se fanang ka tlhaiso-leseling ka panic.
///
/// `PanicInfo` sebopeho se fetisetsoa ho panic hook e behiloeng ke ts'ebetso ea [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// E khutlisa mojaro o amanang le panic.
    ///
    /// Sena hangata e tla ba `&'static str` kapa [`String`], empa eseng kamehla.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Haeba `panic!` macro e tsoang ho `core` crate (eseng e tsoang `std`) e sebelisitsoe ka mohala oa ho fomata le mabaka a mang a mang, e khutlisa molaetsa oo o loketseng ho sebelisoa mohlala le [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// E khutlisa leseli mabapi le sebaka seo panic e tsoang ho sona, haeba e le teng.
    ///
    /// Mokhoa ona hajoale o tla khutlisa [`Some`] kamehla, empa sena se ka fetoha liphetolelong tsa future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Haeba sena se fetotsoe hore ka nako e 'ngoe se khutlele None,
        // sebetsana le nyeoe eo ho std::panicking::default_hook le std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: re ka se sebelise downcast_ref: :<String>() Mona
        // kaha String ha e fumanehe ka libcore!
        // Tefo e lefshoang ke Khoele ha `std::panic!` e bitsoa ka mabaka a mangata, empa maemong ao molaetsa o teng.
        //

        self.location.fmt(formatter)
    }
}

/// Moetso o nang le tlhaiso-leseling ka sebaka sa panic.
///
/// Sebopeho sena se entsoe ke [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Lipapiso tsa tekano le ho odara li etsoa ka faele, mohala, ebe ntlha ea mantlha.
/// Lifaele li bapisoa le likhoele, eseng `Path`, tse ka bang tse sa lebelloang.
/// Bona litokomane tsa [`Location: : file`] bakeng sa puisano e ngoe.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// E khutlisetsa sebaka sa mohloli sa moletsi oa tšebetso ena.
    /// Haeba motho ea letsitseng tšebetso eo a hlalositsoe joale sebaka sa mohala oa hae se tla khutlisoa, joalo-joalo ho nyollela mokhoeng ho letsetsa la pele kahare ho 'mele oa tšebetso o sa lateloang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// E khutlisa [`Location`] moo e bitsoang teng.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// E khutlisa [`Location`] ho tsoa kahare ho tlhaloso ea mosebetsi ona.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ho sebetsa ts'ebetso e ts'oanang e sa koaloang sebakeng se fapaneng ho re fa sephetho se ts'oanang
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ho tsamaisa tšebetso e latiloeng sebakeng se fapaneng ho hlahisa boleng bo fapaneng
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// E khutlisetsa lebitso la file ea mohloli moo panic e tsoang ho eona.
    ///
    /// # `&str`, eseng `&Path`
    ///
    /// Lebitso le khutlisitsoeng le supa tsela ea mohloli tsamaisong ea ho bokella, empa ha e nepahale ho emela sena ka kotloloho joalo ka `&Path`.
    /// Khoutu e hlophisitsoeng e ka sebetsa tsamaisong e ngoe ka ts'ebetsong e fapaneng ea `Path` ho feta sistimi e fanang ka litaba mme laeborari ena ha e na mofuta oa "host path" o fapaneng.
    ///
    /// Boitšoaro bo makatsang ka ho fetesisa bo etsahala ha file ea "the same" e ka fihlelleha ka litsela tse ngata mojuleng oa module (hangata o sebelisa semelo sa `#[path = "..."]` kapa se ts'oanang), se ka etsang hore se shebahalang e le khoutu e ts'oanang se khutlise boleng bo fapaneng mosebetsing ona.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Boleng bona ha bo a lokela ho fetela ho `Path::new` kapa lihahi tse ts'oanang ha sethala sa moamoheli le sethala sa sepheo se fapana.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// E khutlisa nomoro ea mohala eo panic e tsoang ho eona.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// E khutlisa kholomo eo panic e tsoang ho eona.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait e kahare e sebelisitsoeng ke libstd ho fetisa data ho tloha libstd ho ea `panic_unwind` le linako tse ling tsa ts'ebetso tsa panic.
/// Ha e reretsoe ho tsitsisoa nako efe kapa efe haufinyane, se ke oa e sebelisa.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Nka beng ba litaba ka botlalo.
    /// Mofuta oa ho khutla ke `Box<dyn Any + Send>`, empa re ke ke ra sebelisa `Box` ka libcore.
    ///
    /// Kamora hore mokhoa ona o bitsoe, ho setse feela boleng ba mantlha ba dummy ho `self`.
    /// Ho letsetsa mokhoa ona habeli, kapa ho letsetsa `get` kamora ho bitsa mokhoa ona, ke phoso.
    ///
    /// Khang e alimiloe hobane nako ea ho matha ea panic (`__rust_start_panic`) e fumana feela `dyn BoxMeUp` e alimiloeng.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Alima tse ka hare feela.
    fn get(&mut self) -> &(dyn Any + Send);
}