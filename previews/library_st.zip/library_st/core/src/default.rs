//! `Default` trait ea mefuta e ka bang le litekanyetso tsa mantlha tsa mantlha.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait bakeng sa ho fa mofuta boleng ba boleng bo ikhethileng.
///
/// Ka linako tse ling, o batla ho khutlela ho mofuta o mong oa boleng bo sa feleng, 'me ha o tsotelle haholo hore na ke eng.
/// Hangata sena se hlaha ka `struct`s tse hlalosang sete ea likhetho:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Re ka hlalosa joang litekanyetso tse ling tsa kamehla?U ka sebelisa `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Joale u fumana litekanyetso tsohle tsa kamehla.Rust e sebelisa `Default` bakeng sa mefuta e fapaneng ea li-primitives.
///
/// Haeba u batla ho fetisa khetho e itseng, empa u ntse u boloka tse ling tse fapaneng:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// trait ena e ka sebelisoa le `#[derive]` haeba likarolo tsohle tsa mofuta ona li kenya tšebetsong `Default`.
/// Ha`derive`d, e tla sebelisa boleng ba mantlha bakeng sa mofuta o mong le o mong oa tšimo.
///
/// ## Nka kenya `Default` joang?
///
/// Fana ka ts'ebetsong bakeng sa mokhoa oa `default()` o khutlisetsang boleng ba mofuta oa hau o lokelang ho ba oa mantlha:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// E khutlisa "default value" bakeng sa mofuta.
    ///
    /// Litekanyetso tsa kamehla hangata ke mofuta oa boleng ba mantlha, boleng ba boitsebahatso, kapa eng kapa eng e kanna ea utloahala e le ea kamehla.
    ///
    ///
    /// # Examples
    ///
    /// U sebelisa litekanyetso tsa kamehla tse hahiloeng kahare:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Ho iketsetsa:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Khutlisa boleng ba mantlha ba mofuta ho latela `Default` trait.
///
/// Mofuta oa ho khutla o nkuoe ho latela moelelo;sena se lekana le `Default::default()` empa se khuts'oane ho thaepa.
///
/// Ka mohlala:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Fumana tlhahiso e kholo ea trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }