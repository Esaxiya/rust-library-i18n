#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! E na le litlhaloso tsa sebopeho sa sebopeho sa mefuta e hahelletsoeng ka har'a komporo.
//!
//! Li ka sebelisoa e le liphofu tsa li-transmits ka khoutu e sa bolokehang bakeng sa ho tsamaisa lits'oants'o tse tala ka kotloloho.
//!
//!
//! Tlhaloso ea bona e lokela ho lula e ts'oana le ABI e hlalositsoeng ho `rustc_middle::ty::layout`.
//!

/// Tšoantšetso ea ntho ea trait joalo ka `&dyn SomeTrait`.
///
/// Moralo ona o na le sebopeho se ts'oanang le mefuta e kang `&dyn SomeTrait` le `Box<dyn AnotherTrait>`.
///
/// `TraitObject` e netefalitsoe hore e ts'oana le meralo, empa ha se mofuta oa lintho tsa trait (mohlala, masimo ha a fihlellehe ka kotloloho ho `&dyn SomeTrait`) ebile ha e laole sebopeho seo (ho fetola tlhaloso ho ke ke ha fetola sebopeho sa `&dyn SomeTrait`).
///
/// E etselitsoe feela hore e sebelisoe ke khoutu e sa bolokehang e hlokang ho qhekella lintlha tsa boemo bo tlase.
///
/// Ha ho na mokhoa oa ho supa lintho tsohle tsa trait ka mokhoa o ikhethileng, ka hona tsela feela ea ho theha boleng ba mofuta ona ke ka mesebetsi e kang [`std::mem::transmute`][transmute].
/// Ka mokhoa o ts'oanang, tsela e le 'ngoe feela ea ho theha ntho ea' nete ea trait ho tsoa ho boleng ba `TraitObject` ke ka `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ho kopanya ntho ea trait e nang le mefuta e sa tšoanelang - e leng moo vtable e sa lumellaneng le mofuta oa boleng boo sesupisi sa data se supang ho ona - ho ka etsahala hore bo lebise ho boits'oaro bo sa hlaloseheng.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // mohlala trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lumella moqapi hore a etse ntho ea trait
/// let object: &dyn Foo = &value;
///
/// // sheba boemeli bo tala
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // sesupi sa data ke aterese ea `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // aha ntho e ncha, a supa `i32` e fapaneng, a le hlokolosi ho sebelisa `i32` vtable ho tloha `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // e lokela ho sebetsa joalo ka ha eka re thehile ntho ea trait ho tsoa ho `other_value` ka kotloloho
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}