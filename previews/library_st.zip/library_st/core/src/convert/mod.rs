//! Traits bakeng sa liphetoho lipakeng tsa mefuta.
//!
//! traits mojuleng ona li fana ka mokhoa oa ho fetohela ho mofuta o mong ho ea ho o mong.
//! trait e ngoe le e ngoe e sebeletsa sepheo se fapaneng:
//!
//! - Kenya ts'ebetsong [`AsRef`] trait bakeng sa liphetoho tse theko e tlase tsa litšupiso
//! - Kenya ts'ebetsong [`AsMut`] trait bakeng sa liphetoho tse theko e tlaase tse fetohang
//! - Kenya ts'ebetsong [`From`] trait bakeng sa ho sebelisa liphetoho tsa boleng ba boleng
//! - Kenya ts'ebetsong [`Into`] trait bakeng sa ho sebelisa boleng ba boleng ho boleng ho mefuta e kantle ho crate ea hona joale
//! - [`TryFrom`] le [`TryInto`] traits li itšoara joaloka [`From`] le [`Into`], empa li lokela ho kengoa tšebetsong ha phetoho e ka hloleha.
//!
//! traits mojuleng ona hangata li sebelisoa e le trait bound bakeng sa mesebetsi e akaretsang joalo ka hore likhang tsa mefuta e mengata li tšehelitsoe.Bona litokomane tsa trait ka 'ngoe bakeng sa mehlala.
//!
//! Joaloka sengoli sa laeborari, o lokela ho khetha [`From<T>`][`From`] kapa [`TryFrom<T>`][`TryFrom`] ho fapana le [`Into<U>`][`Into`] kapa [`TryInto<U>`][`TryInto`], kaha [`From`] le [`TryFrom`] li fana ka maemo a maholo ebile li fana ka ts'ebetsong e lekanang ea [`Into`] kapa [`TryInto`] mahala, ka lebaka la ts'ebetsong ea kobo laeboraring e tloaelehileng.
//! Ha o lebisa tlhokomelo ho mofuta pele ho Rust 1.41, ho kanna ha hlokahala hore o kenye [`Into`] kapa [`TryInto`] ka kotloloho ha o fetohela mofuteng o kantle ho crate ea hajoale.
//!
//! # Ts'ebetsong ea Tloaelehileng
//!
//! - [`AsRef`] le [`AsMut`]-auto-dereference haeba mofuta o ka hare e le litšupiso
//! - [`Ho tloha`]`<U>etsoe T` e bolela [`Into"] `</u><T><U>bakeng sa U`</u>
//! - [`TryFrom`]`<U>etsoe T` e bolela [`TryInto`]`</u><T><U>bakeng sa U`</u>
//! - [`From`] 'me [`Into`] ha e nahane, ho bolelang hore mefuta eohle e ka ba `into` ka boeona le `from` ka boeona
//!
//! Bona trait ka 'ngoe bakeng sa mehlala ea ts'ebeliso.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Mosebetsi oa boitsebiso.
///
/// Ho na le lintho tse peli tseo ho leng bohlokoa ho li tseba ka ts'ebetso ena:
///
/// - Hase kamehla e lekanang le ho koaloa joaloka `|x| x`, hobane ho koala ho ka qobella `x` ho mofuta o mong.
///
/// - E tsamaisa tlhahiso ea `x` e fetiselitsoeng mosebetsing.
///
/// Le ha ho kanna ha utloahala ho makatsa ho ba le ts'ebetso e khutlisang feela kenyelletso, ho na le ts'ebeliso e ngoe e khahlisang.
///
///
/// # Examples
///
/// U sebelisa `identity` ho se etse letho ka tatellano ea mesebetsi e meng e khahlisang:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ha re etseng eka ho eketsa e le ngoe ke mosebetsi o khahlisang.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// U sebelisa `identity` joalo ka nyeoe ea motheo ea "do nothing" ka tlasa maemo a itseng:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Etsa lintho tse ling tse khahlisang ...
///
/// let _results = do_stuff(42);
/// ```
///
/// U sebelisa `identity` ho boloka mefuta e fapaneng ea `Some` ea iterator ea `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// E ne e sebelisetsoa ho etsa litšupiso tse theko e tlaase ha ho buuoa ka litšupiso.
///
/// trait ena e ts'oana le [`AsMut`] e sebelisetsoang ho fetoha lipakeng tsa litšupiso tse ka fetoloang.
/// Haeba o hloka ho etsa phetoho e turang ho molemo ho kenya [`From`] ka mofuta `&T` kapa ho ngola ts'ebetso ea moetlo.
///
/// `AsRef` e na le saena e tšoanang le [`Borrow`], empa [`Borrow`] e fapane lintlheng tse 'maloa:
///
/// - Ho fapana le `AsRef`, [`Borrow`] e na le kobo e kentsoeng bakeng sa `T` efe kapa efe, 'me e ka sebelisoa ho amohela sets'oants'o kapa boleng.
/// - [`Borrow`] hape e hloka hore [`Hash`], [`Eq`] le [`Ord`] bakeng sa boleng bo alimiloeng li lekana le tsa boleng ba eona.
/// Ka lebaka lena, haeba u batla ho alima tšimo e le 'ngoe feela ea sebopeho u ka kenya `AsRef`, empa eseng [`Borrow`].
///
/// **Note: trait ena ha ea lokela ho hloleha **.Haeba phetoho e ka hloleha, sebelisa mokhoa o inehetseng o khutlisetsang [`Option<T>`] kapa [`Result<T, E>`].
///
/// # Ts'ebetsong ea Tloaelehileng
///
/// - `AsRef` likhetho tsa boithaopo haeba mofuta oa kahare e le litšupiso kapa litšupiso tse ka fetoloang (mohlala: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ka ho sebelisa trait bound re ka amohela likhang tsa mefuta e fapaneng ha feela li ka fetoleloa ho mofuta o boletsoeng `T`.
///
/// Mohlala: Ka ho theha tšebetso e akaretsang e nkang `AsRef<str>` re hlahisa hore re batla ho amohela litšupiso tsohle tse ka fetoloang ho [`&str`] joalo ka khang.
/// Kaha bobeli ba [`String`] le [`&str`] ba kenya ts'ebetsong `AsRef<str>` re ka li amohela ka bobeli e le ngangisano ea ho kenya.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// E etsa phetoho.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// E ne e sebelisetsa phetoho e theko e tlaase e ka fetoloang.
///
/// trait ena e ts'oana le [`AsRef`] empa e sebelisetsoa ho fetoha lipakeng tsa litšupiso tse ka fetohang.
/// Haeba o hloka ho etsa phetoho e turang ho molemo ho kenya [`From`] ka mofuta `&mut T` kapa ho ngola ts'ebetso ea moetlo.
///
/// **Note: trait ena ha ea lokela ho hloleha **.Haeba phetoho e ka hloleha, sebelisa mokhoa o inehetseng o khutlisetsang [`Option<T>`] kapa [`Result<T, E>`].
///
/// # Ts'ebetsong ea Tloaelehileng
///
/// - `AsMut` ho ikhethela haeba mofuta oa kahare e le mokhoa oa ho fetoha (mohlala: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Re sebelisa `AsMut` joalo ka trait bound bakeng sa mosebetsi o tloaelehileng re ka amohela litšupiso tsohle tse ka fetoloang ho mofuta oa `&mut T`.
/// Hobane [`Box<T>`] e kenya ts'ebetsong `AsMut<T>` re ka ngola ts'ebetso `add_one` e nkang mabaka ohle a ka fetoloang ho `&mut u64`.
/// Hobane [`Box<T>`] e sebelisa `AsMut<T>`, `add_one` e amohela likhang tsa mofuta `&mut Box<u64>` hape:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// E etsa phetoho.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Phetoho ea boleng ba boleng e sebelisang boleng ba ho kenya.Ntho e fapaneng le [`From`].
///
/// Motho o lokela ho qoba ho kenya tšebetsong [`Into`] le ho kenya ts'ebetsong [`From`] ho fapana.
/// Ho kenya ts'ebetsong [`From`] ka bo eona ho fa motho ts'ebetsong ea [`Into`] ka lebaka la ts'ebetsong ea kobo laeboraring e tloaelehileng.
///
/// Khetha ho sebelisa [`Into`] ho feta [`From`] ha u totobatsa trait bound ts'ebetsong e tloaelehileng ho netefatsa hore mefuta e sebelisang [`Into`] feela e ka sebelisoa le eona.
///
/// **Note: trait ena ha ea lokela ho hloleha **.Haeba phetoho e ka hloleha, sebelisa [`TryInto`].
///
/// # Ts'ebetsong ea Tloaelehileng
///
/// - [`Ho tloha`]`<T>etsoe U` e bolela `Into<U> for T`
/// - [`Into`] e nahanisisa, ho bolelang hore `Into<T> for T` e kentsoe tšebetsong
///
/// # Ho kenya ts'ebetsong [`Into`] bakeng sa liphetoho ho mefuta ea kantle ho mefuta ea khale ea Rust
///
/// Pele ho Rust 1.41, haeba mofuta oa sebaka seo u eang ho sona e ne e se karolo ea crate ea hona joale u ne u ke ke ua kenya [`From`] ka kotloloho.
/// Mohlala, nka khoutu ena:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Sena se tla hloleha ho hlophisoa liphetolelong tsa khale tsa puo hobane melao ea likhutsana ea Rust e kile ea ba thata ho feta.
/// Ho feta mona, o ka kenya [`Into`] ka kotloloho:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Ho bohlokoa ho utloisisa hore [`Into`] ha e fane ka ts'ebetsong ea [`From`] (joalo ka [`From`] e etsang le [`Into`]).
/// Ka hona, o lokela ho lula o leka ho kenya ts'ebetsong [`From`] ebe o khutlela ho [`Into`] haeba [`From`] e sa khone ho kengoa tšebetsong.
///
/// # Examples
///
/// [`String`] lisebelisoa [`Into`]`<`(`Vec`] `<<` [`u8`]` >> >>:
///
/// Bakeng sa ho bonts'a hore re batla ts'ebetso ea generic ho nka likhang tsohle tse ka fetoloang ho mofuta o boletsoeng `T`, re ka sebelisa trait bound ea [`Into`]`<T>`.
///
/// Mohlala: Ts'ebetso `is_hello` e nka likhang tsohle tse ka fetoloang ho ba "[Vec`]`<<"[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// E etsa phetoho.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// E sebelisetsoa ho etsa liphetoho tsa boleng ba boleng ha u ntse u sebelisa boleng ba ho kenya.Ke phetoho ea [`Into`].
///
/// Motho o lokela ho khetha ho kenya ts'ebetsong `From` ho feta [`Into`] hobane ho kenya ts'ebetsong `From` ka bo eona ho fa motho ts'ebetsong ea [`Into`] ka lebaka la ts'ebetsong ea kobo laeboraring e tloaelehileng.
///
///
/// Kenya ts'ebetsong [`Into`] feela ha u shebile mofuta pele ho Rust 1.41 ebe u fetohela ho mofuta o kantle ho crate ea hajoale.
/// `From` ha ea khona ho etsa mefuta ena ea liphetoho liphetolelong tsa pejana ka lebaka la melao ea likhutsana ea Rust.
/// Bona [`Into`] bakeng sa lintlha tse ling.
///
/// Khetha ho sebelisa [`Into`] ho sebelisa `From` ha u totobatsa trait bounds ts'ebetsong e tloaelehileng.
/// Ka tsela ena, mefuta e sebelisang [`Into`] ka kotloloho e ka sebelisoa e le likhang hape.
///
/// `From` e boetse e na le thuso haholo ha o sebetsana le liphoso.Ha o aha ts'ebetso e khonang ho hloleha, mofuta oa ho khutla ka kakaretso e tla ba oa sebopeho `Result<T, E>`.
/// `From` trait e nolofatsa ho sebetsana le liphoso ka ho lumella ts'ebetso ho khutlisa mofuta o le mong oa liphoso o kenyelletsang mefuta e mengata ea liphoso.Bona karolo ea "Examples" le [the book][book] bakeng sa lintlha tse ling.
///
/// **Note: trait ena ha ea lokela ho hloleha **.Haeba phetoho e ka hloleha, sebelisa [`TryFrom`].
///
/// # Ts'ebetsong ea Tloaelehileng
///
/// - `From<T> for U` e bolela [`Into`] <U>bakeng sa T`</u>
/// - `From` e nahanisisa, ho bolelang hore `From<T> for T` e kentsoe tšebetsong
///
/// # Examples
///
/// [`String`] lisebelisoa `From<&str>`:
///
/// Phetoho e hlakileng ho tloha ho `&str` ho ea ho String e etsoa ka tsela e latelang:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ha o ntse o sebetsana le liphoso hangata ho bohlokoa ho kenya `From` molemong oa mofuta oa phoso ea hau.
/// Ka ho fetolela mefuta ea liphoso molemong oa mofuta oa rona oa liphoso o akaretsang mofuta oa phoso, re ka khutlisa mofuta o le mong oa phoso ntle le ho lahleheloa ke tlhaiso-leseling ka sesosa sa ona.
/// Motsamaisi oa '?' o fetolela ka mokhoa o ikhethileng mofuta oa phoso ho mofuta oa rona oa phoso ka ho letsetsa `Into<CliError>::into` e fanoang ka bo eona ha o kenya ts'ebetsong `From`.
/// Moqapi o kenya ts'ebetsong ea `Into` e lokelang ho sebelisoa.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// E etsa phetoho.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Phetoho e lekiloeng e sebelisang `self`, e kanna ea ba e sa theko e phahameng kapa e se theko e phahameng.
///
/// Bangoli ba laeboraring hangata ha baa lokela ho kenya ts'ebetsong trait ka kotloloho, empa ba lokela ho khetha ho kenya ts'ebetsong [`TryFrom`] trait, e fanang ka phetoho e kholo mme e fana ka ts'ebetso e lekanang ea `TryInto` mahala, ka lebaka la ts'ebetsong ea kobo laeboraring e tloaelehileng.
/// Bakeng sa tlhaiso-leseling e batsi ka sena, bona litokomane tsa [`Into`].
///
/// # Ho kenya ts'ebetsong `TryInto`
///
/// Sena se na le lithibelo le mabaka a tšoanang le ho kenya ts'ebetsong [`Into`], bona moo bakeng sa lintlha.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Mofuta o khutlisitsoe ha ho bile le phoso ea phetoho.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// E etsa phetoho.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Liphetoho tse bonolo le tse bolokehileng tse ka 'nang tsa hloleha ka tsela e laoloang tlasa maemo a mang.Ke phetoho ea [`TryInto`].
///
/// Sena se na le thuso ha o etsa mofuta oa phetoho o ka atlehang hanyane empa o kanna oa hloka ts'ebetso e khethehileng.
/// Mohlala, ha ho na mokhoa oa ho fetolela [`i64`] hore e be [`i32`] o sebelisa [`From`] trait, hobane [`i64`] e kanna ea ba le boleng boo [`i32`] e ke keng ea bo emela mme ka hona phetoho e tla lahleheloa ke data.
///
/// Sena se ka sebetsoa ka ho khella [`i64`] ho [`i32`] (ha e le hantle e fana ka boleng ba [`i64`] modulo [`i32::MAX`]) kapa ka ho khutlisa [`i32::MAX`] feela, kapa ka mokhoa o mong.
/// [`From`] trait e etselitsoe liphetoho tse phethahetseng, kahoo `TryFrom` trait e tsebisa moqapi ha mofuta oa phetoho o ka mpefala mme oa ba lumella ho etsa qeto ea hore na ba e sebetsana joang.
///
/// # Ts'ebetsong ea Tloaelehileng
///
/// - `TryFrom<T> for U` e bolela [`TryInto`] <U>bakeng sa T`</u>
/// - [`try_from`] e nahanisisa, ho bolelang hore `TryFrom<T> for T` e kentsoe tšebetsong 'me e ke ke ea hloleha-mofuta oa `Error` o amanang le ho letsetsa `T::try_from()` ka boleng ba mofuta oa `T` ke [`Infallible`].
/// Ha mofuta oa [`!`] o tsitsitse [`Infallible`] mme [`!`] e tla lekana.
///
/// `TryFrom<T>` e ka sebelisoa ka tsela e latelang:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Joalokaha ho hlalositsoe, [`i32`] e kenya ts'ebetsong `TryFrom <` [``i64`] `>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Li khutsitse li khutsitse `big_number`, li hloka ho fumana le ho sebetsana le truncation kamora 'nete.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // E khutlisa phoso hobane `big_number` e kholo haholo hore e ka lekana `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // E khutlisa `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Mofuta o khutlisitsoe ha ho bile le phoso ea phetoho.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// E etsa phetoho.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// KAKARETSO IMPLS
////////////////////////////////////////////////////////////////////////////////

// Ha a ntse a phahamisa&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ha e phahamisa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): kenya li-impl tse kaholimo bakeng sa&/&mut ka e latelang ka kakaretso:
// // Ha e phahamisa Deref
// kenya <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>bakeng sa D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut e phahamisa &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): kenya sebaka se kaholimo bakeng sa &mut ka se latelang ka kakaretso:
// // AsMut e phahamisa DerefMut
// kenya <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>bakeng sa D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Ho tloha ho maikutlo ho kena
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Ho tloha (ka hona ho kena) hoa fetoha
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Tsebiso e tsitsitseng:** Tlhahiso ena ha e so be teng, empa re "reserving space" ho e kenya ho future.
/// Bona [rust-lang/rust#64715][#64715] bakeng sa lintlha.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): etsa tokiso ea melao-motheo ho fapana.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom e fana ka maikutlo a TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Liphetoho tse sa foseng li tšoana le liphetoho tse fosahetseng ka mofuta oa phoso e sa ahuoang.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// KAKARETSO IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// Mofuta oa Phoso e se nang phoso
////////////////////////////////////////////////////////////////////////////////

/// Mofuta oa phoso bakeng sa liphoso tse ke keng tsa etsahala.
///
/// Kaha enum ena ha e na phapang, boleng ba mofuta ona bo ka se be teng.
/// Sena se ka ba molemo bakeng sa li-API tse tloaelehileng tse sebelisang [`Result`] le ho beha mofuta oa phoso parameter, ho bontša hore sephetho se lula se le [`Ok`].
///
/// Ka mohlala, [`TryFrom`] trait (phetoho e khutlisetsang [`Result`]) e na le ts'ebetsong ea kobo bakeng sa mefuta eohle moo ts'ebetsong ea [`Into`] e fapaneng e leng teng.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ts'ebetsong ea Future
///
/// Enum ena e na le karolo e ts'oanang le [the `!`“never”type][never], e sa tsitsang phetolelong ena ea Rust.
/// Ha `!` e tsitsitse, re rera ho etsa `Infallible` mofuta o mong oa eona:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …'Me qetellong deprecate `Infallible`.
///
/// Leha ho le joalo ho na le nyeoe e le 'ngoe moo syntax ea `!` e ka sebelisoang pele `!` e tsitsisoa e le mofuta o felletseng: maemong a mofuta oa ts'ebetso oa ts'ebetso.
/// Haholo-holo, ho ka etsahala ts'ebetsong bakeng sa mefuta e 'meli ea li-pointer tsa ts'ebetso:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Ha `Infallible` e le enum, khoutu ena e nepahetse.
/// Leha ho le joalo ha `Infallible` e fetoha lebitso la never type, `impl`s tse peli li tla qala ho kopana 'me ka hona li tla lumelloa ke melao ea kutloano ea trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}