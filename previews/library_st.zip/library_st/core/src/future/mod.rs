#![stable(feature = "futures_api", since = "1.36.0")]

//! Litekanyetso tsa Asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Mofuta ona oa hlokahala hobane:
///
/// a) Lijenereithara ha li khone ho kenya tšebetsong `for<'a, 'b> Generator<&'a mut Context<'b>>`, ka hona re hloka ho fetisa sesupa-tala (bona <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Litlhahiso tse tala le `NonNull` ha se `Send` kapa `Sync`, ka hona e ka etsa hore future non-Send/Sync e ngoe le e ngoe e be joalo, 'me ha re e batle.
///
/// E boetse e nolofatsa ho theola HIR ha `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Phuthela jenereithara ka future.
///
/// Mosebetsi ona o khutlisa `GenFuture` ka tlase, empa oa e pata ho `impl Trait` ho fana ka melaetsa e fosahetseng ea liphoso (`impl Future` ho fapana le `GenFuture<[closure.....]>`).
///
// Sena ke `const` ho qoba liphoso tse ling kamora hore re fole ho `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Re ts'epa hore async/await futures ha e sisinyehe molemong oa ho etsa mekoloto e ikemetseng ho jenereithara e ka tlase.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // TSHIRELETSO: Re bolokehile hobane re !Unpin + !Drop, mme ena ke ponelopele ya lebaleng feela.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Qala hape jenereithara, u fetole `&mut Context` hore e be sesupa se tala sa `NonNull`.
            // Ho theoha ha `.await` ho tla e khutlisetsa ho `&mut Context` ka polokeho.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `cx.0` ke sesupi se nepahetseng
    // e phethisang litlhokahalo tsohle bakeng sa ts'upiso e ka fetohang.
    unsafe { &mut *cx.0.as_ptr().cast() }
}