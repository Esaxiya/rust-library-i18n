#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future e emetse palo e fapaneng haholo.
///
/// future ke boleng boo e kanna eaba ha bo e-so qete ho sebelisa k'homphieutha.
/// Mofuta ona oa "asynchronous value" o etsa hore khoele e tsoelepele ho etsa mosebetsi o molemo ha e ntse e emetse hore boleng bo fumanehe.
///
///
/// # Mokhoa oa `poll`
///
/// Mokgwa wa konokono wa future, `poll`,*o leka* ho rarolla future hore e be boleng ba ho qetela.
/// Mokhoa ona ha o thibele haeba boleng bo sa lokisoa.
/// Sebakeng seo, mosebetsi oa hajoale o reretsoe ho tsosoa ha ho khonahala ho etsa tsoelo-pele e eketsehileng ka `pollinging hape.
/// `context` e fetiselitsoeng mokhoeng oa `poll` e ka fana ka [`Waker`], e leng mochini oa ho tsosa mosebetsi oa hajoale.
///
/// Ha u sebelisa future, ka kakaretso u ke ke ua letsetsa `poll` ka kotloloho, empa ho fapana le moo u tla bitsa boleng ba `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Mofuta oa boleng bo hlahisitsoeng qetellong.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Leka ho rarolla future ho boleng ba hoqetela, ho ngodisa mosebetsi wa ha jwale bakeng sa ho tsoha haeba boleng bo so fumanehe.
    ///
    /// # Khutlisa boleng
    ///
    /// Mosebetsi ona oa khutla:
    ///
    /// - [`Poll::Pending`] haeba future ha e so lokele
    /// - [`Poll::Ready(val)`] ka sephetho `val` sa future ena haeba e qetile ka katleho.
    ///
    /// Hang ha future e qetile, bareki ha baa lokela ho `poll` hape.
    ///
    /// Ha future e e-so lokisoe, `poll` e khutlisa `Poll::Pending` ebe e boloka lesela la [`Waker`] e kopitsitsoeng ho tsoa ho [`Context`] ea hajoale.
    /// [`Waker`] ena e tsosoa hang ha future e ka tsoela pele.
    /// Mohlala, future e emetse hore socket e balehe e ka letsetsa `.clone()` ho [`Waker`] ebe ee boloka.
    /// Ha lets'oao le fihla kae kae le bonts'a hore socket e baleha, [`Waker::wake`] ea bitsoa 'me socket mosebetsi oa future oa tsosoa.
    /// Hang ha mosebetsi o tsohile, o lokela ho leka `poll` future hape, e ka hlahisang boleng ba ho qetela kapa e ke keng ea e hlahisa.
    ///
    /// Hlokomela hore ho li-call tse ngata ho ea ho `poll`, ke [`Waker`] feela e tsoang ho [`Context`] e fetiselitsoeng mohala oa morao-rao e lokelang ho hlophisoa ho fumana tsoho.
    ///
    /// # Litšobotsi tsa nako ea ho qeta nako
    ///
    /// Futures feela li *inert*;ba tlameha ho *hloaetsoa* ka mafolofolo ho etsa tsoelo-pele, ho bolelang hore nako le nako ha mosebetsi oa hajoale o tsosoa, o lokela ho `` khetha '' ka mafolofolo ho emetse futures hore e ntse e na le tjantjello.
    ///
    /// Mosebetsi oa `poll` ha o bitsoe khafetsa ka mohala o thata-ho fapana le moo, o lokela ho bitsoa feela ha future e bontša hore e ikemiselitse ho hatela pele (ka ho letsetsa `wake()`).
    /// Haeba u tloaelane le li-syscalls tsa `poll(2)` kapa `select(2)` ho Unix ho bohlokoa ho hlokomela hore futures hangata ha e na * mathata a tšoanang le a "all wakeups must poll all events";li tšoana haholo le `epoll(4)`.
    ///
    /// Ts'ebetso ea `poll` e lokela ho loanela ho khutla kapele, mme ha ea lokela ho thibela.Ho khutlela kapele ho thibela ho koala likhoele kapa likonopo tsa ketsahalo ho sa hlokahale.
    /// Haeba ho tsejoa pele ho nako hore mohala oa `poll` o ka qetella o nkile nakoana, mosebetsi o lokela ho lahleloa letamong la khoele (kapa ho hong ho ts'oanang) ho netefatsa hore `poll` e ka khutla kapele.
    ///
    /// # Panics
    ///
    /// Hang ha future e phethile (e khutlisitse `Ready` ho tloha ho `poll`), e bitsa mokhoa oa eona oa `poll` hape e kanna ea ba panic, ea thiba ka ho sa feleng, kapa ea baka mefuta e meng ea mathata;`Future` trait ha e hloke litlhoko tsa litlamorao tsa mohala o joalo.
    /// Leha ho le joalo, ha mokhoa oa `poll` o sa tšoauoa `unsafe`, melao e tloaelehileng ea Rust ea sebetsa: mehala ha ea lokela ho baka boits'oaro bo sa hlalosoang (bobolu ba memori, ts'ebeliso e fosahetseng ea mesebetsi ea `unsafe`, kapa tse ling tse joalo), ho sa natse boemo ba future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}