use crate::future::Future;

/// Phetoho ho `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Litholoana tseo future e tla li hlahisa ha li phetheloa.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Ke mofuta ofe oa future oo re o fetolelang ho ona?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// E etsa future ho tloha boleng.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}