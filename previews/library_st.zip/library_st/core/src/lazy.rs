//! Litekanyetso tse botsoa le ho qalisoa ha data e le 'ngoe ka nako e le' ngoe.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Sele e ka ngolisoang hanngoe feela.
///
/// Ho fapana le `RefCell`, `OnceCell` e fana feela ka litšupiso tse arolelanoeng tsa `&T` ho boleng ba eona.
/// Ho fapana le `Cell`, `OnceCell` ha e hloke ho kopitsa kapa ho tlosa boleng ho e fumana.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // E sa fetoheng: e ngoletsoe hang hang.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// E etsa sele e ncha e se nang letho.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// E fumana ho buuoa ka boleng ba mantlha.
    ///
    /// E khutlisa `None` haeba sele e se na letho.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // TSHIRELETSO: E bolokehile ka lebaka la `` kahare '' e sa fetoheng
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// E fumana litšupiso tse ka fetoloang ho boleng ba mantlha.
    ///
    /// E khutlisa `None` haeba sele e se na letho.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // TŠIRELETSO: Re sireletsehile hobane re na le phihlello e ikhethang
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// E beha likateng tsa sele ho `value`.
    ///
    /// # Errors
    ///
    /// Mokhoa ona o khutlisa `Ok(())` haeba sele e ne e se na letho le `Err(value)` haeba e ne e tletse.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // TŠIRELETSO: Re sireletsehile hobane re ke ke ra ba le mekoloto e fetohang e ka fetohang
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // TSHIRELETSO: Mona ke hona feela moo re beileng sekotjana teng, ho se nang merabe
        // ka lebaka la reentrancy/concurrency hoa khoneha, 'me re hlahlobile hore slot hona joale ke `None`, ka hona sengoloa sena se boloka se kenang ka hare.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// O fumana likahare tsa sele, o e qala ka `f` haeba sele e ne e se na letho.
    ///
    /// # Panics
    ///
    /// Haeba `f` panics, panic e fetisetsoa ho moletsi, mme sele e lula e sa qalisoa.
    ///
    ///
    /// Ke phoso ho kenya sele ka mokhoa o khutlisetsang ho `f`.Ho etsa joalo ho hlahisa panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// O fumana likahare tsa sele, o e qala ka `f` haeba sele e ne e se na letho.
    /// Haeba sele e ne e se na letho mme `f` e hloleha, ho khutlisoa phoso.
    ///
    /// # Panics
    ///
    /// Haeba `f` panics, panic e fetisetsoa ho moletsi, mme sele e lula e sa qalisoa.
    ///
    ///
    /// Ke phoso ho kenya sele ka mokhoa o khutlisetsang ho `f`.Ho etsa joalo ho hlahisa panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Hlokomela hore * mefuta e meng ea ho kenya tšebetsong hape e ka lebisa ho UB (bona tlhahlobo ea `reentrant_init`).
        // Ke lumela hore ho tlosa `assert` ena feela, ha u ntse u boloka `set/get` ho ka utloahala, empa ho bonahala ho le betere ho panic, ho fapana le ho sebelisa boleng ba khale ka khutso.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// E sebelisa sele, e khutlisa boleng bo phuthetsoeng.
    ///
    /// E khutlisa `None` haeba sele e ne e se na letho.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Hobane `into_inner` e nka `self` ka boleng, motlatsi o tiisa hore ha e alingoe hajoale.
        // Kahoo ho bolokehile ho tsoa `Option<T>`.
        self.inner.into_inner()
    }

    /// E nka boleng ho `OnceCell` ena, ee khutlisetsa maemong a sa qalisoang.
    ///
    /// Ha e na matla mme e khutlisa `None` haeba `OnceCell` e sa qalisoa.
    ///
    /// Polokeho e netefalitsoe ka ho hloka hore ho sebelisoe phetoho.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Boleng bo qalileng phihlelong ea pele.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   e loketse ho qala
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// E theha boleng bo bocha bo botsoa ka ts'ebetso e fanoeng ea ho qala.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// E qobella tlhahlobo ea boleng bona bo botsoa ebe e khutlisetsa leqhubu la sephetho.
    ///
    ///
    /// Sena se lekana le `Deref` impl, empa e hlakile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// E theha boleng bo bocha bo botsoa bo sebelisa `Default` joalo ka ts'ebetso ea ho qala.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}