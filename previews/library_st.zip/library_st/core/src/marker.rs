//! Primitive traits le mefuta e emelang thepa ea mantlha ea mefuta.
//!
//! Mefuta ea Rust e ka aroloa ka litsela tse fapaneng tse nang le thuso ho latela thepa ea eona ea tlhaho.
//! Likarolo tsena li emeloa e le traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mefuta e ka fetisoang ho tlola meeli ea likhoele.
///
/// trait ena e kenngwa tshebetsong ka bo yona ha motlatsi a bona hore e loketse.
///
/// Mohlala oa mofuta o seng oa `Send` ke sesupa-palo sa ho bala sa [`rc::Rc`][`Rc`].
/// Haeba likhoele tse peli li leka ho kopanya [`Rc`] s tse supang boleng bo lekantsoeng bo lekantsoeng, ba kanna ba leka ho ntlafatsa palo ea litšupiso ka nako e ts'oanang, e leng [undefined behavior][ub] hobane [`Rc`] ha e sebelise ts'ebetso ea athomo.
///
/// Motsoala oa hae [`sync::Arc`][arc] o sebelisa ts'ebetso ea athomo (e hlahisang lihlooho tse ling) mme ka hona ke `Send`.
///
/// Bona [the Nomicon](../../nomicon/send-and-sync.html) bakeng sa lintlha tse ling.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Mefuta e nang le boholo bo sa fetoheng bo tsejoang ka nako ea pokello.
///
/// Mefuta eohle ea mekhahlelo e na le tlamo e hlakileng ea `Sized`.Syntax `?Sized` e khethehileng e ka sebelisoa ho tlosa tlamo ena haeba e sa nepahala.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // moralo FooUse(Foo<[i32]>);//phoso: Boholo ha bo kenngoe tšebetsong bakeng sa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Mokhelo o le mong ke mofuta o hlakileng oa `Self` oa trait.
/// trait ha e na `Sized` e hlakileng e tlamang kaha sena ha se lumellane le [trait object] s moo, ka tlhaloso, trait e hlokang ho sebetsa le bohle ba kenyang ts'ebetsong, ka hona e ka ba boholo bofe kapa bofe.
///
///
/// Le ha Rust e tla u tlohella `Sized` ho trait, u ke ke ua khona ho e sebelisa ho theha ntho ea trait hamorao:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // A re ke re: &dyn Bar= &Impl;//phoso: trait `Bar` e ke ke ea etsoa ntho
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // bakeng sa Default, mohlala, e hlokang hore `[T]: !Default` e hlahlojoe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Mefuta e ka bang "unsized" ho mofuta o matla haholo.
///
/// Mohlala, mofuta oa boholo ba mofuta oa `[i8; 2]` o sebelisa `Unsize<[i8]>` le `Unsize<dyn fmt::Debug>`.
///
/// Ts'ebetsong eohle ea `Unsize` e fanoa ka boiketsetso ke motlatsi.
///
/// `Unsize` e kenngwa tshebetsong bakeng sa:
///
/// - `[T; N]` ke `Unsize<[T]>`
/// - `T` ke `Unsize<dyn Trait>` ha `T: Trait`
/// - `Foo<..., T, ...>` ke `Unsize<Foo<..., U, ...>>` haeba:
///   - `T: Unsize<U>`
///   - Foo ke sebopeho
///   - Ke tšimo ea ho qetela ea `Foo` feela e nang le mofuta o kenyelletsang `T`
///   - `T` ha se karolo ea mofuta oa likarolo tse ling
///   - `Bar<T>: Unsize<Bar<U>>`, haeba tšimo ea ho qetela ea `Foo` e na le mofuta oa `Bar<T>`
///
/// `Unsize` e sebelisoa hammoho le [`ops::CoerceUnsized`] ho lumella lijana tsa "user-defined" tse kang [`Rc`] ho ba le mefuta ea boholo bo matla.
/// Bona [DST coercion RFC][RFC982] le [the nomicon entry on coercion][nomicon-coerce] bakeng sa lintlha tse ling.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait e hlokahalang bakeng sa linako tse sebelisoang lipapaling tsa paterone.
///
/// Mofuta ofe kapa ofe o fumanang `PartialEq` o sebelisa trait ka bo eona,*ho sa tsotelehe* hore na mekhahlelo ea eona e sebelisa `Eq`.
///
/// Haeba ntho ea `const` e na le mofuta o mong o sa sebeliseng trait, mofuta oo e ka ba (1.) ha e sebelise `PartialEq` (e bolelang hore kamehla e ke ke ea fana ka mokhoa oo oa papiso, o hlahisang khoutu e teng), kapa (2.) e sebelisa Mofuta oa `PartialEq` (oo re nahanang hore ha o lumellane le papiso ea tekano ea sebopeho).
///
///
/// Ho e 'ngoe ea liketsahalo tse peli tse kaholimo, re hana ts'ebeliso ea tloaelo e joalo papaling ea mohlala.
///
/// Bona hape [structural match RFC][RFC1445], le [issue 63438] e khothalelitseng ho falla ho tloha meralo e thehiloeng ho boleng ho trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait e hlokahalang bakeng sa linako tse sebelisoang lipapaling tsa paterone.
///
/// Mofuta ofe kapa ofe o fumanang `Eq` o sebelisa trait ka bo eona,*ho sa tsotelehe* hore na mekhahlelo ea eona ea mofuta e sebelisa `Eq`.
///
/// Hona ke ho qhekella ho sebetsa ho potoloha moeli tsamaisong ea mofuta oa rona.
///
/// # Background
///
/// Re batla ho hloka hore mefuta ea li-const e sebelisitsoeng lipapaling tsa paterone e na le semelo sa `#[derive(PartialEq, Eq)]`.
///
/// Lefatšeng le letle ho feta moo, re ka sheba tlhoko eo ka ho sheba feela hore mofuta o fanoeng o sebelisa `StructuralPartialEq` trait *le*`Eq` trait.
/// Leha ho le joalo, u ka ba le li-ADT tse etsang * `derive(PartialEq, Eq)`, 'me u be nyeoe eo re batlang hore moqapi a e amohele, leha ho le joalo mofuta oa kamehla o hloleha ho kenya tšebetsong `Eq`.
///
/// Ka mantsoe a mang, nyeoe e kang ena:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Bothata ba khoutu e kaholimo ke hore `Wrap<fn(&())>` ha e sebelise `PartialEq`, kapa `Eq`, hobane `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Ka hona, re ke ke ra ts'epa cheke ea lefeela bakeng sa `StructuralPartialEq` le `Eq` feela.
///
/// Ha re qhekella ho sebetsa ho potoloha sena, re sebelisa traits tse peli tse arotsoeng ka e 'ngoe ea tse peli tsa (`#[derive(PartialEq)]` le `#[derive(Eq)]`) mme re lekole hore ka bobeli li teng e le karolo ea ho lekola papali.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Mefuta eo boleng ba eona bo ka kopitsoang habonolo feela ka ho kopitsa likotoana.
///
/// Ka boiketsetso, litlamo tse fapaneng li na le 'semantics ea ho sisinyeha.'Ka mantsoe a mang:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` e se e kene `y`, ka hona e ke ke ea sebelisoa
///
/// // println! ("{: ?}", x);//phoso: tšebeliso ea boleng bo fallisitsoeng
/// ```
///
/// Leha ho le joalo, haeba mofuta o sebelisa `Copy`, e na le 'copy semantics':
///
/// ```
/// // Re ka fumana ts'ebetsong ea `Copy`.
/// // `Clone` e ea hlokahala, kaha ke supertrait ea `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ke kopi ea `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Ho bohlokoa ho hlokomela hore mehlaleng ena e 'meli, phapang e le' ngoe feela ke hore na u lumelloa ho fihlella `x` kamora kabelo.
/// Tlas'a ntlo, kopi le motsamao li ka fella ka hore likoto li kopitsoe mohopolong, leha ka linako tse ling li ntlafatsoa.
///
/// ## Nka kenya `Copy` joang?
///
/// Ho na le mekhoa e 'meli ea ho kenya ts'ebetsong `Copy` ka mofuta oa hau.E bonolo ka ho fetisisa ke ho sebelisa `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// U ka kenya `Copy` le `Clone` ka letsoho:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ho na le phapang e nyane lipakeng tsa tsena tse peli: leano la `derive` le tla beha `Copy` e tlamelletsoeng ka mekhahlelo ea mofuta, e sa batloang kamehla.
///
/// ## Phapang ke efe lipakeng tsa `Copy` le `Clone`?
///
/// Likopi li etsahala ka mokhoa o hlakileng, mohlala e le karolo ea kabelo ea `y = x`.Boitšoaro ba `Copy` ha bo imeloe haholo;ka mehla ke kopi e bonolo e batlang e le bohlale.
///
/// Cloning ke ketso e hlakileng, `x.clone()`.Ho kengoa tšebetsong ha [`Clone`] ho ka fana ka boits'oaro bo ikhethileng ba mofuta o mong le o mong bo hlokahalang ho etsisa boleng ka mokhoa o sireletsehileng
/// Mohlala, ho kengoa tšebetsong ha [`Clone`] bakeng sa [`String`] ho hloka ho kopitsa mohala o tobisitsoeng ho khoele.
/// Kopi e bonolo feela ea linomoro tsa [`String`] e ka kopitsa sesupa feela, e lebisang ho mahala habeli moleng.
/// Ka lebaka lena, [`String`] ke [`Clone`] empa eseng `Copy`.
///
/// [`Clone`] ke supertrait ea `Copy`, ka hona ntho e ngoe le e ngoe e `Copy` e tlameha ho kenya ts'ebetsong [`Clone`].
/// Haeba mofuta ke `Copy`, ts'ebetso ea eona ea [`Clone`] e hloka feela ho khutlisa `*self` (bona mohlala o kaholimo).
///
/// ## Mofuta oa ka o ka ba `Copy` neng?
///
/// Mofuta o ka kenya ts'ebetsong `Copy` haeba likarolo tsohle tsa eona li kenya tšebetsong `Copy`.Mohlala, sebopeho sena e ka ba `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Moralo e ka ba `Copy`, mme [`i32`] ke `Copy`, ka hona `Point` e tšoaneleha ho ba `Copy`.
/// Ka lehlakoreng le leng, nahana
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Moralo `PointList` o sitoa ho kenya ts'ebetsong `Copy`, hobane [`Vec<T>`] ha se `Copy`.Haeba re leka ho fumana ts'ebetsong ea `Copy`, re tla fumana phoso:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Litšupiso tse arolelanoeng (`&T`) le tsona ke `Copy`, ka hona mofuta o ka ba `Copy`, leha e na le litšupiso tse arolelanoeng tsa mefuta `T` eo e seng * `Copy`.
/// Nahana ka sebopeho se latelang, se ka kenyang ts'ebetsong `Copy`, hobane e na le ts'upiso e arolelanoeng feela * ea mofuta oa rona o seng oa `Copy` `PointList` holimo:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Mofuta oa ka o ke ke oa ba `Copy`?
///
/// Mefuta e meng e ke ke ea kopitsoa ka polokeho.Mohlala, ho kopitsa `&mut T` ho ka hlahisa litšupiso tse ka feto-fetohang.
/// Ho kopitsa [`String`] ho ne ho ka etsisa boikarabello ba ho tsamaisa buffer ea [`String`], e lebisang ho mahala.
///
/// Ho etsa nyeoe ea ho qetela, mofuta ofe kapa ofe o sebelisang [`Drop`] e ke ke ea e-ba `Copy`, hobane e tsamaisa lisebelisoa tse ling ntle le li-byte tsa eona tsa [`size_of::<T>`].
///
/// Haeba u leka ho kenya tšebetsong `Copy` ho struct kapa enum e nang le data eo e seng ea`Copy`, u tla fumana phoso [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Mofuta oa ka o lokela ho ba `Copy` neng?
///
/// Ka kakaretso, haeba mofuta oa hau _can_ o kenya ts'ebetsong `Copy`, e lokela.
/// Hopola, leha ho le joalo, hore ts'ebetsong `Copy` ke karolo ea API ea sechaba ea mofuta oa hau.
/// Haeba mofuta o ka fetoha non-`Copy` ho future, ho ka ba bohlale ho tlohela ts'ebetso ea `Copy` hona joale, ho qoba phetoho e senyehang ea API.
///
/// ## Batlatsi ba bang
///
/// Ntle le [implementors listed below][impls], mefuta e latelang e kenya ts'ebetsong `Copy`:
///
/// * Mefuta ea lintho tsa mosebetsi (ke hore, mefuta e ikhethileng e hlalositsoeng bakeng sa tšebetso ka 'ngoe)
/// * Mefuta ea sesupi sa mosebetsi (mohlala, `fn() -> i32`)
/// * Mefuta ea mefuta, bakeng sa boholo bohle, haeba mofuta oa ntho le eona e sebelisa `Copy` (mohlala, `[i32; 123456]`)
/// * Mefuta ea Tuple, haeba karolo ka 'ngoe e sebelisa `Copy` (mohlala, `()`, `(i32, bool)`)
/// * Mefuta ea ho koala, haeba e sa fumane boleng ba tikoloho kapa haeba litekanyetso tsohle tse hapuoeng li kenya tšebetsong `Copy` ka botsona.
///   Hlokomela hore mefuta-futa e hapuoeng ke litšupiso tse arolelanoang e kenya ts'ebetsong `Copy` (le haeba sebapali se sa etse joalo), ha mefuta e hapuoeng ke litšupiso tse ka fetohang e sa sebelise `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Sena se lumella ho kopitsa mofuta o sa sebeliseng `Copy` ka lebaka la meeli e sa khotsofatseng ea bophelo bohle (ho kopitsa `A<'_>` ha feela `A<'static>: Copy` le `A<'_>: Clone`).
// Re na le semelo sena hajoale hobane feela ho na le litsebo tse seng kae tse seng li ntse li le teng ho `Copy` tse seng li ntse li le teng laeboraring e tloaelehileng, 'me ha ho na mokhoa oa ho ba le boits'oaro bona hona joale.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Fumana tlhahiso e kholo ea trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mefuta eo ho bolokehileng ho arolelana litšupiso lipakeng tsa likhoele.
///
/// trait ena e kenngwa tshebetsong ka bo yona ha motlatsi a bona hore e loketse.
///
/// Tlhaloso e nepahetseng ke: mofuta `T` ke [`Sync`] haeba feela `&T` e le [`Send`].
/// Ka mantsoe a mang, haeba ho se na monyetla oa [undefined behavior][ub] (ho kenyeletsoa merabe ea data) ha ho fetisoa litšupiso tsa `&T` lipakeng tsa likhoele.
///
/// Joalo ka ha motho a ne a ka lebella, mefuta ea khale e kang [`u8`] le [`f64`] kaofela ke [`Sync`], mme ho joalo le ka mefuta e bonolo e kopaneng e nang le tsona, joalo ka li-tuples, structs le enums.
/// Mehlala e meng ea mefuta ea mantlha ea [`Sync`] e kenyelletsa mefuta ea "immutable" joalo ka `&T`, le tse nang le phetoho e bonolo e futsitsoeng, joalo ka [`Box<T>`][box], [`Vec<T>`][vec] le mefuta e meng e mengata ea pokello.
///
/// (Meeli ea generic e hloka ho ba [`Sync`] hore setshelo sa eona e be [`Sync`].)
///
/// Phello e makatsang ea tlhaloso ke hore `&mut T` ke `Sync` (haeba `T` ke `Sync`) leha e bonahala e ka fana ka phetoho e sa lumellaneng.
/// Ho qhekella ke hore ts'upiso e ka feto-fetohang ka morao ho ts'ebeliso e arolelanoeng (ke hore, `& &mut T`) e baleha feela, joalo ka ha eka ke `& &T`.
/// Kahoo ha ho na kotsi ea peiso ea data.
///
/// Mefuta eo e seng `Sync` ke e nang le "interior mutability" ka mokhoa o sa sireletsehang, joalo ka [`Cell`][cell] le [`RefCell`][refcell].
/// Mefuta ena e lumella phetoho ea likahare tsa eona leha e le ka mokhoa o sa fetoheng, o arolelanoang.
/// Mohlala, mokhoa oa `set` ho [`Cell<T>`][cell] o nka `&self`, ka hona e hloka feela reference e arolelanoeng [`&Cell<T>`][cell].
/// Mokhoa ha o lumellane, ka hona [`Cell`][cell] e ke ke ea ba `Sync`.
///
/// Mohlala o mong oa mofuta o seng oa `Sync` ke sesupa-palo sa ho bala [`Rc`][rc].
/// Ha ho fanoa ka [`&Rc<T>`][rc] efe kapa efe ea litšupiso, u ka kopanya [`Rc<T>`][rc] e ncha, 'me ua fetola lipalo tsa litšupiso ka tsela eo e seng ea athomo.
///
/// Bakeng sa linyeoe ha motho a hloka phetoho e kahare e sireletsehileng ea hare, Rust e fana ka [atomic data types], hammoho le ho notlela ka mokhoa o hlakileng ka [`sync::Mutex`][mutex] le [`sync::RwLock`][rwlock].
/// Mefuta ena e netefatsa hore phetoho efe kapa efe e ke keng ea baka merabe ea data, ka hona mefuta ke `Sync`.
/// Ka mokhoa o ts'oanang, [`sync::Arc`][arc] e fana ka analogue e sireletsehileng ea [`Rc`][rc].
///
/// Mefuta efe kapa efe e nang le phetoho ea kahare e tlameha ho sebelisa sekoahelo sa [`cell::UnsafeCell`][unsafecell] ho potoloha value(s) e ka fetoloang ka mokhoa o arolelanoeng.
/// Ho hloleha ho etsa sena ke [undefined behavior][ub].
/// Mohlala, [`transmute`][transmute]-ing ho tloha `&T` ho isa ho `&mut T` ha e sebetse.
///
/// Bona [the Nomicon][nomicon-send-and-sync] bakeng sa lintlha tse ling mabapi le `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): hang ts'ehetso ea ho eketsa lintlha linaheng tsa `rustc_on_unimplemented` ho beta, 'me e atolositsoe ho netefatsa hore na ho koaloa ho kae kapa kae ketaneng ea tlhoko, e atolose joalo ka (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Mofuta oa boholo ba zero o sebelisetsoang ho tšoaea lintho tseo "act like" ba nang le tsona `T`.
///
/// Ho eketsa tšimo ea `PhantomData<T>` ho mofuta oa hau ho bolella moqapi hore mofuta oa hau o sebetsa joalo ka ha eka o boloka boleng ba mofuta oa `T`, leha e hlile e se joalo.
/// Tlhahisoleseling ena e sebelisoa ha ho sebelisoa lisebelisoa tse ling tsa polokeho.
///
/// Bakeng sa tlhaloso e tebileng ea hore na u ka sebelisa `PhantomData<T>` joang, ka kopo bona [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Lengolo le tšosang 👻👻👻
///
/// Le ha ka bobeli ba na le mabitso a tšosang, `PhantomData` le 'phantom types' lia amana, empa ha li tšoane.Moetso oa mofuta oa phantom ke mofuta oa parameter o sa sebelisoeng le ka mohla.
/// Ho Rust, hangata sena se etsa hore moqapi a tletleba, mme tharollo ke ho eketsa ts'ebeliso ea "dummy" ka `PhantomData`.
///
/// # Examples
///
/// ## Mekhahlelo e sa sebelisoang ea bophelo bohle
///
/// Mohlomong nyeoe e sebelisoang haholo bakeng sa `PhantomData` ke sebopeho se nang le parameter ea bophelo e sa sebelisoang, hangata e le karolo ea khoutu e sa bolokehang.
/// Mohlala, mona ke `Slice` e nang le lits'oants'o tse peli tsa mofuta `*const T`, mohlomong e supa ka bongata sebakeng se seng:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Morero ke hore data ea mantlha e sebetsa feela bakeng sa `'a` ea bophelo bohle, kahoo `Slice` ha ea lokela ho phela `'a`.
/// Leha ho le joalo, sepheo sena ha se hlahisoe ke khoutu, hobane ha ho na ts'ebeliso ea `'a` ea bophelo bohle ka hona ha ho hlake hore na e sebetsa ho data efe.
/// Re ka lokisa sena ka ho joetsa moqapi hore a sebetse * joalo ka ha eka `Slice` e na le sets'oants'o sa `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Hona le hona ho hloka hore poleloana e reng `T: 'a`, e bontše hore litšupiso life kapa life tsa `T` li nepahetse nakong ea bophelo ba `'a`.
///
/// Ha o qala `Slice` o fana ka boleng ba `PhantomData` bakeng sa tšimo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Mefuta ea mofuta o sa sebelisoang
///
/// Ka linako tse ling ho etsahala hore o be le mefuta ea mofuta o sa sebelisoeng e bonts'ang hore na "tied" ea data ke ea mofuta ofe, leha data eo e sa fumanehe ho eona ka boeona.
/// Mohlala ke ona moo sena se hlahang ka [FFI].
/// Sebopeho sa kantle ho naha se sebelisa mefuta ea mofuta `*mut ()` ho supa boleng ba Rust ba mefuta e fapaneng.
/// Re latela mofuta oa Rust re sebelisa mofuta oa phantom paramethara ho `ExternalResource` e koahelang mohele.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ho ba monga le cheke ea lerotholi
///
/// Ho eketsa tšimo ea mofuta `PhantomData<T>` ho bonts'a hore mofuta oa hau o na le data ea mofuta `T`.Sena se fana ka maikutlo a hore ha mofuta oa hau o theotsoe, o kanna oa theola ketsahalo e le 'ngoe kapa ho feta tsa mofuta oa `T`.
/// Sena se amana le tlhahlobo ea [drop check] ea Rust.
///
/// Haeba sebopeho sa hau ha se na data ea mofuta oa `T`, ho molemo ho sebelisa mofuta oa litšupiso, joalo ka `PhantomData<&'a T>` (ideally) kapa `PhantomData<*const T>` (haeba ho se na nako ea bophelo), e le hore o se bonts'a beng.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Moqapi-oa kahare trait o ne a sebelisoa ho bonts'a mofuta oa khethollo ea enum.
///
/// trait ena e kenngwa ts'ebetsong ka mokhoa o ikemetseng bakeng sa mofuta o mong le o mong mme ha e kenye tiisetso ho [`mem::Discriminant`].
/// Ke **boits'oaro bo sa hlalosoang** ho fetisa lipakeng tsa `DiscriminantKind::Discriminant` le `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Mofuta oa khethollo, o tlamehang ho khotsofatsa trait bound e hlokoang ke `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Moqapi-oa ka hare trait o sebelisetsoa ho tseba hore na mofuta o na le `UnsafeCell` kahare, empa eseng ka ho kenella.
///
/// Sena se ama, ho etsa mohlala, hore na `static` ea mofuta oo e kentsoe mohopolong oa static memory kapa static memory.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Mefuta e ka tsamauoang ka ts'ireletseho kamora ho hatoa.
///
/// Rust ka boeona ha e na mohopolo oa mefuta e sa sisinyeheng, mme e nka mehato (mohlala, ka kabelo kapa [`mem::replace`]) hore e bolokehe kamehla.
///
/// Mofuta oa [`Pin`][Pin] oa sebelisoa ho fapana le ho thibela ho tsamaea ka mofuta oa sistimi.Lintlha tsa `P<T>` tse phuthetsoeng ka sekoahelo sa [`Pin<P<T>>`][Pin] li ke ke tsa ntšoa ka ntle ho tsona.
/// Bona litokomane tsa [`pin` module] bakeng sa tlhaiso-leseling e batsi ka ho pinning.
///
/// Ho kenya ts'ebetsong `Unpin` trait bakeng sa `T` ho tlosa lithibelo tsa ho hlopha mofuta, o lumellang `T` ho tsoa [`Pin<P<T>>`][Pin] ka mesebetsi e kang [`mem::replace`].
///
///
/// `Unpin` ha e na litlamorao ho hang bakeng sa data e sa buloang.
/// Ka ho khetheha, [`mem::replace`] e tsamaisa data ea `!Unpin` ka thabo (e sebeletsa `&mut T` efe kapa efe, eseng ha `T: Unpin` feela).
/// Leha ho le joalo, u ke ke ua sebelisa [`mem::replace`] ho data e phuthetsoeng ka hare ho [`Pin<P<T>>`][Pin] hobane u ke ke ua fumana `&mut T` eo ue hlokang bakeng sa eona, 'me *that* ke eona e etsang hore sistimi ena e sebetse.
///
/// Kahoo, ka mohlala, ho ka etsoa feela ka mefuta e sebelisang `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Re hloka ts'upiso e ka feto-fetohang ho letsetsa `mem::replace`.
/// // Re ka fumana litšupiso tse joalo ka (implicitly) e kenyelletsang `Pin::deref_mut`, empa seo se ka etsahala hobane `String` e kenya ts'ebetsong `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait ena e kenngwa ts'ebetsong ka bo eona bakeng sa mofuta o mong le o mong.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Mofuta oa lesupa o sa sebeliseng `Unpin`.
///
/// Haeba mofuta o na le `PhantomPinned`, e ke ke ea kenya tšebetsong `Unpin` ka boiketsetso.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ts'ebetsong ea `Copy` bakeng sa mefuta ea khale.
///
/// Ts'ebetsong e ke keng ea hlalosoa ho Rust e kenngwa ts'ebetsong ho `traits::SelectionContext::copy_clone_conditions()` ho `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Litšupiso tse arolelanoeng li ka kopitsoa, empa litšupiso tse ka feto-fetohang *ha li khone*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}