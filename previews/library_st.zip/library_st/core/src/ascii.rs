//! Ts'ebetso ho likhoele le litlhaku tsa ASCII.
//!
//! Boholo ba ts'ebetso ea likhoele ho Rust e sebetsa ka likhoele tsa UTF-8.
//! Leha ho le joalo, ka linako tse ling hoa utloahala ho nahana feela ka sebopeho sa ASCII se hlophiselitsoeng ts'ebetso e itseng.
//!
//! Mosebetsi oa [`escape_default`] o fana ka iterator holim'a li-byte tsa mofuta o balehileng oa semelo se fanoeng.
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// Iterator mabapi le mofuta o balehileng oa byte.
///
/// `struct` ena e entsoe ke mosebetsi oa [`escape_default`].
/// Bona litokomane tsa eona bakeng sa tse ling.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// E khutlisa iterator e hlahisang mofuta oa `u8` o phonyohileng.
///
/// Ho sa feleng ho khethoa ka leeme la ho hlahisa lingoliloeng tse molaong ka lipuo tse fapaneng, ho kenyeletsoa C++ 11 le lipuo tse tšoanang tsa C-tsa malapa.
/// Melao e tobileng ke:
///
/// * Tab e phonyohile joalo ka `\t`.
/// * Ho khutla ha makoloi ho baleha joalo ka `\r`.
/// * Line feed li phonyoha joalo ka `\n`.
/// * Qotso e le 'ngoe e phonyohile joalo ka `\'`.
/// * Ho qotsitsoe mantsoe a mabeli joalo ka `\"`.
/// * Ho khutlela morao ho phonyoha joalo ka `\\`.
/// * Sebopeho se seng le se seng sa 'printable ASCII' `0x20` .. `0x7e` e kenyellelitsoeng ha e balehe.
/// * Mekhoa e meng le e meng e fuoa phonyoha ea hex ea mofuta '\xNN'.
/// * Ho phonyoha ha Unicode ha ho mohla ho hlahisoang ke mosebetsi ona.
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // TSHIRELETSO: ho lokile hobane `escape_default` e thehile feela data e sebetsang ea utf-8
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}