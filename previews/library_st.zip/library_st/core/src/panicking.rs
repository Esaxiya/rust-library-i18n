//! Ts'ehetso ea Panic bakeng sa libcore
//!
//! Laeborari ea mantlha e ke ke ea hlalosa ho tšoha, empa e * phatlalatsa ho tšoha.
//! Sena se bolela hore mesebetsi e kahare ho libcore e lumelloa ho panic, empa ho ba molemo crate e nyolohang e tlameha ho hlalosa ho tšoha ha libcore ho e sebelisa.
//! Sebopeho sa hajoale sa ho tšoha ke:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Tlhaloso ena e lumella ho tšoha ka molaetsa o akaretsang, empa ha e lumelle ho hloleha ka boleng ba `Box<Any>`.
//! (`PanicInfo` e na le `&(dyn Any + Send)` feela, eo re tlatsang boleng ba dummy ho `PanicInfo: : internal_constructor`.) Lebaka la sena ke hore libcore ha ea lumelloa ho aba.
//!
//!
//! Mojule ona o na le mesebetsi e meng e 'maloa e tšosang, empa tsena ke lintho tsa lang tse hlokahalang bakeng sa moqapi.Tsohle panics li hlophisitsoe ka ts'ebetso ena e le 'ngoe.
//! Letšoao la 'nete le phatlalatsoa ka boleng ba `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Ts'ebetsong ea mantlha ea XcoreX macro ea libcore ha ho sa sebelisoe fomate.
#[cold]
// le ka mohla u se ke ua kenella mola ntle le ha u tšaba_e leng_ho qoba ho thibela likhakanyo tsa libaka libakeng tsa mehala kamoo ho ka khonehang
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // e hlokahala ka codegen bakeng sa panic ha e khaphatseha le li-terminator tse ling tsa `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Sebelisa Arguments::new_v1 sebakeng sa format_args! ("{}", Expr) ho fokotsa boholo ba hlooho.
    // Mefuta_args!macro e sebelisa str's Display trait ho ngola expr, e bitsang Formatter::pad, e tlamehang ho amohela khoele truncation le padding (leha ho se na e sebelisoang mona).
    //
    // Ho sebelisa Arguments::new_v1 ho ka lumella moqapi hore a tlohele Formatter::pad ho tsoa ho binary e hlahisang, ho boloka ho li-kilobyte tse 'maloa.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // e hlokahala bakeng sa tlhahlobo ea panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // e hlokahalang ka codegen bakeng sa panic ho fihlella OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ts'ebetsong ea mantlha ea XcoreX macro ea libcore ha ho sebelisoa sebopeho.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // TLHOKOMELISO Mosebetsi ona ha o tšele moeli oa FFI;ke mohala oa Rust-to-Rust o rarolloang ts'ebetsong ea `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // TSHIRELETSO: `panic_impl` e hlaloswa ka khoutu e bolokehileng ya Rust mme ka hona e bolokehile ho ka letsetsoa.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Ts'ebetso ea kahare ea `assert_eq!` le `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}