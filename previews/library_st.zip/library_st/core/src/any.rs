//! Mojule ona o sebelisa `Any` trait, e nolofalletsang ho thaepa ka mokhoa o matla oa mofuta ofe kapa ofe oa `'static` ka ho bonahatsa nako ea ho sebetsa.
//!
//! `Any` ka boeona e ka sebelisoa ho fumana `TypeId`, 'me e na le likarolo tse ling ha e sebelisoa e le ntho ea trait.
//! Joaloka `&dyn Any` (ntho e alimiloeng trait), e na le mekhoa ea `is` le `downcast_ref`, ho leka hore na boleng bo teng ke ba mofuta o fanoeng, le ho fumana boleng ba kahare e le mofuta.
//! Joaloka `&mut dyn Any`, ho boetse ho na le mokhoa oa `downcast_mut`, bakeng sa ho fumana litšupiso tse ka fetoloang ho boleng ba kahare.
//! `Box<dyn Any>` e eketsa mokhoa oa `downcast`, o lekang ho o fetolela ho `Box<T>`.
//! Bona litokomane tsa [`Box`] bakeng sa lintlha tse felletseng.
//!
//! Hlokomela hore `&dyn Any` e lekanyelitsoe ho lekeng hore na boleng ke ba mofuta o itseng oa konkreite, 'me e ke ke ea sebelisoa ho lekola hore na mofuta o sebelisa trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Litlhahiso tse bohlale le `dyn Any`
//!
//! Boitšoaro bo lokelang ho hopoloa kelellong ea hau ha u sebelisa `Any` e le ntho ea trait, haholoholo ka mefuta e kang `Box<dyn Any>` kapa `Arc<dyn Any>`, ke hore ho letsetsa `.type_id()` ka boleng ho tla hlahisa `TypeId` ea setshelo *, eseng ntho ea motheo ea trait.
//!
//! Sena se ka qojoa ka ho fetola pointer e bohlale hore e be `&dyn Any` ho fapana, e tla khutlisa `TypeId` ea ntho.
//! Ka mohlala:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // U na le monyetla oa ho batla sena:
//! let actual_id = (&*boxed).type_id();
//! // ... ho feta mona:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Nahana ka boemo boo re batlang ho fumana boleng bo fetiselitsoeng ho mosebetsi.
//! Rea tseba boleng boo re sebetsang ho bona bo sebelisa lisebelisoa tsa Debug, empa ha re tsebe mofuta oa eona oa konkreite.Re batla ho fana ka kalafo e khethehileng mefuteng e itseng: ntlheng ena re hatisa bolelele ba litekanyetso tsa String pele ho boleng ba tsona.
//! Ha re tsebe mofuta oa konkreite ea boleng ba rona ka nako ea ho bokella, kahoo re hloka ho sebelisa nako ea ho bona nako ea ho matha.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger e sebetsa bakeng sa mofuta ofe kapa ofe o sebelisang Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Leka ho fetolela boleng ba rona ho `String`.
//!     // Haeba re atlehile, re batla ho hlahisa bolelele ba String`` hammoho le boleng ba eona.
//!     // Haeba ho se joalo, ke mofuta o fapaneng: e hatise feela u sa khabisa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Mosebetsi ona o batla ho notlolla paramethara ea ona pele o ka sebetsa le eona.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... etsa mosebetsi o mong
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Leha e le efe trait
///////////////////////////////////////////////////////////////////////////////

/// trait ho etsisa ho ngola ho matla.
///
/// Mefuta e mengata e kenya ts'ebetsong `Any`.Leha ho le joalo, mofuta ofe kapa ofe o nang le sets'oants'o sa e seng `` static 'ha o joalo.
/// Bona [module-level documentation][mod] bakeng sa lintlha tse ling.
///
/// [mod]: crate::any
// trait ena ha e bolokehe, leha re its'etleha holima ts'ebetso ea XsUM `type_id` ea impl ea khoutu e sa bolokehang (mohlala, `downcast`).Ka tloaelo, seo e ka ba bothata, empa hobane moelelo feela oa `Any` ke ts'ebetsong ea kobo, ha ho na khoutu e ngoe e ka sebelisang `Any`.
//
// Re ka etsa hore trait ena e se bolokehe-e ke ke ea baka tšenyo, hobane re laola ts'ebetsong eohle-empa re khetha ho se etse joalo ka ha e sa hlokehe ebile e ka ferekanya basebelisi ka phapang ea traits e sa bolokehang le mekhoa e sa bolokehang (ke hore, `type_id` e ntse e ka bolokeha ho letsa, empa re kanna ra batla ho bontša joalo ka litokomane).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// O fumana `TypeId` ea `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Mekhoa ea katoloso bakeng sa lintho life kapa life tsa trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Netefatsa hore sephetho sa mohlala, ho kopanya khoele se ka hatisoa ka hona sa sebelisoa le `unwrap`.
// Qetellong e kanna ea se hlole e hlokahala ha ho romelloa ho sebetsa ka mokhoa oa upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// E khutlisa `true` haeba mofuta oa mabokose o ts'oana le `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Fumana `TypeId` ea mofuta ona o kentsoeng tšebetsong ena.
        let t = TypeId::of::<T>();

        // Fumana `TypeId` ea mofuta oa ntho ea trait (`self`).
        let concrete = self.type_id();

        // Bapisa li-TypeId` ka bobeli ka tekano.
        t == concrete
    }

    /// E khutlisetsa ts'upiso e 'ngoe ho boleng ba mabokose haeba e le ea mofuta `T`, kapa `None` haeba ho se joalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // TSHIRELETSO: re shebile feela hore na re supa mofuta o nepahetseng, mme re ka itshetleha ka ona
            // ho hlahloba polokeho ea memori hobane re kentse Eng kapa eng bakeng sa mefuta eohle;ha ho li-impls tse ling tse ka bang teng joalo ka ha li ka loantšana le rona.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// E khutlisetsa litšupiso tse ling tse ka feto-fetohang ho boleng ba mabokose haeba e le tsa mofuta `T`, kapa `None` haeba ho se joalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // TSHIRELETSO: re shebile feela hore na re supa mofuta o nepahetseng, mme re ka itshetleha ka ona
            // ho hlahloba polokeho ea memori hobane re kentse Eng kapa eng bakeng sa mefuta eohle;ha ho li-impls tse ling tse ka bang teng joalo ka ha li ka loantšana le rona.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Fetisetsa pele ho mokhoa o hlalositsoeng ka mofuta oa `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID le mekhoa ea eona
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` e emela sekhetho se ikhethileng sa lefatše bakeng sa mofuta.
///
/// `TypeId` ka 'ngoe ke ntho e sa bonoeng e sa lumelleng ho hlahlojoa kahare empa e lumella lits'ebetso tsa mantlha tse kang ho kopanya, ho bapisa, ho hatisa le ho bontša.
///
///
/// `TypeId` hajoale e fumaneha feela bakeng sa mefuta eo ho thoeng ke `'static`, empa moeli ona o ka tlosoa ho future.
///
/// Ha `TypeId` e sebelisa `Hash`, `PartialOrd`, le `Ord`, ho bohlokoa ho hlokomela hore li-hashes le odara li tla fapana lipakeng tsa litokollo tsa Rust.
/// Hlokomela ho itšetleha ka tsona kahare ho khoutu ea hau!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// E khutlisa `TypeId` ea mofuta ona oa ts'ebetso ena o entsoe ka matla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// E khutlisa lebitso la mofuta joaloka selae sa khoele.
///
/// # Note
///
/// Sena se etselitsoe ts'ebeliso ea ts'oaetso.
/// Litaba le sebopeho sa khoele e khutlisitsoeng ha se boleloe, ntle le hore e be tlhaloso e ntle ea mofuta oo.
/// Mohlala, har'a likhoele tseo `type_name::<Option<String>>()` e ka khutlang ke `"Option<String>"` le `"std::option::Option<std::string::String>"`.
///
///
/// Khoele e khutlisitsoeng ha ea lokela ho nkuoa e le sekhetho se ikhethileng sa mofuta ha mefuta e mengata e kanna ea etsa 'mapa oa lebitso le tšoanang.
/// Ka mokhoa o ts'oanang, ha ho na tiiso ea hore likarolo tsohle tsa mofuta li tla hlaha khoeleng e khutlisitsoeng: mohlala, litlhaloso tsa bophelo bohle ha li kenyelelitsoe.
/// Ntle le moo, tlhahiso e ka fetoha lipakeng tsa mefuta ea moqapi.
///
/// Ts'ebetso ea hajoale e sebelisa meralo ea motheo e ts'oanang le tlhahlobo ea likhakanyo le debuginfo, empa sena ha se netefatsoe.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// E khutlisa lebitso la mofuta oa boleng bo supiloeng ho sengoathoana sa khoele.
/// Sena se ts'oana le `type_name::<T>()`, empa se ka sebelisoa moo mofuta oa phapang e sa fumaneheng habonolo.
///
/// # Note
///
/// Sena se etselitsoe ts'ebeliso ea ts'oaetso.Likahare le sebopeho sa khoele ha se boleloe, ntle le hore e be tlhaloso e ntle ea mofuta oo.
/// Mohlala, `type_name_of_val::<Option<String>>(None)` e ka khutlisa `"Option<String>"` kapa `"std::option::Option<std::string::String>"`, empa eseng `"foobar"`.
///
/// Ntle le moo, tlhahiso e ka fetoha lipakeng tsa mefuta ea moqapi.
///
/// Mosebetsi ona ha o rarolle lintho tsa trait, ho bolelang hore `type_name_of_val(&7u32 as &dyn Debug)` e kanna ea khutlisa `"dyn Debug"`, empa eseng `"u32"`.
///
/// Lebitso la mofuta ha lea lokela ho nkuoa e le sekhetho se ikhethileng sa mofuta;
/// mefuta e mengata e ka arolelana lebitso la mofuta o tšoanang.
///
/// Ts'ebetso ea hajoale e sebelisa meralo ea motheo e ts'oanang le tlhahlobo ea likhakanyo le debuginfo, empa sena ha se netefatsoe.
///
/// # Examples
///
/// E hatisa mefuta e sa lekanyetsoang ea linomoro le ho phaphamala.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}