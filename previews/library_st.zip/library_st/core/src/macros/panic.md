Panics khoele ea hajoale.

Sena se lumella lenaneo ho emisa hanghang le ho fana ka maikutlo ho motho ea letsitseng lenaneo.
`panic!` e lokela ho sebelisoa ha lenaneo le fihlella boemo bo ke keng ba fumaneha.

Macro ena ke tsela e phethahetseng ea ho tiisa maemo ka khoutu ea mohlala le litekong.
`panic!` e hokahane haufi le mokhoa oa `unwrap` oa li-enum tsa [`Option`][ounwrap] le [`Result`][runwrap].
Ts'ebetso tsena ka bobeli li letsetsa `panic!` ha li behiloe ho [`None`] kapa [`Err`].

Ha o sebelisa `panic!()` o ka hlakisa mohala o lefshoang ka khoele, o hahiloeng ka ho sebelisa syntax ea [`format!`].
Tefo eo e sebelisoa ha o kenya panic mohaleng oa ho bitsa Rust, o bakang khoele ho panic ka botlalo.

Boitšoaro ba `std` hook ea mantlha, ke hore
khoutu e tsamaeang ka kotloloho kamora hore panic e kenyelletsoe, ke ho hatisa molaetsa o lefelloang ho `stderr` hammoho le tlhaiso-leseling ea file/line/column ea mohala oa `panic!()`.

O ka feta panic hook o sebelisa [`std::panic::set_hook()`].
Ka hare ho hook panic e ka fumaneha joalo ka `&dyn Any + Send`, e nang le `&str` kapa `String` bakeng sa lithapelo tsa `panic!()` tse tloaelehileng.
Ho panic e nang le boleng ba mofuta o mong, [`panic_any`] e ka sebelisoa.

[`Result`] enum hangata ke tharollo e betere ea ho hlaphoheloa liphosong ho fapana le ho sebelisa `panic!` macro.
Macro ena e lokela ho sebelisoa ho qoba ho tsoelapele ho sebelisa litekanyetso tse fosahetseng, joalo ka tse tsoang mehloling e kantle.
Boitsebiso bo qaqileng mabapi le ho sebetsana le liphoso bo fumaneha ho [book].

Bona hape macro [`compile_error!`], bakeng sa ho phahamisa liphoso nakong ea pokello.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Ts'ebetsong ea hajoale

Haeba khoele ea mantlha panics e tla emisa likhoele tsohle tsa hau ebe e phethela lenaneo la hau ka khoutu `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





