#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // E atoloha ho ea ho `$crate::panic::panic_2015` kapa `$crate::panic::panic_2021` ho latela khatiso ea moletsi.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// E fana ka maikutlo a hore lipolelo tse peli lia lekana (ho sebelisa [`PartialEq`]).
///
/// Ho panic, macro ena e tla hatisa boleng ba lipolelo ka lipontšo tsa bona tsa bothata.
///
///
/// Joalo ka [`assert!`], macro ena e na le foromo ea bobeli, moo molaetsa oa tloaelo oa panic o ka fanoang.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Likoloto tse ka tlase li entsoe ka boomo.
                    // Kantle ho tsona, pokello ea mekotla ea kalimo e qalisoa le pele litekanyetso li bapisoa, ho lebisang ho fokotseheng ho bonahalang.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Likoloto tse ka tlase li entsoe ka boomo.
                    // Kantle ho tsona, pokello ea mekotla ea kalimo e qalisoa le pele litekanyetso li bapisoa, ho lebisang ho fokotseheng ho bonahalang.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// E re lipolelo tse peli ha li lekane (ho sebelisoa [`PartialEq`]).
///
/// Ho panic, macro ena e tla hatisa boleng ba lipolelo ka lipontšo tsa bona tsa bothata.
///
///
/// Joalo ka [`assert!`], macro ena e na le foromo ea bobeli, moo molaetsa oa tloaelo oa panic o ka fanoang.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Likoloto tse ka tlase li entsoe ka boomo.
                    // Kantle ho tsona, pokello ea mekotla ea kalimo e qalisoa le pele litekanyetso li bapisoa, ho lebisang ho fokotseheng ho bonahalang.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Likoloto tse ka tlase li entsoe ka boomo.
                    // Kantle ho tsona, pokello ea mekotla ea kalimo e qalisoa le pele litekanyetso li bapisoa, ho lebisang ho fokotseheng ho bonahalang.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// E netefatsa hore polelo ea boolean ke `true` ka nako ea ho matha.
///
/// Sena se tla kopa macro ea [`panic!`] haeba polelo e fanoeng e ke ke ea lekanyetsoa ho `true` ka nako ea ho matha.
///
/// Joalo ka [`assert!`], macro ena e boetse e na le mofuta oa bobeli, moo molaetsa oa tloaelo oa panic o ka fanoang.
///
/// # Uses
///
/// Ho fapana le [`assert!`], lipolelo tsa `debug_assert!` li lumelloa feela moahong o sa ntlafatsoang ka boiketsetso.
/// Kaho e ntlafalitsoeng e ke ke ea etsa lipolelo tsa `debug_assert!` ntle le haeba `-C debug-assertions` e fetiselitsoe ho moqapi.
/// Sena se etsa hore `debug_assert!` e sebetse bakeng sa licheke tse turang haholo ho ba teng moahong oa tokollo empa e ka ba thuso nakong ea nts'etsopele.
/// Phello ea ho holisa `debug_assert!` e lula e hlahlojoa ka mofuta.
///
/// Polelo e sa hlahlojoeng e lumella lenaneo maemong a sa tsitsang hore le tsoele pele ho sebetsa, le ka bang le litlamorao tse sa lebelloang empa le sa hlahise ho se sireletsehe ha feela sena se etsahala ka khoutu e bolokehileng.
///
/// Litsenyehelo tsa ts'ebetso ea lipolelo ha li lekane ka kakaretso.
/// Ho fetola [`assert!`] ka `debug_assert!` ho khothatsoa feela kamora ho etsa profiling e phethahetseng, mme ho bohlokoa le ho feta, ke khoutu e bolokehileng feela!
///
/// # Examples
///
/// ```
/// // molaetsa oa panic bakeng sa lipolelo tsena ke boleng bo hlophisitsoeng ba polelo e fanoeng.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // mosebetsi o bonolo haholo
/// debug_assert!(some_expensive_computation());
///
/// // tiisa ka molaetsa oa tloaelo
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// E re lipolelo tse peli lia lekana.
///
/// Ho panic, macro ena e tla hatisa boleng ba lipolelo ka lipontšo tsa bona tsa bothata.
///
/// Ho fapana le [`assert_eq!`], lipolelo tsa `debug_assert_eq!` li lumelloa feela moahong o sa ntlafatsoang ka boiketsetso.
/// Kaho e ntlafalitsoeng e ke ke ea etsa lipolelo tsa `debug_assert_eq!` ntle le haeba `-C debug-assertions` e fetiselitsoe ho moqapi.
/// Sena se etsa hore `debug_assert_eq!` e sebetse bakeng sa licheke tse turang haholo ho ba teng moahong oa tokollo empa e ka ba thuso nakong ea nts'etsopele.
///
/// Phello ea ho holisa `debug_assert_eq!` e lula e hlahlojoa ka mofuta.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// E re lipolelo tse peli ha li lekane.
///
/// Ho panic, macro ena e tla hatisa boleng ba lipolelo ka lipontšo tsa bona tsa bothata.
///
/// Ho fapana le [`assert_ne!`], lipolelo tsa `debug_assert_ne!` li lumelloa feela moahong o sa ntlafatsoang ka boiketsetso.
/// Kaho e ntlafalitsoeng e ke ke ea etsa lipolelo tsa `debug_assert_ne!` ntle le haeba `-C debug-assertions` e fetiselitsoe ho moqapi.
/// Sena se etsa hore `debug_assert_ne!` e sebetse bakeng sa licheke tse turang haholo ho ba teng moahong oa tokollo empa e ka ba thuso nakong ea nts'etsopele.
///
/// Phello ea ho holisa `debug_assert_ne!` e lula e hlahlojoa ka mofuta.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// E khutlisa hore na polelo e fanoeng e tsamaisana le efe kapa efe ea lipaterone tse fanoeng.
///
/// Joalo ka polelo ea `match`, paterone e ka lateloa ka boikhethelo ke `if` le polelo ea balebeli e nang le phihlello ea mabitso a tlamiloeng ke paterone.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// E notlolla sephetho kapa e jala phoso ea eona.
///
/// Motsamaisi oa `?` o kentsoe ho nka sebaka sa `try!` mme o lokela ho sebelisoa ho fapana.
/// Ho feta moo, `try` ke lentsoe le boloketsoeng ho Rust 2018, kahoo haeba u tlameha ho e sebelisa, u tla hloka ho sebelisa [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` e ts'oana le [`Result`] e fanoeng.Haeba ho na le phapang ea `Ok`, polelo e na le boleng ba boleng bo phuthetsoeng.
///
/// Tabeng ea phapang ea `Err`, e fumana phoso e kahare.`try!` e ntan'o fetolela e sebelisa `From`.
/// Sena se fana ka phetoho ka boiketsetso lipakeng tsa liphoso tse ikhethang le tse ling tse akaretsang.
/// Phoso e hlahisoang e khutlisoa hanghang.
///
/// Ka lebaka la ho khutla kapele, `try!` e ka sebelisoa feela mesebetsing e khutlisetsang [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Mokhoa o khethiloeng oa ho khutlisa liphoso kapele
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Mokhoa o fetileng oa ho khutlisa liphoso kapele
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Sena se lekana le:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// E ngola lintlha tse hlophisitsoeng mochini oa buffer.
///
/// Macro ena e amohela 'writer', mohala oa fomate, le lenane la likhang.
/// Likhang li tla hlophisoa ho latela mohala o boletsoeng mme sephetho se tla fetisetsoa ho mongoli.
/// Sengoli e kanna ea ba boleng bofe kapa bofe ka mokhoa oa `write_fmt`;ka kakaretso sena se tsoa ts'ebetsong ea [`fmt::Write`] kapa [`io::Write`] trait.
/// Macro e khutlisa eng kapa eng eo mokhoa oa `write_fmt` o khutlang ka eona;hangata ke [`fmt::Result`], kapa [`io::Result`].
///
/// Bona [`std::fmt`] bakeng sa tlhaiso-leseling e batsi ka fomate ea mohala oa fomati.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Mojule o ka kenya `std::fmt::Write` le `std::io::Write` ka bobeli ebe o letsetsa `write!` linthong tse sebelisang le eona, kaha lintho ha li sebelise ka bobeli.
///
/// Leha ho le joalo, module e tlameha ho kenya traits e tšoanelehang hore mabitso a bona a se ke a thulana:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // e sebelisa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // e sebelisa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Macro ena e ka sebelisoa le ho li-setup tsa `no_std` hape.
/// Ka setupong sa `no_std` u na le boikarabello ba lintlha tsa ho kenya tšebetsong likarolo.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ngola data e hlophisitsoeng ka har'a buffer, ka newline e kentsoe.
///
/// Lipulong tsohle, mohala o mocha ke LINE FEED character (`\n`/`U+000A`) feela (ha ho na CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Bakeng sa tlhaiso-leseling e batsi, sheba [`write!`].Bakeng sa tlhaiso-leseling ka fomete ea mohala oa fomati, bona [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Mojule o ka kenya `std::fmt::Write` le `std::io::Write` ka bobeli ebe o letsetsa `write!` linthong tse sebelisang le eona, kaha lintho ha li sebelise ka bobeli.
/// Leha ho le joalo, module e tlameha ho kenya traits e tšoanelehang hore mabitso a bona a se ke a thulana:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // e sebelisa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // e sebelisa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// E bonts'a khoutu e sa fihlelleheng.
///
/// Sena se na le thuso nako efe kapa efe eo moqapi a ke keng a fumana hore khoutu e 'ngoe ha e fumanehe.Ka mohlala:
///
/// * Bapisa matsoho le maemo a ho lebela.
/// * Likoti tse emisang ka matla.
/// * Li-Iterator tse emisang ka matla.
///
/// Haeba boikemisetso ba hore khoutu ha e fumanehe bo pakahala bo fosahetse, lenaneo le emisa hanghang ka [`panic!`].
///
/// Molekane ea sa sireletsehang oa macro ena ke ts'ebetso ea [`unreachable_unchecked`], e tla baka boits'oaro bo sa hlalosoang haeba khoutu e ka fihlelleha.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Sena se tla lula se le [`panic!`].
///
/// # Examples
///
/// Bapisa matsoho:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ngola phoso ha ho hlahisitsoe maikutlo
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // e 'ngoe ea ts'ebetsong e futsanehileng ka ho fetisisa ea x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// E bonts'a khoutu e sa phethahatsoang ka ho ts'oha molaetsa oa "not implemented".
///
/// Sena se lumella khoutu ea hau hore e thaepe, e leng molemo haeba o etsa prototyping kapa o kenya ts'ebetsong trait e hlokang mekhoa e mengata eo o sa rerang ho e sebelisa kaofela.
///
/// Phapang lipakeng tsa `unimplemented!` le [`todo!`] ke hore ha `todo!` e fana ka sepheo sa ho kenya tšebetsong ts'ebetso hamorao mme molaetsa ke "not yet implemented", `unimplemented!` ha e etse lipolelo tse joalo.
/// Molaetsa oa eona ke "not implemented".
/// Hape li-IDE tse ling li tla tšoaea `todo!` S.
///
/// # Panics
///
/// Sena se tla lula se le [`panic!`] hobane `unimplemented!` ke khutsufatso feela ea `panic!` ka molaetsa o tsitsitseng, o tobileng.
///
/// Joalo ka `panic!`, macro ena e na le foromo ea bobeli ea ho bonts'a litekanyetso tsa moetlo.
///
/// # Examples
///
/// E re re na le trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Re batla ho kenya ts'ebetsong `Foo` bakeng sa 'MyStruct', empa ka lebaka le itseng hoa utloahala ho kenya ts'ebetsong ts'ebetso ea `bar()`.
/// `baz()` mme `qux()` e ntse e tla hloka ho hlalosoa ts'ebetsong ea rona ea `Foo`, empa re ka sebelisa `unimplemented!` litlhalosong tsa bona ho lumella khoutu ea rona ho ikopanya.
///
/// Re ntse re batla hore lenaneo la rona le emise ho sebetsa haeba mekhoa e sa sebetsoang e ka fihlelleha.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ha ho utloahale ho `baz` a `MyStruct`, ka hona ha re na monahano ho hang.
/////
///         // Sena se tla bontša "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Re na le monahano o mong mona, Re ka eketsa molaetsa ho o sa phethahaleng!ho bontša ho se lumellane ha rona.
///         // Sena se tla bontša: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// E bontša khoutu e sa phethoang.
///
/// Sena se ka ba molemo haeba o etsa prototyping mme o ntse o batla ho ba le khoutu ea hau ea typecheck.
///
/// Phapang lipakeng tsa [`unimplemented!`] le `todo!` ke hore ha `todo!` e fana ka sepheo sa ho kenya tšebetsong ts'ebetso hamorao mme molaetsa ke "not yet implemented", `unimplemented!` ha e etse lipolelo tse joalo.
/// Molaetsa oa eona ke "not implemented".
/// Hape li-IDE tse ling li tla tšoaea `todo!` S.
///
/// # Panics
///
/// Sena se tla lula se le [`panic!`].
///
/// # Examples
///
/// Mona ke mohlala oa khoutu e 'ngoe e ntseng e tsoela pele.Re na le trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Re batla ho kenya tšebetsong `Foo` ho e 'ngoe ea mefuta ea rona, empa hape re batla ho sebetsa ka `bar()` pele.Bakeng sa hore khoutu ea rona e bokelle, re hloka ho kenya ts'ebetsong `baz()`, ka hona re ka sebelisa `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ts'ebetsong e ea mona
///     }
///
///     fn baz(&self) {
///         // ha re ts'oenyeheng ka ho kenya ts'ebetsong baz() hajoale
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ha re sebelise baz(), kahoo ho lokile.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Litlhaloso tsa li-macros tse hahelletsoeng.
///
/// Boholo ba thepa ea macro (botsitso, ponahalo, jj.) E nkuoa khoutu ea mohloli mona, ntle le mesebetsi ea katoloso e fetolang lisebelisoa tsa macro hore e be lihlahisoa, mesebetsi eo e fanoa ke moqapi.
///
///
pub(crate) mod builtin {

    /// E baka pokello ho hloleha ka molaetsa oa phoso o fuoeng ha o kopane.
    ///
    /// Macro ena e lokela ho sebelisoa ha crate e sebelisa leano la ho bokella maemo ho fana ka melaetsa e metle ea liphoso bakeng sa maemo a fosahetseng.
    ///
    /// Ke mofuta oa sebapali sa [`panic!`], empa o hlahisa phoso nakong ea *pokello* ho fapana le ka *nako ea ho sebetsa*.
    ///
    /// # Examples
    ///
    /// Mehlala e 'meli e joalo ke libaka tsa macros le `#[cfg]`.
    ///
    /// Emit phoso ea ho bokella hamolemo haeba macro e fetisitsoe ka litekanyetso tse sa sebetseng.
    /// Ntle le branch ea ho qetela, motlatsi o ne a ntse a tla hlahisa phoso, empa molaetsa oa phoso o ne o ke ke oa bua ka litekanyetso tse peli tse nepahetseng.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit phoso ea ho bokella haeba e 'ngoe ea likarolo ha e fumanehe.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E theha mekhahlelo ea li-macros tse ling tsa ho fomata ka mohala.
    ///
    /// Ts'ebetso ena e kholo ka ho nka mohala o fomate o nang le `{}` bakeng sa ngangisano e ngoe le e ngoe e fetisitsoeng.
    /// `format_args!` e hlophisa mekhahlelo e meng ho netefatsa hore sehlahisoa se ka hlalosoa e le khoele 'me sa hlakola likhang ka mofuta o le mong.
    /// Boleng bofe kapa bofe bo sebelisang [`Display`] trait bo ka fetisetsoa ho `format_args!`, joalo ka ha ts'ebetsong efe kapa efe ea [`Debug`] e ka fetisetsoa ho `{:?}` ka har'a mohala oa ho fomata.
    ///
    ///
    /// Macro ena e hlahisa boleng ba mofuta oa [`fmt::Arguments`].Boleng bona bo ka fetisetsoa ho li-macro kahare ho [`std::fmt`] bakeng sa ho etsa phallo e sebetsang.
    /// Li-macro tse ling tsohle tsa ho fomata ([`format!`], [`write!`], [`println!`], jj) li hlahisoa ka mokhoa ona.
    /// `format_args!`, ho fapana le li-macros tsa eona, e qoba likabelo tsa qubu.
    ///
    /// U ka sebelisa boleng ba [`fmt::Arguments`] boo `format_args!` e bo khutlisetsang ho `Debug` le `Display` maemong a bonoang ka tlase.
    /// Mohlala o boetse o bonts'a mofuta oa `Debug` le `Display` nthong e ts'oanang: khoele ea fomate e kopantsoeng ho `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Bakeng sa tlhaiso-leseling e batsi, bona litokomane ho [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// E ts'oana le `format_args`, empa e eketsa newline qetellong.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// E hlahloba phapang ea tikoloho ka nako ea ho bokella.
    ///
    /// Macro ena e tla hola ho fihlela boleng ba moelelo o fapaneng oa tikoloho ka nako ea ho bokella, e hlahise mofuta oa `&'static str`.
    ///
    ///
    /// Haeba phapang ea tikoloho e sa hlalosoe, joale phoso ea pokello e tla ntšoa.
    /// Ho se ntše phoso ea pokello, sebelisa [`option_env!`] macro ho fapana.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// O ka etsa molaetsa oa phoso ka ho fetisa khoele e le paramethara ea bobeli:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Haeba phapang ea tikoloho ea `documentation` e sa hlalosoe, o tla fumana phoso e latelang:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ka boikhethelo e hlahloba phapang ea tikoloho ka nako ea ho bokella.
    ///
    /// Haeba phapano e boletsoeng ka tikoloho e le teng ka nako ea ho bokella, sena se tla hola ho ba polelo ea mofuta `Option<&'static str>` eo boleng ba eona e leng `Some` ea boleng ba phapano ea tikoloho.
    /// Haeba maemo a sa fetoheng a tikoloho a le sieo, sena se tla hola ho fihlela ho `None`.
    /// Bona [`Option<T>`][Option] bakeng sa tlhaiso-leseling e batsi ka mofuta ona.
    ///
    /// Phoso ea nako ea ho bokella ha e hlahisoe ha ho sebelisoa macro ena ho sa tsotelehe hore na maemo a tikoloho a teng kapa che.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E kopanya lits'oants'o ho khetholla e le 'ngoe.
    ///
    /// Sena se nka palo e fe kapa e fe ea likhechana tse arohaneng ka comma, 'me e li kopanya kaofela hore e be ntho e le ngoe, e hlahisa polelo e khethollang e ncha.
    /// Hlokomela hore bohloeki bo etsa hore mofuta ona o moholo o se ke oa hapa mefuta ea lehae.
    /// Hape, joalo ka molao o akaretsang, li-macro li lumelloa feela nthong, polelo kapa boemo ba polelo.
    /// Seo se bolela hore ha o ntse o ka sebelisa macro ena ho bua ka mefuta e teng, mesebetsi kapa li-module jj, o ka se hlalose e ncha le eona.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (e ncha, e monate, lebitso) { }//ha e sebelisoe ka tsela ena!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E kopanya lingoliloeng ka sengoathoana sa thapo e sa fetoheng.
    ///
    /// Macro ena e nka palo efe kapa efe ea lingoliloeng tse arohaneng ka comma, e hlahisang polelo ea mofuta `&'static str` e emelang lingoliloeng tsohle tse kopantsoeng ho tloha letsohong le letona ho ea ho le letona.
    ///
    ///
    /// Lingoliloeng tse kholo le tse phaphametseng li hokahantsoe molemong oa ho ts'oaroa.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E atoloha ho nomoro ea mohala eo e neng e sebelisitsoe ho eona.
    ///
    /// Ka [`column!`] le [`file!`], li-macro tsena li fana ka tlhaiso-leseling e ntlafatsang bakeng sa bahlahisi mabapi le sebaka se ka har'a mohloli.
    ///
    /// Polelo e atolositsoeng e na le mofuta oa `u32` mme e thehiloe ho 1, ka hona, mohala oa pele ho file ka 'ngoe o lekola ho 1, ea bobeli ho ea ho 2, jj.
    /// Sena se lumellana le melaetsa ea liphoso ke li-compiler tse tloaelehileng kapa bahlophisi ba tummeng.
    /// Mohala o khutlisitsoeng ha se hakaalo * mohala oa boipiletso ba `line!` ka boyona, empa ke kopo ea pele e kholo e lebisang kopong ea `line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// E atoloha ho nomoro ea kholomo eo e neng e sebelisitsoe ho eona.
    ///
    /// Ka [`line!`] le [`file!`], li-macro tsena li fana ka tlhaiso-leseling e ntlafatsang bakeng sa bahlahisi mabapi le sebaka se ka har'a mohloli.
    ///
    /// Polelo e atolositsoeng e na le mofuta oa `u32` mme e thehiloe ho 1, ka hona kholomo ea pele moleng ka mong e lekola ho 1, ea bobeli ho ea ho 2, jj.
    /// Sena se lumellana le melaetsa ea liphoso ke li-compiler tse tloaelehileng kapa bahlophisi ba tummeng.
    /// Kholomo e khutlisitsoeng ha se hakaalo moeli oa boipiletso ba `column!` ka boyona, empa ke kopo ea pele e kholo e lebisang kopong ea `column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// E atolohela lebitsong la faele leo e neng e le teng ho lona.
    ///
    /// Ka [`line!`] le [`column!`], li-macro tsena li fana ka tlhaiso-leseling e ntlafatsang bakeng sa bahlahisi mabapi le sebaka se ka har'a mohloli.
    ///
    /// Polelo e atolositsoeng e na le mofuta oa `&'static str`, mme faele e khutlisitsoeng ha se thapelo ea `file!` macro ka boeona, empa ke kopo ea pele e kholo e lebisang kopong ea `file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// E tiisa mabaka a eona.
    ///
    /// Macro ena e tla fana ka polelo ea mofuta oa `&'static str` e leng tlhatlhobo ea tokens tsohle tse fetisitsoeng ho macro.
    /// Ha ho lithibelo tse behiloeng ho syntax ea kopo e kholo ka boyona.
    ///
    /// Hlokomela hore liphetho tse atolositsoeng tsa kenyelletso tokens li kanna tsa fetoha ho future.U lokela ho ba hlokolosi haeba u itšetleha ka tlhahiso.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// E kenyelletsa faele e kentsoeng ka UTF-8 joalo ka khoele.
    ///
    /// Faele e fumaneha haufi le file ea hajoale (ka mokhoa o ts'oanang le li-module tse fumanoang).
    /// Tsela e fanoeng e hlalosoa ka tsela e ikhethileng sethaleng ka nako ea ho bokella.
    /// Mohlala, thapeli e nang le tsela ea Windows e nang le backslashes `\` e ka se kopane hantle ho Unix.
    ///
    ///
    /// Macro ena e tla fana ka polelo ea mofuta `&'static str` e leng litaba tsa faele.
    ///
    /// # Examples
    ///
    /// Nahana hore ho na le lifaele tse peli kahare e le 'ngoe e nang le litaba tse latelang:
    ///
    /// Faele 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faele 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Ho hlophisa 'main.rs' le ho tsamaisa binary e hlahisoang ho tla hatisa "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E kenyelletsa faele joalo ka ha ho buuoa ka mofuta oa li-byte.
    ///
    /// Faele e fumaneha haufi le file ea hajoale (ka mokhoa o ts'oanang le li-module tse fumanoang).
    /// Tsela e fanoeng e hlalosoa ka tsela e ikhethileng sethaleng ka nako ea ho bokella.
    /// Mohlala, thapeli e nang le tsela ea Windows e nang le backslashes `\` e ka se kopane hantle ho Unix.
    ///
    ///
    /// Macro ena e tla fana ka polelo ea mofuta `&'static [u8; N]` e leng litaba tsa faele.
    ///
    /// # Examples
    ///
    /// Nahana hore ho na le lifaele tse peli kahare e le 'ngoe e nang le litaba tse latelang:
    ///
    /// Faele 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faele 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Ho hlophisa 'main.rs' le ho tsamaisa binary e hlahisoang ho tla hatisa "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E atoloha ho ea khoele e emelang tsela ea hajoale ea module.
    ///
    /// Tsela ea hajoale ea module e ka nkuoa e le bolaoli ba li-module tse lebisang morao ho crate root.
    /// Karolo ea pele ea tsela e khutlisitsoeng ke lebitso la crate e ntseng e hlophisoa hajoale.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// E lekola likarolo tsa boolean tsa lifolakha tsa phetolo ka nako ea ho bokella.
    ///
    /// Ntle le semelo sa `#[cfg]`, macro ena e fanoe ho lumella boolean expression expression ho lekola lifolakha tsa tlhophiso.
    /// Hangata hona ho lebisa khoutu e sa kopitsoang haholo.
    ///
    /// Syntax e fuoeng macro ena ke syntax e tšoanang le semelo sa [`cfg`].
    ///
    /// `cfg!`, ho fapana le `#[cfg]`, ha e tlose khoutu efe kapa efe mme e lekola feela hore ke 'nete kapa bohata.
    /// Mohlala, lithibelo tsohle tsa polelo ea if/else li hloka ho sebetsa ha `cfg!` e sebelisetsoa boemo, ho sa natsoe hore na `cfg!` e lekola eng.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// E nyatsa faele e le polelo kapa ntho ho latela moelelo oa taba.
    ///
    /// Faele e fumaneha haufi le file ea hajoale (ka mokhoa o ts'oanang le li-module tse fumanoang).Tsela e fanoeng e hlalosoa ka tsela e ikhethileng sethaleng ka nako ea ho bokella.
    /// Mohlala, thapeli e nang le tsela ea Windows e nang le backslashes `\` e ka se kopane hantle ho Unix.
    ///
    /// Ho sebelisa macro hangata ke mohopolo o mobe, hobane haeba faele e hlalositsoe e le polelo, e tla beoa ka khoutu e e potileng ntle le bohloeki.
    /// Sena se ka etsa hore mefuta-futa kapa mesebetsi e fapane le seo file e neng e se lebelletse haeba ho na le mefuta kapa mesebetsi e nang le lebitso le tšoanang faeleng ea hajoale.
    ///
    ///
    /// # Examples
    ///
    /// Nahana hore ho na le lifaele tse peli kahare e le 'ngoe e nang le litaba tse latelang:
    ///
    /// Faele 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Faele 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Ho hlophisa 'main.rs' le ho tsamaisa binary e hlahisoang ho tla hatisa "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// E netefatsa hore polelo ea boolean ke `true` ka nako ea ho matha.
    ///
    /// Sena se tla kopa macro ea [`panic!`] haeba polelo e fanoeng e ke ke ea lekanyetsoa ho `true` ka nako ea ho matha.
    ///
    /// # Uses
    ///
    /// Litlamo li lula li hlahlojoa ka bobeli ho lokisa le ho lokolla li aha, 'me ha li khone ho holofala.
    /// Bona [`debug_assert!`] bakeng sa lipolelo tse sa lumelloeng ho lokolloang li aha ka boiketsetso.
    ///
    /// Khoutu e sa bolokehang e kanna ea itšetleha ka `assert!` ho tiisa ts'ebeliso ea nako ea ho sebetsa eo haeba e ka tloloa e ka lebisang ts'ireletsehong.
    ///
    /// Linyeoe tse ling tsa ts'ebeliso ea `assert!` li kenyelletsa ho leka le ho qobella bahlaseli ba nako ea ho matha ka khoutu e bolokehileng (eo tlolo ea eona e ke keng ea baka ts'ireletseho).
    ///
    ///
    /// # Melaetsa ea Tloaelo
    ///
    /// Macro ena e na le foromo ea bobeli, moo molaetsa oa tloaelo oa panic o ka fuoang kapa o se na mabaka a ho o etsa.
    /// Bona [`std::fmt`] bakeng sa syntax ea foromo ena.
    /// Lipolelo tse sebelisoang e le likhang tsa sebopeho li tla hlahlojoa feela haeba polelo e hloleha.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // molaetsa oa panic bakeng sa lipolelo tsena ke boleng bo hlophisitsoeng ba polelo e fanoeng.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // mosebetsi o bonolo haholo
    ///
    /// assert!(some_computation());
    ///
    /// // tiisa ka molaetsa oa tloaelo
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Kopano e ka hare.
    ///
    /// Bala [unstable book] bakeng sa ts'ebeliso.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Kopano ea inline ea setaele sa LLVM.
    ///
    /// Bala [unstable book] bakeng sa ts'ebeliso.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Kopano ea inline-level inline.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Likhatiso li fetisitse tokens hore e be tlhahiso e tloaelehileng.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// E nolofalletsa kapa e thibela ts'ebetso ea ts'ebetso e sebelisetsoang ho lokisa li-macro tse ling.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Fana ka li-macro tse ngata tse sebelisitsoeng ho sebelisa macro ea derive.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Fana ka boholo bo sebelisoang tšebetsong ho e fetola tlhahlobo ea yuniti.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Fana ka boholo bo sebelisoang tšebetsong ho e fetola tlhahlobo ea tlhahlobo.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Tlhaloso ea ts'ebetso ea li-macros tsa `#[test]` le `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Fana ka bongata bo boholo bo sebelisoang ho static ho e ngolisa e le kabo ea lefatše.
    ///
    /// Bona hape [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// E boloka ntho eo e sebelisitsoeng ho eona haeba tsela e fetisitsoeng e fumaneha, ebe ee tlosa ka tsela e ngoe.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// E holisa litšobotsi tsohle tsa `#[cfg]` le `#[cfg_attr]` sekhechaneng sa khoutu eo e sebelisitsoeng ho eona.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Lintlha tse sa tsitsang tsa ts'ebetso ea `rustc` compiler, se sebelise.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Lintlha tse sa tsitsang tsa ts'ebetso ea `rustc` compiler, se sebelise.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}