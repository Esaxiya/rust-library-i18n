use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Sekoahelo se thibelang moqapi hore a se ke a letsetsa mosenyi oa ``T`.
/// Sekoahelo sena ke theko ea 0.
///
/// `ManuallyDrop<T>` e tlas'a maemo a tšoanang le a `T`.
/// Ka lebaka leo, ha e na *phello* likhopolong tseo moqapi a li etsang ka litaba tsa eona.
/// Mohlala, ho qala `ManuallyDrop<&mut T>` ka [`mem::zeroed`] ke boits'oaro bo sa hlalosoang.
/// Haeba o hloka ho sebetsana le data e sa ngolisoang, sebelisa [`MaybeUninit<T>`] ho fapana.
///
/// Hlokomela hore ho fihlella boleng kahare ho `ManuallyDrop<T>` ho bolokehile.
/// Sena se bolela hore `ManuallyDrop<T>` eo litaba tsa eona li lahletsoeng ha lia lokela ho pepesoa ka API e bolokehileng ea sechaba.
/// Ka mokhoa o ts'oanang, `ManuallyDrop::drop` ha e bolokehe.
///
/// # `ManuallyDrop` le tlohele odara.
///
/// Rust e na le [drop order] ea boleng bo hlalositsoeng hantle.
/// Ho etsa bonnete ba hore masimo kapa batho ba moo ba lahleloa ka tatellano e itseng, hlophisa bocha liphatlalatso hore taelo e hlakileng ea lerotholi e nepahale.
///
/// Hoa khoneha ho sebelisa `ManuallyDrop` ho laola taelo, empa sena se hloka khoutu e sa bolokehang 'me ho thata ho e etsa ka nepo ha u bula.
///
///
/// Ka mohlala, haeba u batla ho etsa bonnete ba hore tšimo e itseng e oeloa ka mor'a tse ling, etsa hore e be tšimo ea ho qetela ea struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` e tla akheloa kamora `children`.
///     // Rust e tiisa hore masimo a liheloa ka tatellano ea phatlalatso.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Phuthela boleng hore bo tloheloe ka letsoho.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // O ntse o ka sebetsa ka boleng bo sireletsehileng
    /// assert_eq!(*x, "Hello");
    /// // Empa `Drop` e ke ke ea tsamaisoa mona
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// E ntša boleng ho setshelo sa `ManuallyDrop`.
    ///
    /// Sena se lumella boleng hore bo theohe hape.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Sena se theola `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// E nka boleng ho tsoa setshelong sa `ManuallyDrop<T>`.
    ///
    /// Mokhoa ona o etselitsoe haholo-holo ho tsamaisa litekanyetso ho theoha.
    /// Sebakeng sa ho sebelisa [`ManuallyDrop::drop`] ho lahla boleng ka letsoho, o ka sebelisa mokhoa ona ho nka boleng le ho o sebelisa ka moo o batlang ka teng.
    ///
    /// Nako le nako ha ho khonahala, ho molemo ho sebelisa [`into_inner`][`ManuallyDrop::into_inner`] ho fapana, e thibelang ho kopitsa likateng tsa `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Mosebetsi ona o hlahisa boleng bo fumanehang ntle le ho thibela ts'ebeliso e ngoe, o siea boemo ba setshelo sena bo sa fetoha.
    /// Ke boikarabello ba hau ho netefatsa hore `ManuallyDrop` ena ha e sebelisoe hape.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // TŠIRELETSO: re ntse re bala ho tsoa ho ts'upiso, e netefalitsoeng
        // ho nepahala bakeng sa ho balwa.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ka boeona e theola boleng bo nang le eona.Sena se tšoana hantle le ho letsetsa [`ptr::drop_in_place`] ka sesupa sa boleng bo teng.
    /// Kahoo, ntle le hore boleng bo nang le thepa bo hlophisehe, mosenyi o tla bitsoa sebakeng ntle le ho tsamaisa boleng, ka hona a ka sebelisoa ho theola data ea [pinned] ka polokeho.
    ///
    /// Haeba u na le boleng ba boleng, u ka sebelisa [`ManuallyDrop::into_inner`] ho fapana.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona o tsamaisa mosenyi oa boleng bo fumanehang.
    /// Ntle le liphetoho tse entsoeng ke mosenyi ka boeena, memori e sala e sa fetohe, 'me ho fihlela moo mokhatelli a amehang o ntse a tšoere mofuta o nepahetseng oa mofuta oa `T`.
    ///
    ///
    /// Leha ho le joalo, boleng bona ba "zombie" ha boa lokela ho pepesetsoa khoutu e bolokehileng, mme ts'ebetso ena ha ea lokela ho bitsoa makhetlo a fetang a le mong.
    /// Ho sebelisa boleng kamora hore e oeloe, kapa ho theola boleng makhetlo a mangata, ho ka baka boits'oaro bo sa hlalosoang (ho latela seo `drop` e se etsang).
    /// Hangata hona ho thibeloa ke mofuta oa sistimi, empa basebelisi ba `ManuallyDrop` ba tlameha ho boloka litšepiso tseo ntle le thuso ho moqapi.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // TŠIRELETSO: re lahla boleng bo supiloeng ke ts'upiso e ka fetohang
        // e netefalitsoeng hore e nepahetse bakeng sa ho ngola.
        // Ho ho motho ea letsitseng ho netefatsa hore `slot` ha e oe hape.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}