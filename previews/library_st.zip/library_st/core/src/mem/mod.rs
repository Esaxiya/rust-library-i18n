//! Mesebetsi ea mantlha ea ho sebetsana le memori.
//!
//! Mojule ona o na le mesebetsi ea ho botsa boholo le tatellano ea mefuta, ho qala le ho tsamaisa memori.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// E nka beng le "forgets" mabapi le boleng ** ntle le ho e senya.
///
/// Lisebelisoa leha e le life tseo boleng bo li laolang, joalo ka mohopolo oa qubu kapa sesebelisoa sa faele, li tla lula ka ho sa feleng maemong a sa fihlelleheng.Leha ho le joalo, ha e fane ka tiiso ea hore litsupa tsa mohopolo ona li tla lula li sebetsa.
///
/// * Haeba u batla ho lutla mohopolo, bona [`Box::leak`].
/// * Haeba u batla ho fumana sesupa-pono se tala se hopolang lintho, bona [`Box::into_raw`].
/// * Haeba u batla ho lahla boleng ka nepo, ho e senya, bona [`mem::drop`].
///
/// # Safety
///
/// `forget` ha e tšoauoe e le `unsafe`, hobane ts'ireletso ea Rust ha e kenyeletse tiiso ea hore basenyi ba tla lula ba matha.
/// Mohlala, lenaneo le ka theha potoloho ea litšupiso le sebelisa [`Rc`][rc], kapa la letsetsa [`process::exit`][exit] ho tsoa ntle le ho senya.
/// Kahoo, ho lumella `mem::forget` ho tsoa khoutu e bolokehileng ha ho fetole lits'oants'o tsa polokeho ea Rust.
///
/// Ho boletse joalo, ho lutlisa lisebelisoa tse joalo ka mohopolo kapa lintho tsa I/O hangata ha ho ratehe.
/// Tlhoko e hlaha maemong a mang a khethehileng a ts'ebeliso ea FFI kapa khoutu e sa bolokehang, empa leha ho le joalo, [`ManuallyDrop`] e tloaetse ho khethoa.
///
/// Hobane ho lebala boleng ho lumelloa, khoutu efe kapa efe ea `unsafe` eo o e ngolang e tlameha ho lumella monyetla ona.O ka se khutlise boleng mme o lebelle hore motho ea letsitseng o tla tsamaisa mosenyi oa boleng.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ts'ebeliso e bolokehileng ea `mem::forget` e netefalitsoeng ke ho qoba tšenyo ea boleng e kenngoeng ke `Drop` trait.Mohlala, sena se tla lutla `File`, ke hore
/// khutlisa sebaka se nkuoeng ke se feto-fetohang empa o se ke oa koala sesebelisoa sa motheo:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Sena se na le thuso ha thepa ea mantlha e ne e fetisetsoa khoutu kantle ho Rust, mohlala ka ho fetisetsa sekhechisi sa faele se tala ho khoutu ea C.
///
/// # Kamano le `ManuallyDrop`
///
/// Le ha `mem::forget` e ka sebelisoa ho fetisetsa mong'a *memori*, ho etsa joalo ho na le phoso.
/// [`ManuallyDrop`] e lokela ho sebelisoa ho fapana.Nahana, ka mohlala, khoutu ena:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Theha `String` u sebelisa litaba tsa `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // dutla `v` hobane memori ea eona e se e laoloa ke `s`
/// mem::forget(v);  // PHOSO, v ha e sebetse 'me ha ea lokela ho fetisetsoa mosebetsing
/// assert_eq!(s, "Az");
/// // `s` e lahliloe ka botlalo mme mohopolo oa eona oa fallisoa.
/// ```
///
/// Ho na le litaba tse peli ka mohlala o kaholimo:
///
/// * Haeba khoutu e eketsehileng e ka eketsoa lipakeng tsa kaho ea `String` le ho kopa `mem::forget()`, panic kahare ho eona e ka baka mahala ea mahala hobane mohopolo o ts'oanang o sebetsoa ke `v` le `s`.
/// * Kamora ho letsetsa `v.as_mut_ptr()` le ho fetisetsa boitsebiso ho `s`, boleng ba `v` ha bo sebetse.
/// Le ha boleng bo fetiselitsoe feela ho `mem::forget` (e ke keng ea e hlahloba), mefuta e meng e na le litlhokahalo tse thata ho litekanyetso tsa tsona tse li etsang hore li se sebetse ha li leketlile kapa ha li sa na thepa.
/// Ho sebelisa makgabane a sa sebetseng ka tsela efe kapa efe, ho kenyelletsa ho a fetisetsa ho ona kapa ho a kgutlisa mesebetsing, ho etsa boits'oaro bo sa hlalosehang mme ho ka senya likhopolo tse entsoeng ke moqapi.
///
/// Ho fetohela ho `ManuallyDrop` ho qoba litaba tsena ka bobeli:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Pele re qhaqholla `v` likarolong tsa eona tse tala, etsa bonnete ba hore ha e oe!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Hona joale qhaqholla `v`.Ts'ebetso ena e ke ke ea panic, ka hona ho ka se be le ho dutla.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Qetellong, theha `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` e lahliloe ka botlalo mme mohopolo oa eona oa fallisoa.
/// ```
///
/// `ManuallyDrop` robustly thibela mahala habeli hobane re holofatsa `v` mosenyi pele re etsa ntho efe kapa efe.
/// `mem::forget()` ha e lumelle sena hobane e sebelisa khang ea eona, e re qobella ho e letsetsa feela kamora ho ntša eng kapa eng eo re e hlokang ho `v`.
/// Le ha panic e ne e ka hlahisoa lipakeng tsa kaho ea `ManuallyDrop` le ho aha khoele (e ke keng ea etsahala ka khoutu e bontšitsoeng), e ka fella ka ho dutla eseng mahala habeli.
/// Ka mantsoe a mang, `ManuallyDrop` e etsa liphoso ka lehlakoreng la ho lutla ho fapana le ho fosahala ka lehlakoreng la (Double-).
///
/// Hape, `ManuallyDrop` e re thibela ho ba le "touch" `v` kamora ho fetisetsa beng ho `s`-mohato oa hoqetela oa ho sebelisana le `v` ho e lahla ntle le ho e senya e qojoa ka botlalo.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Joalo ka [`forget`], empa hape e amohela litekanyetso tse sa lekanyetsoang.
///
/// Mosebetsi ona ke shim feela e reretsoeng ho tlosoa ha karolo ea `unsized_locals` e tsitsisoa.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// E khutlisa boholo ba mofuta oa li-byte.
///
/// Haholo-holo sena ke setlankane sa li-byte lipakeng tsa likarolo tse latellanang ka tatellano le mofuta oa ntho eo ho kenyeletsoa ho tsamaisoa ha lintho.
///
/// Kahoo, bakeng sa mofuta ofe kapa ofe `T` le bolelele `n`, `[T; n]` e na le boholo ba `n * size_of::<T>()`.
///
/// Ka kakaretso, boholo ba mofuta ha boa tsitsa lipokellong tsohle, empa mefuta e ikhethileng e kang ea pele ke.
///
/// Tafole e latelang e fana ka boholo ba li-primitives.
///
/// Tšoaea |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Ho feta moo, `usize` le `isize` li na le boholo bo lekanang.
///
/// Mefuta ea `*const T`, `&T`, `Box<T>`, `Option<&T>`, le `Option<Box<T>>` kaofela li na le boholo bo lekanang.
/// Haeba `T` e Boholo, mefuta eo kaofela e na le boholo bo lekanang le `usize`.
///
/// Ho fetoha ha sesupa ha ho fetole boholo ba sona.Kahoo, `&T` le `&mut T` li na le boholo bo lekanang.
/// Ka mokhoa o ts'oanang bakeng sa `*const T` le `* mut T`.
///
/// # Boholo ba lintho tsa `#[repr(C)]`
///
/// Boemeli ba `C` ba lintho bo na le sebopeho se hlalositsoeng.
/// Ka moralo ona, boholo ba lintho bo boetse bo tsitsitse ha feela masimo ohle a na le boholo bo tsitsitseng.
///
/// ## Boholo ba Structs
///
/// Bakeng sa `structs`, boholo bo khethoa ke algorithm e latelang.
///
/// Bakeng sa lefapha le leng le le leng mohahong o hlophisitsoeng ka taelo ea phatlalatso:
///
/// 1. Kenya boholo ba tšimo.
/// 2. Fetisa boholo ba hajoale ho li-multiple tse haufi tsa [alignment] ea tšimo.
///
/// Kamora nako, potoloha boholo ba sebopeho ho bongata bo haufi ba [alignment].
/// Ho tsamaellana le sebopeho hangata ke ho hokahanya ho hoholo hoa masimo ohle a eona;sena se ka fetoloa ka ts'ebeliso ea `repr(align(N))`.
///
/// Ho fapana le `C`, li-struct tse boholo bo sa lefelloeng ha li bokelloe ho fihlela ho byte e le ngoe ka boholo.
///
/// ## Boholo ba Enum
///
/// Li-enum tse se nang data ntle le khethollo li na le boholo bo lekanang le li-enum tsa C sethaleng tseo ba li hlophiselitsoeng.
///
/// ## Boholo ba Mekhatlo ea basebetsi
///
/// Boholo ba kopano ke boholo ba tšimo ea eona e kholo.
///
/// Ho fapana le `C`, mekhatlo ea basebetsi e boholo bo sa lefelloeng ha e na bophahamo bo lekanang.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Tse ling tsa lintho tsa pele
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Tse ling tse fapaneng
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Tekano ea boholo ba sesupa
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// U sebelisa `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Boholo ba tšimo ea pele ke 1, kahoo eketsa 1 ho boholo.Boholo ke 1.
/// // Tsamaiso ea tšimo ea bobeli ke 2, kahoo eketsa 1 ho boholo ba ho katoa.Boholo ke 2.
/// // Boholo ba tšimo ea bobeli ke 2, kahoo eketsa 2 ho boholo.Boholo ke 4.
/// // Tsamaiso ea tšimo ea boraro ke 1, kahoo eketsa 0 ho boholo ba ho katoa.Boholo ke 4.
/// // Boholo ba tšimo ea boraro ke 1, kahoo eketsa 1 ho boholo.Boholo ke 5.
/// // Kamora nako, tatellano ea sebopeho ke 2 (hobane peakanyo e kholohali har'a masimo a eona ke 2), ka hona eketsa 1 ho boholo ba padding.
/// // Boholo ke 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Li-Tuple structs li latela melao e ts'oanang.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Hlokomela hore ho hlophisa bocha masimo ho ka theola boholo.
/// // Re ka tlosa li-padding byte ka ho beha `third` pele ho `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Boholo ba Union ke boholo ba tšimo e kholo ka ho fetisisa.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// E khutlisa boholo ba boleng bo supiloeng ho li-byte.
///
/// Hangata hona ho tšoana le `size_of::<T>()`.
/// Leha ho le joalo, ha `T` * e se na boholo bo tsejoang ka lipalo, mohlala, selae sa [`[T]`][slice] kapa [trait object], `size_of_val` e ka sebelisoa ho fumana boholo bo tsejoang ka matla.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // TSHIRELETSO: `val` ke setshupiso, ka hona ke sesupi se sebetsang se tala
    unsafe { intrinsics::size_of_val(val) }
}

/// E khutlisa boholo ba boleng bo supiloeng ho li-byte.
///
/// Hangata hona ho tšoana le `size_of::<T>()`.Leha ho le joalo, ha `T` * e se na boholo bo tsejoang ka lipalo, mohlala, selae sa [`[T]`][slice] kapa [trait object], `size_of_val_raw` e ka sebelisoa ho fumana boholo bo tsejoang ka matla.
///
/// # Safety
///
/// Mosebetsi ona o bolokehile feela hore o ka letsetsoa haeba maemo a latelang a le teng:
///
/// - Haeba `T` ke `Sized`, ts'ebetso ena e lula e bolokehile ho e letsetsa.
/// - Haeba mohatla o sa lekanyetsoang oa `T` ke:
///     - [slice], ebe bolelele ba mohatla oa selae e tlameha ho ba palo e qalileng, mme boholo ba *boleng bo felletseng*(bolelele ba mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
///     - [trait object], ebe karolo ea vtable ea pointer e tlameha ho supa vtable e nepahetseng e fumanoeng ka ho qobelloa ho sa lekanyetsoang, mme boholo ba *boleng bo felletseng*(bolelele ba mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
///
///     - (unstable) [extern type], ebe ts'ebetso ena e lula e bolokehile ho e letsetsa, empa e kanna eaba panic kapa e khutlisa boleng bo fosahetseng, joalo ka ha sebopeho sa mofuta oa kantle se sa tsejoe.
///     Ena ke boits'oaro bo ts'oanang le [`size_of_val`] ha ho buuoa ka mofuta o nang le mohatla oa mofuta o kantle.
///     - ho seng joalo, ka mokhoa o bolokehileng ha oa lumelloa ho bitsa ts'ebetso ena.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TSHIRELETSO: moletsi o tlameha ho fana ka sesupi se sa hlahisoang se tala
    unsafe { intrinsics::size_of_val(val) }
}

/// E khutlisa peakanyo e nyane ea mofuta oa [ABI].
///
/// Tlhaloso e ngoe le e ngoe ea boleng ba mofuta oa `T` e tlameha ho ba palo e ngata ea palo ena.
///
/// Ena ke peakanyo e sebelisetsoang likarolo tsa sebopeho.E kanna ea ba nyane ho feta peakanyo e khethiloeng.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// E khutlisetsa ho hokahanya ho hlokahalang ho mofuta oa [ABI] oa mofuta oa boleng oo `val` e o supang.
///
/// Tlhaloso e ngoe le e ngoe ea boleng ba mofuta oa `T` e tlameha ho ba palo e ngata ea palo ena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // TSHIRELETSO: val ke setshupiso, ka hona ke sesupi se sebetsang se tala
    unsafe { intrinsics::min_align_of_val(val) }
}

/// E khutlisa peakanyo e nyane ea mofuta oa [ABI].
///
/// Tlhaloso e ngoe le e ngoe ea boleng ba mofuta oa `T` e tlameha ho ba palo e ngata ea palo ena.
///
/// Ena ke peakanyo e sebelisetsoang likarolo tsa sebopeho.E kanna ea ba nyane ho feta peakanyo e khethiloeng.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// E khutlisetsa ho hokahanya ho hlokahalang ho mofuta oa [ABI] oa mofuta oa boleng oo `val` e o supang.
///
/// Tlhaloso e ngoe le e ngoe ea boleng ba mofuta oa `T` e tlameha ho ba palo e ngata ea palo ena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // TSHIRELETSO: val ke setshupiso, ka hona ke sesupi se sebetsang se tala
    unsafe { intrinsics::min_align_of_val(val) }
}

/// E khutlisetsa ho hokahanya ho hlokahalang ho mofuta oa [ABI] oa mofuta oa boleng oo `val` e o supang.
///
/// Tlhaloso e ngoe le e ngoe ea boleng ba mofuta oa `T` e tlameha ho ba palo e ngata ea palo ena.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Mosebetsi ona o bolokehile feela hore o ka letsetsoa haeba maemo a latelang a le teng:
///
/// - Haeba `T` ke `Sized`, ts'ebetso ena e lula e bolokehile ho e letsetsa.
/// - Haeba mohatla o sa lekanyetsoang oa `T` ke:
///     - [slice], ebe bolelele ba mohatla oa selae e tlameha ho ba palo e qalileng, mme boholo ba *boleng bo felletseng*(bolelele ba mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
///     - [trait object], ebe karolo ea vtable ea pointer e tlameha ho supa vtable e nepahetseng e fumanoeng ka ho qobelloa ho sa lekanyetsoang, mme boholo ba *boleng bo felletseng*(bolelele ba mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
///
///     - (unstable) [extern type], ebe ts'ebetso ena e lula e bolokehile ho e letsetsa, empa e kanna eaba panic kapa e khutlisa boleng bo fosahetseng, joalo ka ha sebopeho sa mofuta oa kantle se sa tsejoe.
///     Ena ke boits'oaro bo ts'oanang le [`align_of_val`] ha ho buuoa ka mofuta o nang le mohatla oa mofuta o kantle.
///     - ho seng joalo, ka mokhoa o bolokehileng ha oa lumelloa ho bitsa ts'ebetso ena.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // TSHIRELETSO: moletsi o tlameha ho fana ka sesupi se sa hlahisoang se tala
    unsafe { intrinsics::min_align_of_val(val) }
}

/// E khutlisa `true` haeba e lahla boleng ba litaba tsa mofuta oa `T`.
///
/// Hona ke mohopolo feela o ntlafatsang, 'me o ka kengoa tšebetsong ka mokhoa o bolokehileng:
/// e kanna ea khutlisa `true` bakeng sa mefuta eo ho sa hlokahaleng hore e oeloe.
/// Kahoo ho khutlisa `true` kamehla e ka ba ts'ebetsong e nepahetseng ea ts'ebetso ena.Leha ho le joalo haeba ts'ebetso ena e khutlisa `false`, o ka ba le bonnete ba hore ho lahla `T` ha ho na litlamorao.
///
/// Ts'ebetsong ea maemo a tlase ea lintho tse kang likoleke, tse hlokang ho lahla data ea bona ka letsoho, li lokela ho sebelisa ts'ebetso ena ho qoba ho leka ho lahla litaba tsa tsona ho sa hlokahale ha li senngoa.
///
/// Sena se kanna sa se etse phapang ea ho aha tokollo (moo sekgoqetsane se se nang litla-morao se fumanehang habonolo le ho tlosoa), empa hangata e ba tlholo e kholo bakeng sa ho aha litšitiso.
///
/// Hlokomela hore [`drop_in_place`] e se e ntse e etsa cheke ena, kahoo haeba mojaro oa hau oa mosebetsi o ka fokotsoa ho ba palo e nyane ea mehala ea [`drop_in_place`], ho sebelisa sena ha ho hlokahale.
/// Haholo-holo hlokomela hore u ka etsa [`drop_in_place`] selae, 'me seo se tla etsa tlhahlobo e le ngoe ea litlhoko tsa litlhoko bakeng sa litekanyetso tsohle.
///
/// Mefuta e joalo ka Vec ke `drop_in_place(&mut self[..])` feela ntle le ho sebelisa `needs_drop` ka ho hlaka.
/// Mefuta e joalo ka [`HashMap`], ka lehlakoreng le leng, e tlameha ho lahla litekanyetso ka bonngoe 'me e lokela ho sebelisa API ena.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Mona ke mohlala oa kamoo pokello e ka sebelisang `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // lahlela data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// E khutlisa boleng ba mofuta oa `T` bo emeloang ke mofuta oa zero-byte.
///
/// Sena se bolela hore, mohlala, padding byte ho `(u8, u16)` ha e hlile ha e na zero.
///
/// Ha ho na tiiso ea hore mofuta oa zero-zero o emela boleng bo nepahetseng ba mofuta o mong oa `T`.
/// Mohlala, all-zero byte-pattern ha se boleng bo nepahetseng bakeng sa mefuta ea litšupiso (`&T`, `&mut T`) le litsupa tsa mesebetsi.
/// Ho sebelisa `zeroed` mefuteng e joalo ho baka [undefined behavior][ub] hanghang hobane [the Rust compiler assumes][inv] hore ho lula ho na le boleng bo nepahetseng molemong o fapaneng oo e nahanang hore o qalile.
///
///
/// Sena se na le phello e ts'oanang le [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// E bohlokoa bakeng sa FFI ka linako tse ling, empa ka kakaretso e lokela ho qojoa.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Tšebeliso e nepahetseng ea ts'ebetso ena: ho qala palo e kholo ka zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// Ts'ebeliso e fosahetseng * ea ts'ebetso ena: ho qala tšupiso le zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Boitšoaro bo sa hlalosoang!
/// let _y: fn() = unsafe { mem::zeroed() }; // Mme hape!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore boleng ba zero yohle bo nepahetse bakeng sa `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Meetso ea Rust e tloahelehileng e qala ho lekola ka ho iketsa eka e hlahisa boleng ba mofuta oa `T`, athe ha e etse letho.
///
/// **Ts'ebetso ena e theotsoe.** Sebelisa [`MaybeUninit<T>`] ho fapana.
///
/// Lebaka la ho nyahama ke hore mosebetsi ha o khone ho sebelisoa ka nepo: o na le phello e ts'oanang le [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Joalokaha [`assume_init` documentation][assume_init] e hlalosa, [the Rust compiler assumes][inv] hore litekanyetso li qalisoa hantle.
/// Ka lebaka leo, ho letsetsa mohlala
/// `mem::uninitialized::<bool>()` e baka boits'oaro bo sa hlalosoang kapele ba ho khutlisa `bool` eo kannete e seng `true` kapa `false`.
/// Ho hobe le ho feta, mohopolo o sa qalisoang joalo ka o khutlisoang mona o khethehile ka hore moqapi o tseba hore ha o na boleng bo lekantsoeng.
/// Sena se etsa hore e be boits'oaro bo sa hlalosoang ba ho ba le tlhaiso-leseling e sa qalisoang ka ho feto-fetoha leha phapang eo e na le mofuta o lekanang.
/// (Hlokomela hore melao e mabapi le linomoro tse sa qalisoang ha e so phetheloe, empa ho fihlela ha e etsoa, ho bohlokoa hore u e qobe.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore boleng bo sa hlahiswang bo sebetsa bakeng sa `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// E fetola boleng libakeng tse peli tse ka fetohang ntle le ho hlakola e le 'ngoe.
///
/// * Haeba u batla ho fapanyetsana ka boleng ba kamehla kapa ba dummy, bona [`take`].
/// * Haeba u batla ho fapanyetsana ka boleng bo fetisitsoeng, ho khutlisa boleng ba khale, bona [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // TSHIRELETSO: litsupa tse tala li entsoe ka litšupiso tse sireletsehileng tse ka fetoloang tse khotsofatsang tsohle
    // lithibelo ho `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// E khutlisa `dest` ka boleng ba mantlha ba `T`, e khutlisa boleng ba `dest` bo fetileng.
///
/// * Haeba u batla ho khutlisa boleng ba mefuta e 'meli, bona [`swap`].
/// * Haeba u batla ho khutlisa ka boleng bo fetisitsoeng ho fapana le boleng ba kamehla, bona [`replace`].
///
/// # Examples
///
/// Mohlala o bonolo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` e lumella ho nka beng ba tšimo ka ho e nkela sebaka ka boleng ba "empty".
/// Ntle le `take` u ka kena litabeng tse kang tsena:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Hlokomela hore `T` ha e hlile ha e sebelise [`Clone`], ka hona e ke ke ea khona ho ts'oara le ho seta `self.buf` hape.
/// Empa `take` e ka sebelisoa ho khetholla boleng ba mantlha ba `self.buf` ho `self`, ee lumella hore e khutlisoe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// E tsamaisa `src` ho `dest` e boletsoeng, e khutlisa boleng ba `dest` bo fetileng.
///
/// Ha ho boleng bo theotsoeng.
///
/// * Haeba u batla ho khutlisa boleng ba mefuta e 'meli, bona [`swap`].
/// * Haeba u batla ho khutlisa ka boleng bo sa feleng, bona [`take`].
///
/// # Examples
///
/// Mohlala o bonolo:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` e lumella tšebeliso ea tšimo ka ho e nkela sebaka ka boleng bo bong.
/// Ntle le `replace` u ka kena litabeng tse kang tsena:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Hlokomela hore `T` ha e hlile ha e sebelise [`Clone`], ka hona re sitoa le ho kopanya `self.buf[i]` ho qoba ho tsamaea.
/// Empa `replace` e ka sebelisoa ho khetholla boleng ba mantlha ho index eo ho tloha ho `self`, ee lumella hore e khutlisoe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // TSHIRELETSO: Re bala ho tloha ho `dest` empa ka ho otloloha re ngola `src` ho yona kamora moo,
    // joalo hore boleng ba khale ha bo kopitsoe.
    // Ha ho letho le oetsoeng 'me ha ho letho mona le ka khonang panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Lahla boleng.
///
/// Sena se etsa joalo ka ho letsetsa ts'ebetsong ea khang ea [`Drop`][drop].
///
/// Sena ha se etse letho bakeng sa mefuta e sebelisang `Copy`, mohlala
/// integers.
/// Litekanyetso tse joalo lia kopitsoa 'me _then_ e isoa tšebetsong, ka hona boleng bo ntse bo tsoela pele kamora mohala ona oa ts'ebetso.
///
///
/// Mosebetsi ona ha se boselamose;e hlalosoa ka nepo e le
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Hobane `_x` e isoa ts'ebetsong, e theoha ka boiketsetso pele mosebetsi o khutla.
///
/// [drop]: Drop
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // tlohela vector ka ho hlaka
/// ```
///
/// Kaha [`RefCell`] e tiisa melao ea kalimo ka nako ea ho matha, `drop` e ka lokolla mokoloto oa [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // tela mokoloto o ka fetohang sebakeng sena
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Linomoro le mefuta e meng e sebelisang [`Copy`] ha e amehe ke `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // khopi ea `x` ea sisinyeha ebe ea lahloa
/// drop(y); // khopi ea `y` ea sisinyeha ebe ea lahloa
///
/// println!("x: {}, y: {}", x, y.0); // e ntse e le teng
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// E fetolela `src` e le mofuta oa `&U`, ebe e bala `src` ntle le ho tsamaisa boleng bo teng.
///
/// Mosebetsi ona o tla nka hore sesupa `src` e sebetsa bakeng sa li-byte tsa [`size_of::<U>`][size_of] ka ho fetisa `&T` ho `&U` ebe o bala `&U` (ntle le hore sena se etsoa ka tsela e nepahetseng le ha `&U` e etsa litlhoko tse matla ho feta `&T`).
/// E tla etsa kopi ea boleng bo teng ka mokhoa o sa bolokehang ho fapana le ho tsoa `src`.
///
/// Ha se phoso ea nako ea ho bokella haeba `T` le `U` li na le boholo bo fapaneng, empa e khothaletsoa haholo ho kopa ts'ebetso ena feela moo `T` le `U` li nang le boholo bo lekanang.Mosebetsi ona o baka [undefined behavior][ub] haeba `U` e kholo ho feta `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopitsa data ho tsoa ho 'foo_array' 'me ue tšoare joaloka 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Fetola boitsebiso bo kopitsitsoeng
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Litaba tsa 'foo_array' ha lia lokela ho fetoha
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Haeba U e na le tlhoko ea boemo bo holimo, src e kanna ea se lumellane hantle.
    if align_of::<U>() > align_of::<T>() {
        // TSHIRELETSO: `src` ke setshupiso se netefaditsweng hore se nepahetse bakeng sa ho balwa.
        // Moletsi o tlameha ho netefatsa hore phetiso ea 'nete e bolokehile.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // TSHIRELETSO: `src` ke setshupiso se netefaditsweng hore se nepahetse bakeng sa ho balwa.
        // Re sa tsoa sheba hore `src as *const U` e hokahane hantle.
        // Moletsi o tlameha ho netefatsa hore phetiso ea 'nete e bolokehile.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Mofuta oa Opaque o emelang khethollo ea enum.
///
/// Bona ts'ebetso ea [`discriminant`] mojulung ona bakeng sa tlhaiso-leseling e batsi.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ts'ebetsong tsena tsa trait li ke ke tsa fumaneha hobane ha re batle meeli ho T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// E khutlisa boleng bo khethollang ka mokhoa o ikhethileng mofuta oa enum ho `v`.
///
/// Haeba `T` e se enum, ho letsetsa mosebetsi ona ho ke ke ha fella ka boits'oaro bo sa hlalosoang, empa boleng ba ho khutla ha bo tsejoe.
///
///
/// # Stability
///
/// Khethollo ea phapang ea enum e ka fetoha haeba tlhaloso ea enum e fetoha.
/// Khethollo ea mefuta e meng e ke ke ea fetoha lipakeng tsa likhokahano le moqapi o tšoanang.
///
/// # Examples
///
/// Sena se ka sebelisoa ho bapisa li-enum tse nang le data, ha u sa natse lintlha tsa nnete:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// E khutlisa palo ea mefuta e fapaneng ka mofuta oa enum `T`.
///
/// Haeba `T` e se enum, ho letsetsa mosebetsi ona ho ke ke ha fella ka boits'oaro bo sa hlalosoang, empa boleng ba ho khutla ha bo tsejoe.
/// Ka mokhoa o ts'oanang, haeba `T` ke enum e nang le mefuta e fapaneng ho feta `usize::MAX` boleng ba ho khutla ha bo tsejoe.
/// Mefuta e sa lekanyetsoang ea baahi e tla baloa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}