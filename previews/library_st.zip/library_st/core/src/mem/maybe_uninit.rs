use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Mofuta oa sekoahelo ho aha liketsahalo tse sa qalisoang tsa `T`.
///
/// # Qalo e sa fetoheng
///
/// Moqapi ka kakaretso o nka hore phapang e qalisoa hantle ho latela litlhoko tsa mofuta oa mofuta.Mohlala, mofuta o fapaneng oa litšupiso o tlameha ho hokahana le ho se NULL.
/// Sena ke se sa fetoheng se tlamehang ho lula se ts'oeroe, leha e le ka khoutu e sa bolokehang.
/// Ka lebaka leo, ho qala zero ho qala mofuta o fapaneng oa litšupiso ho baka [undefined behavior][ub] hanghang, ho sa tsotelehe hore na ts'upiso eo e kile ea tloaela ho fihlella mohopolo:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // boitšoaro bo sa hlalosoang!.️
/// // Khoutu e lekanang le `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // boitšoaro bo sa hlalosoang!.️
/// ```
///
/// Sena se sebelisoa hampe ke moqapi bakeng sa ntlafatso e fapaneng, joalo ka ho qoba ho hlahloba nako ea ho matha le ho ntlafatsa sebopeho sa `enum`.
///
/// Ka mokhoa o ts'oanang, memori e sa qalisoang ka botlalo e ka ba le litaba, ha `bool` e tlameha ho lula e le `true` kapa `false`.Kahoo, ho theha `bool` e sa qalisoang ke boits'oaro bo sa hlalosoang:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // boitšoaro bo sa hlalosoang!.️
/// // Khoutu e lekanang le `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // boitšoaro bo sa hlalosoang!.️
/// ```
///
/// Ntle le moo, mohopolo o sa qalisoang o khethehile ka hore ha o na boleng bo sa fetoheng ("fixed" e bolelang "it won't change without being written to").Ho bala e tšoanang uninitialized byte makhetlo a mangata ho ka fana ka liphetho tse fapaneng.
/// Sena se etsa hore e be boits'oaro bo sa hlalosoang ba ho ba le tlhaiso-leseling e sa qalisoang ka ho feto-fetoha le haeba phapano eo e na le mofuta o lekanang, o ka ts'oaroang o ka ts'oara mofuta o fe kapa o fe oa *
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // boitšoaro bo sa hlalosoang!.️
/// // Khoutu e lekanang le `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // boitšoaro bo sa hlalosoang!.️
/// ```
/// (Hlokomela hore melao e mabapi le linomoro tse sa qalisoang ha e so phetheloe, empa ho fihlela ha e etsoa, ho bohlokoa hore u e qobe.)
///
/// Holim'a moo, hopola hore mefuta e mengata e na le li-invariant tse ling ntle le ho nkuoa hore e qalile molemong oa mofuta.
/// Mohlala, `1`-e qalileng [`Vec<T>`] e nkuoa e qalile (tlasa ts'ebetsong ea hona joale; sena ha se netefatso e tsitsitseng) hobane tlhoko feela eo motsamaisi a e tsebang ka eona ke hore sesupa-data ha sea lokela ho ba lefeela.
/// Ho theha `Vec<T>` e joalo ha ho bake boits'oaro bo sa lebelloang, empa ho tla baka boits'oaro bo sa hlalosoang ka ts'ebetso e bolokehileng haholo (ho kenyeletsoa le ho e lahla).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` E sebeletsa ho nolofalletsa khoutu e sa bolokehang ho sebetsana le lintlha tse sa qalisoang.
/// Ke lets'oao ho moqapi le bonts'ang hore lintlha tse mona li kanna tsa se keng tsa qalisoa:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Theha tšupiso e sa qalisoang ka ho hlaka.
/// // Moqapi o tseba hore data e kahare ho `MaybeUninit<T>` e kanna ea se sebetse, ka hona sena ha se UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // E behe boleng bo nepahetseng.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Tlosa lintlha tse qalileng-sena se lumelloa feela ka mor'a * ho qala `x` hantle!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Moqapi o tseba hore a se ke a etsa likhopolo kapa likhakanyo tse fosahetseng khoutu ena.
///
/// U ka nahana ka `MaybeUninit<T>` e batla e tšoana le `Option<T>` empa e sena ts'ebetso ea nako ea ho matha le ntle le cheke ea polokeho.
///
/// ## out-pointers
///
/// U ka sebelisa `MaybeUninit<T>` ho kenya ts'ebetsong "out-pointers": sebakeng sa ho khutlisa data ho tsoa ts'ebetsong, e fetisetse sesupa ho memori ea (uninitialized) ho kenya sephetho.
/// Sena se ka ba molemo ha ho le bohlokoa hore moletsi a laole hore na sephetho sa mohopolo se bolokiloe ho sona se abuoa joang, 'me u batla ho qoba mehato e sa hlokahaleng.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ha e lahle litaba tsa khale, e leng tsa bohlokoa.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Joale rea tseba hore `v` e qalile!Sena se etsa bonnete ba hore vector e theoha hantle.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ho qala karolo ea lintho ka tatellano
///
/// `MaybeUninit<T>` e ka sebelisoa ho qala karolo e kholo ea likarolo-ka-element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Theha mofuta o sa qalisoang oa `MaybeUninit`.
///     // `assume_init` e bolokehile hobane mofuta oo re ipolelang hore re o qalile mona ke sehlopha sa `MaybeUninit`s, tse sa hlokeng ho qalisoa.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ho lahla `MaybeUninit` ha ho etse letho.
///     // Kahoo ho sebelisa kabelo e tala ho e-na le `ptr::write` ha ho etse hore boleng ba khale bo sa qaloang bo theoleloe.
/////
///     // Hape haeba ho na le panic nakong ena ea leqhubu, re na le memori e dutlang, empa ha ho na taba ea polokeho ea memori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tsohle lia qalisoa.
///     // Fetisetsa sehlopha ho mofuta o qalileng.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// U ka sebetsa le likarolo tse qalileng tse qalileng, tse ka fumanoang litsing tsa maemo a tlase.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Theha mofuta o sa qalisoang oa `MaybeUninit`.
/// // `assume_init` e bolokehile hobane mofuta oo re ipolelang hore re o qalile mona ke sehlopha sa `MaybeUninit`s, tse sa hlokeng ho qalisoa.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Bala palo ea likarolo tseo re li abetseng.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Bakeng sa ntho e ngoe le e ngoe ka tatellano, tlohella haeba re e abetse.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Ho qala tšimo ka tšimo
///
/// U ka sebelisa `MaybeUninit<T>`, le [`std::ptr::addr_of_mut`] macro, ho qala tšimo ka libaka:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // E qala tšimo ea `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ho qala tšimo ea `list` Haeba ho na le panic mona, ebe `String` e sebakeng sa `name` se dutlang.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Masimo ohle a qaliloe, ka hona re letsetsa `assume_init` ho fumana Foo e qalileng.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ho netefalitsoe hore e tla ba le boholo, tatellano, le ABI joalo ka `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Leha ho le joalo hopola hore mofuta *o nang le*`MaybeUninit<T>` ha se sebopeho se ts'oanang;Rust ha e fane ka tiiso e akaretsang ea hore masimo a `Foo<T>` a na le tatellano e ts'oanang le `Foo<U>` leha `T` le `U` li na le boholo le tatellano e lekanang.
///
/// Ntle le moo hobane boleng bofe kapa bofe ba boleng bo sebetsa bakeng sa `MaybeUninit<T>` moqapi a ke ke a etsa likhakanyo tsa non-zero/niche-filling, tse ka lebisang boholo bo boholo:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Haeba `T` e sireletsehile FFI, ho joalo le ka `MaybeUninit<T>`.
///
/// Le ha `MaybeUninit` e le `#[repr(transparent)]` (ho bontša hore e tiisa boholo bo lekanang, tatellano, le ABI joalo ka `T`), sena ha se * fetole leha e le efe ea lithibelo tse fetileng.
/// `Option<T>` mme `Option<MaybeUninit<T>>` e kanna ea ba le boholo bo fapaneng, 'me mefuta e nang le tšimo ea mofuta `T` e ka beoa (le boholo) ka tsela e fapaneng ho fapana le haeba tšimo eo e ne e le `MaybeUninit<T>`.
/// `MaybeUninit` ke mofuta oa bonngoe, 'me `#[repr(transparent)]` ho mekhatlo ea basebetsi ha e a tsitsa (bona [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Ha nako e ntse e tsamaea, netefatso ea `#[repr(transparent)]` ho mekhatlo ea basebetsi e ka fetoha, mme `MaybeUninit` e kanna ea lula `#[repr(transparent)]` kapa ea se ke ea lula.
/// Seo se boletse, `MaybeUninit<T>` e tla lula e netefatsa hore e na le boholo, tatellano, le ABI joalo ka `T`;ke feela hore tsela eo `MaybeUninit` e sebelisang ts'episo eo e ka fetoha.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang e le hore re ka thatela mefuta e meng ho eona.Sena se na le thuso bakeng sa lijenereithara.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ha re sa bitse `T::clone()`, re ke ke ra tseba hore na re qaliloe ka ho lekana bakeng sa seo.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// E theha `MaybeUninit<T>` e ncha e qalileng ka boleng bo fanoeng.
    /// Ho bolokehile ho letsetsa [`assume_init`] ka boleng ba ho khutlisa ts'ebetso ena.
    ///
    /// Hlokomela hore ho lahla `MaybeUninit<T>` ho ke ke ha hlola ho letsetsa khoutu ea `T`.
    /// Ke boikarabello ba hau ho etsa bonnete ba hore `T` ea oa ha e ka qala.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// E theha `MaybeUninit<T>` e ncha maemong a sa qalisoang.
    ///
    /// Hlokomela hore ho lahla `MaybeUninit<T>` ho ke ke ha hlola ho letsetsa khoutu ea `T`.
    /// Ke boikarabello ba hau ho etsa bonnete ba hore `T` ea oa ha e ka qala.
    ///
    /// Bona [type-level documentation][MaybeUninit] bakeng sa mehlala e meng.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Theha lethathamo le lecha la lintho tsa `MaybeUninit<T>`, maemong a sa qalisoang.
    ///
    /// Note: Mofuteng oa future Rust mokhoa ona o ka fetoha o sa hlokahaleng ha syntax ea mantlha e lumella [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Mohlala o ka tlase o ne o ka sebelisa `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// E khutlisa selae sa (mohlomong se nyane) sa data se neng se baliloe
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // TŠIRELETSO: `[MaybeUninit<_>; LEN]` e sa qalisoang e nepahetse.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// E etsa `MaybeUninit<T>` e ncha boemong bo sa qalisoang, mohopolo o tlatsoa ka li-byte tsa `0`.Ho latela `T` hore na e se e ntse e etsa hore e qalo e nepahetseng.
    ///
    /// Mohlala, `MaybeUninit<usize>::zeroed()` e qalile, empa `MaybeUninit<&'static i32>::zeroed()` ha se hobane litšupiso li sa lokela ho ba lefeela.
    ///
    /// Hlokomela hore ho lahla `MaybeUninit<T>` ho ke ke ha hlola ho letsetsa khoutu ea `T`.
    /// Ke boikarabello ba hau ho etsa bonnete ba hore `T` ea oa ha e ka qala.
    ///
    /// # Example
    ///
    /// Ts'ebeliso e nepahetseng ea ts'ebetso ena: ho qala sebopeho le zero, moo likarolo tsohle tsa struct li ka ts'oereng mohlala-0 e le boleng bo nepahetseng.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng * ea ts'ebetso ena: ho letsetsa `x.zeroed().assume_init()` ha `0` e se mokhoa o nepahetseng oa mofuta ona:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ka hare ho para, re theha `NotZero` e se nang khethollo e nepahetseng.
    /// // Ena ke boits'oaro bo sa hlalosoang..️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // TŠIRELETSO: `u.as_mut_ptr()` e supa mohopolo o abetsoeng.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// E beha boleng ba `MaybeUninit<T>`.
    /// Sena se ngola boleng bofe kapa bofe ba pele ntle le ho se lahla, ka hona, hlokomela hore u se sebelise sena habeli ntle le haeba u batla ho tlola ho tsamaisa sesosa.
    ///
    /// Molemong oa hau, sena se boetse se khutlisa litšupiso tse ka fetoloang ho (tse seng li qaliloe ka mokhoa o bolokehileng) tsa `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // POLOKEHO: Re sa tsoa qala boleng bona.
        unsafe { self.assume_init_mut() }
    }

    /// E fumana sesupa ho boleng bo nang le eona.
    /// Ho bala ho tsoa sesupisong sena kapa ho se fetola e le boits'oaro ke boits'oaro bo sa hlalosoang ntle le haeba `MaybeUninit<T>` e qalisoa.
    /// Ho ngolla mohopolong hore sesupisi sena sa (non-transitively) se supa ho boits'oaro bo sa hlalosoang (ntle le kahare ho `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Theha tšupiso ho `MaybeUninit<T>`.Sena se lokile hobane re se qalile.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Re thehile litšupiso ho vector e sa qalisoang!Ena ke boits'oaro bo sa hlalosoang..️
    /// ```
    ///
    /// (Hlokomela hore melao e mabapi le litšupiso tsa tlhaiso-leseling e e-so ho qaloe ha e so phetheloe, empa ho fihlela ha e etsoa, ho bohlokoa ho e qoba.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` le `ManuallyDrop` ka bobeli ke `repr(transparent)` kahoo re ka lahlela sesupa-tsela.
        self as *const _ as *const T
    }

    /// E fumana sesupisi se ka fetoloang ho boleng bo fumanehang.
    /// Ho bala ho tsoa sesupisong sena kapa ho se fetola e le boits'oaro ke boits'oaro bo sa hlalosoang ntle le haeba `MaybeUninit<T>` e qalisoa.
    ///
    /// # Examples
    ///
    /// Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Theha tšupiso ho `MaybeUninit<Vec<u32>>`.
    /// // Sena se lokile hobane re se qalile.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Re thehile litšupiso ho vector e sa qalisoang!Ena ke boits'oaro bo sa hlalosoang..️
    /// ```
    ///
    /// (Hlokomela hore melao e mabapi le litšupiso tsa tlhaiso-leseling e e-so ho qaloe ha e so phetheloe, empa ho fihlela ha e etsoa, ho bohlokoa ho e qoba.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` le `ManuallyDrop` ka bobeli ke `repr(transparent)` kahoo re ka lahlela sesupa-tsela.
        self as *mut _ as *mut T
    }

    /// E ntša boleng ho setshelo sa `MaybeUninit<T>`.Ena ke mokhoa o motle oa ho netefatsa hore data e tla theoha, hobane `T` e hlahisoang e tlas'a ts'ebeliso e tloaelehileng ea lerotholi.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho tiisa hore `MaybeUninit<T>` e maemong a qalileng.Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlalosehang hanghang.
    /// [type-level documentation][inv] e na le tlhaiso-leseling e batsi ka ts'ebetso ena ea ho qala.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Holim'a moo, hopola hore mefuta e mengata e na le li-invariant tse ling ntle le ho nkuoa hore e qalile molemong oa mofuta.
    /// Mohlala, `1`-e qalileng [`Vec<T>`] e nkuoa e qalile (tlasa ts'ebetsong ea hona joale; sena ha se netefatso e tsitsitseng) hobane tlhoko feela eo motsamaisi a e tsebang ka eona ke hore sesupa-data ha sea lokela ho ba lefeela.
    ///
    /// Ho theha `Vec<T>` e joalo ha ho bake boits'oaro bo sa lebelloang, empa ho tla baka boits'oaro bo sa hlalosoang ka ts'ebetso e bolokehileng haholo (ho kenyeletsoa le ho e lahla).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` e ne e so qalisoe, ka hona mohala ona oa hoqetela o bakile boits'oaro bo sa hlaloseheng.️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // TSHIRELETSO: moletsi o lokela ho netefatsa hore `self` e qadile.
        // Sena se boetse se bolela hore `self` e tlameha ho ba mofuta o fapaneng oa `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// E bala boleng ho tsoa setshelong sa `MaybeUninit<T>`.`T` e hlahisoang e tlas'a taolo e tloaelehileng ea ho lahla.
    ///
    /// Nako le nako ha ho khonahala, ho molemo ho sebelisa [`assume_init`] ho fapana, e thibelang ho kopitsa likateng tsa `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore `MaybeUninit<T>` e maemong a qalileng.Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlaloseheng.
    /// [type-level documentation][inv] e na le tlhaiso-leseling e batsi ka ts'ebetso ena ea ho qala.
    ///
    /// Ho feta moo, sena se siea kopi ea data e ts'oanang morao ho `MaybeUninit<T>`.
    /// Ha u sebelisa likopi tse ngata tsa data (ka ho letsetsa `assume_init_read` makhetlo a mangata, kapa ho letsetsa `assume_init_read` ebe [`assume_init`]), ke boikarabello ba hau ho netefatsa hore data eo e kanna ea kopitsoa.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ke `Copy`, kahoo re ka bala makhetlo a mangata.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ho kopitsa boleng ba `None` ho lokile, kahoo re ka bala makhetlo a mangata.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Hona joale re thehile likopi tse peli tsa vector e ts'oanang, e lebisang ho e sa lefelloeng habeli ha li theoha ka bobeli!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // TSHIRELETSO: moletsi o lokela ho netefatsa hore `self` e qadile.
        // Ho bala ho tloha `self.as_ptr()` ho bolokehile kaha `self` e lokela ho qalisoa.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// E theola boleng bo nang le sebaka.
    ///
    /// Haeba u na le `MaybeUninit`, u ka sebelisa [`assume_init`] ho fapana.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore `MaybeUninit<T>` e maemong a qalileng.Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlaloseheng.
    ///
    /// Holim'a moo, bahlaseli ba bang ba tlatsetso ba mofuta oa `T` ba tlameha ho khotsofatsoa, kaha ts'ebetsong ea `Drop` ea `T` (kapa litho tsa eona) e kanna ea itšetleha ka sena.
    /// Mohlala, `1`-e qalileng [`Vec<T>`] e nkuoa e qalile (tlasa ts'ebetsong ea hona joale; sena ha se netefatso e tsitsitseng) hobane tlhoko feela eo motsamaisi a e tsebang ka eona ke hore sesupa-data ha sea lokela ho ba lefeela.
    ///
    /// Ho lahla `Vec<T>` e joalo ho tla baka boits'oaro bo sa hlaloseheng.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e qalile mme
        // e khotsofatsa lihlaseli tsohle tsa `T`.
        // Ho theola boleng ba sebaka ho bolokehile haeba ho le joalo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// E fumana litšupiso tse arolelanoeng tsa boleng bo nang le tsona.
    ///
    /// Sena se ka ba molemo ha re batla ho fihlella `MaybeUninit` e qalileng empa e se na beng ba `MaybeUninit` (e thibelang ts'ebeliso ea `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ho letsetsa sena ha litaba li e-so qalelloe ka botlalo ho baka boits'oaro bo sa hlaloseheng: ho ho motho ea letsitseng ho netefatsa hore `MaybeUninit<T>` e maemong a qalileng.
    ///
    ///
    /// # Examples
    ///
    /// ### Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Qala `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Kaha joale `MaybeUninit<_>` ea rona e tsejoa hore e tla qala, ho lokile ho theha litšupiso tse arolelanoeng ho eona:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // POLOKEHO: `x` e se e qaliloe.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Re thehile litšupiso ho vector e sa qalisoang!Ena ke boits'oaro bo sa hlalosoang..️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Qala `MaybeUninit` u sebelisa `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Ho buuoa ka `Cell<bool>` e sa qalisoang: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // TSHIRELETSO: moletsi o lokela ho netefatsa hore `self` e qadile.
        // Sena se boetse se bolela hore `self` e tlameha ho ba mofuta o fapaneng oa `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// E fumana phetoho e ka fetoloang ea (unique) ho boleng bo nang le eona.
    ///
    /// Sena se ka ba molemo ha re batla ho fihlella `MaybeUninit` e qalileng empa e se na beng ba `MaybeUninit` (e thibelang ts'ebeliso ea `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ho letsetsa sena ha litaba li e-so qalelloe ka botlalo ho baka boits'oaro bo sa hlaloseheng: ho ho motho ea letsitseng ho netefatsa hore `MaybeUninit<T>` e maemong a qalileng.
    /// Mohlala, `.assume_init_mut()` e ke ke ea sebelisoa ho qala `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Tšebeliso e nepahetseng ea mokhoa ona:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// E qala * li-byte tsohle tsa konopo ea ho kenya.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Qala `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Joale rea tseba hore `buf` e se e qaliloe, ka hona re ka e `.assume_init()`.
    /// // Leha ho le joalo, ho sebelisa `.assume_init()` ho ka baka `memcpy` ea 2048 byte.
    /// // Ho tiisa hore buffer ea rona e qaliloe ntle le ho e kopitsa, re ntlafatsa `&mut MaybeUninit<[u8; 2048]>` ho ea ho `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // POLOKEHO: `buf` e se e qaliloe.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Joale re ka sebelisa `buf` joalo ka selae se tloaelehileng:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Ts'ebeliso e fosahetseng * ea mokhoa ona:
    ///
    /// U ke ke ua sebelisa `.assume_init_mut()` ho qala boleng:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Re thehile litšupiso tsa (mutable) ho `bool` e sa qalisoang!
    ///     // Ena ke boits'oaro bo sa hlalosoang..️
    /// }
    /// ```
    ///
    /// Mohlala, o ka se [`Read`] ka hara buffer e sa qalisoang:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ho buuoa ka mohopolo o sa qalisoang!
    ///                             // Ena ke boits'oaro bo sa hlalosoang.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Hape u ke ke ua sebelisa phihlello ea tšimo ka kotlolloho ho qala tšimo ka tšimo butle-butle:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ho buuoa ka mohopolo o sa qalisoang!
    ///                  // Ena ke boits'oaro bo sa hlalosoang.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ho buuoa ka mohopolo o sa qalisoang!
    ///                  // Ena ke boits'oaro bo sa hlalosoang.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Hajoale re ts'epa hore tse boletsoeng kaholimo ha lia nepahala, ke hore, re na le litšupiso tsa tlhaiso-leseling e sa qalisoang (mohlala, ho `libcore/fmt/float.rs`).
    // Re lokela ho etsa qeto ea hoqetela ka melao pele re ka tsitsa.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // TSHIRELETSO: moletsi o lokela ho netefatsa hore `self` e qadile.
        // Sena se boetse se bolela hore `self` e tlameha ho ba mofuta o fapaneng oa `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// E qhekella boleng ho tsoa lethathamong la lijana tsa `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore likarolo tsohle tsa sehlopha li maemong a qalileng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // TSHIRELETSO: E se e sireletsehile ha re ntse re qala likarolo tsohle
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Moletsi o tiisa hore likarolo tsohle tsa sehlopha lia qalisoa
        // * `MaybeUninit<T>` mme T e netefalitsoe hore e tla ba le sebopeho se tšoanang
        // * MohlomongUnint ha e oe, ka hona ha ho na litokollo tse habeli 'Me ka hona phetoho e bolokehile
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ho nka hore likarolo tsohle li qalile, fumana selae ho tsona.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore likarolo tsa `MaybeUninit<T>` li maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlaloseheng.
    ///
    /// Bona [`assume_init_ref`] bakeng sa lintlha le mehlala e meng.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // TSHIRELETSO: ho lahla selaete ho `*const [T]` ho bolokehile ho tloha ha moletsi a tiisa seo
        // `slice` e qalisoa, 'me`MaybeUninit` e netefalitsoe hore e tla ba le sebopeho se ts'oanang le `T`.
        // Sesupi se fumanoeng sea sebetsa hobane se bua ka mohopolo oa `slice` e leng sengoliso 'me ka hona se netefalitsoe hore se nepahetse bakeng sa ho baloa.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ho nka hore likarolo tsohle li se li qalile, fumana selae se ka fetoloang ho bona.
    ///
    /// # Safety
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore likarolo tsa `MaybeUninit<T>` li maemong a qalileng.
    ///
    /// Ho letsetsa sena ha litaba li e-so qaloe ka botlalo ho baka boits'oaro bo sa hlaloseheng.
    ///
    /// Bona [`assume_init_mut`] bakeng sa lintlha le mehlala e meng.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // TŠIRELETSO: e ts'oanang le lintlha tsa polokeho bakeng sa `slice_get_ref`, empa re na le
        // phetoho e ka feto-fetohang eo hape e netefalitsoeng hore e tla sebetsa bakeng sa ho ngola.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// E fumana sesupisi ho karolo ea pele ea sehlopha.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// E fumana sesupi se ka fetohang ho karolo ea pele ea sehlopha.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// E kopitsa likarolo ho tloha ho `src` ho ea ho `this`, e khutlisetse ts'upiso e ka fetoloang ho litaba tsa `this` tse seng li sa sebetse.
    ///
    /// Haeba `T` e sa sebelise `Copy`, sebelisa [`write_slice_cloned`]
    ///
    /// Sena se ts'oana le [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla ba panic haeba likhae tse peli li na le bolelele bo fapaneng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TŠIRELETSO: re sa tsoa kopitsa likarolo tsohle tsa len ho bokhoni ba poloko
    /// // likarolo tsa pele tsa src.len() tsa vec li sebetsa joale.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // TSHIRELETSO: &[T] le&[MaybeUninit<T>] li na le sebopeho se tšoanang
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // TŠIRELETSO: Lintho tse sebetsang li sa tsoa kopitsoa ho `this` ka hona ha e na matla
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// E khabisa likarolo tsa `src` ho ea ho `this`, e khutlisetsa ts'upiso e ka fetoloang ho se ka hare ho `this`.
    /// Lintho life kapa life tse seng li ntse li kenelletsoe li ke ke tsa akheloa.
    ///
    /// Haeba `T` e kenya `Copy`, sebelisa [`write_slice`]
    ///
    /// Sena se ts'oana le [`slice::clone_from_slice`] empa ha se tlohele lintho tse seng li ntse li le teng.
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena e tla panic haeba likotoana tse peli li na le bolelele bo fapaneng, kapa haeba ts'ebetsong ea `Clone` panics.
    ///
    /// Haeba ho na le panic, likarolo tse seng li entsoe li tla lahloa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // TSHIRELETSO: re sa tswa hlophisa dielemente tsohle tsa len matla a ho boloka
    /// // likarolo tsa pele tsa src.len() tsa vec li sebetsa joale.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ho fapana le copy_from_slice sena ha se bitse clone_from_slice selae sena ke hobane `MaybeUninit<T: Clone>` ha e sebelise Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // TS'ireletso: selae sena se tala se tla ba le lintho tse qalileng feela
                // ke ka hona, e lumelloang ho e lahla.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Re hloka ho li arola ka mokhoa o hlakileng ka bolelele bo lekanang
        // bakeng sa ho lekanyetsa meeli hore e qheleloe, 'me optimizer e tla hlahisa memcpy bakeng sa linyeoe tse bonolo (mohlala T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Molebeli oa hlokahala b/c panic e kanna ea etsahala nakong ea "clone"
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // TŠIRELETSO: Lintho tse sebetsang li sa tsoa ngolisoa ho `this` ka hona ha e na matla
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}