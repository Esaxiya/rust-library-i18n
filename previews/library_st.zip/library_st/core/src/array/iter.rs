//! E hlalosa seterator sa `IntoIter` se nang le thepa.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Mohlophisi oa boleng ba [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ona ke mofuta oo re o phetelang.
    ///
    /// Lintlha tse nang le index `i` moo `alive.start <= i < alive.end` e so hlahisoe hona joale 'me ke litlatsetso tse nepahetseng.
    /// Lintho tse nang le li-indices `i < alive.start` kapa `i >= alive.end` li se li hlahisitsoe mme ha li sa tlameha ho fihlelloa hape!Lintho tseo tse shoeleng li kanna tsa ba li le boemong bo sa qalisoang ka botlalo!
    ///
    ///
    /// Kahoo bahlaseli ke:
    /// - `data[alive]` oa phela (ke hore, o na le likarolo tse nepahetseng)
    /// - `data[..alive.start]` mme `data[alive.end..]` e shoele (ke hore likarolo li ne li se li baliloe mme ha li sa lokela ho angoa hape!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Lintlha tsa `data` tse e-s'o hlahisoe.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// E etsa iterator e ncha holim'a `array` e fanoeng.
    ///
    /// *Hlokomela*: mokhoa ona o kanna oa fokotseha ho future, kamora [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Mofuta oa `value` ke `i32` mona, sebakeng sa `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // TSHIRELETSO: Transute mona e hlile e bolokehile.Litokomane tsa `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` e netefalitsoe hore e tla ba le boholo le tatellano e ts'oanang
        // > joalo ka `T`.
        //
        // Li-docs li bile li bonts'a phetiso ho tloha ho `MaybeUninit<T>` ho ea ho `T`.
        //
        //
        // Ka seo, qalo ena e khotsofatsa bahlaseli.

        // FIXME(LukasKalbertodt): sebelisa `mem::transmute` mona, hang ha e sebetsa le li-generic:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Ho fihlela ka nako eo, re ka sebelisa `mem::transmute_copy` ho etsa kopi e nyane joalo ka mofuta o fapaneng, ebe re lebala `array` hore e se ke ea theoleloa tlase.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// E khutlisa selae se sa fetoheng sa likarolo tsohle tse so kang li hlahisoa.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // TSHIRELETSO: Rea tseba hore likarolo tsohle tse kahare ho `alive` li qalisitsoe hantle.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// E khutlisa selae se ka feto-fetohang sa likarolo tsohle tse so hlahisoang.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // TSHIRELETSO: Rea tseba hore likarolo tsohle tse kahare ho `alive` li qalisitsoe hantle.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Fumana index e latelang ho tloha ka pele.
        //
        // Ho eketsa `alive.start` ka 1 ho boloka ho sa fetoheng mabapi le `alive`.
        // Leha ho le joalo, ka lebaka la phetoho ena, sebaka se setseng ha se `data[alive]`, empa ke `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Bala karolo ho tsoa lenaneng.
            // TSHIRELETSO: `idx` ke sesupo sa karolo ya pele ya "alive" ya
            // array.Ho bala ntlha ena ho bolela hore `data[idx]` e nkuoa e shoele joale (ke hore, u se ke oa ama).
            // Kaha `idx` e ne e le qalo ea libaka tse ntseng li phela, sebaka se ntseng se phela e se e le `data[alive]` hape, se khutlisetsa bohle ba sa hlaseleng.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Fumana index e latelang ho tloha ka morao.
        //
        // Ho fokotsa `alive.end` ka 1 ho boloka ho sa fetoheng mabapi le `alive`.
        // Leha ho le joalo, ka lebaka la phetoho ena, sebaka se setseng ha se `data[alive]`, empa ke `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Bala karolo ho tsoa lenaneng.
            // TSHIRELETSO: `idx` ke sesupo sa karolo ya pele ya "alive" ya
            // array.Ho bala ntlha ena ho bolela hore `data[idx]` e nkuoa e shoele joale (ke hore, u se ke oa ama).
            // Kaha `idx` e ne e le pheletso ea libaka tse ntseng li phela, sebaka se ntseng se phela se se se le `data[alive]` hape, se khutlisetsa bohle ba sa hlaseleng.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // TSHIRELETSO: Sena se bolokehile: `as_mut_slice` e khutlisa sekhechana hantle
        // tsa likarolo tse so kang li ntšoa ebe li ntse li lokela ho lahloa.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Ha ho mohla e tla phalla ka lebaka la `` alive.start '' e sa fetoheng <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Mohlophisi o tlaleha bolelele bo nepahetseng.
// Palo ea likarolo tsa "alive" (tse ntseng li tla hlahisoa) ke bolelele ba `alive`.
// Lebelo lena le fokotsehile ka bolelele ka `next` kapa `next_back`.
// Kamehla e fokotsoa ke 1 mekhoeng eo, empa ha feela `Some(_)` e khutlisitsoe.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Hlokomela, ha ho hlokahale hore re tšoane le mofuta o tšoanang hantle oa bophelo, ka hona re ka ts'oaroa ho offset 0 ho sa tsotelehe `self` e hokae.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Etsa lintho tsohle tse phelang.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ngola lesela ka har'a sehlopha se secha, ebe u se ntlafatsa.
            // Haeba cloning panics, ka nepo re tla lahla lintho tse fetileng.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Hatisa feela likarolo tse neng li so ka li hlahisa: ha re sa khona ho fihlella likarolo tse hlahisitsoeng.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}