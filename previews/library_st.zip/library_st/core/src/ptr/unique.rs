use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Sekoahelo se pota-potileng `*mut T` e tala e sa boneng e bonts'a hore mong'a sekoahelo sena ke sa hae.
/// E na le thuso bakeng sa ho aha litšitiso tse kang `Box<T>`, `Vec<T>`, `String`, le `HashMap<K, V>`.
///
/// Ho fapana le `*mut T`, `Unique<T>` e itšoara joaloka "as if" e ne e le mohlala oa `T`.
/// E kenya ts'ebetsong `Send`/`Sync` haeba `T` e le `Send`/`Sync`.
/// E fana ka maikutlo a hore mofuta oa li-aliasing tse matla o tiisa hore mohlala oa `T` o ka lebella:
/// Referent ea pointer ha ea lokela ho fetoloa ntle le tsela e ikhethileng ea ho ba le eona e ikhethang.
///
/// Haeba o sa tsebe hantle hore na ho nepahetse ho sebelisa `Unique` molemong oa hau, nahana ka ho sebelisa `NonNull`, e nang le semantics e fokolang.
///
///
/// Ho fapana le `*mut T`, sesupa-hlooho se tlameha ho lula se sa sebetse, leha sesupa-tsela se sa hlahisoe hape.
/// Sena ke hore li-enum li ka sebelisa boleng bona bo hanetsoeng joalo ka khethollo-`Option<Unique<T>>` e na le boholo bo lekanang le `Unique<T>`.
/// Leha ho le joalo, sesupi se kanna sa thekesela haeba se sa hlalosoe.
///
/// Ho fapana le `*mut T`, `Unique<T>` ke covariant ho feta `T`.
/// Sena se lokela ho lula se nepahetse bakeng sa mofuta ofe kapa ofe o tšehetsang litlhoko tse ikhethileng tsa ikhethelo.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: lesupa lena ha le na litlamorao bakeng sa ho fapana, empa hoa hlokahala
    // molemong oa ho utloisisa hore re na le `T` ka mokhoa o utloahalang.
    //
    // Bakeng sa lintlha, bona:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` litsupa ke `Send` haeba `T` ke `Send` hobane data eo ba e supang e felisitsoe.
/// Hlokomela hore sehlophisi sena se hlaselang ha se qobelloe ke mofuta oa sistimi;Tlhaloso e sebelisang `Unique` e tlameha ho e tiisa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` litsupa ke `Sync` haeba `T` ke `Sync` hobane data eo ba e supang e felisitsoe.
/// Hlokomela hore sehlophisi sena se hlaselang ha se qobelloe ke mofuta oa sistimi;Tlhaloso e sebelisang `Unique` e tlameha ho e tiisa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// E etsa `Unique` e ncha e lepeletseng, empa e hokahane hantle.
    ///
    /// Sena se na le thuso bakeng sa ho qala mefuta e fanoang ka botsoa, joalo ka `Vec::new`.
    ///
    /// Hlokomela hore boleng ba sesupi bo kanna ba emela sesupa se nepahetseng ho `T`, ho bolelang hore sena ha sea lokela ho sebelisoa e le boleng ba "not yet initialized" sentinel.
    /// Mefuta e fanang ka botsoa e tlameha ho latedisa ho qala ka mekhoa e meng.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // TŠIRELETSO: mem::align_of() e khutlisa sesupi se nepahetseng, se se nang thuso.The
        // Kahoo maemo a ho letsetsoa new_unchecked() a hlomphuoa.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// E theha `Unique` e ncha.
    ///
    /// # Safety
    ///
    /// `ptr` ha ea lokela ho ba null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `ptr` ha e na thuso.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// E etsa `Unique` e ncha haeba `ptr` e sa sebetse.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TSHIRELETSO: Sesupi se se se hlahlobilwe mme ha se lefeela.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// E fumana sesupa-ntlha sa `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// E khetholla litaba.
    ///
    /// Nako ea bophelo e tlisoang ke eona e ikemetse kahoo e itšoara joaloka "as if" ehlile e ne e le mohlala oa T o alingoang.
    /// Haeba ho hlokahala nako e telele ea (unbound), sebelisa `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        unsafe { &*self.as_ptr() }
    }

    /// Ka mokhoa o ts'oanang li hlahisa litaba.
    ///
    /// Nako ea bophelo e tlisoang ke eona e ikemetse kahoo e itšoara joaloka "as if" ehlile e ne e le mohlala oa T o alingoang.
    /// Haeba ho hlokahala nako e telele ea (unbound), sebelisa `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso e ka fetohang.
        unsafe { &mut *self.as_ptr() }
    }

    /// E kenya sesupisi sa mofuta o mong.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // TŠIRELETSO: Unique::new_unchecked() e theha e ncha e ikhethang le litlhoko
        // sesupi se fanoeng hore se se ke sa sebetsa.
        // Kaha re ntse re iphetela joaloka pointer, e ke ke ea fetoha lefeela.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TSHIRELETSO: Tshupiso e ka fetohang ha e na ho fetoha
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}