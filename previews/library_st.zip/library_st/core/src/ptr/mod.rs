//! Laola memori ka matsoho ka litsupiso tse tala.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mesebetsi e mengata mojulung ona e nka lits'oants'o tse tala e le likhang ebe e li balla kapa ho li ngolla.E le hore sena se bolokehe, litsupa tsena li tlameha ho ba tse *sebetsang*.
//! Hore na sesupi se nepahetse ho latela ts'ebetso eo se e sebeliselitseng (bala kapa ho ngola), le boholo ba mohopolo o fihletsoeng (ke hore, read/written ea li-byte).
//! Mesebetsi e mengata e sebelisa `*mut T` le `* const T` ho fihlella boleng bo le bong feela, 'me maemong ao litokomane li siea boholo ebe li nka hore ke li-byte tsa `size_of::<T>()`.
//!
//! Melao e nepahetseng ea bonnete ha e so tsejoe.Litšepiso tse fanoeng hona joale li nyane haholo:
//!
//! * Sesupa sa [null] ha se sebetse *, leha e le bakeng sa phihlello ea [size zero][zst].
//! * Hore sesupa se sebetse hantle, ho a hlokahala, empa ha se lekane kamehla, hore sesupi se be se ke keng sa hlalosoa *: mohopolo oa boholo bo fanoeng o qalang ho pointer o tlameha ho ba kahara meeli ea ntho e le 'ngoe e abetsoeng.
//!
//! Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
//! * Le bakeng sa ts'ebetso ea [size zero][zst], sesupa-hlooho ha sea lokela ho supa mohopolo o tsamaisitsoeng, ke hore, ho tsamaisoa ho etsa hore litsupa li se sebetse le bakeng sa ts'ebetso ea boholo ba zero.
//! Leha ho le joalo, ho lahlela "pointer" efe kapa efe e seng zero "ho" pointer "ho nepahetse bakeng sa phihlello e boholo ba zero, leha mohopolo o mong o ka ba teng atereseng eo ebe oa tsamaisoa.
//! Sena se tsamaellana le ho ngola seabo sa hau: ho abela lintho tsa boholo ba zero ha ho thata haholo.
//! Mokhoa o hlophisitsoeng oa ho fumana sesupa-tsela se sebetsang bakeng sa phihlello ea boholo ba zero ke [`NonNull::dangling`].
//! * Phitlhelelo eohle e etsoang ke mesebetsi mojuleng ona ke *e seng atomic* ka kutloisiso ea [atomic operations] e sebelisitsoeng ho hokahanya lipakeng tsa likhoele.
//! Hona ho bolela hore ke boits'oaro bo sa hlalosoang ho etsa phihlello e le 'ngoe ka nako e le' ngoe sebakeng se le seng ho tsoa likhoeleng tse fapaneng ntle le haeba bobeli ba tsona ba bala feela ho tsoa mohopolong.
//! Hlokomela hore sena se kenyelletsa ka ho hlaka [`read_volatile`] le [`write_volatile`]: Ho fihlella ka bongata ha ho khone ho sebelisoa bakeng sa khokahano ea likhoele.
//! * Litholoana tsa ho qekisa sesupa-tsela e sebetsa ha feela ntho e ipatileng e ntse e phela 'me ha ho na litšupiso (litsupa tse tala feela) tse sebelisoang ho fihlella mohopolo o tšoanang.
//!
//! Li-axioms tsena, hammoho le ts'ebeliso e hlokolosi ea [`offset`] bakeng sa lipalo tsa pointer, li lekane ho kenya tšebetsong ka nepo lintho tse ngata tsa bohlokoa ka khoutu e sa bolokehang.
//! Tiiso e matla e tla fanoa qetellong, ha melao ea [aliasing] e ntse e etsoa.
//! Bakeng sa tlhaiso-leseling e batsi, sheba [book] hammoho le karolo eo ho buuoang ka eona ho [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Litlhahiso tse sebetsang tse tala tse hlalositsoeng kaholimo ha li hlile ha lia tsamaellana hantle (moo tatellano ea "proper" e hlalosoang ke mofuta oa pointee, ke hore, `*const T` e tlameha ho hokahana le `mem::align_of::<T>()`).
//! Le ha ho le joalo, mesebetsi e mengata e hloka hore mabaka a bona a hokahanngoe hantle, 'me e tla hlakisa tlhoko ena litokomaneng tsa bona.
//! Likhetho tse tsebahalang ho sena ke [`read_unaligned`] le [`write_unaligned`].
//!
//! Ha ts'ebetso e hloka ho tsamaellana hantle, e etsa joalo leha phihlello e na le boholo ba 0, ke hore, le ha mohopolo o sa ameha.Nahana ka ho sebelisa [`NonNull::dangling`] maemong a joalo.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// E phethisa mosenyi (haeba a le teng) oa boleng bo boletsoeng.
///
/// Sena se batla se lekana le ho letsetsa [`ptr::read`] le ho lahla sephetho, empa se na le melemo e latelang:
///
/// * Ho hlokahala * ho sebelisa `drop_in_place` ho lahla mefuta e sa lekanyetsoang joalo ka lintho tsa trait, hobane li ke ke tsa balloa ka mokoting ebe li oela ka mokhoa o tloaelehileng.
///
/// * Ke mofuthu ho optimizer ho etsa sena ho feta [`ptr::read`] ha o lahla memori e abetsoeng ka letsoho (mohlala, ts'ebetsong ea `Box`/`Rc`/`Vec`), kaha moqapi ha a hloke ho paka hore ho utloahala ho sebelisa kopi.
///
///
/// * E ka sebelisoa ho lahla data ea [pinned] ha `T` e se `repr(packed)` (data e pentiloeng ha ea lokela ho tsamaisoa pele e theoleloa).
///
/// Litekanyetso tse sa lekanyetsoang li ke ke tsa theoleloa sebakeng sa tsona, li tlameha ho qopitsoa sebakeng se tsamaellaneng pele ho sebelisoa [`ptr::read_unaligned`].Bakeng sa liphahlo tse pakiloeng, mohato ona o etsoa ka boiketsetso ke motlatsi.
/// Sena se bolela hore masimo a batho ba pakiloeng ha a oeloe sebakeng.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `to_drop` e tlameha ho ba [valid] bakeng sa ho bala le ho ngola ka bobeli.
///
/// * `to_drop` e tlameha ho hokahana hantle.
///
/// * Boleng ba `to_drop` bo supa hore e tlameha ho ba bo nepahetseng bakeng sa ho lahla, ho ka bolelang hore e tlameha ho ts'ehetsa bahlaseli ba tlatsetso, hona ho latela mofuta.
///
/// Ntle le moo, haeba `T` ha se [`Copy`], ho sebelisa boleng bo supiloeng kamora ho letsetsa `drop_in_place` ho ka baka boits'oaro bo sa hlaloseheng.Hlokomela hore `*to_drop = foo` e nkoa e le ts'ebeliso hobane e tla etsa hore boleng bo theohe hape.
/// [`write()`] e ka sebelisoa ho ngola lintlha ntle le ho e etsa hore e oe.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ka letsoho tlosa ntho ea ho qetela ho vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Fumana sesupi se tala ho karolo ea ho qetela ho `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Khutsufatsa `v` ho thibela hore ntho ea hoqetela e se ke ea liheloa.
///     // Re etsa joalo pele, ho thibela litaba haeba `drop_in_place` e ka tlase ho panics.
///     v.set_len(1);
///     // Ntle le mohala `drop_in_place`, ntho ea hoqetela e ne e ke ke ea lahloa, mme mohopolo oo e o laolang o ne o tla lutloa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Netefatsa hore ntho ea hoqetela e oele.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Hlokomela hore motlatsi o etsa kopi ena ka boiketsetso ha a liha li-struct tse pakiloeng, ke hore, hangata ha ua tlameha ho tšoenyeha ka litaba tse joalo ntle le haeba o letsetsa `drop_in_place` ka letsoho.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Khoutu mona ha e na taba, sena se nkeloa sebaka ke sekhomaretsi sa 'nete ke moqapi.
    //

    // TŠIRELETSO: bona maikutlo a kaholimo
    unsafe { drop_in_place(to_drop) }
}

/// E etsa sesupi se sa sebetseng se sa sebetseng.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// E etsa sesupi se sa fetoheng se sa sebetseng.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Ho kenya letsoho ka letsoho ho qoba ho tlangoa ke `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Ho kenya letsoho ka letsoho ho qoba ho tlangoa ke `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// E etsa selae se tala ho tsoa ho sesupi le bolelele.
///
/// Khang ea `len` ke palo ea **lintho**, eseng palo ea li-byte.
///
/// Mosebetsi ona o bolokehile, empa ha e le hantle ho sebelisa boleng ba ho khutlisa ha ho bolokehe.
/// Bona litokomane tsa [`slice::from_raw_parts`] bakeng sa litlhoko tsa polokeho ea selae.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // theha sesupi sa selae ha u qala ka sesupa ho ntlha ea pele
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // TŠIRELETSO: Ho fihlella boleng ho tsoa ho mokhatlo oa `Repr` ho bolokehile ho tloha ha * const [T]
        //
        // le FatPtr li na le mekhoa e tšoanang ea ho hopola.Ke std feela e ka etsang tiiso ena.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// E etsa ts'ebetso e ts'oanang le [`slice_from_raw_parts`], ntle le hore selae se tala se ka fetohang sea khutlisoa, ho fapana le selae se tala se sa fetoheng.
///
///
/// Bona litokomane tsa [`slice_from_raw_parts`] bakeng sa lintlha tse ling.
///
/// Mosebetsi ona o bolokehile, empa ha e le hantle ho sebelisa boleng ba ho khutlisa ha ho bolokehe.
/// Bona litokomane tsa [`slice::from_raw_parts_mut`] bakeng sa litlhoko tsa polokeho ea selae.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // fana ka boleng ho index ho selae
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // TŠIRELETSO: Ho fihlella boleng ho tsoa ho mokhatlo oa `Repr` ho bolokehile ho tloha ha * mut [T]
        // le FatPtr li na le mekhoa e tšoanang ea ho hopola
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// E fetola boleng libakeng tse peli tse ka feto-fetohang tsa mofuta o le mong, ntle le ho hlakola ebang ke.
///
/// Empa bakeng sa mekhelo e 'meli e latelang, ts'ebetso ena e lekana le [`mem::swap`].
///
///
/// * E sebetsa ho litsupa tse tala ho fapana le litšupiso.
/// Ha litšupiso li fumaneha, [`mem::swap`] e lokela ho khethoa.
///
/// * Litekanyetso tse peli tse supisitsoeng li kanna tsa kopana.
/// Haeba litekanyetso li kopana, sebaka sa memori se tlallanang se tsoang ho `x` se tla sebelisoa.
/// Sena se bontšoa mohlaleng oa bobeli o ka tlase.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * Ka bobeli `x` le `y` e tlameha ho ba [valid] bakeng sa ho bala le ho ngola ka bobeli.
///
/// * Ka bobeli `x` le `y` li tlameha ho hokahanngoa hantle.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, lits'oants'o ha lia lokela ho ba NULL mme li hokahane hantle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ho sesa libaka tse peli tse sa kopaneng:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ena ke `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ena ke `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ho sesa libaka tse peli tse fetang:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ena ke `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ena ke `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Li-indices `1..3` tsa selae se feta pakeng tsa `x` le `y`.
///     // Liphetho tse utloahalang e ka ba bakeng sa bona e ka ba `[2, 3]`, hoo lits'oants'o tsa `0..3` e leng `[1, 2, 3]` (tse tsamaellanang le `y` pele ho `swap`);kapa hore li be `[0, 1]` e le hore li-indices `1..4` li `[0, 1, 2]` (tse tsamaellanang le `x` pele ho `swap`).
/////
///     // Ts'ebetso ena e hlalosoa ho etsa khetho ea morao-rao.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Iphe sebaka sa ho qala ho sebetsa le sona.
    // Ha rea lokela ho tšoenyeha ka marotholi: `MaybeUninit` ha e etse letho ha e lahloa.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Etsa phetoho ka polokeho: moletsi o tlameha ho netefatsa hore `x` le `y` li nepahetse bakeng sa ho ngola le ho hokahana hantle.
    // `tmp` e ke ke ea tlatlapa e ka ba `x` kapa `y` hobane `tmp` e ne e abetsoe feela mokotla e le ntho e arotsoeng ka thoko.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` mme `y` e ka kopana
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// E chencha li-byte tsa `count * size_of::<T>()` lipakeng tsa libaka tse peli tsa memori ho qala ka `x` le `y`.
/// Libaka tsena tse peli ha lia lokela ho kopana.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * Ka bobeli `x` le `y` e tlameha ho ba [valid] bakeng sa ho bala ka bobeli le ho ngola ka `count *
///   size_of: :<T>() `li-byte.
///
/// * Ka bobeli `x` le `y` li tlameha ho hokahanngoa hantle.
///
/// * Sebaka sa memori se qalang ka `x` ka boholo ba `count *
///   size_of: :<T>() `byte ha ea lokela ho * kopana le sebaka sa memori ho qala ka `y` ka boholo bo lekanang.
///
/// Hlokomela hore leha boholo bo kopilitsoe hantle (`count * size_of: :<T>()`) ke `0`, lits'oants'o ha lia lokela ho ba NULL mme li hokahane hantle.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `x` le `y` ke tsona
    // e nepahetse bakeng sa ho ngola le ho hokahana hantle.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Bakeng sa mefuta e menyenyane ho feta ts'ebeliso e tlase ea marang-rang, o ka chencha ka kotloloho ho qoba ho nyahamisa codegen.
    //
    if mem::size_of::<T>() < 32 {
        // POLOKEHO: moletsi o tlameha ho netefatsa hore `x` le `y` li nepahetse
        // bakeng sa ho ngola, e hokahane hantle, ebile e sa kopane.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Mokhoa o sebelisoang mona ke ho sebelisa simd ho chencha x&y ka nepo.
    // Teko e senola hore ho fapanya li-byte tse 32 kapa li-byte tse 64 ka nako e le 'ngoe ho sebetsa hantle haholo ho li-processor tsa Intel Haswell E.
    // LLVM e khona ho ntlafatsa haeba re fana ka #[repr(simd)], leha re sa sebelise sebopeho sena ka kotloloho.
    //
    //
    // FIXME repr(simd) e robehile ho emscripten le redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop ka x&y, u li kopitsa `Block` ka nako Optimizer e lokela ho phetlolla lupu ka botlalo bakeng sa mefuta e mengata ea NB
    // Re ka se sebelise foropo ha `range` impl e letsetsa `mem::swap` khafetsa
    //
    let mut i = 0;
    while i + block_size <= len {
        // Theha mohopolo o sa qalisoang joalo ka sebaka sa ho qala Ho phatlalatsa `t` mona e qoba ho hokahanya mothapo ha leqhubu lena le sa sebelisoe
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // TSHIRELETSO: Jwalo ka `i < len`, mme ha moletsi a lokela ho netefatsa hore `x` le `y` di nepahetse
        // bakeng sa `len` byte, `x + i` le `y + i` e tlameha ho ba liaterese tse nepahetseng, tse phethahatsang konteraka ea polokeho ea `add`.
        //
        // Hape, moletsi o tlameha ho netefatsa hore `x` le `y` li nepahetse bakeng sa ho ngola, ho hokahana hantle, le ho se kopane, ho phethahatsang konteraka ea polokeho ea `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Fetolela li-byte tsa x&y, u sebelisa t e le sesupa-nako sa nakoana Sena se lokela ho ntlafatsoa hore se sebetse hantle ho SIMD moo se fumanehang
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Fetola li-byte tse setseng
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // TŠIRELETSO: bona maikutlo a nakong e fetileng a polokeho.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// E tsamaisa `src` ho `dst` e supileng, e khutlisa boleng ba `dst` bo fetileng.
///
/// Ha ho boleng bo theotsoeng.
///
/// Mosebetsi ona o lekana le [`mem::replace`] ntle le hore o sebetsa litsing tse tala ho fapana le litšupiso.
/// Ha litšupiso li fumaneha, [`mem::replace`] e lokela ho khethoa.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho bala le ho ngola ka bobeli.
///
/// * `dst` e tlameha ho hokahana hantle.
///
/// * `dst` E tlameha ho supa boleng bo qaliloeng hantle ba mofuta `T`.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` e tla ba le phello e ts'oanang ntle le ho hloka boloko bo sa bolokehang.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `dst` e nepahetse ho ba
    // lahlela tšupisong e ka feto-fetohang (e nepahetse bakeng sa ho ngola, ho hokahanya, ho qalisoa), 'me e ke ke ea feta `src` ho tloha ha `dst` e tlameha ho supa ntho e arotsoeng ka thoko.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // e ke ke ea kopana
    }
    src
}

/// E bala boleng ho tsoa ho `src` ntle le ho e tsamaisa.Sena se siea memori ho `src` e sa fetohe.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `src` e tlameha ho ba [valid] bakeng sa ho baloa.
///
/// * `src` e tlameha ho hokahana hantle.Sebelisa [`read_unaligned`] haeba ho se joalo.
///
/// * `src` E tlameha ho supa boleng bo qaliloeng hantle ba mofuta `T`.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kenya letsoho [`mem::swap`] ka letsoho:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Theha mofuta oa boleng bo tlase ho `a` ho `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ho tsoa ntlheng ena (ekaba ka ho khutla ka mokhoa o hlakileng kapa ka ho letsetsa tšebetso eo panics) e ka etsang hore boleng ba `tmp` bo theohe ha boleng bo tšoanang bo ntse bo hlalosoa ke `a`.
///         // Sena se ka baka boits'oaro bo sa hlalosoang haeba `T` ha se `Copy`.
/////
/////
///
///         // Theha mofuta oa boleng bo tlase ho `b` ho `a`.
///         // Sena se bolokehile hobane litšupiso tse ka feto-fetohang ha li na mabitso.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Joalokaha ho boletsoe kaholimo, ho tsoa mona ho ka baka boits'oaro bo sa hlalosoang hobane boleng bo tšoanang bo supiloe ke `a` le `b`.
/////
///
///         // Tlosa `tmp` ho `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` e fallisitsoe (`write` e nka beng ba eona ngangisano ea eona ea bobeli), ka hona ha ho letho le oeloang mona ka botlalo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Botho ba Boleng bo Khutlisitsoeng
///
/// `read` e etsa kopi e sa reng letho ea `T`, ho sa tsotelehe `T` ke [`Copy`].
/// Haeba `T` ha se [`Copy`], ho sebelisa boleng bo khutlisitsoeng le boleng ba `*src` ho ka tlola polokeho ea memori.
/// Hlokomela hore ho abela lipalo tsa `*src` e le ts'ebeliso hobane e tla leka ho theola boleng ho `* src`.
///
/// [`write()`] e ka sebelisoa ho ngola lintlha ntle le ho e etsa hore e oe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` joale e supa mohopolong o ts'oanang le `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ho abeloa `s2` ho baka hore boleng ba eona ba mantlha bo theohe.
///     // Ntle le ntlha ena, `s` ha e sa lokela ho sebelisoa, hobane mohopolo oa mantlha o lokollotsoe.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ho abela `s` ho ka etsa hore boleng ba khale bo theoleloe hape, ho hlahise boits'oaro bo sa hlalosoang.
/////
///     // s= String::from("bar");//PHOSO
///
///     // `ptr::write` e ka sebelisoa ho ngola boleng ntle le ho e lahla.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `src` e nepahetse bakeng sa ho baloa.
    // `src` e ke ke ea feta `tmp` hobane `tmp` e ne e abetsoe feela mokoting e le ntho e arotsoeng ka thoko.
    //
    //
    // Hape, kaha re sa tsoa ngola boleng bo nepahetseng ho `tmp`, ho netefalitsoe hore e tla qalisoa hantle.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// E bala boleng ho tsoa ho `src` ntle le ho e tsamaisa.Sena se siea memori ho `src` e sa fetohe.
///
/// Ho fapana le [`read`], `read_unaligned` e sebetsa ka litsupa tse sa lumellaneng.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `src` e tlameha ho ba [valid] bakeng sa ho baloa.
///
/// * `src` E tlameha ho supa boleng bo qaliloeng hantle ba mofuta `T`.
///
/// Joalo ka [`read`], `read_unaligned` e etsa kopi ea `T` hanyane hanyane, ho sa tsotelehe `T` ke [`Copy`].
/// Haeba `T` ha se [`Copy`], ho sebelisa boleng bo khutlisitsoeng le boleng ba `*src` bo ka ba [violate memory safety][read-ownership].
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-tsela e tlameha ebe ha se NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ka `packed` e ntse e itsamaela
///
/// Hajoale ho ke ke ha khoneha ho theha lits'oants'o tse tala masimong a sa lumellaneng a sebopeho se pakiloeng.
///
/// Ho leka ho theha sesupisi se tala sebakeng sa `unaligned` se nang le polelo e kang `&packed.unaligned as *const FieldType` ho theha tšupiso e sa lumellaneng pele e fetoloa ho pointer e tala.
///
/// Hore tšupiso ena ke ea nakoana 'me hang ha e etsoa ha e na thuso kaha moqapi o lula a lebelletse hore litšupiso li hokahane hantle.
/// Ka lebaka leo, ho sebelisa `&packed.unaligned as *const FieldType` ho baka boits'oaro bo sa hlakileng* lenaneong la hau.
///
/// Mohlala oa seo u sa lokelang ho se etsa le hore na sena se amana joang le `read_unaligned` ke:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Mona re leka ho nka aterese ea 32-bit integer e sa tsamaellanang.
///     let unaligned =
///         // Tšupiso ea nakoana e sa ngolisoang e thehiloe mona e hlahisang boits'oaro bo sa hlalosoang ho sa tsotelehe hore na litšupiso li sebelisitsoe kapa che.
/////
///         &packed.unaligned
///         // Ho lahlela pointer e tala ha ho thuse letho;phoso e se e etsahetse.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ho fihlella masimo a sa lumellaneng ka kotloloho le mohlala, `packed.unaligned` ho bolokehile.
///
///
///
///
///
///
// FIXME: Ntlafatsa li-doc ho ipapisitse le RFC #2582 le metsoalle.
/// # Examples
///
/// Bala boleng ba usize ho tsoa ho buffer ea byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `src` e nepahetse bakeng sa ho baloa.
    // `src` e ke ke ea feta `tmp` hobane `tmp` e ne e abetsoe feela mokoting e le ntho e arotsoeng ka thoko.
    //
    //
    // Hape, kaha re sa tsoa ngola boleng bo nepahetseng ho `tmp`, ho netefalitsoe hore e tla qalisoa hantle.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// E ngola sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
///
/// `write` ha e lahle litaba tsa `dst`.
/// Sena se bolokehile, empa se ka lutla likabo kapa lisebelisoa, ka hona, tlhokomelo e lokela ho nkuoa hore e se ke ea ngola holim'a ntho e lokelang ho liheloa.
///
///
/// Ntle le moo, ha e tlohele `src`.Ka mokhoa o ts'oanang, `src` e isoa sebakeng se supiloeng ke `dst`.
///
/// Sena se loketse ho qala mohopolo o sa ngolisoang, kapa ho ngola mohopolo o neng o le [`read`] ho tloha pele.
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola.
///
/// * `dst` e tlameha ho hokahana hantle.Sebelisa [`write_unaligned`] haeba ho se joalo.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Kenya letsoho [`mem::swap`] ka letsoho:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Theha mofuta oa boleng bo tlase ho `a` ho `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ho tsoa ntlheng ena (ekaba ka ho khutla ka mokhoa o hlakileng kapa ka ho letsetsa tšebetso eo panics) e ka etsang hore boleng ba `tmp` bo theohe ha boleng bo tšoanang bo ntse bo hlalosoa ke `a`.
///         // Sena se ka baka boits'oaro bo sa hlalosoang haeba `T` ha se `Copy`.
/////
/////
///
///         // Theha mofuta oa boleng bo tlase ho `b` ho `a`.
///         // Sena se bolokehile hobane litšupiso tse ka feto-fetohang ha li na mabitso.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Joalokaha ho boletsoe kaholimo, ho tsoa mona ho ka baka boits'oaro bo sa hlalosoang hobane boleng bo tšoanang bo supiloe ke `a` le `b`.
/////
///
///         // Tlosa `tmp` ho `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` e fallisitsoe (`write` e nka beng ba eona ngangisano ea eona ea bobeli), ka hona ha ho letho le oeloang mona ka botlalo.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Re letsetsa li-intrinsics ka kotloloho ho qoba mehala ea ts'ebetso ka khoutu e hlahisitsoeng kaha `intrinsics::copy_nonoverlapping` ke mosebetsi o koahelang.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `dst` e nepahetse bakeng sa ho ngola.
    // `dst` e ke ke ea kopana le `src` hobane moletsi o na le phihlello e ka fetohang ho `dst` ha `src` e le ea mosebetsi ona.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// E ngola sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
///
/// Ho fapana le [`write()`], sesupa-tsela se kanna sa se lumellane.
///
/// `write_unaligned` ha e lahle litaba tsa `dst`.Sena se bolokehile, empa se ka lutla likabo kapa lisebelisoa, ka hona, tlhokomelo e lokela ho nkuoa hore e se ke ea ngola holim'a ntho e lokelang ho liheloa.
///
/// Ntle le moo, ha e tlohele `src`.Ka mokhoa o ts'oanang, `src` e isoa sebakeng se supiloeng ke `dst`.
///
/// Sena se loketse ho qala mohopolo o sa ngolisoang, kapa ho ngola mohopolo o neng o kile oa baloa le [`read_unaligned`].
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-tsela e tlameha ebe ha se NULL.
///
/// [valid]: self#safety
///
/// ## Ka `packed` e ntse e itsamaela
///
/// Hajoale ho ke ke ha khoneha ho theha lits'oants'o tse tala masimong a sa lumellaneng a sebopeho se pakiloeng.
///
/// Ho leka ho theha sesupisi se tala sebakeng sa `unaligned` se nang le polelo e kang `&packed.unaligned as *const FieldType` ho theha tšupiso e sa lumellaneng pele e fetoloa ho pointer e tala.
///
/// Hore tšupiso ena ke ea nakoana 'me hang ha e etsoa ha e na thuso kaha moqapi o lula a lebelletse hore litšupiso li hokahane hantle.
/// Ka lebaka leo, ho sebelisa `&packed.unaligned as *const FieldType` ho baka boits'oaro bo sa hlakileng* lenaneong la hau.
///
/// Mohlala oa seo u sa lokelang ho se etsa le hore na sena se amana joang le `write_unaligned` ke:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Mona re leka ho nka aterese ea 32-bit integer e sa tsamaellanang.
///     let unaligned =
///         // Tšupiso ea nakoana e sa ngolisoang e thehiloe mona e hlahisang boits'oaro bo sa hlalosoang ho sa tsotelehe hore na litšupiso li sebelisitsoe kapa che.
/////
///         &mut packed.unaligned
///         // Ho lahlela pointer e tala ha ho thuse letho;phoso e se e etsahetse.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ho fihlella masimo a sa lumellaneng ka kotloloho le mohlala, `packed.unaligned` ho bolokehile.
///
///
///
///
///
///
///
///
///
// FIXME: Ntlafatsa li-doc ho ipapisitse le RFC #2582 le metsoalle.
/// # Examples
///
/// Ngola boleng ba usize ho buffer ea byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `dst` e nepahetse bakeng sa ho ngola.
    // `dst` e ke ke ea kopana le `src` hobane moletsi o na le phihlello e ka fetohang ho `dst` ha `src` e le ea mosebetsi ona.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Re letsetsa ea tlhaho ka kotloloho ho qoba lits'ebetso tsa khoutu e hlahisitsoeng.
        intrinsics::forget(src);
    }
}

/// E bala boleng bo sa tloaelehang ba `src` ntle le ho e tsamaisa.Sena se siea memori ho `src` e sa fetohe.
///
/// Ts'ebetso e feto-fetohang e etselitsoe ho sebetsa mohopolong oa I/O, 'me e netefalitsoe hore e ke ke ea qhekelloa kapa ea hlophisoa bocha ke mokopanyi mesebetsing e meng e mebe.
///
/// # Notes
///
/// Rust hajoale ha e na mofuta oa memori o hlakileng le o hlophisitsoeng hantle, ka hona semantics e nepahetseng ea seo "volatile" e se bolelang mona e ka fetoha ha nako e ntse e tsamaea.
/// Ha ho buuoa joalo, semantics e tla lula e tšoana hantle le [C11's definition of volatile][c11].
///
/// Moqapi ha a lokela ho fetola tatellano e lekanyelitsoeng kapa palo ea ts'ebetso ea memori e sa fetoheng.
/// Leha ho le joalo, ts'ebetso e sa fetoheng ea mohopolo mefuteng ea boholo ba zero (mohlala, haeba mofuta o boholo ba zero o fetiselitsoe ho `read_volatile`) ke li-noops mme li kanna tsa hlokomolohuoa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `src` e tlameha ho ba [valid] bakeng sa ho baloa.
///
/// * `src` e tlameha ho hokahana hantle.
///
/// * `src` E tlameha ho supa boleng bo qaliloeng hantle ba mofuta `T`.
///
/// Joalo ka [`read`], `read_volatile` e etsa kopi ea `T` hanyane hanyane, ho sa tsotelehe `T` ke [`Copy`].
/// Haeba `T` ha se [`Copy`], ho sebelisa boleng bo khutlisitsoeng le boleng ba `*src` bo ka ba [violate memory safety][read-ownership].
/// Leha ho le joalo, ho boloka mefuta eo e seng ea [`Copy`] mohopolong o sa tsitsang ho hlile ho fosahetse.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Joalo ka C, hore na ts'ebetso e fetoha ka mokhoa o sa tsitsang ha e na taba le letho lipotsong tse amanang le phihlello ea nako e le ngoe ho tsoa likhoeleng tse ngata.Ho fihlella ka bongata ho itšoara hantle joalo ka phihlello eo eseng ea athomo ntlheng eo.
///
/// Haholo-holo, peiso lipakeng tsa `read_volatile` le ts'ebetso efe kapa efe ea ho ngola sebakeng se le seng ke boits'oaro bo sa hlalosoang.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ha re tšohe ho boloka tšusumetso ea codegen e nyane.
        abort();
    }
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// E ngola mongolo o sa tsitsang oa sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
///
/// Ts'ebetso e feto-fetohang e etselitsoe ho sebetsa mohopolong oa I/O, 'me e netefalitsoe hore e ke ke ea qhekelloa kapa ea hlophisoa bocha ke mokopanyi mesebetsing e meng e mebe.
///
/// `write_volatile` ha e lahle litaba tsa `dst`.Sena se bolokehile, empa se ka lutla likabo kapa lisebelisoa, ka hona, tlhokomelo e lokela ho nkuoa hore e se ke ea ngola holim'a ntho e lokelang ho liheloa.
///
/// Ntle le moo, ha e tlohele `src`.Ka mokhoa o ts'oanang, `src` e isoa sebakeng se supiloeng ke `dst`.
///
/// # Notes
///
/// Rust hajoale ha e na mofuta oa memori o hlakileng le o hlophisitsoeng hantle, ka hona semantics e nepahetseng ea seo "volatile" e se bolelang mona e ka fetoha ha nako e ntse e tsamaea.
/// Ha ho buuoa joalo, semantics e tla lula e tšoana hantle le [C11's definition of volatile][c11].
///
/// Moqapi ha a lokela ho fetola tatellano e lekanyelitsoeng kapa palo ea ts'ebetso ea memori e sa fetoheng.
/// Leha ho le joalo, ts'ebetso e sa fetoheng ea mohopolo mefuteng ea boholo ba zero (mohlala, haeba mofuta o boholo ba zero o fetiselitsoe ho `write_volatile`) ke li-noops mme li kanna tsa hlokomolohuoa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Boitšoaro ha bo hlalosehe haeba ho tloloa efe kapa efe ea maemo a latelang:
///
/// * `dst` e tlameha ho ba [valid] bakeng sa ho ngola.
///
/// * `dst` e tlameha ho hokahana hantle.
///
/// Hlokomela hore le haeba `T` e na le boholo ba `0`, sesupa-hlooho se tlameha ho se se NULL le ho hokahana hantle.
///
/// [valid]: self#safety
///
/// Joalo ka C, hore na ts'ebetso e fetoha ka mokhoa o sa tsitsang ha e na taba le letho lipotsong tse amanang le phihlello ea nako e le ngoe ho tsoa likhoeleng tse ngata.Ho fihlella ka bongata ho itšoara hantle joalo ka phihlello eo eseng ea athomo ntlheng eo.
///
/// Ka ho khetheha, peiso lipakeng tsa `write_volatile` le ts'ebetso efe kapa efe (ho bala kapa ho ngola) sebakeng se le seng ke boits'oaro bo sa hlalosoang.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ha re tšohe ho boloka tšusumetso ea codegen e nyane.
        abort();
    }
    // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Lumella sesupa `p`.
///
/// Sebetsa palo ea offset (ho latela likarolo tsa mohato oa `stride`) o lokelang ho sebelisoa ho supa pointer `p` hore sesupa `p` se lumellane le `a`.
///
/// Note: Ts'ebetso ena e hlophiselitsoe ka hloko hore e se panic.Ke UB bakeng sa sena ho panic.
/// Phetoho feela ea 'nete e ka etsoang mona ke phetoho ea `INV_TABLE_MOD_16` le li-constants tse amanang.
///
/// Haeba re ka nka qeto ea ho etsa hore ho khonehe ho letsetsa ntho ea mantlha ka `a` eo e seng matla a mabeli, ho ka ba bohlale hore re fetohele ts'ebetsong e se nang tsebo ho fapana le ho leka ho e fetola hore e lumellane le phetoho eo.
///
///
/// Lipotso life kapa life li ea ho@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ts'ebeliso e tobileng ea li-intrinsics tsena e ntlafatsa codegen haholo boemong ba khetho <=
    // 1, moo mefuta ea lits'ebetso tsena e sa ngolisoang.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Sebelisa palo e fapaneng ea modular inverse ea `x` modulo `m`.
    ///
    /// Ts'ebetso ena e etselitsoe `align_offset` mme e na le maemo a latelang:
    ///
    /// * `m` ke matla a mabeli;
    /// * `x < m`; (haeba `x ≥ m`, fetisa `x % m` ho fapana)
    ///
    /// Ts'ebetsong ea ts'ebetso ena e ke ke ea panic.Kamehla.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse tafole modulo 2⁴=16.
        ///
        /// Hlokomela, hore tafole ena ha e na boleng moo ho fapakaneng ho seng teng (ke hore, bakeng sa `0⁻¹ mod 16`, `2⁻¹ mod 16`, jj.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo eo `INV_TABLE_MOD_16` e reretsoeng eona.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // TSHIRELETSO: `m` e hlokeha ho ba matla a mabedi, ka hona e seng zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Re lekanyetsa "up" re sebelisa foromo e latelang:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // ho fihlela 2²ⁿ ≥ m.Ebe joale re ka fokotsa ho ea ho `m` eo re e batlang ka ho nka sephetho sa `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) modimo n
                //
                // Hlokomela hore re sebelisa ho phuthela mona ka boomo-foromo ea mantlha e sebelisa mohlala, ho tlosa `mod n`.
                // Ho lokile ka ho felletseng ho li etsa `mod usize::MAX` ho fapana, hobane re nka sephetho sa `mod n` qetellong leha ho le joalo.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // TSHIRELETSO: `a` ke matla a mabedi, ka hona ha se zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Nyeoe e ka balelloa habonolo feela ka `-p (mod a)`, empa ho etsa joalo ho thibela bokhoni ba LLVM ba ho khetha litaelo tse kang `lea`.Sebakeng seo rea bala
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // e fanang ka ts'ebetso ho potoloha le mojaro, empa e nyahamisa `and` ka ho lekana hore LLVM e tsebe ho sebelisa likhakanyo tse fapaneng tseo e li tsebang.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // E se e hokahane.Shatee!
        return 0;
    } else if stride == 0 {
        // Haeba sesupa ha sea tsamaellana hantle, 'me ntlha e boholo ba zero, ka hona ha ho na likarolo tsa likarolo tse tla lumellanya sesupa.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // TSHIRELETSO: a ke matla a mabedi ka hona ha se zero.stride==0 nyeoe e sebetsoa kaholimo.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // TŠIRELETSO: gcdpow e na le litlamo tse holimo e leng palo ea likotoana tse ngata tsa usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // TŠIRELETSO: gcd e lula e le kholo kapa e lekana le 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch ena e rarolla sekhahla se latelang sa likopano:
        //
        // ` p + so = 0 mod a `
        //
        // `p` Mona ke boleng ba pointer, `s`, stride ea `T`, `o` e kentsoeng ho `T`s, le `a`, tatellano e kopiloeng.
        //
        // Ka `g = gcd(a, s)`, mme boemo bo boletsoeng kaholimo bo tiisa hore `p` le eona e ka aroloa ke `g`, re ka supa `a' = a/g`, `s' = s/g`, `p' = p/g`, joale sena se lekana le:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Kotara ea pele ke "the relative alignment of `p` to `a`" (e arotsoe ke `g`), kotara ea bobeli ke "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (hape e arotsoe ke `g`).
        //
        // Karohano ka `g` ea hlokahala ho etsa hore inverse e thehe hantle haeba `a` le `s` li sa sebelisane hantle.
        //
        // Ho feta moo, sephetho se hlahisitsoeng ke tharollo ena ha se "minimal", ka hona ho hlokahala hore u nke sephetho sa `o mod lcm(s, a)`.Re ka nka sebaka sa `lcm(s, a)` ka `a'` feela.
        //
        //
        //
        //
        //

        // TŠIRELETSO: `gcdpow` e na le litlamo tse holimo tse seng kholo ho feta palo ea lits'oants'o tse 0 ho `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // TSHIRELETSO: `a2` ha se zero.Ho suthisa `a` ka `gcdpow` ho sitoa ho suthisa likotoana tse behiloeng
        // ka `a` (eo e nang le eona hantle).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // TŠIRELETSO: `gcdpow` e na le litlamo tse holimo tse seng kholo ho feta palo ea lits'oants'o tse 0 ho `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // TŠIRELETSO: `gcdpow` e na le litlamo tse holimo eseng e kholo ho feta palo ea litsupa tse 0 tse kenang
        // `a`.
        // Ho feta moo, ho tlosa ho ke ke ha phalla, hobane `a2 = a >> gcdpow` e tla lula e le kholo ho `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // POLOKEHO: `a2` ke matla a mabeli, joalo ka ha ho netefalitsoe kaholimo.`s2` e tlase ka tlase ho `a2`
        // hobane `(s % a) >> gcdpow` e hlile e ka tlase ho `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ha e khone ho hokahana ho hang.
    usize::MAX
}

/// E bapisa litsupa tse tala tsa tekano.
///
/// Sena se ts'oana le ho sebelisa `==` opareitara, empa ha e na generic:
/// mabaka a tlameha ho ba lits'oants'o tse tala tsa `*const T`, eseng eng kapa eng e sebelisang `PartialEq`.
///
/// Sena se ka sebelisoa ho bapisa litšupiso tsa `&T` (tse qobellang ho `*const T` ka botlalo) ka aterese ea bona ho fapana le ho bapisa litekanyetso tseo ba li supang (ke seo ts'ebetsong ea `PartialEq for &T` e se etsang).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Likarolo li boetse li bapisoa le bolelele ba tsona (litšupiso tsa mafura):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits le tsona li bapisoa le ts'ebetsong ea tsona:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Litšupiso li na le liaterese tse lekanang.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Lintho li na le liaterese tse lekanang, empa `Trait` e na le ts'ebetsong e fapaneng.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ho fetola litšupiso ho `*const u8` ho bapisoa le aterese.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash a sesupi e tala.
///
/// Sena se ka sebelisoa ho fana ka tšupiso ea `&T` (e qobellang `*const T` ka botlalo) ka aterese ea eona ho fapana le boleng boo e bo supang (ke seo ts'ebetsong ea `Hash for &T` e se etsang).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls bakeng sa litsupa tsa ts'ebetso
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Sebopeho sa mahareng ha se sebelisoa se hlokahala bakeng sa AVR
                // e le hore sebaka sa aterese sa mohloli oa tšebetso ea mohloli se bolokiloe ho pointer ea ho qetela ea mosebetsi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Sebopeho sa mahareng ha se sebelisoa se hlokahala bakeng sa AVR
                // e le hore sebaka sa aterese sa mohloli oa tšebetso ea mohloli se bolokiloe ho pointer ea ho qetela ea mosebetsi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ha ho na mesebetsi e fapaneng ka mekhahlelo e 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Theha sesepa se tala sa `const` sebakeng se seng ntle le ho etsa sets'oants'o sa lipakeng.
///
/// Ho theha sets'oants'o le `&`/`&mut` ho lumelloa feela haeba sesupa se hokahane hantle 'me se supa lintlha tse qalileng.
/// Bakeng sa maemo ao litlhokahalo li sa tšoareng, litsupa tse tala li lokela ho sebelisoa ho fapana.
/// Le ha ho le joalo, `&expr as *const _` e etsa sets'oants'o pele e e lahlela sesupising se sa hlahisoang, 'me ts'upiso eo e tlas'a melao e ts'oanang le litšupiso tse ling tsohle.
///
/// Macro ena e ka theha sesupa se tala ntle le ho theha sets'oants'o pele.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` e ka theha tšupiso e sa lumellaneng, ka hona ea ba undefined boits'oaro!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Theha sesepa se tala sa `mut` sebakeng se seng ntle le ho etsa sets'oants'o sa lipakeng.
///
/// Ho theha sets'oants'o le `&`/`&mut` ho lumelloa feela haeba sesupa se hokahane hantle 'me se supa lintlha tse qalileng.
/// Bakeng sa maemo ao litlhokahalo li sa tšoareng, litsupa tse tala li lokela ho sebelisoa ho fapana.
/// Le ha ho le joalo, `&mut expr as *mut _` e etsa sets'oants'o pele e e lahlela sesupising se sa hlahisoang, 'me ts'upiso eo e tlas'a melao e ts'oanang le litšupiso tse ling tsohle.
///
/// Macro ena e ka theha sesupa se tala ntle le ho theha sets'oants'o pele.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` e ka theha tšupiso e sa lumellaneng, ka hona ea ba undefined boits'oaro!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` E qobella ho kopitsa tšimo ho fapana le ho theha tšupiso.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}