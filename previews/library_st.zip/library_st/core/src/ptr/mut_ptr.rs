use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// E khutlisa `true` haeba pointer e sa sebetse.
    ///
    /// Hlokomela hore mefuta e sa lekanngoang e na le lits'oants'o tse ngata tsa lefeela, hobane ke sesupa-data se tala feela se nkuoang, eseng bolelele ba sona, vtable jj.
    /// Ka hona, litsupa tse peli tse sa sebetseng li kanna tsa se bapise tse lekanang.
    ///
    /// ## Boitšoaro nakong ea tlhahlobo ea const
    ///
    /// Ha ts'ebetso ena e sebelisoa nakong ea tlhahlobo ea const, e kanna ea khutlisa `false` bakeng sa litsupa tse tla fetoha tse sa sebetseng ka nako ea ho matha.
    /// Ka ho khetheha, ha sesupa sa mohopolo o itseng se koaloa ka n beyond'ane ho meeli ea sona ka tsela eo sesupa sephetho se sa sebetseng, mosebetsi o ntse o tla khutlisa `false`.
    ///
    /// Ha ho na mokhoa oa hore CTFE e tsebe boemo bo phethahetseng ba memori eo, ka hona re ke ke ra tseba hore na sesupi ha se na thuso kapa che.
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bapisa ka samente ho sesupa se tšesaane, kahoo litsupa tse mafura li ntse li nahana ka karolo ea tsona ea "data" bakeng sa null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// E kenya sesupisi sa mofuta o mong.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Senya sesupa (mohlomong ka bophara) sa aterese le likarolo tsa metadata.
    ///
    /// Pointer e ka ntlafatsoa hamorao ka [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// E khutlisa `None` haeba pointer e sa sebetse, kapa ho seng joalo e khutlisetsa litšupiso tse arolelanoeng tsa boleng bo phuthetsoeng ka `Some`.Haeba boleng bo ka se qaloe, [`as_uninit_ref`] e tlameha ho sebelisoa ho fapana.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * Sesupi se tlameha ho supa mohlala o qalileng oa `T`.
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    /// (Karolo e mabapi le ho qalisoa ha e so etse qeto e felletseng, empa ho fihlela e le teng, mokhoa o le mong feela o bolokehileng ke ho netefatsa hore ehlile lia qalisoa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Mofuta o sa hlahlojoeng o sa sebetseng
    ///
    /// Haeba u na le bonnete ba hore sesupi ha se na ho ba lefeela 'me u batla mofuta o itseng oa `as_ref_unchecked` o khutlisetsang `&T` sebakeng sa `Option<&T>`, tseba hore o ka sheba sesupa-tsela ka kotloloho.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e nepahetse bakeng sa a
        // supa haeba e sa sebetse.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// E khutlisa `None` haeba sesupa ha se na thuso, kapa ho seng joalo e khutlisetsa ts'upiso e arolelanoeng ea boleng bo phuthetsoeng ka `Some`.
    /// Ho fapana le [`as_ref`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// E sebetsa ka palo ho tloha sesupa-tsela.
    ///
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Haeba efe kapa efe ea maemo a latelang a tloloa, sephetho ke Boitšoaro bo sa Rutehang:
    ///
    /// * Sesupa sa ho qala le se hlahisang se tlameha ho ba ka har'a meeli kapa e le ngoe ea li-byte tse fetileng qetellong ea ntho e abuoeng.
    /// Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// * Computed offset,**in bytes**, e ke ke ea phallela `isize`.
    ///
    /// * Phokotso ea ho ba moeling e ke ke ea itšetleha ka "wrapping around" sebaka sa aterese.Ka mantsoe a mang, kakaretso e sa feleng ea ho nepahala,**ka li-byte** e tlameha ho lekana ka boholo.
    ///
    /// Moqapi le laeborari e tloaelehileng ka kakaretso e leka ho netefatsa hore likabo ha li fihle boholo ba moo ho nang le bothata bo amehang.
    /// Mohlala, `Vec` le `Box` ba netefatsa hore ha ho mohla ba fanang ka li-byte tse fetang `isize::MAX`, kahoo `vec.as_ptr().add(vec.len())` e lula e bolokehile.
    ///
    /// Boholo ba lipolanete ha bo khone ho aha kabo e joalo.
    /// Mohlala, ha ho sethala sa 64-bit se tsejoang se ka kopang kopo ea li-byte tse 2 <sup>63</sup> ka lebaka la meeli ea tafole ea maqephe kapa ho arola sebaka sa aterese.
    /// Leha ho le joalo, liforomo tse ling tsa 32-bit le 16-bit li ka sebetsa ka katleho kopo ea li-byte tse fetang `isize::MAX` tse nang le lintho tse kang Physical Address Extension.
    ///
    /// Kahoo, memori e fumanoeng ka kotloloho ho baabi kapa lifaele tsa 'mapa oa memori * e kanna ea ba kholo haholo hore e ka sebetsoa ka ts'ebetso ena.
    ///
    /// Nahana ka ho sebelisa [`wrapping_offset`] ho fapana haeba mathata ana a le thata ho a khotsofatsa.
    /// Monyetla o le mong feela oa mokhoa ona ke hore o nolofalletsa likhakanyo tse ngata tse mabifi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `offset`.
        // Pointer e fumanoeng e nepahetse bakeng sa ho ngola ho tloha ha moletsi a tlameha ho netefatsa hore e supa ntho e abetsoeng e tšoanang le `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// E sebetsa ka palo ho tloha sesupa ka ho sebelisa arithmetic ea ho phuthela.
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ka boeona e lula e bolokehile, empa ho sebelisa sesupa-tsela se hlahang ha ho joalo.
    ///
    /// Sesupa se hlahisoang se lula se hokelletsoe ho ntho e le 'ngoe e abiloeng eo `self` e e supang.
    /// E kanna ea se sebelisoe ho fihlella ntho e fanoeng e fapaneng.Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// Ka mantsoe a mang, `let z = x.wrapping_offset((y as isize) - (x as isize))` ha e etse hore `z` e tšoane le `y` leha re nahana hore `T` e na le boholo ba `1` mme ha ho na phallo e fetang: `z` e ntse e khomaretse ntho `x` e hoketsoeng ho eona, 'me ho e hlakola ke Boitšoaro bo sa hlalosoang ntle le `x` le `y` e supa ntho e tšoanang e abetsoeng.
    ///
    /// Ha e bapisoa le [`offset`], mokhoa ona o liehisa tlhoko ea ho lula ka har'a ntho e tšoanang eo o e abetsoeng: [`offset`] ke boits'oaro bo sa lekanyetsoang ha o tšela meeli ea lintho;`wrapping_offset` e hlahisa sesupi empa e ntse e lebisa ho Boitšoaro bo sa Rutehang haeba sesupa se sa hlalosoe ha se le moeling oa ntho eo e hoketsoeng ho eona.
    /// [`offset`] e ka ntlafatsoa hantle 'me ka hona ea rateha ho khoutu e sa sebetseng.
    ///
    /// Cheke e liehang e nka feela boleng ba sesupa se ileng sa hlakisoa, eseng litekanyetso tsa mahareng tse sebelisitsoeng nakong ea palo ea sephetho sa hoqetela.
    /// Mohlala, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` e lula e tšoana le `x`.Ka mantsoe a mang, ho siea ntho eo re e abetsoeng ebe re e kenya hape hamorao ho a lumelloa.
    ///
    /// Haeba o hloka ho tšela meeli ea ntho, lahlela sesupa ho palo e kholo ebe o etsa lipalo moo.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // Iterate o sebelisa sesupa se tala ka keketseho ea likarolo tse peli
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // TSHIRELETSO: `arith_offset` ea mantlha ha e na lintho tse hlokahalang hore li ka bitsoa.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// E khutlisa `None` haeba sesupa ha se na thuso, kapa ho seng joalo e khutlisa tšupiso e ikhethang ho boleng bo phuthetsoeng ka `Some`.Haeba boleng bo ka se qaloe, [`as_uninit_mut`] e tlameha ho sebelisoa ho fapana.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * Sesupi se tlameha ho supa mohlala o qalileng oa `T`.
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    /// (Karolo e mabapi le ho qalisoa ha e so etse qeto e felletseng, empa ho fihlela e le teng, mokhoa o le mong feela o bolokehileng ke ho netefatsa hore ehlile lia qalisoa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // E tla hatisa: "[4, 2, 3]".
    /// ```
    ///
    /// # Mofuta o sa hlahlojoeng o sa sebetseng
    ///
    /// Haeba u na le bonnete ba hore sesupi ha se na ho ba lefeela 'me u batla mofuta o itseng oa `as_mut_unchecked` o khutlisetsang `&mut T` sebakeng sa `Option<&mut T>`, tseba hore u ka sheba sesupa ka kotloloho.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // E tla hatisa: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e nepahetse bakeng sa
        // se ka fetoloang haeba se sa sebetse.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// E khutlisa `None` haeba sesupa ha se na thuso, kapa ho seng joalo e khutlisa tšupiso e ikhethang ho boleng bo phuthetsoeng ka `Some`.
    /// Ho fapana le [`as_mut`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// E khutlisa hore na lits'oants'o tse peli li netefalitsoe hore li lekana.
    ///
    /// Nakong ea ho matha mosebetsi ona o itšoara joaloka `self == other`.
    /// Leha ho le joalo, maemong a mang (mohlala, tlhahlobo ea nako ea ho bokella), ha se kamehla ho ka khonehang ho fumana tekano ea litsupa tse peli, ka hona ts'ebetso ena e ka khutlisa `false` ka mokhoa o makatsang bakeng sa litlhahiso tseo hamorao li tla lekana.
    ///
    /// Empa ha e khutlisa `true`, litsupa li netefalitsoe hore li tla lekana.
    ///
    /// Mosebetsi ona ke seipone sa [`guaranteed_ne`], empa eseng se khelohileng.Ho na le papiso ea sesupi eo mesebetsi ka bobeli e khutlisetsang `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Boleng ba ho khutla bo ka fetoha ho latela mofuta oa sekhomphutha mme khoutu e sa bolokehang e kanna ea se itšetlehe ka sephetho sa ts'ebetso ena bakeng sa ho hlaka.
    /// Ho khothalletsoa hore ho sebelisoe ts'ebetso ena feela bakeng sa ho ntlafatsa ts'ebetso ea ts'ebetso moo boleng ba ho khutlisa `false` ka ts'ebetso ena bo sa ameng sephetho, empa ts'ebetso feela.
    /// Litlamorao tsa ho sebelisa mokhoa ona ho etsa hore nako ea ho matha le khoutu ea nako li itšoare ka tsela e fapaneng ha li so ka li hlahlojoa.
    /// Mokhoa ona ha oa lokela ho sebelisoa ho hlahisa liphapang tse joalo, hape ha oa lokela ho tsitsa pele re utloisisa hantle taba ena.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// E khutlisa hore na litsupa tse peli li netefalitsoe hore ha li tšoane.
    ///
    /// Nakong ea ho matha mosebetsi ona o itšoara joaloka `self != other`.
    /// Leha ho le joalo, maemong a mang (mohlala, tlhahlobo ea nako ea ho bokella), ha se kamehla ho ka khonehang ho fumana ho se lekane ha litsupa tse peli, ka hona ts'ebetso ena e ka khutlisa `false` ka mokhoa o makatsang bakeng sa litlhahiso tseo hamorao li tla fetoha li sa lekana.
    ///
    /// Empa ha e khutlisa `true`, litsupa li netefalitsoe hore ha li lekane.
    ///
    /// Mosebetsi ona ke seipone sa [`guaranteed_eq`], empa eseng se khelohileng.Ho na le papiso ea sesupi eo mesebetsi ka bobeli e khutlisetsang `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Boleng ba ho khutla bo ka fetoha ho latela mofuta oa sekhomphutha mme khoutu e sa bolokehang e kanna ea se itšetlehe ka sephetho sa ts'ebetso ena bakeng sa ho hlaka.
    /// Ho khothalletsoa hore ho sebelisoe ts'ebetso ena feela bakeng sa ho ntlafatsa ts'ebetso ea ts'ebetso moo boleng ba ho khutlisa `false` ka ts'ebetso ena bo sa ameng sephetho, empa ts'ebetso feela.
    /// Litlamorao tsa ho sebelisa mokhoa ona ho etsa hore nako ea ho matha le khoutu ea nako li itšoare ka tsela e fapaneng ha li so ka li hlahlojoa.
    /// Mokhoa ona ha oa lokela ho sebelisoa ho hlahisa liphapang tse joalo, hape ha oa lokela ho tsitsa pele re utloisisa hantle taba ena.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// E lekanya sebaka se pakeng tsa litlhahiso tse peli.Boleng bo khutlisitsoeng bo ka likarolo tsa T: sebaka sa li-byte se arotsoe ke `mem::size_of::<T>()`.
    ///
    /// Ts'ebetso ena ke karohano ea [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Haeba efe kapa efe ea maemo a latelang a tloloa, sephetho ke Boitšoaro bo sa Rutehang:
    ///
    /// * Sesupi sa ho qala le tse ling ka bobeli li tlameha ho ba ka har'a meeli kapa e le ngoe ea byte e fetileng qetellong ea ntho e abuoeng.
    /// Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// * Litlhahiso ka bobeli li tlameha ho tsoa ho * sesupi ho ntho e ts'oanang.
    ///   (Sheba mohlala o ka tlase.)
    ///
    /// * Sebaka se pakeng tsa litsupa, ka li-byte, se tlameha ho ba palo e fapaneng hantle le boholo ba `T`.
    ///
    /// * Sebaka se lipakeng tsa litsupa,**ka li-byte**, ha se khone ho phalla `isize`.
    ///
    /// * Sebaka se meeling se ke ke sa itšetleha ka "wrapping around" sebaka sa aterese.
    ///
    /// Mefuta ea Rust ha ho mohla e kholo ho feta likabelo tsa `isize::MAX` le Rust ha ho mohla li koahelang sebaka sa aterese, ka hona, litsupa tse peli ka har'a boleng ba mofuta ofe kapa ofe oa Rust `T` li tla lula li khotsofatsa maemo a mabeli a ho qetela.
    ///
    /// Laeborari e tloaelehileng le eona ka kakaretso e netefatsa hore likabo ha li fihle boholo ba moo offset e leng taba.
    /// Mohlala, `Vec` le `Box` ba netefatsa hore ha ba arolelane li-byte tse fetang `isize::MAX`, ka hona `ptr_into_vec.offset_from(vec.as_ptr())` e khotsofatsa maemo a mabeli a ho qetela.
    ///
    /// Boholo ba lipolanete ha bo khone ho aha kabo e kholo joalo.
    /// Mohlala, ha ho sethala sa 64-bit se tsejoang se ka kopang kopo ea li-byte tse 2 <sup>63</sup> ka lebaka la meeli ea tafole ea maqephe kapa ho arola sebaka sa aterese.
    /// Leha ho le joalo, liforomo tse ling tsa 32-bit le 16-bit li ka sebetsa ka katleho kopo ea li-byte tse fetang `isize::MAX` tse nang le lintho tse kang Physical Address Extension.
    /// Kahoo, memori e fumanoeng ka kotloloho ho baabi kapa lifaele tsa 'mapa oa memori * e kanna ea ba kholo haholo hore e ka sebetsoa ka ts'ebetso ena.
    /// (Hlokomela hore [`offset`] le [`add`] le tsona li na le meeli e ts'oanang 'me ka hona li ke ke tsa sebelisoa likabelong tse kholo joalo.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ts'ebetso ena panics haeba `T` ke mofuta oa Zero-Sized ("ZST").
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Ts'ebeliso e fosahetseng *:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Etsa ptr2_other "alias" of ptr2, empa e tsoa ho ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kaha ptr2_other le ptr2 li tsoa litsing ho ea ho lintho tse fapaneng, ho sebelisa offset ea bona ke boits'oaro bo sa hlalosoang, leha ba supa atereseng e le 'ngoe!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Boitšoaro bo sa hlalosoang
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// E fumana palo ho tloha pointer (bonolo bakeng sa `.offset(count as isize)`).
    ///
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Haeba efe kapa efe ea maemo a latelang a tloloa, sephetho ke Boitšoaro bo sa Rutehang:
    ///
    /// * Sesupa sa ho qala le se hlahisang se tlameha ho ba ka har'a meeli kapa e le ngoe ea li-byte tse fetileng qetellong ea ntho e abuoeng.
    /// Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// * Computed offset,**in bytes**, e ke ke ea phallela `isize`.
    ///
    /// * Phokotso ea ho ba moeling e ke ke ea itšetleha ka "wrapping around" sebaka sa aterese.Ka mantsoe a mang, chelete e sa feleng e nepahetseng e tlameha ho lekana le `usize`.
    ///
    /// Moqapi le laeborari e tloaelehileng ka kakaretso e leka ho netefatsa hore likabo ha li fihle boholo ba moo ho nang le bothata bo amehang.
    /// Mohlala, `Vec` le `Box` ba netefatsa hore ha ho mohla ba fanang ka li-byte tse fetang `isize::MAX`, kahoo `vec.as_ptr().add(vec.len())` e lula e bolokehile.
    ///
    /// Boholo ba lipolanete ha bo khone ho aha kabo e joalo.
    /// Mohlala, ha ho sethala sa 64-bit se tsejoang se ka kopang kopo ea li-byte tse 2 <sup>63</sup> ka lebaka la meeli ea tafole ea maqephe kapa ho arola sebaka sa aterese.
    /// Leha ho le joalo, liforomo tse ling tsa 32-bit le 16-bit li ka sebetsa ka katleho kopo ea li-byte tse fetang `isize::MAX` tse nang le lintho tse kang Physical Address Extension.
    ///
    /// Kahoo, memori e fumanoeng ka kotloloho ho baabi kapa lifaele tsa 'mapa oa memori * e kanna ea ba kholo haholo hore e ka sebetsoa ka ts'ebetso ena.
    ///
    /// Nahana ka ho sebelisa [`wrapping_add`] ho fapana haeba mathata ana a le thata ho a khotsofatsa.
    /// Monyetla o le mong feela oa mokhoa ona ke hore o nolofalletsa likhakanyo tse ngata tse mabifi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// E fumana palo ho tloha pointer (bonolo ba `.offset ((bala e le isize).wrapping_neg())`).
    ///
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Haeba efe kapa efe ea maemo a latelang a tloloa, sephetho ke Boitšoaro bo sa Rutehang:
    ///
    /// * Sesupa sa ho qala le se hlahisang se tlameha ho ba ka har'a meeli kapa e le ngoe ea li-byte tse fetileng qetellong ea ntho e abuoeng.
    /// Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// * Compset offset e ke ke ea feta `isize::MAX`**byte**.
    ///
    /// * Phokotso ea ho ba moeling e ke ke ea itšetleha ka "wrapping around" sebaka sa aterese.Ka mantsoe a mang, chelete e sa lekanyetsoang-e nepahetseng e tlameha ho lekana ka boholo.
    ///
    /// Moqapi le laeborari e tloaelehileng ka kakaretso e leka ho netefatsa hore likabo ha li fihle boholo ba moo ho nang le bothata bo amehang.
    /// Mohlala, `Vec` le `Box` ba netefatsa hore ha ho mohla ba fanang ka li-byte tse fetang `isize::MAX`, kahoo `vec.as_ptr().add(vec.len()).sub(vec.len())` e lula e bolokehile.
    ///
    /// Boholo ba lipolanete ha bo khone ho aha kabo e joalo.
    /// Mohlala, ha ho sethala sa 64-bit se tsejoang se ka kopang kopo ea li-byte tse 2 <sup>63</sup> ka lebaka la meeli ea tafole ea maqephe kapa ho arola sebaka sa aterese.
    /// Leha ho le joalo, liforomo tse ling tsa 32-bit le 16-bit li ka sebetsa ka katleho kopo ea li-byte tse fetang `isize::MAX` tse nang le lintho tse kang Physical Address Extension.
    ///
    /// Kahoo, memori e fumanoeng ka kotloloho ho baabi kapa lifaele tsa 'mapa oa memori * e kanna ea ba kholo haholo hore e ka sebetsoa ka ts'ebetso ena.
    ///
    /// Nahana ka ho sebelisa [`wrapping_sub`] ho fapana haeba mathata ana a le thata ho a khotsofatsa.
    /// Monyetla o le mong feela oa mokhoa ona ke hore o nolofalletsa likhakanyo tse ngata tse mabifi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// E sebetsa ka palo ho tloha sesupa ka ho sebelisa arithmetic ea ho phuthela.
    /// (bonolo bakeng sa `.wrapping_offset(count as isize)`)
    ///
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ka boeona e lula e bolokehile, empa ho sebelisa sesupa-tsela se hlahang ha ho joalo.
    ///
    /// Sesupa se hlahisoang se lula se hokelletsoe ho ntho e le 'ngoe e abiloeng eo `self` e e supang.
    /// E kanna ea se sebelisoe ho fihlella ntho e fanoeng e fapaneng.Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// Ka mantsoe a mang, `let z = x.wrapping_add((y as usize) - (x as usize))` ha e etse hore `z` e tšoane le `y` leha re nahana hore `T` e na le boholo ba `1` mme ha ho na phallo e fetang: `z` e ntse e khomaretse ntho `x` e hokeletsoeng ho eona, 'me ho e hlakola ke boits'oaro bo sa hlalosoang ntle le `x` le `y` e supa ntho e tšoanang e abetsoeng.
    ///
    /// Ha e bapisoa le [`add`], mokhoa ona o liehisa tlhoko ea ho lula ka har'a ntho e le 'ngoe e abetsoeng: [`add`] ke boits'oaro bo sa lekanyetsoang ha o tšela meeli ea lintho;`wrapping_add` e hlahisa sesupi empa e ntse e lebisa ho Boitšoaro bo sa Rutehang haeba sesupa se sa hlalosoe ha se le moeling oa ntho eo e hoketsoeng ho eona.
    /// [`add`] e ka ntlafatsoa hantle 'me ka hona ea rateha ho khoutu e sa sebetseng.
    ///
    /// Cheke e liehang e nka feela boleng ba sesupa se ileng sa hlakisoa, eseng litekanyetso tsa mahareng tse sebelisitsoeng nakong ea palo ea sephetho sa hoqetela.
    /// Mohlala, `x.wrapping_add(o).wrapping_sub(o)` e lula e tšoana le `x`.Ka mantsoe a mang, ho siea ntho eo re e abetsoeng ebe re e kenya hape hamorao ho a lumelloa.
    ///
    /// Haeba o hloka ho tšela meeli ea ntho, lahlela sesupa ho palo e kholo ebe o etsa lipalo moo.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // Iterate o sebelisa sesupa se tala ka keketseho ea likarolo tse peli
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Lupu lena le hatisa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// E sebetsa ka palo ho tloha sesupa ka ho sebelisa arithmetic ea ho phuthela.
    /// (bonolo bakeng sa `.wrapping_offset ((bala joalo ka isize).wrapping_neg())`)
    ///
    /// `count` e ka liuniti tsa T;mohl., `count` ea 3 e emetse sesupo sa sesupo sa li-byte tsa `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ka boeona e lula e bolokehile, empa ho sebelisa sesupa-tsela se hlahang ha ho joalo.
    ///
    /// Sesupa se hlahisoang se lula se hokelletsoe ho ntho e le 'ngoe e abiloeng eo `self` e e supang.
    /// E kanna ea se sebelisoe ho fihlella ntho e fanoeng e fapaneng.Hlokomela hore ho Rust, mofuta o mong le o mong oa (stack-allocated) o nkuoa e le ntho e arotsoeng ka thoko.
    ///
    /// Ka mantsoe a mang, `let z = x.wrapping_sub((x as usize) - (y as usize))` ha e etse hore `z` e tšoane le `y` leha re nahana hore `T` e na le boholo ba `1` mme ha ho na phallo e fetang: `z` e ntse e khomaretse ntho `x` e hokeletsoeng ho eona, 'me ho e hlakola ke boits'oaro bo sa hlalosoang ntle le `x` le `y` e supa ntho e tšoanang e abetsoeng.
    ///
    /// Ha e bapisoa le [`sub`], mokhoa ona o liehisa tlhoko ea ho lula ka har'a ntho e le 'ngoe e abetsoeng: [`sub`] ke boits'oaro bo sa lekanyetsoang ha o tšela meeli ea lintho;`wrapping_sub` e hlahisa sesupi empa e ntse e lebisa ho Boitšoaro bo sa Rutehang haeba sesupa se sa hlalosoe ha se le moeling oa ntho eo e hoketsoeng ho eona.
    /// [`sub`] e ka ntlafatsoa hantle 'me ka hona ea rateha ho khoutu e sa sebetseng.
    ///
    /// Cheke e liehang e nka feela boleng ba sesupa se ileng sa hlakisoa, eseng litekanyetso tsa mahareng tse sebelisitsoeng nakong ea palo ea sephetho sa hoqetela.
    /// Mohlala, `x.wrapping_add(o).wrapping_sub(o)` e lula e tšoana le `x`.Ka mantsoe a mang, ho siea ntho eo re e abetsoeng ebe re e kenya hape hamorao ho a lumelloa.
    ///
    /// Haeba o hloka ho tšela meeli ea ntho, lahlela sesupa ho palo e kholo ebe o etsa lipalo moo.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// // Iterate o sebelisa sesupa se tala ka keketseho ea likarolo tse peli (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Lupu lena le hatisa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// E beha boleng ba pointer ho `ptr`.
    ///
    /// Haeba `self` e le sesupa sa (fat) ho mofuta o sa lekanyetsoang, ts'ebetso ena e tla ama karolo ea sesupa feela, athe bakeng sa lits'oants'o tsa (thin) ho mefuta e boholo, sena se na le phello e ts'oanang le kabelo e bonolo.
    ///
    /// Pointer e hlahisoang e tla ba le projeke ea `val`, ke hore, bakeng sa sesupa-mafura, ts'ebetso ena e ts'oana hantle le ho theha sesupi se secha sa mafura se nang le boleng ba sesupi sa data sa `val` empa metadata ea `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ts'ebetso ena e bohlokoa haholo bakeng sa ho lumella lipalo tsa pointer tse bohlale ka lits'oants'o tse ka bang le mafura:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // e tla hatisa "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // TŠIRELETSO: Haeba ho na le sesupa-tšesaane, ts'ebetso ena e ts'oana
        // ho kabelo e bonolo.
        // Haeba ho na le sesupa-mafura, ka tšebetso ea hona joale ea sesupo sa mafura, tšimo ea pele ea sesupi se joalo e lula e le sesupa-data, se abeloang ka mokhoa o ts'oanang.
        //
        unsafe { *thin = val };
        self
    }

    /// E bala boleng ho tsoa ho `self` ntle le ho e tsamaisa.
    /// Sena se siea memori ho `self` e sa fetohe.
    ///
    /// Bona [`ptr::read`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya ``.
        unsafe { read(self) }
    }

    /// E bala boleng bo sa tloaelehang ba `self` ntle le ho e tsamaisa.Sena se siea memori ho `self` e sa fetohe.
    ///
    /// Ts'ebetso e feto-fetohang e etselitsoe ho sebetsa mohopolong oa I/O, 'me e netefalitsoe hore e ke ke ea qhekelloa kapa ea hlophisoa bocha ke mokopanyi mesebetsing e meng e mebe.
    ///
    ///
    /// Bona [`ptr::read_volatile`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// E bala boleng ho tsoa ho `self` ntle le ho e tsamaisa.
    /// Sena se siea memori ho `self` e sa fetohe.
    ///
    /// Ho fapana le `read`, sesupa-tsela se kanna sa se lumellane.
    ///
    /// Bona [`ptr::read_unaligned`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Likopi tsa `count * size_of<T>` byte ho tloha `self` ho isa ho `dest`.
    /// Mohloli le moo o eang teng li ka kopana.
    ///
    /// NOTE: sena se na le tatellano ea ngangisano e tšoanang le [`ptr::copy`].
    ///
    /// Bona [`ptr::copy`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Likopi tsa `count * size_of<T>` byte ho tloha `self` ho isa ho `dest`.
    /// Mohloli le sebaka seo o yang ho sona se kanna sa se * tsamaisane.
    ///
    /// NOTE: sena se na le tatellano ea ngangisano e tšoanang le [`ptr::copy_nonoverlapping`].
    ///
    /// Bona [`ptr::copy_nonoverlapping`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Likopi tsa `count * size_of<T>` byte ho tloha `src` ho isa ho `self`.
    /// Mohloli le moo o eang teng li ka kopana.
    ///
    /// NOTE: sena se na le tatellano * ea khang ea [`ptr::copy`].
    ///
    /// Bona [`ptr::copy`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Likopi tsa `count * size_of<T>` byte ho tloha `src` ho isa ho `self`.
    /// Mohloli le sebaka seo o yang ho sona se kanna sa se * tsamaisane.
    ///
    /// NOTE: sena se na le tatellano * ea khang ea [`ptr::copy_nonoverlapping`].
    ///
    /// Bona [`ptr::copy_nonoverlapping`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// E phethisa mosenyi (haeba a le teng) oa boleng bo boletsoeng.
    ///
    /// Bona [`ptr::drop_in_place`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// E ngola sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
    ///
    ///
    /// Bona [`ptr::write`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `write`.
        unsafe { write(self, val) }
    }

    /// E kopa memset ho pointer e boletsoeng, e beha li-memory tsa `count * size_of::<T>()` ho qala ka `self` ho isa ho `val`.
    ///
    ///
    /// Bona [`ptr::write_bytes`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// E ngola mongolo o sa tsitsang oa sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
    ///
    /// Ts'ebetso e feto-fetohang e etselitsoe ho sebetsa mohopolong oa I/O, 'me e netefalitsoe hore e ke ke ea qhekelloa kapa ea hlophisoa bocha ke mokopanyi mesebetsing e meng e mebe.
    ///
    ///
    /// Bona [`ptr::write_volatile`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// E ngola sebaka sa mohopolo ka boleng bo fanoeng ntle le ho bala kapa ho theola boleng ba khale.
    ///
    ///
    /// Ho fapana le `write`, sesupa-tsela se kanna sa se lumellane.
    ///
    /// Bona [`ptr::write_unaligned`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// E khutlisa boleng ba `self` ka `src`, e khutlisa boleng ba khale, ntle le ho e lahla.
    ///
    ///
    /// Bona [`ptr::replace`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `replace`.
        unsafe { replace(self, src) }
    }

    /// E fetola boleng libakeng tse peli tse ka feto-fetohang tsa mofuta o le mong, ntle le ho hlakola ebang ke.
    /// Li kanna tsa kopana, ho fapana le `mem::swap` e batlang e lekana ka tsela e ngoe.
    ///
    /// Bona [`ptr::swap`] bakeng sa matšoenyeho a polokeho le mehlala.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `swap`.
        unsafe { swap(self, with) }
    }

    /// E lekanya offset e hlokang ho sebelisoa ho sesupa ho e hokahanya le `align`.
    ///
    /// Haeba ho sa khonehe ho hokahanya sesupa, ts'ebetso e khutlisa `usize::MAX`.
    /// Ho lumelloa hore ts'ebetsong e khutlisetse `usize::MAX` kamehla.
    /// Ke ts'ebetso ea algorithm ea hau feela e ka itšetlehang ka ho fumana offset e ka sebelisoang mona, eseng ho nepahala ha eona.
    ///
    /// Offset e hlahisoa ka palo ea likarolo tsa `T`, eseng li-byte.Boleng bo khutlisitsoeng bo ka sebelisoa ka mokhoa oa `wrapping_add`.
    ///
    /// Ha ho na tiiso ea hore ho hlakisa sesupi ho ke ke ha phalla kapa ho feta kabo eo sesupi se supang ho eona.
    ///
    /// Ho ho motho ea letsitseng ho netefatsa hore offset e khutlisitsoeng e nepahetse maemong ohle ntle le tatellano.
    ///
    /// # Panics
    ///
    /// Ts'ebetso panics haeba `align` e se matla a mabeli.
    ///
    /// # Examples
    ///
    /// Ho fihlella haufi le `u8` joalo ka `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ha sesupa se ka hokahanngoa ka `offset`, se ka supa kantle ho kabo
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // TSHIRELETSO: `align` e lekotswe ho ba matla a 2 kaholimo
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// E khutlisa bolelele ba selae se tala.
    ///
    /// Boleng bo khutlisitsoeng ke palo ea **likarolo**, eseng palo ea li-byte.
    ///
    /// Mosebetsi ona o bolokehile, leha selae se tala se ke ke sa lahleloa ho sets'oants'o sa selae hobane sesupa ha se na thuso kapa ha sea loka.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // TŠIRELETSO: sena se bolokehile hobane `*const [T]` le `FatPtr<T>` li na le sebopeho se tšoanang.
            // Ke `std` feela e ka etsang tiiso ena.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// E khutlisetsa sesupisi se tala ho sesepa sa selae.
    ///
    /// Sena se lekana le ho lahla `self` ho `*mut T`, empa ho bolokehile haholoanyane.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// E khutlisetsa pointer e tala ho elemente kapa subslice, ntle le ho hlahloba meeli.
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli kapa ha `self` e sa hlakoloe ke *[boits'oaro bo sa hlalosoang]* leha sesupisi se hlahisoang se sa sebelisoe.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // TSHIRELETSO: moletsi o netefatsa hore `self` ha e sa tlholeha mme `index` ha e na meeli.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// E khutlisa `None` haeba pointer e sa sebetse, ho seng joalo e khutlisa selae se arolelanoeng ho boleng bo phuthetsoeng ka `Some`.
    /// Ho fapana le [`as_ref`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Pointer e tlameha ho ba [valid] bakeng sa ho baloa bakeng sa li-byte tse ngata tsa `ptr.len() * mem::size_of::<T>()`, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
    ///
    ///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
    ///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.
    ///
    ///     * Sesupa se tlameha ho hokahanngoa le bakeng sa likhechana tse bolelele ba zero.
    ///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
    ///
    ///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
    ///
    /// * Boholo ba `ptr.len() * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
    ///   Bona litokomane tsa polokeho ea [`pointer::offset`].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// Bona hape [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// E khutlisa `None` haeba pointer e sa sebetse, ho seng joalo e khutlisa selae se ikhethileng ho boleng bo phuthetsoeng ka `Some`.
    /// Ho fapana le [`as_mut`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore *sesupi ke NULL* kapa * tsohle tse latelang ke 'nete:
    ///
    /// * Pointer e tlameha ho ba [valid] bakeng sa ho bala le ho ngola bakeng sa `ptr.len() * mem::size_of::<T>()` li-byte tse ngata, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
    ///
    ///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
    ///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.
    ///
    ///     * Sesupa se tlameha ho hokahanngoa le bakeng sa likhechana tse bolelele ba zero.
    ///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
    ///
    ///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
    ///
    /// * Boholo ba `ptr.len() * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
    ///   Bona litokomane tsa polokeho ea [`pointer::offset`].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// Bona hape [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Tekatekano bakeng sa litsupa
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}