use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` empa e se zero ebile e le covariant.
///
/// Hangata hona ke ntho e nepahetseng eo u ka e sebelisang ha u aha meralo ea data u sebelisa lits'oants'o tse tala, empa qetellong ho kotsi ho e sebelisa ka lebaka la thepa ea eona e tlatselletsang.Haeba o sa tsebe hantle hore na o lokela ho sebelisa `NonNull<T>`, sebelisa `*mut T` feela!
///
/// Ho fapana le `*mut T`, sesupa-hlooho se tlameha ho lula se sa sebetse, leha sesupa-tsela se sa hlahisoe hape.Sena ke hore li-enum li ka sebelisa boleng bona bo hanetsoeng joalo ka khethollo-`Option<NonNull<T>>` e na le boholo bo lekanang le `* mut T`.
/// Leha ho le joalo, sesupi se kanna sa thekesela haeba se sa hlalosoe.
///
/// Ho fapana le `*mut T`, `NonNull<T>` e ile ea khethoa hore e be covariant ho feta `T`.Sena se nolofalletsa ho sebelisa `NonNull<T>` ha o haha mefuta ea covariant, empa e hlahisa kotsi ea ho hloka botsitso haeba e sebelisoa ka mofuta o sa lokelang ho ba covariant.
/// (Khetho e fapaneng e entsoe bakeng sa `*mut T` leha e le hore botekgeniki ho hloka botsitso ho ka bakoa feela ke ho bitsa mesebetsi e sa bolokehang.)
///
/// Covariance e nepahetse bakeng sa lits'oants'o tse bolokehileng tse ngata, joalo ka `Box`, `Rc`, `Arc`, `Vec`, le `LinkedList`.Ho joalo hobane ba fana ka API ea sechaba e latelang melao e tloaelehileng e arolelanoeng ea XOR ea Rust.
///
/// Haeba mofuta oa hau o sa khone ho ba covariant ka polokeho, o tlameha ho netefatsa hore o na le tšimo e 'ngoe e fanang ka tlhaiso-leseling.Hangata tšimo ena e tla ba mofuta oa [`PhantomData`] joalo ka `PhantomData<Cell<T>>` kapa `PhantomData<&'a mut T>`.
///
/// Hlokomela hore `NonNull<T>` e na le mohlala oa `From` bakeng sa `&T`.Leha ho le joalo, sena ha se fetole taba ea hore ho fetoloa ka (pointer e tsoang ho) litšupiso tse arolelanoeng ke boits'oaro bo sa hlalosoang ntle le haeba phetoho e etsahala kahare ho [`UnsafeCell<T>`].E ts'oanang le ea ho theha tšupiso e ka feto-fetohang ho tsoa bukaneng e arolelanoeng.
///
/// Ha o sebelisa mohlala ona oa `From` ntle le `UnsafeCell<T>`, ke boikarabello ba hau ho netefatsa hore `as_mut` ha e bitsoe, 'me `as_ptr` ha e sebelisoe bakeng sa phetoho.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` lits'oants'o ha se `Send` hobane data eo ba e supang e kanna ea hlonamisoa.
// NB, tlhahiso ena ha e hlokahale, empa e lokela ho fana ka melaetsa ea liphoso e betere.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` lits'oants'o ha se `Sync` hobane data eo ba e supang e kanna ea hlonamisoa.
// NB, tlhahiso ena ha e hlokahale, empa e lokela ho fana ka melaetsa ea liphoso e betere.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// E etsa `NonNull` e ncha e lepeletseng, empa e hokahane hantle.
    ///
    /// Sena se na le thuso bakeng sa ho qala mefuta e fanoang ka botsoa, joalo ka `Vec::new`.
    ///
    /// Hlokomela hore boleng ba sesupi bo kanna ba emela sesupa se nepahetseng ho `T`, ho bolelang hore sena ha sea lokela ho sebelisoa e le boleng ba "not yet initialized" sentinel.
    /// Mefuta e fanang ka botsoa e tlameha ho latedisa ho qala ka mekhoa e meng.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // TSHIRELETSO: mem::align_of() e kgutlisa usize eo e seng ya zero e ntan'o lahlwa
        // ho * mut T.
        // Ka hona, `ptr` ha e na thuso mme maemo a ho letsetsa new_unchecked() aa hlomphuoa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// E khutlisetsa litšupiso tse arolelanoeng ho boleng.Ho fapana le [`as_ref`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        unsafe { &*self.cast().as_ptr() }
    }

    /// E khutlisetsa litšupiso tse ikhethang ho boleng.Ho fapana le [`as_mut`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// E theha `NonNull` e ncha.
    ///
    /// # Safety
    ///
    /// `ptr` ha ea lokela ho ba null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `ptr` ha e na thuso.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// E etsa `NonNull` e ncha haeba `ptr` e sa sebetse.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // TSHIRELETSO: Sesupi se se se hlahlobilwe mme ha se lefeela
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// E etsa ts'ebetso e ts'oanang le [`std::ptr::from_raw_parts`], ntle le hore sesupa sa `NonNull` sea khutlisoa, ho fapana le sesupa se tala sa `*const`.
    ///
    ///
    /// Bona litokomane tsa [`std::ptr::from_raw_parts`] bakeng sa lintlha tse ling.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // TSHIRELETSO: Sephetho sa `ptr::from::raw_parts_mut` ha se na thuso hobane `data_address` ke.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Senya sesupa (mohlomong ka bophara) sa aterese le likarolo tsa metadata.
    ///
    /// Pointer e ka ntlafatsoa hamorao ka [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// E fumana sesupa-ntlha sa `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// E khutlisetsa litšupiso tse arolelanoeng tsa boleng.Haeba boleng bo ka se qaloe, [`as_uninit_ref`] e tlameha ho sebelisoa ho fapana.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * Sesupi se tlameha ho supa mohlala o qalileng oa `T`.
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    /// (Karolo e mabapi le ho qalisoa ha e so etse qeto e felletseng, empa ho fihlela e le teng, mokhoa o le mong feela o bolokehileng ke ho netefatsa hore ehlile lia qalisoa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso.
        unsafe { &*self.as_ptr() }
    }

    /// E khutlisetsa ts'upiso e ikhethang ho boleng.Haeba boleng bo ka se qaloe, [`as_uninit_mut`] e tlameha ho sebelisoa ho fapana.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Sesupa se tlameha ho hokahanngoa hantle.
    ///
    /// * E tlameha ho ba "dereferencable" ka kutloisiso e hlalositsoeng ho [the module documentation].
    ///
    /// * Sesupi se tlameha ho supa mohlala o qalileng oa `T`.
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    /// (Karolo e mabapi le ho qalisoa ha e so etse qeto e felletseng, empa ho fihlela e le teng, mokhoa o le mong feela o bolokehileng ke ho netefatsa hore ehlile lia qalisoa.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `self` e fihlela tsohle
        // litlhokahalo bakeng sa ts'upiso e ka fetohang.
        unsafe { &mut *self.as_ptr() }
    }

    /// E kenya sesupisi sa mofuta o mong.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // TSHIRELETSO: `self` ke sesupi sa `NonNull` seo haele hantle e seng sa lefeela
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// E etsa selae se tala se sa sebetseng ho tloha sesupa-tšesaane le bolelele.
    ///
    /// Khang ea `len` ke palo ea **lintho**, eseng palo ea li-byte.
    ///
    /// Mosebetsi ona o bolokehile, empa ho hlakola boleng ba ho khutlisa ha ho bolokehe.
    /// Bona litokomane tsa [`slice::from_raw_parts`] bakeng sa litlhoko tsa polokeho ea selae.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // theha sesupi sa selae ha u qala ka sesupa ho ntlha ea pele
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Hlokomela hore mohlala ona o bonts'a ts'ebeliso ea mokhoa ona ka boqhetseke, empa` let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // TSHIRELETSO: `data` ke sesupi sa `NonNull` seo haele hantle e seng sa lefeela
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// E khutlisa bolelele ba selae se tala se sa null.
    ///
    /// Boleng bo khutlisitsoeng ke palo ea **likarolo**, eseng palo ea li-byte.
    ///
    /// Mosebetsi ona o bolokehile, leha selae se tala se sa null se ke ke sa hlalosoa ho selae hobane sesupa ha se na aterese e nepahetseng.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// E khutlisetsa sesupa-hloko se sa sebetseng mochining oa selae.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // TSHIRELETSO: Re a tseba `self` ha e na thuso.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// E khutlisetsa sesupisi se tala ho sesepa sa selae.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// E khutlisetsa litšupiso tse arolelanoeng ho selae sa litekanyetso tse sa qaloang.Ho fapana le [`as_ref`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa mphato ea ka fetohang bona [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Pointer e tlameha ho ba [valid] bakeng sa ho baloa bakeng sa li-byte tse ngata tsa `ptr.len() * mem::size_of::<T>()`, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
    ///
    ///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
    ///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.
    ///
    ///     * Sesupa se tlameha ho hokahanngoa le bakeng sa likhechana tse bolelele ba zero.
    ///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
    ///
    ///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
    ///
    /// * Boholo ba `ptr.len() * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
    ///   Bona litokomane tsa polokeho ea [`pointer::offset`].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fetoha (ntle le kahare ho `UnsafeCell`).
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// Bona hape [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// E khutlisetsa ts'upiso e ikhethileng selae sa litheko tse ka sa qaloang.Ho fapana le [`as_mut`], sena ha se hloke hore boleng bo tlameha ho qalisoa.
    ///
    /// Bakeng sa molekane ea arolelanoeng bona [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ha o letsetsa mokhoa ona, o tlameha ho etsa bonnete ba hore tsohle tse latelang ke 'nete:
    ///
    /// * Pointer e tlameha ho ba [valid] bakeng sa ho bala le ho ngola bakeng sa `ptr.len() * mem::size_of::<T>()` li-byte tse ngata, 'me e tlameha ho hokahana hantle.Sena se bolela haholoholo:
    ///
    ///     * Mefuta eohle ea memori ea selae sena e tlameha ho ba ka har'a ntho e le 'ngoe e abetsoeng!
    ///       Likarolo ha li khone ho tšela lintho tse ngata tse abetsoeng.
    ///
    ///     * Sesupa se tlameha ho hokahanngoa le bakeng sa likhechana tse bolelele ba zero.
    ///     Lebaka le leng la sena ke hore ntlafatso ea meralo ea enum e kanna ea itšetleha ka litšupiso (ho kenyeletsoa le lilae tsa bolelele bofe kapa bofe) li hokahantsoe ebile li sa null ho li khetholla ho data e ngoe.
    ///
    ///     O ka fumana sesupa se ka sebelisoang e le `data` bakeng sa likhae tsa bolelele ba zero u sebelisa [`NonNull::dangling()`].
    ///
    /// * Boholo ba `ptr.len() * mem::size_of::<T>()` ea selae ha ea lokela ho ba kholo ho feta `isize::MAX`.
    ///   Bona litokomane tsa polokeho ea [`pointer::offset`].
    ///
    /// * O tlameha ho tiisa melao ea ho hlonama ea Rust, kaha nako ea bophelo e khutlisitsoeng `'a` e khethiloe ka mokhoa o ikhethileng 'me ha e hlile ha e bontše nako ea bophelo ba data.
    ///   Haholo-holo, bakeng sa nako ea bophelo bona bohle, mohopolo oo pointer a o supisang ha oa lokela ho fihlella (ho baloa kapa ho ngoloa) ka sesupi se seng.
    ///
    /// Sena se sebetsa le haeba sephetho sa mokhoa ona se sa sebelisoe!
    ///
    /// Bona hape [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Sena se bolokehile kaha `memory` e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tse ngata tsa `memory.len()`.
    /// // Hlokomela hore ho letsetsa `memory.as_mut()` ha hoa lumelloa mona kaha litaba li kanna tsa se qaloe.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// E khutlisetsa pointer e tala ho elemente kapa subslice, ntle le ho hlahloba meeli.
    ///
    /// Ho letsetsa mokhoa ona ka index ea kantle ho meeli kapa ha `self` e sa hlakoloe ke *[boits'oaro bo sa hlalosoang]* leha sesupisi se hlahisoang se sa sebelisoe.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // TSHIRELETSO: moletsi o netefatsa hore `self` ha e sa tlholeha mme `index` ha e na meeli.
        // Ka lebaka leo, sesupi se hlahisoang e ke ke ea ba NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // TSHIRELETSO: Sesupi se ikgethang se ke ke sa fetoha, kahoo maemo a
        // new_unchecked() lia hlomphuoa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // TSHIRELETSO: Tshupiso e ka fetohang ha e na ho fetoha.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // TSHIRELETSO: Tshupiso e ke ke ya fetoha lefeela, ka hona maemo a
        // new_unchecked() lia hlomphuoa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}