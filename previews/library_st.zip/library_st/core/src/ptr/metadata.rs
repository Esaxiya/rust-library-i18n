#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// E fana ka mofuta oa metadata ea sesupi ea mofuta ofe kapa ofe o supisitsoeng.
///
/// # Metadata ea sesupo
///
/// Mefuta ea pointer e tala le mefuta ea litšupiso ho Rust e ka nahanoa e entsoe ka likarolo tse peli:
/// sesupi sa data se nang le aterese ea memori ea boleng, le metadata e meng.
///
/// Bakeng sa mefuta ea boholo-holo (e sebelisang `Sized` traits) hammoho le mefuta ea `extern`, litsupa ho thoe li "tšesaane": metadata e boholo ba zero mme mofuta oa eona ke `()`.
///
///
/// Litlhahiso tsa [dynamically-sized types][dst] ho thoe li "pharaletse" kapa "mafura", li na le metadata e sa lekanang le zero:
///
/// * Bakeng sa li-structs tseo tšimo ea tsona ea hoqetela e leng DST, metadata ke metadata bakeng sa tšimo ea hoqetela
/// * Bakeng sa mofuta oa `str`, metadata ke bolelele ba li-byte joaloka `usize`
/// * Bakeng sa mefuta ea selae joaloka `[T]`, metadata ke bolelele ba lintho tse kang `usize`
/// * Bakeng sa lintho tsa trait tse kang `dyn SomeTrait`, metadata ke [`DynMetadata<Self>`][DynMetadata] (mohlala, `DynMetadata<dyn SomeTrait>`)
///
/// Ho future, puo ea Rust e ka fumana mefuta e mecha ea mefuta e nang le metadata e fapaneng ea sesupi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Ntlha ea trait ena ke mofuta oa eona o amanang le `Metadata`, e leng `()` kapa `usize` kapa `DynMetadata<_>` joalo ka ha ho hlalositsoe kaholimo.
/// E sebelisoa ka boiketsetso bakeng sa mofuta o mong le o mong.
/// Ho ka nahanoa hore e ka kenngwa ts'ebetsong ka mokhoa o akaretsang, leha e se na tlamo e lekanang.
///
/// # Usage
///
/// Litlhahiso tse tala li ka senyeha atereseng ea data le metadata ka mokhoa oa bona oa [`to_raw_parts`].
///
/// Ntle le moo, metadata feela e ka nkuoa ka ts'ebetso ea [`metadata`].
/// Referense e ka fetisetsoa ho [`metadata`] mme ea qobelloa ka mokhoa o felletseng.
///
/// Sesupa sa (possibly-wide) se ka khutlisoa hammoho ho tloha atereseng ea sona le metadata e nang le [`from_raw_parts`] kapa [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Mofuta oa metadata ho litsupa le litšupiso tsa `Self`.
    #[lang = "metadata_type"]
    // NOTE: Boloka trait bounds ho `static_assert_expected_bounds_for_metadata`
    //
    // ka `library/core/src/ptr/metadata.rs` ka ho lumellana le ba mona:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Litlhahiso ho mefuta e sebelisang ts'ebeliso ena ea lebitso la trait li "tšesaane".
///
/// Sena se kenyelletsa mefuta ea `lipalo-boholo 'le mefuta ea `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: se ke oa tsitsisa sena pele li-alias tsa trait li tsitsitse puong?
pub trait Thin = Pointee<Metadata = ()>;

/// Tlosa karolo ea metadata ea pointer.
///
/// Litekanyetso tsa mofuta oa `*mut T`, `&T`, kapa `&mut T` li ka fetisoa ka kotloloho ts'ebetsong ena ha li ntse li qobella `* const T` ka botlalo.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // TSHIRELETSO: Ho fihlella boleng ho mokgatlo wa `PtrRepr` ho bolokehile ho tloha ha * const T
    // le PtrComponents<T>na le mekhoa ea ho hopola e tšoanang.
    // Ke std feela e ka etsang tiiso ena.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// E theha sesupa se tala sa (possibly-wide) ho tsoa atereseng ea data le metadata.
///
/// Mosebetsi ona o bolokehile empa sesupa-tsela se khutlisitsoeng ha se hlile ha se bolokehe ho khethollo.
/// Bakeng sa lilae, bona litokomane tsa [`slice::from_raw_parts`] bakeng sa litlhoko tsa polokeho.
/// Bakeng sa lintho tsa trait, metadata e tlameha ho tsoa ho sesupa ho ea ho mofuta o tšoanang o fokolitsoeng.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // TSHIRELETSO: Ho fihlella boleng ho mokgatlo wa `PtrRepr` ho bolokehile ho tloha ha * const T
    // le PtrComponents<T>na le mekhoa ea ho hopola e tšoanang.
    // Ke std feela e ka etsang tiiso ena.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// E etsa ts'ebetso e ts'oanang le [`from_raw_parts`], ntle le hore sesupa se tala sa `*mut` sea khutlisoa, ho fapana le sesupa se tala sa `* const`.
///
///
/// Bona litokomane tsa [`from_raw_parts`] bakeng sa lintlha tse ling.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // TSHIRELETSO: Ho fihlella boleng ho mokgatlo wa `PtrRepr` ho bolokehile ho tloha ha * const T
    // le PtrComponents<T>na le mekhoa ea ho hopola e tšoanang.
    // Ke std feela e ka etsang tiiso ena.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Ho kenya letsoho ka letsoho ho qoba ho tlangoa ke `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Ho kenya letsoho ka letsoho ho qoba ho tlangoa ke `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata ea mofuta oa ntho ea `Dyn = dyn SomeTrait` trait.
///
/// Ke sesupisi ho vtable (tafole ea mohala e fumanehang) e emelang tlhaiso-leseling eohle e hlokahalang ho tsamaisa mofuta oa konkreite o bolokiloeng kahare ho ntho ea trait.
/// The vtable haholo-holo e na le:
///
/// * boholo ba mofuta
/// * tatellano ea mofuta
/// * sesupi sa mofuta oa `drop_in_place` impl (e kanna ea ba no-op bakeng sa data ea khale-ea-khale)
/// * e supa mekhoa eohle ea ho kenya ts'ebetsong mofuta oa trait
///
/// Hlokomela hore tse tharo tsa pele li khethehile hobane li hlokahala ho abela, ho lahla le ho tsamaisa ntho efe kapa efe ea trait.
///
/// Hoa khoneha ho reha mofuta ona ka mofuta oa paramethara eo e seng ntho ea `dyn` trait (mohlala `DynMetadata<u64>`) empa e sa fumane boleng ba bohlokoa ba sebopeho seo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Sephetho se tloaelehileng sa li-vtable tsohle.E lateloa ke litsupa tsa ts'ebetso bakeng sa mekhoa ea trait.
///
/// Tlhahisoleseling e ikemetseng ea `DynMetadata::size_of` jj.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// E khutlisa boholo ba mofuta o amanang le vtable ena.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// E khutlisa peakanyo ea mofuta o amanang le vtable ena.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// E khutlisa boholo le tatellano hammoho joalo ka `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // TSHIRELETSO: mokopanyi o hlahisitse vtable ena bakeng sa mofuta oa konkreite Rust eo
        // e tsejoa hore e na le sebopeho se nepahetseng.Mabaka a tšoanang le a `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Lisebelisoa tsa matsoho li hlokahala ho qoba meeli ea `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}