//! Mefuta e kengoang data sebakeng sa eona ka mohopolo.
//!
//! Ka linako tse ling ho bohlokoa ho ba le lintho tse netefalitsoeng hore li ke ke tsa sisinyeha, ka kutloisiso ea hore ho beoa mohopolong ha ho fetohe, 'me ka hona ho ka tšeptjoa.
//! Mohlala o ka sehloohong oa boemo bo joalo e ka ba ho aha mekhahlelo e ikemetseng, hobane ho tsamaisa ntho e nang le litsupa ho eona ho tla li nyopisa, tse ka bakang boits'oaro bo sa hlaloseheng.
//!
//! Boemong bo phahameng, [`Pin<P>`] e netefatsa hore pointee ea mofuta ofe kapa ofe oa pointer `P` e na le sebaka se tsitsitseng mohopolong, ho bolelang hore e ke ke ea fallisetsoa kae kapa kae mme memori ea eona e ke ke ea tsamaisoa ho fihlela e oela.Re re pointee ke "pinned".Lintho li ba masene haholo ha ho buisanoa ka mefuta e kopanyang e kengoe le data e sa manngoeng;[see below](#projections-and-structural-pinning) bakeng sa lintlha tse ling.
//!
//! Ka boiketsetso, mefuta eohle ea Rust e ka tsamaisoa.
//! Rust e lumella ho fetisa mefuta eohle ka boleng, 'me mefuta e tloaelehileng ea li-smart-pointer joalo ka [`Box<T>`] le `&mut T` e lumella ho tlosa le ho tsamaisa melao eo e nang le eona: o ka tsoa [`Box<T>`], kapa o ka sebelisa [`mem::swap`].
//! [`Pin<P>`] Koahela mofuta oa sesupa `P`, kahoo [`Pin`]`<<`[`Box`] `<T>>`e sebetsa joalo ka tloaelo
//!
//! [`Box<T>`]: when a [`Pin`]`<<[`Lebokose`]`<T>> `e oa, joalo le ka litaba tsa eona, 'me memori ea qala
//!
//! tsamaisoa.Ka mokhoa o ts'oanang, [`Pin`]`<&mut T>`e tšoana haholo le `&mut T`.Leha ho le joalo, [`Pin<P>`] ha e lumelle bareki ho fumana [`Box<T>`] kapa `&mut T` ho data e hatisitsoeng, e bolelang hore u ke ke ua sebelisa lits'ebetso tse kang [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` e hloka `&mut T`, empa re sitoa ho e fumana.
//!     // Re ntse re khomaretse, re ke ke ra fapanyetsana le litaba tsa litšupiso tsena.
//!     // Re ka sebelisa `Pin::get_unchecked_mut`, empa seo ha sea bolokeha ka lebaka:
//!     // ha rea lumelloa ho e sebelisa bakeng sa ho tlosa lintho ka ntle ho `Pin`.
//! }
//! ```
//!
//! Ke habohlokoa ho pheta hore [`Pin<P>`] ha e fetole taba ea hore moqapi oa Rust o nka mefuta eohle e ka tsamaisoa.[`mem::swap`] e lula e ka letsetsoa `T` efe kapa efe.Sebakeng seo, [`Pin<P>`] e thibela boleng bo itseng ba * (bo supiloe ke litsupa tse phuthetsoeng ka [`Pin<P>`]) hore li se ke tsa tsamaisoa ka ho etsa hore ho be thata ho letsetsa mekhoa e hlokang `&mut T` ho tsona (joalo ka [`mem::swap`])
//!
//! [`Pin<P>`] e ka sebelisoa ho thatela mofuta ofe kapa ofe oa sesupi `P`, ka hona e sebelisana le [`Deref`] le [`DerefMut`].[`Pin<P>`] moo `P: Deref` e lokelang ho nkuoa e le "`P`-style pointer" ho `P::Target` e tšoaetsoeng-ka hona, [`Pin`]`<<`[`Box`] `<T>>`ke sesupi se nang le XP3X, le [`Pin`] `<<` [`Rc`]`<T>>`ke sesupa-palo se baloang ho sephutheloana sa `T`.
//! Bakeng sa ho nepahala, [`Pin<P>`] e itšetleha ka ts'ebetsong ea [`Deref`] le [`DerefMut`] hore e se ke ea tsoa parameng ea bona ea `self`, 'me e kile ea khutlisetsa sesupi ho data e hatisitsoeng ha e bitsoa pointer e pentiloeng.
//!
//! # `Unpin`
//!
//! Mefuta e mengata e lula e tsamaisoa ka bolokolohi, leha e kengoe, hobane ha e itšetlehe ka ho ba le aterese e tsitsitseng.Sena se kenyelletsa mefuta eohle ea mantlha (joalo ka [`bool`], [`i32`], le litšupiso) hammoho le mefuta e nang le mefuta ena feela.Mefuta e sa tsotelleng ho pinning e kenya ts'ebetsong [`Unpin`] auto-trait, e hlakolang phello ea [`Pin<P>`].
//! Bakeng sa `T: Unpin`, [`Pin`]`<<[`Box`]`<T>> `le [`Box<T>`] e sebetsa ka mokhoa o ts'oanang, joalo ka [` Pin`]`<&mut T>` le `&mut T`.
//!
//! Hlokomela hore pinning le [`Unpin`] li ama feela mofuta o supang `P::Target`, eseng mofuta oa pointer `P` ka boeona e neng e thatetsoe ka [`Pin<P>`].Mohlala, hore na [`Box<T>`] ke [`Unpin`] ha ho na phello ho boitšoaro ba [`Pin`]`<<`[`Box`] `<T>>`(Mona, `T` ke mofuta o supiloeng).
//!
//! # Mohlala: boits'oaro bo ikemetseng
//!
//! Pele re kena lintlheng tse ling ho hlalosa netefatso le likhetho tse amanang le `Pin<T>`, re tšohla mehlala e meng ea hore na e ka sebelisoa joang.
//! Ikutloe u lokolohile ho [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ena ke sebopeho se ikemetseng hobane sengoathoana se supa tšimo ea data.
//! // Re ke ke ra tsebisa moqapi ka seo ka mokhoa o tloaelehileng, kaha paterone ena e ke ke ea hlalosoa ka melao e tloaelehileng ea kalimo.
//! //
//! // Sebakeng seo re sebelisa sesupa-tala, leha se tsejoa hore ha se na thuso, joalo ka ha re tseba se supa khoele.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ho etsa bonnete ba hore data ha e sisinyehe ha ts'ebetso e khutla, re e beha qubung moo e tla lula bophelo bohle ba ntho, mme tsela feela ea ho e fumana e ka ba ka sesupi ho eona.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // re theha sesupa feela ha data e se e le teng ho seng joalo e tla be e se e tsamaile le pele re qala
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // rea tseba hore sena se bolokehile hobane ho fetola tšimo ha ho tsamaise sebopeho sohle
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Sesupi se lokela ho supa sebaka se nepahetseng, ha feela moaho o sa sisinyehe.
//! //
//! // Khabareng, re lokolohile ho tsamaisa sesupa-hohle.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kaha mofuta oa rona ha o sebelise Unpin, sena se tla hloleha ho bokella:
//! // tlohella mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Mohlala: lenane le kenelletseng le kopaneng habeli
//!
//! Lethathamong le hokahaneng le kopaneng habeli, pokello ha e hlile e sa arole mohopolo bakeng sa likarolo ka botsona.
//! Kabo e laoloa ke bareki, 'me likarolo li ka phela ka sethala se lulang se le khuts'oane ho feta seo pokello e se etsang.
//!
//! Ho etsa mosebetsi ona, karolo e ngoe le e ngoe e na le lits'oants'o ho ea pele ho eena le mohlahlami lenaneng.Lintho li ka kenyelletsoa feela ha li kengoe, hobane ho tsamaisa likarolo ho ka etsa hore litsupiso li se sebetse.Ho feta moo, ts'ebetsong ea [`Drop`] ea lenane le hokahaneng e tla kopanya lits'oants'o tsa mohlahlami oa eona le mohlahlami oa eona ho itlosa lenaneng.
//!
//! Ka bohloka, re tlameha ho ts'epa hore [`drop`] e tla bitsoa.Haeba ntho e ka tsamaisoa kapa e sa sebetse ntle le ho bitsa [`drop`], litsupa tse ho eona tse tsoang linthong tsa eona tse haufi li ne li ke ke tsa sebetsa, tse neng li ka senya sebopeho sa data.
//!
//! Ka hona, pinning le eona e tla le tiiso e amanang le [`lerotholi"].
//!
//! # `Drop` guarantee
//!
//! Morero oa ho pinning ke ho khona ho itšetleha ka ho beoa ha data e ngoe mohopolong.
//! Ho etsa mosebetsi ona, ha ho tsamaisoe feela ke lintlha tse thibetsoeng;Ho tsamaisa, ho pheta-pheta hape, kapa ho etsa hore memori e sebelisitsoeng ho boloka lintlha e se sebetse le eona ea thibeloa.
//! Ka botshepehi, bakeng sa data e tšoaetsoeng o tlameha ho boloka e sa fetoheng hore *memori ea eona e ke ke ea felloa ke matla kapa ea nchafatsoa ho tloha ha e pikitloa ho fihlela ha [`drop`] e bitsoa*.Hang ha [`drop`] e khutla kapa panics, memori e ka sebelisoa bocha.
//!
//! Memori e ka ba "invalidated" ka translocation, empa hape ka ho nkela [`Some(v)`] ka [`None`], kapa ho letsetsa [`Vec::set_len`] ho "kill" likarolo tse ling tse tsoang vector.E ka khutlisoa hape ka ho sebelisa [`ptr::write`] ho e ngola hape ntle le ho letsetsa mosenyi pele.Ha ho le e 'ngoe ea tsena e lumelloang bakeng sa data e tšoaetsoeng ntle le ho letsetsa [`drop`].
//!
//! Ona ke mofuta oa netefatso ea hore lenane le hokahaneng le kenelletseng le tsoang karolong e fetileng le hloka ho sebetsa ka nepo.
//!
//! Hlokomela hore netefatso ena ha e bolele hore mohopolo ha o lutle!Ho ntse ho lokile ka ho felletseng hore o se ke oa letsetsa [`drop`] nthong e tšoaetsoeng (mohlala, o ntse o ka letsetsa [`mem::forget`] ho [`Pin`]`<<`[`Box`] `<T>>``).Mohlala oa lenane le hokahaneng habeli, karolo eo e ne e tla lula lenaneng.Leha ho le joalo o kanna oa se ke oa lokolla kapa oa sebelisa polokelo ntle le ho letsetsa [`drop`] *.
//!
//! # `Drop` implementation
//!
//! Haeba mofuta oa hau o sebelisa pinning (joalo ka mehlala e 'meli e kaholimo), o tlameha ho ba hlokolosi ha o kenya ts'ebetsong [`Drop`].Mosebetsi oa [`drop`] o nka `&mut self`, empa sena se bitsoa *le haeba mofuta oa hau o ne o kentsoe pejana*!Ho joalo ka ha mokopanyi a bitsoa [`Pin::get_unchecked_mut`] ka boiketsetso.
//!
//! Sena se ke ke sa baka bothata khoutu e bolokehileng hobane ho kenya tšebetsong mofuta o itšetlehileng ka ho pinana ho hloka khoutu e sa bolokehang, empa hlokomela hore ho nka qeto ea ho sebelisa pinning ka mofuta oa hau (mohlala ka ho kenya tšebetsong tšebetso e itseng ho [`Pin`]`<<Self>`kapa [`Pin`] `<&mut Self>` `) e na le litlamorao bakeng sa ts'ebetsong ea hau ea [`Drop`] hape: haeba ho na le karolo ea mofuta oa hau e kengoelitsoeng, o tlameha ho nka [`Drop`] joalo ka ha e nka ka botlalo [` Pin`]`<<&mut Boithati> `.
//!
//!
//! Mohlala, o ka kenya `Drop` ka tsela e latelang:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` ho lokile hobane rea tseba hore boleng bona ha bo sa sebelisoa hape kamora ho theoloa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Khoutu ea 'nete e theoha mona.
//!         }
//!     }
//! }
//! ```
//!
//! Ts'ebetso `inner_drop` e na le mofuta oo [`drop`] * e lokelang ho ba le oona, ka hona sena se etsa bonnete ba hore ha o sebelise `self`/`this` ka phoso ka tsela e hananang le pinning.
//!
//! Ho feta moo, haeba mofuta oa hau ke `#[repr(packed)]`, moqapi o tla tsamaisa masimo ka boiketsetso hore a tsebe ho a lihela.E kanna ea etsa joalo bakeng sa masimo a hokahaneng ka ho lekana.Ka lebaka leo, o ke ke oa sebelisa pinning ka mofuta oa `#[repr(packed)]`.
//!
//! # Lits'oants'o le Pinning ea Moralo
//!
//! Ha u sebetsa le li-pinch structs, ho hlaha potso ea hore na motho a ka fihlella joang masimong a struct eo ka mokhoa o nkang feela [`Pin`]`<&mut Struct>`.
//! Mokhoa o tloaelehileng ke ho ngola mekhoa ea bathusi (eo ho thoeng ke *projection*) e fetolang [`Pin`]`<&mut Struct>`ho supa tšimo, empa ts'upiso eo e lokela ho ba le mofuta oa eng?Na ke [`Pin`]`<&mut Field>`kapa `&mut Field`?
//! Potso e ts'oanang e hlaha ka masimo a `enum`, hape le ha ho nahanoa ka mefuta ea container/wrapper joalo ka [`Vec<T>`], [`Box<T>`], kapa [`RefCell<T>`].
//! (Potso ena e sebetsa ho litšupiso tse ka feto-fetohang le tse arolelanoeng, re mpa re sebelisa nyeoe e tloaelehileng ea litšupiso tse ka fetoloang mona bakeng sa papiso.)
//!
//! Hoa hlaha hore ho hlile ho ho mongoli oa sebopeho sa data ho etsa qeto ea hore na projeke e tšoaetsoeng tšimo e itseng e fetoha [`Pin`]`<&mut Struct>`into [[Pin`]" <&mut Field> `` or `&mut Field`.Ho na le litšitiso tse ling, mme tšitiso ea bohlokoahali ke ho se lumellane *:
//! Sebaka se seng le se seng se ka hlahisoa ho supa, kapa * ho tlosoa pinning e le karolo ea morero.
//! Haeba ka bobeli li etselitsoe tšimo e le 'ngoe, ho ka etsahala hore ebe ha ho na thuso!
//!
//! Joaloka moqapi oa sebopeho sa data o tlameha ho nka qeto bakeng sa sebaka ka seng hore na o pinning "propagates" lebaleng lena kapa che.
//! Ho penya tse phatlalatsang ho boetse ho bitsoa "structural", hobane e latela sebopeho sa mofuta.
//! Likarolong tse latelang re hlalosa lintlha tse lokelang ho etsoa bakeng sa khetho efe kapa efe.
//!
//! ## Ho penya * ha se sebopeho sa `field`
//!
//! Ho kanna ha utloahala ho sa lumellane le taba ea hore tšimo ea sebopeho se pentiloeng e kanna ea se manametsoe, empa eo ke khetho e bonolo ka ho fetesisa: haeba [`Pin`]`<&mut Field>`e sa ka ea hlola e etsoa, ha ho letho le ka senyehang!Kahoo, haeba u nka qeto ea hore tšimo e 'ngoe ha e na pinning ea sebopeho, sohle seo u tlamehang ho se etsa ke hore le ka mohla ha u bue ka tšupiso e tšoailoeng ea tšimo eo.
//!
//! Makala a se nang pinning ea sebopeho a kanna a ba le mokhoa oa projeke o fetolang [`Pin`]`<&mut Struct>`ho `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Sena se lokile hobane `field` ha ho mohla e nkuoang e hatelletsoe.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Le uena u ka ba `impl Unpin for Struct` * leha mofuta oa `field` e se [`Unpin`].Seo mofuta oo o se nahanang ka ho pinning ha se amehe ha ho se [`Pin`]`<&mut Field>`` e kileng ea etsoa.
//!
//! ## Ho pinning * ke sebopeho sa `field`
//!
//! Khetho e 'ngoe ke ho nka qeto ea hore pinning ke "structural" bakeng sa `field`, ho bolelang hore haeba sebopeho se kengoe joalo ka tšimo.
//!
//! Sena se lumella ho ngola moelelo o hlahisang [`Pin`]`<&mut Field>``, ka hona ho paka hore tšimo e manehiloe:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Sena se lokile hobane `field` e pinetsoe ha `self` e le.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Leha ho le joalo, pinning ea moralo e tla le litlhoko tse ling tse 'maloa:
//!
//! 1. Moralo o tlameha ho ba [`Unpin`] feela haeba likarolo tsohle tsa sebopeho e le [`Unpin`].Sena ke sa mantlha, empa [`Unpin`] ke trait e bolokehileng, ka hona ha mongoli oa struct e le boikarabello ba hau * eseng ho kenya ntho e kang `impl<T> Unpin for Struct<T>`.
//! (Hlokomela hore ho eketsa ts'ebetso ea projeke ho hloka khoutu e sa bolokehang, ka hona taba ea hore [`Unpin`] ke trait e sireletsehileng ha e robe molao-motheo oa hore o tlameha ho tšoenyeha ka eng kapa eng ea sena haeba o sebelisa `e sa bolokehang`.)
//! 2. Moferefere oa sebopeho ha a tlameha ho suthisa likarolo tsa sebopeho molemong oa ngangisano ea eona.Ena ke ntlha e tobileng e hlahisitsoeng ho [previous section][drop-impl]: `drop` e nka `&mut self`, empa sebopeho (mme ka hona masimo a sona) se kanna sa manehoa pejana.
//!     U tlameha ho netefatsa hore ha u tsamaise tšimo ka har'a ts'ebetsong ea hau ea [`Drop`].
//!     Haholo-holo, joalo ka ha ho hlalositsoe pejana, sena se bolela hore sebopeho sa hau ha se tlameha ho ba `#[repr(packed)]`.
//!     Bona karolo eo ea ho ngola [`drop`] ka tsela eo moqapi a ka u thusang hore u se ke oa roba pinning ka phoso.
//! 3. O tlameha ho etsa bonnete ba hore o boloka [`Drop` guarantee][drop-guarantee]:
//!     hang ha sebopeho sa hau se manehiloe, mohopolo o nang le litaba ha o ngolloe kapa ho tsamaisoa ntle le ho bitsa basenyi ba litaba.
//!     Sena e ka ba se qhekellang, joalo ka ha ho bone [`VecDeque<T>`]: mosenyi oa [`VecDeque<T>`] a ka hloleha ho letsetsa [`drop`] linthong tsohle haeba e le e mong oa basenyi panics.Sena se tlola tiiso ea [`Drop`], hobane e ka lebisa ho li-element tsa tsamaisoang ntle le hore mosenyi oa tsona a bitsoe.([`VecDeque<T>`] ha e na li-pinning, ka hona sena ha se bake ho hloka botsitso.)
//! 4. Ha ua lokela ho fana ka lits'ebetso tse ling tse ka lebisang ho data e tlosoe masimong ha mofuta oa hau o kengoe.Mohlala, haeba sebopeho se na le [`Option<T>`] mme ho na le ts'ebetso ea `nka 'le mofuta oa `fn(Pin<&mut Struct<T>>) -> Option<T>`, ts'ebetso eo e ka sebelisoa ho tsamaisa `T` ka thoko ho `Struct<T>`-ho bolelang hore ho pinning ho ke ke ha ba sebopeho sa lebala le ts'oereng sena data.
//!
//!     Bakeng sa mohlala o rarahaneng oa ho tsamaisa data ho tsoa mofuteng o pentiloeng, nahana hore na [`RefCell<T>`] e na le mokhoa oa `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Joale re ka etsa tse latelang:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Sena ke tlokotsi, ho bolela hore re ka qala ho maneha litaba tsa [`RefCell<T>`] (re sebelisa `RefCell::get_pin_mut`) ebe re tsamaisa litaba tseo re sebelisa mokhoa oo re ka o fetolang hamorao.
//!
//! ## Examples
//!
//! Bakeng sa mofuta o kang [`Vec<T>`], menyetla eo ka bobeli (pinning ea sebopeho kapa che) ea utloahala.
//! [`Vec<T>`] e nang le pinning ea sebopeho e ka ba le mekhoa ea `get_pin`/`get_pin_mut` ea ho supa litšupiso tsa likarolo.Leha ho le joalo, e ka se * lumelle ho letsetsa [`pop`][Vec::pop] ho [`Vec<T>`] e hatisitsoeng hobane seo se ka tsamaisa litaba tse (tse manehiloeng ka sebopeho)!Ebile e ke ke ea lumella [`push`][Vec::push], e ka fallang hape mme ka hona ea tsamaisa litaba.
//!
//! [`Vec<T>`] ntle le pinning ea sebopeho e ka ba `impl<T> Unpin for Vec<T>`, hobane ha ho mohla lintho tse ngotsoeng li manehiloeng 'me [`Vec<T>`] ka boeona e lokile ka ho tsamaisoa le eona.
//! Ka nako eo pinning ha e na tšusumetso ho vector ho hang.
//!
//! Laeboraring e tloaelehileng, mefuta ea sesupa ka kakaretso ha e na pinning ea sebopeho, ka hona ha e fane ka likhakanyo tsa pinning.Ke ka lebaka lena `Box<T>: Unpin` e ts'oereng `T` kaofela.
//! Hoa utloahala ho etsa sena bakeng sa mefuta ea pointer, hobane ho tsamaisa `Box<T>` ha e hlile ha e tsamaise `T`: [`Box<T>`] e ka tsamaisoa ka bolokolohi (aka `Unpin`) leha `T` e se joalo.Ebile, esita le [`Pin`]`<<["Box`]`<T>> `le [` Pin`]`<&mut T>` li lula li le [`Unpin`] ka bobona, ka lebaka le ts'oanang: litaba tsa tsona (`T`) li manehiloe, empa litsupa ka botsona li ka tsamaisoa ntle le ho tsamaisa lintlha tse tšoaetsoeng.
//! Bakeng sa [`Box<T>`] le [`Pin`]`<<`[`Box`] `<T>>`, hore na litaba li kentsoe kahare ho ikemetse ka botlalo hoba sesupa se kentsoe, ho bolelang hore ho pinning ha se * sebopeho.
//!
//! Ha o kenya tšebetsong motswako wa [`Future`], hangata o tla hloka phini ea sebopeho sa sehlaha sa futures, kaha o hloka ho fumana litšupiso tse tobisitsoeng ho bona ho letsetsa [`poll`].
//! Empa haeba motsoako oa hau o na le lintlha tse ling tse sa hlokeng ho maneoa, o ka etsa hore likarolo tseo e se tsa sebopeho mme ka hona o li fihlelle ka bolokolohi ka litšupiso tse ka feto-fetohang leha o na le [`Pin`]`<&mut Self>`` (joalo joalo ka ts'ebetsong ea hau ea [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Sesupa se hatisitsoeng.
///
/// Ena ke sekoaelo se potolohileng mofuta oa sesupi se etsang hore sesupi "pin" e be boleng ba sona, se thibela boleng bo boletsoeng ke sesupi hore bo sisinyehe ntle le hore bo sebelise [`Unpin`].
///
///
/// *Bona litokomane tsa [`pin` module] bakeng sa tlhaloso ea pinning.*
///
/// [`pin` module]: self
///
// Note: `Clone` e fumanoang ka tlase e baka ho hloka botsitso kamoo ho ka etsahalang
// `Clone` bakeng sa litšupiso tse ka feto-fetohang.
// Bona <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> bakeng sa lintlha tse ling.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ts'ebetsong e latelang ha e fumanoe molemong oa ho qoba mathata.
// `&self.pointer` ha ea lokela ho fihlelleha ts'ebetsong e sa ts'epahaleng ea trait.
//
// Bona <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> bakeng sa lintlha tse ling.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Theha `Pin<P>` e ncha ho potoloha sesupa-data ho mofuta o sebelisang [`Unpin`].
    ///
    /// Ho fapana le `Pin::new_unchecked`, mokhoa ona o bolokehile hobane pointer `P` e khetha mofuta oa [`Unpin`], e hlakolang li-pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // TSHIRELETSO: boleng bo supilweng ke `Unpin`, ka hona ha bo na litlhoko
        // ho pota pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// E notlolla `Pin<P>` ena e khutlisetsa sesupa-ntlha.
    ///
    /// Sena se hloka hore data e kahare ho `Pin` ke [`Unpin`] e le hore re ka iphapanya lintho tse hlaselang ha re li manolla.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Theha `Pin<P>` e ncha mabapi le lintlha tse ling tsa mofuta o ka sebelisang `Unpin` kapa o sa e sebeliseng.
    ///
    /// Haeba likhetho tsa `pointer` ho mofuta oa `Unpin`, `Pin::new` e lokela ho sebelisoa ho fapana.
    ///
    /// # Safety
    ///
    /// Sehahi sena ha se bolokehe hobane re ke ke ra tiisa hore lintlha tse supiloeng ke `pointer` li manamisitsoe, ho bolelang hore data e ke ke ea sisinyeha kapa polokelo ea eona ea senyeha ho fihlela e oa.
    /// Haeba `Pin<P>` e hahiloeng e sa fane ka tiiso ea hore lintlha tse `P` li supa li tšoaetsoe, hoo ke tlolo ea konteraka ea API mme ho ka lebisa ho boits'oaro bo sa hlalosoang liketsong tsa (safe) hamorao.
    ///
    /// Ka ho sebelisa mokhoa ona, o etsa promise mabapi le ts'ebetsong ea `P::Deref` le `P::DerefMut`, haeba e le teng.
    /// Habohlokoa ka ho fetisisa, ha baa tlameha ho tsoa likhang tsa bona tsa `self`: `Pin::as_mut` le `Pin::as_ref` ba tla letsetsa `DerefMut::deref_mut` le `Deref::deref`*ho sesupa se tšoaetsoeng*'me ba lebelle hore mekhoa ena e tla ts'ehetsa bahlaseli ba pinning.
    /// Ho feta moo, ka ho bitsa mokhoa ona o promise hore litšupiso tsa `P` ha li na ho tlosoa hape;haholoholo, ho tlameha hore ho se khonehe ho fumana `&mut P::Target` ebe o tsoa moo ho buuoang (ho sebelisoa, mohlala [`mem::swap`]).
    ///
    ///
    /// Mohlala, ho letsetsa `Pin::new_unchecked` ka `&'a mut T` ha ho bolokehe hobane ha o ntse o khona ho e maneha bakeng sa nako ea bophelo ea `'a`, ha o na taolo ea hore na e bolokiloe e kengoe hang ha `'a` e fela:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Sena se lokela ho bolela hore pointee `a` e ke ke ea hlola e sisinyeha hape.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Aterese ea `a` e fetohetse ho `b's stack slot, kahoo `a` e ile ea sisinyeha leha re ne re e pehile pejana!Re tlotse konteraka ea pinning API.
    /////
    /// }
    /// ```
    ///
    /// Boleng, hang ha bo pentiloe, bo tlameha ho lula bo tšoaetsoe ka ho sa feleng (ntle le haeba mofuta oa eona o sebelisa `Unpin`).
    ///
    /// Ka mokhoa o ts'oanang, ho letsetsa `Pin::new_unchecked` ka `Rc<T>` ha ho bolokehe hobane ho ka ba le liphapang ho data e le 'ngoe e seng tlasa lithibelo tsa pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Sena se lokela ho bolela hore pointee a ke ke a hlola a sisinyeha hape.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Joale, haeba `x` e ne e le eona feela tšupiso, re na le litšupiso tse ka feto-fetohang ho data eo re e kentseng kaholimo, eo re ka e sebelisang ho e tsamaisa joalo ka ha re bone mohlaleng o fetileng.
    ///     // Re tlotse konteraka ea pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// E fumana litšupiso tse arolelanoeng tse arolelanoeng ho tsoa sesupisong sena se hatisitsoeng.
    ///
    /// Ona ke mokhoa o tloaelehileng ho tloha `&Pin<Pointer<T>>` ho ea `Pin<&T>`.
    /// E bolokehile hobane, joalo ka karolo ea konteraka ea `Pin::new_unchecked`, pointee e ke ke ea sisinyeha kamora hore `Pin<Pointer<T>>` e thehe.
    ///
    /// "Malicious" Ts'ebetsong ea `Pointer::Deref` ka mokhoa o ts'oanang ha e lumelloe ke konteraka ea `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // TŠIRELETSO: bona litokomane mabapi le mosebetsi ona
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// E notlolla `Pin<P>` ena e khutlisetsa sesupa-ntlha.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ha e bolokehe.O tlameha ho netefatsa hore o tla tsoelapele ho ts'oara sesupa `P` joalo ka ha se kengoe kamora hore o bitse ts'ebetso ena, e le hore bahlaseli ba mofuta oa `Pin` ba ka ts'ehetsoa.
    /// Haeba khoutu e sebelisang sephetho sa `P` e sa tsoelepele ho boloka li-pinning tse kenang e le tlolo ea konteraka ea API mme e ka lebisa ho boits'oaro bo sa hlalosoang mesebetsing ea (safe) hamorao.
    ///
    ///
    /// Haeba data ea mantlha e le [`Unpin`], [`Pin::into_inner`] e lokela ho sebelisoa ho fapana.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// E fumana litšupiso tse ka fetotsoeng tse tsoang ponts'eng ena e hatisitsoeng.
    ///
    /// Ona ke mokhoa o tloaelehileng ho tloha `&mut Pin<Pointer<T>>` ho ea `Pin<&mut T>`.
    /// E bolokehile hobane, joalo ka karolo ea konteraka ea `Pin::new_unchecked`, pointee e ke ke ea sisinyeha kamora hore `Pin<Pointer<T>>` e thehe.
    ///
    /// "Malicious" Ts'ebetsong ea `Pointer::DerefMut` ka mokhoa o ts'oanang ha e lumelloe ke konteraka ea `Pin::new_unchecked`.
    ///
    /// Mokhoa ona o na le thuso ha o etsa li-call tse ngata ho isa lits'ebetsong tse jang mofuta o hoketsoeng.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // etsa ho hong
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` e sebelisa `self`, ka hona, khutlisa hape `Pin<&mut Self>` ka `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // TŠIRELETSO: bona litokomane mabapi le mosebetsi ona
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Fana ka boleng bo bocha mohopolong kamora se boletsoeng.
    ///
    /// Lintlha tsena li ngola lintlha tse hatisitsoeng, empa ho joalo: mosenyi oa eona o qala ho sebetsa pele a ngoloa, ka hona ha ho tiiso ea pinning e tlotsoeng.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// E theha phini e ncha ka ho etsa 'mapa oa boleng ba kahare.
    ///
    /// Mohlala, haeba u batla ho fumana `Pin` ea tšimo ea ho hong, u ka sebelisa sena ho fihlella tšimo eo moleng o le mong oa khoutu.
    /// Leha ho le joalo, ho na le li-gotcha tse 'maloa tse nang le tsena "pinning projections";
    /// bona litokomane tsa [`pin` module] bakeng sa lintlha tse ling ka taba eo.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ha e bolokehe.
    /// O tlameha ho netefatsa hore data eo o e khutlisang e ke ke ea tsamaea ha feela boleng ba khang bo sa sisinyehe (mohlala, hobane ke e 'ngoe ea likarolo tsa boleng boo), hape o sa tlohe ho ngangisano eo o e fumanang ho mosebetsi wa ka hare.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // TSHIRELETSO: konteraka ya polokeho ya `new_unchecked` e tlameha ho ba
        // ho tshoaroa ke ya letsitseng.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// E fumana litšupiso tse arolelanoeng ka phini.
    ///
    /// Sena se bolokehile hobane ho ke ke ha khoneha ho tsoa bukaneng e arolelanoeng.
    /// Ho kanna ha bonahala eka ho na le bothata mona ka phetoho ea kahare: haele hantle, ho ka khonahala ho tlosa `T` ho tsoa ho `&RefCell<T>`.
    /// Leha ho le joalo, sena ha se bothata ha feela ho se na `Pin<&T>` e supang lintlha tse ts'oanang, 'me `RefCell<T>` ha eu lumelle hore u thehe litšupiso tse tšoaetsoeng litaba tsa eona.
    ///
    /// Bona puisano ho ["pinning projections"] bakeng sa lintlha tse ling.
    ///
    /// Note: `Pin` e sebelisa `Deref` ho sepheo, se ka sebelisoang ho fihlella boleng ba kahare.
    /// Leha ho le joalo, `Deref` e fana feela ka ts'upiso e phelang ha feela ho alima `Pin`, eseng bophelo ba `Pin` ka boyona.
    /// Mokhoa ona o lumella ho fetola `Pin` ho e bua ka nako e tšoanang ea bophelo le `Pin` ea mantlha.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// E fetola `Pin<&mut T>` ena hore e be `Pin<&T>` ka nako e tšoanang ea bophelo.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// E fumana litšupiso tse ka fetoloang ho data e kahare ho `Pin` ena.
    ///
    /// Sena se hloka hore data e kahare ho `Pin` ke `Unpin`.
    ///
    /// Note: `Pin` e boetse e sebelisa `DerefMut` ho data, e ka sebelisoang ho fihlella boleng ba kahare.
    /// Leha ho le joalo, `DerefMut` e fana feela ka ts'upiso e phelang ha feela ho alima `Pin`, eseng bophelo ba `Pin` ka boyona.
    ///
    /// Mokhoa ona o lumella ho fetola `Pin` ho e bua ka nako e tšoanang ea bophelo le `Pin` ea mantlha.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// E fumana litšupiso tse ka fetoloang ho data e kahare ho `Pin` ena.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ha e bolokehe.
    /// O tlameha ho netefatsa hore ha ho mohla o tla tlosa data ho tsoa ts'ebetsong e ka fetoloang eo o e fumanang ha o letsetsa ts'ebetso ena, e le hore bahlaseli ba mofuta oa `Pin` ba ka ts'ehetsoa.
    ///
    ///
    /// Haeba data ea mantlha e le `Unpin`, `Pin::get_mut` e lokela ho sebelisoa ho fapana.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Theha phini e ncha ka ho etsa 'mapa oa boleng ba bokahare.
    ///
    /// Mohlala, haeba u batla ho fumana `Pin` ea tšimo ea ho hong, u ka sebelisa sena ho fihlella tšimo eo moleng o le mong oa khoutu.
    /// Leha ho le joalo, ho na le li-gotcha tse 'maloa tse nang le tsena "pinning projections";
    /// bona litokomane tsa [`pin` module] bakeng sa lintlha tse ling ka taba eo.
    ///
    /// # Safety
    ///
    /// Ts'ebetso ena ha e bolokehe.
    /// O tlameha ho netefatsa hore data eo o e khutlisang e ke ke ea tsamaea ha feela boleng ba khang bo sa sisinyehe (mohlala, hobane ke e 'ngoe ea likarolo tsa boleng boo), hape o sa tlohe ho ngangisano eo o e fumanang ho mosebetsi wa ka hare.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // TSHIRELETSO: moletsi o na le boikarabello ba ho se tsamaise
        // boleng bo tsoang bukeng ena.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // TSHIRELETSO: ka ha boleng ba `this` ho netefaditswe hore ha bo na yona
        // tlosoa, mohala ona oa `new_unchecked` o bolokehile.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Fumana litšupiso tse tšoaelitsoeng ho tsoa ho litšupiso tse emeng.
    ///
    /// Sena se bolokehile, hobane `T` e alimiloe bakeng sa `'static` ea bophelo bohle, e sa feleng.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // TSHIRELETSO: The 'static loan' e tiisa hore data e ke ke ea ba teng
        // moved/invalidated ho fihlela e oela (e leng ha ho mohla).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Fumana litšupiso tse fetotsoeng tse ka tšoauoang ho tsoa ponong e sa fetoheng e emeng.
    ///
    /// Sena se bolokehile, hobane `T` e alimiloe bakeng sa `'static` ea bophelo bohle, e sa feleng.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // TSHIRELETSO: The 'static loan' e tiisa hore data e ke ke ea ba teng
        // moved/invalidated ho fihlela e oela (e leng ha ho mohla).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: sena se bolela hore tlhahiso efe kapa efe ea `CoerceUnsized` e lumellang ho qobelloa ho tloha
// mofuta o kenyang `Deref<Target=impl !Unpin>` ho mofuta o kenyang `Deref<Target=Unpin>` ha o na kelello.
// Tlhahiso efe kapa efe e joalo e kanna ea ba e sa nepahala ka mabaka a mang, leha ho le joalo, kahoo re hloka feela ho ba hlokolosi hore re se lumelle li-impls tse joalo hore li lule std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}