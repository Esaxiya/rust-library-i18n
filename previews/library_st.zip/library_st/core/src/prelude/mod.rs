//! Libcore prelude
//!
//! Mojulu ona o etselitsoe basebelisi ba libcore tse sa amaneng le libstd hape.
//! Mojule ona o tlisoa ka boiketsetso ha `#![no_std]` e sebelisoa ka mokhoa o ts'oanang le laeborari e tloaelehileng ea prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Mofuta oa mantlha oa prelude oa 2015.
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Mofuta oa mantlha oa prelude oa 2018.
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Mofuta oa mantlha oa prelude oa 2021.
///
/// Bona [module-level documentation](self) bakeng sa tse ling.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Kenya lintho tse ling.
}