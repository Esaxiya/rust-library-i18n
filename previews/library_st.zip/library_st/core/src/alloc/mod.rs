//! Kabo ea memori APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Phoso ea `AllocError` e bonts'a ho hloleha ha kabo e ka bang ka lebaka la mokhathala oa lisebelisoa kapa ho hong ho fosahetseng ha o kopanya likhang tse kentsoeng tsa ho kenya le seabi sena.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (re hloka sena bakeng sa tlatsetso e tlase ea trait Phoso)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Ts'ebetsong ea `Allocator` e ka aba, ea hola, ea honyela le ho tsamaisa likhakanyo tsa tlhaiso-leseling tse hlalositsoeng ka [`Layout`][].
///
/// `Allocator` e etselitsoe hore e kenngoe tšebetsong ho li-ZST, litšupiso, kapa lits'oants'o tse bohlale hobane ho ba le seabi se kang `MyAlloc([u8; N])` ho ke ke ha sisinyeha, ntle le ho ntlafatsa li-pointer mohopolong o abetsoeng.
///
/// Ho fapana le [`GlobalAlloc`][], likabelo tsa boholo ba zero li lumelloa ho `Allocator`.
/// Haeba morekisi ea ipabolang a sa tšehetse sena (joalo ka jemalloc) kapa a khutlise pointer ea null (joalo ka `libc::malloc`), sena se tlameha ho ts'oaroa ke ts'ebetsong.
///
/// ### Khopolo e fanoeng hajoale
///
/// Mekhoa e meng e hloka hore memori block *e abeloe hona joale* ka ho e aba.Sena se bolela hore:
///
/// * aterese e qalang ea memory block eo e ne e khutlisitsoe pele ke [`allocate`], [`grow`], kapa [`shrink`], le
///
/// * memori block ha e so tsamaisoe kamora moo, moo li-block li tsamaisoang ka kotloloho ka ho fetisetsoa ho [`deallocate`] kapa li fetotsoe ka ho fetisetsoa ho [`grow`] kapa [`shrink`] e khutlisetsang `Ok`.
///
/// Haeba `grow` kapa `shrink` e khutlisitse `Err`, sesupa se fetisitsoeng se lula se sebetsa.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Ho loketse mohopolo
///
/// Mekhoa e meng e hloka hore moralo o lumellane le mohopolo.
/// Seo e se bolelang bakeng sa sebopeho sa "fit" memory block e bolela (kapa ka mokhoa o ts'oanang, bakeng sa memory block ho "fit" sebopeho) ke hore maemo a latelang a tlameha ho ts'oara:
///
/// * Boloko e tlameha ho abuoa ka tatellano e ts'oanang le [`layout.align()`], le
///
/// * [`layout.size()`] e fanoeng e tlameha ho oela ka har'a `min ..= max`, moo:
///   - `min` boholo ba sebopeho se sebelisitsoeng haufinyane ho abela block, 'me
///   - `max` boholo ba morao-rao bo khutlisitsoeng bo tsoa ho [`allocate`], [`grow`], kapa [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Likarete tsa memori tse khutlisitsoeng ho kabelo li lokela ho supa mohopolo o nepahetseng ebe li boloka bonnete ba tsona ho fihlela mohlala le li-clone tsohle tsa eona li oele,
///
/// * Ho kopanya kapa ho tsamaisa moabi ha hoa lokela ho etsa hore li-memory block tse khutlisitsoeng ho tsoa ho sesebelisoa sena li se sebetse.Morekisi ea hlophisitsoeng o tlameha ho itšoara joalo ka moabi a le mong, mme
///
/// * sesupi leha e le sefe se ka lebokoseng la memori e leng [*currently allocated*] se ka fetisetsoa mokhoeng o mong le o mong oa seabi.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Boiteko ba ho fana ka boloko ba mohopolo.
    ///
    /// Ha u atleha, e khutlisa seboka sa [`NonNull<[u8]>`][NonNull] ka boholo le tiiso ea tokiso ea `layout`.
    ///
    /// Sebaka se khutlisitsoeng se kanna sa ba le boholo bo boholo ho feta bo boletsoeng ke `layout.size()`, 'me se kanna sa qalisoa kapa se se na litaba tsa sona.
    ///
    /// # Errors
    ///
    /// Ho khutlisa `Err` ho bonts'a hore mohopolo o felile kapa `layout` ha e fihlelle boholo ba seabo kapa lithibelo tsa peakanyo.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa `Err` ka mokhathala oa mohopolo ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// E itšoara joaloka `allocate`, empa hape e netefatsa hore memori e khutlisitsoeng e qalisoa ka zero.
    ///
    /// # Errors
    ///
    /// Ho khutlisa `Err` ho bonts'a hore mohopolo o felile kapa `layout` ha e fihlelle boholo ba seabo kapa lithibelo tsa peakanyo.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa `Err` ka mokhathala oa mohopolo ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // TŠIRELETSO: `alloc` e khutlisa memori e nepahetseng
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// E tlosa mohopolo o boletsoeng ke `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` e tlameha ho bonts'a mohopolo oa [*currently allocated*] ka sesebelisoa sena, mme
    /// * `layout` e tlameha ho ba [*fit*] block eo ea memori.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Boiteko ba ho holisa mohopolo.
    ///
    /// E khutlisa [`NonNull<[u8]>`][NonNull] e ncha e nang le sesupa le boholo ba 'nete ba memori e fanoeng.Sesupi se loketse ho ts'oara lintlha tse hlalositsoeng ke `new_layout`.
    /// Ho etsa sena, kabelo e ka eketsa kabo e boletsoeng ke `ptr` ho lekana sebopeho se secha.
    ///
    /// Haeba sena se khutlisa `Ok`, joale ho ba mong'a memori block e boletsoeng ke `ptr` ho fetiselitsoe ho kabelo ena.
    /// Memori e kanna ea lokolloa kapa ea se ke ea lokolloa, 'me e lokela ho nkuoa e sa sebelisoe ntle leha e ka khutlisetsoa ho motho ea letsitseng hape ka boleng ba ho khutlisa mokhoa ona.
    ///
    /// Haeba mokhoa ona o khutlisa `Err`, ho ba mong'a memori block ha ho so fetisetsoe ho mofani oa sena, mme likahare tsa memory block ha lia fetoha.
    ///
    /// # Safety
    ///
    /// * `ptr` e tlameha ho supa palo ea memori [*currently allocated*] ka sesebelisoa sena.
    /// * `old_layout` e tlameha ho ba [*fit*] block of memory eo (Khang ea `new_layout` ha ea lokela ho e lekana.).
    /// * `new_layout.size()` e tlameha ho ba kholo ho feta kapa ho lekana le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// E khutlisa `Err` haeba sebopeho se secha se sa fihlelle boholo ba seabi le tatellano ea motsamaisi ea seabi, kapa haeba ho hola ka tsela e ngoe ho hloleha.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa `Err` ka mokhathala oa mohopolo ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TŠIRELETSO: hobane `new_layout.size()` e tlameha ho ba kholo ho feta kapa ho lekana le
        // `old_layout.size()`, Kabo ea mohopolo oa khale le e ncha e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tsa `old_layout.size()`.
        // Hape, hobane kabo ea khale e ne e so tsamaisoe, e ke ke ea feta `new_ptr`.
        // Kahoo, mohala oa `copy_nonoverlapping` o bolokehile.
        // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// E itšoara joaloka `grow`, empa hape e netefatsa hore litaba tse ncha li behiloe ho zero pele li khutlisoa.
    ///
    /// Sebaka sa memori se tla ba le litaba tse latelang kamora ho letsetsa ka katleho ho
    /// `grow_zeroed`:
    ///   * Li-byte `0..old_layout.size()` li bolokiloe ho tsoa kabo ea mantlha.
    ///   * Li-byte `old_layout.size()..old_size` li ka bolokoa kapa tsa fokotsoa, ho latela ts'ebetsong ea kabo.
    ///   `old_size` e bolela boholo ba memori pele ho mohala oa `grow_zeroed`, o kanna oa ba moholo ho feta boholo bo neng bo kopiloe qalong ha o ne o abuoa.
    ///   * Li-byte `old_size..new_size` ha li na thuso.`new_size` e bolela boholo ba memori e khutlisitsoeng ke mohala oa `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` e tlameha ho supa palo ea memori [*currently allocated*] ka sesebelisoa sena.
    /// * `old_layout` e tlameha ho ba [*fit*] block of memory eo (Khang ea `new_layout` ha ea lokela ho e lekana.).
    /// * `new_layout.size()` e tlameha ho ba kholo ho feta kapa ho lekana le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// E khutlisa `Err` haeba sebopeho se secha se sa fihlelle boholo ba seabi le tatellano ea motsamaisi ea seabi, kapa haeba ho hola ka tsela e ngoe ho hloleha.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa `Err` ka mokhathala oa mohopolo ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // TŠIRELETSO: hobane `new_layout.size()` e tlameha ho ba kholo ho feta kapa ho lekana le
        // `old_layout.size()`, Kabo ea mohopolo oa khale le e ncha e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tsa `old_layout.size()`.
        // Hape, hobane kabo ea khale e ne e so tsamaisoe, e ke ke ea feta `new_ptr`.
        // Kahoo, mohala oa `copy_nonoverlapping` o bolokehile.
        // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Boiteko ba ho fokotsa mohopolo.
    ///
    /// E khutlisa [`NonNull<[u8]>`][NonNull] e ncha e nang le sesupa le boholo ba 'nete ba memori e fanoeng.Sesupi se loketse ho ts'oara lintlha tse hlalositsoeng ke `new_layout`.
    /// Ho etsa sena, kabelo e ka fokotsa kabelo e boletsoeng ke `ptr` ho lekana sebopeho se secha.
    ///
    /// Haeba sena se khutlisa `Ok`, joale ho ba mong'a memori block e boletsoeng ke `ptr` ho fetiselitsoe ho kabelo ena.
    /// Memori e kanna ea lokolloa kapa ea se ke ea lokolloa, 'me e lokela ho nkuoa e sa sebelisoe ntle leha e ka khutlisetsoa ho motho ea letsitseng hape ka boleng ba ho khutlisa mokhoa ona.
    ///
    /// Haeba mokhoa ona o khutlisa `Err`, ho ba mong'a memori block ha ho so fetisetsoe ho mofani oa sena, mme likahare tsa memory block ha lia fetoha.
    ///
    /// # Safety
    ///
    /// * `ptr` e tlameha ho supa palo ea memori [*currently allocated*] ka sesebelisoa sena.
    /// * `old_layout` e tlameha ho ba [*fit*] block of memory eo (Khang ea `new_layout` ha ea lokela ho e lekana.).
    /// * `new_layout.size()` e tlameha ho ba nyane ho feta kapa ho lekana le `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// E khutlisa `Err` haeba sebopeho se secha se sa fihlelle boholo ba seabi le tatellano ea motsamaisi ea seabi, kapa haeba ho fokotseha ka tsela e ngoe ho hloleha.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa `Err` ka mokhathala oa mohopolo ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // TSHIRELETSO: hobane `new_layout.size()` e tlameha ho ba tlase ho feta kapa ho lekana le
        // `old_layout.size()`, Kabo ea mohopolo oa khale le e ncha e nepahetse bakeng sa ho baloa ebile e ngolla li-byte tsa `new_layout.size()`.
        // Hape, hobane kabo ea khale e ne e so tsamaisoe, e ke ke ea feta `new_ptr`.
        // Kahoo, mohala oa `copy_nonoverlapping` o bolokehile.
        // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// E etsa adapta ea "by reference" ketsahalong ena ea `Allocator`.
    ///
    /// Adapter e khutlisitsoeng e boetse e sebelisa `Allocator` mme e tla alima sena habonolo feela.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // TSHIRELETSO: konteraka ya polokeho e tlameha ho bolokwa ke moletsi
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TSHIRELETSO: konteraka ya polokeho e tlameha ho bolokwa ke moletsi
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TSHIRELETSO: konteraka ya polokeho e tlameha ho bolokwa ke moletsi
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // TSHIRELETSO: konteraka ya polokeho e tlameha ho bolokwa ke moletsi
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}