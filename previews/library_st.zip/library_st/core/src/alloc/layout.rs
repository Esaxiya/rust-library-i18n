use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ha ts'ebetso ena e sebelisoa sebakeng se le seng mme ts'ebetsong ea eona e ka tšoaetsoa, liteko tsa pele tsa ho etsa joalo li entse rustc butle butle:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Sebopeho sa mohopolo.
///
/// Mohlala oa `Layout` o hlalosa sebopeho se itseng sa mohopolo.
/// U haha `Layout` e le seabo ho fa seabi.
///
/// Lisebelisoa tsohle li na le boholo bo amanang le tatellano ea matla a mabeli.
///
/// (Hlokomela hore meralo * ha e ea hlokahala hore e be le boholo bo se nang zero, leha `GlobalAlloc` e hloka hore likopo tsohle tsa memori li se boholo ba zero.
/// Moletsi o tlameha ho netefatsa hore maemo a kang ana a ea fihlelleha, a sebelise baabi ba itseng ba nang le litlhoko tse hlephileng, kapa a sebelise sebopeho se bonolo sa `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // boholo ba mohopolo oa mohopolo o kopiloeng, o lekantsoeng ka li-byte.
    size_: usize,

    // tatellano ea mohopolo oa mohopolo o kopiloeng, o lekantsoeng ka li-byte.
    // re netefatsa hore kamehla ena ke matla a mabeli, hobane li-API joalo ka `posix_memalign` lia e hloka ebile ke tšitiso e utloahalang ea ho qobella lihahi tsa Moralo.
    //
    //
    // (Leha ho le joalo, ha re batle ka mokhoa o ts'oanang `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// E theha `Layout` ho tsoa ho `size` le `align`, kapa e khutlisa `LayoutError` haeba maemo afe kapa afe a latelang a sa fihlelloe:
    ///
    /// * `align` ha ea lokela ho ba lefela,
    ///
    /// * `align` e tlameha ho ba matla a mabeli,
    ///
    /// * `size`, ha e bokelloa ho palo e haufi ea `align`, ha ea lokela ho phalla (ke hore, boleng bo lekaneng bo tlameha ho ba tlase ho kapa bo lekane le `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (matla a mabeli a bolela ho hokahanya!=0.)

        // Boholo bo hlophisitsoeng ke:
        //   size_rounded_up=(size + align, 1)&! (hokahanya, 1);
        //
        // Re tseba ho tsoa holimo hore align!=0.
        // Haeba ho eketsa (align, 1) ho sa khaphatsehe, ho phethela ho tla loka.
        //
        // Ka lehlakoreng le leng,&-masking le! (Align, 1) e tla tlosa li-bits tsa tlase feela.
        // Kahoo ha phallo e hlaha ka kakaretso,&-mask e ke ke ea tlosa ho lekana ho etsolla phallo eo.
        //
        //
        // Ka holimo ho bolela hore ho lekola kakaretso ea kakaretso ho hlokahala ebile hoa lekana.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // TSHIRELETSO: maemo a `from_size_align_unchecked` esale a le teng
        // hlahlobiloe ka holimo.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// E etsa moralo, e feta licheke tsohle.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe kaha ha o netefatse maemo a tsoang ho [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `align` e feta zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Boholo ba bonyane ba li-byte bakeng sa memori ea mofuta ona.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Boholo ba tatellano ea byte bakeng sa memori ea sebopeho sena.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// E theha `Layout` e loketseng ho boloka boleng ba mofuta `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // TSHIRELETSO: align e netefalitsoe ke Rust ho ba matla a mabeli le
        // boholo ba + align combo bo netefalitsoe hore bo lekana sebakeng sa rona sa aterese.
        // Ka lebaka leo sebelisa sehahi se sa hlahlojoang mona ho qoba ho kenya khoutu ea panics haeba e sa ntlafatsoa hantle.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// E hlahisa sebopeho se hlalosang rekoto e ka sebelisoang ho fana ka sebopeho sa tšehetso bakeng sa `T` (e ka bang trait kapa mofuta o mong o sa lekanngoeng joalo ka selae).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TSHIRELETSO: bona mabaka ho `new` hore hobaneng sena se sebedisa phapang e sa bolokehang
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// E hlahisa sebopeho se hlalosang rekoto e ka sebelisoang ho fana ka sebopeho sa tšehetso bakeng sa `T` (e ka bang trait kapa mofuta o mong o sa lekanngoeng joalo ka selae).
    ///
    /// # Safety
    ///
    /// Mosebetsi ona o bolokehile feela hore o ka letsetsoa haeba maemo a latelang a le teng:
    ///
    /// - Haeba `T` ke `Sized`, ts'ebetso ena e lula e bolokehile ho e letsetsa.
    /// - Haeba mohatla o sa lekanyetsoang oa `T` ke:
    ///     - [slice], ebe bolelele ba mohatla oa selae e tlameha ho ba palo e lekantsoeng, mme boholo ba *boleng bo felletseng*(bolelele ba mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
    ///     - [trait object], ebe karolo ea vtable ea pointer e tlameha ho supa vtable e nepahetseng bakeng sa mofuta `T` e fumanoeng ka coersion e sa lekanyetsoang, mme boholo ba *boleng kaofela*(matla a mohatla o matla + le selelekela sa boholo ba lipalo) bo tlameha ho lekana `isize`.
    ///
    ///     - (unstable) [extern type], ebe ts'ebetso ena e lula e bolokehile ho e letsetsa, empa e kanna eaba panic kapa e khutlisa boleng bo fosahetseng, joalo ka ha sebopeho sa mofuta oa kantle se sa tsejoe.
    ///     Ena ke boits'oaro bo ts'oanang le [`Layout::for_value`] ha ho buuoa ka mohatla oa mofuta o kantle.
    ///     - ho seng joalo, ka mokhoa o bolokehileng ha oa lumelloa ho bitsa ts'ebetso ena.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // POLOKEHO: re fetisetsa lintho tse hlokahalang ho mesebetsi ena ho ea letsitseng
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // TSHIRELETSO: bona mabaka ho `new` hore hobaneng sena se sebedisa phapang e sa bolokehang
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// E etsa `NonNull` e leketlileng, empa e hokahane hantle bakeng sa Sebopeho sena.
    ///
    /// Hlokomela hore boleng ba sesupi bo kanna ba emela sesupa se nepahetseng, ho bolelang hore sena ha sea lokela ho sebelisoa e le boleng ba "not yet initialized" ba sentinel.
    /// Mefuta e fanang ka botsoa e tlameha ho latedisa ho qala ka mekhoa e meng.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // TS'ireletso: ho hokahana ho netefalitsoe hore ha ho letho
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// E theha moralo o hlalosang rekoto e ka ts'oereng boleng ba sebopeho se ts'oanang le `self`, empa le eona e hokahane le tatellano ea `align` (e lekantsoe ka li-byte).
    ///
    ///
    /// Haeba `self` e se e ntse e kopana le tatellano e behiloeng, e khutlise `self`.
    ///
    /// Hlokomela hore mokhoa ona ha o kenye padding ho boholo ka kakaretso, ho sa tsotelehe hore na sebopeho se khutlisitsoeng se na le tatellano e fapaneng.
    /// Ka mantsoe a mang, haeba `K` e na le boholo ba 16, `K.align_to(32)` e ntse e tla ba le boholo ba 16.
    ///
    /// E khutlisa phoso haeba motsoako oa `self.size()` le `align` e fanoeng li tlola maemo a thathamisitsoeng ho [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// E khutlisa palo eo re lokelang ho e kenya kamora `self` ho netefatsa hore aterese e latelang e tla khotsofatsa `align` (e lekantsoe ka li-byte).
    ///
    /// Mohlala, haeba `self.size()` e 9, `self.padding_needed_for(4)` e khutlisa 3, hobane eo ke palo e tlase ea li-byte tsa padding tse hlokahalang ho fumana aterese e tsamaellaneng le 4 (ho nka hore memori e lumellanang e qala atereseng e tsamaisitsoeng ka 4).
    ///
    ///
    /// Boleng ba ho khutlisa ts'ebetso ena ha bo na moelelo haeba `align` e se matla a mabeli.
    ///
    /// Hlokomela hore ts'ebeliso ea boleng bo khutlisitsoeng e hloka hore `align` e be tlase kapa e lekane le tatellano ea aterese e qalang bakeng sa mohopolo oohle o abetsoeng mohopolo.Mokhoa o mong oa ho khotsofatsa tšitiso ena ke ho netefatsa `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Boleng bo hlophisitsoeng ke:
        //   len_rounded_up=(len + align, 1)&! (hokahanya, 1);
        // ebe re khutlisa phapang ea padding: `len_rounded_up - len`.
        //
        // Re sebelisa arithmetic modular hohle:
        //
        // 1. align e netefalitsoe ho ba> 0, ka hona, hokahanya, 1 e sebetsa kamehla.
        //
        // 2.
        // `len + align - 1` e ka khaphatseha ka boholo ba `align - 1`, ka hona&-mask e nang le `!(align - 1)` e tla netefatsa hore haeba e khaphatseha, `len_rounded_up` ka boeona e tla ba 0.
        //
        //    Ka hona, padding e khutlisitsoeng, ha e kenyelletsoa ho `len`, e hlahisa 0, e khotsofatsang hanyane ho hokahana `align`.
        //
        // (Ehlile, liteko tsa ho abela li-block tsa memori tseo boholo ba tsona le padding li khaphatsehang ka tsela e kaholimo li lokela ho baka hore morekisi a hlahise phoso leha ho le joalo.
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// E theha moralo ka ho potoloha boholo ba moaho ona ho fihlela tatellano ea tatellano.
    ///
    ///
    /// Sena se lekana le ho eketsa sephetho sa `padding_needed_for` ho boholo ba hona joale ba sebopeho.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Sena se ka se khaphatsehe.Ho qotsa ho sa fetoheng ha Sebopeho:
        // > `size`, ha u qeta ho fumana linomoro tse haufi tsa `align`,
        // > ha ea lokela ho phalla (ke hore, boleng bo lekaneng bo tlameha ho ba tlase ho
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// E theha moralo o hlalosang rekoto bakeng sa maemo a `n` a `self`, ka palo e loketseng ea ho pata pakeng tsa e 'ngoe le e' ngoe ho netefatsa hore mohlala o mong le o mong o fuoa boholo le tatellano ea ona.
    /// Ha u atleha, u khutlisa `(k, offs)` moo `k` e leng moralo oa sehlopha mme `offs` ke sebaka se pakeng tsa qaleho ea karolo ka 'ngoe sehlopheng.
    ///
    /// Ho phallo ea lipalo, e khutlisa `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Sena se ka se khaphatsehe.Ho qotsa ho sa fetoheng ha Sebopeho:
        // > `size`, ha u qeta ho fumana linomoro tse haufi tsa `align`,
        // > ha ea lokela ho phalla (ke hore, boleng bo lekaneng bo tlameha ho ba tlase ho
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // TSHIRELETSO: self.align e se e tsejwa e le e nepahetseng mme alloc_size esale e le teng
        // e se e kentsoe.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// E theha moralo o hlalosang rekoto ea `self` e lateloe ke `next`, ho kenyeletsoa le padding efe kapa efe e hlokahalang ho netefatsa hore `next` e hokahane hantle, empa *ha ho na trailing padding*.
    ///
    /// Bakeng sa ho bapisa C sebopeho sa boemeli `repr(C)`, o lokela ho letsetsa `pad_to_align` kamora ho holisa sebopeho le likarolo tsohle.
    /// (Ha ho na mokhoa oa ho bapisa sebopeho sa boemeli ba Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Hlokomela hore peakanyo ea sebopeho se hlahisoang e tla ba boholo ba `self` le `next`, molemong oa ho netefatsa tatellano ea likarolo tseo ka bobeli.
    ///
    /// E khutlisa `Ok((k, offset))`, moo `k` e leng sebopeho sa rekoto e lumellanang 'me `offset` ke sebaka se amanang, ka li-byte, sa qalo ea `next` e kentsoeng ka har'a rekoto e netefalitsoeng (ho nka hore rekoto ka boeona e qala ka offset 0).
    ///
    ///
    /// Ho phallo ea lipalo, e khutlisa `LayoutError`.
    ///
    /// # Examples
    ///
    /// Ho bala moralo oa sebopeho sa `#[repr(C)]` le liphokotso tsa masimo ho tsoa mehahong ea masimo a ona:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Hopola ho phethela ka `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // leka hore e ea sebetsa
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// E theha moralo o hlalosang rekoto ea maemo a `n` a `self`, ho se na padding lipakeng tsa ketsahalo ka 'ngoe.
    ///
    /// Hlokomela hore, ho fapana le `repeat`, `repeat_packed` ha e fane ka tiiso ea hore maemo a phetoang a `self` a tla hokahana hantle, leha mohlala o fanoeng oa `self` o hokahane hantle.
    /// Ka mantsoe a mang, haeba sebopeho se khutlisitsoeng ke `repeat_packed` se sebelisetsoa ho abela sehlopha, ha ho netefatsoe hore likarolo tsohle tse ka hara sehlopha li tla hokahana hantle.
    ///
    /// Ho phallo ea lipalo, e khutlisa `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// E etsa moralo o hlalosang rekoto ea `self` e lateloe ke `next` ho se na padding e eketsehileng lipakeng tsa tsena tse peli.
    /// Kaha ha ho kenngoe padding, tatellano ea `next` ha e na thuso, 'me ha e kenyellelitsoe *ho hang* mohahong o hlahang.
    ///
    ///
    /// Ho phallo ea lipalo, e khutlisa `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// E etsa moralo o hlalosang rekoto ea `[T; n]`.
    ///
    /// Ho phallo ea lipalo, e khutlisa `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Meeli e fuoeng `Layout::from_size_align` kapa sehahi se seng sa `Layout` ha e khotsofatse lithibelo tsa eona tse ngotsoeng.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (re hloka sena bakeng sa tlatsetso e tlase ea trait Phoso)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}