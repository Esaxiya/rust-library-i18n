use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Morero oa mohopolo o ka ngolisoang e le oa mantlha oa laeborari ka sebopeho sa `#[global_allocator]`.
///
/// Mekhoa e meng e hloka hore memori block *e abeloe hona joale* ka ho e aba.Sena se bolela hore:
///
/// * aterese e qalang ea memori block e ne e khutlisitsoe pejana ke mohala o fetileng ho mokhoa oa kabo o kang `alloc`, le
///
/// * memori block ha e so tsamaisoe kamora moo, moo li-block li tsamaisoang teng ka ho fetisetsoa mokhoeng oa thekiso joalo ka `dealloc` kapa ka ho fetisetsoa ho mokhoa oa phalliso o khutlisang pointer eo e seng ea lefeela.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ke `unsafe` trait ka mabaka a 'maloa, mme baphethahatsi ba tlameha ho netefatsa hore ba latela likonteraka tsena:
///
/// * Ke boits'oaro bo sa hlalosoang haeba baabi ba lefats'e ba ka phutholoha.Thibelo ena e ka tlosoa ho future, empa hajoale panic ho tsoa ho efe kapa efe ea mesebetsi ena e ka baka ho se bolokehe mohopolong.
///
/// * `Layout` lipotso le lipalo ka kakaretso li tlameha ho nepahala.Batho ba letsetsang trait ena ba lumelloa ho itšetleha ka likonteraka tse hlalositsoeng mokhoeng o mong le o mong, mme baphethahatsi ba tlameha ho netefatsa hore likonteraka tse joalo li lula li le nnete.
///
/// * U kanna oa se ke oa ts'epa likabelo ha e le hantle li etsahala, leha ho na le likabelo tse hlakileng tsa qubu mohloling.
/// Se sebetsang hantle se ka fumana likabelo tse sa sebelisoeng se ka se felisang ka botlalo kapa sa fetela mokhoeng ebe ka hona ha se sa kopa moabi.
/// Setsi se ntlafatsang se kanna sa nahana hore kabo ha e na phoso, ka hona khoutu e neng e sa atlehe ka lebaka la ho hloleha ha moabi joale e ka sebetsa ka tšohanyetso hobane sebali se sebelitseng ho potoloha tlhoko ea kabo.
/// Ka mokhoa o ts'oanang, mohlala o latelang oa khoutu ha o na thuso, ho sa tsotelehe hore na moabi oa hau oa moetlo o lumella ho bala hore na likabo li kae tse etsahetseng.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Hlokomela hore litokisetso tse boletsoeng ka holimo ha se tsona feela ntlafatso tse ka sebelisoang.Ka kakaretso o kanna oa se ke oa ts'epa likabo tsa qubu ha li ka tlosoa ntle le ho fetola boits'oaro ba lenaneo.
///   Hore na likabo li etsahala kapa che ha se karolo ea boits'oaro ba lenaneo, leha e ka fumanoa ka seabi se latelang likabo ka ho hatisa kapa ho ba le litla-morao.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Abela memori joalo ka ha ho hlalositsoe ke `layout` e fanoeng.
    ///
    /// E khutlisetsa sesupi mohopolong o sa tsoa fuoa, kapa ha e na thuso ho bonts'a ho hloleha ha kabo.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe hobane boits'oaro bo sa hlalosoang bo ka hlaha haeba moletsi a sa netefatse hore `layout` ha e na boholo ba zero.
    ///
    /// (Lits'oants'o tsa katoloso li kanna tsa fana ka meeli e ikhethileng mabapi le boits'oaro, mohlala, netefatsa aterese ea sentinel kapa sesupi se sa sebetseng ho arabela kopo ea kabelo ea boholo ba zero.)
    ///
    /// Sebaka se hopotsoeng sa memori se kanna sa qalisoa kapa se ka se qaloe.
    ///
    /// # Errors
    ///
    /// Ho khutlisa sesupi se sa sebetseng ho supa hore mohopolo o felile kapa `layout` ha e fihlelle boholo ba moabi kapa lithibelo tsa peakanyo.
    ///
    /// Ts'ebetsong li khothaletsoa ho khutlisa ho tepella mohopolong ho fapana le ho ntša mpa, empa ena ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Fana ka sebaka sa memori ho pointer ea `ptr` e fanoeng ka `layout` e fanoeng.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe hobane boits'oaro bo sa hlaloseheng bo ka hlaha haeba moletsi a sa netefatse tse latelang kaofela:
    ///
    ///
    /// * `ptr` e tlameha ho supa mohopolo oa mohopolo o fanoeng ka seabi sena,
    ///
    /// * `layout` e tlameha ho ba sebopeho se ts'oanang se neng se sebelisetsoa ho abela block eo ea memori.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// E itšoara joaloka `alloc`, empa hape e netefatsa hore litaba li behiloe ho zero pele li khutlisoa.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe ka mabaka a tšoanang le a `alloc`.
    /// Leha ho le joalo karolo e bolokiloeng ea memori e netefalitsoe hore e tla qalisoa.
    ///
    /// # Errors
    ///
    /// Ho khutlisa sesupi se sa sebetseng ho supa hore mohopolo o felile kapa `layout` ha e fihlelle boholo ba seabo kapa lithibelo tsa peakanyo, joalo ka `alloc`.
    ///
    /// Bareki ba lakatsang ho hlakola lipalo ho arabela phoso ea kabo ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho hohella ka kotloloho `panic!` kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // TSHIRELETSO: konteraka ya polokeho ya `alloc` e tlameha ho bolokwa ke moletsi.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // TSHIRELETSO: kaha kabo e atlehile, sebaka ho tloha `ptr`
            // ea boholo ba `size` e netefalitsoe hore e tla sebetsa bakeng sa ho ngola.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Fokotsa kapa u holise mohopolo ho `new_size` eo u e filoeng.
    /// Sebaka se hlalosoa ke sesupi sa `ptr` le `layout`.
    ///
    /// Haeba sena se khutlisa sesupa-pono se se nang thuso, ho ba mong'a memori block e boletsoeng ke `ptr` ho fetiselitsoe ho kabelo ena.
    /// Memori e kanna ea tsamaisoa kapa ea se ke ea fallisoa, 'me e lokela ho nkuoa e sa sebelisoe (ntle le haeba e khutliselitsoe ho motho ea letsitseng hape ka boleng ba ho khutlisa mokhoa ona).
    /// Memori block e ncha e fanoe ka `layout`, empa ka `size` e ntlafalitsoe ho `new_size`.
    /// Sebopeho sena se secha se lokela ho sebelisoa ha ho tsamaisoa block block e ncha le `dealloc`.
    /// Mofuta oa `0..min(layout.size(), new_size) `oa block memory e ncha o netefalitsoe hore o tla ba le litekanyetso tse tšoanang le tsa block ea mantlha.
    ///
    /// Haeba mokhoa ona o khutla o se na thuso, ho ba mong'a memori block ha ho so fetisetsoe ho mofani oa sena, 'me litaba tsa block block ha lia fetoloa.
    ///
    /// # Safety
    ///
    /// Mosebetsi ona ha o bolokehe hobane boits'oaro bo sa hlaloseheng bo ka hlaha haeba moletsi a sa netefatse tse latelang kaofela:
    ///
    /// * `ptr` e tlameha ho abuoa hona joale ka mofani enoa,
    ///
    /// * `layout` e tlameha ho ba sebopeho se tšoanang se neng se sebelisetsoa ho fana ka mohopolo oo,
    ///
    /// * `new_size` e tlameha ho ba kholo ho feta lefela.
    ///
    /// * `new_size`, ha e bokelloa ho palo e haufi ea `layout.align()`, ha ea lokela ho phalla (ke hore, boleng bo lekaneng bo tlameha ho ba tlase ho `usize::MAX`).
    ///
    /// (Lits'oants'o tsa katoloso li kanna tsa fana ka meeli e ikhethileng mabapi le boits'oaro, mohlala, netefatsa aterese ea sentinel kapa sesupi se sa sebetseng ho arabela kopo ea kabelo ea boholo ba zero.)
    ///
    /// # Errors
    ///
    /// E khutlisa lefeela haeba sebopeho se secha se sa fihlelle lithibelo tsa boholo le peakanyo ea seabi, kapa haeba kabelo e ncha e sa atlehe.
    ///
    /// Ts'ebetso li khothaletsoa ho khutlisa mohopolo oa mokhathala ho fapana le ho tšoha kapa ho senya mpa, empa hona ha se tlhoko e thata.
    /// (Haholo-holo: ho *molaong* ho kenya ts'ebetsong trait e holim'a laebrari ea kabo ea matsoalloa e ipapisang le mokhathala oa mohopolo.)
    ///
    /// Bareki ba lakatsang ho ntša likhomphutha ho arabela phoso ea phalliso, ba khothaletsoa ho letsetsa mosebetsi oa [`handle_alloc_error`], ho fapana le ho kopa `panic!` ka kotloloho kapa e ts'oanang.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `new_size` ha e phalle.
        // `layout.align()` e tsoa ho `Layout` mme ka hona e netefalitsoe hore e nepahetse.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // TSHIRELETSO: moletsi o tlameha ho netefatsa hore `new_layout` e feta zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // TSHIRELETSO: block e neng e abilwe pejana e ke ke ya feta sebaka se sa tsoa abeloa.
            // Konteraka ea polokeho ea `dealloc` e tlameha ho bolokoa ke motho ea letsitseng.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}