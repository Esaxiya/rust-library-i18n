//! Melao ea boikhethelo.
//!
//! Mofuta oa [`Option`] o emela boleng ba boikhethelo: [`Option`] e ngoe le e ngoe e ka ba [`Some`] mme e na le boleng, kapa [`None`], 'me ha e na eona.
//! [`Option`] mefuta e atile haholo ho khoutu ea Rust, kaha li na le ts'ebeliso e 'maloa:
//!
//! * Litekanyetso tsa pele
//! * Khutlisa boleng ba mesebetsi e sa hlalosoang ho latela mefuta eohle ea ho kenya (mesebetsi e sa fellang)
//! * Khutlisa boleng ba ho tlaleha liphoso tse bonolo, moo [`None`] e khutlisoang ka phoso
//! * Boikhethelo struct masimo
//! * Hlopha masimo a ka alimiloeng kapa "taken"
//! * Likhetho tsa mosebetsi oa boikhethelo
//! * Litlhahiso tse sa sebetseng
//! * Ho tlosa lintho maemong a thata
//!
//! [`Option`] s hangata li kopanngoa le paterone e ts'oanang le ho botsa boteng ba boleng le ho nka bohato, kamehla ho ikarabella bakeng sa nyeoe ea [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Boleng ba ho khutla ba mosebetsi ke khetho
//! let result = divide(2.0, 3.0);
//!
//! // Papiso ea mohlala ho fumana boleng
//! match result {
//!     // Karohano e ne e sebetsa
//!     Some(x) => println!("Result: {}", x),
//!     // Karohano e ne e sa sebetse
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Bontša hore na `Option` e sebelisoa joang ts'ebetsong, ka mekhoa e mengata
//
//! # Khetho le litlhahiso (litsupa tsa "nullable")
//!
//! Mefuta ea sesupi ea Rust e tlameha ho lula e supa sebaka se nepahetseng;ha ho na litšupiso tsa "null".Sebakeng seo, Rust e na le lits'oants'o tsa boikhethelo, joalo ka lebokose la boikhethelo, [`Option`]``<` [`Box<T>`]`>`.
//!
//! Mohlala o latelang o sebelisa [`Option`] ho etsa lebokose la khetho la [`i32`].
//! Hlokomela hore molemong oa ho sebelisa boleng ba [`i32`] bo kahare pele, ts'ebetso ea `check_optional` e hloka ho sebelisa mokhoa o ts'oanang ho bona hore na lebokose le na le boleng (ke hore, ke [`Some(...)`][`Some`]) kapa ha ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust e tiisa ho ntlafatsa mefuta e latelang `T` hoo [`Option<T>`] e nang le boholo bo lekanang le `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` struct ho potoloha le leng la mefuta ea lenane lena.
//!
//! Ho netefatsoa hape hore, bakeng sa linyeoe tse kaholimo, motho a ka ba [`mem::transmute`] ho tsoa ho litekanyetso tsohle tse nepahetseng tsa `T` ho ea ho `Option<T>` le ho tloha `Some::<T>(_)` ho isa ho `T` (empa ho fetisetsa `None::<T>` ho `T` ke boits'oaro bo sa hlalosoang).
//!
//! # Examples
//!
//! Mokhoa oa mantlha o tšoanang le [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Bala ka khoele e nang le eona
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Tlosa khoele e nang le eona, u senye khetho ea Option
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Qala sephetho ho [`None`] pele ho lupu:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Lethathamo la lintlha tseo u lokelang ho li batlisisa.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Re tla batla lebitso la phoofolo e kholo ka ho fetisisa, empa ho qala feela re na le `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Joale re fumane lebitso la phoofolo e kholo
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// Mofuta oa `Option`.Bona [the module level documentation](self) bakeng sa tse ling.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Ha ho boleng
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Tse ling tsa boleng ba `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Mofuta oa ho kenya tšebetsong
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Ho pheta litekanyetso tse fumanehang
    /////////////////////////////////////////////////////////////////////////

    /// E khutlisa `true` haeba khetho e le boleng ba [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// E khutlisa `true` haeba khetho e le boleng ba [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// E khutlisa `true` haeba khetho e le boleng ba [`Some`] bo nang le boleng bo fanoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter bakeng sa ho sebetsa le litšupiso
    /////////////////////////////////////////////////////////////////////////

    /// E fetola ho tloha `&Option<T>` ho ea `Option<&T>`.
    ///
    /// # Examples
    ///
    /// E fetola `Khetho <` [`String`]`>`ho`Khetho <`[`usize`] `>`, ho boloka ea mantlha.
    /// Mokhoa oa [`map`] o nka khang ea `self` ka boleng, o sebelisa oa mantlha, ka hona mokhoa ona o sebelisa `as_ref` ho nka `Option` pele ho supa boleng bo kahare ho ea mantlha.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Taba ea mantlha, lahlela `Option<String>` ho `Option<&String>` ka `as_ref`, ebe u ja * le `map`, 'me u siee `text` ka mokoting.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// E fetola ho tloha `&mut Option<T>` ho isa ho `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// E fetoha ho tloha [`Pin`]`<&Khetho<T>>`ho`Khetho <`[``Pin`]`<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // TSHIRELETSO: `x` e netefaditswe hore e tlanngwe hobane e tswa ho `self`
        // e kengoelitsoeng.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// E fetoha ho tloha [`Pin`]`<&mut Option<T>>`ho`Khetho <`[`Pin`] `<<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // TŠIRELETSO: `get_unchecked_mut` ha e sebelisoe ho tsamaisa `Option` kahare ho `self`.
        // `x` e netefalitsoe hore e tlanngoe hobane e tsoa ho `self` e khethetsoeng.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ho fihlela melao ea boitšoaro
    /////////////////////////////////////////////////////////////////////////

    /// E khutlisa boleng ba [`Some`], e sebelisang boleng ba `self`.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng e le [`None`] ka molaetsa o tloaelehileng oa panic o fanoeng ke `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// E khutlisa boleng ba [`Some`], e sebelisang boleng ba `self`.
    ///
    /// Hobane ts'ebetso ena e kanna ea ba panic, ts'ebeliso ea eona ka kakaretso ha e khotsofale.
    /// Sebakeng seo, khetha ho sebelisa pattern matching le ho sebetsana le nyeoe ea [`None`] ka ho hlaka, kapa letsetsa [`unwrap_or`], [`unwrap_or_else`], kapa [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics haeba boleng ba hau bo lekana le [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// E khutlisa boleng ba [`Some`] bo nang le eona kapa ea kamehla e fanoeng.
    ///
    /// Likhang tse fetisitsoeng ho `unwrap_or` li hlahlojoa ka cheseho;haeba o fetisa sephetho sa mohala o sebetsang, ho kgothaletswa ho sebelisa [`unwrap_or_else`], e hlahlojoang ka botsoa.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// E khutlisa boleng ba [`Some`] e nang le eona kapa oa e bala ho tloha ha ho koaloa.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// E khutlisa boleng ba [`Some`], e sebelisa boleng ba `self`, ntle le ho lekola hore boleng ha se [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Ho letsetsa mokhoa ona ho [`None`] ke *[boits'oaro bo sa hlalosoang]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Boitšoaro bo sa hlalosoang!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // TSHIRELETSO: konteraka ya polokeho e tlameha ho bolokwa ke moletsi.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ho fetola melao-motheo e na le litekanyetso
    /////////////////////////////////////////////////////////////////////////

    /// 'Mapa ea `Option<T>` ho ea ho `Option<U>` ka ho sebelisa tšebetso ho boleng bo teng.
    ///
    /// # Examples
    ///
    /// E fetola `Khetho <` [`String`]`>`ho`Khetho <`[`usize`] `>`, ho sebelisa ea mantlha:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` e inkela boleng ba hau *, e ja `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// E kenya ts'ebetso ho boleng bo nang le eona (haeba e le teng), kapa e khutlisa sekhetho se fanoeng (haeba ho se joalo).
    ///
    /// Likhang tse fetisitsoeng ho `map_or` li hlahlojoa ka cheseho;haeba o fetisa sephetho sa mohala o sebetsang, ho kgothaletswa ho sebelisa [`map_or_else`], e hlahlojoang ka botsoa.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// E sebetsa ho boleng bo nang le boleng (haeba bo le teng), kapa e bala ea mantlha (haeba ho se joalo).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// E fetola `Option<T>` hore e be [`Result<T, E>`], 'mapa oa [`Some(v)`] ho [`Ok(v)`] le [`None`] ho [`Err(err)`].
    ///
    /// Likhang tse fetisitsoeng ho `ok_or` li hlahlojoa ka cheseho;haeba o fetisa sephetho sa mohala o sebetsang, ho kgothaletswa ho sebelisa [`ok_or_else`], e hlahlojoang ka botsoa.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// E fetola `Option<T>` hore e be [`Result<T, E>`], 'mapa oa [`Some(v)`] ho [`Ok(v)`] le [`None`] ho [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// E kenya `value` ho khetho ebe e khutlisetsa litšupiso ho eona.
    ///
    /// Haeba khetho e se e ntse e na le boleng, boleng ba khale bo oa.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // TS'ireletso: khoutu e kaholimo e tlatsitse khetho
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Baetsi ba Iterator
    /////////////////////////////////////////////////////////////////////////

    /// E khutlisetsa iterator ka holim'a boleng bo ka bang teng.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// E khutlisa seterator se ka fetohang ho feta boleng bo ka bang teng.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ts'ebetso ea Boolean mabapi le litekanyetso, e labalabela le ho ba botsoa
    /////////////////////////////////////////////////////////////////////////

    /// E khutlisa [`None`] haeba khetho e le [`None`], ho seng joalo e khutlisa `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// E khutlisa [`None`] haeba khetho e le [`None`], ho seng joalo e letsetsa `f` ka boleng bo phuthetsoeng ebe e khutlisa sephetho.
    ///
    ///
    /// Lipuo tse ling li bitsa ts'ebetso ena flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// E khutlisa [`None`] haeba khetho e le [`None`], ho seng joalo e letsetsa `predicate` ka boleng bo phuthetsoeng ebe ea khutla:
    ///
    ///
    /// - [`Some(t)`] haeba `predicate` e khutlisa `true` (moo `t` e leng boleng bo phuthetsoeng), le
    /// - [`None`] haeba `predicate` e khutlisa `false`.
    ///
    /// Mosebetsi ona o sebetsa ka tsela e ts'oanang le [`Iterator::filter()`].
    /// U ka inahanela hore `Option<T>` e ka ba iterator holim'a ntho e le 'ngoe kapa ea zero.
    /// `filter()` e u lumella ho nka qeto ea hore na u boloka lintho life.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// E khutlisa khetho haeba e na le boleng, ho seng joalo e khutlisa `optb`.
    ///
    /// Likhang tse fetisitsoeng ho `or` li hlahlojoa ka cheseho;haeba o fetisa sephetho sa mohala o sebetsang, ho kgothaletswa ho sebelisa [`or_else`], e hlahlojoang ka botsoa.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// E khutlisa khetho haeba e na le boleng, ho seng joalo e letsetsa `f` ebe e khutlisa sephetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// E khutlisa [`Some`] haeba e le 'ngoe ea `self`, `optb` ke [`Some`], ho seng joalo e khutlisa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Ts'ebetso e ts'oanang le ho kena ho kenya haeba e le sieo le ho khutlisa tšupiso
    /////////////////////////////////////////////////////////////////////////

    /// E kenya `value` ho khetho haeba e le [`None`], ebe e khutlisetsa litšupiso tse ka fetoloang ho boleng bo teng.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// E kenya boleng ba mantlha ho khetho haeba e le [`None`], ebe e khutlisetsa litšupiso tse ka fetoloang ho boleng bo nang le eona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// E kenya boleng bo bokelletsoeng ho tloha ho `f` ho ea ho khetho haeba e le [`None`], ebe e khutlisa litšupiso tse ka fetoloang ho boleng bo nang le eona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // TŠIRELETSO: mofuta oa `None` oa `self` o ka be o ile oa nkeloa sebaka ke `Some`
            // e fapaneng khoutu e kaholimo.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// E nka boleng ka khetho, e siea [`None`] sebakeng sa eona.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// E khutlisetsa boleng ba nnete ka khetho ka boleng bo fanoeng ka parameter, e khutlisa boleng ba khale haeba e le teng, e siea [`Some`] sebakeng sa eona ntle le ho hlakola e le 'ngoe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Zips `self` le `Option` e ngoe.
    ///
    /// Haeba `self` ke `Some(s)` 'me `other` ke `Some(o)`, mokhoa ona o khutlisa `Some((s, o))`.
    /// Ho seng joalo, `None` ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` le `Option` e 'ngoe e nang le ts'ebetso `f`.
    ///
    /// Haeba `self` ke `Some(s)` 'me `other` ke `Some(o)`, mokhoa ona o khutlisa `Some(f(s, o))`.
    /// Ho seng joalo, `None` ea khutlisoa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// 'Mapa oa `Option<&T>` ho ea ho `Option<T>` ka ho kopitsa likahare tsa khetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// 'Mapa oa `Option<&mut T>` ho ea ho `Option<T>` ka ho kopitsa likahare tsa khetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// 'Mapa oa `Option<&T>` ho ea ho `Option<T>` ka ho kopanya likahare tsa khetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// 'Mapa oa `Option<&mut T>` ho ea ho `Option<T>` ka ho kopanya likahare tsa khetho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// E sebelisa `self` ha e ntse e lebelletse [`None`] mme e sa khutlise letho.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng e le [`Some`], e nang le molaetsa oa panic ho kenyelletsa molaetsa o fetisitsoeng, le litaba tsa [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Sena ha se panic, hobane linotlolo tsohle li ikhethile.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// E sebelisa `self` ha e ntse e lebelletse [`None`] mme e sa khutlise letho.
    ///
    /// # Panics
    ///
    /// Panics haeba boleng e le [`Some`], ka molaetsa o tloaelehileng oa panic o fanoeng ke boleng ba [`Ba bang`].
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Sena ha se panic, hobane linotlolo tsohle li ikhethile.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// E khutlisa boleng bo nang le [`Some`] kapa ea kamehla
    ///
    /// E sebelisa khang ea `self` ka nako eo, haeba [`Some`], e khutlisa boleng bo nang le eona, ho seng joalo haeba [`None`], e khutlisa [default value] bakeng sa mofuta oo.
    ///
    ///
    /// # Examples
    ///
    /// E fetola khoele hore e be palo e felletseng, e fetola likhoele tse sa sebetsoang hantle hore e be 0 (boleng ba mantlha bakeng sa linomoro).
    /// [`parse`] e fetolela khoele ho mofuta o fe kapa o fe o sebelisang [`FromStr`], e khutlisetsang [`None`] ka phoso.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// E fetola ho tloha `Option<T>` (kapa `&Option<T>`) ho ea ho `Option<&T::Target>`.
    ///
    /// E siea Khetho ea mantlha sebakeng, e theha e ncha e bua ka ea mantlha, hape e qobella litaba ka [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// E fetola ho tloha `Option<T>` (kapa `&mut Option<T>`) ho ea ho `Option<&mut T::Target>`.
    ///
    /// E siea `Option` ea mantlha e le sebakeng, e theha e ncha e nang le ts'upiso e ka fetoloang ho mofuta oa `Deref::Target` oa mofuta o kahare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// E fetisetsa `Option` ea [`Result`] ho [`Result`] ea `Option`.
    ///
    /// [`None`] e tla etsoa 'mapa oa [`Ok`]`(`[`None`] `)`.
    /// [`Ba bang`]`(`[Ok`]` (_)) `le [` Ba bang`]`(`(`Err`]` (_)) `ba tla etsoa 'mapa oa [` Ok`]`(`[` Ba bang`]`(_))`le [`Liphoso`]` (_) `.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Ona ke mosebetsi o ikemetseng ho fokotsa boholo ba khoutu ea .expect() ka boeona.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Ona ke mosebetsi o ikemetseng ho fokotsa boholo ba khoutu ea .expect_none() ka boeona.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Ts'ebetsong ea Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// E khutlisa [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// E khutlisetsa seterator se jang ho feta boleng bo ka bang teng.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// E kopitsa `val` ho `Some` e ncha.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// E fetola ho tloha `&Option<T>` ho ea `Option<&T>`.
    ///
    /// # Examples
    ///
    /// E fetola `Khetho <` [`String`]`>`ho`Khetho <`[`usize`] `>`, ho boloka ea mantlha.
    /// Mokhoa oa [`map`] o nka khang ea `self` ka boleng, o sebelisa oa mantlha, ka hona mokhoa ona o sebelisa `as_ref` ho nka `Option` pele ho supa boleng bo kahare ho ea mantlha.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// E fetola ho tloha `&mut Option<T>` ho ea `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// The Iterators ea Khetho
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Iterator ha ho buuoa ka mofuta o fapaneng oa [`Some`] oa [`Option`].
///
/// Iterator e hlahisa boleng bo le bong haeba [`Option`] ke [`Some`], ho seng joalo ha e eo.
///
/// `struct` ena e entsoe ke mosebetsi oa [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Iterator ka lebaka la phetoho e ka feto-fetohang ho mofuta oa [`Some`] oa [`Option`].
///
/// Iterator e hlahisa boleng bo le bong haeba [`Option`] ke [`Some`], ho seng joalo ha e eo.
///
/// `struct` ena e entsoe ke mosebetsi oa [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Sesebelisoa se fetang boleng ho mofuta oa [`Some`] oa [`Option`].
///
/// Iterator e hlahisa boleng bo le bong haeba [`Option`] ke [`Some`], ho seng joalo ha e eo.
///
/// `struct` ena e entsoe ke mosebetsi oa [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// E nka ntho e ngoe le e ngoe ho [`Iterator`]: haeba ke [`None`][Option::None], ha ho sa nkuoa likarolo tse ling, 'me [`None`][Option::None] ea khutlisoa.
    /// Ha ho ka etsahala [`None`][Option::None], setshelo se nang le boleng ba [`Option`] ka 'ngoe sea khutlisoa.
    ///
    /// # Examples
    ///
    /// Mohlala ke ona o eketsang palo e ngoe le e ngoe ho vector.
    /// Re sebelisa mofuta o lekiloeng oa `add` o khutlisetsang `None` ha lipalo li ka baka phallo.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Joalokaha u bona, sena se tla khutlisa lintho tse lebelletsoeng, tse nepahetseng.
    ///
    /// Mohlala o mong ke ona o lekang ho tlosa le leng lenaneng la li-integer, lekhetlong lena o ntse o lekola hore na le tlaleha joang.
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Kaha ntlha ea hoqetela ke zero, e ne e tla tlala.Kahoo, boleng bo hlahisoang ke `None`.
    ///
    /// Phapang ke ena mohlaleng o fetileng, ho bonts'a hore ha ho likarolo tse ling tse nkuoang ho `iter` kamora `None` ea pele.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Kaha karolo ea boraro e bakile ho phalla, ha ho likarolo tse ling tse nkuoeng, ka hona boleng ba ho qetela ba `shared` ke 6 (= `3 + 2 + 1`), eseng 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Sena se ka nkeloa sebaka ke Iterator::scan ha ts'oaetso ena ea ts'ebetso e koetsoe.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Mofuta oa phoso o hlahisoang ke ho sebelisa sesebelisoa sa try (`?`) ho boleng ba `None`.
/// Haeba u lakatsa ho lumella `x?` (moo `x` e leng `Option<T>`) hore e fetohe mofuta oa phoso ea hau, u ka kenya `impl From<NoneError>` bakeng sa `YourErrorType`.
///
/// Tabeng eo, `x?` ka har'a ts'ebetso e khutlisetsang `Result<_, YourErrorType>` e tla fetolela boleng ba `None` ho sephetho sa `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// E fetola ho tloha `Option<Option<T>>` ho ea `Option<T>`
    ///
    /// # Examples
    ///
    /// Tšebeliso mantlha:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Ho batalatsa feela ho tlosa boemo bo le bong ba sehlaha ka nako.
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}