#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` e lumella morekisi oa moetsi oa mosebetsi ho etsa [`Waker`] e fanang ka boits'oaro bo ikhethileng ba ho tsoha.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// E na le sesupi sa data le [virtual function pointer table (vtable)][vtable] e hlophisitseng boitšoaro ba `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Sesupa-data, se ka sebelisoang ho boloka tlhaiso-leseling e hatellang joalo ka ha e hlokoa ke moabi.
    /// Sena e ka ba mohlala
    /// sesupi se hlakotsoeng ho `Arc` se amanang le mosebetsi.
    /// Boleng ba tšimo ena bo fetisetsoa mesebetsing eohle eo e leng karolo ea vtable joalo ka parameter ea pele.
    ///
    data: *const (),
    /// Tafole ea sesupo sa mosebetsi e hlophisitseng boitšoaro ba setsoso
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// E etsa `RawWaker` e ncha ho tsoa ho sesupi sa `data` se fanoeng le `vtable`.
    ///
    /// Pointer ea `data` e ka sebelisoa ho boloka lintlha tse sa hlokeng moelelo ho latela moahloli.Sena e ka ba mohlala
    /// sesupi se hlakotsoeng ho `Arc` se amanang le mosebetsi.
    /// Boleng ba sesupi sena bo tla fetisetsoa mesebetsing eohle eo e leng karolo ea `vtable` joalo ka parameter ea pele.
    ///
    /// `vtable` e hlophisa boitšoaro ba `Waker` e hlahisoang ho tloha ho `RawWaker`.
    /// Bakeng sa ts'ebetso e ngoe le e ngoe ea `Waker`, ts'ebetso e amanang le `vtable` ea `RawWaker` ea motheo e tla bitsoa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tafole ea sesupo sa mosebetsi (vtable) e hlalosang boits'oaro ba [`RawWaker`].
///
/// Sesupi se fetiselitsoeng mesebetsing eohle e ka har'a vtable ke sesupa sa `data` ho tsoa ho ntho e kentsoeng ea [`RawWaker`].
///
/// Mesebetsi e kahare ho sebopeho sena e reretsoe feela ho bitsoa pointer ea `data` ea ntho e hahiloeng hantle ea [`RawWaker`] ho tsoa kahare ho ts'ebetsong ea [`RawWaker`].
/// Ho letsetsa o mong oa mesebetsi e fuperoeng u sebelisa sesupi sefe kapa sefe sa `data` ho ka baka boits'oaro bo sa hlaloseheng
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Mosebetsi ona o tla bitsoa ha [`RawWaker`] e etsoa ka thata, mohlala, ha [`Waker`] eo [`RawWaker`] e bolokiloeng ho eona e hlophisoa.
    ///
    /// Ts'ebetsong ea ts'ebetso ena e tlameha ho boloka lisebelisoa tsohle tse hlokahalang molemong ona oa tlatsetso oa [`RawWaker`] le mosebetsi o amanang le ona.
    /// Ho letsetsa `wake` ho sephetho sa [`RawWaker`] ho lokela ho baka tsoho ea mosebetsi o ts'oanang o neng o ka tsosoa ke [`RawWaker`] ea mantlha.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ts'ebetso ena e tla bitsoa ha `wake` e bitsoa ho [`Waker`].
    /// E tlameha ho tsosa mosebetsi o amanang le [`RawWaker`] ena.
    ///
    /// Ts'ebetso ea ts'ebetso ena e tlameha ho etsa bonnete ba hore e lokolla lisebelisoa life kapa life tse amanang le ketsahalo ena ea [`RawWaker`] le mosebetsi o amanang le eona.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ts'ebetso ena e tla bitsoa ha `wake_by_ref` e bitsoa ho [`Waker`].
    /// E tlameha ho tsosa mosebetsi o amanang le [`RawWaker`] ena.
    ///
    /// Mosebetsi ona o ts'oana le `wake`, empa ha oa lokela ho sebelisa sesupa-data se fanoeng.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Mosebetsi ona o bitsoa ha [`RawWaker`] e theoha.
    ///
    /// Ts'ebetso ea ts'ebetso ena e tlameha ho etsa bonnete ba hore e lokolla lisebelisoa life kapa life tse amanang le ketsahalo ena ea [`RawWaker`] le mosebetsi o amanang le eona.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// E etsa `RawWakerVTable` e ncha ho tsoa lits'ebetsong tse fanoeng tsa `clone`, `wake`, `wake_by_ref`, le `drop`.
    ///
    /// # `clone`
    ///
    /// Mosebetsi ona o tla bitsoa ha [`RawWaker`] e etsoa ka thata, mohlala, ha [`Waker`] eo [`RawWaker`] e bolokiloeng ho eona e hlophisoa.
    ///
    /// Ts'ebetsong ea ts'ebetso ena e tlameha ho boloka lisebelisoa tsohle tse hlokahalang molemong ona oa tlatsetso oa [`RawWaker`] le mosebetsi o amanang le ona.
    /// Ho letsetsa `wake` ho sephetho sa [`RawWaker`] ho lokela ho baka tsoho ea mosebetsi o ts'oanang o neng o ka tsosoa ke [`RawWaker`] ea mantlha.
    ///
    /// # `wake`
    ///
    /// Ts'ebetso ena e tla bitsoa ha `wake` e bitsoa ho [`Waker`].
    /// E tlameha ho tsosa mosebetsi o amanang le [`RawWaker`] ena.
    ///
    /// Ts'ebetso ea ts'ebetso ena e tlameha ho etsa bonnete ba hore e lokolla lisebelisoa life kapa life tse amanang le ketsahalo ena ea [`RawWaker`] le mosebetsi o amanang le eona.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ts'ebetso ena e tla bitsoa ha `wake_by_ref` e bitsoa ho [`Waker`].
    /// E tlameha ho tsosa mosebetsi o amanang le [`RawWaker`] ena.
    ///
    /// Mosebetsi ona o ts'oana le `wake`, empa ha oa lokela ho sebelisa sesupa-data se fanoeng.
    ///
    /// # `drop`
    ///
    /// Mosebetsi ona o bitsoa ha [`RawWaker`] e theoha.
    ///
    /// Ts'ebetso ea ts'ebetso ena e tlameha ho etsa bonnete ba hore e lokolla lisebelisoa life kapa life tse amanang le ketsahalo ena ea [`RawWaker`] le mosebetsi o amanang le eona.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ea mosebetsi o ts'oanang.
///
/// Hajoale, `Context` e sebeletsa feela ho fana ka phihlello ho `&Waker` e ka sebelisoang ho tsosa mosebetsi oa hajoale.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Netefatsa hore re na le bopaki ba future khahlano le liphetoho tse fapaneng ka ho qobella nako ea bophelo hore e se fetohe (linako tsa bophelo tsa maemo a likhang lia fapana ha linako tsa bophelo tsa maemo a ho khutla li le teng).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Theha `Context` e ncha ho tloha `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// E khutlisetsa tšupiso ho `Waker` bakeng sa mosebetsi oa hona joale.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ke mohele oa ho tsosa mosebetsi ka ho tsebisa moetsi oa eona hore o ikemiselitse ho tsamaisoa.
///
/// Mohele ona o kenyelletsa mohlala oa [`RawWaker`], o hlalosang boits'oaro bo ikhethang ba ho tsoha.
///
///
/// E sebelisa [`Clone`], [`Send`], le [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Tsoha mosebetsi o amanang le `Waker` ena.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Mohala oa 'nete oa ho tsosa o fanoa ka mohala oa ts'ebetso o kenang ts'ebetsong o hlalosoang ke moabi.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Se ke oa letsetsa `drop`-tsohang e tla jeoa ke `wake`.
        crate::mem::forget(self);

        // TSHIRELETSO: Sena se bolokehile hobane `Waker::from_raw` ke yona feela tsela
        // ho qala `wake` le `data` e hlokang hore mosebelisi a ananele hore konteraka ea `RawWaker` ea tiisoa.
        //
        unsafe { (wake)(data) };
    }

    /// Tsoha mosebetsi o amanang le `Waker` ena ntle le ho sebelisa `Waker`.
    ///
    /// Sena se ts'oana le `wake`, empa se kanna sa sebetsa hanyane maemong ao `Waker` e nang le eona e fumanehang.
    /// Mokhoa ona o lokela ho khethoa ho letsetsa `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Mohala oa 'nete oa ho tsosa o fanoa ka mohala oa ts'ebetso o kenang ts'ebetsong o hlalosoang ke moabi.
        //

        // TSHIRELETSO: bona `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// E khutlisa `true` haeba `Waker` ena le `Waker` e 'ngoe li tsohile mosebetsi o tšoanang.
    ///
    /// Mosebetsi ona o sebetsa ka boikitlaetso bo matla, mme o ka khutla o le leshano leha ba ha Waker ba ka tsosa mosebetsi o tšoanang.
    /// Leha ho le joalo, haeba mosebetsi ona o khutlisa `true`, ho netefalitsoe hore `Waker`s ba tla tsosa mosebetsi o tšoanang.
    ///
    /// Mosebetsi ona o sebelisoa haholoholo molemong oa ntlafatso.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// E etsa `Waker` e ncha ho tloha [`RawWaker`].
    ///
    /// Boitšoaro ba `Waker` e khutlisitsoeng ha boa hlalosoa ha konteraka e hlalositsoeng ho litokomane tsa ["RawWaker"] le ["RawWakerVTable`] e sa tiisoe.
    ///
    /// Ka hona mokhoa ona ha o bolokehe.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // TSHIRELETSO: Sena se bolokehile hobane `Waker::from_raw` ke yona feela tsela
            // ho qala `clone` le `data` e hlokang hore mosebelisi a ananele hore konteraka ea [`RawWaker`] ea tiisoa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // TSHIRELETSO: Sena se bolokehile hobane `Waker::from_raw` ke yona feela tsela
        // ho qala `drop` le `data` e hlokang hore mosebelisi a ananele hore konteraka ea `RawWaker` ea tiisoa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}