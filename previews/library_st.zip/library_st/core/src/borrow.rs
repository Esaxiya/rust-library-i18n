//! Mojule oa ho sebetsana le data e alimiloeng.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait bakeng sa lintlha tsa kalimo.
///
/// Ho Rust, ho tloaelehile ho fana ka litšoantšo tse fapaneng tsa mofuta bakeng sa linyeoe tse fapaneng tsa ts'ebeliso.
/// Mohlala, sebaka sa polokelo le taolo ea boleng li ka khethoa ka ho khetheha hore li loketse ts'ebeliso e itseng ka mefuta ea pointer joalo ka [`Box<T>`] kapa [`Rc<T>`].
/// Ka ntle ho masela ana a tloaelehileng a ka sebelisoang ka mofuta ofe kapa ofe, mefuta e meng e fana ka likarolo tsa boikhethelo tse fanang ka ts'ebetso e ka bang theko e boima.
/// Mohlala oa mofuta o joalo ke [`String`] e eketsang bokhoni ba ho holisa khoele ho [`str`] ea mantlha.
/// Sena se hloka ho boloka tlhaiso-leseling e tlatselletsang e sa hlokahale bakeng sa khoele e bonolo, e sa fetoheng.
///
/// Mefuta ena e fana ka phihlello ho data ea mantlha ka litšupiso tsa mofuta oa data eo.Ho thoe ba "alingoe joalo" mofuta oo.
/// Mohlala, [`Box<T>`] e ka alima joalo ka `T` ha [`String`] e ka alima joalo ka `str`.
///
/// Mefuta e bontša hore e ka alimoa joalo ka mofuta o mong oa `T` ka ho kenya ts'ebetsong `Borrow<T>`, e fana ka sesupo sa `T` ka mokhoa oa trait oa [`borrow`].Mofuta o lokolohile ho kalima joalo ka mefuta e fapaneng e fapaneng.
/// Haeba e lakatsa ho alima ka mokhoa o ts'oanang e le mofuta-e lumellang lintlha tsa mantlha hore li fetoloe, e ka kenya ts'ebetsong [`BorrowMut<T>`].
///
/// Ho feta moo, ha ho fanoa ka ts'ebetsong bakeng sa traits e eketsehileng, ho hlokahala hore ho nahanoe hore na ba lokela ho itšoara ka tsela e ts'oanang le ea mofuta o ka lebaka la ho sebetsa e le boemeli ba mofuta oo.
/// Khoutu e tloaelehileng e sebelisa `Borrow<T>` ha e itšetleha ka boits'oaro bo ts'oanang ba lits'ebetso tsena tse ling tsa trait.
/// Tsena traits li kanna tsa hlaha joalo ka trait bounds.
///
/// Haholo-holo `Eq`, `Ord` le `Hash` e tlameha ho lekana le litekanyetso tse alimiloeng le tse nang le thepa: `x.borrow() == y.borrow()` e lokela ho fana ka sephetho se ts'oanang le `x == y`.
///
/// Haeba khoutu ea generic e hloka feela ho sebeletsa mefuta eohle e ka fanang ka litšupiso tsa mofuta o amanang le `T`, hangata ho molemo ho sebelisa [`AsRef<T>`] kaha mefuta e meng e ka e kenya ts'ebetsong ka mokhoa o sireletsehileng.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Joaloka pokello ea lintlha, [`HashMap<K, V>`] e na le linotlolo le boleng ka bobeli.Haeba tlhaiso-leseling ea 'nete e thatetsoe ka mofuta o itseng oa taolo, ho ntse ho ka khonahala ho batla boleng o sebelisa ts'upiso ea data ea senotlolo.
/// Mohlala, haeba senotlolo ke khoele, se kanna sa bolokoa le 'mapa oa hash joalo ka [`String`], ha ho ntse ho ka khonahala ho batla o sebelisa [`&str`][`str`].
/// Kahoo, `insert` e hloka ho sebetsa ka `String` ha `get` e hloka ho khona ho sebelisa `&str`.
///
/// E nolofalitsoe hanyane, likarolo tse loketseng tsa `HashMap<K, V>` li shebahala tjena:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // ha e siuoe
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// 'Mapa oohle oa hashi o entsoe ka mofuta oa senotlolo `K`.Hobane linotlolo tsena li bolokiloe ka 'mapa oa hashi, mofuta ona o tlameha ho ba le data ea senotlolo.
/// Ha o kenya para ea boleng ba bohlokoa, 'mapa o fuoa `K` joalo' me o hloka ho fumana bakete e nepahetseng ea hash mme o hlahlobe hore na senotlolo se se se ntse se le teng ho latela `K` eo.Ka hona e hloka `K: Hash + Eq`.
///
/// Ha u batla boleng 'mapeng, leha ho le joalo, ho tlameha ho fana ka litšupiso ho `K` e le senotlolo sa ho e batla ho tla hloka hore kamehla u thehe boleng bo joalo.
/// Bakeng sa linotlolo tsa likhoele, sena se ka bolela hore boleng ba `String` bo lokela ho etsoa feela bakeng sa ho batlisisa linyeoe moo ho nang le `str` feela.
///
/// Ho e-na le hoo, mokhoa oa `get` ke o tloaelehileng ho feta mofuta oa lintlha tsa bohlokoa, tse bitsoang `Q` ka mokhoa oa ho saena ka holimo.E bolela hore `K` e kalima joalo ka `Q` ka ho hloka `K: Borrow<Q>` eo.
/// Ho feta moo e hloka `Q: Hash + Eq`, e supa tlhokeho ea hore `K` le `Q` ba be le ts'ebetsong ea `Hash` le `Eq` traits tse hlahisang sephetho se ts'oanang.
///
/// Ts'ebetsong ea `get` e its'etleha ka ho khetheha ts'ebetsong e ts'oanang ea `Hash` ka ho khetha bakete ea hash ea senotlolo ka ho letsetsa `Hash::hash` ka boleng ba `Q` leha e kentse senotlolo ho latela boleng ba hashi bo baloang ho boleng ba `K`.
///
///
/// Ka lebaka leo, 'mapa oa hash oa robeha haeba `K` e phuthela boleng ba `Q` e hlahisa hash e fapaneng le `Q`.Mohlala, nahana hore u na le mofuta o thatelang khoele empa u bapisa litlhaku tsa ASCII tse sa tsotelleng linyeoe tsa bona:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Hobane litekanyetso tse peli tse lekanang li hloka ho hlahisa boleng bo tšoanang ba hashi, ts'ebetsong ea `Hash` e hloka ho hlokomoloha nyeoe ea ASCII, hape:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Na `CaseInsensitiveString` e ka kenya ts'ebetsong `Borrow<str>`?Ka sebele e ka fana ka tšupiso ea selae sa khoele ka mohala oa eona o nang le eona.
/// Empa hobane ts'ebetsong ea eona ea `Hash` e fapane, e itšoara ka tsela e fapaneng le `str` mme ka hona ha ea lokela ho kenya ts'ebetsong `Borrow<str>`.
/// Haeba e batla ho lumella ba bang ho fumana `str` e ka tlase, e ka etsa joalo ka `AsRef<str>` e sa nang le litlhoko tse ling.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// O kalima ka kotloloho ho boleng ba hae.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait bakeng sa lintlha tse alingoang ka mokhoa o feto-fetohang.
///
/// Joaloka motsoalle oa [`Borrow<T>`] trait ena e lumella mofuta ho alima e le mofuta oa mantlha ka ho fana ka ts'upiso e ka fetohang.
/// Bona [`Borrow<T>`] bakeng sa tlhaiso-leseling e batsi ka ho kalima e le mofuta o mong.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Ka mokhoa o ts'oanang, o alima ho boleng ba hae.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}