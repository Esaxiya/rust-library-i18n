//! Ho fetola likhoele tsa decimal ho linomoro tsa lintlha tse phaphametseng tsa IEEE 754.
//!
//! # Polelo ea bothata
//!
//! Re fuoa khoele ea decimal e kang `12.34e56`.
//! Khoele ena e na le karolo ea bohlokoa ea (`12`), karoloana ea (`34`), le likarolo tse hlahisang (`56`).Likarolo tsohle ke tsa boikhethelo 'me li tolokoa e le zero ha li le sieo.
//!
//! Re batla nomoro ea ntlha e phaphametseng ea IEEE 754 e haufi haholo le boleng bo nepahetseng ba khoele ea decimal.
//! Hoa tsebahala hore likhoele tse ngata tsa selemo ha li na liphetho tsa ho emisa ho base ea bobeli, ka hona re potoloha ho li-unit tsa 0.5 sebakeng sa ho qetela (ka mantsoe a mang, hantle kamoo ho ka khonehang).
//! Maqhama, litekanyetso tsa decimal li lekana hantle halofo ea tsela lipakeng tsa lifofane tse peli tse latellanang, li rarolloa ka leano la halofo ho isa le le leng, le tsejoang hape e le ho potoloha ha banka.
//!
//! Ha ho potang hore sena se thata haholo, ka bobeli mabapi le ho rarahana ha ts'ebetso le ka lipallo tsa CPU tse nkiloeng.
//!
//! # Implementation
//!
//! Pele, re hlokomoloha matšoao.Kapa ho fapana, re e tlosa qalong ea ts'ebetso ea ho sokoloha ebe re e sebelisa hape qetellong.
//! Sena se nepahetse maemong 'ohle a edge ho tloha ha li-floating tsa IEEE li lekane ho pota zero, ho hlokomoloha e le' ngoe feela ho phunya hanyane.
//!
//! Ka mor'a moo re tlosa ntlha ea decimal ka ho fetola sehlahisoa: Ka khopolo, `12.34e56` e fetoha `1234e54`, eo re e hlalosang ka palo e nepahetseng ea `f = 1234` le e kholo ea `e = 54`.
//! Boemeli ba `(f, e)` bo sebelisoa ke likhoutu tsohle tse fetileng.
//!
//! Ka mor'a moo re leka lethathamo le lelelele la linyeoe tse ikhethileng tse turang le ho bitsa chelete e ngata re sebelisa linomoro tsa boholo ba mochini le linomoro tse nyane tse boholo bo lekantsoeng (`f32`/`f64` ea pele, ebe mofuta o nang le li-bit tsa 64, `Fp`).
//!
//! Ha tsena tsohle li hloleha, re loma kulo ebe re ea ho algorithm e bonolo empa e lieha haholo e neng e kenyelletsa ho sebelisa `f * 10^e` ka botlalo le ho etsa patlo e potelletseng bakeng sa kakanyo e molemohali.
//!
//! Haholo-holo mojulu ona le bana ba ona ba kenya tšebetsong algorithms e hlalositsoeng ho:
//! "How to Read Floating Point Numbers Accurately" ke William D.
//! Clinger, e fumanehang marang-rang: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Ntle le moo, ho na le mesebetsi e mengata ea bathusi e sebelisitsoeng pampiring empa e sa fumanehe ho Rust (kapa bonyane mantlha).
//! Mofuta oa rona o boetse o rarahane ke tlhoko ea ho sebetsana le ho phalla le ho tlala le takatso ea ho sebetsana le linomoro tse sa tloaelehang.
//! Bellerophon le Algorithm R li na le bothata ba ho khaphatseha, lintho tse sa tloaelehang le ho tlala.
//! Re fetohela ho Algorithm M ka boikhethelo (ka liphetoho tse hlalositsoeng karolong ea 8 ea pampiri) hantle pele lipehelo li kena sebakeng se mahlonoko.
//!
//! Karolo e 'ngoe e hlokang ho tsotelloa ke `` RawFloat' 'trait eo hoo e batlang e le mesebetsi eohle e etsoang.Motho a ka nahana hore ho lekane ho lekola `f64` ebe o lahlela sephetho ho `f32`.
//! Ka bomalimabe sena ha se lefats'e leo re phelang ho lona, 'me sena ha se amane le letho ka ho sebelisa base ea bobeli kapa halofo ho isa le ho potoloha.
//!
//! Nahana ka mohlala mefuta e 'meli ea `d2` le `d4` e emelang mofuta oa decimal o nang le linomoro tse peli tsa desimali le linomoro tse' ne tsa desimali ka 'ngoe ebe u nka "0.01499" e le kenyelletso.Ha re sebeliseng ho qeta halofo.
//! Ho ea ka kotloloho ho linomoro tse peli tsa desimali ho fana ka `0.01`, empa haeba re potoloha ho isa ho tse nne pele, re fumana `0.0150`, e ntan'o bokelloa ho fihlela `0.02`.
//! Molao-motheo o ts'oanang o sebetsa le lits'ebetsong tse ling hape, haeba o batla ho nepahala ha 0.5 ULP o hloka ho etsa *ntho e ngoe le e ngoe ka botlalo le ho potoloha* hang hang, qetellong *, ka ho sheba lits'oants'o tsohle tse hahiloeng ka nako e le ngoe.
//!
//! FIXME: Le ha ho hlokahala hore likopi tse ling tsa khoutu li hlokahale, mohlomong likarolo tse ling tsa khoutu li ka ts'oaroa joalo ka hore khoutu e nyane e etsisoe.
//! Likarolo tse kholo tsa li-algorithms ha li ikemele ka mofuta oa ho phaphamala, kapa li hloka phihlello ea li-constant tse 'maloa, tse ka fetisoang joalo ka mekhahlelo.
//!
//! # Other
//!
//! Phetoho ha ea lokela ho ba * panic.
//! Ho na le lipolelo le panics tse hlakileng ka har'a khoutu, empa ha lia lokela ho qholotsoa mme li sebetsa joalo ka ho hlahloba bohloeki ba kahare.panics efe kapa efe e lokela ho nkuoa e le phoso.
//!
//! Ho na le liteko tsa yuniti empa li haella ka bomalimabe ho netefatsa ho nepahala, li koahela feela karolo e nyane ea liphoso tse ka bang teng.
//! Liteko tse pharalletseng haholo li fumaneha bukeng ea `src/etc/test-float-parse` joalo ka sengoloa sa Python.
//!
//! Noutu mabapi le ho phalla ho hoholo: Likarolo tse ngata tsa faele ena li etsa lipalo le sehlahisoa sa `e`.
//! Haholo-holo, re fetola ntlha ea decimal ho potoloha: Pele ho nomoro ea pele ea desimali, kamora nomoro ea ho qetela ea desimali, joalo-joalo.Sena se ka khaphatseha haeba se ka etsoa ka bohlasoa.
//! Re ts'epa mochini o monyane oa ho fana ka lisebelisoa tse nyane feela, moo "sufficient" e bolelang "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Lihlahisoa tse kholo lia amoheloa, empa ha re etse lipalo le tsona, li fetoha {positive,negative} {zero,infinity} hanghang.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Ba babeli ba na le liteko tsa bona.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// E fetola khoele botlaaseng ba 10 ho ea ho float.
            /// E amohela sehlahisoa se ikhethileng sa desimali.
            ///
            /// Mosebetsi ona o amohela likhoele tse kang
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', kapa ka mokhoa o ts'oanang, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', kapa, ka ho lekana, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Lebala la bosoeu le etellang pele le ho latela le emela phoso.
            ///
            /// # Grammar
            ///
            /// Likhoele tsohle tse khomarelang sebōpeho-puo sa [EBNF] li tla etsa hore [`Ok`] e khutlisoe:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Likokoanyana tse tsebahalang
            ///
            /// Maemong a mang, likhoele tse ling tse lokelang ho theha float e sebetsang li khutlisa phoso.
            /// Bona [issue #31407] bakeng sa lintlha.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Khoele
            ///
            /// # Khutlisa boleng
            ///
            /// `Err(ParseFloatError)` haeba mohala o ne o sa emele palo e nepahetseng.
            /// Ho seng joalo, `Ok(n)` moo `n` e leng palo ea ntlha e phaphametseng e emeloang ke `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Phoso e ka khutlisoang ha ho etsoa float.
///
/// Phoso ena e sebelisoa e le mofuta oa phoso bakeng sa ts'ebetsong ea [`FromStr`] bakeng sa [`f32`] le [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// E arola khoele ea decimal hore e be lets'oao le tse ling kaofela, ntle le ho lekola kapa ho netefatsa tse ling kaofela.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Haeba khoele e sa sebetse, ha ho mohla re sebelisang lets'oao, ka hona ha ho hlokahale hore re netefatse mona.
        _ => (Sign::Positive, s),
    }
}

/// E fetola khoele ea decimal hore e be palo ea ntlha e phaphametseng.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Mosebetsi o ka sehloohong oa phetolelo ea decimal-to-float: hlophisa lintho tsohle tse ntseng li etsoa pele le ho fumana hore na ke algorithm efe e lokelang ho fetoha.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift tsoa ntlha ea desimali.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 e lekanyelitsoe ho li-bits tse 1280, tse fetolelang ho linomoro tse ka bang 385 tsa decimal.
    // Haeba re feta sena, re tla oa, ka hona re fosa pele re atamela haholo (kahare ho 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Hona joale sebapali se hlile se lekana ka likotoana tse 16, tse sebelisoang hohle ho li-algorithms tsa mantlha.
    let e = e as i16;
    // FIXME Meeli ena e thata haholo.
    // Tlhatlhobo e hlokolosi ea mekhoa ea ho hloleha ea Bellerophon e ka lumella ho e sebelisa maemong a mang bakeng sa lebelo le leholo.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Joalokaha ho ngotsoe, sena se ntlafatsa hantle (bona #27130, leha e bua ka mofuta oa khale oa khoutu).
// `inline(always)` ke ts'ebetso ea seo.
// Ho na le libaka tsa mehala tse peli feela ka kakaretso mme ha e etse hore boholo ba khoutu e mpe le ho feta.

/// Strip zeros moo ho khonehang, leha sena se hloka ho fetola sebapali
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Ho faola zero tsena ha ho fetole letho empa ho ka thusa tsela e potlakileng (<linomoro tse 15).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Nolofatsa linomoro tsa foromo ea 0.0 ... x le x ... 0.0, u fetole sehlahisoa hantle.
    // Sena e kanna ea se hlōle kamehla (mohlomong se sutumetsa linomoro tse ling tseleng e potlakileng), empa e nolofatsa likarolo tse ling haholo (haholoholo, ho lekanya boholo ba boleng).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// E khutlisetsa moeli o kaholimo o litšila ka boholo ba (log10) ea boleng bo boholo ka ho fetisisa boo Algorithm R le Algorithm M ba tla bo bala ha ba ntse ba sebetsa ho decimal e fanoeng.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Ha ho hlokahale hore re tšoenyehe haholo ka ho khaphatseha mona ka lebaka la trivial_cases() le sebatli, se sefa lipehelo tse fetelletseng ho rona.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Boemong ba e>=0, li-algorithms ka bobeli li bala ka `f * 10^e`.
        // Algorithm R e tsoela pele ho etsa lipalo tse rarahaneng ka sena empa re ka iphapanyetsa eona molemong o holimo hobane e boetse e fokotsa karoloana pele ho moo, ka hona re na le buffer e ngata moo.
        //
        f_len + (e as u64)
    } else {
        // Haeba e <0, Algorithm R e etsa ntho e ts'oanang, empa Algorithm M ea fapana:
        // E leka ho fumana nomoro e nepahetseng k hoo `f << k / 10^e` e leng moelelo o bohareng.
        // Sena se tla fella ka `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Tlatsetso e 'ngoe e bakang sena ke 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// E lemoha ho phalla ho totobetseng le ho phalla ntle le ho sheba lipalo tsa desimali.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Ho ne ho na le zero empa li hlobolisitsoe ke simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Ena ke khakanyo e sa hlonepheng ea ceil(log10(the real value)).
    // Ha ho hlokahale hore re tšoenyehe haholo ka ho khaphatseha mona hobane bolelele ba ho kenya bo bonyenyane (bonyane ha bo bapisoa le 2 ^ 64) mme sebatli se se se sebetsana le li-expoter tseo boleng ba tsona bo felletseng ho feta 10 ^ 18 (e ntseng e le khutšoane ka 10 ^ 19 ea 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}