//! Ho netefatsa le ho senya khoele ea decimal ea foromo:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ka mantsoe a mang, syntax e tloaelehileng ea ntlha e phaphametseng, ntle le mekhelo e 'meli: Ha ho na lets'oao, mme ha ho ts'oaroe "inf" le "NaN".Tsena li sebetsoa ke ts'ebetso ea mokhanni (super::dec2flt).
//!
//! Le ha ho amohela litlatsetso tse sebetsang ho le bonolo, module ena e tlameha ho hana mefuta e mengata e sa sebetseng, eseng panic, hape e etse licheke tse ngata tseo li-module tse ling li itšetlehileng ka tsona eseng panic (kapa ho phalla) ka ho latellana.
//!
//! Ho mpefatsa litaba le ho feta, tsohle tse etsahalang ka nako e le 'ngoe li feta kenyelletso.
//! Kahoo, ela hloko ha u fetola eng kapa eng, 'me u hlahlobe habeli ka li-module tse ling.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Likarolo tse khahlisang tsa khoele ea desimali.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Motlalehi wa desimali, o netefaditswe hore o tla ba le dinomoro tse ka tlase ho 18 tsa didijiti
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// E hlahloba hore na khoele ea ho kenya ke nomoro ea ntlha e phaphametseng 'me haeba ho le joalo, fumana karolo ea bohlokoa, karoloana ea karoloana, le sebapali se ho eona.
/// Ha e sebetse lipontšo.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Ha ho linomoro pele ho 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Re hloka bonyane nomoro e le 'ngoe pele kapa kamora ntlha.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Junk e latelang ka mora karolo e harelaneng
            }
        }
        _ => Invalid, // Junk e latelang kamora khoele ea linomoro tsa pele
    }
}

/// E tlosa linomoro tsa desimali ho fihlela ho motho oa pele eo e seng oa linomoro.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ho qhekella le ho lekola liphoso.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Junk e latelang
    }
    if number.is_empty() {
        return Invalid; // Tlhaloso e se nang letho
    }
    // Mothating ona, ka nnete re na le khoele e nepahetseng ea linomoro.E kanna ea ba telele haholo hore o ka e kenya ka `i64`, empa haeba e le kholo hakana, kenyelletso e hlile e le zero kapa e sa feleng.
    // Kaha zero e 'ngoe le e' ngoe ea linomoro tsa desimali e fetola feela sehlahisoa ka +/-1, ho exp=10 ^ 18 kenyelletso e tla tlameha ho ba exabyte (!) ea zeros e le hore e ka ba haufi le ho fella.
    //
    // Hona ha se taba ea tšebeliso eo re hlokang ho e hlokomela.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}