//! Ho koahana hanyane ka li-float tse ntle tsa IEEE 754.Linomoro tse fosahetseng ha lia lokela ho sebetsoa.
//! Linomoro tse tloaelehileng tsa lintlha tse phaphametseng li na le kemiso ea kananelo joalo ka (frac, exp) joalo ka hore boleng ke 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) moo N e leng palo ea likotoana.
//!
//! Lintho tse sa tloaelehang li fapana hanyane ebile lia makatsa, empa molao-motheo o tšoanang oa sebetsa.
//!
//! Mona, leha ho le joalo, re ba emela e le (sig, k) ka f positive, joalo ka hore boleng ke f *
//! 2 <sup>e</sup> .Ntle le ho hlakisa "hidden bit", sena se fetola sebapali ka seo ho thoeng ke mantissa shift.
//!
//! Ka tsela e 'ngoe, hangata ho phaphamala ho ngotsoe e le (1) empa mona li ngotsoe e le (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Re bitsa (1) the **fractional representation** and (2) the **integral representation**.
//!
//! Mesebetsi e mengata mojulung ona e sebetsana feela le linomoro tse tloaelehileng.Mekhoa ea dec2flt ka mokhoa o sireletsehileng e nka tsela e tsamaeang butle e nepahetseng (Algorithm M) bakeng sa lipalo tse nyane haholo.
//! Algorithm eo e hloka next_float() feela e sebetsanang le maemo a sa tloaelehang le linotši.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Mothusi trait ho qoba ho kopitsa khoutu eohle ea `f32` le `f64`.
///
/// Bona maikutlo a module ea motsoali oa motsoali hore na hobaneng sena se hlokahala.
///
/// Ha ho mohla e tla keng e sebelisoe bakeng sa mefuta e meng kapa e sebelisoe kantle ho module ea dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Mofuta o sebelisoang ke `to_bits` le `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// E etsa phetiso e tala ho palo e kholo.
    fn to_bits(self) -> Self::Bits;

    /// E etsa phetiso e tala ho tsoa ho palo e kholo.
    fn from_bits(v: Self::Bits) -> Self;

    /// E khutlisa sehlopha seo palo ena e oelang ho sona.
    fn classify(self) -> FpCategory;

    /// E khutlisa mantissa, exporter le ho saena e le palo e kholo.
    fn integer_decode(self) -> (u64, i16, i8);

    /// E khetholla ho phaphamala.
    fn unpack(self) -> Unpacked;

    /// Disamente ho tswa ho palo e nyane e ka emeloang hantle.
    /// Panic haeba palo e felletseng e ke ke ea emeloa, khoutu e ngoe mojuleng ona e etsa bonnete ba hore le ka mohla e se ke ea etsahala.
    fn from_int(x: u64) -> Self;

    /// Fumana boleng 10 <sup>ea e</sup> tloha tafole ea pele ho ea computed.
    /// Panics bakeng sa `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Seo lebitso le se bolelang.
    /// Ho bonolo ho ba le khoutu e thata ho feta ho qhekella li-intrinsics le ho ts'epa hore LLVM e lula ee penya.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Tlamo e khomaretseng lipalo tsa linomoro tse kengoang li ke ke tsa hlahisa phallo e fetang kapa zero kapa
    /// tse sa tloaelehang.Mohlomong sehlahisoa sa boleng bo holimo bo tloaelehileng, ke ka lebaka leo lebitso.
    const MAX_NORMAL_DIGITS: usize;

    /// Ha nomoro e hlahelletseng ka ho fetesisa e na le boleng ba sebaka bo fetang bona, ka sebele palo e lekantsoe ho isa tekanyong.
    ///
    const INF_CUTOFF: i64;

    /// Ha nomoro ea bohlokoa ka ho fetisisa ea desimali e na le boleng ba sebaka bo ka tlase ho bona, ka sebele palo e tla ba zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Palo ea likotoana ho sebapali.
    const EXP_BITS: u8;

    /// Palo ea likotoana ka bohlokoa, ho kenyelletsa * le bit e patiloeng.
    const SIG_BITS: u8;

    /// Palo ea likotoana ka bohlokoa,*ntle le* biti e patiloeng.
    const EXPLICIT_SIG_BITS: u8;

    /// Moemeli ea phahameng ka ho fetisisa oa molao ka boemeli bo fokolang.
    const MAX_EXP: i16;

    /// Bonyane moemeli oa molao ea hlahisang likaroloana, ntle le tse sa tloaelehang.
    const MIN_EXP: i16;

    /// `MAX_EXP` bakeng sa boemeli bo kopaneng, ke hore, ka phetoho e sebelisitsoeng.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (ke hore, ka khethollo ea offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` bakeng sa boemeli bo kopaneng, ke hore, ka phetoho e sebelisitsoeng.
    const MIN_EXP_INT: i16;

    /// Boima ba boleng bo phahameng ka ho fetesisa ka boemeli bo kopaneng.
    const MAX_SIG: u64;

    /// Bohlokoa bo iketlileng bo tloaelehileng bo emetseng.
    const MIN_SIG: u64;
}

// Haholo ke ts'ebetso ea #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// E khutlisa mantissa, exporter le ho saena e le palo e kholo.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Khethollo ea sekhahla + phetoho ea mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ha e na bonnete ba hore na `as` e potoloha ka nepo lipulong tsohle.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// E khutlisa mantissa, exporter le ho saena e le palo e kholo.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Khethollo ea sekhahla + phetoho ea mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ha e na bonnete ba hore na `as` e potoloha ka nepo lipulong tsohle.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// E fetola `Fp` ho mofuta o haufi oa mochini o phaphamalang.
/// Ha e sebetsane le liphetho tse sa tloaelehang.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ke 64 hanyane, ka hona xe e na le phetoho ea mantissa ea 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Potoloha 64-bit e bohlokoa ho li-T::SIG_BITS bits ka halofo ho isa ho even.
/// Ha e sebetsane le phallo e fetang.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Fetola phetoho ea mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// E fapane le `RawFloat::unpack()` bakeng sa linomoro tse tloaelehileng.
/// Panics haeba bohlokoa kapa sehlahisoa se sa sebetse bakeng sa linomoro tse tloaelehileng.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Tlosa sekontiri se patiloeng
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Fetola sehlahisoa bakeng sa leeme la lihlahisoa le phetoho ea mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Tlohela letšoao ho 0 ("+"), lipalo tsa rona kaofela li ntle
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Theha ntho e sa tloaelehang.Mantissa ea 0 e lumelloa ebile e theha zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Sesebelisoa se kentsoeng ke 0, lets'oao la 0 ke 0, ka hona re tlameha feela ho fetolela likotoana.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ho hakanngoa bignum le Fp.E potoloha kahare ho 0.5 ULP ka halofo ea halofo.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Re khaotse likotoana tsohle pele ho index `start`, ke hore, re fetoha ka nepo ka palo ea `start`, ka hona ena ke eona e hlalosang eo re e hlokang.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) ho latela lits'oants'o tse hahiloeng.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// E fumana nomoro e kholo ka ho fetesisa e nyane ho feta ngangisano.
/// Ha e sebetsane le lintho tse sa tloaelehang, zero, kapa tse hlahisang lintho.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Fumana nomoro e nyane ka ho fetesisa e phaphametseng ho feta ngangisano.
// Ts'ebetso ena ea khotsofatsa, ke hore, next_float(inf) ==inf.
// Ho fapana le likhoutu tse ngata mojuleng ona, ts'ebetso ena e sebetsana le zero, lintho tse sa tloaelehang le infinities.
// Leha ho le joalo, joalo ka khoutu e 'ngoe mona, ha e sebetsane le NaN le linomoro tse fosahetseng.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Sena se bonahala se le monate haholo hore e ka ba 'nete, empa sea sebetsa.
        // 0.0 e kentsoe joalo ka lentsoe la zero-zero.Lintho tse sa tloaelehang ke 0x000m ... m moo m ke mantissa.
        // Haholo-holo, e nyane ka ho fetisisa e sa tloaelehang ke 0x0 ... 01 mme e kholo ka ho fetisisa ke 0x000F ... F.
        // Nomoro e nyane ka ho fetisisa e tloaelehileng ke 0x0010 ... 0, kahoo nyeoe ena ea sekhutlo le eona ea sebetsa.
        // Haeba keketseho e koahela mantissa, meroalo e nyolla sehlahisoa kamoo re batlang, 'me likotoana tsa mantissa li fetoha zero.
        // Ka lebaka la kopano e patiloeng, sena le sona ke sona seo re se batlang!
        // Qetellong, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}