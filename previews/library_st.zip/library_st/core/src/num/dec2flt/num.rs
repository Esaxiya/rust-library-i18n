//! Mesebetsi ea utility bakeng sa li-bignum tse sa utloahaleng haholo ho fetoha mekhoa.

// FIXME Lebitso la module ena ke bomalimabe, hobane li-module tse ling le tsona li kenya `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Lekola hore na ho khaola likotoana tsohle ho se bohlokoa ho feta `ones_place` ho hlahisa phoso e lekanyelitsoeng e tlase, e lekana, kapa e kholo ho feta 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Haeba likotoana tsohle tse setseng e le zero, ke= 0.5 ULP, ho seng joalo> 0.5 Haeba ho se na li-bits (half_bit==0), tse ka tlase le tsona li khutlisa ka nepo Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// E fetola khoele ea ASCII e nang le linomoro tsa decimal feela ho `u64`.
///
/// Ha e etse licheke tsa ho khaphatseha kapa litlhaku tse sa sebetseng, ka hona haeba motho ea letsitseng a sa hlokomele, sephetho ke sa maiketsetso mme se ka ba panic (leha e ke ke ea ba `unsafe`).
/// Ntle le moo, likhoele tse se nang letho li nkuoa e le zero.
/// Mosebetsi ona o teng hobane
///
/// 1. ho sebelisa `FromStr` ho `&[u8]` ho hloka `from_utf8_unchecked`, e leng mpe, 'me
/// 2. ho kopanya liphetho tsa `integral.parse()` le `fractional.parse()` ho thata ho feta mosebetsi ona kaofela.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// E fetola khoele ea linomoro tsa ASCII hore e be bignum.
///
/// Joalo ka `from_str_unchecked`, ts'ebetso ena e its'etleha ho sebali ho hlakola linomoro tse seng tsa linomoro.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// E notlolla bignum hore e be palo e nyane ea 64.Panics haeba palo e le kholo haholo.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// E ntša likotoana tse fapaneng.

/// Index 0 ke ntho ea bohlokoa hanyane mme moalo o buletsoe halofo joalo ka tloaelo.
/// Panics haeba e botsoa ho ntša likotoana tse ngata ho feta tse lekaneng mofuteng oa ho khutla.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}