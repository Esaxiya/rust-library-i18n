//! Mefuta ea liphoso tsa ho fetohela mefuteng ea bohlokoa.

use crate::convert::Infallible;
use crate::fmt;

/// Mofuta oa phoso o khutlisitsoe ha phetohelo ea mofuta o kopaneng e hlahlojoang e hloleha.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Bapisa ho fapana le ho qobella ho etsa bonnete ba hore khoutu e kang `From<Infallible> for TryFromIntError` e kaholimo e tla lula e sebetsa ha `Infallible` e fetoha lebitso la `!`.
        //
        //
        match never {}
    }
}

/// Phoso e ka khutlisoang ha ho etsoa palo e felletseng.
///
/// Phoso ena e sebelisoa e le mofuta oa phoso bakeng sa mesebetsi ea `from_str_radix()` mefuteng ea mefuta ea khale, joalo ka [`i8::from_str_radix`].
///
/// # Lisosa tse ka bang teng
///
/// Har'a lisosa tse ling, `ParseIntError` e ka lahleloa ka lebaka la sebaka se bosoeu se etellang pele kapa se tsamaisang khoele, mohlala, ha e fumanoa ho tsoa ho kenyelletso e tloaelehileng.
///
/// Ho sebelisa mokhoa oa [`str::trim()`] ho netefatsa hore ha ho sebaka se tšoeu se setseng pele se ka etsoa.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum ho boloka mefuta e fapaneng ea liphoso tse ka etsang hore ho hlakola palo e felletseng ho hlolehe.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Boleng bo senotsoeng ha bo na letho.
    ///
    /// Har'a lisosa tse ling, mofuta ona o tla hahuoa ha ho qaloa khoele e se nang letho.
    Empty,
    /// E na le linomoro tse sa sebetseng moelelong oa eona.
    ///
    /// Har'a lisosa tse ling, mofuta ona o tla hahuoa ha ho qaloa khoele e nang le char e seng ea ASCII.
    ///
    /// Mofuta ona o boetse oa etsoa ha `+` kapa `-` e kentsoe phoso kahare ho khoele ka bo eona kapa bohareng ba palo.
    ///
    ///
    InvalidDigit,
    /// Nete e kholo haholo hore e ka bolokoa ka mofuta oa linomoro tse lebisitsoeng.
    PosOverflow,
    /// Linomoro li nyane haholo hore li ka bolokoa ka mofuta oa linomoro tse lebisitsoeng.
    NegOverflow,
    /// Boleng e ne e le Zero
    ///
    /// Mofuta ona o tla hlahisoa ha khoele ea ho hlakola e na le boleng ba zero, e ka bang tlolo ea molao bakeng sa mefuta eo e seng ea zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Ho hlahisa lebaka le qaqileng la ho hlakola palo e felletseng.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}