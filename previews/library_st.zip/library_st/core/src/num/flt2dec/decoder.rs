//! E khetholla boleng ba ntlha e phaphametseng ka likarolo le liphoso tse fapaneng.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Boleng bo sa lekanyetsoang bo saennweng bo saennoang, joalo ka hore:
///
/// - Boleng ba mantlha bo lekana le `mant * 2^exp`.
///
/// - Nomoro efe kapa efe ho tloha `(mant - minus)*2^exp` ho isa ho `(mant + plus)* 2^exp` e tla potoloha ho boleng ba mantlha.
/// Lebelo le kenyeletsa feela ha `inclusive` e le `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa e nyane.
    pub mant: u64,
    /// Phoso e tlase.
    pub minus: u64,
    /// Phoso e kaholimo.
    pub plus: u64,
    /// Sehlahisoa se arolelanoeng botlaaseng ba 2.
    pub exp: i16,
    /// Ke 'nete ha mokoloko oa liphoso o kenyelelitsoe.
    ///
    /// Ho IEEE 754, sena ke 'nete ha mantissa ea mantlha e ne e lekana.
    pub inclusive: bool,
}

/// Boleng ba boleng bo saennoeng.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, ebang e ntle kapa e mpe.
    Infinite,
    /// Zero, ebang ke tse ntle kapa tse mpe.
    Zero,
    /// Linomoro tse felileng tse nang le likarolo tse ling tse khethiloeng.
    Finite(Decoded),
}

/// Mofuta oa ntlha e phaphametseng e ka bang `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Bonyane ba boleng bo tloaelehileng bo tloaelehileng.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// E khutlisa lets'oao ('nete ha e le mpe) le boleng ba `FullDecoded` ho tsoa ho nomoro ea ntlha e phaphametseng.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // baahelani: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode Kamehla e boloka se hlahisang, ka hona mantissa e nyollotsoe ka maemo a sa tloaelehang.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // baahelani: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // moo maxmant=e sa tloaelehang * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // baahelani: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}