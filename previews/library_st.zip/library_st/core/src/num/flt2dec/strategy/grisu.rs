//! Ts'ebetso ea Rust ea Grisu3 algorithm e hlalositsoeng ho "Printing Floating-Point Numbers Quickly and Accurately with Integers" [^ 1].
//! E sebelisa hoo e ka bang 1KB ea tafole e etselitsoeng pele, mme ka lehlakoreng le leng, e potlakile haholo bakeng sa lisebelisoa tse ngata.
//!
//! [^1]: Florian Loitsch.2010. Ho hatisa linomoro tsa lintlha tse phaphamalang kapele le
//!   ka nepo le linomoro.SIGPLAN Ha ho joalo.45, 6 (Phuptjane 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// bona litlhaloso ho `format_shortest_opt` bakeng sa mabaka.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-ke;e=4* ke, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Fuoa `x > 0`, e khutlisa `(k, 10^k)` joalo hore `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ts'ebetso e khuts'oane ea mofuta oa Grisu.
///
/// E khutlisa `None` ha e ne e tla khutlisa setšoantšo se sa nepahalang ho seng joalo.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // re hloka bonyane likotoana tse tharo tsa ho nepahala ho eketsehileng

    // qala ka litekanyetso tse tloaelehileng ka sehlahisoa se arolelanoeng
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // fumana `cached = 10^minusk` efe kapa efe joalo ka hore `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // kaha `plus` e tloaelehile, sena se bolela `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // ha re khetha likhetho tsa `ALPHA` le `GAMMA`, sena se beha `plus * cached` ho `[4, 2^32)`.
    //
    // ho hlakile hore hoa rateha ho nyolla `GAMMA - ALPHA`, e le hore re se ke ra hloka matla a mangata a bolokiloeng ka 10, empa ho na le lintlha tse ling.
    //
    //
    // 1. re batla ho boloka `floor(plus * cached)` kahare ho `u32` hobane e hloka karohano e turang.
    //    (sena ha se hlile se ka qojoa, ho setse se setseng bakeng sa tekanyetso ea ho nepahala.)
    // 2.
    // karolo e setseng ea `floor(plus * cached)` e atisoa ka makhetlo a 10, 'me ha ea lokela ho phalla.
    //
    // ea pele e fana ka `64 + GAMMA <= 32`, ha ea bobeli e fana ka `10 * 2^-ALPHA <= 2^64`;
    // -60 'me -32 ke sebaka se phahameng ka ho fetisisa se nang le tšitiso ena,' me V8 le eona ea e sebelisa.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // tekanyo fps.sena se fana ka phoso e kholo ea 1 ulp (e pakiloe ho Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-mefuta ea nnete ea ho tlosa
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // kaholimo ho `minus`, `v` le `plus` li hakantsoe *likhakanyo*(phoso <1 ulp).
    // kaha ha re tsebe hore phoso e ntle kapa e mpe, re sebelisa likhakanyo tse peli tse arotsoeng ka ho lekana 'me re na le phoso e kholo ea li-ulps tse 2.
    //
    // "unsafe region" ke nako ea bolokolohi eo re e hlahisang qalong.
    // "safe region" ke nako e sa fetoheng eo re e amohelang feela.
    // re qala ka repr e nepahetseng kahare ho sebaka se sa bolokehang, ebe re leka ho fumana repr e haufi haholo ho `v` eo hape e leng sebakeng se bolokehileng.
    // haeba re sa khone, rea inehela.
    //
    let plus1 = plus.f + 1;
    // ha plus0 = plus.f, 1;//feela bakeng sa tlhaloso a minus0 = minus.f + 1;//feela bakeng sa tlhaloso
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // karolo e arolelanoeng

    // arola `plus1` likarolo tsa bohlokoa le likaroloana.
    // likarolo tsa bohlokoa li netefalitsoe hore li tla lekana u32, kaha matla a khutsitsoeng a tiisa `plus < 2^32` mme `plus.f` e tloaelehileng e lula e le tlase ho `2^64 - 2^4` ka lebaka la tlhoko e nepahetseng.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // lekanya `10^max_kappa` e kholo ho feta `plus1` (ka hona `plus1 < 10^(max_kappa+1)`).
    // ena ke tlamo e kaholimo ea `kappa` ka tlase.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: haeba `k` ke nomoro e kholo ka ho fetisisa st
    // `0 <= y mod 10^k <= y - x`,              ebe `V = floor(y / 10^k) * 10^k` e ho `[x, y]` 'me ke e' ngoe ea lipapiso tse khuts'oane haholo (tse nang le palo e fokolang ea linomoro tsa bohlokoa) ho lethathamo leo.
    //
    //
    // fumana bolelele ba linomoro `kappa` lipakeng tsa `(minus1, plus1)` ho latela Theorem 6.2.
    // Theorem 6.2 e ka amoheloa ho khetholla `x` ka ho batla `y mod 10^k < y - x` ho fapana.
    // (mohlala, `x` =32000, `y` =32777; `kappa` =2 ho tloha `y mod 10 ^ 3=777 <y, x=777`.) algorithm e itšetleha ka karolo ea morao-rao ea netefatso ho khetholla `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) joalo ka boholo;//feela bakeng sa tlhaloso
    let delta1frac = delta1 & ((1 << e) - 1);

    // fana ka likarolo tsa bohlokoa, ha o ntse o sheba ho nepahala mohatong o mong le o mong.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // linomoro tse lokelang ho fanoa
    loop {
        // re lula re na le bonyane nomoro e le 'ngoe eo re lokelang ho fana ka eona, joalo ka bahlaseli ba `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ho latela hore `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // arola `remainder` ka `10^kappa`.Ka bobeli li lekantsoe ke `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; re fumane `kappa` e nepahetseng.
            let ten_kappa = (ten_kappa as u64) << e; // scale 10 ^ kappa khutlela ho exponent e arolelanoeng
            return round_and_weed(
                // TŠIRELETSO: re qalile mohopolo oo kaholimo.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // roba lupu ha re se re fane ka linomoro tsohle tsa bohlokoa.
        // Nomoro e nepahetseng ea linomoro ke `max_kappa + 1` e le `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // khutlisetsa lintho tse sa fetoheng
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // fana ka likarolo tse arohaneng, ha o ntse o hlahloba ho nepahala mohatong o mong le o mong.
    // Lekhetlong lena re ts'epa ho pheta-pheta khafetsa, kaha karohano e tla lahleheloa ke ho nepahala.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // nomoro e latelang e lokela ho ba ea bohlokoa joalo ka ha re lekile seo pele re ka hlasela tse hlaselang, moo `m = max_kappa + 1` (#ea linomoro karolong ea bohlokoa):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // e ke ke ea phalla, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // arola `remainder` ka `10^kappa`.
        // Ka bobeli li lekantsoe ke `2^e / 10^kappa`, ka hona tse latelang li totobetse mona.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // seqhetso se hlakileng
            return round_and_weed(
                // TŠIRELETSO: re qalile mohopolo oo kaholimo.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // khutlisetsa lintho tse sa fetoheng
        kappa -= 1;
        remainder = r;
    }

    // re hlahisitse linomoro tsohle tsa bohlokoa tsa `plus1`, empa ha re na bonnete ba hore na ke eona e nepahetseng.
    // Mohlala, haeba `minus1` ke 3.14153 ... 'me `plus1` ke 3.14158 ..., ho na le boemeli bo fapaneng bo 5 bo khuts'oane ho tloha ho 3.14154 ho isa ho 3.14158 empa re na le e kholo feela.
    // re tlameha ho fokotsa nomoro ea ho qetela ka tatellano ebe re sheba hore na ena ke repr e nepahetseng.
    // ho na le bonyane likhetho tse 9 (. 1 ho isa ho ..9), ka hona sena se potlakile haholo.(Karolo ea "rounding")
    //
    // mosebetsi o lekola haeba XRX repr ena e hlile e le kahara mekhahlelo ea ulp, hape, ho ka etsahala hore repr ea "second-to-optimal" e ka ba e nepahetseng ka lebaka la phoso e potileng.
    // maemong afe kapa afe sena se khutlisa `None`.
    // (Karolo ea "weeding")
    //
    // Likhang tsohle mona li lekantsoe ke boleng bo tloaelehileng (empa bo sa hlalosoang) `k`, e le hore:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (hape, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (hape, `threshold > plus1v` ho tsoa ho lihlaseli tsa pejana)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // hlahisa likhakanyo tse peli ho `v` (ha e le hantle `plus1 - v`) kahare ho li-ulps tsa 1.5.
        // boemeli bo hlahisoang e lokela ho ba boemeli bo haufi ho feta bobeli.
        //
        // mona `plus1 - v` e sebelisoa ho tloha ha lipalo li etsoa mabapi le `plus1` molemong oa ho qoba overflow/underflow (ka hona ke mabitso a bonahalang a fapantsoe).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ntho e 'ngoe)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 mofuta)

        // fokotsa nomoro ea hoqetela ebe o emisa ho boemeli bo haufi ho `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // re sebetsa le linomoro tse hakantsoeng tsa `w(n)`, tseo qalong li lekanang le `plus1 - plus1 % 10^kappa`.kamora ho tsamaisa 'mele oa loop makhetlo a `n`, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // re beha `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (ka hona `remainder= plus1w(0)`) ho nolofatsa licheke.
            // hlokomela hore `plus1w(n)` e lula e eketseha.
            //
            // re na le maemo a mararo a ho emisa.efe kapa efe ea tsona e tla etsa hore lupu e se khone ho tsoela pele, empa joale re na le bonyane boemeli bo le bong bo tsebahalang bo haufi le `v + 1 ulp` leha ho le joalo.
            // re tla li hlalosa e le TC1 ho ea ho TC3 ka bokhutšoane.
            //
            // TC1: `w(n) <= v + 1 ulp`, ke hore, ena ke repr ea hoqetela e ka bang e haufi haholo.
            // hona ho lekana le `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // e kopantswe le TC2 (e lekolang haeba `w(n+1)` is valid), sena se thibela phallo e ka etsahalang palong ea `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ke hore, repr e latelang ha e potolohe ho `v`.
            // hona ho lekana le `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // lehlakore le letšehali le ka khaphatseha, empa rea tseba `threshold > plus1v`, kahoo haeba TC1 e fosahetse, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` mme re ka leka ka polokeho hore na `threshold - plus1w(n) < 10^kappa` e teng.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ke hore, repr e latelang ke
            // ha ho haufi le `v + 1 ulp` ho feta repr ea hajoale.
            // ha u fuoa `z(n) = plus1v_up - plus1w(n)`, e fetoha `abs(z(n)) <= abs(z(n+1))`.hape re nka hore TC1 ke leshano, re na le `z(n) > 0`.re na le linyeoe tse peli tseo re lokelang ho nahana ka tsona:
            //
            // - ha `z(n+1) >= 0`: TC3 e fetoha `z(n) <= z(n+1)`.
            // ha `plus1w(n)` e ntse e eketseha, `z(n)` e lokela ho fokotseha mme hona ho hlakile hore ke leshano.
            // - neng `z(n+1) < 0`:
            //   - TC3a: selelekela ke `plus1v_up < plus1w(n) + 10^kappa`.ho nka hore TC2 ke leshano, `threshold >= plus1w(n) + 10^kappa` ka hona e ka se khaphatsehe.
            //   - TC3b: TC3 e fetoha `z(n) <= -z(n+1)`, ke hore, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 e hlokomolohuoang e fana ka `plus1v_up > plus1w(n)`, ka hona e ke ke ea phalla kapa ea phalla ha e kopantsoe le TC3a.
            //
            // ka lebaka leo, re lokela ho emisa ha `TC1 || TC2 || (TC3a && TC3b)`.tse latelang li lekana le ho fapakana ha eona, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr e khuts'oane e ke ke ea fela ka `0`
                plus1w += ten_kappa;
            }
        }

        // lekola hore na kemelo ena le eona ke boemeli bo haufi ho `v - 1 ulp`.
        //
        // hona ho ts'oana le maemo a felisang `v + 1 ulp`, 'me `plus1v_up` kaofela e nkeloe sebaka ke `plus1v_down`.
        // tlhahlobo e khaphatsehang e ts'oara ka ho lekana.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // joale re na le boemeli bo haufi ho `v` lipakeng tsa `plus1` le `minus1`.
        // sena se lokolohile haholo, leha ho le joalo, kahoo re hana `w(n)` efe kapa efe e seng lipakeng tsa `plus0` le `minus0`, ke hore, `plus1 - plus1w(n) <= minus0` kapa `plus1 - plus1w(n) >= plus0`.
        // re sebelisa lintlha tsa hore `threshold = plus1 - minus1` le `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Ts'ebetso e khuts'oane ka ho fetesisa ea Grisu le Dragon fallback.
///
/// Sena se lokela ho sebelisoa maemong a mangata.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // TSHIRELETSO: Sehlahlobi sa kadimo ga se botlhale jo bo lekaneng go re letlelela go dirisa `buf`
    // ho branch ea bobeli, ka hona re lahla nako ea bophelo mona.
    // Empa re sebelisa `buf` feela haeba `format_shortest_opt` e khutlisitse `None` kahoo ho lokile.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Ts'ebetso e nepahetseng le e sa fetoheng ea mofuta oa Grisu.
///
/// E khutlisa `None` ha e ne e tla khutlisa setšoantšo se sa nepahalang ho seng joalo.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // re hloka bonyane likotoana tse tharo tsa ho nepahala ho eketsehileng
    assert!(!buf.is_empty());

    // tiisa le ho lekanya `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // arola `v` likarolo tsa bohlokoa le likaroloana.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // `v` ea khale le `v` e ncha (e nyollotsoeng ke `10^-k`) e na le phoso ea <1 ulp (Theorem 5.1).
    // kaha ha re tsebe hore phoso e nepahetse kapa e fosahetse, re sebelisa likhakanyo tse peli tse arotsoeng ka ho lekana 'me re na le phoso e kholo ea li-ulps tse 2 (ho tšoana le tabeng e khuts'oane haholo).
    //
    //
    // sepheo ke ho fumana letoto la linomoro tse lekaneng hantle tse tloaelehileng ho `v - 1 ulp` le `v + 1 ulp`, hore re tle re itšepe haholo.
    // haeba sena se sa khonehe, ha re tsebe hore na ke efe e hlahisitsoeng hantle bakeng sa `v`, ka hona rea inehela ebe rea khutlela morao.
    //
    // `err` e hlalosoa e le `1 ulp * 2^e` mona (e ts'oanang le ulp ho `vfrac`), 'me re tla e lekanya neng kapa neng ha `v` e nyoloha.
    //
    //
    //
    let mut err = 1;

    // lekanya `10^max_kappa` e kholo ho feta `v` (ka hona `v < 10^(max_kappa+1)`).
    // ena ke tlamo e kaholimo ea `kappa` ka tlase.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // haeba re sebetsa le meeli ea linomoro tsa ho qetela, re hloka ho khutsufatsa buffer pele ho phetolelo ea 'nete ho qoba ho potoloha habeli.
    //
    // hlokomela hore re tlameha ho holisa buffer hape ha ho phethela ho etsahala!
    let len = if exp <= limit {
        // oops, re sitoa le ho hlahisa linomoro tse le 'ngoe.
        // sena se ka etsahala ha, re, re na le ho hong ho kang 9.5 mme e ntse e bokelloa ho fihla ho 10.
        //
        // ha e le hantle re ka letsetsa `possibly_round` hanghang ka buffer e se nang letho, empa ho nyolla `max_ten_kappa << e` ka 10 ho ka baka phallo.
        //
        // ka hona, re botsoa mona 'me re atolosa pharalla ea liphoso ka palo ea 10.
        // sena se tla eketsa sekhahla se fosahetseng sa bohata, empa haholo,*haholo* hanyane;
        // e ka ba taba ea bohlokoa feela ha mantissa e le kholo ho feta likotoana tse 60.
        //
        // TSHIRELETSO: `len=0`, ka hona boitlamo ba ho qala memori ena ha bo na thuso.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // fana ka likarolo tsa bohlokoa.
    // phoso ke karoloana feela, ka hona ha ho hlokahale hore re e hlahlobe karolong ena.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // linomoro tse lokelang ho fanoa
    loop {
        // re lula re na le bonyane nomoro e le 'ngoe ho fana ka lintho tse sa fetoheng:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ho latela hore `remainder = vint % 10^(kappa+1)`)
        //
        //

        // arola `remainder` ka `10^kappa`.Ka bobeli li lekantsoe ke `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // na buffer e tletse?tsamaisa potoloho e setseng.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // TŠIRELETSO: re qalile li-byte tse ngata tsa `len`.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // roba lupu ha re se re fane ka linomoro tsohle tsa bohlokoa.
        // Nomoro e nepahetseng ea linomoro ke `max_kappa + 1` e le `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // khutlisetsa lintho tse sa fetoheng
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // fana ka likarolo tse fokolang.
    //
    // ka molao-motheo re ka tsoelapele ho linomoro tsa ho qetela tse fumanehang ebe re lekola ho nepahala.
    // ka bomalimabe re ntse re sebetsa le li-integer tse boholo bo lekanyelitsoeng, ka hona re hloka mokhoa o itseng oa ho bona ho phalla.
    // V8 e sebelisa `remainder > err`, e fetohang leshano ha linomoro tsa pele tsa `i` tsa `v - 1 ulp` le `v` li fapana.
    // leha ho le joalo sena se hana ho kenya letsoho tse ngata haholo tse seng molaong.
    //
    // ho tloha ha mokhahlelo oa morao-rao o na le phumano e nepahetseng ea phallo, re sebelisa mochini o thata haholoanyane:
    // re tsoelapele ho fihlela `err` e feta `10^kappa / 2`, hore moeli o lipakeng tsa `v - 1 ulp` le `v + 1 ulp` ka sebele o na le lipontšo tse peli kapa ho feta tse chitja.
    //
    // hona ho ts'oana le lipapiso tse peli tsa pele tse tsoang ho `possibly_round`, bakeng sa ts'upiso.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // tse sa fetoheng, moo `m = max_kappa + 1` (#ea linomoro karolong ea bohlokoa):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // e ke ke ea phalla, `2^e * 10 < 2^64`
        err *= 10; // e ke ke ea phalla, `err * 10 < 2^e * 5 < 2^64`

        // arola `remainder` ka `10^kappa`.
        // Ka bobeli li lekantsoe ke `2^e / 10^kappa`, ka hona tse latelang li totobetse mona.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // na buffer e tletse?tsamaisa potoloho e setseng.
        if i == len {
            // TŠIRELETSO: re qalile li-byte tse ngata tsa `len`.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // khutlisetsa lintho tse sa fetoheng
        remainder = r;
    }

    // lipalo tse ling ha li na thuso (`possibly_round` ehlile ea hloleha), ka hona rea tela.
    return None;

    // re hlahisitse linomoro tsohle tse kopiloeng tsa `v`, tse lokelang ho ts'oana le linomoro tse tsamaellanang tsa `v - 1 ulp`.
    // joale rea sheba hore na ho na le boemeli bo ikhethileng bo arolelanoeng ke bobeli ba `v - 1 ulp` le `v + 1 ulp`;sena se ka ts'oana le lipalo tse hlahisitsoeng, kapa ho mofuta o hlophisitsoeng oa linomoro tseo.
    //
    // haeba mofuta ona o na le lipontšo tse ngata tsa bolelele bo lekanang, re ke ke ra netefatsa hore re lokela ho khutlisa `None` ho fapana.
    //
    // Likhang tsohle mona li lekantsoe ke boleng bo tloaelehileng (empa bo sa hlalosoang) `k`, e le hore:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // TŠIRELETSO: li-byte tsa pele tsa `len` tsa `buf` li tlameha ho qalisoa.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (bakeng sa referense, mola o nang le matheba o bontša boleng bo tobileng ba litlhahiso tse ka bang teng ka linomoro tse fanoeng.)
        //
        //
        // Phoso e kholo haholo hoo bonyane ho nang le lipontšo tse tharo pakeng tsa `v - 1 ulp` le `v + 1 ulp`.
        // re sitoa ho tseba hore na ke efe e nepahetseng.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ha e le hantle, 1/2 ulp e lekane ho hlahisa litšoantšo tse peli tse ka bang teng.
        // (hopola hore re hloka boemeli bo ikhethileng bakeng sa `v - 1 ulp` le `v + 1 ulp`.) sena se ke ke sa phalla, joalo ka `ulp < ten_kappa` ho tloha cheke ea pele.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // haeba `v + 1 ulp` e haufi le boemeli bo hlophisitsoeng (bo seng bo le `buf`), re ka khutla ka polokeho.
        // hlokomela hore `v - 1 ulp` * e ka ba tlase ho boemeli ba hajoale, empa joalo ka `1 ulp < 10^kappa / 2`, boemo bona bo lekane:
        // sebaka se pakeng tsa `v - 1 ulp` le boemeli ba hona joale se ke ke sa feta `10^kappa / 2`.
        //
        // boemo bo lekana le `remainder + ulp < 10^kappa / 2`.
        // kaha sena se ka khaphatseha habonolo, qala ka ho hlahloba hore na `remainder < 10^kappa / 2`.
        // Re se re netefalitse hore `ulp < 10^kappa / 2`, ha feela `10^kappa` e sa khaphatsehe, cheke ea bobeli e nepahetse.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // TSHIRELETSO: moletsi wa rona o qalile mohopolo oo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------masala------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ka lehlakoreng le leng, haeba `v - 1 ulp` e le haufi le boemeli bo hlophisitsoeng, re lokela ho phutha le ho khutla.
        // ka lona lebaka leo ha re hloke ho hlahloba `v + 1 ulp`.
        //
        // boemo bo lekana le `remainder - ulp >= 10^kappa / 2`.
        // hape re qala ho hlahloba hore na `remainder > ulp` (hlokomela hore ena hase `remainder >= ulp`, kaha `10^kappa` ha ho mohla e leng zero).
        //
        // hlokomela hape hore `remainder - ulp <= 10^kappa`, ka hona cheke ea bobeli ha e phalle.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // TSHIRELETSO: moletsi wa rona o tlameha ebe o qalile mohopolo oo.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // eketsa feela linomoro tse ling ha re kopuoa ho nepahala ho sa fetoheng.
                // re hloka hape ho netefatsa hore, haeba buffer ea mantlha e ne e se na letho, linomoro tse ling li ka eketsoa feela ha `exp == limit` (edge case).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // TSHIRELETSO: rona le moletsi wa mohala re qalile mohopolo oo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ho seng joalo re ahloletsoe (ke hore, litekanyetso tse ling lipakeng tsa `v - 1 ulp` le `v + 1 ulp` lia fokotseha 'me tse ling lia bokellana) ebe rea tela.
        //
        None
    }
}

/// Ts'ebetso e nepahetseng le e sa fetoheng ea mofuta oa Grisu le Dragon fallback.
///
/// Sena se lokela ho sebelisoa maemong a mangata.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // TSHIRELETSO: Sehlahlobi sa kadimo ga se botlhale jo bo lekaneng go re letlelela go dirisa `buf`
    // ho branch ea bobeli, ka hona re lahla nako ea bophelo mona.
    // Empa re sebelisa `buf` feela haeba `format_exact_opt` e khutlisitse `None` kahoo ho lokile.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}