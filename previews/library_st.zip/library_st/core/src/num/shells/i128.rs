//! Mekhahlelo ea mofuta oa linomoro tse 128 tse saennweng.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Khoutu e ncha e lokela ho sebelisa likhakanyo tse amanang ka kotloloho le mofuta oa khale.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }