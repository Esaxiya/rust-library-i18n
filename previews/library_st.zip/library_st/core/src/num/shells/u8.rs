//! Mekhahlelo ea mofuta oa palo e sa ngolisoang ea 8-bit.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Khoutu e ncha e lokela ho sebelisa likhakanyo tse amanang ka kotloloho le mofuta oa khale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }