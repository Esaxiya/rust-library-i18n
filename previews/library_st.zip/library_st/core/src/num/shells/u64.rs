//! Mekhahlelo ea mofuta oa linomoro tse 64 tse sa ngolisoang.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Khoutu e ncha e lokela ho sebelisa likhakanyo tse amanang ka kotloloho le mofuta oa khale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }