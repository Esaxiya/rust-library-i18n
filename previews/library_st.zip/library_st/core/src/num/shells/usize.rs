//! Mekhahlelo ea mofuta oa linomoro tse sa ngolisoang tse saennweng ka boholo ba sesupa.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Khoutu e ncha e lokela ho sebelisa likhakanyo tse amanang ka kotloloho le mofuta oa khale.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }