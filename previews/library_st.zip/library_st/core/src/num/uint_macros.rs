macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Boleng bo bonyenyane haholo bo ka emeloang ke mofuta ona oa linomoro.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Boleng bo boholohali bo ka emeloang ke mofuta ona oa palo e felletseng.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Boholo ba mofuta ona o lekanang ka likotoana.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// E fetola selae sa khoele ka setsi se fanoeng hore e be palo e kholo.
        ///
        /// Khoele e lebelletsoe ho ba lets'oao la `+` le lateloang ke lipalo.
        ///
        /// Lebala la bosoeu le etellang pele le ho latela le emela phoso.
        /// Lidijiti ke seteishene sa litlhaku tsena, ho latela `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ts'ebetso ena panics haeba `radix` e le sieo ho tloha ho 2 ho isa ho 36.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// E khutlisa palo ea tsona ho boemeli ba binary ba `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// E khutlisa palo ea zero ka setšoantšo sa binary sa `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// E khutlisa palo ea linotši tse etelletseng pele ho boemeli ba binary ba `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// E khutlisa palo ea li-zero tse latelang ka setšoantšo sa binary sa `self`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// E khutlisa palo ea ba etelletseng pele ho setšoantšo sa binary sa `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// E khutlisa palo ea ba tsamaeang morao ka setšoantšo sa binary sa `self`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// E fetisetsa likotoana ka ho le letšehali ka chelete e boletsoeng, `n`, e phuthela likotoana tse phuthetsoeng qetellong ea palo e felletseng.
        ///
        ///
        /// Ka kopo hlokomela hore sena ha se ts'ebetso e ts'oanang le ts'ebetso ea `<<`!
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// E fetisetsa likotoana ka ho le letona ka palo e boletsoeng, `n`, e phuthela likotoana tse phuthetsoeng qalong ea palo e felletseng.
        ///
        ///
        /// Ka kopo hlokomela hore sena ha se ts'ebetso e ts'oanang le ts'ebetso ea `>>`!
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// E khutlisetsa tatellano ea "byte" ea palo e felletseng.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tlohella m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// E khutlisa tatellano ea likotoana ka palo e felletseng.
        /// Ntho e nyane haholo e fetoha ntho ea bohlokoahali, ea bobeli e nyane haholo e ba ea bobeli ea bohlokoa ka ho fetesisa, jj.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tlohella m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// E fetola palo e kholo ho tloha ho endian e kholo ho ea ho endianness ea sepheo.
        ///
        /// Ho endian e kholo ena ke no-op.
        /// Ho li-endian tse nyane li-byte li fapanyetsana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haeba cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } bo bong {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// E fetola palo e kholo ho tloha ho endian e nyane ho ea ho endianness ea sepheo.
        ///
        /// Ho endian e nyane sena ke no-op.
        /// Ho li-endian tse kholo li-byte li fapanyetsana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haeba cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } bo bong {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// E fetola `self` ho ea ho endian e kholo ho tloha ho endianness ea sepheo.
        ///
        /// Ho endian e kholo ena ke no-op.
        /// Ho li-endian tse nyane li-byte li fapanyetsana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haeba cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } e nngwe { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // kapa ho se be joalo?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// E fetola `self` ho ea ho endian e nyane ho tloha ho endianness ea sepheo.
        ///
        /// Ho endian e nyane sena ke no-op.
        /// Ho li-endian tse kholo li-byte li fapanyetsana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// haeba cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } e nngwe { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ho hlahlojoe palo e kholo.
        /// E bala `self + rhs`, e khutlisetsang `None` haeba phallo e etsahetse.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Tlatsetso ea palo e sa hlahlojoangE bala li-`self + rhs`, ka ho nka hore ho khaphatseha ho ke ke ha etsahala.
        /// Sena se baka boits'oaro bo sa hlalosoang ha
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Ho hlahlojoe palo e felletseng.
        /// E bala `self - rhs`, e khutlisetsang `None` haeba phallo e etsahetse.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ho tlosa palo e sa lekanyetsoang.E bala li-`self - rhs`, ka ho nka hore ho khaphatseha ho ke ke ha etsahala.
        /// Sena se baka boits'oaro bo sa hlalosoang ha
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Ho hlahlojoe palo e kholo.
        /// E bala `self * rhs`, e khutlisetsang `None` haeba phallo e etsahetse.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Phetiso ya palo e felletseng e sa hlahlojoeng.E bala `self * rhs`, ka ho nka hore ho phalla ho ke ke ha etsahala.
        /// Sena se baka boits'oaro bo sa hlalosoang ha
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // TSHIRELETSO: moletsi o lokela ho boloka konteraka ya polokeho ya `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Ho hlahlojoe karohano ea palo e felletseng
        /// E bala `self / rhs`, e khutlisa `None` haeba `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TŠIRELETSO: div ka zero e se e hlahlobiloe kaholimo mme mefuta e sa ngolisoang ha e na e meng
                // mekhoa ea ho hloleha bakeng sa karohano
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Ho hlahlojoe karohano ea Euclidean.
        /// E bala `self.div_euclid(rhs)`, e khutlisa `None` haeba `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// E hlahlojoe palo e setseng.
        /// E bala `self % rhs`, e khutlisa `None` haeba `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // TŠIRELETSO: div ka zero e se e hlahlobiloe kaholimo mme mefuta e sa ngolisoang ha e na e meng
                // mekhoa ea ho hloleha bakeng sa karohano
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Hlahloba Euclidean modulo.
        /// E bala `self.rem_euclid(rhs)`, e khutlisa `None` haeba `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Ho hlahlojoa ho hlokomoloha.E bala `-self`, e khutlisa `None` ntle le haeba `self==
        /// 0`.
        ///
        /// Hlokomela hore ho hlokomoloha palo efe kapa efe e ntle ho tla phalla.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// E hlahlobile shift ka ho le letšehali
        /// E sebelisa `self << rhs`, e khutlisa `None` haeba `rhs` e le kholo ho feta kapa e lekana le palo ea likotoana ho `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// E hlahlobile shift ka ho le letona.
        /// E sebelisa `self >> rhs`, e khutlisa `None` haeba `rhs` e le kholo ho feta kapa e lekana le palo ea likotoana ho `self`.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Lekola exponentiation.
        /// E bala `self.pow(exp)`, e khutlisetsang `None` haeba phallo e etsahetse.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ho tloha exp!=0, qetellong exp e tlameha ho ba 1.
            // Sebetsana le karolo ea ho qetela ea sebapali ka thoko, hobane ho bokella setsi kamora moo ha ho hlokahale mme ho ka baka phallo e sa hlokahaleng.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Kakaretso e khotsofatsang.
        /// E hlophisa `self + rhs`, e khotsofatsa meeling ea linomoro ho fapana le ho khaphatseha.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Ho tlosa palo e felletseng.
        /// E hlophisa `self - rhs`, e khotsofatsa meeling ea linomoro ho fapana le ho khaphatseha.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Katiso e tlatsang ya palo e phethahetseng.
        /// E hlophisa `self * rhs`, e khotsofatsa meeling ea linomoro ho fapana le ho khaphatseha.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Tlatsetso e phethahatsang ea palo e felletseng.
        /// E hlophisa `self.pow(exp)`, e khotsofatsa meeling ea linomoro ho fapana le ho khaphatseha.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Ho phethela tlatsetso ea (modular).
        /// E bala `self + rhs`, e phuthela moeling oa mofuta oo.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Ho phuthela (modular) ho tlosa.
        /// E bala `self - rhs`, e phuthela moeling oa mofuta oo.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Ho phethela katiso ea (modular).
        /// E bala `self * rhs`, e phuthela moeling oa mofuta oo.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// Ka kopo hlokomela hore mohlala ona o arolelanoe lipakeng tsa mefuta e mengata.
        /// E hlalosang hore na hobaneng `u8` e sebelisoa mona.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Ho phethela karohano ea (modular).Likhomphutha `self / rhs`.
        /// Karolo e phuthetsoeng ka mefuta e sa ngolisoang ke karohano e tloaelehileng feela.
        /// Ha ho na mokhoa oa ho thatela o neng o ka etsahala.
        /// Mosebetsi ona o teng, e le hore lits'ebetso tsohle li tlalehiloe mesebetsing ea ho phuthela.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Ho phethela karohano ea Euclidean.Likhomphutha `self.div_euclid(rhs)`.
        /// Karolo e phuthetsoeng ka mefuta e sa ngolisoang ke karohano e tloaelehileng feela.
        /// Ha ho na mokhoa oa ho thatela o neng o ka etsahala.
        /// Mosebetsi ona o teng, e le hore lits'ebetso tsohle li tlalehiloe mesebetsing ea ho phuthela.
        /// Hobane, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano li lekana, sena se lekana hantle le `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Ho phuthela karolo e setseng ea (modular).Likhomphutha `self % rhs`.
        /// Palo e setseng ea mefuta e sa ngolisoang ke palo e tloaelehileng e setseng.
        ///
        /// Ha ho na mokhoa oa ho thatela o neng o ka etsahala.
        /// Mosebetsi ona o teng, e le hore lits'ebetso tsohle li tlalehiloe mesebetsing ea ho phuthela.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ho thatela Euclidean modulo.Likhomphutha `self.rem_euclid(rhs)`.
        /// Palo ea modulo e phuthetsoeng ka mefuta e sa ngolisoang ke palo e setseng e tloaelehileng.
        /// Ha ho na mokhoa oa ho thatela o neng o ka etsahala.
        /// Mosebetsi ona o teng, e le hore lits'ebetso tsohle li tlalehiloe mesebetsing ea ho phuthela.
        /// Hobane, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano li lekana, sena se lekana hantle le `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Ho phuthela phoso ea (modular).
        /// E bala `-self`, e phuthela moeling oa mofuta oo.
        ///
        /// Kaha mefuta e sa ngolisoang ha e na likarolo tse fosahetseng lits'ebetso tsohle tsa mosebetsi ona li tla phuthela (ntle le `-0`).
        /// Bakeng sa litekanyetso tse nyane ho feta boholo ba mofuta o saenneng sephetho se ts'oana le ho lahla boleng bo saennweng bo lekanang.
        ///
        /// Litekanyetso life kapa life tse kholo li lekana le `MAX + 1 - (val - MAX - 1)` moo `MAX` e leng mofuta o lekanang oa mofuta o saennweng.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// Ka kopo hlokomela hore mohlala ona o arolelanoe lipakeng tsa mefuta e mengata.
        /// E hlalosang hore na hobaneng `i8` e sebelisoa mona.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic e sa tsamaee hantle ka lehlakoreng le letšehali;
        /// e hlahisa `self << mask(rhs)`, moo `mask` e tlosang likotoana leha e le life tse phahameng tsa `rhs` tse ka etsang hore phetoho e fete botebo ba mofuta oo.
        ///
        /// Hlokomela hore sena ha se * tšoane le ho potoloha ka ho le letšehali;RHS ea ho phuthela ka letsohong le letšehali e lekanyelitsoe mofuteng oa mofuta, ho fapana le hore likotoana tse tlositsoeng ho LHS li khutlisetsoe pheletsong e ngoe.
        /// Mefuta ea khale ea khale e etsa ts'ebetso ea [`rotate_left`](Self::rotate_left), e kanna ea ba seo u se batlang ho fapana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // TSHIRELETSO: ho ikoahela ka mofuta oa bitsize ho netefatsa hore ha re fetohe
            // kantle ho meeli
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic e sa tsamaee hantle ka lehlakoreng le letona;
        /// e hlahisa `self >> mask(rhs)`, moo `mask` e tlosang likotoana tsa odara e phahameng tsa `rhs` tse ka etsang hore phetoho e fete botebo ba mofuta oo.
        ///
        /// Hlokomela hore hona ha ho tšoane le ho potoloha ka ho le letona;RHS ea ho phuthela ka letsohong le letona e lekanyelitsoe mofuteng oa mofuta, ho fapana le hore likotoana tse tlositsoeng ho LHS li khutlisetsoe ntlheng e ngoe.
        /// Mefuta ea khale ea khale e etsa ts'ebetso ea [`rotate_right`](Self::rotate_right), e kanna ea ba seo u se batlang ho fapana.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // TSHIRELETSO: ho ikoahela ka mofuta oa bitsize ho netefatsa hore ha re fetohe
            // kantle ho meeli
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Ho phuthela poleloana ea (modular).
        /// E bala `self.pow(exp)`, e phuthela moeling oa mofuta oo.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ho tloha exp!=0, qetellong exp e tlameha ho ba 1.
            // Sebetsana le karolo ea ho qetela ea sebapali ka thoko, hobane ho bokella setsi kamora moo ha ho hlokahale mme ho ka baka phallo e sa hlokahaleng.
            //
            //
            acc.wrapping_mul(base)
        }

        /// E lekanya `self` + `rhs`
        ///
        /// E khutlisa tuple ea kenyelletso hammoho le boolean e bonts'a hore na phallo ea lipalo e tla etsahala.
        /// Haeba ho khaphatseha ho ka be ho etsahetse joale boleng bo phuthetsoeng boa khutlisoa.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// E lekanya `self`, `rhs`
        ///
        /// E khutlisa tuple ea ho tlosa hammoho le boolean e bonts'a hore na phallo ea lipalo e ka ba teng.
        /// Haeba ho khaphatseha ho ka be ho etsahetse joale boleng bo phuthetsoeng boa khutlisoa.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// O fumana palo ya `self` le `rhs`.
        ///
        /// E khutlisa tuple ea katiso hammoho le boolean e bonts'a hore na phallo ea lipalo e ka etsahala.
        /// Haeba ho khaphatseha ho ka be ho etsahetse joale boleng bo phuthetsoeng boa khutlisoa.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// Ka kopo hlokomela hore mohlala ona o arolelanoe lipakeng tsa mefuta e mengata.
        /// E hlalosang hore na hobaneng `u32` e sebelisoa mona.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// E lekanya divisor ha `self` e arotsoe ka `rhs`.
        ///
        /// E khutlisa karoloana ea sehlahloli hammoho le boolean e bonts'a hore na phallo ea lipalo e tla etsahala.
        /// Hlokomela hore bakeng sa lipalo tse sa ngolisoang tse sa ngolisoang ha ho mohla li hlahang, ka hona boleng ba bobeli bo lula bo le `false`.
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// E lekanya quotient ea karohano ea Euclidean `self.div_euclid(rhs)`.
        ///
        /// E khutlisa karoloana ea sehlahloli hammoho le boolean e bonts'a hore na phallo ea lipalo e tla etsahala.
        /// Hlokomela hore bakeng sa lipalo tse sa ngolisoang tse sa ngolisoang ha ho mohla li hlahang, ka hona boleng ba bobeli bo lula bo le `false`.
        /// Hobane, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano li lekana, sena se lekana hantle le `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// E bala se setseng ha `self` e arotsoe ka `rhs`.
        ///
        /// E khutlisa palo ea masala kamora ho arola hammoho le boolean e bonts'a hore na phallo ea lipalo e tla etsahala.
        /// Hlokomela hore bakeng sa lipalo tse sa ngolisoang tse sa ngolisoang ha ho mohla li hlahang, ka hona boleng ba bobeli bo lula bo le `false`.
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// E bala karolo e setseng ea `self.rem_euclid(rhs)` joalokaha eka ke ka karohano ea Euclidean.
        ///
        /// E khutlisa tuple ea modulo kamora ho arola hammoho le boolean e bonts'a hore na phallo ea lipalo e tla etsahala.
        /// Hlokomela hore bakeng sa lipalo tse sa ngolisoang tse sa ngolisoang ha ho mohla li hlahang, ka hona boleng ba bobeli bo lula bo le `false`.
        /// Kaha, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano lia lekana, ts'ebetso ena e lekana hantle le `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Ho itšepa ka mokhoa o phoroselang.
        ///
        /// E khutlisa `!self + 1` e sebelisa lits'ebetso tsa ho phuthela ho khutlisa boleng bo emelang boiphapanyo ba boleng bona bo sa ngolisoang.
        /// Hlokomela hore bakeng sa litekanyetso tse sa ngolisoang tse sa ngolisoeng ho lula ho hlaha, empa ho hana 0 ha ho khaphatsehe.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// E fetoha ka boeona e siiloeng ke likotoana tsa `rhs`.
        ///
        /// E khutlisa mofuta oa mofuta o fetotsoeng hammoho le boolean e bonts'ang hore na boleng ba shift bo ne bo le kholo ho feta kapa bo lekana le palo ea likotoana.
        /// Haeba boleng ba phetoho bo le boholo haholo, boleng bo patiloe (N-1) moo N e leng palo ea likotoana, 'me boleng bona bo sebelisoa ho etsa phetoho.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// E fetoha ka ho le letona ka li-`rhs` bits.
        ///
        /// E khutlisa mofuta oa mofuta o fetotsoeng hammoho le boolean e bonts'ang hore na boleng ba shift bo ne bo le kholo ho feta kapa bo lekana le palo ea likotoana.
        /// Haeba boleng ba phetoho bo le boholo haholo, boleng bo patiloe (N-1) moo N e leng palo ea likotoana, 'me boleng bona bo sebelisoa ho etsa phetoho.
        ///
        /// # Examples
        ///
        /// Ts'ebeliso ea mantlha
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// E iphahamisetsa matla a `exp`, e sebelisa poleloana ka ho etsa squaring.
        ///
        /// E khutlisa makhetlo a mangata le bool e bonts'ang hore na phallo e etsahetse.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, ke 'nete));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Mengoapo bakeng sa ho boloka liphetho tsa overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ho tloha exp!=0, qetellong exp e tlameha ho ba 1.
            // Sebetsana le karolo ea ho qetela ea sebapali ka thoko, hobane ho bokella setsi kamora moo ha ho hlokahale mme ho ka baka phallo e sa hlokahaleng.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// E iphahamisetsa matla a `exp`, e sebelisa poleloana ka ho etsa squaring.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ho tloha exp!=0, qetellong exp e tlameha ho ba 1.
            // Sebetsana le karolo ea ho qetela ea sebapali ka thoko, hobane ho bokella setsi kamora moo ha ho hlokahale mme ho ka baka phallo e sa hlokahaleng.
            //
            //
            acc * base
        }

        /// E etsa karohano ea Euclidean.
        ///
        /// Hobane, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano li lekana, sena se lekana hantle le `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// E lekanya bonyane bo setseng ba `self (mod rhs)`.
        ///
        /// Hobane, bakeng sa linomoro tse nepahetseng, litlhaloso tsohle tse tloaelehileng tsa karohano li lekana, sena se lekana hantle le `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Mosebetsi ona o tla ba panic haeba `rhs` e le 0.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// E khutlisa `true` haeba feela `self == 2^k` bakeng sa `k` e itseng.
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // E khutlisa e le 'ngoe ka tlase ho matla a latelang a mabeli.
        // (Bakeng sa 8u8 matla a latelang a mabeli ke 8u8 le bakeng sa 6u8 ke 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Mokhoa ona o ke ke oa khaphatseha, joalo ka maemong a `next_power_of_two` a phallang empa o qetella o khutlisitse boleng bo phahameng ba mofuta, mme o ka khutlisa 0 bakeng sa 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // TSHIRELETSO: Hobane `p > 0`, e ka se be le zero e etelletseng pele.
            // Seo se bolela hore phetoho e lula e le meeling, 'me li-processor tse ling (joalo ka Intel pre-haswell) li na le li-intrinsics tse sebetsang hantle ha khang e se zero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// E khutlisa matla a manyane ho feta a mabeli ho feta kapa a lekana le `self`.
        ///
        /// Ha boleng ba ho khutla bo khaphatseha (ke hore, `self > (1 << (N-1))` bakeng sa mofuta oa `uN`), ke panics ka mokhoa oa ho lokisa le boleng ba ho khutlisa bo phuthetsoe ho 0 ka mokhoa oa tokollo (boemo feela boo mokhoa o ka khutlisang 0).
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// E khutlisa matla a manyane ho feta a mabeli ho feta kapa a lekana le `n`.
        /// Haeba matla a latelang a mabeli a le maholo ho feta boleng bo phahameng ba mofuta, `None` ea khutlisoa, ho seng joalo matla a mabeli a phuthetsoe ka `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// E khutlisa matla a manyane ho feta a mabeli ho feta kapa a lekana le `n`.
        /// Haeba matla a latelang a mabeli a le maholo ho feta boleng bo phahameng ba mofuta, boleng ba ho khutla bo phuthetsoe ho `0`.
        ///
        ///
        /// # Examples
        ///
        /// Tšebeliso mantlha:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Khutlisa setšoantšo sa mohopolo oa palo ena e le lethathamo la li-byte tse kholo tsa endian (network) byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Khutlisa setšoantšo sa mohopolo oa palo ena e le lethathamo la li-byte ka tatellano ea li-endian byte.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Khutlisa setšoantšo sa mohopolo oa palo ena e le letoto la li-byte ka tatellano ea li-byte tsa lehae.
        ///
        /// Ha tšebeliso ea sethala sa sepheo sa sethala se sebelisoa, khoutu e nkehang e lokela ho sebelisa [`to_be_bytes`] kapa [`to_le_bytes`], ka moo ho loketseng.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     li-byte, haeba cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } bo bong {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TŠIRELETSO: const molumo hobane li-integer ke li-database tsa khale tse hlakileng kahoo re ka lula re le teng
        // li fetisetsa ho li-byte
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // TŠIRELETSO: li-integer ke li-database tsa khale tse hlakileng hore re tle re li fetisetse ho tsona kamehla
            // lihlopha tsa li-byte
            unsafe { mem::transmute(self) }
        }

        /// Khutlisa setšoantšo sa mohopolo oa palo ena e le letoto la li-byte ka tatellano ea li-byte tsa lehae.
        ///
        ///
        /// [`to_ne_bytes`] e lokela ho khethoa ho feta sena neng kapa neng ha ho khonahala.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let byte= num.as_ne_bytes();
        /// assert_eq!(
        ///     li-byte, haeba cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } bo bong {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // TŠIRELETSO: li-integer ke li-database tsa khale tse hlakileng hore re tle re li fetisetse ho tsona kamehla
            // lihlopha tsa li-byte
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Theha boleng ba tlhaiso-leseling ea "endian" ea tlhaho ho tsoa ho boemeli ba eona joalo ka sehlopha sa byte se seholo sa endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sebelisa std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kenya=phomolo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Theha boleng ba tlhaiso-leseling ea "endian" ea tlhaho ho tsoa ho boemeli ba eona e le lethathamo la li-byte tse nyane haholo.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sebelisa std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kenya=phomolo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Theha boleng ba tlhaiso-leseling ea "endian" ea tlhaho ho tsoa ho boemelo ba eona ba mohopolo joalo ka bongata ba li-endianness.
        ///
        /// Ha tšebeliso ea sethala sa sepheo sa sethala se sebelisoa, khoutu e nkehang e kanna ea batla ho sebelisa [`from_be_bytes`] kapa [`from_le_bytes`], ka moo ho loketseng.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } bo bong {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// sebelisa std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * kenya=phomolo;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // TŠIRELETSO: const molumo hobane li-integer ke li-database tsa khale tse hlakileng kahoo re ka lula re le teng
        // fetisetsa ho bona
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // TŠIRELETSO: li-integer ke li-database tsa khale tse hlakileng kahoo re ka li fetisang kamehla
            unsafe { mem::transmute(bytes) }
        }

        /// Khoutu e ncha e lokela ho khetha ho e sebelisa
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// E khutlisa boleng bo bonyenyane haholo bo ka emeloang ke mofuta ona oa palo e felletseng.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Khoutu e ncha e lokela ho khetha ho e sebelisa
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// E khutlisa boleng bo boholohali bo ka emeloang ke mofuta ona o lekanang.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}