//! Lisebelisoa tsa ho fomata le ho hatisa likhoele.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Lintlafatso tse ka bang teng li khutlisitsoe ke `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ho bontša hore litaba li lokela ho tsamaellana le leqele.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Ho bontša hore litaba li lokela ho hokahana hantle.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Sesupo sa hore litaba li lokela ho hokahanngoa bohareng.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Mofuta o khutlisitsoeng ka mekhoa ea ho hlophisa.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Mofuta oa phoso o khutlisitsoeng ho tloha ho fomate molaetsa ho ea molatsoaneng.
///
/// Mofuta ona ha o tšehetse phetiso ea phoso ntle le hore phoso e etsahetse.
/// Tlhahisoleseling efe kapa efe e eketsehileng e tlameha ho hlophisoa hore e fetisoe ka mekhoa e meng.
///
/// Ntho ea bohlokoa eo u lokelang ho e hopola ke hore mofuta oa `fmt::Error` ha oa lokela ho ferekanngoa le [`std::io::Error`] kapa [`std::error::Error`], eo le uena u ka bang le eona.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait ea ho ngola kapa ho fomata ho li-buffers kapa melapo e amohelang Unicode.
///
/// trait ena e amohela feela data e kentsoeng ka UTF-8 mme ha se [flushable].
/// Haeba u batla feela ho amohela Unicode 'me u sa hloke ho tsubella, u lokela ho kenya ts'ebetsong trait;
/// ho seng joalo o lokela ho kenya ts'ebetsong [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// O ngola sekhahla ho mongoli enoa, ho khutlisa hore na sengoloa se atlehile.
    ///
    /// Mokhoa ona o ka atleha ha feela selae sohle sa thapo se ngotsoe ka katleho, 'me mokhoa ona o ke ke oa khutla ho fihlela data yohle e ngotsoe kapa phoso e etsahala.
    ///
    ///
    /// # Errors
    ///
    /// Mosebetsi ona o tla khutlisa mohlala oa [`Error`] ka phoso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// O ngola [`char`] ho sengoli sena, ho khutlisa hore na sengoloa se atlehile.
    ///
    /// [`char`] e le 'ngoe e ka kenyelletsoa joalo ka byte e fetang e le' ngoe.
    /// Mokhoa ona o ka atleha feela haeba tatellano eohle ea li-byte e ngotsoe ka katleho, 'me mokhoa ona o ke ke oa khutla ho fihlela data yohle e ngotsoe kapa phoso e etsahala.
    ///
    ///
    /// # Errors
    ///
    /// Mosebetsi ona o tla khutlisa mohlala oa [`Error`] ka phoso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Sekhomaretsi sa ts'ebeliso ea [`write!`] macro le ba kenyang ts'ebetsong ea trait.
    ///
    /// Mokhoa ona ka kakaretso ha oa lokela ho sebelisoa ka letsoho, empa ho fapana le ka [`write!`] macro ka boeona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Tlhophiso ea ho fomata
///
/// `Formatter` e emela likhetho tse fapaneng tse amanang le ho fomata.
/// Basebelisi ha ba hahe `Formatter`s ka kotloloho;ha ho buuoa ka e 'ngoe e ka fetoloang ho e' ngoe e fetisetsoa mokhoeng oa `fmt` oa mefuta eohle ea traits, joalo ka [`Debug`] le [`Display`].
///
///
/// Ho sebelisana le `Formatter`, o tla letsetsa mekhoa e fapaneng ho fetola likhetho tse fapaneng tse amanang le ho fomata.
/// Bakeng sa mehlala, ka kopo bona litokomane tsa mekhoa e hlalositsoeng ho `Formatter` ka tlase.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Ho pheha khang ke ts'ebetso e ntlafalitsoeng e sebelisitsoeng hantle, e lekanang le `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Sebopeho sena se emetse "argument" e nkiloeng ke lelapa la Xprintf la mesebetsi.E na le ts'ebetso ea ho fomata boleng bo fanoeng.
/// Ka nako ea ho bokella ho netefatsoa hore tšebetso le boleng li na le mefuta e nepahetseng, ebe sebopeho sena se sebelisetsoa ho hlakola likhang tsa mofuta o le mong.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Sena se tiisa boleng bo le bong bo tsitsitseng ba sesupa-tšebetso se amanang le indices/counts ho sebopeho sa meralo.
//
// Hlokomela hore ts'ebetso e hlalosoang joalo e ne e ke ke ea nepahala joalo ka ha mesebetsi e lula e tšoailoe e sa boleloa lebitso_addr ka ho theoha ha hona joale ho LLVM IR, ka hona aterese ea bona ha e nkoe e le ea bohlokoa ho LLVM mme joalo ka ha_basebelisi ba bangata ba ka be ba sa kopitsoa.
//
// Ka ts'ebetso, ha ho mohla re bitsang as_usize ho non-usize e nang le data (joalo ka moloko o tsitsitseng oa mabaka a fomate), ka hona ena ke cheke e eketsehileng.
//
// Re batla haholo-holo ho netefatsa hore pointer ea ts'ebetso ho `USIZE_MARKER` e na le aterese e tsamaellanang le *feela* ho mesebetsi e nkang `&usize` e le khang ea bona ea pele.
// Read_volatile mona e netefatsa hore re ka hlophisa ts'ebeliso ka mokhoa o sireletsehileng ho tsoa ho litšupiso tse fetisitsoeng le hore aterese ena ha e supe ts'ebetsong e sa sebeliseng boholo.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // TSHIRELETSO: ptr ke setshupiso
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // TSHIRELETSO: `mem::transmute(x)` e bolokehile hobane
        //     1. `&'b T` e boloka nako eohle ea bophelo e simolohile ho `'b` (hore e se be le bophelo bo se nang moeli)
        //     2.
        //     `&'b T` 'me `&'b Opaque` e na le mohopolo o tšoanang (ha `T` e le `Sized`, joalo ka ha e le mona) `mem::transmute(f)` e bolokehile kaha `fn(&T, &mut Formatter<'_>) -> Result` le `fn(&Opaque, &mut Formatter<'_>) -> Result` li na le ABI e tšoanang (ha feela `T` e le `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // TSHIRELETSO: Lebala la `formatter` le behiloe feela ho USIZE_MARKER haeba
            // boleng ke usize, ka hona sena se bolokehile
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// lifolakha tse fumanehang ka sebopeho sa v1 sa format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Ha o sebelisa fomati_args! () Macro, mosebetsi ona o sebelisetsoa ho hlahisa sebopeho sa Likhang.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Mosebetsi ona o sebelisetsoa ho hlakisa mekhahlelo ea maemo a sa lekanyetsoang.
    /// Sehlopha sa `pieces` se tlameha ho ba bonyane bolelele ba `fmt` ho aha moaho o nepahetseng oa Likhang.
    /// Hape, `Count` efe kapa efe ka hare ho `fmt` eo e leng `CountIsParam` kapa `CountIsNextParam` e tlameha ho supa ngangisano e hlahisitsoeng ka `argumentusize`.
    ///
    /// Leha ho le joalo, ho se etse joalo ha ho bake ho se sireletsehe, empa ho tla hlokomoloha ho sa nepahalang.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// E hakanya bolelele ba sengoloa se hlophisitsoeng.
    ///
    /// Sena se reretsoe ho sebelisetsoa ho beha matla a pele a `String` ha u sebelisa `format!`.
    /// Note: sena ha se bophahamo ba tlase kapa holimo.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Haeba mohala oa fomate o qala ka ngangisano, u se ke oa beha letho pele, ntle le haeba bolelele ba likotoana bo le bohlokoa.
            //
            //
            0
        } else {
            // Ho na le likhang, ka hona, Puseletso efe kapa efe e tlatsetsang e tla kenya mohala sebakeng se seng hape.
            //
            // Ho qoba seo, re matla a "pre-doubling" mona.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Sebopeho sena se emela mofuta o hlophisitsoeng o bolokehileng hantle oa thapo ea fomate le mabaka a eona.
/// Sena se ke ke sa hlahisoa ka nako ea ho matha hobane se ke ke sa etsoa ka polokeho, ka hona ha ho lihahi tse fanoang mme masimo a ikemetse ho thibela phetoho.
///
///
/// [`format_args!`] macro e tla theha mohlala oa sebopeho sena ka polokeho.
/// Macro e tiisa mohala oa fomate ka nako ea ho bokella hore ts'ebeliso ea mesebetsi ea [`write()`] le [`format()`] e ka etsoa ka polokeho.
///
/// U ka sebelisa `Arguments<'a>` eo [`format_args!`] e khutlelang ho eona `Debug` le `Display` joalo ka ha ho bonoa ka tlase.
/// Mohlala o boetse o bonts'a mofuta oa `Debug` le `Display` nthong e ts'oanang: khoele ea fomate e kopantsoeng ho `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Hlahisa likotoana tsa likhoele ho li hatisa.
    pieces: &'a [&'static str],

    // Li-specs tsa li-placeholder, kapa `None` haeba li-specs tsohle li sa sebetse (joalo ka "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Mabaka a matla a ho kenella, ho hokahana ka likotoana tsa likhoele.
    // (Khang e ngoe le e ngoe e etelloa pele ke sekotoana sa thapo.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Fumana mohala o hlophisitsoeng, haeba o se na mabaka a lokelang ho hlophisoa.
    ///
    /// Sena se ka sebelisoa ho qoba likabo maemong a sa reng letho.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` e lokela ho hlophisa se hlahisoang ka mokhoa o shebaneng le moralo, o nang le bothata.
///
/// Ka kakaretso, o lokela feela `derive` ho kenya ts'ebetsong `Debug`.
///
/// Ha e sebelisoa le mofuta o mong oa sebopeho sa `#?`, tlhahiso e hatisitsoe hantle.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait ena e ka sebelisoa le `#[derive]` haeba likarolo tsohle li kenya tšebetsong `Debug`.
/// Ha `derive`d bakeng sa li-structs, e tla sebelisa lebitso la `struct`, ebe `{`, ebe lethathamo le arohaneng ka likhefi la lebitso la tšimo ka 'ngoe le boleng ba `Debug`, ebe `}`.
/// Bakeng sa `enum`, e tla sebelisa lebitso la mofuta 'me, haeba ho hlokahala, `(`, ebe litheko tsa `Debug` tsa masimo, ebe `)`.
///
/// # Stability
///
/// Mefuta e hlahisitsoeng ea `Debug` ha e tsitsitse, ka hona e ka fetoha ka mefuta ea future Rust.
/// Ntle le moo, ts'ebetsong ea `Debug` ea mefuta e fanoeng ke laeborari e tloaelehileng (`libstd`, `libcore`, `liballoc`, jj.) Ha e ea tsitsa, hape e ka fetoha ka mefuta ea future Rust.
///
///
/// # Examples
///
/// Ho fumana ts'ebetso:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Ho kenya letsoho ka letsoho:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Ho na le mekhoa e mengata ea bathusi ho [`Formatter`] struct ho u thusa ka ts'ebetsong ea matsoho, joalo ka [`debug_struct`].
///
/// `Debug` ts'ebetsong o sebelisa `derive` kapa debug builder API ho [`Formatter`] ts'ehetsa khatiso e ntle o sebelisa folakha e ngoe: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Ho hatisa hantle ka `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Arola mojule oa ho khutlisetsa thepa e kholo ea `Debug` ho prelude ntle le trait `Debug`.
pub(crate) mod macros {
    /// Fumana tlhahiso e kholo ea trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Format trait bakeng sa sebopeho se se nang letho, `{}`.
///
/// `Display` e ts'oana le [`Debug`], empa `Display` ke ea tlhahiso e shebaneng le mosebelisi, ka hona e ke ke ea fumanoa.
///
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ho kenya ts'ebetsong `Display` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait e lokela ho hlophisa tlhahiso ea eona e le palo ho base-8.
///
/// Bakeng sa linomoro tsa khale tse saennweng (`i8` ho `i128`, le `isize`), litekanyetso tse mpe li hlophisitsoe e le tlatsetso ea bobeli.
///
///
/// Folakha e ngoe, `#`, e eketsa `0o` ka pel'a sehlahisoa.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `i32`:
///
/// ```
/// let x = 42; // 42 ke '52' ho octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Ho kenya ts'ebetsong `Octal` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // moemeli ho ts'ebetsong ea i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait e lokela ho hlophisa tlhahiso ea eona e le palo ho binary.
///
/// Bakeng sa linomoro tsa khale tse saennweng ([`i8`] ho [`i128`], le [`isize`]), litekanyetso tse mpe li hlophisitsoe e le tlatsetso ea bobeli.
///
///
/// Folakha e ngoe, `#`, e eketsa `0b` ka pel'a sehlahisoa.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le [`i32`]:
///
/// ```
/// let x = 42; // 42 ke '101010' ka binary
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Ho kenya ts'ebetsong `Binary` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // moemeli ho ts'ebetsong ea i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait e lokela ho hlophisa tlhahiso ea eona e le palo ho hexadecimal, ka `a` ho ea ho `f` ka tlase.
///
/// Bakeng sa linomoro tsa khale tse saennweng (`i8` ho `i128`, le `isize`), litekanyetso tse mpe li hlophisitsoe e le tlatsetso ea bobeli.
///
///
/// Folakha e ngoe, `#`, e eketsa `0x` ka pel'a sehlahisoa.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `i32`:
///
/// ```
/// let x = 42; // 42 ke '2a' ka hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Ho kenya ts'ebetsong `LowerHex` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // moemeli ho ts'ebetsong ea i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait e lokela ho hlophisa tlhahiso ea eona e le palo ho hexadecimal, ka `A` ho ea ho `F` maemong a holimo.
///
/// Bakeng sa linomoro tsa khale tse saennweng (`i8` ho `i128`, le `isize`), litekanyetso tse mpe li hlophisitsoe e le tlatsetso ea bobeli.
///
///
/// Folakha e ngoe, `#`, e eketsa `0x` ka pel'a sehlahisoa.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `i32`:
///
/// ```
/// let x = 42; // 42 ke '2A' ka hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Ho kenya ts'ebetsong `UpperHex` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // moemeli ho ts'ebetsong ea i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait e lokela ho hlophisa tlhahiso ea eona joalo ka sebaka sa memori.
/// Hangata sena se hlahisoa e le hexadecimal.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // sena se hlahisa ntho e kang '0x7f06092ac6d0'
/// ```
///
/// Ho kenya ts'ebetsong `Pointer` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // sebelisa `as` ho fetolela `*const T`, e sebelisang Pointer, eo re ka e sebelisang
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait e lokela ho hlophisa tlhahiso ea eona ka mongolo oa mahlale le `e` e tlase.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ke '4.2e1' ka mongolo oa mahlale
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Ho kenya ts'ebetsong `LowerExp` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // moemeli ho ts'ebetsong ea f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait e lokela ho hlophisa tlhahiso ea eona ka mongolo oa mahlale le `E` ea boemo bo holimo.
///
/// Bakeng sa tlhaiso-leseling e batsi ka lifomate, bona [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Tšebeliso ea mantlha le `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ke '4.2E1' ka mongolo oa mahlale
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Ho kenya ts'ebetsong `UpperExp` ka mofuta:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // moemeli ho ts'ebetsong ea f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// E hlophisa boleng e sebelisa fomate e fanoeng.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Mosebetsi oa `write` o nka molapo o tsoang, le sebopeho sa `Arguments` se ka kopantsoang le `format_args!` macro.
///
///
/// Likhang li tla hlophisoa ho latela mohala o boletsoeng ka har'a molatsoana o hlahisitsoeng.
///
/// # Examples
///
/// Tšebeliso mantlha:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Ka kopo hlokomela hore ho ka ba molemo ho sebelisa [`write!`].Mohlala:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Re ka sebelisa methati ea fomate ea kamehla bakeng sa likhang tsohle.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Ntho e 'ngoe le e' ngoe e na le khang e lekanang e etelletsoeng pele ka khoele.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // TŠIRELETSO: arg le args.args li tsoa likhang tse tšoanang,
                // e netefatsang hore li-index li lula li le ka har'a meeli.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Ho ka ba le sengoathoana se le seng feela sa khoele se setseng.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // TŠIRELETSO: arg le args li tsoa likhang tse tšoanang,
    // e netefatsang hore li-index li lula li le ka har'a meeli.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Ntša khang e nepahetseng
    debug_assert!(arg.position < args.len());
    // TŠIRELETSO: arg le args li tsoa likhang tse tšoanang,
    // e netefatsang hore index ea eona e lula e le ka har'a meeli.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Ebe u etsa khatiso e itseng
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // TŠIRELETSO: cnt le args li tsoa Likhang tse tšoanang,
            // e netefatsang hore index ena e lula e le ka har'a meeli.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Ho palama kamora ho fela hoa ntho e itseng.E khutlisitsoe ke `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Ngola poso ena.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Re batla ho fetola sena
            buf: wrap(self.buf),

            // 'Me u li boloke
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Mekhoa ea mothusi e sebelisetsoang ho katela le ho sebetsana le likhang tsa ho fomata tse ka sebelisoang ke mefuta eohle ea traits.
    //

    /// E etsa padding e nepahetseng bakeng sa palo e kholo e seng e ntšitsoe ka str.
    /// The str ha ea lokela ho ba le lets'oao la palo e felletseng, e tla eketsoa ka mokhoa ona.
    ///
    /// # Arguments
    ///
    /// * ha e na molato, hore na palo ea mantlha ea mantlha e ne e le ntle kapa e le zero.
    /// * qalo ya lebitso, haeba ho fanwe ka sebopeho sa '#' (Alternate), ke sona sehlongwapele sa ho behwa kapele ho palo.
    ///
    /// * buf, lenane la li-byte leo palo e hlophisitsoeng ho lona
    ///
    /// Ts'ebetso ena e tla ikarabella ka nepo bakeng sa lifolakha tse fanoeng hammoho le bophara bo fokolang.
    /// E ke ke ea nka ho nepahala ho nahanela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Re hloka ho tlosa "-" ho tsoa palo ea palo.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // O ngola letšoao haeba le teng, ebe o ngola lehlaphahlapha haeba le kopiloe
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Lebala la `width` ke karolo ea `min-width` hona joale.
        match self.width {
            // Haeba ho se na litlhoko tse tlase tsa bolelele re ka ngola li-byte feela.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Hlahloba hore na re fetile bophara bo tlase, haeba ho joalo re ka ngola li-byte feela.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Letšoao le sehlongwapele se ea pele ho padding haeba sebopeho sa ho tlatsa se le zero
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Ho seng joalo, lets'oao le sehlongwapele se latela phala
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Mosebetsi ona o nka selae sa khoele ebe oa o fetisetsa ho buffer ea kahare kamora ho sebelisa lifolakha tse nepahetseng tsa sebopeho.
    /// Lifolakha tse amoheloang ka likhoele tse tloaelehileng ke tsena:
    ///
    /// * bophara, bophara bo fokolang ba seo o lokelang ho se ntša
    /// * fill/align - seo u lokelang ho se ntša le moo u ka se hlahisang teng haeba mohala o fanoeng o hloka ho maneoa
    /// * ho nepahala, bolelele bo boholo ho tsoa, khoele e fokotsoe haeba e le telele ho feta bolelele bona
    ///
    /// Mosebetsi ona o hlokomoloha mekhahlelo ea `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Etsa bonnete ba hore ho na le tsela e potlakileng ka pele
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Tšimo ea `precision` e ka hlalosoa e le `max-width` bakeng sa mohala o hlophisitsoeng.
        //
        let s = if let Some(max) = self.precision {
            // Haeba khoele ea rona e telele ho feta ho nepahala, re tlameha ho ba le truncation.
            // Leha ho le joalo lifolakha tse ling tse kang `fill`, `width` le `align` li tlameha ho sebetsa joalo ka mehleng.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM mona e ke ke ea paka hore `..i` e ke ke ea panic `&s[..i]`, empa rea tseba hore e ke ke ea panic.
                // Sebelisa `get` + `unwrap_or` ho qoba `unsafe` mme ho seng joalo u se ke oa hlahisa khoutu efe kapa efe e amanang le panic mona.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Lebala la `width` ke karolo ea `min-width` hona joale.
        match self.width {
            // Haeba re ka tlase ho bolelele bo boholo, 'me ha ho na litlhoko tse tlase tsa bolelele, re ka tsoa ka khoele
            //
            None => self.buf.write_str(s),
            // Haeba re ka tlase ho bophara bo boholo, sheba hore na re fetile bophara bo tlase, haeba ho joalo ho bonolo joalo ka ho ntša khoele feela.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Haeba re ka tlase ho bophahamo bo boholo le bo tlase, tlatsa bophara bo tlase ka khoele + e boletsoeng.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ngola pre-padding ebe u khutlisa e sa ngolisoang post-padding.
    /// Batsali ba ikarabella ho netefatsa hore poso-padding e ngotsoe kamora ntho e ntseng e katisoa.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// E nka likarolo tse hlophisitsoeng mme e sebelisa padding.
    /// E nka hore moletsi o se a fane ka likarolo ka nepo e hlokahalang, hore `self.precision` e ka hlokomolohuoa.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // bakeng sa zero padding e hlokomelang, re fana ka lets'oao pele ebe re itšoara joalo ka ha eka ha re na letshwao ho tloha qalong.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // kamehla letšoao le ea pele
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // tlosa lets'oao likarolong tse hlophisitsoeng
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // Likarolo tse setseng li feta ts'ebetsong e tloaelehileng ea ho pata.
            let len = formatted.len();
            let ret = if width <= len {
                // ha ho na padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ena ke taba e tloaelehileng mme re nka tsela e khuts'oane
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // TSHIRELETSO: Sena se sebedisetswa `flt2dec::Part::Num` le `flt2dec::Part::Copy`.
            // Ho bolokehile ho e sebelisa bakeng sa `flt2dec::Part::Num` kaha char char `c` e pakeng tsa `b'0'` le `b'9'`, ho bolelang hore `s` ke UTF-8 e sebetsang.
            // Mohlomong ho bolokehile ts'ebetsong ho e sebelisa bakeng sa `flt2dec::Part::Copy(buf)` kaha `buf` e lokela ho hlaka ASCII, empa ho a khonahala hore motho e mong a fete ka boleng bo bobe ba `buf` ho `flt2dec::to_shortest_str` kaha e le mosebetsi oa sechaba.
            //
            // FIXME: Etsa qeto ea hore na sena se ka fella ka UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // Linoko tse 64
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// E ngola lintlha tse ling ho sesosa sa konokono se fumanehang ka har'a fomate ena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Sena se lekana le:
    ///         // ngola! (fomata, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// O ngola tlhaiso-leseling e hlophisitsoeng ketsahalong ena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Lifolakha tsa ho fomata
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Sebopeho se sebelisoang e le 'fill' neng kapa neng ha ho tsamaellana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Re hlophisa ho hokahana ka ho le letona le ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Folakha e bonts'ang mofuta oa tatellano o kopiloeng.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Khetho ea khetho e boletsoeng ka khetho ea khetho e lokela ho ba.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Haeba re fumane bophara, rea e sebelisa
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Ho seng joalo ha re etse letho le ikhethang
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Ho khetholla ka mokhoa o ikhethileng bakeng sa mefuta ea linomoro.
    /// Ntle le moo, bophara bo boholo bakeng sa mefuta ea likhoele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Haeba re fumane ho nepahala, rea ho sebelisa.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Ntle le moo re fetohela ho 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// E etsa qeto ea hore na folakha ea `+` e boletsoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// E etsa qeto ea hore na folakha ea `-` e boletsoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // O batla letshwao la ho tlosa?Eba le eona!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// E etsa qeto ea hore na folakha ea `#` e boletsoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// E etsa qeto ea hore na folakha ea `0` e boletsoe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Re hlokomoloha likhetho tsa fomate.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Etsa qeto ea hore na re batla API ea sechaba bakeng sa lifolakha tsena tse peli.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// E theha sehahi sa [`DebugStruct`] se etselitsoeng ho thusa ka ho theha ts'ebetsong ea [`fmt::Debug`] bakeng sa li-structs.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// E theha sehahi sa `DebugTuple` se etselitsoeng ho thusa ka ho theha ts'ebetsong ea `fmt::Debug` bakeng sa li-tuple structs.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// E theha sehahi sa `DebugList` se etselitsoeng ho thusa ka ho theha ts'ebetsong ea `fmt::Debug` bakeng sa meaho e joalo ka ea lenane.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// E theha sehahi sa `DebugSet` se etselitsoeng ho thusa ka ho theha ts'ebetsong ea `fmt::Debug` bakeng sa meaho e ts'oanang.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Mohlala ona o rarahaneng ho feta, re sebelisa [`format_args!`] le `.debug_set()` ho aha lethathamo la libetsa tsa papali:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// E theha sehahi sa `DebugMap` se etselitsoeng ho thusa ka ho theha ts'ebetsong ea `fmt::Debug` bakeng sa meaho e joalo ka 'mapa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Ts'ebetsong ea sebopeho sa mantlha sa traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Haeba char e batla ho baleha, ho sallela morao ho fihlela joale ebe u ngola, ho seng joalo tlola
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Folakha e ngoe e se e tšoeroe ke LowerHex joalo ka ha e khethehile-e supa hore na sehlongwapele ka 0x.
        // Re e sebelisa ho tseba hore na zero e tla atoloha kapa che, ebe re e beha ntle le mabaka ho fumana sehlongwapele.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Ts'ebetsong ea Display/Debug bakeng sa mefuta e fapaneng ea mantlha

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell e alimiloe ka mokhoa o ts'oanang kahoo re ke ke ra sheba boleng ba eona mona.
                // Bontša seswari sebakeng.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Haeba u ne u lebelletse hore liteko li tla ba mona, sheba fesheneng ea core/tests/fmt.rs, ho bonolo haholo ho feta ho theha meralo eohle ea rt::Piece mona.
//
// Hape ho na le liteko ho crate e abetsoeng, bakeng sa ba hlokang likabo.