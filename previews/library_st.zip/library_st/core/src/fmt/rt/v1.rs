//! Ena ke module ea kahare e sebelisoang ke ifmt!nako ea ho matha.Meaho ena e hlahisoa ka tatellano ea tatellano ho hlophisa likhoele tsa fomate pele ho nako.
//!
//! Litlhaloso tsena li ts'oana le lipalo tsa tsona tsa `ct`, empa li fapane ka hore tsena li ka abuoa ka lipalo ebile li ntlafalitsoe hanyane bakeng sa nako ea ho matha
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Lintlafatso tse ka bang teng tse ka kopeloang e le karolo ea taelo ea ho fomata.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Ho bontša hore litaba li lokela ho tsamaellana le leqele.
    Left,
    /// Ho bontša hore litaba li lokela ho hokahana hantle.
    Right,
    /// Sesupo sa hore litaba li lokela ho hokahanngoa bohareng.
    Center,
    /// Ha ho tumellano e kopiloeng.
    Unknown,
}

/// E sebelisoa ke li-specifiers tsa [width](https://doc.rust-lang.org/std/fmt/#width) le [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// E boletsoeng ka nomoro ea 'nete, e boloka boleng
    Is(usize),
    /// E boletsoeng ka ho sebelisa li-syntax tsa `$` le `*`, e boloka index ho `args`
    Param(usize),
    /// Ha ea hlalosoa
    Implied,
}