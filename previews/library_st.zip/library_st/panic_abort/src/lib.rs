//! Ts'ebetsong ea Rust panics ka mokhoa oa ho khaotsa
//!
//! Ha e bapisoa le ts'ebetsong ka ho phutholoha, crate ena e bonolo haholo!Ha ho buuoa joalo, ha e tšoane haholo, empa ke ena!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" tefo ea moputso le shim ho ea ntšang mpa e loketseng sethaleng se amehang.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // letsetsa std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Ho Windows, sebelisa sesebelisoa se ikhethileng sa __fastfail.Ho Windows 8 le hamorao, sena se tla emisa ts'ebetso hang hang ntle le ho tsamaisa batsamaisi ba kantle ho ts'ebetso.
            // Mefuteng ea pejana ea Windows, tatellano ena ea litaelo e tla nkuoa e le tlolo ea phihlello, e emise ts'ebetso empa e sa fete basebelisi bohle ba ikhethang.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ena ke ts'ebetsong e ts'oanang le ea libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Sena ... ke ntho e makatsang.Tl; dr;ke hore sena se hlokahala ho hokahanya ka nepo, tlhaloso e telele e ka tlase.
//
// Hona joale li-binaries tsa libcore/libstd tseo re li romellang kaofela li hlophisitsoe le `-C panic=unwind`.Sena se etsoa ho netefatsa hore li-binary li tsamaisana hantle le maemo a mangata kamoo ho ka khonehang.
// Moqapi, leha ho le joalo, o hloka "personality function" bakeng sa mesebetsi eohle e hlophisitsoeng le `-C panic=unwind`.Ts'ebetso ena ea botho e ngotsoe ka thata ho lets'oao `rust_eh_personality` mme e hlalosoa ke ntho ea `eh_personality` lang.
//
// So...
// hobaneng o sa hlalose ntho eo feela mona?Potso e ntle!Tsela eo linako tsa ts'ebetso tsa panic li hokahantsoeng ka eona ha e le hantle ke lintho tse poteletseng ka hore ke "sort of" lebenkeleng la moqapi oa crate, empa li hlile li hokahane haeba e 'ngoe e sa hokahana hantle.
//
// Sena se qetella se bolela hore crate le panic_unwind crate li ka hlaha lebenkeleng la moqapi oa crate, 'me haeba ka bobeli li hlalosa `eh_personality` lang ntho eo e tla ba le phoso.
//
// Ho sebetsana le sena moqapi o hloka feela hore `eh_personality` e hlalosoe haeba nako ea ho sebetsa ea panic e hokahantsoeng ke nako ea ho phomola, mme ho seng joalo ha e hlokehe hore e hlalosoe (ka nepo joalo).
// Tabeng ena, leha ho le joalo, laeborari ena e hlalosa feela lets'oao lena ka hona ho na le botho bo itseng kae kae.
//
// Ha e le hantle letshwao lena le hlalosoa feela hore le ts'oaroe ho fihlela li-binaries tsa libcore/libstd, empa ha lea lokela ho bitsoa hobane re sa hokahane le nako ea ho matha e sa tlolang.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Ho x86_64-pc-windows-gnu re sebelisa tšebetso ea botho ba rona e hlokang ho khutlisa `ExceptionContinueSearch` ha re ntse re fetisa liforeimi tsohle tsa rona.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // E ts'oanang le e kaholimo, sena se tsamaellana le `eh_catch_typeinfo` lang ntho e sebelisoang feela ho Emscripten hajoale.
    //
    // Kaha panics ha e hlahise mekhelo le mekhelo ea kantle ho naha hajoale ke UB e nang le -C panic=ho ntša mpa (leha sena se ka fetoha), mehala efe kapa efe ea catch_unwind e ke ke ea sebelisa mofuta ona.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Tsena tse peli li bitsoa ke lintho tsa rona tsa ho qalisa ho i686-pc-windows-gnu, empa ha ho hlokahale hore li etse letho hore 'mele e be bohlasoa.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}