//! Laeborari ea tšehetso bakeng sa bangoli ba bangata ha ba hlalosa li-macro tse ncha.
//!
//! Laeborari ena, e fanoeng ke kabo e tloaelehileng, e fana ka mefuta e sebelisitsoeng likhokahanong tsa litlhaloso tse hlakileng tsa ts'ebetso joalo ka li-macros `#[proc_macro]`, likarolo tse kholo tsa `#[proc_macro_attribute]` le litšoaneleho tse tsoang ho moetlo`#[proc_macro_derive]`.
//!
//!
//! Bona [the book] bakeng sa tse ling.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// E khetholla hore na proc_macro e entsoe hore e fumanehe lenaneong le ntseng le sebetsa hajoale.
///
/// Proc_macro crate e etselitsoe feela ho sebelisoa ka har'a ts'ebetsong ea ts'ebetso ea macro ea ts'ebetso.Mesebetsi eohle ho crate panic ena haeba e entsoe ka ntle ho ts'ebetso ea macro, joalo ka ho tsoa ho script script kapa teko ea yuniti kapa binary e tloaelehileng ea Rust.
///
/// Ka ho nahanisisa ka lilaebrari tsa Rust tse etselitsoeng ho ts'ehetsa linyeoe tsa tšebeliso ea macro le tse seng tsa bongata, `proc_macro::is_available()` e fana ka tsela e sa ts'oenyeheng ea ho bona hore na lits'ebeletso tsa motheo tse hlokoang ho sebelisa API ea proc_macro li teng hajoale.
/// E khutlisa 'nete haeba e kentsoe kahare ho ts'ebetso ea macro, ke leshano haeba e qapiloe ho tsoa ho efe kapa efe ea binary.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Mofuta oa mantlha o fanoeng ke crate ena, e emelang molapo o sa bonahaleng oa tokens, kapa, haholo-holo, tatellano ea lifate tsa token.
/// Mofuta ona o fana ka likarolo tsa ho potoloha holim'a lifate tsa token, hape, ho bokella lifate tse ngata tsa token molatsoaneng o le mong.
///
///
/// Hona ka bobeli ke kenyelletso le tlhahiso ea litlhaloso tsa `#[proc_macro]`, `#[proc_macro_attribute]` le `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Phoso e khutlisitsoe ho `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// E khutlisa `TokenStream` e se nang letho e se nang lifate tsa token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// E hlahloba hore na `TokenStream` ena ha e na letho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Boiteko ba ho khaola khoele hore e be tokens ebe o tšoaea tokens hore e be molapo oa token.
/// E ka hloleha ka mabaka a 'maloa, mohlala, haeba mohala o na le likhaohano tse sa lekanyetsoang kapa litlhaku tse seng teng ka puo eo.
///
/// Li-tokens tsohle tse molatsoaneng o pharalletseng li fumana li-`Span::call_site()` spans.
///
/// NOTE: Liphoso tse ling li ka baka panics sebakeng sa ho khutlisa `LexError`.Re na le tokelo ea ho fetola liphoso tsena hore li be `LexError`s hamorao.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// E hatisa molapo oa token e le khoele e lokelang ho fetoha ntle le tahlehelo hore e khutlele molatong o tšoanang oa token (modulo spans), ntle le mohlomong oa `TokenTree: : Group`s e nang le li-delimiters tsa `Delimiter::None` le linomoro tse fosahetseng tsa linomoro.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// E hatisa token ka mokhoa o loketseng ho lokisa bothata.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// E etsa molapo oa token o nang le sefate se le seng sa token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// E bokella lifate tse 'maloa tsa token molatsoaneng o le mong.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ts'ebetso ea "flattening" melapong ea token, e bokella lifate tsa token ho tsoa melapong e mengata ea token hore e be molapo o le mong.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Sebelisa ts'ebetsong e ntlafalitsoeng ea if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Lintlha tsa ts'ebetso ea sechaba tsa mofuta oa `TokenStream`, joalo ka li-iterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Mohlophisi oa `TokenTree`s ea`TokenStream`s.
    /// Iteration ke "shallow", mohlala, iterator ha e khutlele lihlopheng tse arotsoeng, mme e khutlisa lihlopha kaofela e le lifate tsa token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` e amohela tokens e hatellang ebe e atoloha ho ba `TokenStream` e hlalosang kenyelletso.
/// Mohlala, `quote!(a + b)` e tla hlahisa polelo, eo, ha e hlahlojoa, e thehang `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ho qotsa ho etsoa ka `$`, 'me ho sebetsa ka ho nka lebitso le le leng le latelang e le lentsoe le sa qotsoang.
/// Ho qotsa `$` ka boeona, sebelisa `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Sebaka sa khoutu ea mohloli, hammoho le tlhaiso-leseling e kholo.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// E etsa `Diagnostic` e ncha ka `message` e fanoeng ka span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Nako e rarollang sebakeng sa tlhaloso e kholo.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Nako ea ho kopa mochini oa hona joale oa ts'ebetso.
    /// Lits'oants'o tse entsoeng ka nako ena li tla rarolloa joalo ka ha li ngotsoe ka kotloloho sebakeng sa mehala e meholo (bohloeki ba sebaka sa mehala) mme khoutu e ngoe e sebakeng sa mehala ea macro le eona e tla khona ho bua ka tsona.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Nako e emelang bohloeki ba `macro_rules`, 'me ka linako tse ling e rarolloa sebakeng sa litlhaloso tse kholo (mefuta-futa ea lehae, mabitso, `$crate`) mme ka linako tse ling sebakeng sa mehala ea mehala (ntho e ngoe le e ngoe e ngoe).
    ///
    /// Sebaka sa bolelele ba nako se nkuoe sebakeng sa mehala.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Mohloli oa mantlha oa mohloli oo nako ena e supang ho oona.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` bakeng sa tokens kholisong e kholo e fetileng eo `self` e hlahisitsoeng ho eona, haeba e le teng.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Nako ea khoutu ea mohloli oa mohloli eo `self` e entsoeng ho eona.
    /// Haeba `Span` ena e sa hlahisoa ho tsoa linthong tse ling tse kholo, boleng ba ho khutla bo ts'oana le `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// E fumana line/column e qalang faeleng ea mohloli bakeng sa nako ena.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// O fumana qetello ea line/column faeleng ea mohloli bakeng sa nako ena.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// E theha sebaka se secha se akaretsang `self` le `other`.
    ///
    /// E khutlisa `None` haeba `self` le `other` li tsoa lifaele tse fapaneng.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// E theha nako e ncha e nang le tlhaiso-leseling e tšoanang ea line/column joalo ka `self` empa e rarolla matšoao joalo ka ha eka e ne e le `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// E theha sebaka se secha se nang le boits'oaro bo tšoanang ba tharollo ea mabitso joaloka `self` empa se na le tlhaiso-leseling ea line/column ea `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// E bapisa ho spans ho bona hore na baa lekana.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// E khutlisetsa mongolo oa mohloli kamora nako.
    /// Sena se boloka khoutu ea mohloli oa mantlha, ho kenyeletsoa libaka le litlatsetso.
    /// E khutlisa sephetho feela haeba nako e lekana le khoutu ea 'nete ea mohloli.
    ///
    /// Note: Litholoana tse hlokomelehang tsa macro li lokela ho itšetleha feela ka tokens eseng sengoliloeng sena.
    ///
    /// Litholoana tsa mosebetsi ona ke boiteko bo botle bo ka sebelisetsoang tlhahlobo ea mafu feela.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Hatisa sepane ka mokhoa o loketseng ho lokisa bothata.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Sehlopha se nang le mela se emelang qalo kapa pheletso ea `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Mohala o nang le li-index tse 1 faeleng ea mohloli moo sepane se qalang kapa se qetellang (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Kholomo e nang le li-index tse 0 (ka litlhaku tsa UTF-8) faeleng ea mohloli eo nako e qalang kapa e qetellang ho eona (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Faele ea mohloli ea `Span` e fanoeng.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// O fumana tsela e lebisang ho file ena ea mohloli.
    ///
    /// ### Note
    /// Haeba khoutu ea span e amanang le `SourceFile` ena e hlahisitsoe ke macro e kantle, macro ena, ena e kanna ea se be tsela ea 'nete tsamaisong ea lifaele.
    /// Sebelisa [`is_real`] ho hlahloba.
    ///
    /// Hape hlokomela hore leha `is_real` e khutlisa `true`, haeba `--remap-path-prefix` e fetisitsoe moleng oa taelo, tsela eo e fanoeng e kanna ea se sebetse.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// E khutlisa `true` haeba faele ena ea mohloli e le faele ea 'nete,' me e sa hlahisoe ke kholo ea kantle ea macro.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Hona ke ho qhekella ho fihlela lipakeng tsa li-intercrate li kenngwa tšebetsong mme re ka ba le lifaele tsa mohloli oa 'nete bakeng sa li-span tse hlahisitsoeng ka har'a macros a kantle.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token e le 'ngoe kapa tatellano e arotsoeng ea lifate tsa token (mohlala, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Molapo oa token o lika-likelitsoe ke basomi ba likonteraka.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Sekhetho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Sebopeho sa matšoao a le mong (`+`, `,`, `$`, jj.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Sebopeho sa 'nete (`'a'`), khoele (`"hello"`), nomoro (`2.3`), jj.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// E khutlisa bolelele ba sefate sena, e fana ka mokhoa oa `span` oa token kapa molapo o lekantsoeng.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// E hlophisa nako ea *feela token*.
    ///
    /// Hlokomela hore haeba token ena e le `Group` mokhoa ona o ke ke oa hlophisa nako ea tokens e ngoe le e ngoe kahare, sena se tla fetisetsa mokhoa oa `set_span` oa mofuta ka mong.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// E hatisa sefate sa token ka mokhoa o loketseng ho lokisa bothata.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // E 'ngoe le e' ngoe ea tsona e na le lebitso ka mofuta oa sebopeho sa `` debug '' se tsoang ho uena, kahoo o se ts'oenyehe ka karolo e 'ngoe ea tlhatlhobo
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// E hatisa sefate sa token e le khoele e lokelang ho fetoloa ntle le tahlehelo hore e khutlele sefateng se le seng sa token (modulo spans), ntle le mohlomong `TokenTree: : Group`s e nang le li-delimiters tsa `Delimiter::None` le lipalo tse fosahetseng tsa linomoro.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Molapo o khethiloeng oa token.
///
/// `Group` ka hare e na le `TokenStream` e pota-potiloeng ke `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// E hlalosa hore na tatellano ea lifate tsa token e arotsoe joang.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Moqapi o sa hlakang, o ka etsang mohlala, o ka hlaha o potile tokens o tsoa "macro variable" `$var`.
    /// Ho bohlokoa ho boloka lintho tse tlang pele bophelong ba mosebeletsi maemong a kang `$var * 3` moo `$var` e leng `1 + 2`.
    /// Batho ba khethiloeng ka ho hlaka ba ka 'na ba se ke ba pholoha ho potoloha ha molapo oa token ka khoele.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// E theha `Group` e ncha e nang le delimiter e fanoeng le molapo oa token.
    ///
    /// Sehahi sena se tla beha nako ea sehlopha sena ho `Span::call_site()`.
    /// Ho fetola nako u ka sebelisa mokhoa oa `set_span` ka tlase.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// E khutlisa moeli oa `Group` ena
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// E khutlisa `TokenStream` ea tokens tse khethiloeng ho `Group` ena.
    ///
    /// Hlokomela hore molapo o khutlisitsoeng oa token ha o kenyeletse moeli o khutlisitsoeng kaholimo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// E khutlisa sepane sa nako bakeng sa bajaki ba molapo ona oa token, e haolang `Group` kaofela.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// E khutlisa sepane se supileng moeling o qalang oa sehlopha sena.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// E khutlisa sepane se supang moeling o koalang oa sehlopha sena.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// E hlophisa nako ea "delimiters" tsa Sehlopha sena, empa eseng tokens ea eona ea kahare.
    ///
    /// Mokhoa ona o tla **se** behe bolelele ba tokens tsohle tse kahare ho sehlopha sena, empa e tla beha feela bolelele ba sekhahla sa tokens boemong ba `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// E hatisa sehlopha joalo ka khoele e lokelang ho fetoloa ntle le tahlehelo hore e khutlele sehlopheng se le seng (modulo spans), ntle le mohlomong `TokenTree: : Group`s e nang le li-delimiters tsa `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ke semelo sa matšoao se le seng se kang `+`, `-` kapa `#`.
///
/// Basebelisi ba mefuta-futa ba kang `+=` ba emeloa e le mehlala e 'meli ea `Punct` ka mefuta e fapaneng ea `Spacing` e khutlisitsoeng.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Hore na `Punct` e lateloa hang-hang ke `Punct` e ngoe kapa e lateloa ke token e 'ngoe kapa whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// mohlala, `+` ke `Alone` ho `+ =`, `+ident` kapa `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// mohlala, `+` ke `Joint` ho `+=` kapa `'#`.
    /// Ntle le moo, qotsulo e le 'ngoe `'` e ka ikopanya le likonopo ho theha `'ident` ea bophelo bohle.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// E theha `Punct` e ncha ho tsoa ho sebapali le sebaka se fanoeng.
    /// Khang ea `ch` e tlameha ho ba sebopeho sa matšoao se lumelloang ke puo, ho seng joalo ts'ebetso e tla ba panic.
    ///
    /// `Punct` e khutlisitsoeng e tla ba le bolelele ba nako ba `Span::call_site()` bo ka ntlafatsoang ka mokhoa oa `set_span` ka tlase.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// E khutlisa boleng ba tlhaku ena ea matšoao joalo ka `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// E khutlisa sebaka sa tlhaku ena ea matšoao, e bontšang hore na e lateloa hang-hang ke `Punct` e ngoe molapong oa token, hore e tle e khone ho kopanngoa ho ba sebapali sa (`Joint`), kapa e lateloa ke token kapa whitespace (`Alone`) kahoo motsamaisi e felile.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// E khutlisa sepane sa moetso ona oa matšoao.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Beakanya sepane sa tlhaku ena ea matšoao.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// E hatisa matšoao a puo e le khoele e lokelang ho fetoloa ntle le tahlehelo hore e khutlele ho motho ea tšoanang.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Sekhetho (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// E etsa `Ident` e ncha ka `string` e fanoeng hammoho le `span` e boletsoeng.
    /// Khang ea `string` e tlameha ho ba sesupisi se nepahetseng se lumelloang ke puo (ho kenyeletsoa mantsoe a bohlokoa, mohlala, `self` kapa `fn`).Ho seng joalo, ts'ebetso e tla panic.
    ///
    /// Hlokomela hore `span`, eo hajoale e leng rustc, e hlophisa tlhaiso-leseling ea bohloeki bakeng sa sesupa-tsela sena.
    ///
    /// Ho tloha nakong ena `Span::call_site()` e kenella ka ho hlaka ho bohloeki ba "call-site" ho bolelang hore lits'oants'o tse entsoeng ka nako ena li tla rarolloa joalo ka ha li ngotsoe ka kotloloho sebakeng sa mohala o moholo, mme khoutu e ngoe e sebakeng sa mehala ea macro e tla khona ho bua ka eona le bona.
    ///
    ///
    /// Hamorao maqhubu a kang `Span::def_site()` a tla lumella ho khetha bohloeki ba "definition-site" ho bolelang hore lits'oants'o tse entsoeng ka nako ena li tla rarolloa moo tlhaloso ea macro e fumanehang mme khoutu e ngoe e sebakeng sa mehala ea macro e ke ke ea khona ho bua ka tsona.
    ///
    /// Ka lebaka la bohlokoa ba hajoale ba bohloeki sehahi sena, ho fapana le tse ling tokens, se hloka hore `Span` e boletsoe mohahong.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// E ts'oana le `Ident::new`, empa e theha senotlolo sa (`r#ident`) se tala.
    /// Khang ea `string` e ka ba sesupa se nepahetseng se lumelloang ke puo (ho kenyeletsoa mantsoe a bohlokoa, mohlala, `fn`).
    /// Mantsoe a bohlokoa a sebelisoang likarolong tsa tsela (mohlala
    /// `self`, `super`) ha li tšehetsoe, 'me li tla baka panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// E khutlisa bolelele ba `Ident`, e akaretsa mohala oohle o khutlisitsoeng ke [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// E hlophisa nako ea `Ident` ena, mohlomong e fetola moelelo oa eona oa bohloeki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Hatisa sesupa-tsela e le khoele se lokelang ho fetoloa ntle le tahlehelo hore se khutlele ho se khethollang.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Khoele ea sebele (`"hello"`), byte khoele (`b"hello"`), sebapali (`'a'`), sebapali sa byte (`b'a'`), palo e felletseng kapa e phaphametseng e nang le sehlomathiso kapa `
///
/// Lingoliloeng tsa Boolean tse kang `true` le `false` ha se tsa mona, ke `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// E theha palo e ncha e nang le sepikara se nang le boleng bo boletsoeng.
        ///
        /// Ts'ebetso ena e tla theha palo e felletseng e kang `1u32` moo boleng bo felletseng bo boletsoeng e le karolo ea pele ea token mme karolo ea eona e boetse e lekantsoe qetellong.
        /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele maeto a ho potoloha ka `TokenStream` kapa likhoele 'me li ka aroloa ho tokens tse peli (`-` le tsa sebele).
        ///
        ///
        /// Lingoliloeng tse entsoeng ka mokhoa ona li na le nako ea `Span::call_site()` ka boikhethelo, e ka hlophisoang ka mokhoa oa `set_span` ka tlase.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// E theha lebitso le lecha le sa lekanyetsoang le nang le boleng bo boletsoeng.
        ///
        /// Ts'ebetso ena e tla theha palo e kholo joalo ka `1` moo boleng bo felletseng bo boletsoeng e le karolo ea pele ea token.
        /// Ha ho na suffix e boletsoeng ho token ena, ho bolelang hore lithapelo tse kang `Literal::i8_unsuffixed(1)` li lekana le `Literal::u32_unsuffixed(1)`.
        /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele liphororo ka `TokenStream` kapa likhoele 'me li ka aroloa ka tokens tse peli (`-` le tsa sebele).
        ///
        ///
        /// Lingoliloeng tse entsoeng ka mokhoa ona li na le nako ea `Span::call_site()` ka boikhethelo, e ka hlophisoang ka mokhoa oa `set_span` ka tlase.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// E theha sebaka se secha sa "floating" se sa thehoang.
    ///
    /// Sehahi sena se ts'oana le tse kang `Literal::i8_unsuffixed` moo boleng ba float bo hlahisoang ka kotloloho ho token empa ha ho na sehlong se sebelisoang, ka hona ho ka nahanoa hore ke `f64` hamorao ho moqapi.
    ///
    /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele liphororo ka `TokenStream` kapa likhoele 'me li ka aroloa ka tokens tse peli (`-` le tsa sebele).
    ///
    /// # Panics
    ///
    /// Mosebetsi ona o hloka hore float e boletsoeng e felile, ka mohlala haeba e le infinity kapa NaN mosebetsi ona o tla panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// E theha sebaka se secha sa ntlha e phaphametseng.
    ///
    /// Sehahi sena se tla etsa ntho ea 'nete joalo ka `1.0f32` moo boleng bo boletsoeng e le karolo e fetileng ea token le `f32` ke sehlophisi sa token.
    /// token ena e tla lula e tšoauoa hore ke `f32` ho moqapi.
    /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele liphororo ka `TokenStream` kapa likhoele 'me li ka aroloa ka tokens tse peli (`-` le tsa sebele).
    ///
    ///
    /// # Panics
    ///
    /// Mosebetsi ona o hloka hore float e boletsoeng e felile, ka mohlala haeba e le infinity kapa NaN mosebetsi ona o tla panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// E theha sebaka se secha sa "floating" se sa thehoang.
    ///
    /// Sehahi sena se ts'oana le tse kang `Literal::i8_unsuffixed` moo boleng ba float bo hlahisoang ka kotloloho ho token empa ha ho na sehlong se sebelisoang, ka hona ho ka nahanoa hore ke `f64` hamorao ho moqapi.
    ///
    /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele liphororo ka `TokenStream` kapa likhoele 'me li ka aroloa ka tokens tse peli (`-` le tsa sebele).
    ///
    /// # Panics
    ///
    /// Mosebetsi ona o hloka hore float e boletsoeng e felile, ka mohlala haeba e le infinity kapa NaN mosebetsi ona o tla panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// E theha sebaka se secha sa ntlha e phaphametseng.
    ///
    /// Sehahi sena se tla etsa ntho ea 'nete joalo ka `1.0f64` moo boleng bo boletsoeng e le karolo e fetileng ea token le `f64` ke sehlophisi sa token.
    /// token ena e tla lula e tšoauoa hore ke `f64` ho moqapi.
    /// Lingoliloeng tse entsoeng ka linomoro tse fosahetseng li kanna tsa se phele liphororo ka `TokenStream` kapa likhoele 'me li ka aroloa ka tokens tse peli (`-` le tsa sebele).
    ///
    ///
    /// # Panics
    ///
    /// Mosebetsi ona o hloka hore float e boletsoeng e felile, ka mohlala haeba e le infinity kapa NaN mosebetsi ona o tla panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Khoele ea sebele.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Sebopeho sa sebele.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Khoele ea Byte ka kotloloho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// E khutlisa sekhahla se akaretsang sena ka kotloloho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// E hlophisa sepane se amanang le sena.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// E khutlisa `Span` eo e leng seteishene sa `self.span()` se nang le li-byte tsa mohloli feela ho `range`.
    /// E khutlisa `None` haeba nako e neng e tla fokotsoa e kantle ho meeli ea `self`.
    ///
    // FIXME(SergioBenitez): hlahloba hore na mofuta oa byte o qala le ho fela moeling oa UTF-8 oa mohloli.
    // ho seng joalo, ho ka etsahala hore panic e etsahale kae kapa kae ha sengoloa sa mohloli se hatisoa.
    // FIXME(SergioBenitez): ha ho na mokhoa oa hore mosebelisi a tsebe seo `self.span()` e hlileng e leng 'mapa ho sona, ka hona mokhoa ona o ka bitsoa feela ka bofofu.
    // Mohlala, `to_string()` bakeng sa sebapali 'c' e khutlisa "'\u{63}'";ha ho na mokhoa oa hore mosebelisi a tsebe hore na sengoloa sa mohloli e ne e le 'c' kapa hore na e ne e le '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ho hong ho tšoanang le `Option::cloned`, empa bakeng sa `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, borokho bo fana feela ka `to_string`, kenya `fmt::Display` ts'ebetsong ho eona (mokokotlo oa kamano e tloaelehileng lipakeng tsa tse peli).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// E hatisa ea sebele joalo ka khoele e lokelang ho fetoha ka mokhoa o sa lahleheng ebe e khutlela ho eona ka mokhoa o ts'oanang (ntle le ha ho ka khoneha ho potoloha bakeng sa litheko tse phaphametseng).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ho fihlella phihlello ea mefuta-futa ea tikoloho.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Fumana seemo se fapaneng sa tikoloho 'me u se kenye ho aha leseli la ts'epahalo.
    /// Haha sistimi e sebelisang mohokahanyi e tla tseba hore se fetohang se fihletsoe nakong ea pokello, 'me se tla tseba ho nchafatsa moaho ha boleng ba se fapaneng bo fetoha.
    ///
    /// Ntle le ts'ekamelo ea ho latela ts'ebetso ena e lokela ho lekana le `env::var` ho tsoa laeboraring e tloaelehileng, ntle le hore ngangisano e tlameha ho ba UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}