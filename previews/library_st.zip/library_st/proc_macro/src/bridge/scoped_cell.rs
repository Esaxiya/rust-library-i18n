//! `Cell` mofuta o fapaneng oa nako ea bophelo ea (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Tlanya kopo ea lambda, ka bophelo bohle.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Thaepa lambda e nka bophelo bohle, ke hore, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) sebetsa ho potoloha meeli ea projeke ka newtype FIXME(#52812) e nkela `&'a mut <T as ApplyL<'b>>::Out` sebaka
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// E beha boleng ho `self` ho `replacement` ha e ntse e sebetsa `f`, e fumanang boleng ba khale, ka mokhoa o ts'oanang.
    /// Boleng ba khale bo tla khutlisoa kamora hore `f` e tsoe, esita le ka panic, ho kenyeletsoa le liphetoho tse entsoeng ho eona ke `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Wrapper e netefatsang hore sele e lula e tlala (ka boemo ba mantlha, ka khetho e fetotsoe ke `f`), leha `f` e ne e tšohile.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// E beha boleng ho `self` ho `value` ha e ntse e sebetsa `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}