# `rustc-std-workspace-core` crate

この crate は、シムで空の crate であり、`libcore` に依存し、そのすべてのコンテンツを再エクスポートします。
crate は、crates.io の crates に依存するように標準ライブラリを強化するための核心です。

標準ライブラリが依存する crates.io 上の Crates は、空の crates.io からの `rustc-std-workspace-core` crate に依存する必要があります。

`[patch]` を使用して、このリポジトリ内のこの crate にオーバーライドします。
その結果、crates.io 上の crates は、このリポジトリで定義されているバージョンである `libcore` への依存関係 edge を描画します。
これで、Cargo が crates を正常にビルドできるように、すべての依存関係エッジが描画されます。

crates.io 上の crates は、すべてが正しく機能するために、`core` という名前のこの crate に依存する必要があることに注意してください。それを行うには、次のものを使用できます。

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` キーを使用すると、crate の名前が `core` に変更されます。つまり、次のようになります。

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

Cargo がコンパイラーを呼び出し、コンパイラーによって注入された暗黙の `extern crate core` ディレクティブを満たします。




