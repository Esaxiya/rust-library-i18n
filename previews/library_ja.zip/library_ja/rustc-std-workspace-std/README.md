# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate のドキュメントを参照してください。