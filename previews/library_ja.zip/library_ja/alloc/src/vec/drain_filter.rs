use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// クロージャを使用して要素を削除する必要があるかどうかを判断するイテレータ。
///
/// この構造体は [`Vec::drain_filter`] によって作成されます。
/// 詳細については、そのドキュメントを参照してください。
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next` への次の呼び出しによって検査されるアイテムのインデックス。
    pub(super) idx: usize,
    /// これまでに (removed) を排出したアイテムの数。
    pub(super) del: usize,
    /// 排水前の `vec` の元の長さ。
    pub(super) old_len: usize,
    /// フィルタテスト述語。
    pub(super) pred: F,
    /// フィルタテスト述部で panic が発生したことを示すフラグ。
    /// これは、`DrainFilter` の残りの部分の消費を防ぐために、ドロップ実装のヒントとして使用されます。
    /// 未処理のアイテムは `vec` でバックシフトされますが、それ以上のアイテムがフィルター述語によってドロップまたはテストされることはありません。
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// 基になるアロケータへの参照を返します。
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // 述部が呼び出された *後* にインデックスを更新します。
                // インデックスが以前に更新され、述部 panics の場合、このインデックスの要素がリークされます。
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // これはかなりめちゃくちゃな状態であり、明らかに正しいことは実際にはありません。
                        // `pred` を実行し続けたくないので、未処理の要素をすべてバックシフトして、それらがまだ存在することを vec に通知します。
                        //
                        // バックシフトは、述部の panic の前に最後に正常に排出されたアイテムのダブルドロップを防ぐために必要です。
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // フィルタ述部がまだパニックになっていない場合は、残りの要素を消費してみてください。
        // すでにパニックになっている場合でも、ここでの消費が panics である場合でも、残りの要素をバックシフトします。
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}