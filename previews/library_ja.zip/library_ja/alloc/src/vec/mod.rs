//! `Vec<T>` と記述された、ヒープに割り当てられたコンテンツを持つ連続した拡張可能な配列タイプ。
//!
//! Vectors には、`O(1)` インデックス、償却済み `O(1)` プッシュ (最後まで)、および `O(1)` ポップ (最後から) があります。
//!
//!
//! Vectors は、`isize::MAX` バイトを超えて割り当てないようにします。
//!
//! # Examples
//!
//! [`Vec::new`] を使用して [`Vec`] を明示的に作成できます。
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... または [`vec!`] マクロを使用して:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // 10 個のゼロ
//! ```
//!
//! vector の末尾に [`push`] 値を設定できます (必要に応じて vector が大きくなります)。
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! 値のポップはほとんど同じように機能します。
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors は、インデックス作成もサポートしています ([`Index`] および [`IndexMut`] traits を介して)。
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// `Vec<T>` として記述され、'vector' と発音される連続した拡張可能な配列型。
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] マクロは、初期化をより便利にするために提供されています。
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// また、`Vec<T>` の各要素を指定された値で初期化することもできます。
/// これは、特にゼロの vector を初期化する場合に、割り当てと初期化を別々のステップで実行するよりも効率的です。
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // 以下は同等ですが、遅くなる可能性があります。
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// 詳細については、[Capacity and Reallocation](#capacity-and-reallocation) を参照してください。
///
/// `Vec<T>` を効率的なスタックとして使用します。
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // プリント 3、2、1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` タイプは、[`Index`] trait を実装しているため、インデックスで値にアクセスできます。例はより明確になります:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // '2' が表示されます
/// ```
///
/// ただし、注意してください。`Vec` にないインデックスにアクセスしようとすると、ソフトウェアは panic になります。これを行うことはできません:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// インデックスが `Vec` にあるかどうかを確認する場合は、[`get`] および [`get_mut`] を使用します。
///
/// # Slicing
///
/// `Vec` は変更可能です。一方、スライスは読み取り専用オブジェクトです。
/// [slice][prim@slice] を入手するには、[`&`] を使用します。例:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... そしてそれだけです!
/// // 次のようにすることもできます。
/// let u: &[usize] = &v;
/// // またはこのように:
/// let u: &[_] = &v;
/// ```
///
/// Rust では、読み取りアクセスを提供するだけの場合は、vectors ではなく引数としてスライスを渡すのが一般的です。[`String`] と [`&str`] についても同じことが言えます。
///
/// # 容量と再割り当て
///
/// vector の容量は、vector に追加される future 要素に割り当てられるスペースの量です。これは、vector 内の実際の要素の数を指定する vector の *長さ* と混同しないでください。
/// vector の長さがその容量を超えると、その容量は自動的に増加しますが、その要素は再割り当てする必要があります。
///
/// たとえば、容量が 10 で長さが 0 の vector は、さらに 10 個の要素用のスペースがある空の vector になります。10 個以下の要素を vector にプッシュしても、容量が変更されたり、再割り当てが発生したりすることはありません。
/// ただし、vector の長さが 11 に増加すると、再割り当てする必要があり、時間がかかる可能性があります。このため、vector が取得すると予想される大きさを指定するには、可能な限り [`Vec::with_capacity`] を使用することをお勧めします。
///
/// # Guarantees
///
/// その信じられないほど基本的な性質のために、`Vec` はその設計について多くの保証をします。これにより、一般的なケースで可能な限りオーバーヘッドが少なくなり、安全でないコードによって原始的な方法で正しく操作できるようになります。これらの保証は、修飾されていない `Vec<T>` を参照していることに注意してください。
/// 追加のタイプパラメータが追加された場合 (たとえば、カスタムアロケータをサポートするため)、それらのデフォルトをオーバーライドすると、動作が変わる可能性があります。
///
/// 最も基本的に、`Vec` は (ポインター、容量、長さ) トリプレットです。それ以上でもそれ以下でもありません。これらのフィールドの順序は完全に指定されていないため、適切な方法を使用してこれらを変更する必要があります。
/// ポインタが null になることはないため、このタイプは null ポインタに最適化されています。
///
/// ただし、ポインタが実際に割り当てられたメモリを指しているとは限りません。
/// 特に、[`Vec::new`]、[`vec![]`][`vec!`]、[`Vec::with_capacity(0)`][`Vec::with_capacity`] を介して、または空の Vec で [`shrink_to_fit`] を呼び出すことにより、容量 0 の `Vec` を構築する場合、メモリは割り当てられません。同様に、`Vec` 内にゼロサイズの型を格納する場合、それらにスペースは割り当てられません。
/// *この場合、`Vec` は 0 の [`capacity`] を報告しない可能性があることに注意してください*。
/// `Vec` [`mem: : size_of:: の場合にのみ、割り当てます < T>`]` () * capacity()> 0`。
/// 一般に、`Vec` の割り当ての詳細は非常に微妙です。`Vec` を使用してメモリを割り当て、それを他の目的 (安全でないコードに渡すか、独自のメモリバックアップコレクションを構築するため) に使用する場合は、`from_raw_parts` を使用して `Vec` をリカバリし、それをドロップすることにより、このメモリの割り当てを解除します。
///
/// `Vec` に割り当てられたメモリがある場合、それが指すメモリはヒープ上にあり (アロケータ Rust によって定義されるように、デフォルトで使用するように構成されています)、そのポインタは [`len`] で初期化された連続した要素を順番に指します (スライスに強制したかどうかを確認してください)、その後に [`capacity`]`、`[`len`] 論理的に初期化されていない連続した要素が続きます。
///
///
/// 容量 4 の要素 `'a'` および `'b'` を含む vector は、次のように視覚化できます。上部は `Vec` 構造体であり、ヒープ、長さ、および容量の割り当ての先頭へのポインターが含まれています。
/// 下部は、ヒープ上の連続したメモリブロックの割り当てです。
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** は、初期化されていないメモリを表します。[`MaybeUninit`] を参照してください。
/// - Note: ABI は安定しておらず、`Vec` はそのメモリレイアウト (フィールドの順序を含む) について保証しません。
///
/// `Vec` 次の 2 つの理由により、要素が実際にスタックに格納されている "small optimization" を実行することはありません。
///
/// * 安全でないコードが `Vec` を正しく操作することはより困難になります。`Vec` の内容は、移動されただけでは安定したアドレスを持たず、`Vec` が実際にメモリを割り当てたかどうかを判断するのがより困難になります。
///
/// * これは一般的なケースにペナルティを課し、アクセスごとに追加の branch が発生します。
///
/// `Vec` 完全に空であっても、自動的に縮小することはありません。これにより、不要な割り当てや割り当て解除が発生しなくなります。`Vec` を空にしてから、同じ [`len`] に埋め戻すと、アロケーターが呼び出されることはありません。未使用のメモリを解放したい場合は、[`shrink_to_fit`] または [`shrink_to`] を使用してください。
///
/// [`push`] 報告された容量が十分である場合、[`insert`] は決して (再) 割り当てません。[`push`] および [`insert`] は、[`len`]`==`[`capacity`] の場合に * (再) 割り当てます。つまり、報告された容量は完全に正確であり、信頼できます。必要に応じて、`Vec` によって割り当てられたメモリを手動で解放するために使用することもできます。
/// 一括挿入方法は、不要な場合でも再割り当てする場合があります。
///
/// `Vec` フル時に再割り当てするとき、または [`reserve`] が呼び出されるとき、特定の成長戦略を保証するものではありません。現在の戦略は基本的なものであり、一定でない成長係数を使用することが望ましい場合があります。もちろん、どの戦略を使用しても、*O*(1) の償却済み [`push`] が保証されます。
///
/// `vec![x; n]`, `vec![a, b, c, d]` および [`Vec::with_capacity(n)`][`Vec::with_capacity`] はすべて、要求された容量の `Vec` を生成します。
/// [`len`]`==`[`capacity`] の場合 ([`vec!`] マクロの場合のように)、要素を再割り当てまたは移動することなく、`Vec<T>` を [`Box<[T]>`][owned slice] との間で変換できます。
///
/// `Vec` 削除されたデータを具体的に上書きすることはありませんが、特に保存することもありません。初期化されていないメモリは、必要に応じて使用できるスクラッチスペースです。それは一般的に、最も効率的であるか、さもなければ実装が簡単なことを何でもするでしょう。セキュリティ上の理由から、削除されたデータが消去されることに依存しないでください。
/// `Vec` をドロップしても、そのバッファは単に別の `Vec` によって再利用される可能性があります。
/// 最初に `Vec` のメモリをゼロにしたとしても、オプティマイザはこれを保存する必要のある副作用と見なさないため、実際には発生しない可能性があります。
/// ただし、壊れないケースが 1 つあります。それは、`unsafe` コードを使用して超過容量に書き込み、それに合わせて長さを増やすことは常に有効です。
///
/// 現在、`Vec` は、要素がドロップされる順序を保証していません。
/// 順序は過去に変更されており、再度変更される可能性があります。
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// 固有の方法
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// 新しい空の `Vec<T>` を構築します。
    ///
    /// vector は、要素がプッシュされるまで割り当てられません。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// 指定された容量で新しい空の `Vec<T>` を構築します。
    ///
    /// vector は、再割り当てせずに正確に `capacity` 要素を保持できます。
    /// `capacity` が 0 の場合、vector は割り当てません。
    ///
    /// 返される vector には *容量* が指定されていますが、vector の *長さ* はゼロであることに注意してください。
    ///
    /// 長さと容量の違いの説明については、*[容量と再割り当て]* を参照してください。
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector には、より多くの容量がありますが、アイテムは含まれていません。
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // これらはすべて再割り当てせずに行われます...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... しかし、これにより vector が再割り当てされる可能性があります
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// 別の vector の生のコンポーネントから直接 `Vec<T>` を作成します。
    ///
    /// # Safety
    ///
    /// チェックされていない不変条件の数が多いため、これは非常に安全ではありません。
    ///
    /// * `ptr` [`String`]/`Vec を介して事前に割り当てられている必要があります <T>` (少なくとも、そうでない場合は正しくない可能性が高いです)。
    /// * `T` `ptr` が割り当てられたものと同じサイズと配置である必要があります。
    ///   (`T` の配置はそれほど厳密ではありません。メモリを同じレイアウトで割り当て、割り当てを解除する必要があるという [`dealloc`] の要件を満たすには、実際には配置を等しくする必要があります。)
    ///
    /// * `length` `capacity` 以下である必要があります。
    /// * `capacity` ポインタが割り当てられた容量である必要があります。
    ///
    /// これらに違反すると、アロケータの内部データ構造が破損するなどの問題が発生する可能性があります。たとえば、長さ `size_t` の C `char` 配列へのポインタから `Vec<u8>` を構築することは **安全ではありません**。
    /// また、`Vec<u16>` とその長さから作成するのは安全ではありません。これは、アロケーターが配置を考慮し、これら 2 つのタイプの配置が異なるためです。
    /// バッファはアライメント 2 (`u16` の場合) で割り当てられましたが、`Vec<u8>` に変換した後、アライメント 1 で割り当てが解除されます。
    ///
    /// `ptr` の所有権は `Vec<T>` に効果的に転送され、`Vec<T>` は、ポインターが指すメモリの内容を自由に割り当て解除、再割り当て、または変更できます。
    /// この関数を呼び出した後、他に何もポインタを使用していないことを確認してください。
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXMEvec_into_raw_parts が安定したときにこれを更新します。
    ///     // `v` のデストラクタを実行しないようにして、割り当てを完全に制御できるようにします。
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` に関するさまざまな重要な情報を引き出します
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // 4、5、6 でメモリを上書きする
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // すべてを Vec に戻します
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 新しい空の `Vec<T, A>` を構築します。
    ///
    /// vector は、要素がプッシュされるまで割り当てられません。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// 提供されたアロケータを使用して、指定された容量で新しい空の `Vec<T, A>` を構築します。
    ///
    /// vector は、再割り当てせずに正確に `capacity` 要素を保持できます。
    /// `capacity` が 0 の場合、vector は割り当てません。
    ///
    /// 返される vector には *容量* が指定されていますが、vector の *長さ* はゼロであることに注意してください。
    ///
    /// 長さと容量の違いの説明については、*[容量と再割り当て]* を参照してください。
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector には、より多くの容量がありますが、アイテムは含まれていません。
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // これらはすべて再割り当てせずに行われます...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... しかし、これにより vector が再割り当てされる可能性があります
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// 別の vector の生のコンポーネントから直接 `Vec<T, A>` を作成します。
    ///
    /// # Safety
    ///
    /// チェックされていない不変条件の数が多いため、これは非常に安全ではありません。
    ///
    /// * `ptr` [`String`]/`Vec を介して事前に割り当てられている必要があります <T>` (少なくとも、そうでない場合は正しくない可能性が高いです)。
    /// * `T` `ptr` が割り当てられたものと同じサイズと配置である必要があります。
    ///   (`T` の配置はそれほど厳密ではありません。メモリを同じレイアウトで割り当て、割り当てを解除する必要があるという [`dealloc`] の要件を満たすには、実際には配置を等しくする必要があります。)
    ///
    /// * `length` `capacity` 以下である必要があります。
    /// * `capacity` ポインタが割り当てられた容量である必要があります。
    ///
    /// これらに違反すると、アロケータの内部データ構造が破損するなどの問題が発生する可能性があります。たとえば、長さ `size_t` の C `char` 配列へのポインタから `Vec<u8>` を構築することは **安全ではありません**。
    /// また、`Vec<u16>` とその長さから作成するのは安全ではありません。これは、アロケーターが配置を考慮し、これら 2 つのタイプの配置が異なるためです。
    /// バッファはアライメント 2 (`u16` の場合) で割り当てられましたが、`Vec<u8>` に変換した後、アライメント 1 で割り当てが解除されます。
    ///
    /// `ptr` の所有権は `Vec<T>` に効果的に転送され、`Vec<T>` は、ポインターが指すメモリの内容を自由に割り当て解除、再割り当て、または変更できます。
    /// この関数を呼び出した後、他に何もポインタを使用していないことを確認してください。
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXMEvec_into_raw_parts が安定したときにこれを更新します。
    ///     // `v` のデストラクタを実行しないようにして、割り当てを完全に制御できるようにします。
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` に関するさまざまな重要な情報を引き出します
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // 4、5、6 でメモリを上書きする
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // すべてを Vec に戻します
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// `Vec<T>` を未加工のコンポーネントに分解します。
    ///
    /// 基になるデータへの生のポインタ、vector の長さ (要素単位)、およびデータの割り当てられた容量 (要素単位) を返します。
    /// これらは、[`from_raw_parts`] の引数と同じ順序の同じ引数です。
    ///
    /// この関数を呼び出した後、呼び出し元は `Vec` によって以前に管理されていたメモリを担当します。
    /// これを行う唯一の方法は、生のポインター、長さ、および容量を [`from_raw_parts`] 関数を使用して `Vec` に変換し直し、デストラクタがクリーンアップを実行できるようにすることです。
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // これで、生のポインターを互換性のある型に変換するなど、コンポーネントに変更を加えることができます。
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// `Vec<T>` を未加工のコンポーネントに分解します。
    ///
    /// 基になるデータへの生のポインター、vector の長さ (要素単位)、データの割り当てられた容量 (要素単位)、およびアロケーターを返します。
    /// これらは、[`from_raw_parts_in`] の引数と同じ順序の同じ引数です。
    ///
    /// この関数を呼び出した後、呼び出し元は `Vec` によって以前に管理されていたメモリを担当します。
    /// これを行う唯一の方法は、生のポインター、長さ、および容量を [`from_raw_parts_in`] 関数を使用して `Vec` に変換し直し、デストラクタがクリーンアップを実行できるようにすることです。
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // これで、生のポインターを互換性のある型に変換するなど、コンポーネントに変更を加えることができます。
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// vector が再割り当てせずに保持できる要素の数を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// 指定された `Vec<T>` に挿入される要素の少なくとも `additional` 以上の容量を予約します。
    /// コレクションは、頻繁な再割り当てを回避するために、より多くのスペースを予約する場合があります。
    /// `reserve` を呼び出した後、容量は `self.len() + additional` 以上になります。
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// # Panics
    ///
    /// 新しい容量が `isize::MAX` バイトを超える場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// 指定された `Vec<T>` に挿入される要素を正確に `additional` 増やすための最小容量を予約します。
    ///
    /// `reserve_exact` を呼び出した後、容量は `self.len() + additional` 以上になります。
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// アロケータは、コレクションに要求よりも多くのスペースを与える可能性があることに注意してください。
    /// したがって、容量を正確に最小にすることはできません。
    /// future の挿入が予想される場合は、`reserve` を優先します。
    ///
    /// # Panics
    ///
    /// 新しい容量が `usize` をオーバーフローした場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// 指定された `Vec<T>` に挿入される要素の少なくとも `additional` の容量を予約しようとします。
    /// コレクションは、頻繁な再割り当てを回避するために、より多くのスペースを予約する場合があります。
    /// `try_reserve` を呼び出した後、容量は `self.len() + additional` 以上になります。
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// # Errors
    ///
    /// 容量がオーバーフローした場合、またはアロケータが障害を報告した場合、エラーが返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // メモリを事前に予約し、できない場合は終了します
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 今、私たちはこれが私たちの複雑な仕事の途中で OOM できないことを知っています
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // とても難しい
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// 指定された `Vec<T>` に挿入される正確な `additional` 要素の最小容量を予約しようとします。
    /// `try_reserve_exact` を呼び出した後、`Ok(())` を返す場合、容量は `self.len() + additional` 以上になります。
    ///
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// アロケータは、コレクションに要求よりも多くのスペースを与える可能性があることに注意してください。
    /// したがって、容量を正確に最小にすることはできません。
    /// future の挿入が予想される場合は、`reserve` を優先します。
    ///
    /// # Errors
    ///
    /// 容量がオーバーフローした場合、またはアロケータが障害を報告した場合、エラーが返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // メモリを事前に予約し、できない場合は終了します
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // 今、私たちはこれが私たちの複雑な仕事の途中で OOM できないことを知っています
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // とても難しい
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector の容量を可能な限り縮小します。
    ///
    /// 可能な限り長さに近づけてドロップダウンしますが、アロケータは vector にさらにいくつかの要素のためのスペースがあることを通知する場合があります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // 容量は長さよりも小さくなることはなく、等しい場合は何もする必要がないため、より大きな容量で呼び出すだけで、`RawVec::shrink_to_fit` の panic のケースを回避できます。
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector の容量を下限で縮小します。
    ///
    /// 容量は、少なくとも長さと提供された値の両方と同じ大きさのままになります。
    ///
    ///
    /// 現在の容量が下限よりも小さい場合、これはノーオペレーションです。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector を [`Box<[T]>`][owned slice] に変換します。
    ///
    /// これにより、余分な容量が減少することに注意してください。
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// 余分な容量はすべて削除されます。
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector を短くし、最初の `len` 要素を保持し、残りを削除します。
    ///
    /// `len` が vector の現在の長さより大きい場合、これは効果がありません。
    ///
    /// [`drain`] メソッドは `truncate` をエミュレートできますが、余分な要素が削除されるのではなく返されます。
    ///
    ///
    /// この方法は、vector の割り当てられた容量には影響しないことに注意してください。
    ///
    /// # Examples
    ///
    /// 5 つの要素 vector を 2 つの要素に切り捨てます。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// `len` が vector の現在の長さより大きい場合、切り捨ては発生しません。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// `len == 0` の場合の切り捨ては、[`clear`] メソッドの呼び出しと同等です。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // これは安全です:
        //
        // * `drop_in_place` に渡されたスライスは有効です。`len > self.len` の場合は、無効なスライスの作成を回避し、
        // * vector の `len` は、`drop_in_place` を呼び出す前に縮小されるため、`drop_in_place` が panic に 1 回送信された場合、値が 2 回ドロップされることはありません (panics が 2 回の場合、プログラムは異常終了します)。
        //
        //
        //
        unsafe {
            // Note: これは `>=` ではなく `>` であることを意図しています。
            //       `>=` に変更すると、パフォーマンスに悪影響を与える場合があります。
            //       詳細については、#78884 を参照してください。
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// vector 全体を含むスライスを抽出します。
    ///
    /// `&s[..]` と同等です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// vector 全体の可変スライスを抽出します。
    ///
    /// `&mut s[..]` と同等です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector のバッファへの生のポインタを返します。
    ///
    /// 呼び出し元は、vector がこの関数が返すポインターよりも長生きすることを確認する必要があります。そうしないと、ゴミを指すことになります。
    /// vector を変更すると、そのバッファーが再割り当てされる可能性があります。これにより、vector へのポインターも無効になります。
    ///
    /// 呼び出し元は、このポインタまたはそこから派生したポインタを使用して、ポインタ (non-transitively) が指すメモリが (`UnsafeCell` 内を除いて) 書き込まれないようにする必要もあります。
    /// スライスの内容を変更する必要がある場合は、[`as_mut_ptr`] を使用してください。
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // 中間参照を作成する `deref` を通過しないように、同じ名前の slice メソッドをシャドウします。
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector のバッファへの安全でない可変ポインタを返します。
    ///
    /// 呼び出し元は、vector がこの関数が返すポインターよりも長生きすることを確認する必要があります。そうしないと、ゴミを指すことになります。
    ///
    /// vector を変更すると、そのバッファーが再割り当てされる可能性があります。これにより、vector へのポインターも無効になります。
    ///
    /// # Examples
    ///
    /// ```
    /// // 4 つの要素に十分な大きさの vector を割り当てます。
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // 生のポインタ書き込みを介して要素を初期化し、長さを設定します。
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // 中間参照を作成する `deref_mut` を通過しないように、同じ名前の slice メソッドをシャドウします。
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// 基になるアロケータへの参照を返します。
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector の長さを `new_len` に強制します。
    ///
    /// これは、タイプの正規不変量を維持しない低レベルの操作です。
    /// 通常、vector の長さの変更は、[`truncate`]、[`resize`]、[`extend`]、[`clear`] などの安全な操作のいずれかを使用して行われます。
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] 以下である必要があります。
    /// - `old_len..new_len` の要素を初期化する必要があります。
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// このメソッドは、vector が他のコードのバッファーとして機能している状況、特に FFI を介して役立つ場合があります。
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // これは、ドキュメントの例の最小限のスケルトンにすぎません。
    /// # // これを実際のライブラリの開始点として使用しないでください。
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // FFI メソッドのドキュメントによると、 "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // 安全性: `deflateGetDictionary` が `Z_OK` を返す場合、次のようになります。
    ///     // 1. `dict_length` 要素が初期化されました。
    ///     // 2.
    ///     // `dict_length` <= `set_len` を安全に呼び出すことができる容量 (32_768)。
    ///     unsafe {
    ///         // FFI 呼び出しを行います...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... そして長さを初期化されたものに更新します。
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// 次の例は適切ですが、`set_len` 呼び出しの前に内部の vectors が解放されなかったため、メモリリークが発生します。
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` は空なので、要素を初期化する必要はありません。
    /// // 2. `0 <= capacity` `capacity` が何であれ常に保持します。
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// 通常、ここでは、代わりに [`clear`] を使用してコンテンツを正しくドロップし、メモリをリークしないようにします。
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector から要素を削除し、それを返します。
    ///
    /// 削除された要素は、vector の最後の要素に置き換えられます。
    ///
    /// これは順序を保持しませんが、O(1) です。
    ///
    /// # Panics
    ///
    /// `index` が範囲外の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // self [index] を最後の要素に置き換えます。
            // 上記の境界チェックが成功した場合、最後の要素 (self [index] 自体である可能性があります) が存在する必要があることに注意してください。
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector 内の位置 `index` に要素を挿入し、その後のすべての要素を右にシフトします。
    ///
    ///
    /// # Panics
    ///
    /// `index > len` の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // 新しい要素のためのスペース
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // 間違いのない新しい価値を置く場所
            //
            {
                let p = self.as_mut_ptr().add(index);
                // スペースを作るためにすべてをシフトします。
                // ( `index` 番目の要素を 2 つの連続した場所に複製します。)
                ptr::copy(p, p.offset(1), len - index);
                // `index` 番目の要素の最初のコピーを上書きして、それを書き込みます。
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector 内の位置 `index` にある要素を削除して返し、その後のすべての要素を左にシフトします。
    ///
    ///
    /// # Panics
    ///
    /// `index` が範囲外の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // 私たちが取っている場所。
                let ptr = self.as_mut_ptr().add(index);
                // それをコピーして、スタックと vector に同時に値のコピーを安全に持たないようにします。
                //
                ret = ptr::read(ptr);

                // その場所を埋めるためにすべてを下にシフトします。
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// 述部によって指定された要素のみを保持します。
    ///
    /// つまり、`f(&e)` が `false` を返すように、すべての要素 `e` を削除します。
    /// このメソッドはその場で動作し、元の順序で各要素に 1 回だけアクセスし、保持されている要素の順序を保持します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// 要素は元の順序で 1 回だけアクセスされるため、外部状態を使用して、保持する要素を決定できます。
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // ドロップガードを実行しない場合は、プロセス中に穴が開く可能性があるため、ダブルドロップは避けてください。
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <- 処理された len-> |^- チェックの隣
        //                  | <- 削除された cnt-> |
        //      | <-original_len-> |Kept: 述語が true を返す要素。
        //
        // 穴: 要素スロットを移動またはドロップしました。
        // 未チェック: チェックされていない有効な要素。
        //
        // このドロップガードは、要素の述語または `drop` がパニックになったときに呼び出されます。
        // チェックされていない要素をシフトして穴を覆い、`set_len` を正しい長さにします。
        // 述語と `drop` がパニックにならない場合は、最適化されます。
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // 安全性: チェックされていないアイテムの末尾は、決して触れないため有効である必要があります。
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // 安全性: 穴を埋めた後、すべてのアイテムは連続したメモリにあります。
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // 安全性: チェックされていない要素は有効である必要があります。
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // `drop_in_place` がパニックになった場合にダブルドロップを回避するために、早めに進んでください。
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // 安全性: 落とした後、この要素に再び触れることはありません。
                unsafe { ptr::drop_in_place(cur) };
                // すでにカウンターを進めました。
                continue;
            }
            if g.deleted_cnt > 0 {
                // 安全性: `deleted_cnt`> 0 であるため、穴スロットは現在の要素と重ならないようにする必要があります。
                // 移動にはコピーを使用し、この要素に二度と触れないようにします。
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // すべてのアイテムが処理されます。これは、LLVM によって `set_len` に最適化できます。
        drop(g);
    }

    /// 同じキーに解決される vector の最初の連続する要素を除くすべてを削除します。
    ///
    ///
    /// vector がソートされている場合、これによりすべての重複が削除されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// 指定された等式関係を満たす vector の最初の連続する要素を除くすべてを削除します。
    ///
    /// `same_bucket` 関数は、vector から 2 つの要素への参照を渡され、要素が等しいかどうかを判断する必要があります。
    /// 要素はスライス内の順序とは逆の順序で渡されるため、`same_bucket(a, b)` が `true` を返す場合、`a` は削除されます。
    ///
    ///
    /// vector がソートされている場合、これによりすべての重複が削除されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// コレクションの後ろに要素を追加します。
    ///
    /// # Panics
    ///
    /// 新しい容量が `isize::MAX` バイトを超える場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // isize::MAX を超えるバイトを割り当てる場合、またはサイズがゼロのタイプで長さの増分がオーバーフローする場合、これは panic または中止になります。
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector から最後の要素を削除して返します。空の場合は、[`None`] を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` のすべての要素を `Self` に移動し、`other` を空のままにします。
    ///
    /// # Panics
    ///
    /// vector の要素数が `usize` をオーバーフローした場合、Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// 他のバッファから `Self` に要素を追加します。
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// vector 内の指定された範囲を削除し、削除されたアイテムを生成するドレインイテレーターを作成します。
    ///
    /// イテレータが **ドロップ** されると、イテレータが完全に消費されていなくても、範囲内のすべての要素が vector から削除されます。
    /// イテレータが **ドロップされない** 場合 (たとえば [`mem::forget`] の場合)、削除される要素の数は指定されていません。
    ///
    /// # Panics
    ///
    /// 開始点が終了点よりも大きい場合、または終了点が vector の長さよりも大きい場合は、Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // フルレンジは vector をクリアします
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // メモリの安全性
        //
        // Drain が最初に作成されるとき、ソース vector の長さを短くして、Drain のデストラクタが実行されない場合に、初期化されていない要素や移動元の要素にアクセスできないようにします。
        //
        //
        // Drain は、削除する値を ptr::read で出力します。
        // 終了すると、vec の残りのテールがコピーされて穴が覆われ、vector の長さが新しい長さに復元されます。
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // Drain がリークした場合に備えて、self.vec の長さを開始するように設定します
            self.set_len(start);
            // IterMut の借用を使用して、Drain イテレーター全体 (&mut T など) の借用動作を示します。
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector をクリアし、すべての値を削除します。
    ///
    /// この方法は、vector の割り当てられた容量には影響しないことに注意してください。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// 'length' とも呼ばれる vector 内の要素の数を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// vector に要素が含まれていない場合、`true` を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 指定されたインデックスでコレクションを 2 つに分割します。
    ///
    /// `[at, len)` の範囲の要素を含む新しく割り当てられた vector を返します。
    /// 呼び出し後、元の vector には、以前の容量が変更されていない要素 `[0, at)` が含まれたままになります。
    ///
    ///
    /// # Panics
    ///
    /// `at > len` の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // 新しい vector は元のバッファを引き継ぎ、コピーを回避できます
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // 安全ではない `set_len` とアイテムを `other` にコピーします。
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `len` が `new_len` と等しくなるように、`Vec` をインプレースでサイズ変更します。
    ///
    /// `new_len` が `len` より大きい場合、`Vec` は差によって拡張され、追加の各スロットはクロージャー `f` を呼び出した結果で埋められます。
    ///
    /// `f` からの戻り値は、生成された順序で `Vec` になります。
    ///
    /// `new_len` が `len` より小さい場合、`Vec` は単純に切り捨てられます。
    ///
    /// このメソッドは、クロージャを使用して、プッシュするたびに新しい値を作成します。特定の値を [`Clone`] にする場合は、[`Vec::resize`] を使用します。
    /// [`Default`] trait を使用して値を生成する場合は、2 番目の引数として [`Default::default`] を渡すことができます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// `Vec` を消費してリークし、コンテンツへの変更可能な参照を返します。`&'a mut [T]`.
    /// タイプ `T` は、選択したライフタイム `'a` よりも長持ちする必要があることに注意してください。
    /// タイプに静的参照しかない場合、またはまったくない場合は、`'static` として選択できます。
    ///
    /// この関数は、リークしたメモリを回復する方法がないことを除いて、[`Box`] の [`leak`][Box::leak] 関数に似ています。
    ///
    ///
    /// この関数は、主にプログラムの残りの期間存続するデータに役立ちます。
    /// 返された参照を削除すると、メモリリークが発生します。
    ///
    /// # Examples
    ///
    /// 簡単な使用法:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector の残りのスペア容量を `MaybeUninit<T>` のスライスとして返します。
    ///
    /// 返されたスライスを使用して、vector にデータを入力できます (例:
    /// [`set_len`] メソッドを使用してデータを初期化済みとしてマークする前に、ファイルから読み取ることによって)。
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // 10 個の要素に十分な大きさの vector を割り当てます。
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // 最初の 3 つの要素を入力します。
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector の最初の 3 つの要素を初期化済みとしてマークします。
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // このメソッドは、バッファーへのポインターの無効化を防ぐために、`split_at_spare_mut` に関しては実装されていません。
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector のコンテンツを `T` のスライスとして返し、vector の残りの予備容量を `MaybeUninit<T>` のスライスとして返します。
    ///
    /// 返された予備の容量スライスを使用して、[`set_len`] メソッドを使用して初期化されたものとしてデータをマークする前に、vector をデータで埋めることができます (ファイルからの読み取りなど)。
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// これは低レベルの API であり、最適化の目的で注意して使用する必要があることに注意してください。
    /// `Vec` にデータを追加する必要がある場合は、正確なニーズに応じて、[`push`]、[`extend`]、[`extend_from_slice`]、[`extend_from_within`]、[`insert`]、[`append`]、[`resize`]、または [`resize_with`] を使用できます。
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 個の要素に十分な大きさの追加スペースを予約します。
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // 次の 4 つの要素を入力します。
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector の 4 つの要素を初期化済みとしてマークします。
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len は無視されるため、変更されることはありません
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// 安全性: 返された.2 (&mut usize) を変更することは、`.set_len(_)` を呼び出すことと同じと見なされます。
    ///
    /// この方法は、`extend_from_within` で一度にすべての vec パーツに一意にアクセスするために使用されます。
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` 要素に対して有効であることが保証されています
        // - `spare_ptr` はバッファの先の 1 つの要素を指しているため、`initialized` と重複しません
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `len` が `new_len` と等しくなるように、`Vec` をインプレースでサイズ変更します。
    ///
    /// `new_len` が `len` より大きい場合、`Vec` は差によって拡張され、追加の各スロットは `value` で埋められます。
    ///
    /// `new_len` が `len` より小さい場合、`Vec` は単純に切り捨てられます。
    ///
    /// このメソッドでは、渡された値のクローンを作成できるようにするために、`T` が [`Clone`] を実装する必要があります。
    /// より柔軟性が必要な場合 (または [`Clone`] ではなく [`Default`] に依存したい場合) は、[`Vec::resize_with`] を使用してください。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// スライス内のすべての要素を複製して `Vec` に追加します。
    ///
    /// スライス `other` を繰り返し、各要素のクローンを作成してから、この `Vec` に追加します。
    /// `other` vector は順番にトラバースされます。
    ///
    /// この関数は、代わりにスライスを操作することに特化していることを除いて、[`extend`] と同じであることに注意してください。
    ///
    /// Rust が特殊化された場合、この関数は非推奨になる可能性があります (ただし、引き続き使用できます)。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` 範囲から vector の終わりまで要素をコピーします。
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` 指定された範囲が自己のインデックス作成に有効であることを保証します
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// このコードは `extend_with_{element,default}` を一般化します。
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// 指定されたジェネレーターを使用して、vector を `n` 値で拡張します。
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // SetLenOnDrop を使用して、コンパイラが `ptr` から self.set_len() までのストアがエイリアスしないことを認識しない可能性があるバグを回避します。
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // 最後の要素を除くすべての要素を書き込む
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // next() panics の場合は、すべてのステップで長さをインクリメントします
                local_len.increment_len(1);
            }

            if n > 0 {
                // 不必要にクローンを作成することなく、最後の要素を直接書き込むことができます
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // スコープガードによって設定された len
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait の実装に従って、vector 内の連続する繰り返し要素を削除します。
    ///
    ///
    /// vector がソートされている場合、これによりすべての重複が削除されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// 内部メソッドと機能
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` 有効なインデックスである必要があります
    /// - `self.capacity() - self.len()` `>= src.len()` である必要があります
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len は、要素を初期化した後にのみ増加します
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - 呼び出し元は、src が有効なインデックスであることを保証します
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - 要素は `MaybeUninit::write` で初期化されたばかりなので、len を増やしても問題ありません
            // - リークを防ぐために、各要素の後に len が増加します (問題 #82533 を参照)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - 発信者は、`src` が有効なインデックスであることを保証します
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - 両方のポインタは一意のスライス参照 ( `＆mut [_]`) から作成されるため、有効であり、重複しません。
            //
            // - 要素は: Copy なので、元の値を使用せずにコピーしても問題ありません。
            // - `count` `source` の len に等しいため、ソースは `count` 読み取りに有効です
            // - `.reserve(count)` `spare.len() >= count` が `count` 書き込みに有効であることを保証します
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - 要素は `copy_nonoverlapping` によって初期化されました
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Vec の一般的な trait 実装
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) では、このメソッド定義に必要な固有の `[T]::to_vec` メソッドは使用できません。
    // 代わりに、cfg(test) NB でのみ使用可能な `slice::to_vec` 機能を使用してください。詳細については、slice.rs の slice::hack モジュールを参照してください。
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // 上書きされないものはすべて削除してください
        self.truncate(other.len());

        // self.len <= 上記の切り捨てにより、other.len であるため、ここのスライスは常にインバウンドです。
        //
        let (init, tail) = other.split_at(self.len());

        // 含まれている値の allocations/resources を再利用します。
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// 消費するイテレータ、つまり、各値を vector から (最初から最後まで) 移動するイテレータを作成します。
    /// これを呼び出した後、vector は使用できません。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s のタイプは String であり、&String ではありません
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // 適用する最適化がさらにない場合に、さまざまな SpecFrom/SpecExtend 実装が委任するリーフメソッド
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // これは、一般的なイテレータの場合です。
        //
        // この関数は、道徳的に次のものと同等である必要があります。
        //
        //      イテレータ内のアイテムの場合 {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // アドレス空間を割り当てなければならなかったので、NB はオーバーフローできません
                self.set_len(len + 1);
            }
        }
    }

    /// vector の指定された範囲を指定された `replace_with` イテレーターに置き換えるスプライシングイテレーターを作成し、削除されたアイテムを生成します。
    ///
    /// `replace_with` `range` と同じ長さである必要はありません。
    ///
    /// `range` イテレータが最後まで消費されなくても削除されます。
    ///
    /// `Splice` 値がリークされた場合に、vector から削除される要素の数は指定されていません。
    ///
    /// 入力イテレータ `replace_with` は、`Splice` 値がドロップされた場合にのみ消費されます。
    ///
    /// これは、次の場合に最適です。
    ///
    /// * テール (`range` の後の vector の要素) は空です。
    /// * または `replace_with` は、`range` の長さよりも少ないか等しい要素を生成します
    /// * または、`size_hint()` の下限が正確です。
    ///
    /// それ以外の場合は、一時的な vector が割り当てられ、テールが 2 回移動されます。
    ///
    /// # Panics
    ///
    /// 開始点が終了点よりも大きい場合、または終了点が vector の長さよりも大きい場合は、Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// クロージャを使用して要素を削除する必要があるかどうかを判断するイテレータを作成します。
    ///
    /// クロージャーが true を返す場合、要素は削除されて生成されます。
    /// クロージャが false を返す場合、要素は vector に残り、イテレータによって生成されません。
    ///
    /// このメソッドの使用は、次のコードと同等です。
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ここにあなたのコード
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// ただし、`drain_filter` の方が使いやすいです。
    /// `drain_filter` また、配列の要素をまとめてバックシフトできるため、より効率的です。
    ///
    /// `drain_filter` では、保持するか削除するかに関係なく、フィルタークロージャー内のすべての要素を変更することもできます。
    ///
    ///
    /// # Examples
    ///
    /// 元の割り当てを再利用して、配列を偶数と奇数に分割します。
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // 漏れを防ぐ (漏れ増幅)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// 要素を Vec にプッシュする前に、参照から要素をコピーする実装を拡張します。
///
/// この実装はスライスイテレータに特化しており、[`copy_from_slice`] を使用してスライス全体を一度に追加します。
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors の比較を実装します。[lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors の順序付けを実装します。[lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // [T] に drop を使用する raw スライスを使用して、vector の要素を最も弱い必要なタイプとして参照します。
            //
            // 特定の場合に有効性の質問を回避することができます
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec は割り当て解除を処理します
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// 空の `Vec<T>` を作成します。
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: テストは libstd をプルしますが、これによりここでエラーが発生します
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: テストは libstd をプルしますが、これによりここでエラーが発生します
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// サイズが要求された配列のサイズと完全に一致する場合、`Vec<T>` のコンテンツ全体を配列として取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// 長さが一致しない場合、入力は `Err` に戻ります。
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// `Vec<T>` のプレフィックスを取得するだけで問題がない場合は、最初に [`.truncate(N)`](Vec::truncate) を呼び出すことができます。
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // 安全性: `.set_len(0)` は常に健全です。
        unsafe { vec.set_len(0) };

        // 安全性: `Vec` のポインタは常に適切に配置され、
        // 配列に必要な配置はアイテムと同じです。
        // 十分なアイテムがあることを以前に確認しました。
        // `set_len` が `Vec` にアイテムもドロップしないように指示するため、アイテムはダブルドロップされません。
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}