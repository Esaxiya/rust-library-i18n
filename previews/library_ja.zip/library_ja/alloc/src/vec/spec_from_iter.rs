use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter に使用されるスペシャライゼーション trait
///
/// ## 委任グラフ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // 一般的なケースは、vector を関数に渡して、すぐに vector に再収集することです。
        // IntoIter がまったく進んでいない場合は、これを短絡できます。
        // 進んだらメモリを再利用してデータを前面に移動することもできます。
        // ただし、これを行うのは、結果の Vec に、一般的な FromIterator 実装を介して作成するよりも多くの未使用容量がない場合のみです。
        //
        // Vec の割り当て動作は意図的に指定されていないため、この制限は厳密には必要ありません。
        // しかし、それは控えめな選択です。
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // extend() 自体が空の Vec の spec_from に委任するため、spec_extend() に委任する必要があります
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// spec_extend は、最終的な容量 + 長さを推論するためにより多くの手順を実行する必要があるため、`iterator.as_slice().to_vec()` を利用し、より多くの作業を実行します。
// `to_vec()` 正しい金額を直接割り当てて、正確に記入します。
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) では、このメソッド定義に必要な固有の `[T]::to_vec` メソッドは使用できません。
    // 代わりに、cfg(test) NB でのみ使用可能な `slice::to_vec` 機能を使用してください。詳細については、slice.rs の slice::hack モジュールを参照してください。
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}