//! `String` をフォーマットおよび印刷するためのユーティリティ。
//!
//! このモジュールには、[`format!`] 構文拡張のランタイムサポートが含まれています。
//! このマクロは、実行時に引数を文字列にフォーマットするために、このモジュールへの呼び出しを発行するためにコンパイラーに実装されます。
//!
//! # Usage
//!
//! [`format!`] マクロは、C の `printf`/`fprintf` 関数または Python の `str.format` 関数に由来するものに精通していることを目的としています。
//!
//! [`format!`] 拡張機能の例は次のとおりです。
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" 先行ゼロ付き
//! ```
//!
//! これらから、最初の引数がフォーマット文字列であることがわかります。これが文字列リテラルであることがコンパイラによって要求されます。(妥当性チェックを実行するために) 渡される変数にすることはできません。
//! 次に、コンパイラはフォーマット文字列を解析し、提供された引数のリストがこのフォーマット文字列に渡すのに適しているかどうかを判断します。
//!
//! 単一の値を文字列に変換するには、[`to_string`] メソッドを使用します。これは、[`Display`] フォーマットの trait を使用します。
//!
//! ## 位置パラメータ
//!
//! 各フォーマット引数は、参照する値引数を指定できます。省略した場合は、"the next argument" と見なされます。
//! たとえば、フォーマット文字列 `{} {} {}` は 3 つのパラメーターを取り、指定されたのと同じ順序でフォーマットされます。
//! ただし、フォーマット文字列 `{2} {1} {0}` は、引数を逆の順序でフォーマットします。
//!
//! 2 種類の位置指定子を混ぜ始めると、少し注意が必要になる場合があります。"next argument" 指定子は、引数の反復子と考えることができます。
//! "next argument" 指定子が表示されるたびに、イテレーターが進みます。これにより、次のような動作が発生します。
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! 引数の内部イテレータは、最初の `{}` が表示されるまでに進められていないため、最初の引数を出力します。次に、2 番目の `{}` に到達すると、イテレータは 2 番目の引数に進みます。
//! 基本的に、引数に明示的に名前を付けるパラメーターは、位置指定子に関して引数に名前を付けないパラメーターには影響しません。
//!
//! すべての引数を使用するにはフォーマット文字列が必要です。それ以外の場合は、コンパイル時エラーになります。フォーマット文字列で同じ引数を複数回参照できます。
//!
//! ## 名前付きパラメーター
//!
//! Rust 自体には、関数の名前付きパラメーターに相当する Python のようなものはありませんが、[`format!`] マクロは、名前付きパラメーターを活用できるようにする構文拡張です。
//! 名前付きパラメーターは、引数リストの最後にリストされ、構文は次のとおりです。
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! たとえば、次の [`format!`] 式はすべて名前付き引数を使用します。
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! 名前のある引数の後に位置パラメータ (名前のないもの) を置くことは無効です。位置パラメータと同様に、フォーマット文字列で使用されない名前付きパラメータを指定することは無効です。
//!
//! # パラメータのフォーマット
//!
//! フォーマットされる各引数は、いくつかのフォーマットパラメータ ([the syntax](#syntax)) の `format_spec` に対応します。これらのパラメータは、フォーマットされるものの文字列表現に影響します) によって変換できます。
//!
//! ## Width
//!
//! ```
//! // これらすべてのプリント "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! これは、フォーマットが使用する必要がある "minimum width" のパラメーターです。
//! 値の文字列がこれだけ多くの文字を埋めない場合は、fill/alignment で指定されたパディングを使用して、必要なスペースを占有します (以下を参照)。
//!
//! 幅の値は、2 番目の引数が幅を指定する [`usize`] であることを示す接尾辞 `$` を追加することにより、パラメーターのリストに [`usize`] として指定することもできます。
//!
//! ドル構文で引数を参照しても "next argument" カウンターには影響しないため、通常は、位置で引数を参照するか、名前付き引数を使用することをお勧めします。
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! オプションの塗りつぶし文字と配置は、通常、[`width`](#width) パラメーターと組み合わせて提供されます。`width` の前、`:` の直後に定義する必要があります。
//! これは、フォーマットされている値が `width` より小さい場合、その周りに余分な文字が印刷されることを示しています。
//! 塗りつぶしには、さまざまな配置用に次のバリエーションがあります。
//!
//! * `[fill]<` - 引数は `width` 列で左揃えになります
//! * `[fill]^` - 引数は `width` 列で中央揃えになります
//! * `[fill]>` - 引数は `width` 列で右揃えになります
//!
//! 非数値のデフォルトの [fill/alignment](#fillalignment) はスペースであり、左揃えです。数値フォーマッタのデフォルトもスペース文字ですが、右揃えです。
//! 数値に `0` フラグ (以下を参照) が指定されている場合、暗黙の塗りつぶし文字は `0` です。
//!
//! 一部のタイプでは、位置合わせが実装されていない場合があることに注意してください。特に、`Debug` trait には一般的に実装されていません。
//! パディングが確実に適用されるようにする良い方法は、入力をフォーマットしてから、この結果の文字列をパディングして出力を取得することです。
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => 「こんにちは Some("hi")!」
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! これらはすべて、フォーマッタの動作を変更するフラグです。
//!
//! * `+` - これは数値タイプを対象としており、記号は常に印刷する必要があることを示しています。正の符号はデフォルトで印刷されることはなく、負の符号は `Signed` trait のデフォルトでのみ印刷されます。
//! このフラグは、正しい記号 (`+` または `-`) を常に印刷する必要があることを示します。
//! * `-` - 現在使用されていません
//! * `#` - このフラグは、"alternate" 形式の印刷を使用する必要があることを示します。代替形式は次のとおりです。
//!     * `#?` - [`Debug`] フォーマットをきれいに印刷する
//!     * `#x` - 引数の前に `0x` を付けます
//!     * `#X` - 引数の前に `0x` を付けます
//!     * `#b` - 引数の前に `0b` を付けます
//!     * `#o` - 引数の前に `0o` を付けます
//! * `0` - これは、整数形式の場合、`width` へのパディングを `0` 文字で行う必要があることと、符号を認識する必要があることを示すために使用されます。
//! `{:08}` のような形式では、整数 `1` に対して `00000001` が生成されますが、同じ形式では、整数 `-1` に対して `-0000001` が生成されます。
//! ネガティブバージョンのゼロはポジティブバージョンより 1 つ少ないことに注意してください。
//!         パディングゼロは常に記号 (存在する場合) の後、数字の前に配置されることに注意してください。`#` フラグと一緒に使用すると、同様のルールが適用されます。接頭辞の後、数字の前にパディングゼロが挿入されます。
//!         プレフィックスは全幅に含まれます。
//!
//! ## Precision
//!
//! 非数値タイプの場合、これは "maximum width" と見なすことができます。
//! 結果の文字列がこの幅よりも長い場合、その文字列はこの数の文字に切り捨てられ、これらのパラメータが設定されている場合、その切り捨てられた値は適切な `fill`、`alignment`、および `width` で出力されます。
//!
//! 整数型の場合、これは無視されます。
//!
//! 浮動小数点型の場合、これは小数点以下の桁数を印刷する必要があることを示します。
//!
//! 目的の `precision` を指定するには、次の 3 つの方法があります。
//!
//! 1. 整数 `.N`:
//!
//!    整数 `N` 自体が精度です。
//!
//! 2. 整数または名前の後にドル記号 `.N$` が続く:
//!
//!    精度としてフォーマット *引数*`N` (`usize` である必要があります) を使用します。
//!
//! 3. アスタリスク `.*`:
//!
//!    `.*` これは、この `{...}` が 1 つではなく *2 つの* 形式の入力に関連付けられていることを意味します。最初の入力は `usize` の精度を保持し、2 番目の入力は印刷する値を保持します。
//!    この場合、フォーマット文字列 `{<arg>:<spec>.*}` を使用すると、`<arg>` 部分は印刷する* 値*を参照し、`precision` は `<arg>` の前の入力に含まれている必要があることに注意してください。
//!
//! たとえば、次の呼び出しはすべて同じもの `Hello x is 0.01000` を出力します。
//!
//! ```
//! // こんにちは {arg 0 ("x")} は {arg 1 (0.01) with precision specified inline (5)} です
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // こんにちは {arg 1 ("x")} は {arg 2 (0.01) with precision specified in arg 0 (5)} です
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // こんにちは {arg 0 ("x")} は {arg 2 (0.01) with precision specified in arg 1 (5)} です
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // こんにちは {next arg ("x")} は {second of next two args (0.01) with precision specified in first of next two args (5)} です
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // こんにちは {next arg ("x")} は {arg 2 (0.01) with precision specified in its predecessor (5)} です
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // こんにちは {next arg ("x")} は {arg "number" (0.01) with precision specified in arg "prec" (5)} です
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! これらの間:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! 3 つの大きく異なるものを印刷します。
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! 一部のプログラミング言語では、文字列フォーマット関数の動作は、オペレーティングシステムのロケール設定によって異なります。
//! Rust の標準ライブラリによって提供されるフォーマット関数にはロケールの概念がなく、ユーザー構成に関係なく、すべてのシステムで同じ結果が生成されます。
//!
//! たとえば、次のコードは、システムロケールでドット以外の小数点記号が使用されている場合でも、常に `1.5` を出力します。
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! リテラル文字 `{` と `}` は、同じ文字を前に付けることで文字列に含めることができます。たとえば、`{` 文字は `{{` でエスケープされ、`}` 文字は `}}` でエスケープされます。
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! 要約すると、ここにフォーマット文字列の完全な文法があります。
//! 使用されるフォーマット言語の構文は他の言語から引用されているため、あまり異質なものであってはなりません。引数は Python のような構文でフォーマットされます。つまり、引数は C のような `%` ではなく `{}` で囲まれます。
//! フォーマット構文の実際の文法は次のとおりです。
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! 上記の文法では、`text` に `'{'` または `'}'` 文字を含めることはできません。
//!
//! # traits のフォーマット
//!
//! 引数を特定のタイプでフォーマットするように要求する場合、実際には、引数が特定の trait に属することを要求しています。
//! これにより、複数の実際のタイプを `{:x}` ([`i8`] や [`isize`] など) でフォーマットできます。タイプの traits への現在のマッピングは次のとおりです。
//!
//! * *なし* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒小文字の 16 進整数の [`Debug`]
//! * `X?` ⇒大文字の 16 進整数を含む [`Debug`]
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! これが意味するのは、[`fmt::Binary`][`Binary`] trait を実装する任意のタイプの引数を `{:b}` でフォーマットできるということです。これらの traits の実装は、標準ライブラリによっていくつかのプリミティブ型にも提供されています。
//!
//! (`{}` または `{:6}` のように) フォーマットが指定されていない場合、使用されるフォーマット trait は [`Display`] trait です。
//!
//! 独自のタイプにフォーマット trait を実装する場合は、署名のメソッドを実装する必要があります。
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // 私たちのカスタムタイプ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! タイプは参照によって `self` として渡され、関数は `f.buf` ストリームに出力を出力する必要があります。要求されたフォーマットパラメータに正しく準拠するかどうかは、各フォーマット trait の実装次第です。
//! これらのパラメーターの値は、[`Formatter`] 構造体のフィールドにリストされます。これを支援するために、[`Formatter`] 構造体はいくつかのヘルパーメソッドも提供します。
//!
//! さらに、この関数の戻り値は [`fmt::Result`] であり、これは [`Result`]`< ()、`[`std: : fmt::Error`] `>` の型エイリアスです。
//! フォーマットの実装では、[`Formatter`] からのエラーを確実に伝播する必要があります (たとえば、[`write!`] を呼び出す場合)。
//! ただし、誤ってエラーを返すことはありません。
//! つまり、フォーマットの実装は、渡された [`Formatter`] がエラーを返した場合にのみ、エラーを返す必要があります。
//! これは、関数のシグネチャが示唆するものとは逆に、文字列のフォーマットは間違いのない操作であるためです。
//! この関数は、基になるストリームへの書き込みが失敗する可能性があるため、結果のみを返します。エラーが発生したという事実をスタックに戻す方法を提供する必要があります。
//!
//! 書式設定 traits を実装する例は次のようになります。
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` 値は、`Write` trait を実装します。これは、書き込みです。マクロが期待しています。
//!         // このフォーマットでは、文字列のフォーマットに提供されるさまざまなフラグが無視されることに注意してください。
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // 異なる traits は、タイプの異なる形式の出力を許可します。
//! // この形式の意味は、vector の大きさを出力することです。
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Formatter オブジェクトでヘルパーメソッド `pad_integral` を使用して、フォーマットフラグを尊重します。
//!         // 詳細については、メソッドのドキュメントを参照してください。関数 `pad` を使用して文字列を埋めることができます。
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! これらの 2 つのフォーマット traits には、明確な目的があります。
//!
//! - [`fmt::Display`][`Display`] 実装は、型が常に UTF-8 文字列として忠実に表現できることを主張します。すべてのタイプが [`Display`] trait を実装することは **期待されていません**。
//! - [`fmt::Debug`][`Debug`] 実装は、**すべて** のパブリックタイプに実装する必要があります。
//!   出力は通常、可能な限り忠実に内部状態を表します。
//!   [`Debug`] trait の目的は、Rust コードのデバッグを容易にすることです。ほとんどの場合、`#[derive(Debug)]` を使用するだけで十分であり、推奨されます。
//!
//! 両方の traits からの出力のいくつかの例:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # 関連するマクロ
//!
//! [`format!`] ファミリには、関連するマクロがいくつかあります。現在実装されているものは次のとおりです。
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! これと [`writeln!`] は、指定されたストリームにフォーマット文字列を出力するために使用される 2 つのマクロです。これは、フォーマット文字列の中間割り当てを防ぎ、代わりに出力を直接書き込むために使用されます。
//! 内部的には、この関数は実際には [`std::io::Write`] trait で定義された [`write_fmt`] 関数を呼び出しています。
//! 使用例は次のとおりです。
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! これと [`println!`] は、出力を stdout に出力します。[`write!`] マクロと同様に、これらのマクロの目的は、出力を印刷するときに中間割り当てを回避することです。使用例は次のとおりです。
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] および [`eprintln!`] マクロは、出力を stderr に出力することを除いて、それぞれ [`print!`] および [`println!`] と同じです。
//!
//! ### `format_args!`
//!
//! これは、フォーマット文字列を記述する不透明なオブジェクトを安全に渡すために使用される奇妙なマクロです。このオブジェクトは、作成するためにヒープ割り当てを必要とせず、スタック上の情報のみを参照します。
//! 内部的には、関連するすべてのマクロがこの観点から実装されています。
//! まず、使用例は次のとおりです。
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] マクロの結果は、タイプ [`fmt::Arguments`] の値です。
//! 次に、この構造体をこのモジュール内の [`write`] および [`format`] 関数に渡して、フォーマット文字列を処理できます。
//! このマクロの目的は、フォーマット文字列を処理するときに中間割り当てをさらに防ぐことです。
//!
//! たとえば、ロギングライブラリは標準のフォーマット構文を使用できますが、出力の送信先が決定されるまで、この構造を内部的に渡します。
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format` 関数は [`Arguments`] 構造体を取り、結果のフォーマットされた文字列を返します。
///
///
/// [`Arguments`] インスタンスは、[`format_args!`] マクロを使用して作成できます。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format!`] の使用が望ましい場合があることに注意してください。
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}