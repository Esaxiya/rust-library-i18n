use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// 2 つの昇順イテレータの和集合からすべてのキーと値のペアを追加し、途中で `length` 変数をインクリメントします。後者を使用すると、ドロップハンドラーがパニックになったときに、呼び出し元がリークを回避しやすくなります。
    ///
    /// 両方のイテレータが同じキーを生成する場合、このメソッドは左側のイテレータからペアを削除し、右側のイテレータからペアを追加します。
    ///
    /// `BTreeMap` のように、ツリーを厳密に昇順で終了させたい場合は、両方のイテレータが厳密に昇順でキーを生成する必要があります。各キーは、エントリ時にツリーにすでに存在するキーを含め、ツリー内のすべてのキーよりも大きくなります。
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // `left` と `right` を線形時間でソートされたシーケンスにマージする準備をします。
        let iter = MergeIter(MergeIterInner::new(left, right));

        // その間、線形時間でソートされたシーケンスからツリーを構築します。
        self.bulk_push(iter, length)
    }

    /// すべてのキーと値のペアをツリーの最後にプッシュし、途中で `length` 変数をインクリメントします。
    /// 後者を使用すると、イテレータがパニックになったときに呼び出し元がリークを回避しやすくなります。
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // すべてのキーと値のペアを繰り返し処理し、それらを適切なレベルのノードにプッシュします。
        for (key, value) in iter {
            // キーと値のペアを現在のリーフノードにプッシュしてみてください。
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // スペースが残っていないので、上に上がってそこに押し込みます。
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // スペースが残っているノードが見つかりました。ここを押してください。
                                open_node = parent;
                                break;
                            } else {
                                // もう一度上がってください。
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // 私たちはトップにいて、新しいルートノードを作成してそこにプッシュします。
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // キーと値のペアと新しい右側のサブツリーをプッシュします。
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // もう一度右端の葉に降りてください。
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // イテレータのパニックを進めても、マップが追加された要素を確実にドロップするように、反復ごとに長さをインクリメントします。
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ソートされた 2 つのシーケンスを 1 つにマージするためのイテレータ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// 2 つのキーが等しい場合、正しいソースからキーと値のペアを返します。
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}