use core::intrinsics;
use core::mem;
use core::ptr;

/// これは、関連する関数を呼び出すことにより、`v` 一意参照の背後にある値を置き換えます。
///
///
/// `change` クロージャで panic が発生した場合、プロセス全体が中止されます。
#[allow(dead_code)] // イラストとして保管し、future で使用する
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// これは、関連する関数を呼び出すことによって `v` 一意参照の背後にある値を置き換え、途中で取得した結果を返します。
///
///
/// `change` クロージャで panic が発生した場合、プロセス全体が中止されます。
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}