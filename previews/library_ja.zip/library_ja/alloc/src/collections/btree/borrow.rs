use core::marker::PhantomData;
use core::ptr::NonNull;

/// ある時点で再借用とそのすべての子孫 (つまり、すべてのポインターとその派生参照) が使用されなくなることがわかっている場合は、いくつかの一意の参照の再借用をモデル化します。その後、元の一意の参照を再度使用します。。
///
///
/// 借用チェッカーは通常、この借用のスタックを処理しますが、このスタックを実現する一部の制御フローは、コンパイラーが従うには複雑すぎます。
/// `DormantMutRef` を使用すると、スタックの性質を表現しながら、自分で借用を確認し、未定義の動作なしでこれを行うために必要な生のポインターコードをカプセル化できます。
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// 独自の借用をキャプチャし、すぐに再借用します。
    /// コンパイラーの場合、新しい参照の存続期間は元の参照の存続期間と同じですが、promise を使用すると、より短い期間使用できます。
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // 安全性: `_marker` を介して 'a 全体で借用を保持し、公開します
        // この参照のみなので、一意です。
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// 最初に取得した一意の借用に戻します。
    ///
    /// # Safety
    ///
    /// 再借用は終了している必要があります。つまり、`new` によって返される参照と、そこから派生するすべてのポインターおよび参照は、使用できなくなります。
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // 安全性: 私たち自身の安全条件は、この参照が再び一意であることを意味します。
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;