// これは、理想に従った実装の試みです。
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust には実際には依存型と多形再帰がないため、多くの安全性が失われます。
//

// このモジュールの主な目標は、ツリーを一般的な (奇妙な形の場合) コンテナーとして扱い、ほとんどの B ツリー不変条件を処理しないようにすることで複雑さを回避することです。
//
// そのため、このモジュールは、エントリがソートされているかどうか、どのノードがアンダーフルである可能性があるか、またはアンダーフルが何を意味するかを気にしません。ただし、いくつかの不変条件に依存しています。
//
// - 木は均一な depth/height を持っている必要があります。これは、特定のノードからリーフまでのすべてのパスがまったく同じ長さであることを意味します。
// - 長さ `n` のノードには、`n` キー、`n` 値、および `n + 1` エッジがあります。
//   これは、空のノードでも少なくとも 1 つの edge があることを意味します。
//   リーフノードの場合、リーフエッジは空であり、データ表現を必要としないため、"having an edge" はノード内の位置を識別できることを意味するだけです。
// 内部ノードでは、edge は位置を識別し、子ノードへのポインタを含みます。
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// リーフノードの基礎となる表現と内部ノードの表現の一部。
struct LeafNode<K, V> {
    /// `K` と `V` で共変になりたいです。
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// 親ノードの `edges` 配列へのこのノードのインデックス。
    /// `*node.parent.edges[node.parent_idx]` `node` と同じである必要があります。
    /// これは、`parent` が null 以外の場合にのみ初期化されることが保証されています。
    parent_idx: MaybeUninit<u16>,

    /// このノードが格納するキーと値の数。
    len: u16,

    /// ノードの実際のデータを格納する配列。
    /// 各配列の最初の `len` 要素のみが初期化され、有効になります。
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// 新しい `LeafNode` をインプレースで初期化します。
    unsafe fn init(this: *mut Self) {
        // 一般的なポリシーとして、フィールドを初期化できない場合は、初期化しないままにします。これは、Valgrind での追跡がわずかに速く、簡単になるためです。
        //
        unsafe {
            // parent_idx、keys、および vals はすべて MaybeUninit です
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// 新しいボックス化された `LeafNode` を作成します。
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// 内部ノードの基礎となる表現。`LeafNode` と同様に、これらは `BoxedNode` の背後に隠して、初期化されていないキーと値がドロップされないようにする必要があります。
/// `InternalNode` へのポインターは、ノードの基になる `LeafNode` 部分へのポインターに直接キャストできるため、ポインターが 2 つのポインターのどちらを指しているかを確認することなく、コードをリーフノードと内部ノードに一般的に作用させることができます。
///
/// このプロパティは、`repr(C)` を使用することで有効になります。
///
#[repr(C)]
// gdb_providers.py イントロスペクションにこのタイプ名を使用します。
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// このノードの子へのポインター。
    /// `len + 1` これらのうち、ツリーが借用タイプ `Dying` を介して保持されている間、これらのポインターの一部がぶら下がっている場合を除いて、初期化されて有効であると見なされます。
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// 新しいボックス化された `InternalNode` を作成します。
    ///
    /// # Safety
    /// 内部ノードの不変条件は、それらが少なくとも 1 つの初期化された有効な edge を持っていることです。
    /// この関数は、そのような edge を設定しません。
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // データを初期化するだけで済みます。エッジは MaybeUninit です。
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ノードへの管理された null 以外のポインター。これは、`LeafNode<K, V>` への所有ポインターまたは `InternalNode<K, V>` への所有ポインターのいずれかです。
///
/// ただし、`BoxedNode` には、2 つのタイプのノードのどちらが実際に含まれているかに関する情報が含まれていません。また、この情報が不足していることもあり、別個のタイプではなく、デストラクタもありません。
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// 所有ツリーのルートノード。
///
/// これにはデストラクタがないため、手動でクリーンアップする必要があることに注意してください。
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// 最初は空である独自のルートノードを持つ、新しい所有ツリーを返します。
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ゼロであってはなりません。
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// 所有するルートノードを可変的に借用します。
    /// `reborrow_mut` とは異なり、戻り値を使用してルートを破棄することはできず、ツリーへの他の参照が存在しないため、これは安全です。
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 所有されているルートノードをわずかに変更可能に借用します。
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// トラバーサルを許可し、破壊的な方法などを提供する参照に不可逆的に移行します。
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 前のルートノードを指す単一の edge を持つ新しい内部ノードを追加し、その新しいノードをルートノードにして、それを返します。
    /// これにより、高さが 1 増加し、`pop_internal_level` の反対になります。
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, 私たちが今内部にいることを忘れたことを除いて:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// 最初の子を新しいルートノードとして使用して、内部ルートノードを削除します。
    /// ルートノードに子が 1 つしかない場合にのみ呼び出されることを目的としているため、キー、値、およびその他の子のクリーンアップは行われません。
    ///
    /// これにより、高さが 1 減少し、`push_internal_level` の反対になります。
    ///
    /// `Root` オブジェクトへの排他的アクセスが必要ですが、ルートノードへのアクセスは必要ありません。
    /// ルートノードへの他のハンドルまたは参照を無効にすることはありません。
    ///
    /// 内部レベルがない場合、つまりルートノードがリーフの場合は Panics。
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // 安全性: 私たちは内部的であると主張しました。
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // 安全性: `self` を排他的に借用し、その借用タイプは排他的です。
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // 安全性: 最初の edge は常に初期化されます。
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `BorrowType` が `Mut` の場合でも、`NodeRef` は常に `K` と `V` で共変です。
// これは技術的には間違っていますが、`K` および `V` に対して完全に汎用的であるため、`NodeRef` の内部使用による安全性の低下につながることはありません。
//
// ただし、パブリック型が `NodeRef` をラップする場合は常に、正しい分散があることを確認してください。
//
/// ノードへの参照。
///
/// このタイプには、その動作を制御するいくつかのパラメーターがあります。
/// - `BorrowType`: 借用の種類を記述し、ライフタイムを運ぶダミータイプ。
///    - これが `Immut<'a>` の場合、`NodeRef` はほぼ `&'a Node` のように動作します。
///    - これが `ValMut<'a>` の場合、`NodeRef` は、キーとツリー構造に関して `&'a Node` とほぼ同じように機能しますが、ツリー全体の値への多くの変更可能な参照を共存させることもできます。
///    - これが `Mut<'a>` の場合、`NodeRef` は `&'a mut Node` とほぼ同じように機能しますが、挿入メソッドを使用すると、値への可変ポインターを共存させることができます。
///    - これが `Owned` の場合、`NodeRef` は `Box<Node>` とほぼ同じように動作しますが、デストラクタがないため、手動でクリーンアップする必要があります。
///    - これが `Dying` の場合、`NodeRef` は `Box<Node>` とほぼ同じように動作しますが、ツリーを少しずつ破棄するメソッドがあり、通常のメソッドは、呼び出すのが安全でないとマークされていませんが、誤って呼び出された場合に UB を呼び出すことができます。
///
///   どの `NodeRef` でもツリー内を移動できるため、`BorrowType` はノード自体だけでなく、ツリー全体に効果的に適用されます。
/// - `K` および `V`: これらはノードに格納されているキーと値のタイプです。
/// - `Type`: これは、`Leaf`、`Internal`、または `LeafOrInternal` にすることができます。
/// これが `Leaf` の場合、`NodeRef` はリーフノードを指し、これが `Internal` の場合、`NodeRef` は内部ノードを指し、これが `LeafOrInternal` の場合、`NodeRef` はいずれかのタイプのノードを指している可能性があります。
///   `Type` `NodeRef` の外部で使用される場合、`NodeType` という名前になります。
///
/// `BorrowType` と `NodeType` はどちらも、静的型安全性を活用するために、実装するメソッドを制限しています。このような制限を適用する方法には制限があります。
/// - タイプパラメータごとに、一般的に、または 1 つの特定のタイプに対してのみメソッドを定義できます。
/// たとえば、`into_kv` のようなメソッドを、すべての `BorrowType` に対して一般的に定義したり、ライフタイムを持つすべてのタイプに対して 1 回定義したりすることはできません。これは、`&'a` 参照を返す必要があるためです。
///   したがって、最も強力でないタイプ `Immut<'a>` に対してのみ定義します。
/// - たとえば `Mut<'a>` から `Immut<'a>` への暗黙の強制を取得することはできません。
///   したがって、`into_kv` のようなメソッドに到達するには、より強力な `NodeRef` で `reborrow` を明示的に呼び出す必要があります。
///
/// ある種の参照を返す `NodeRef` のすべてのメソッドは、次のいずれかです。
/// - `self` を値で取得し、`BorrowType` によって運ばれる寿命を返します。
///   このようなメソッドを呼び出すには、`reborrow_mut` を呼び出す必要がある場合があります。
/// - 参照によって `self` を取得すると、(implicitly) は、`BorrowType` によって保持される有効期間ではなく、その参照の有効期間を返します。
/// このようにして、借用チェッカーは、返された参照が使用されている限り、`NodeRef` が借用されたままであることを保証します。
///   挿入をサポートするメソッドは、生のポインター、つまり有効期間のない参照を返すことによって、このルールを曲げます。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// ノードとリーフのレベルが離れているレベルの数、`Type` で完全に記述できないノードの定数、およびノード自体が格納しないレベル。
    /// ルートノードの高さを保存し、そこから他のすべてのノードの高さを導出するだけで済みます。
    /// `Type` が `Leaf` の場合はゼロで、`Type` が `Internal` の場合はゼロ以外である必要があります。
    ///
    ///
    height: usize,
    /// リーフまたは内部ノードへのポインタ。
    /// `InternalNode` の定義により、ポインターがどちらの方法でも有効であることが保証されます。
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` としてパックされたノード参照をアンパックします。
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// 内部ノードのデータを公開します。
    ///
    /// このノードへの他の参照が無効にならないように、生の ptr を返します。
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // 安全性: 静的ノードタイプは `Internal` です。
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// 内部ノードのデータへの排他的アクセスを借用します。
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ノードの長さを検索します。これは、キーまたは値の数です。
    /// エッジの数は `len() + 1` です。
    /// 安全であるにもかかわらず、この関数を呼び出すと、安全でないコードが作成した可変参照が無効になるという副作用が発生する可能性があることに注意してください。
    ///
    pub fn len(&self) -> usize {
        // 重要なのは、ここでは `len` フィールドにのみアクセスすることです。
        // BorrowType が marker::ValMut の場合、無効にしてはならない値への未解決の変更可能な参照がある可能性があります。
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// ノードとリーフが離れているレベルの数を返します。
    /// 高さがゼロの場合、ノード自体がリーフであることを意味します。
    /// ルートが上にある木を描く場合、数字はノードがどの標高に表示されるかを示します。
    /// 葉が上にある木を想像すると、数字は木がノードの上にどれだけ高く伸びているかを示します。
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// 同じノードへの別の不変の参照を一時的に取り出します。
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// リーフまたは内部ノードのリーフ部分を公開します。
    ///
    /// このノードへの他の参照が無効にならないように、生の ptr を返します。
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // ノードは、少なくとも LeafNode 部分に対して有効である必要があります。
        // 一意であるか共有であるかがわからないため、これは NodeRef タイプの参照ではありません。
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// 現在のノードの親を検索します。
    /// 現在のノードに実際に親がある場合は `Ok(handle)` を返します。ここで、`handle` は、現在のノードを指す親の edge を指します。
    ///
    /// 現在のノードに親がない場合は `Err(self)` を返し、元の `NodeRef` を返します。
    ///
    /// メソッド名は、ルートノードが上にあるツリーを描画することを前提としています。
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` は両方とも、成功すると何もしないはずです。
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BorrowType が marker::ValMut の場合、無効にしてはならない値への未処理の可変参照が存在する可能性があるため、ノードへの生のポインターを使用する必要があります。
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` は空でない必要があることに注意してください。
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` は空でない必要があることに注意してください。
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// 不変ツリー内の任意のリーフまたは内部ノードのリーフ部分を公開します。
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // 安全性: `Immut` として借用されたこのツリーへの変更可能な参照はありません。
        unsafe { &*ptr }
    }

    /// ノードに格納されているキーにビューを借用します。
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` と同様に、ノードの親ノードへの参照を取得しますが、プロセス内の現在のノードの割り当てを解除します。
    /// 割り当てが解除されても現在のノードにアクセスできるため、これは安全ではありません。
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// このノードが `Leaf` であるという静的情報をコンパイラーに安全に主張しません。
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// このノードが `Internal` であるという静的情報をコンパイラーに安全に主張しません。
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// 同じノードへの別の可変参照を一時的に取り出します。この方法は非常に危険であるため、すぐには危険に見えない可能性があるため、二重に注意してください。
    ///
    /// 可変ポインターはツリーのどこでもローミングできるため、返されたポインターを簡単に使用して、元のポインターをぶら下げたり、範囲外にしたり、スタックされた借用ルールの下で無効にしたりできます。
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` にさらに別の型パラメーターを追加して、再借用されたポインターでのナビゲーションメソッドの使用を制限し、この安全性を防ぐことを検討してください。
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// リーフまたは内部ノードのリーフ部分への排他的アクセスを借用します。
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // 安全性: ノード全体に排他的にアクセスできます。
        unsafe { &mut *ptr }
    }

    /// リーフまたは内部ノードのリーフ部分への排他的アクセスを提供します。
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // 安全性: ノード全体に排他的にアクセスできます。
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// キーストレージ領域の要素への排他的アクセスを借用します。
    ///
    /// # Safety
    /// `index` 0. .CAPACITY の範囲内にあります
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // 安全性: 発信者は自分でそれ以上のメソッドを呼び出すことができなくなります
        // 借用の存続期間中は一意のアクセス権があるため、キースライス参照が削除されるまで。
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// ノードの値ストレージ領域の要素またはスライスへの排他的アクセスを借用します。
    ///
    /// # Safety
    /// `index` 0. .CAPACITY の範囲内にあります
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // 安全性: 発信者は自分でそれ以上のメソッドを呼び出すことができなくなります
        // 借用の存続期間中は一意のアクセス権があるため、値スライス参照が削除されるまで。
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge コンテンツのノードのストレージ領域の要素またはスライスへの排他的アクセスを借用します。
    ///
    /// # Safety
    /// `index` 0. .CAPACITY +1 の範囲内にあります
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // 安全性: 発信者は自分でそれ以上のメソッドを呼び出すことができなくなります
        // 借用の存続期間中は一意のアクセス権があるため、edge スライス参照が削除されるまで。
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - ノードには、`idx` で初期化された要素が複数あります。
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // 他の要素、特に以前の反復で呼び出し元に返された要素への未処理の参照によるエイリアシングを回避するために、関心のある 1 つの要素への参照のみを作成します。
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust は #74679 を発行するため、サイズ変更されていない配列ポインターを強制変換する必要があります。
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ノードの長さへの排他的アクセスを借用します。
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ノードへの他の参照を無効にすることなく、ノードのリンクをその親 edge に設定します。
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// 親 edge へのルートのリンクをクリアします。
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// キーと値のペアをノードの最後に追加します。
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` によって返されるすべてのアイテムは、ノードの有効な edge インデックスです。
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// キーと値のペアを追加し、そのペアの右側にある edge をノードの最後に追加します。
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ノードが `Internal` ノードであるか `Leaf` ノードであるかを確認します。
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ノード内の特定のキーと値のペアまたは edge への参照。
/// `Node` パラメーターは `NodeRef` である必要がありますが、`Type` は `KV` (キーと値のペアのハンドルを示す) または `Edge` (edge のハンドルを示す) のいずれかです。
///
/// `Leaf` ノードでも `Edge` ハンドルを持つことができることに注意してください。
/// 子ノードへのポインターを表す代わりに、これらは子ポインターがキーと値のペアの間を移動するスペースを表します。
/// たとえば、長さが 2 のノードでは、3 つの可能な edge 位置があり、1 つはノードの左側、1 つは 2 つのペアの間に、もう 1 つはノードの右側にあります。
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// `Node` が「クローン」可能になるのは、それが不変の参照であり、したがって `Copy` である場合のみであるため、`#[derive(Clone)]` の完全な一般性は必要ありません。
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// このハンドルが指す edge またはキーと値のペアを含むノードを取得します。
    pub fn into_node(self) -> Node {
        self.node
    }

    /// ノード内のこのハンドルの位置を返します。
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` のキーと値のペアへの新しいハンドルを作成します。
    /// 発信者は `idx < node.len()` を確認する必要があるため、安全ではありません。
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq のパブリック実装である可能性がありますが、このモジュールでのみ使用されます。
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// 同じ場所にある別の不変のハンドルを一時的に取り出します。
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // タイプがわからないため、Handle::new_kv または Handle::new_edge を使用できません
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ハンドルのノードが `Leaf` であるという静的情報をコンパイラーに安全に主張しません。
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// 同じ場所にある別の可変ハンドルを一時的に取り出します。
    /// この方法は非常に危険であるため、すぐには危険に見えない可能性があるため、二重に注意してください。
    ///
    ///
    /// 詳細については、`NodeRef::reborrow_mut` を参照してください。
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // タイプがわからないため、Handle::new_kv または Handle::new_edge を使用できません
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` の edge への新しいハンドルを作成します。
    /// 発信者は `idx <= node.len()` を確認する必要があるため、安全ではありません。
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// 容量がいっぱいになったノードに挿入する edge インデックスが与えられると、分割ポイントの適切な KV インデックスと、挿入を実行する場所を計算します。
///
/// 分割ポイントの目標は、そのキーと値が最終的に親ノードになることです。
/// 分割点の左側にあるキー、値、およびエッジが左の子になります。
/// 分割点の右側にあるキー、値、およびエッジが正しい子になります。
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust の問題 #74834 は、これらの対称ルールを説明しようとします。
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// この edge の左右のキーと値のペアの間に新しいキーと値のペアを挿入します。
    /// この方法は、新しいペアが収まるのに十分なスペースがノードにあることを前提としています。
    ///
    /// 返されたポインタは、挿入された値を指します。
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// この edge の左右のキーと値のペアの間に新しいキーと値のペアを挿入します。
    /// この方法では、十分なスペースがない場合にノードを分割します。
    ///
    /// 返されたポインタは、挿入された値を指します。
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// この edge がリンクする子ノードの親ポインターとインデックスを修正します。
    /// これは、エッジの順序が変更された場合に役立ちます。
    fn correct_parent_link(self) {
        // ノードへの他の参照を無効にせずにバックポインターを作成します。
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// この edge とこの edge の右側にあるキーと値のペアの間に、新しいキーと値のペアとその新しいペアの右側に配置される edge を挿入します。
    /// この方法は、新しいペアが収まるのに十分なスペースがノードにあることを前提としています。
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// この edge とこの edge の右側にあるキーと値のペアの間に、新しいキーと値のペアとその新しいペアの右側に配置される edge を挿入します。
    /// この方法では、十分なスペースがない場合にノードを分割します。
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// この edge の左右のキーと値のペアの間に新しいキーと値のペアを挿入します。
    /// このメソッドは、十分なスペースがない場合にノードを分割し、ルートに到達するまで、分割された部分を親ノードに再帰的に挿入しようとします。
    ///
    ///
    /// 返される結果が `Fit` の場合、そのハンドルのノードは、この edge のノードまたは祖先である可能性があります。
    /// 返された結果が `Split` の場合、`left` フィールドがルートノードになります。
    /// 返されたポインタは、挿入された値を指します。
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// この edge が指すノードを検索します。
    ///
    /// メソッド名は、ルートノードが上にあるツリーを描画することを前提としています。
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` は両方とも、成功すると何もしないはずです。
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // BorrowType が marker::ValMut の場合、無効にしてはならない値への未処理の可変参照が存在する可能性があるため、ノードへの生のポインターを使用する必要があります。
        // その値がコピーされるため、高さフィールドにアクセスする心配はありません。
        // ノードポインタが逆参照されると、参照を使用してエッジ配列にアクセスし (Rust 問題 #73987)、配列への、または配列内の他の参照があれば無効にすることに注意してください。
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // 2 番目のメソッドを呼び出すと、最初のメソッドによって返された参照が無効になるため、個別の Key メソッドと Value メソッドを呼び出すことはできません。
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// KV ハンドルが参照するキーと値を置き換えます。
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// リーフデータを処理することにより、特定の `NodeType` の `split` の実装を支援します。
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// 基になるノードを 3 つの部分に分割します。
    ///
    /// - ノードは、このハンドルの左側にあるキーと値のペアのみを含むように切り捨てられます。
    /// - このハンドルが指すキーと値が抽出されます。
    /// - このハンドルの右側にあるすべてのキーと値のペアは、新しく割り当てられたノードに配置されます。
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// このハンドルが指すキーと値のペアを削除し、キーと値のペアが折りたたまれた edge とともに返します。
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// 基になるノードを 3 つの部分に分割します。
    ///
    /// - ノードは、このハンドルの左側にあるエッジとキーと値のペアのみを含むように切り捨てられます。
    /// - このハンドルが指すキーと値が抽出されます。
    /// - このハンドルの右側にあるすべてのエッジとキーと値のペアは、新しく割り当てられたノードに配置されます。
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// 内部のキーと値のペアの周りでバランシング操作を評価および実行するためのセッションを表します。
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// 子としてノードを含むバランシングコンテキストを選択します。つまり、親ノードのすぐ左または右の KV 間で選択します。
    /// 親がない場合は `Err` を返します。
    /// 親が空の場合は Panics。
    ///
    /// 左側が優先されます。特定のノードが何らかの理由でいっぱいになっていない場合に最適です。つまり、ここでは、要素が存在する場合は、左側の兄弟および右側の兄弟よりも要素が少ないことを意味します。
    /// その場合、ノードを右にシフトして N 個を超える要素を前に移動するのではなく、ノードの N 個の要素を移動するだけでよいため、左の兄弟とのマージが高速になります。
    /// 兄弟の要素の少なくとも N を左にシフトするのではなく、ノードの N の要素を右にシフトするだけでよいため、通常、左の兄弟から盗む方が高速です。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// マージが可能かどうか、つまり、中央の KV を隣接する両方の子ノードと組み合わせるのに十分なスペースがノードにあるかどうかを返します。
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// マージを実行し、クロージャに何を返すかを決定させます。
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // 安全性: マージされるノードの高さは、高さより 1 つ低くなります
                // この edge のノードの、したがってゼロより上であるため、それらは内部にあります。
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// 親のキーと値のペアと隣接する両方の子ノードを左側の子ノードにマージし、縮小された親ノードを返します。
    ///
    ///
    /// `.can_merge()` でない限り、Panics。
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// 親のキーと値のペアと隣接する両方の子ノードを左側の子ノードにマージし、その子ノードを返します。
    ///
    ///
    /// `.can_merge()` でない限り、Panics。
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// 親のキーと値のペアと隣接する両方の子ノードを左側の子ノードにマージし、追跡された子 edge が終了した子ノードの edge ハンドルを返します。
    ///
    ///
    /// `.can_merge()` でない限り、Panics。
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// 左の子からキーと値のペアを削除し、親のキーと値のストレージに配置し、古い親のキーと値のペアを右の子にプッシュします。
    ///
    /// `track_right_edge_idx` で指定された元の edge が終了した場所に対応する、右の子の edge へのハンドルを返します。
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// 右側の子からキーと値のペアを削除し、親のキーと値のストレージに配置し、古い親のキーと値のペアを左側の子にプッシュします。
    ///
    /// 移動しなかった `track_left_edge_idx` で指定された左側の子の edge へのハンドルを返します。
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// これは `steal_left` と同様に盗みますが、一度に複数の要素を盗みます。
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 安全に盗むことができることを確認してください。
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // リーフデータを移動します。
            {
                // 右の子供に盗まれた要素のためのスペースを作ります。
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // 要素を左の子から右の子に移動します。
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // 左端の盗まれたペアを親に移動します。
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 親のキーと値のペアを右の子に移動します。
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // 盗まれたエッジのためのスペースを作ります。
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // エッジを盗みます。
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` の対称クローン。
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // 安全に盗むことができることを確認してください。
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // リーフデータを移動します。
            {
                // 右端の盗まれたペアを親に移動します。
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // 親のキーと値のペアを左の子に移動します。
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // 要素を右の子から左の子に移動します。
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // 盗まれた要素があった場所の隙間を埋めます。
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // エッジを盗みます。
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // 盗まれたエッジがあった場所のギャップを埋めます。
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// このノードが `Leaf` ノードであることを表明する静的情報を削除します。
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// このノードが `Internal` ノードであることを表明する静的情報を削除します。
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// 基になるノードが `Internal` ノードであるか `Leaf` ノードであるかを確認します。
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` の後のサフィックスをあるノードから別のノードに移動します。`right` は空である必要があります。
    /// `right` の最初の edge は変更されません。
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ノードがその容量を超えて拡張する必要がある場合の挿入の結果。
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv` の左側に属する要素とエッジを持つ既存のツリーの変更されたノード。
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // 一部のキーと値が分割され、別の場所に挿入されます。
    pub kv: (K, V),
    // `kv` の右側に属する要素とエッジを持つ、所有された、接続されていない新しいノード。
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // この借用タイプのノード参照が、ツリー内の他のノードへのトラバースを許可するかどうか。
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // トラバーサルは必要ありません。`borrow_mut` の結果を使用して行われます。
        // トラバーサルを無効にし、ルートへの新しい参照のみを作成することにより、`Owned` タイプのすべての参照がルートノードへのものであることがわかります。
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// 初期化された要素のスライスに値を挿入し、その後に 1 つの初期化されていない要素を挿入します。
///
/// # Safety
/// スライスには `idx` 以上の要素があります。
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// 初期化されたすべての要素のスライスから値を削除して返し、後続の初期化されていない要素を 1 つ残します。
///
///
/// # Safety
/// スライスには `idx` 以上の要素があります。
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// スライス `distance` 位置の要素を左にシフトします。
///
/// # Safety
/// スライスには少なくとも `distance` 要素があります。
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// スライス `distance` 位置の要素を右にシフトします。
///
/// # Safety
/// スライスには少なくとも `distance` 要素があります。
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// すべての値を初期化された要素のスライスから初期化されていない要素のスライスに移動し、`src` をすべて未初期化のままにします。
///
/// `dst.copy_from_slice(src)` と同様に機能しますが、`T` が `Copy` である必要はありません。
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;