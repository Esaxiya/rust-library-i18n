//! Unicode 文字列スライス。
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` タイプは、2 つの主要な文字列タイプの 1 つであり、もう 1 つは `String` です。
//! `String` の対応物とは異なり、その内容は借用されます。
//!
//! # 基本的な使用法
//!
//! `&str` タイプの基本的な文字列宣言:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ここでは、文字列スライスとも呼ばれる文字列リテラルを宣言しました。
//! 文字列リテラルには静的な有効期間があります。つまり、文字列 `hello_world` は、プログラム全体の期間中有効であることが保証されています。
//!
//! `hello_world` の存続期間も明示的に指定できます。
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// このモジュールでの使用法の多くは、テスト構成でのみ使用されます。
// 修正するよりも、unused_imports 警告をオフにする方がクリーンです。
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>` の `str` は、ここでは意味がありません。
/// trait のこのタイプパラメータは、別の impl を有効にするためにのみ存在します。
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ハードコードされたサイズのループははるかに高速に実行され、セパレータの長さが短い場合に特化します
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // ゼロ以外の任意のサイズのフォールバック
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// 両方の Vec で機能する最適化された結合の実装 <T> (T: コピー) および String の内部 vec 現在 (2018-05-13) には、型推論と特殊化に関するバグがあります (問題 #36262 を参照)。このため、SliceConcat<T>T に特化していません: コピーと SliceConcat<str> この関数の唯一のユーザーです。
// それが修正される間、それはそのまま残されます。
//
// String-join の境界は S: Borrow です。<str>Vec の場合 - Borrow <[T]> [T] と str の両方に参加して、いくつかの T に対して AsRef <[T]> を実装します。
// => s.borrow().as_ref() そして私たちは常にスライスを持っています
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // 最初のスライスは、その前にセパレータがない唯一のスライスです
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` の計算がオーバーフローした場合、結合された Vec の正確な全長を計算します。とにかくメモリが不足し、残りの関数では安全のために Vec 全体が事前に割り当てられている必要があります。
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // 初期化されていないバッファを準備します
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // セパレーターのコピーと境界なしのスライスチェックにより、小さなセパレーターのオフセットがハードコードされたループが生成されます。大幅な改善が可能です (〜x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // 奇妙な借用の実装では、長さの計算と実際のコピーに対して異なるスライスが返される場合があります。
        //
        // 初期化されていないバイトを呼び出し元に公開しないようにしてください。
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// 文字列スライスのメソッド。
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>` をコピーまたは割り当てなしで `Box<[u8]>` に変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// パターンのすべての一致を別の文字列に置き換えます。
    ///
    /// `replace` 新しい [`String`] を作成し、この文字列スライスからデータをコピーします。
    /// そうしている間、それはパターンの一致を見つけようとします。
    /// 見つかった場合は、それらを置換文字列スライスに置き換えます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// パターンが一致しない場合:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// パターンの最初の N 個の一致を別の文字列に置き換えます。
    ///
    /// `replacen` 新しい [`String`] を作成し、この文字列スライスからデータをコピーします。
    /// そうしている間、それはパターンの一致を見つけようとします。
    /// 見つかった場合は、最大 `count` 回、置換文字列スライスに置き換えます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// パターンが一致しない場合:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // 再割り当ての時間を短縮したい
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// この文字列スライスに相当する小文字を新しい [`String`] として返します。
    ///
    /// 'Lowercase' Unicode 派生コアプロパティ `Lowercase` の条件に従って定義されます。
    ///
    /// 一部の文字は大文字と小文字を変更すると複数の文字に展開される可能性があるため、この関数はパラメーターをインプレースで変更する代わりに [`String`] を返します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// シグマを使用したトリッキーな例:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // しかし、単語の終わりでは、それは σ ではなく σ です:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// 大文字と小文字を区別しない言語は変更されません。
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ は、σ にマップされる単語の終わりを除いて、σ にマップされます。
                // これは唯一の条件付き (contextual) ですが、`SpecialCasing.txt` では言語に依存しないマッピングであるため、一般的な "condition" メカニズムではなくハードコーディングします。
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` の定義について。
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// この文字列スライスに相当する大文字を新しい [`String`] として返します。
    ///
    /// 'Uppercase' Unicode 派生コアプロパティ `Uppercase` の条件に従って定義されます。
    ///
    /// 一部の文字は大文字と小文字を変更すると複数の文字に展開される可能性があるため、この関数はパラメーターをインプレースで変更する代わりに [`String`] を返します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// 大文字と小文字を区別しないスクリプトは変更されません。
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// 1 つの文字が複数になる可能性があります。
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`] をコピーまたは割り当てなしで [`String`] に変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// 文字列 `n` を繰り返すことにより、新しい [`String`] を作成します。
    ///
    /// # Panics
    ///
    /// 容量がオーバーフローした場合、この関数は panic になります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// オーバーフロー時の panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// この文字列のコピーを返します。各文字は、同等の ASCII 大文字にマップされます。
    ///
    ///
    /// ASCII 文字 'a' から 'z' は 'A' から 'Z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を大文字にするには、[`make_ascii_uppercase`] を使用します。
    ///
    /// 非 ASCII 文字に加えて ASCII 文字を大文字にするには、[`to_uppercase`] を使用します。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 不変条件を保持します。
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// この文字列のコピーを返します。各文字は、同等の ASCII 小文字にマップされます。
    ///
    ///
    /// ASCII 文字 'A' から 'Z' は 'a' から 'z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を小文字にするには、[`make_ascii_lowercase`] を使用します。
    ///
    /// 非 ASCII 文字に加えて ASCII 文字を小文字にするには、[`to_lowercase`] を使用します。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 不変条件を保持します。
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// 文字列に有効な UTF-8 が含まれていることを確認せずに、ボックス化されたバイトスライスをボックス化された文字列スライスに変換します。
///
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}