/// 引数を含む [`Vec`] を作成します。
///
/// `vec!` `Vec` を配列式と同じ構文で定義できます。
/// このマクロには 2 つの形式があります。
///
/// - 指定された要素のリストを含む [`Vec`] を作成します。
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - 指定された要素とサイズから [`Vec`] を作成します。
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// 配列式とは異なり、この構文は [`Clone`] を実装するすべての要素をサポートし、要素の数は定数である必要はないことに注意してください。
///
/// これは `clone` を使用して式を複製するため、非標準の `Clone` 実装を持つタイプでこれを使用する場合は注意が必要です。
/// たとえば、`vec![Rc::new(1);5] ` は、独立してボックス化された整数を指す 5 つの参照ではなく、同じボックス化された整数値への 5 つの参照の vector を作成します。
///
///
/// また、`vec![expr; 0]` が許可され、空の vector を生成することに注意してください。
/// ただし、これでも `expr` は評価され、結果の値はすぐに削除されるため、副作用に注意してください。
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) では、このマクロ定義に必要な固有の `[T]::into_vec` メソッドは使用できません。
// 代わりに、cfg(test) NB でのみ使用可能な `slice::into_vec` 機能を使用してください。詳細については、slice.rs の slice::hack モジュールを参照してください。
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// ランタイム式の補間を使用して `String` を作成します。
///
/// `format!` が受け取る最初の引数はフォーマット文字列です。これは文字列リテラルである必要があります。書式設定文字列の威力は、含まれている `{}` にあります。
///
/// `format!` に渡される追加のパラメーターは、名前付きパラメーターまたは位置パラメーターが使用されていない限り、指定された順序でフォーマット文字列内の `{}` を置き換えます。詳細については、[`std::fmt`] を参照してください。
///
///
/// `format!` の一般的な使用法は、文字列の連結と補間です。
/// 文字列の目的の宛先に応じて、[`print!`] マクロと [`write!`] マクロでも同じ規則が使用されます。
///
/// 単一の値を文字列に変換するには、[`to_string`] メソッドを使用します。これは、[`Display`] フォーマットの trait を使用します。
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` trait のフォーマット実装がエラーを返した場合は panics。
/// `fmt::Write for String` 自体がエラーを返すことはないため、これは実装が正しくないことを示しています。
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// パターン位置の診断を改善するために、AST ノードを式に強制します。
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}