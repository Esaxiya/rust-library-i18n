//! UTF-8 でエンコードされた拡張可能な文字列。
//!
//! このモジュールには、[`String`] タイプ、文字列に変換するための [`ToString`] trait、および [`String`] の操作によって発生する可能性のあるいくつかのエラータイプが含まれています。
//!
//!
//! # Examples
//!
//! 文字列リテラルから新しい [`String`] を作成する方法は複数あります。
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! と連結することにより、既存の [`String`] から新しい [`String`] を作成できます。
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! 有効な UTF-8 バイトの vector がある場合は、それから [`String`] を作成できます。逆もできます。
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // これらのバイトが有効であることがわかっているので、`unwrap()` を使用します。
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 でエンコードされた拡張可能な文字列。
///
/// `String` タイプは、文字列の内容に対する所有権を持つ最も一般的な文字列タイプです。借用した相手であるプリミティブ [`str`] と密接な関係があります。
///
/// # Examples
///
/// [`String::from`] を使用して [a literal string][`str`] から `String` を作成できます。
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`push`] メソッドを使用して [`char`] を `String` に追加し、[`push_str`] メソッドを使用して [`&str`] を追加できます。
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// UTF-8 バイトの vector がある場合は、[`from_utf8`] メソッドを使用してそこから `String` を作成できます。
///
/// ```
/// // vector 内のいくつかのバイト
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // これらのバイトが有効であることがわかっているので、`unwrap()` を使用します。
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `文字列` は常に有効な UTF-8 です。これにはいくつかの影響があります。最初の影響は、UTF-8 以外の文字列が必要な場合は、[`OsString`] を検討することです。これは似ていますが、UTF-8 制約がありません。2 番目の意味は、`String` にインデックスを付けることができないということです。
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// インデックス作成は一定時間の操作を目的としていますが、UTF-8 エンコーディングではこれを行うことができません。さらに、インデックスがどのようなものを返す必要があるか (バイト、コードポイント、または書記素クラスター) は明確ではありません。
/// [`bytes`] メソッドと [`chars`] メソッドは、それぞれ最初の 2 つの反復子を返します。
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s は [`Deref`] `を実装します <Target=str>`、したがって [`str`] のすべてのメソッドを継承します。さらに、これは、アンペアと (`&`) を使用して、`String` を [`&str`] を受け取る関数に渡すことができることを意味します。
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// これにより、`String` から [`&str`] が作成され、渡されます。この変換は非常に安価であるため、特定の理由で `String` が必要な場合を除き、通常、関数は引数として [`＆str`] を受け入れます。
///
/// 場合によっては、Rust には、[`Deref`] 強制と呼ばれる、この変換を行うための十分な情報がありません。次の例では、文字列スライス [`&'a str`][`&str`] は trait `TraitExample` を実装し、関数 `example_func` は trait を実装するすべてのものを取ります。
/// この場合、Rust は 2 つの暗黙的な変換を行う必要がありますが、Rust にはそれを行う手段がありません。
/// そのため、次の例はコンパイルされません。
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// 代わりに機能する 2 つのオプションがあります。1 つ目は、メソッド [`as_str()`] を使用して行 `example_func(&example_string);` を `example_func(example_string.as_str());` に変更し、文字列を含む文字列スライスを明示的に抽出することです。
/// 2 番目の方法は、`example_func(&example_string);` を `example_func(&*example_string);` に変更します。
/// この場合、`String` を [`str`][`&str`] に逆参照してから、[`str`][`&str`] を参照して [`&str`] に戻します。
/// 2 番目の方法はより慣用的ですが、どちらも暗黙的な変換に依存するのではなく、明示的に変換を行うように機能します。
///
/// # Representation
///
/// `String` は、いくつかのバイトへのポインター、長さ、および容量の 3 つのコンポーネントで構成されています。ポインタは、`String` がデータを格納するために使用する内部バッファを指します。長さは現在バッファに格納されているバイト数であり、容量はバイト単位のバッファのサイズです。
///
/// そのため、長さは常に容量以下になります。
///
/// このバッファは常にヒープに格納されます。
///
/// これらは、[`as_ptr`]、[`len`]、および [`capacity`] メソッドで確認できます。
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXMEvec_into_raw_parts が安定したときにこれを更新します。
/// // 文字列のデータが自動的に削除されないようにする
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ストーリーは 19 バイトです
/// assert_eq!(19, len);
///
/// // ptr、len、および容量から文字列を再構築できます。
/// // コンポーネントが有効であることを確認する責任があるため、これはすべて安全ではありません。
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// `String` に十分な容量がある場合、それに要素を追加しても再割り当てされません。たとえば、次のプログラムについて考えてみます。
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// これにより、次のように出力されます。
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// 最初はメモリがまったく割り当てられていませんが、文字列に追加すると、容量が適切に増加します。代わりに [`with_capacity`] メソッドを使用して、最初に正しい容量を割り当てる場合:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// 最終的には異なる出力になります。
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ここでは、ループ内にさらにメモリを割り当てる必要はありません。
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// `String` を UTF-8 バイト vector から変換するときに発生する可能性のあるエラー値。
///
/// このタイプは、[`String`] での [`from_utf8`] メソッドのエラータイプです。
/// 再割り当てを慎重に回避するように設計されています。[`into_bytes`] メソッドは、変換の試行で使用されたバイト vector を返します。
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] によって提供される [`Utf8Error`] タイプは、[`u8`] のスライスを [`&str`] に変換するときに発生する可能性のあるエラーを表します。
/// この意味で、これは `FromUtf8Error` に類似しており、`FromUtf8Error` から [`utf8_error`] メソッドを介して取得できます。
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// // vector 内のいくつかの無効なバイト
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 バイトスライスから `String` を変換するときに発生する可能性のあるエラー値。
///
/// このタイプは、[`String`] での [`from_utf16`] メソッドのエラータイプです。
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// 新しい空の `String` を作成します。
    ///
    /// `String` が空の場合、これは初期バッファーを割り当てません。これは、この最初の操作が非常に安価であることを意味しますが、後でデータを追加するときに過剰な割り当てが発生する可能性があります。
    ///
    /// `String` が保持するデータの量がわかっている場合は、過度の再割り当てを防ぐために [`with_capacity`] メソッドを検討してください。
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// 特定の容量で新しい空の `String` を作成します。
    ///
    /// `String` には、データを保持するための内部バッファーがあります。
    /// 容量はそのバッファーの長さであり、[`capacity`] メソッドで照会できます。
    /// このメソッドは空の `String` を作成しますが、`capacity` バイトを保持できる初期バッファーを持つものを作成します。
    /// これは、大量のデータを `String` に追加して、実行する必要のある再割り当ての数を減らす場合に役立ちます。
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// 指定された容量が `0` の場合、割り当ては発生せず、この方法は [`new`] の方法と同じです。
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // 文字列には文字が含まれていませんが、それ以上の容量があります
    /// assert_eq!(s.len(), 0);
    ///
    /// // これらはすべて再割り当てせずに行われます...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... しかし、これにより文字列が再割り当てされる可能性があります
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) では、このメソッド定義に必要な固有の `[T]::to_vec` メソッドは使用できません。
    // テストの目的でこのメソッドを必要としないので、スタブするだけです。詳細については、slice.rs の slice::hack モジュールを参照してください。
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// バイトの vector を `String` に変換します。
    ///
    /// 文字列 ([`String`]) はバイト ([`u8`]) で構成され、バイト ([`Vec<u8>`]) の vector はバイトで構成されているため、この関数は 2 つの間で変換します。
    /// ただし、すべてのバイトスライスが有効な「文字列」であるとは限りません。`String` では、有効な UTF-8 である必要があります。
    /// `from_utf8()` バイトが有効な UTF-8 であることを確認してから、変換を実行します。
    ///
    /// バイトスライスが有効な UTF-8 であることが確実であり、有効性チェックのオーバーヘッドを発生させたくない場合は、この関数の安全でないバージョンである [`from_utf8_unchecked`] があります。これは同じ動作をしますが、チェックをスキップします。
    ///
    ///
    /// このメソッドは、効率を上げるために、vector をコピーしないように注意します。
    ///
    /// `String` の代わりに [`&str`] が必要な場合は、[`str::from_utf8`] を検討してください。
    ///
    /// この方法の逆は [`into_bytes`] です。
    ///
    /// # Errors
    ///
    /// スライスが UTF-8 でない場合は、提供されたバイトが UTF-8 でない理由に関する説明とともに [`Err`] を返します。移動した vector も含まれています。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかのバイト
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // これらのバイトが有効であることがわかっているので、`unwrap()` を使用します。
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 不正なバイト:
    ///
    /// ```
    /// // vector 内のいくつかの無効なバイト
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// このエラーで何ができるかについての詳細は、[`FromUtf8Error`] のドキュメントを参照してください。
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// バイトのスライスを、無効な文字を含む文字列に変換します。
    ///
    /// 文字列はバイト ([`u8`]) で構成され、バイト ([`&[u8]`][byteslice]) のスライスはバイトで構成されるため、この関数は 2 つの間で変換します。ただし、すべてのバイトスライスが有効な文字列であるとは限りません。文字列は有効な UTF-8 である必要があります。
    /// この変換中に、`from_utf8_lossy()` は無効な UTF-8 シーケンスを [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] に置き換えます。これは次のようになります。
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// バイトスライスが有効な UTF-8 であることが確実で、変換のオーバーヘッドを発生させたくない場合は、この関数の安全でないバージョンである [`from_utf8_unchecked`] があります。これは同じ動作をしますが、チェックをスキップします。
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// この関数は [`Cow<'a, str>`] を返します。バイトスライスが無効な UTF-8 の場合、置換文字を挿入する必要があります。これにより、文字列のサイズが変更されるため、`String` が必要になります。
    /// ただし、すでに有効な UTF-8 である場合は、新しい割り当ては必要ありません。
    /// このリターンタイプにより、両方のケースを処理できます。
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかのバイト
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 不正なバイト:
    ///
    /// ```
    /// // いくつかの無効なバイト
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// UTF-16 でエンコードされた vector `v` を `String` にデコードし、`v` に無効なデータが含まれている場合は [`Err`] を返します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // これは collect: : を介して行われません。<Result<_, _>> () パフォーマンス上の理由から。
        // FIXME: #48994 を閉じると、機能を再び簡略化できます。
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// UTF-16 でエンコードされたスライス `v` を `String` にデコードし、無効なデータを [the replacement character (`U+FFFD`)][U+FFFD] に置き換えます。
    ///
    /// [`Cow<'a, str>`] を返す [`from_utf8_lossy`] とは異なり、UTF-16 から UTF-8 への変換にはメモリ割り当てが必要なため、`from_utf16_lossy` は `String` を返します。
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String` を未加工のコンポーネントに分解します。
    ///
    /// 基になるデータへの生のポインタ、文字列の長さ (バイト単位)、およびデータに割り当てられた容量 (バイト単位) を返します。
    /// これらは、[`from_raw_parts`] の引数と同じ順序の同じ引数です。
    ///
    /// この関数を呼び出した後、呼び出し元は `String` によって以前に管理されていたメモリを担当します。
    /// これを行う唯一の方法は、生のポインター、長さ、および容量を [`from_raw_parts`] 関数を使用して `String` に変換し直し、デストラクタがクリーンアップを実行できるようにすることです。
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// 長さ、容量、およびポインターから新しい `String` を作成します。
    ///
    /// # Safety
    ///
    /// チェックされていない不変条件の数が多いため、これは非常に安全ではありません。
    ///
    /// * `buf` のメモリは、標準ライブラリが使用するのと同じアロケータによって事前に割り当てられている必要があり、必要な配置は正確に 1 です。
    /// * `length` `capacity` 以下である必要があります。
    /// * `capacity` 正しい値である必要があります。
    /// * `buf` の最初の `length` バイトは、有効な UTF-8 である必要があります。
    ///
    /// これらに違反すると、アロケータの内部データ構造が破損するなどの問題が発生する可能性があります。
    ///
    /// `buf` の所有権は `String` に効果的に転送され、`String` は、ポインタが指すメモリの内容を自由に割り当て解除、再割り当て、または変更できます。
    /// この関数を呼び出した後、他に何もポインタを使用していないことを確認してください。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXMEvec_into_raw_parts が安定したときにこれを更新します。
    ///     // 文字列のデータが自動的に削除されないようにする
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// 文字列に有効な UTF-8 が含まれていることを確認せずに、バイトの vector を `String` に変換します。
    ///
    /// 詳細については、安全なバージョン [`from_utf8`] を参照してください。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// この関数は、渡されたバイトが有効な UTF-8 であるかどうかをチェックしないため、安全ではありません。
    /// この制約に違反すると、`String` の future ユーザーにメモリの安全性の問題が発生する可能性があります。これは、標準ライブラリの残りの部分が `String` が有効な UTF-8 であると想定しているためです。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかのバイト
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String` をバイト vector に変換します。
    ///
    /// これは `String` を消費するため、その内容をコピーする必要はありません。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// `String` 全体を含む文字列スライスを抽出します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String` を可変の文字列スライスに変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// 指定された文字列スライスをこの `String` の最後に追加します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// この `String` の容量をバイト単位で返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// この `String` の容量がその長さより少なくとも `additional` バイト大きいことを確認します。
    ///
    /// 頻繁な再割り当てを防ぐために、必要に応じて容量を `additional` バイト以上増やすことができます。
    ///
    ///
    /// この "at least" の動作が必要ない場合は、[`reserve_exact`] メソッドを参照してください。
    ///
    /// # Panics
    ///
    /// 新しい容量が [`usize`] をオーバーフローした場合は Panics。
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// これは実際には容量を増加させない場合があります。
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s の長さは 2、容量は 10 になりました。
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // すでに追加の 8 容量があるので、これを呼び出します...
    /// s.reserve(8);
    ///
    /// // ... 実際には増加しません。
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// この `String` の容量がその長さより `additional` バイト大きいことを確認します。
    ///
    /// アロケータよりも完全によく知っている場合を除いて、[`reserve`] メソッドの使用を検討してください。
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// 新しい容量が `usize` をオーバーフローした場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// これは実際には容量を増加させない場合があります。
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s の長さは 2、容量は 10 になりました。
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // すでに追加の 8 容量があるので、これを呼び出します...
    /// s.reserve_exact(8);
    ///
    /// // ... 実際には増加しません。
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// 指定された `String` に挿入される要素の少なくとも `additional` の容量を予約しようとします。
    /// コレクションは、頻繁な再割り当てを回避するために、より多くのスペースを予約する場合があります。
    /// `reserve` を呼び出した後、容量は `self.len() + additional` 以上になります。
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// # Errors
    ///
    /// 容量がオーバーフローした場合、またはアロケータが障害を報告した場合、エラーが返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // メモリを事前に予約し、できない場合は終了します
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 今、私たちはこれが私たちの複雑な仕事の途中で OOM できないことを知っています
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// 指定された `String` に挿入される要素を正確に `additional` 増やすための最小容量を予約しようとします。
    ///
    /// `reserve_exact` を呼び出した後、容量は `self.len() + additional` 以上になります。
    /// 容量がすでに十分な場合は何もしません。
    ///
    /// アロケータは、コレクションに要求よりも多くのスペースを与える可能性があることに注意してください。
    /// したがって、容量を正確に最小にすることはできません。
    /// future の挿入が予想される場合は、`reserve` を優先します。
    ///
    /// # Errors
    ///
    /// 容量がオーバーフローした場合、またはアロケータが障害を報告した場合、エラーが返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // メモリを事前に予約し、できない場合は終了します
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 今、私たちはこれが私たちの複雑な仕事の途中で OOM できないことを知っています
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// この `String` の容量を、その長さに合わせて縮小します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// この `String` の容量を下限で縮小します。
    ///
    /// 容量は、少なくとも長さと提供された値の両方と同じ大きさのままになります。
    ///
    ///
    /// 現在の容量が下限よりも小さい場合、これはノーオペレーションです。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// 指定された [`char`] をこの `String` の最後に追加します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// この `String` の内容のバイトスライスを返します。
    ///
    /// この方法の逆は [`from_utf8`] です。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// この `String` を指定された長さに短縮します。
    ///
    /// `new_len` が文字列の現在の長さより大きい場合、これは効果がありません。
    ///
    ///
    /// この方法は、文字列の割り当てられた容量には影響しないことに注意してください
    ///
    /// # Panics
    ///
    /// `new_len` が [`char`] 境界上にない場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// 文字列バッファから最後の文字を削除して返します。
    ///
    /// この `String` が空の場合、[`None`] を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// この `String` からバイト位置で [`char`] を削除し、それを返します。
    ///
    /// これは *O*(*n*) 操作です。これは、バッファー内のすべての要素をコピーする必要があるためです。
    ///
    /// # Panics
    ///
    /// `idx` が `String` の長さ以上の場合、または [`char`] 境界上にない場合は Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` 内のパターン `pat` のすべての一致を削除します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// 一致は繰り返し検出されて削除されるため、パターンが重複している場合は、最初のパターンのみが削除されます。
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // 安全性: 開始と終了は utf8 バイト境界になります
        // サーチャードキュメント
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// 述部によって指定された文字のみを保持します。
    ///
    /// つまり、`f(c)` が `false` を返すように、すべての文字 `c` を削除します。
    /// このメソッドはその場で動作し、元の順序で各文字に 1 回だけアクセスし、保持されている文字の順序を保持します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// 正確な順序は、インデックスなどの外部状態を追跡するのに役立つ場合があります。
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // idx を次の文字にポイントします
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// この `String` のバイト位置に文字を挿入します。
    ///
    /// これは、バッファ内のすべての要素をコピーする必要があるため、*O*(*n*) 操作です。
    ///
    /// # Panics
    ///
    /// `idx` が `String` の長さよりも大きい場合、または [`char`] 境界上にない場合は Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// この `String` のバイト位置に文字列スライスを挿入します。
    ///
    /// これは、バッファ内のすべての要素をコピーする必要があるため、*O*(*n*) 操作です。
    ///
    /// # Panics
    ///
    /// `idx` が `String` の長さよりも大きい場合、または [`char`] 境界上にない場合は Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// この `String` のコンテンツへの変更可能な参照を返します。
    ///
    /// # Safety
    ///
    /// この関数は、渡されたバイトが有効な UTF-8 であるかどうかをチェックしないため、安全ではありません。
    /// この制約に違反すると、`String` の future ユーザーにメモリの安全性の問題が発生する可能性があります。これは、標準ライブラリの残りの部分が `String` が有効な UTF-8 であると想定しているためです。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// [`char`] や graphemes ではなく、この `String` の長さをバイト単位で返します。
    /// 言い換えれば、それは人間が文字列の長さを考慮するものではないかもしれません。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// この `String` の長さがゼロの場合は `true` を返し、それ以外の場合は `false` を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 指定されたバイトインデックスで文字列を 2 つに分割します。
    ///
    /// 新しく割り当てられた `String` を返します。
    /// `self` バイト `[0, at)` が含まれ、返される `String` にはバイト `[at, len)` が含まれます。
    /// `at` UTF-8 コードポイントの境界上にある必要があります。
    ///
    /// `self` の容量は変更されないことに注意してください。
    ///
    /// # Panics
    ///
    /// `at` が `UTF-8` コードポイント境界上にない場合、または文字列の最後のコードポイントを超えている場合は、Panics。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// この `String` を切り捨てて、すべてのコンテンツを削除します。
    ///
    /// これは、`String` の長さがゼロになることを意味しますが、容量には影響しません。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String` で指定された範囲を削除し、削除された `chars` を生成するドレインイテレータを作成します。
    ///
    ///
    /// Note: イテレータが最後まで消費されなくても、要素範囲は削除されます。
    ///
    /// # Panics
    ///
    /// 開始点または終了点が [`char`] 境界上にない場合、または範囲外の場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 文字列から β までの範囲を削除します
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // 全範囲で文字列がクリアされます
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // メモリの安全性
        //
        // 文字列バージョンの Drain には、vector バージョンのメモリ安全性の問題はありません。
        // データは単なるバイトです。
        // 範囲の削除は Drop で行われるため、Drain イテレーターがリークした場合、削除は行われません。
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // 2 つの同時借用を行います。
        // &mut 文字列は、Drop で反復が終了するまでアクセスされません。
        let self_ptr = self as *mut _;
        // 安全性: `slice::range` および `is_char_boundary` は適切な境界チェックを実行します。
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// 文字列内の指定された範囲を削除し、指定された文字列に置き換えます。
    /// 指定された文字列は、範囲と同じ長さである必要はありません。
    ///
    /// # Panics
    ///
    /// 開始点または終了点が [`char`] 境界上にない場合、または範囲外の場合は Panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 文字列から β までの範囲を置き換えます
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // メモリの安全性
        //
        // Replace_range には、vector スプライスのメモリ安全性の問題はありません。
        // vector バージョンの。データは単なるバイトです。

        // 警告: この変数をインライン化すると、(#81138) は正しくありません。
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // 警告: この変数をインライン化すると、(#81138) は正しくありません。
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` を再度使用すると不健全になります (#81138) `range` によって報告された境界は同じままであると想定しますが、敵対的な実装は呼び出し間で変更される可能性があります
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// この `String` を [`Box`]`<`[`str`] `>` に変換します。
    ///
    /// これにより、余分な容量がすべて削除されます。
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// `String` への変換が試行された [`u8`] バイトのスライスを返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかの無効なバイト
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// `String` への変換が試行されたバイトを返します。
    ///
    /// このメソッドは、割り当てを回避するために慎重に構築されています。
    /// エラーが発生し、バイトが移動するため、バイトのコピーを作成する必要はありません。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかの無効なバイト
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// `Utf8Error` をフェッチして、変換の失敗に関する詳細を取得します。
    ///
    /// [`std::str`] によって提供される [`Utf8Error`] タイプは、[`u8`] のスライスを [`&str`] に変換するときに発生する可能性のあるエラーを表します。
    /// この意味で、`FromUtf8Error` のアナログです。
    /// 使用の詳細については、そのドキュメントを参照してください。
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // vector 内のいくつかの無効なバイト
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ここでは最初のバイトは無効です
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // `String` を反復処理しているため、反復子から最初の文字列を取得し、それに後続のすべての文字列を追加することで、少なくとも 1 つの割り当てを回避できます。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // CoW を反復処理しているため、(potentially) は、最初のアイテムを取得し、それに後続のすべてのアイテムを追加することで、少なくとも 1 つの割り当てを回避できます。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str` の impl に委任する便利な impl。
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// 空の `String` を作成します。
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// 2 つの文字列を連結するための `+` 演算子を実装します。
///
/// これにより、左側の `String` が消費され、そのバッファーが再利用されます (必要に応じて拡張します)。
/// これは、新しい `String` を割り当てて、すべての操作でコンテンツ全体をコピーすることを回避するために行われます。これにより、連結を繰り返して *n* バイトの文字列を作成するときに、*O*(*n*^ 2) の実行時間が発生します。
///
///
/// 右側の文字列は借用のみです。その内容は、返された `String` にコピーされます。
///
/// # Examples
///
/// 2 つの `String` を連結すると、最初の文字列が値で取得され、2 番目の文字列が借用されます。
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` が移動され、ここでは使用できなくなります。
/// ```
///
/// 最初の `String` を引き続き使用する場合は、クローンを作成して、代わりにクローンに追加できます。
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ここでも有効です。
/// ```
///
/// `&str` スライスの連結は、最初のスライスを `String` に変換することで実行できます。
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `String` に追加するための `+=` 演算子を実装します。
///
/// これは、[`push_str`][String::push_str] メソッドと同じ動作をします。
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] のタイプエイリアス。
///
/// このエイリアスは下位互換性のために存在し、最終的には非推奨になる可能性があります。
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// 値を `String` に変換するための trait。
///
/// この trait は、[`Display`] trait を実装するすべてのタイプに自動的に実装されます。
/// そのため、`ToString` を直接実装しないでください。
/// [`Display`] 代わりに実装する必要があり、`ToString` の実装を無料で入手できます。
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// 指定された値を `String` に変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// この実装では、`Display` 実装がエラーを返した場合、`to_string` メソッド panics。
/// `fmt::Write for String` 自体がエラーを返すことはないため、これは `Display` の実装が正しくないことを示しています。
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // 一般的なガイドラインは、ジェネリック関数をインライン化しないことです。
    // ただし、このメソッドから `#[inline]` を削除すると、無視できない回帰が発生します。
    // <https://github.com/rust-lang/rust/pull/74852>、それを削除しようとする最後の試みを参照してください。
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str` を `String` に変換します。
    ///
    /// 結果はヒープに割り当てられます。
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: テストは libstd をプルしますが、これによりここでエラーが発生します
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// 指定されたボックス化された `str` スライスを `String` に変換します。
    /// `str` スライスが所有されていることは注目に値します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// 指定された `String` を、所有されているボックス化された `str` スライスに変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// 文字列スライスを借用バリアントに変換します。
    /// ヒープの割り当ては実行されず、文字列はコピーされません。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// 文字列を Owned バリアントに変換します。
    /// ヒープの割り当ては実行されず、文字列はコピーされません。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// 文字列参照を借用バリアントに変換します。
    /// ヒープの割り当ては実行されず、文字列はコピーされません。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// 指定された `String` を、タイプ `u8` の値を保持する vector `Vec` に変換します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` 用の排出イテレータ。
///
/// この構造体は、[`String`] の [`drain`] メソッドによって作成されます。
/// 詳細については、そのドキュメントを参照してください。
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// デストラクタで＆'amut 文字列として使用されます
    string: *mut String,
    /// 削除するパーツの開始
    start: usize,
    /// 削除するパーツの終わり
    end: usize,
    /// 削除する現在の残りの範囲
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain を使用します。
            // "Reaffirm" 境界チェックは、panic コードが再度挿入されないようにします。
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// このイテレータの残りの (サブ) 文字列をスライスとして返します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: 安定化するときは、以下の AsRef のコメントを外します。
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` を安定させるときにコメントを外します。
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str {の場合
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> for Drain <' a> {fn as_ref(&self)->＆[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}