use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // `RawVec` API はフォールブルな割り当てメソッドを公開しないため、サードパーティのアロケータと `RawVec` の統合テストを作成するのは少し注意が必要です。そのため、アロケータが使い果たされたときに何が起こるかを確認できません (panic の検出以外)。
    //
    //
    // 代わりに、これは、`RawVec` メソッドがストレージを予約するときに少なくとも AllocatorAPI を通過することを確認するだけです。
    //
    //
    //
    //
    //

    // 割り当ての試行が失敗し始める前に一定量の燃料を消費するダムアロケータ。
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (再割り当てが発生するため、50 + 150=200 単位の燃料を使用します)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // まず、`reserve` は `reserve_exact` のように割り当てます。
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 は 7 の 2 倍以上なので、`reserve` は `reserve_exact` のように機能するはずです。
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 は 12 の半分未満であるため、`reserve` は指数関数的に成長する必要があります。
        // このテストの執筆時点では、成長係数は 2 であるため、新しい容量は 24 ですが、1.5 の成長係数でも問題ありません。
        //
        // したがって、`>= 18` はアサートされます。
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}