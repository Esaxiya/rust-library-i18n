#![stable(feature = "rust1", since = "1.0.0")]

//! スレッドセーフな参照カウントポインタ。
//!
//! 詳細については、[`Arc<T>`][Arc] のドキュメントを参照してください。

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// `Arc` に対して行われる可能性のある参照の量に対するソフト制限。
///
/// この制限を超えると、_exactly_ `MAX_REFCOUNT + 1` 参照でプログラムが中止されます (必ずしもそうとは限りません)。
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer はメモリフェンスをサポートしていません。
// Arc/Weak 実装での誤検知レポートを回避するには、代わりに同期にアトミックロードを使用します。
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// スレッドセーフな参照カウントポインタ。'Arc' は「AtomicallyReferenceCounted」の略です。
///
/// タイプ `Arc<T>` は、ヒープに割り当てられたタイプ `T` の値の共有所有権を提供します。`Arc` で [`clone`][clone] を呼び出すと、新しい `Arc` インスタンスが生成されます。これは、参照カウントを増やしながら、ソース `Arc` と同じヒープ上の割り当てを指します。
/// 特定の割り当てへの最後の `Arc` ポインターが破棄されると、その割り当てに格納されている値 ("inner value" と呼ばれることもあります) も削除されます。
///
/// Rust の共有参照はデフォルトで変更を許可しません。また、`Arc` も例外ではありません。通常、`Arc` 内の何かへの変更可能な参照を取得することはできません。`Arc` を介して変更する必要がある場合は、[`Mutex`][mutex]、[`RwLock`][rwlock]、または [`Atomic`][atomic] タイプのいずれかを使用してください。
///
/// ## スレッドセーフ
///
/// [`Rc<T>`] とは異なり、`Arc<T>` は参照カウントにアトミック操作を使用します。これは、スレッドセーフであることを意味します。欠点は、アトミック操作が通常のメモリアクセスよりもコストがかかることです。スレッド間で参照カウントの割り当てを共有していない場合は、オーバーヘッドを減らすために [`Rc<T>`] の使用を検討してください。
/// [`Rc<T>`] コンパイラはスレッド間で [`Rc<T>`] を送信しようとする試みをすべてキャッチするため、これは安全なデフォルトです。
/// ただし、図書館は、図書館の利用者により多くの柔軟性を与えるために `Arc<T>` を選択する場合があります。
///
/// `Arc<T>` `T` が [`Send`] および [`Sync`] を実装している限り、[`Send`] および [`Sync`] を実装します。
/// スレッドセーフではないタイプの `T` を `Arc<T>` に入れて、スレッドセーフにすることができないのはなぜですか? これは最初は少し直感に反するかもしれません。結局のところ、`Arc<T>` スレッドセーフのポイントではないでしょうか。重要なのはこれです。`Arc<T>` は同じデータの複数の所有権を持つことをスレッドセーフにしますが、そのデータにスレッドセーフを追加しません。
///
/// `Arc <` [`RefCell を検討してください < T>`]`>`。
/// [`RefCell<T>`] [`Sync`] ではなく、`Arc<T>` が常に [`Send`] であった場合、`Arc <` [`RefCell<T>`]`>` も同様です。
/// しかし、問題が発生します。
/// [`RefCell<T>`] スレッドセーフではありません。非アトミック操作を使用して借用カウントを追跡します。
///
/// 結局、これは、`Arc<T>` をある種の [`std::sync`] タイプ (通常は [`Mutex<T>`][mutex]) とペアリングする必要があるかもしれないことを意味します。
///
/// ## `Weak` でサイクルを壊す
///
/// [`downgrade`][downgrade] メソッドを使用して、所有していない [`Weak`] ポインターを作成できます。[`Weak`] ポインタを `Arc` に [`upgrade`][upgrade] することができますが、割り当てに格納されている値がすでに削除されている場合、これは [`None`] を返します。
/// 言い換えると、`Weak` ポインターは、割り当て内の値を存続させません。ただし、割り当て (値のバッキングストア) は維持されます。
///
/// `Arc` ポインター間のサイクルが割り当て解除されることはありません。
/// このため、[`Weak`] はサイクルを中断するために使用されます。たとえば、ツリーには、親ノードから子への強力な `Arc` ポインターと、子から親に戻る [`Weak`] ポインターを含めることができます。
///
/// # クローニングリファレンス
///
/// 既存の参照カウントポインタからの新しい参照の作成は、[`Arc<T>`][Arc] および [`Weak<T>`][Weak] 用に実装された `Clone` trait を使用して行われます。
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // 以下の 2 つの構文は同等です。
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a、b、および foo はすべて、同じメモリ位置を指すアークです。
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ([`Deref`][deref] trait を介して) `T` を自動的に逆参照するため、タイプ `Arc<T>` の値で `T` のメソッドを呼び出すことができます。`T` のメソッドとの名前の衝突を避けるために、`Arc<T>` 自体のメソッドは、[fully qualified syntax] を使用して呼び出される関連関数です。
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `アーク <T>`Clone` のような traits の` の実装は、完全修飾構文を使用して呼び出すこともできます。
/// 完全修飾構文を使用することを好む人もいれば、メソッド呼び出し構文を使用することを好む人もいます。
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // メソッド呼び出し構文
/// let arc2 = arc.clone();
/// // 完全修飾構文
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] 内部値がすでに削除されている可能性があるため、`T` への自動逆参照は行われません。
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// スレッド間で不変のデータを共有する:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ここではこれらのテストを **実行しない** ことに注意してください。
// windows ビルダーは、スレッドがメインスレッドよりも長生きし、同時に終了する (何かがデッドロックする) と非常に不幸になるため、これらのテストを実行しないことでこれを完全に回避します。
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// 可変 [`AtomicUsize`] の共有:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// 一般的な参照カウントのその他の例については、[`rc` documentation][rc_examples] を参照してください。
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` は、管理対象割り当てへの非所有参照を保持する [`Arc`] のバージョンです。
/// 割り当てにアクセスするには、`Weak` ポインタで [`upgrade`] を呼び出します。これにより、[`Option`]`<`[`Arc`] `が返されます。<T>>`。
///
/// `Weak` 参照は所有権にカウントされないため、割り当てに格納されている値が削除されるのを防ぐことはできません。また、`Weak` 自体は、値がまだ存在することを保証しません。
///
/// したがって、[`upgrade`] d のときに [`None`] を返す場合があります。
/// ただし、`Weak` 参照は、割り当て自体 (バッキングストア) の割り当て解除を *防止* することに注意してください。
///
/// `Weak` ポインターは、内部値がドロップされるのを防ぐことなく、[`Arc`] によって管理される割り当てへの一時的な参照を保持するのに役立ちます。
/// また、相互に所有する参照によって [`Arc`] がドロップされることは決してないため、[`Arc`] ポインター間の循環参照を防ぐためにも使用されます。
/// たとえば、ツリーには、親ノードから子への強力な [`Arc`] ポインターと、子から親に戻る `Weak` ポインターを含めることができます。
///
/// `Weak` ポインターを取得する一般的な方法は、[`Arc::downgrade`] を呼び出すことです。
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // これは、列挙型でこのタイプのサイズを最適化できるようにする `NonNull` ですが、必ずしも有効なポインターであるとは限りません。
    //
    // `Weak::new` これを `usize::MAX` に設定して、ヒープにスペースを割り当てる必要がないようにします。
    // RcBox には少なくとも 2 の配置があるため、これは実際のポインターが持つ値ではありません。
    // これは、`T: Sized` の場合にのみ可能です。サイズのない `T` がぶら下がることはありません。
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// これは repr(C) から future であり、フィールドの並べ替えの可能性に対して耐性があります。これにより、変換可能な内部タイプの安全な [into|from]_raw() が妨害されます。
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // 値 usize::MAX は、弱いポインターをアップグレードしたり、強いポインターをダウングレードしたりする機能を一時的に "locking" するための番兵として機能します。これは、`make_mut` および `get_mut` でのレースを回避するために使用されます。
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// 新しい `Arc<T>` を構築します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // 弱いポインタのカウントを 1 として開始します。これは、すべての強いポインタ (kinda) によって保持されている弱いポインタです。詳細については、std/rc.rs を参照してください。
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// それ自体への弱い参照を使用して、新しい `Arc<T>` を構築します。
    /// この関数が戻る前に弱参照をアップグレードしようとすると、`None` 値になります。
    /// ただし、弱参照は自由に複製され、後で使用するために保存される場合があります。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // 単一の弱参照を使用して、"uninitialized" 状態で内部を構築します。
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // 弱いポインタの所有権を放棄しないことが重要です。そうしないと、`data_fn` が戻るまでにメモリが解放される可能性があります。
        // 本当に所有権を譲渡したい場合は、自分自身に追加の弱ポインターを作成できますが、これにより、弱参照カウントが追加で更新され、それ以外の場合は必要ない場合があります。
        //
        //
        //
        //
        let data = data_fn(&weak);

        // これで、内部値を適切に初期化し、弱参照を強参照に変えることができます。
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // 上記のデータフィールドへの書き込みは、ゼロ以外のストロングカウントを監視するすべてのスレッドに表示される必要があります。
            // したがって、`Weak::upgrade` の `compare_exchange_weak` と同期するには、少なくとも "Release" の順序が必要です。
            //
            // "Acquire" 注文は必要ありません。
            // `data_fn` の考えられる動作を検討するときは、アップグレード不可能な `Weak` を参照して何ができるかを確認するだけで済みます。
            //
            // - `Weak` を *複製* して、弱参照数を増やすことができます。
            // - それらのクローンを削除して、弱参照数を減らすことができます (ただし、ゼロになることはありません)。
            //
            // これらの副作用は私たちに何の影響も与えず、安全なコードだけでは他の副作用は起こり得ません。
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // 強い参照は共有された弱い参照を集合的に所有する必要があるため、古い弱い参照に対してデストラクタを実行しないでください。
        //
        mem::forget(weak);
        strong
    }

    /// 初期化されていない内容で新しい `Arc` を構築します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 初期化されていない内容で新しい `Arc` を構築し、メモリは `0` バイトで満たされます。
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 新しい `Pin<Arc<T>>` を構築します。
    /// `T` が `Unpin` を実装していない場合、`data` はメモリに固定され、移動できなくなります。
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// 新しい `Arc<T>` を構築し、割り当てが失敗した場合にエラーを返します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // 弱いポインタのカウントを 1 として開始します。これは、すべての強いポインタ (kinda) によって保持されている弱いポインタです。詳細については、std/rc.rs を参照してください。
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// 初期化されていない内容で新しい `Arc` を構築し、割り当てが失敗した場合はエラーを返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// 初期化されていない内容で新しい `Arc` を構築し、メモリは `0` バイトで満たされ、割り当てが失敗した場合はエラーを返します。
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc` に厳密な参照が 1 つしかない場合は、内部値を返します。
    ///
    /// それ以外の場合、[`Err`] は、渡されたのと同じ `Arc` で返されます。
    ///
    ///
    /// これは、顕著な弱い参照がある場合でも成功します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // 弱ポインターを作成して、暗黙の強弱参照をクリーンアップします
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// 初期化されていないコンテンツを使用して、アトミックに参照カウントされた新しいスライスを構築します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 遅延初期化:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// メモリが `0` バイトで満たされている状態で、初期化されていない内容で新しいアトミック参照カウントスライスを構築します。
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` に変換します。
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] と同様に、内部値が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、すぐに未定義の動作が発生します。
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` に変換します。
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] と同様に、内部値が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、すぐに未定義の動作が発生します。
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 遅延初期化:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` を消費し、ラップされたポインターを返します。
    ///
    /// メモリリークを回避するには、[`Arc::from_raw`] を使用してポインタを `Arc` に戻す必要があります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// データへの生のポインタを提供します。
    ///
    /// カウントはまったく影響を受けず、`Arc` は消費されません。
    /// `Arc` に強いカウントがある限り、ポインターは有効です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // 安全性: これは Deref::deref または RcBoxPtr::inner を通過できません。
        // これは、raw/mut の出所を保持するために必要です。
        // `get_mut` Rc が `from_raw` を介して回復された後、ポインタを介して書き込むことができます。
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// 生のポインタから `Arc<T>` を構築します。
    ///
    /// 生のポインタは、[`Arc<U>::into_raw`][into_raw] の呼び出しによって以前に返されている必要があります。ここで、`U` は `T` と同じサイズと配置である必要があります。
    /// `U` が `T` の場合、これは簡単に当てはまります。
    /// `U` が `T` ではなく、同じサイズと配置である場合、これは基本的に、異なるタイプの参照を変換するようなものであることに注意してください。
    /// この場合に適用される制限の詳細については、[`mem::transmute`][transmute] を参照してください。
    ///
    /// `from_raw` のユーザーは、`T` の特定の値が 1 回だけドロップされることを確認する必要があります。
    ///
    /// 返された `Arc<T>` にアクセスしなくても、不適切な使用はメモリの安全性を損なう可能性があるため、この関数は安全ではありません。
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // 漏れを防ぐために `Arc` に戻します。
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` をさらに呼び出すと、メモリが安全ではなくなります。
    /// }
    ///
    /// // `x` が上記のスコープから外れたときにメモリが解放されたため、`x_ptr` がぶら下がっています。
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // オフセットを逆にして、元の ArcInner を見つけます。
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// この割り当てへの新しい [`Weak`] ポインタを作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // 以下の CAS で値を確認しているので、このリラックスは問題ありません。
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // 弱いカウンターが現在 "locked" であるかどうかを確認します。もしそうなら、スピンします。
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: このコードは現在、オーバーフローの可能性を無視しています
            // usize::MAX に; 一般に、オーバーフローに対処するには、Rc と Arc の両方を調整する必要があります。
            //

            // Clone() とは異なり、`is_unique` からの書き込みと同期するには、これを取得読み取りにする必要があります。これにより、その書き込みの前のイベントがこの読み取りの前に発生します。
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ぶら下がっている弱点を作成しないようにしてください
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// この割り当てへの [`Weak`] ポインターの数を取得します。
    ///
    /// # Safety
    ///
    /// この方法自体は安全ですが、正しく使用するには特別な注意が必要です。
    /// 別のスレッドは、このメソッドを呼び出してから結果に基づいて動作するまでの間を含め、いつでもウィークカウントを変更できます。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // スレッド間で `Arc` または `Weak` を共有していないため、このアサーションは決定論的です。
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // 弱いカウントが現在ロックされている場合、ロックを取得する直前のカウントの値は 0 でした。
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// この割り当てへの強力な (`Arc`) ポインターの数を取得します。
    ///
    /// # Safety
    ///
    /// この方法自体は安全ですが、正しく使用するには特別な注意が必要です。
    /// 別のスレッドは、このメソッドを呼び出してから結果に基づいて動作するまでの間を含め、いつでもストロングカウントを変更できます。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // `Arc` をスレッド間で共有していないため、このアサーションは決定論的です。
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// 指定されたポインタに関連付けられている `Arc<T>` の強力な参照カウントを 1 つ増やします。
    ///
    /// # Safety
    ///
    /// ポインタは `Arc::into_raw` を介して取得されている必要があり、関連する `Arc` インスタンスは有効である必要があります (つまり、
    /// このメソッドの期間中、ストロングカウントは少なくとも 1) である必要があります。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // `Arc` をスレッド間で共有していないため、このアサーションは決定論的です。
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc を保持しますが、ManuallyDrop でラップして refcount に触れないでください
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ここで refcount を増やしますが、新しい refcount も削除しないでください
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// 指定されたポインタに関連付けられている `Arc<T>` の強い参照カウントを 1 つ減らします。
    ///
    /// # Safety
    ///
    /// ポインタは `Arc::into_raw` を介して取得されている必要があり、関連する `Arc` インスタンスは有効である必要があります (つまり、
    /// このメソッドを呼び出す場合、ストロングカウントは少なくとも 1) である必要があります。
    /// このメソッドは、最終的な `Arc` とバッキングストレージを解放するために使用できますが、最終的な `Arc` が解放された後に呼び出すことは **すべきではありません**。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // スレッド間で `Arc` を共有していないため、これらのアサーションは決定論的です。
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // このアークが生きている間、内部ポインタが有効であることが保証されているため、この安全性は問題ありません。
        // さらに、内部データも `Sync` であるため、`ArcInner` 構造自体が `Sync` であることがわかっているため、これらのコンテンツへの不変のポインターを貸し出してもかまいません。
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` のインライン化されていない部分。
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ボックスの割り当て自体を解放できない場合でも、この時点でデータを破棄します (まだ弱いポインタが存在する可能性があります)。
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // すべての強参照によって集合的に保持されている弱参照を削除します
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// 2 つの `Arc` が同じ割り当てを指している場合 ([`ptr::eq`] と同様の静脈内)、`true` を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// 値にレイアウトが指定されている場合に、サイズ変更されていない可能性のある内部値に十分なスペースを備えた `ArcInner<T>` を割り当てます。
    ///
    /// 関数 `mem_to_arcinner` は、データポインターを使用して呼び出され、`ArcInner<T>` の (潜在的に太い) ポインターを返す必要があります。
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // 指定された値のレイアウトを使用してレイアウトを計算します。
        // 以前は、レイアウトは式 `&*(ptr as* const ArcInner<T>)` で計算されていましたが、これにより参照がずれてしまいました (#54908 を参照)。
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// 値にレイアウトが指定されている、サイズが変更されていない可能性のある内部値に十分なスペースを備えた `ArcInner<T>` を割り当て、割り当てが失敗した場合はエラーを返します。
    ///
    ///
    /// 関数 `mem_to_arcinner` は、データポインターを使用して呼び出され、`ArcInner<T>` の (潜在的に太い) ポインターを返す必要があります。
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // 指定された値のレイアウトを使用してレイアウトを計算します。
        // 以前は、レイアウトは式 `&*(ptr as* const ArcInner<T>)` で計算されていましたが、これにより参照がずれてしまいました (#54908 を参照)。
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner を初期化します
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// サイズ変更されていない内部値に十分なスペースを持つ `ArcInner<T>` を割り当てます。
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // 指定された値を使用して `ArcInner<T>` に割り当てます。
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // 値をバイトとしてコピー
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // 内容を削除せずに割り当てを解放します
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// 指定された長さの `ArcInner<[T]>` を割り当てます。
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// スライスから新しく割り当てられた Arc <\[T\]> に要素をコピーします
    ///
    /// 呼び出し元が所有権を取得するか、`T: Copy` をバインドする必要があるため、安全ではありません。
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// 特定のサイズであることがわかっているイテレータから `Arc<[T]>` を構築します。
    ///
    /// サイズが間違っている場合の動作は未定義です。
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // T 要素のクローン作成中の Panic ガード。
        // panic の場合、新しい ArcInner に書き込まれた要素は削除され、メモリが解放されます。
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // 最初の要素へのポインタ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // すべて明確です。新しい ArcInner が解放されないように、ガードを忘れてください。
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` に使用される特殊化 trait。
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` ポインタのクローンを作成します。
    ///
    /// これにより、同じ割り当てへの別のポインタが作成され、強力な参照カウントが増加します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // 元の参照を知っていると、他のスレッドがオブジェクトを誤って削除するのを防ぐため、ここでは緩和された順序を使用しても問題ありません。
        //
        // [Boost documentation][1] で説明されているように、参照カウンターの増加は常に memory_order_relaxed を使用して実行できます。オブジェクトへの新しい参照は既存の参照からのみ形成でき、あるスレッドから別のスレッドに既存の参照を渡すと、必要な同期がすでに提供されている必要があります。
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ただし、誰かが Arcs を「mem: : forget」している場合に備えて、大量の refcount を防ぐ必要があります。
        // これを行わないと、カウントがオーバーフローし、ユーザーが使用する可能性があります - 解放後。
        // 一度に参照カウントをインクリメントする ~2 億のスレッドがないことを前提として、`isize::MAX` に急速に飽和します。
        //
        // この branch は、現実的なプログラムでは使用されません。
        //
        // そのようなプログラムは信じられないほど退化していて、それをサポートする気がないので、私たちは中止します。
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// 指定された `Arc` への可変参照を作成します。
    ///
    /// 同じ割り当てへの他の `Arc` または [`Weak`] ポインターがある場合、`make_mut` は新しい割り当てを作成し、内部値で [`clone`][clone] を呼び出して、一意の所有権を確保します。
    /// これは、クローンオンライトとも呼ばれます。
    ///
    /// これは、残りの `Weak` ポインターの関連付けを解除する [`Rc::make_mut`] の動作とは異なることに注意してください。
    ///
    /// [`get_mut`][get_mut] も参照してください。これは、クローンではなく失敗します。
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // 何も複製しません
    /// let mut other_data = Arc::clone(&data); // 内部データのクローンを作成しません
    /// *Arc::make_mut(&mut data) += 1;         // クローン内部データ
    /// *Arc::make_mut(&mut data) += 1;         // 何も複製しません
    /// *Arc::make_mut(&mut other_data) *= 2;   // 何も複製しません
    ///
    /// // これで、`data` と `other_data` は異なる割り当てを指します。
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // 強参照と弱参照の両方を保持していることに注意してください。
        // したがって、強い参照のみを解放しても、それ自体ではメモリの割り当てが解除されることはありません。
        //
        // Acquire を使用して、`strong` へのリリース書き込み (つまり、デクリメント) の前に発生する `weak` への書き込みを確認します。
        // カウントが弱いため、ArcInner 自体の割り当てが解除される可能性はありません。
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // 別の強力なポインタが存在するため、クローンを作成する必要があります。
            // 複製された値を直接書き込むことができるように、メモリを事前に割り当てます。
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // これは基本的に最適化であるため、上記ではリラックスしただけで十分です。常に弱いポインターをドロップしてレースを行っています。
            // 最悪の場合、不必要に新しいアークが割り当てられてしまいます。
            //

            // 最後の強い参照を削除しましたが、追加の弱い参照が残っています。
            // コンテンツを新しいアークに移動し、他の弱い参照を無効にします。
            //

            // 弱いカウントは強い参照を持つスレッドによってのみロックできるため、`weak` の読み取りで usize::MAX を生成する (つまり、ロックする) ことはできないことに注意してください。
            //
            //

            // 必要に応じて ArcInner をクリーンアップできるように、独自の暗黙的なウィークポインターを実体化します。
            //
            let _weak = Weak { ptr: this.ptr };

            // データを盗むことができます、残っているのは弱点だけです
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // 私たちはどちらの種類の唯一の参照でもありました。強力な参照カウントをバックアップします。
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` と同様に、参照が最初から一意であるか、コンテンツのクローンを作成すると 1 つになったため、安全性は問題ありません。
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// 同じ割り当てへの他の `Arc` または [`Weak`] ポインターがない場合、指定された `Arc` への可変参照を返します。
    ///
    ///
    /// それ以外の場合は、共有値を変更するのは安全ではないため、[`None`] を返します。
    ///
    /// [`make_mut`][make_mut] も参照してください。これは、他のポインターがある場合に内部値を [`clone`][clone] します。
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // 返されるポインタは、T に返される *唯一の* ポインタであることが保証されているため、この安全性は問題ありません。
            // この時点で参照カウントは 1 であることが保証されており、Arc 自体が `mut` である必要があるため、内部データへの唯一の可能な参照を返します。
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// チェックなしで、指定された `Arc` への可変参照を返します。
    ///
    /// 安全で適切なチェックを行う [`get_mut`] も参照してください。
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// 同じ割り当てへの他の `Arc` または [`Weak`] ポインターは、返された借用の期間中、逆参照されてはなりません。
    ///
    /// これは、たとえば `Arc::new` の直後など、そのようなポインタが存在しない場合は簡単に当てはまります。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" フィールドをカバーする参照を作成しないように注意してください。これは、参照カウントへの同時アクセスでエイリアスを作成するためです (例:
        // `Weak` による)。
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// これが基になるデータへの一意の参照 (弱い参照を含む) であるかどうかを判別します。
    ///
    ///
    /// これには、弱参照カウントをロックする必要があることに注意してください。
    fn is_unique(&mut self) -> bool {
        // 唯一のウィークポインターホルダーであると思われる場合は、ウィークポインターカウントをロックします。
        //
        // ここでの取得ラベルは、`weak` カウントのデクリメント (リリースを使用する `Weak::drop` 経由) の前に、`strong` (特に `Weak::upgrade`) への書き込みとの発生前の関係を保証します。
        // アップグレードされた弱参照がドロップされなかった場合、ここの CAS は失敗するため、同期する必要はありません。
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // これは、`drop` の `strong` カウンターのデクリメントと同期するために `Acquire` である必要があります。これは、最後の参照以外がドロップされたときに発生する唯一のアクセスです。
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ここでのリリース書き込みは `downgrade` の読み取りと同期し、書き込み後に上記の `strong` の読み取りが発生するのを効果的に防ぎます。
            //
            //
            self.inner().weak.store(1, Release); // ロックを解除します
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` をドロップします。
    ///
    /// これにより、強い参照カウントが減少します。
    /// 強い参照カウントがゼロに達した場合、他の参照 (存在する場合) は [`Weak`] のみであるため、内部値を `drop` します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // 何も印刷しません
    /// drop(foo2);   // "dropped!" を印刷します
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` はすでにアトミックであるため、オブジェクトを削除しない限り、他のスレッドと同期する必要はありません。
        // これと同じロジックが、以下の `fetch_sub` から `weak` カウントに適用されます。
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // このフェンスは、データの使用の並べ替えやデータの削除を防ぐために必要です。
        // `Release` とマークされているため、参照カウントの減少はこの `Acquire` フェンスと同期します。
        // これは、データの使用が参照カウントを減らす前に行われることを意味します。これは、データの削除の前に行われるこのフェンスの前に行われます。
        //
        // [Boost documentation][1] で説明されているように、
        //
        // > オブジェクトへの可能なアクセスを 1 つに強制することが重要です
        // > 削除する前に *発生する* スレッド (既存の参照を介して)
        // > 別のスレッドのオブジェクト。これは "release" によって実現されます
        // > 参照を削除した後の操作 (オブジェクトへのアクセス)
        // > この参照を通じて、明らかに前に起こったに違いありません)、そして
        // > "acquire" オブジェクトを削除する前の操作。
        //
        // 特に、Arc のコンテンツは通常不変ですが、Mutex のようなものに内部書き込みを行うことができます。<T>。
        // ミューテックスは削除されたときに取得されないため、同期ロジックに依存して、スレッド A での書き込みをスレッド B で実行されているデストラクタから見えるようにすることはできません。
        //
        //
        // また、ここでの取得フェンスは、おそらく取得負荷に置き換えることができることに注意してください。これにより、非常に競合する状況でのパフォーマンスが向上する可能性があります。[2] を参照してください。
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` を具象型にダウンキャストしてみてください。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// メモリを割り当てずに、新しい `Weak<T>` を構築します。
    /// 戻り値で [`upgrade`] を呼び出すと、常に [`None`] が得られます。
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// データフィールドについてアサーションを作成せずに参照カウントにアクセスできるようにするヘルパータイプ。
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// この `Weak<T>` が指すオブジェクト `T` への生のポインタを返します。
    ///
    /// ポインタは、強い参照がある場合にのみ有効です。
    /// ポインタがぶら下がっている、位置が合っていない、または [`null`] である可能性があります。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // 両方が同じオブジェクトを指しています
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ここの強いものはそれを生かし続けるので、私たちはまだオブジェクトにアクセスすることができます。
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // もうそうじゃない。
    /// // weak.as_ptr() を実行できますが、ポインターにアクセスすると、未定義の動作が発生します。
    /// // assert_eq! ( "hello"、unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ポインタがぶら下がっている場合は、番兵を直接返します。
            // ペイロードは少なくとも ArcInner (usize) と同じように整列されているため、これを有効なペイロードアドレスにすることはできません。
            ptr as *const T
        } else {
            // 安全性: is_dangling が false を返す場合、ポインターは参照解除可能です。
            // ペイロードはこの時点でドロップされる可能性があり、来歴を維持する必要があるため、生のポインター操作を使用します。
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` を消費し、生のポインターに変換します。
    ///
    /// これにより、1 つの弱参照の所有権を保持したまま、弱ポインターが生のポインターに変換されます (弱カウントはこの操作によって変更されません)。
    /// [`from_raw`] で `Weak<T>` に戻すことができます。
    ///
    /// [`as_ptr`] の場合と同じように、ポインタのターゲットにアクセスする際の制限が適用されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// 以前に [`into_raw`] によって作成された生のポインターを `Weak<T>` に変換し直します。
    ///
    /// これは、強力な参照を安全に取得するため (後で [`upgrade`] を呼び出すことによって)、または `Weak<T>` を削除することによって弱いカウントの割り当てを解除するために使用できます。
    ///
    /// 1 つの弱参照の所有権を取得します ([`new`] によって作成されたポインターを除いて、これらは何も所有していません。メソッドは引き続きそれらに対して機能します)。
    ///
    /// # Safety
    ///
    /// ポインターは [`into_raw`] から発信されている必要があり、潜在的な弱参照を所有している必要があります。
    ///
    /// これを呼び出すときに、ストロングカウントを 0 にすることができます。
    /// それにもかかわらず、これは現在 raw ポインターとして表されている 1 つの弱参照の所有権を取得します (弱カウントはこの操作によって変更されません)。したがって、[`into_raw`] への以前の呼び出しとペアにする必要があります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // 最後の弱いカウントをデクリメントします。
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // 入力ポインターの導出方法のコンテキストについては、Weak::as_ptr を参照してください。

        let ptr = if is_dangling(ptr as *mut T) {
            // これはぶら下がっている弱点です。
            ptr as *mut ArcInner<T>
        } else {
            // それ以外の場合は、ポインタがぶら下がっていない弱点からのものであることが保証されます。
            // 安全性: ptr は実際の (ドロップされる可能性のある) T を参照するため、data_offset を安全に呼び出すことができます。
            let offset = unsafe { data_offset(ptr) };
            // したがって、オフセットを逆にして RcBox 全体を取得します。
            // 安全性: ポインターは弱点から発生したため、このオフセットは安全です。
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // 安全性: 元のウィークポインタを復元したので、ウィークを作成できます。
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` ポインターを [`Arc`] にアップグレードしようとし、成功した場合は内部値のドロップを遅らせます。
    ///
    ///
    /// 内部値が削除された場合は、[`None`] を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // すべての強力なポインタを破壊します。
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // この関数は参照カウントを 0 から 1 にしないため、fetch_add の代わりに CAS ループを使用して強いカウントをインクリメントします。
        //
        //
        let inner = self.inner()?;

        // 観察できる 0 の書き込みは、フィールドを永続的にゼロの状態のままにするため (したがって、"stale" の読み取りは 0 で問題ありません)、その他の値は以下の CAS を介して確認されます。
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // これを行う理由については、`Arc::clone` のコメントを参照してください (`mem::forget` の場合)。
            if n > MAX_REFCOUNT {
                abort();
            }

            // 新しい状態については何も期待していないため、失敗した場合はリラックスしても問題ありません。
            // `Weak` 参照がすでに作成された後で内部値を初期化できる場合、成功ケースが `Arc::new_cyclic` と同期するには、取得が必要です。
            // その場合、完全に初期化された値を観察することを期待しています。
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // 上記で null チェック
                Err(old) => n = old,
            }
        }
    }

    /// この割り当てを指す強力な (`Arc`) ポインターの数を取得します。
    ///
    /// `self` が [`Weak::new`] を使用して作成された場合、これは 0 を返します。
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// この割り当てを指す `Weak` ポインターの数の概算を取得します。
    ///
    /// `self` が [`Weak::new`] を使用して作成された場合、または強力なポインターが残っていない場合、これは 0 を返します。
    ///
    /// # Accuracy
    ///
    /// 実装の詳細により、他のスレッドが同じ割り当てを指す `Arc` または `Weak` を操作している場合、戻り値はどちらの方向にも 1 ずれることがあります。
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // 弱いカウントを読み取った後、少なくとも 1 つの強いポインタが存在することを確認したので、弱いカウントを観察したときに暗黙の弱い参照 (強い参照が存在する場合は常に存在する) がまだ存在していることがわかり、したがって安全に差し引くことができます。
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ポインタがぶら下がっていて、割り当てられた `ArcInner` がない場合 (つまり、この `Weak` が `Weak::new` によって作成された場合) に `None` を返します。
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" フィールドは同時に変更される可能性があるため、"data" フィールドをカバーする参照を作成しないように注意してください (たとえば、最後の `Arc` が削除された場合、データフィールドはその場で削除されます)。
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// 2 つの `Weak` が同じ割り当てを指している場合 ([`ptr::eq`] と同様)、または両方が割り当てを指していない場合 (`Weak::new()`) で作成されているため)、`true` を返します。
    ///
    ///
    /// # Notes
    ///
    /// これはポインタを比較するため、割り当てを指していない場合でも、`Weak::new()` は互いに等しくなることを意味します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` の比較。
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// 同じ割り当てを指す `Weak` ポインターのクローンを作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // これが緩和される理由については、Arc::clone() のコメントを参照してください。
        // ウィークカウントは *他の* ウィークポインタが存在しない場合にのみロックされるため、これは fetch_add (ロックを無視) を使用できます。
        //
        // (したがって、その場合、このコードを実行することはできません)。
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // これを行う理由については、Arc::clone() のコメントを参照してください (mem::forget の場合)。
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// メモリを割り当てずに、新しい `Weak<T>` を構築します。
    /// 戻り値で [`upgrade`] を呼び出すと、常に [`None`] が得られます。
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ポインタをドロップします。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // 何も印刷しません
    /// drop(foo);        // "dropped!" を印刷します
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // 私たちが最後の弱いポインタであることがわかった場合は、データを完全に割り当て解除するときです。メモリオーダリングについては、Arc::drop() の説明を参照してください
        //
        // ここでロック状態を確認する必要はありません。弱カウントは、弱参照が 1 つだけ存在する場合にのみロックできるためです。つまり、ドロップは、残りの弱参照でのみ実行できます。これは、ロックが解放された後にのみ発生します。
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// `&T` でのより一般的な最適化としてではなく、ここでこの特殊化を行っています。そうしないと、参照のすべての等価性チェックにコストがかかるためです。
/// `Arc` は、複製に時間がかかるが、等しいかどうかをチェックするのに重い大きな値を格納するために使用されると想定しているため、このコストをより簡単に回収できます。
///
/// また、2 つの `＆T` よりも、同じ値を指す 2 つの `Arc` クローンが存在する可能性が高くなります。
///
/// `PartialEq` としての `T: Eq` が意図的に無反射である可能性がある場合にのみ、これを行うことができます。
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// 2 つの `アーク` の等式。
    ///
    /// 2 つの `Arc` は、それらが異なる割り当てで格納されている場合でも、それらの内部値が等しい場合は等しくなります。
    ///
    /// `T` が `Eq` (等式の再帰性を意味する) も実装している場合、同じ割り当てを指す 2 つの `Arc` は常に等しくなります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// 2 つの `アーク` の不等式。
    ///
    /// 2 つの `Arc` は、それらの内部値が等しくない場合、等しくありません。
    ///
    /// `T` が `Eq` (等式の再帰性を意味する) も実装している場合、同じ値を指す 2 つの `Arc` が等しくなることはありません。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// 2 つの `Arc` の部分的な比較。
    ///
    /// 2 つは、内部値で `partial_cmp()` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// 2 つの `Arc` の比較より少ない。
    ///
    /// 2 つは、内部値で `<` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 2 つの「アーク」の「以下」の比較。
    ///
    /// 2 つは、内部値で `<=` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// 2 つの `Arc` の比較よりも大きい。
    ///
    /// 2 つは、内部値で `>` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 2 つの「アーク」の「以上」の比較。
    ///
    /// 2 つは、内部値で `>=` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// 2 つの `アーク` の比較。
    ///
    /// 2 つは、内部値で `cmp()` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T` の `Default` 値を使用して、新しい `Arc<T>` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// 参照カウントされたスライスを割り当て、`v` のアイテムを複製して埋めます。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// 参照カウントされた `str` を割り当て、`v` をその中にコピーします。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// 参照カウントされた `str` を割り当て、`v` をその中にコピーします。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ボックス化されたオブジェクトを、参照カウントされた新しい割り当てに移動します。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// 参照カウントされたスライスを割り当て、`v` のアイテムをその中に移動します。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vec がメモリを解放できるようにしますが、内容を破壊しないでください
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` の各要素を取得し、`Arc<[T]>` に収集します。
    ///
    /// # 性能特性
    ///
    /// ## 一般的なケース
    ///
    /// 一般的なケースでは、`Arc<[T]>` への収集は、最初に `Vec<T>` への収集によって行われます。つまり、次のように書くとき:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// これは、次のように動作します。
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // 割り当ての最初のセットはここで発生します。
    ///     .into(); // `Arc<[T]>` の 2 番目の割り当てはここで行われます。
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// これにより、`Vec<T>` を構築するために必要な回数だけ割り当てられ、次に `Vec<T>` を `Arc<[T]>` に変換するために 1 回割り当てられます。
    ///
    ///
    /// ## 既知の長さのイテレータ
    ///
    /// `Iterator` が `TrustedLen` を実装し、正確なサイズである場合、`Arc<[T]>` に対して単一の割り当てが行われます。例えば:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // ここでは、1 つの割り当てのみが発生します。
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` への収集に使用される特殊化 trait。
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // これは、`TrustedLen` イテレータの場合です。
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // 安全性: イテレータの長さが正確であることを確認する必要があります。
                Arc::from_iter_exact(self, low)
            }
        } else {
            // 通常の実装にフォールバックします。
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ポインターの背後にあるペイロードの `ArcInner` 内のオフセットを取得します。
///
/// # Safety
///
/// ポインターは、以前に有効だった T のインスタンスを指している (そして有効なメタデータを持っている) 必要がありますが、T は削除できます。
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // サイズ変更されていない値を ArcInner の最後に揃えます。
    // RcBox は repr(C) であるため、常にメモリ内の最後のフィールドになります。
    // 安全性: サイズ変更されていないタイプはスライス、trait オブジェクトのみであるため、
    // および extern タイプの場合、入力安全要件は現在、align_of_val_raw の要件を満たすのに十分です。これは、std の外部では信頼できない可能性のある言語の実装の詳細です。
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}