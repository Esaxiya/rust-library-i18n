//! メモリ割り当て API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // これらは、グローバルアロケータを呼び出すための魔法のシンボルです。rustc は、`__rg_alloc` などを呼び出すためにそれらを生成します。
    // `#[global_allocator]` 属性がある場合 (その属性マクロを展開するコードがそれらの関数を生成する場合)、または libstd のデフォルトの実装を呼び出す場合 (`__rdl_alloc` など)。
    //
    // `library/std/src/alloc.rs` で) それ以外の場合。
    // LLVM の rustc fork も、これらの関数名を特殊なケースに分けて、それぞれ `malloc`、`realloc`、`free` のように最適化できるようにします。
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// グローバルメモリアロケータ。
///
/// このタイプは、`#[global_allocator]` 属性 (存在する場合) または `std` crate のデフォルトで登録されたアロケーターに呼び出しを転送することにより、[`Allocator`] trait を実装します。
///
///
/// Note: このタイプは不安定ですが、[free functions in `alloc`](self#functions) を介して提供される機能にアクセスできます。
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// グローバルアロケータでメモリを割り当てます。
///
/// この関数は、`#[global_allocator]` 属性が存在する場合は `#[global_allocator]` 属性で登録されたアロケータの [`GlobalAlloc::alloc`] メソッド、または `std` crate のデフォルトへの呼び出しを転送します。
///
///
/// この関数は、[`Global`] タイプの `alloc` メソッドと [`Allocator`] trait が安定すると、廃止される予定です。
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] を参照してください。
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// グローバルアロケータでメモリの割り当てを解除します。
///
/// この関数は、`#[global_allocator]` 属性が存在する場合は `#[global_allocator]` 属性で登録されたアロケータの [`GlobalAlloc::dealloc`] メソッド、または `std` crate のデフォルトへの呼び出しを転送します。
///
///
/// この関数は、[`Global`] タイプの `dealloc` メソッドと [`Allocator`] trait が安定すると、廃止される予定です。
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] を参照してください。
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// グローバルアロケータを使用してメモリを再割り当てします。
///
/// この関数は、`#[global_allocator]` 属性が存在する場合は `#[global_allocator]` 属性で登録されたアロケーターの [`GlobalAlloc::realloc`] メソッド、または `std` crate のデフォルトへの呼び出しを転送します。
///
///
/// この関数は、[`Global`] タイプの `realloc` メソッドと [`Allocator`] trait が安定すると、廃止される予定です。
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] を参照してください。
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ゼロで初期化されたメモリをグローバルアロケータに割り当てます。
///
/// この関数は、`#[global_allocator]` 属性が存在する場合は `#[global_allocator]` 属性で登録されたアロケータの [`GlobalAlloc::alloc_zeroed`] メソッド、または `std` crate のデフォルトへの呼び出しを転送します。
///
///
/// この関数は、[`Global`] タイプの `alloc_zeroed` メソッドと [`Allocator`] trait が安定すると、廃止される予定です。
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] を参照してください。
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // 安全性: `layout` のサイズはゼロ以外です。
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // 安全性: `Allocator::grow` と同じ
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // 安全性: `old_size` が `new_size` 以上であるため、`new_size` はゼロ以外です。
            // 安全条件によって要求されるように。その他の条件は、発信者が支持する必要があります
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` おそらく `new_size >= old_layout.size()` または同様のものをチェックします。
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 安全性: `new_layout.size()` は `old_size` 以上である必要があるため、
            // 古いメモリ割り当てと新しいメモリ割り当ての両方が、`old_size` バイトの読み取りと書き込みに有効です。
            // また、古い割り当てはまだ割り当て解除されていないため、`new_ptr` と重複することはできません。
            // したがって、`copy_nonoverlapping` への呼び出しは安全です。
            // `dealloc` の安全契約は、発信者が支持する必要があります。
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // 安全性: `layout` のサイズはゼロ以外です。
            // 他の条件は、発信者が支持する必要があります
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全性: すべての条件は発信者が支持する必要があります
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全性: すべての条件は発信者が支持する必要があります
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // 安全性: 条件は発信者が支持する必要があります
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // 安全性: `new_size` はゼロ以外です。その他の条件は、発信者が支持する必要があります
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` おそらく `new_size <= old_layout.size()` または同様のものをチェックします。
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // 安全性: `new_size` は `old_layout.size()` 以下である必要があるため、
            // 古いメモリ割り当てと新しいメモリ割り当ての両方が、`new_size` バイトの読み取りと書き込みに有効です。
            // また、古い割り当てはまだ割り当て解除されていないため、`new_ptr` と重複することはできません。
            // したがって、`copy_nonoverlapping` への呼び出しは安全です。
            // `dealloc` の安全契約は、発信者が支持する必要があります。
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// 一意のポインタのアロケータ。
// この関数は巻き戻してはいけません。含まれている場合、MIRcodegen は失敗します。
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// この署名は `Box` と同じである必要があります。そうでない場合、ICE が発生します。
// `Box` に追加のパラメーター (`A: Allocator` など) を追加する場合は、これもここに追加する必要があります。
// たとえば、`Box` を `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` に変更した場合、この関数も `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` に変更する必要があります。
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # 割り当てエラーハンドラ

extern "Rust" {
    // これは、グローバル割り当てエラーハンドラーを呼び出すための魔法のシンボルです。
    // rustc は、`#[alloc_error_handler]` がある場合は `__rg_oom` を呼び出すために、それ以外の場合は (`__rdl_oom`) より下のデフォルトの実装を呼び出すためにそれを生成します。
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// メモリ割り当てエラーまたは失敗で中止します。
///
/// 割り当てエラーに応答して計算を中止したいメモリ割り当て API の呼び出し元は、`panic!` などを直接呼び出すのではなく、この関数を呼び出すことをお勧めします。
///
///
/// この関数のデフォルトの動作は、メッセージを標準エラーに出力し、プロセスを中止することです。
/// [`set_alloc_error_hook`] および [`take_alloc_error_hook`] と交換できます。
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// 割り当てテストでは、`std::alloc::handle_alloc_error` を直接使用できます。
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // 生成された `__rust_alloc_error_handler` を介して呼び出されます

    // `#[alloc_error_handler]` がない場合
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // `#[alloc_error_handler]` がある場合
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// クローンを事前に割り当てられた初期化されていないメモリに特化します。
/// `Box::clone` および `Rc`/`Arc::make_mut` で使用されます。
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *最初の* を割り当てた場合、オプティマイザはローカルをスキップして移動し、クローン化された値をインプレースで作成できる場合があります。
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ローカル値を使用せずに、いつでもインプレースでコピーできます。
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}