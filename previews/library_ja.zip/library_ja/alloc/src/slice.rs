//! 連続したシーケンスへの動的なサイズのビュー、 `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! スライスは、ポインタと長さとして表されるメモリブロックへのビューです。
//!
//! ```
//! // Vec をスライスする
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // アレイをスライスに強制する
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! スライスは変更可能または共有のいずれかです。
//! 共有スライスタイプは `&[T]` ですが、可変スライスタイプは `&mut [T]` です。ここで、`T` は要素タイプを表します。
//! たとえば、可変スライスが指すメモリブロックを変更できます。
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! このモジュールに含まれるもののいくつかを次に示します。
//!
//! ## Structs
//!
//! スライスの反復を表す [`Iter`] など、スライスに役立つ構造体がいくつかあります。
//!
//! ## Trait の実装
//!
//! スライス用の一般的な traits の実装がいくつかあります。いくつかの例が含まれます:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`]、要素タイプが [`Eq`] または [`Ord`] のスライス用。
//! * [`Hash`] - 要素タイプが [`Hash`] のスライスの場合。
//!
//! ## Iteration
//!
//! スライスは `IntoIterator` を実装します。イテレータは、スライス要素への参照を生成します。
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! 可変スライスは、要素への可変参照を生成します。
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! このイテレータはスライスの要素への可変参照を生成するため、スライスの要素タイプは `i32` ですが、イテレータの要素タイプは `&mut i32` です。
//!
//!
//! * [`.iter`] および [`.iter_mut`] は、デフォルトのイテレーターを返す明示的なメソッドです。
//! * イテレータを返すその他のメソッドは、[`.split`]、[`.splitn`]、[`.chunks`]、[`.windows`] などです。
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// このモジュールでの使用法の多くは、テスト構成でのみ使用されます。
// 修正するよりも、unused_imports 警告をオフにする方がクリーンです。
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// 基本的なスライス拡張方法
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) NB のテスト中に `vec!` マクロを実装するために必要です。詳細については、このファイルの `hack` モジュールを参照してください。
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) NB のテスト中に `Vec::clone` を実装するために必要です。詳細については、このファイルの `hack` モジュールを参照してください。
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) では `impl [T]` は使用できません。これらの 3 つの関数は、実際には `impl [T]` にはあるが、`core::slice::SliceExt` にはないメソッドです。これらの関数は、`test_permutations` テスト用に提供する必要があります。
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // これは主に `vec!` マクロで使用され、パフォーマンスの低下を引き起こすため、これにインライン属性を追加しないでください。
    // ディスカッションとパフォーマンスの結果については、#71204 を参照してください。
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // アイテムは、以下のループで初期化されたとマークされました
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) LLVM が境界チェックを削除するために必要であり、zip よりも優れた codegen を備えています。
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec は、上記で少なくともこの長さに割り当てられ、初期化されました。
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` の容量で上に割り当てられ、下の ptr::copy_to_non_overlapping で `s.len()` に初期化されます。
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// スライスを並べ替えます。
    ///
    /// この並べ替えは安定しており (つまり、等しい要素を並べ替えません)、*O*(*n*\*log(* n*)) 最悪の場合) です。
    ///
    /// 該当する場合、安定したソートよりも一般的に高速であり、補助メモリを割り当てないため、不安定なソートが推奨されます。
    /// [`sort_unstable`](slice::sort_unstable) を参照してください。
    ///
    /// # 現在の実装
    ///
    /// 現在のアルゴリズムは、[timsort](https://en.wikipedia.org/wiki/Timsort) に触発された適応型の反復マージソートです。
    /// スライスがほぼソートされている場合、または 2 つ以上のソートされたシーケンスが次々に連結されている場合に非常に高速になるように設計されています。
    ///
    ///
    /// また、`self` の半分のサイズの一時ストレージを割り当てますが、短いスライスの場合は、代わりに非割り当て挿入ソートが使用されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// コンパレータ機能でスライスをソートします。
    ///
    /// この並べ替えは安定しており (つまり、等しい要素を並べ替えません)、*O*(*n*\*log(* n*)) 最悪の場合) です。
    ///
    /// コンパレータ関数は、スライス内の要素の全順序を定義する必要があります。順序が合計でない場合、要素の順序は指定されていません。
    /// (すべての `a`、`b`、および `c` の場合) 次の場合、注文は全注文です。
    ///
    /// * 合計および非対称: `a < b`、`a == b`、または `a > b` のいずれかが真であり、
    /// * 推移的、`a < b` および `b < c` は `a < c` を意味します。`==` と `>` の両方に同じことが当てはまる必要があります。
    ///
    /// たとえば、[`f64`] は `NaN != NaN` のために [`Ord`] を実装していませんが、スライスに `NaN` が含まれていないことがわかっている場合は、ソート関数として `partial_cmp` を使用できます。
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// 該当する場合、安定したソートよりも一般的に高速であり、補助メモリを割り当てないため、不安定なソートが推奨されます。
    /// [`sort_unstable_by`](slice::sort_unstable_by) を参照してください。
    ///
    /// # 現在の実装
    ///
    /// 現在のアルゴリズムは、[timsort](https://en.wikipedia.org/wiki/Timsort) に触発された適応型の反復マージソートです。
    /// スライスがほぼソートされている場合、または 2 つ以上のソートされたシーケンスが次々に連結されている場合に非常に高速になるように設計されています。
    ///
    /// また、`self` の半分のサイズの一時ストレージを割り当てますが、短いスライスの場合は、代わりに非割り当て挿入ソートが使用されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // 逆ソート
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// キー抽出機能を使用してスライスを並べ替えます。
    ///
    /// この並べ替えは安定しており (つまり、等しい要素を並べ替えません)、*O*(*m*\* * n *\* log(*n*)) ワーストケースで、キー関数は *O*(*m*) です。
    ///
    /// 高価なキー機能 (例:
    /// 単純なプロパティアクセスや基本的な操作ではない関数)、[`sort_by_cached_key`](slice::sort_by_cached_key) は要素キーを再計算しないため、大幅に高速になる可能性があります。
    ///
    ///
    /// 該当する場合、安定したソートよりも一般的に高速であり、補助メモリを割り当てないため、不安定なソートが推奨されます。
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) を参照してください。
    ///
    /// # 現在の実装
    ///
    /// 現在のアルゴリズムは、[timsort](https://en.wikipedia.org/wiki/Timsort) に触発された適応型の反復マージソートです。
    /// スライスがほぼソートされている場合、または 2 つ以上のソートされたシーケンスが次々に連結されている場合に非常に高速になるように設計されています。
    ///
    /// また、`self` の半分のサイズの一時ストレージを割り当てますが、短いスライスの場合は、代わりに非割り当て挿入ソートが使用されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// キー抽出機能を使用してスライスを並べ替えます。
    ///
    /// ソート中、キー関数は要素ごとに 1 回だけ呼び出されます。
    ///
    /// この並べ替えは安定しており (つまり、等しい要素を並べ替えません)、*O*(*m*\* * n *+* n *\* log(*n*)) 最悪の場合、キー関数は *O*(*m*) です。。
    ///
    /// 単純なキー関数 (たとえば、プロパティアクセスまたは基本操作である関数) の場合、[`sort_by_key`](slice::sort_by_key) の方が高速である可能性があります。
    ///
    /// # 現在の実装
    ///
    /// 現在のアルゴリズムは、Orson Peters による [pattern-defeating quicksort][pdqsort] に基づいています。これは、ランダム化されたクイックソートの高速平均ケースとヒープソートの最悪のケースを組み合わせ、特定のパターンのスライスで線形時間を実現します。
    /// 縮退したケースを回避するためにいくつかのランダム化を使用しますが、常に決定論的な動作を提供するために固定された seed を使用します。
    ///
    /// 最悪の場合、アルゴリズムはスライスの長さの `Vec<(K, usize)>` に一時ストレージを割り当てます。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // 割り当てを減らすために、vector を可能な限り最小のタイプでインデックス付けするためのヘルパーマクロ。
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` の要素はインデックスが付けられているため一意であるため、元のスライスに対してどのような種類でも安定します。
                // ここでは `sort_unstable` を使用します。これは、必要なメモリ割り当てが少ないためです。
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` を新しい `Vec` にコピーします。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ここで、`s` と `x` は個別に変更できます。
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` をアロケータ付きの新しい `Vec` にコピーします。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ここで、`s` と `x` は個別に変更できます。
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // 注意: 詳細については、このファイルの `hack` モジュールを参照してください。
        hack::to_vec(self, alloc)
    }

    /// `self` をクローンや割り当てなしで vector に変換します。
    ///
    /// 結果の vector は、`Vec を介してボックスに戻すことができます。<T>` の `into_boxed_slice` メソッド。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` `x` に変換されているため、使用できなくなりました。
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // 注意: 詳細については、このファイルの `hack` モジュールを参照してください。
        hack::into_vec(self)
    }

    /// スライスを `n` 回繰り返すことにより、vector を作成します。
    ///
    /// # Panics
    ///
    /// 容量がオーバーフローした場合、この関数は panic になります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// オーバーフロー時の panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` がゼロより大きい場合は、`n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` として分割できます。
        // `2^expn` は `n` の左端の '1' ビットで表される番号であり、`rem` は `n` の残りの部分です。
        //
        //

        // `Vec` を使用して `set_len()` にアクセスします。
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` 繰り返しは、`buf` の `expn` 回を 2 倍にすることによって行われます。
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` の場合、左端の '1' まで残りのビットがあります。
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` の容量があります。
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` ( `=n、2 ^ expn`) 繰り返しは、`buf` 自体から最初の `rem` 繰り返しをコピーすることによって行われます。
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // これは `2^expn > rem` 以降重複していません。
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` に等しい ( `= self.len() * n`)。
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` のスライスを単一の値 `Self::Output` にフラット化します。
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` のスライスを単一の値 `Self::Output` にフラット化し、それぞれの間に指定されたセパレーターを配置します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` のスライスを単一の値 `Self::Output` にフラット化し、それぞれの間に指定されたセパレーターを配置します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// このスライスのコピーを含む vector を返します。ここで、各バイトは同等の ASCII 大文字にマップされます。
    ///
    ///
    /// ASCII 文字 'a' から 'z' は 'A' から 'Z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を大文字にするには、[`make_ascii_uppercase`] を使用します。
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// このスライスのコピーを含む vector を返します。ここで、各バイトは同等の ASCII 小文字にマップされます。
    ///
    ///
    /// ASCII 文字 'A' から 'Z' は 'a' から 'z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を小文字にするには、[`make_ascii_lowercase`] を使用します。
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// 特定の種類のデータのスライス用の拡張 traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`] (slice::concat) のヘルパー trait。
///
/// Note: `Item` タイプパラメータはこの trait では使用されませんが、impl をより汎用的にすることができます。
/// これがないと、次のエラーが発生します。
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// これは、複数の `T` タイプが適用されるように、複数の `Borrow<[_]>` impl を持つ `V` タイプが存在する可能性があるためです。
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 連結後の結果の型
    type Output;

    /// [`[T]: : concat`] (slice::concat) の実装
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] (slice::join) のヘルパー trait
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// 連結後の結果の型
    type Output;

    /// [`[T]: : join`] (slice::join) の実装
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// スライスの標準 trait 実装
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // 上書きされないものをターゲットにドロップします
        target.truncate(self.len());

        // target.len <= 上記の切り捨てにより、self.len であるため、ここのスライスは常にインバウンドです。
        //
        let (init, tail) = self.split_at(target.len());

        // 含まれている値の allocations/resources を再利用します。
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` を事前にソートされたシーケンス `v[1..]` に挿入して、`v[..]` 全体がソートされるようにします。
///
/// これは挿入ソートの不可欠なサブルーチンです。
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ここに挿入を実装するには、次の 3 つの方法があります。
            //
            // 1. 最初の要素が最終目的地に到達するまで、隣接する要素を交換します。
            //    ただし、この方法では、必要以上にデータをコピーします。
            //    要素が大きな構造である場合 (コピーにコストがかかる)、この方法は遅くなります。
            //
            // 2. 最初の要素の適切な場所が見つかるまで繰り返します。
            // 次に、後続の要素をシフトしてスペースを確保し、最後に残りの穴に配置します。
            // これは良い方法です。
            //
            // 3. 最初の要素を一時変数にコピーします。適切な場所が見つかるまで繰り返します。
            // 進むにつれて、トラバースされたすべての要素をその前のスロットにコピーします。
            // 最後に、一時変数から残りの穴にデータをコピーします。
            // この方法はとても良いです。
            // ベンチマークは、2 番目の方法よりもわずかに優れたパフォーマンスを示しました。
            //
            // すべての方法がベンチマークされ、3 番目が最良の結果を示しました。だから私たちはそれを選びました。
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // 挿入プロセスの中間状態は常に `hole` によって追跡されます。これは、次の 2 つの目的に役立ちます。
            // 1. `is_less` の panics から `v` の整合性を保護します。
            // 2. 最後に `v` の残りの穴を埋めます。
            //
            // Panic の安全性:
            //
            // プロセス中の任意の時点で `is_less` panics が発生すると、`hole` がドロップされ、`v` の穴が `tmp` で埋められるため、`v` は、最初に保持していたすべてのオブジェクトを 1 回だけ保持できます。
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ドロップされるため、`tmp` を `v` の残りの穴にコピーします。
        }
    }

    // ドロップすると、`src` から `dest` にコピーします。
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `buf` を一時ストレージとして使用して、減少しない実行 `v[..mid]` と `v[mid..]` をマージし、結果を `v[..]` に格納します。
///
/// # Safety
///
/// 2 つのスライスは空でない必要があり、`mid` は範囲内にある必要があります。
/// バッファ `buf` は、短いスライスのコピーを保持するのに十分な長さである必要があります。
/// また、`T` はゼロサイズタイプであってはなりません。
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // マージプロセスは、最初に短いランを `buf` にコピーします。
    // 次に、新しくコピーされた実行と長い実行を順方向 (または逆方向) にトレースし、次の未消費要素を比較して、小さい方 (または大きい方) の要素を `v` にコピーします。
    //
    // 短い実行が完全に消費されるとすぐに、プロセスが完了します。長いランが最初に消費される場合は、短いランの残りを `v` の残りの穴にコピーする必要があります。
    //
    // プロセスの中間状態は常に `hole` によって追跡されます。これには、次の 2 つの目的があります。
    // 1. `is_less` の panics から `v` の整合性を保護します。
    // 2. 長いランが最初に消費された場合、`v` の残りの穴を埋めます。
    //
    // Panic の安全性:
    //
    // プロセス中の任意の時点で `is_less` panics が発生すると、`hole` がドロップされ、`v` の穴が `buf` の未消費範囲で埋められるため、`v` は最初に保持していたすべてのオブジェクトを 1 回だけ保持できます。
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // 左のランは短くなります。
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // 最初、これらのポインターは配列の先頭を指します。
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // 少ない側を消費します。
            // 等しい場合は、安定性を維持するために左の実行を優先します。
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // 正しい実行はより短いです。
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // 最初、これらのポインターは配列の終わりを超えて指します。
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // 大きい方を消費します。
            // 等しい場合は、安定性を維持するために適切な実行を優先します。
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // 最後に、`hole` がドロップされます。
    // 短いランが完全に消費されなかった場合、残りのランはすべて `v` の穴にコピーされます。

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ドロップすると、範囲 `start..end` を `dest..` にコピーします。
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ゼロサイズタイプではないので、サイズで割っても大丈夫です。
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// このマージソートは、[here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) で詳細に説明されている TimSort からいくつかの (すべてではない) アイデアを借用しています。
///
///
/// アルゴリズムは、自然実行と呼ばれる厳密に降順および非降順のサブシーケンスを識別します。まだマージされていない保留中の実行のスタックがあります。
/// 新しく見つかった各実行はスタックにプッシュされ、次に、これら 2 つの不変条件が満たされるまで、隣接する実行のいくつかのペアがマージされます。
///
/// 1. `1..runs.len()` のすべての `i` に対して: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()` のすべての `i` に対して: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// 不変条件により、合計実行時間が *O*(*n*\*log(* n*)) 最悪の場合) になります。
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // この長さまでのスライスは、挿入ソートを使用してソートされます。
    const MAX_INSERTION: usize = 20;
    // 挿入ソートを使用して非常に短い実行が拡張され、少なくともこの数の要素にまたがります。
    const MIN_RUN: usize = 10;

    // サイズがゼロの型では、並べ替えは意味のある動作をしません。
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // 短い配列は、割り当てを回避するために挿入ソートを介してインプレースでソートされます。
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // スクラッチメモリとして使用するバッファを割り当てます。`is_less` panics の場合、コピーで実行される dtor のリスクを冒すことなく、`v` のコンテンツの浅いコピーを保持できるように、長さ 0 を保持します。
    //
    // ソートされた 2 つの実行をマージする場合、このバッファーは短い実行のコピーを保持します。これは常に最大 `len / 2` の長さになります。
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` での自然な実行を識別するために、それを逆方向にトラバースします。
    // これは奇妙な決定のように思えるかもしれませんが、マージが (forwards) の反対方向に進むことが多いという事実を考慮してください。
    // ベンチマークによると、前方へのマージは後方へのマージよりもわずかに高速です。
    // 結論として、後方にトラバースすることによって実行を識別すると、パフォーマンスが向上します。
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // 次の自然な走りを見つけて、それが厳密に下降している場合はそれを逆にします。
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // 短すぎる場合は、実行にさらにいくつかの要素を挿入します。
        // 挿入ソートは短いシーケンスでのマージソートよりも高速であるため、パフォーマンスが大幅に向上します。
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // この実行をスタックにプッシュします。
        runs.push(Run { start, len: end - start });
        end = start;

        // 不変条件を満たすために、隣接する実行のいくつかのペアをマージします。
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // 最後に、スタックには 1 回だけ実行する必要があります。
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // 実行のスタックを調べて、マージする次の実行のペアを識別します。
    // より具体的には、`Some(r)` が返された場合、`runs[r]` と `runs[r + 1]` を次にマージする必要があることを意味します。
    // 代わりにアルゴリズムが新しい実行の構築を続行する必要がある場合は、`None` が返されます。
    //
    // TimSort は、ここで説明するように、バグのある実装で有名です。
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ストーリーの要点は、スタックの上位 4 つの実行で不変条件を適用する必要があるということです。
    // 上位 3 つだけにそれらを適用するだけでは、スタック内の *すべての* 実行に対して不変条件が保持されることを保証するのに十分ではありません。
    //
    // この関数は、上位 4 つの実行の不変条件を正しくチェックします。
    // さらに、トップランがインデックス 0 から始まる場合、ソートを完了するために、スタックが完全に折りたたまれるまで、常にマージ操作が必要になります。
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}