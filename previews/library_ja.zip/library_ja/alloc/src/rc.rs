//! シングルスレッドの参照カウントポインタ。'Rc' は ' リファレンスの略です
//! Counted'.
//!
//! タイプ [`Rc<T>`][`Rc`] は、ヒープに割り当てられたタイプ `T` の値の共有所有権を提供します。
//! [`Rc`] で [`clone`][clone] を呼び出すと、ヒープ内の同じ割り当てへの新しいポインターが生成されます。
//! 特定の割り当てへの最後の [`Rc`] ポインターが破棄されると、その割り当てに格納されている値 ("inner value" と呼ばれることもあります) も削除されます。
//!
//! Rust の共有参照はデフォルトで変更を許可しません。また、[`Rc`] も例外ではありません。通常、[`Rc`] 内の何かへの変更可能な参照を取得することはできません。
//! 可変性が必要な場合は、[`Cell`] または [`RefCell`] を [`Rc`] 内に配置します。[an example of mutability inside an `Rc`][mutability] を参照してください。
//!
//! [`Rc`] 非アトミック参照カウントを使用します。
//! これは、オーバーヘッドが非常に低いことを意味しますが、[`Rc`] をスレッド間で送信できないため、[`Rc`] は [`Send`][send] を実装しません。
//! その結果、Rust コンパイラは、スレッド間で [`Rc`] を送信していないことを *コンパイル時に* チェックします。
//! マルチスレッドのアトミック参照カウントが必要な場合は、[`sync::Arc`][arc] を使用してください。
//!
//! [`downgrade`][downgrade] メソッドを使用して、所有していない [`Weak`] ポインターを作成できます。
//! [`Weak`] ポインタを [`Rc`] に [`upgrade`][upgrade] することができますが、割り当てに格納されている値がすでに削除されている場合、これは [`None`] を返します。
//! 言い換えると、`Weak` ポインターは、割り当て内の値を存続させません。ただし、割り当て (内部値のバッキングストア) は存続します。
//!
//! [`Rc`] ポインター間のサイクルが割り当て解除されることはありません。
//! このため、[`Weak`] はサイクルを中断するために使用されます。
//! たとえば、ツリーには、親ノードから子への強力な [`Rc`] ポインターと、子から親に戻る [`Weak`] ポインターを含めることができます。
//!
//! `Rc<T>` ([`Deref`] trait を介して) `T` を自動的に逆参照するため、タイプ [`Rc<T>`][`Rc`] の値で `T` のメソッドを呼び出すことができます。
//! `T` のメソッドとの名前の衝突を避けるために、[`Rc<T>`][`Rc`] 自体のメソッドは、[fully qualified syntax] を使用して呼び出される関連関数です。
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` のような traits の` の実装は、完全修飾構文を使用して呼び出すこともできます。
//! 完全修飾構文を使用することを好む人もいれば、メソッド呼び出し構文を使用することを好む人もいます。
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // メソッド呼び出し構文
//! let rc2 = rc.clone();
//! // 完全修飾構文
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] 内部値がすでに削除されている可能性があるため、`T` への自動逆参照は行われません。
//!
//! # クローニングリファレンス
//!
//! [`Rc<T>`][`Rc`] および [`Weak<T>`][`Weak`] に実装された `Clone` trait を使用して、既存の参照カウントポインターと同じ割り当てへの新しい参照を作成します。
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // 以下の 2 つの構文は同等です。
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a と b はどちらも foo と同じメモリ位置を指しています。
//! ```
//!
//! `Rc::clone(&from)` 構文は、コードの意味をより明確に伝えるため、最も慣用的なものです。
//! 上記の例では、この構文により、foo のコンテンツ全体をコピーするのではなく、このコードが新しい参照を作成していることが簡単にわかります。
//!
//! # Examples
//!
//! 一連の「ガジェット」が特定の `Owner` によって所有されているシナリオを考えてみます。
//! `ガジェット` が `Owner` を指すようにします。複数のガジェットが同じ `Owner` に属している可能性があるため、一意の所有権でこれを行うことはできません。
//! [`Rc`] 複数の「ガジェット」間で `Owner` を共有し、`Gadget` がポイントしている限り `Owner` を割り当てたままにすることができます。
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... その他のフィールド
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... その他のフィールド
//! }
//!
//! fn main() {
//!     // 参照カウントされた `Owner` を作成します。
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` に属する `ガジェット` を作成します。
//!     // `Rc<Owner>` のクローンを作成すると、同じ `Owner` 割り当てへの新しいポインターが得られ、プロセスの参照カウントが増加します。
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // ローカル変数 `gadget_owner` を破棄します。
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` を削除しても、「ガジェット」の `Owner` の名前を印刷することはできます。
//!     // これは、それが指す `Owner` ではなく、単一の `Rc<Owner>` のみをドロップしたためです。
//!     // 同じ `Owner` 割り当てを指している他の `Rc<Owner>` がある限り、それはライブのままになります。
//!     // `Rc<Owner>` は自動的に `Owner` を逆参照するため、フィールドプロジェクション `gadget1.owner.name` は機能します。
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // 関数の最後に、`gadget1` と `gadget2` が破棄され、最後にカウントされた `Owner` への参照が破棄されます。
//!     // ガジェットマンも破壊されるようになりました。
//!     //
//! }
//! ```
//!
//! 要件が変更され、`Owner` から `Gadget` にトラバースできるようにする必要がある場合、問題が発生します。
//! `Owner` から `Gadget` への [`Rc`] ポインターは、サイクルを導入します。
//! これは、参照カウントが 0 に達することはなく、割り当てが破棄されることはないことを意味します。
//! メモリリーク。これを回避するために、[`Weak`] ポインターを使用できます。
//!
//! Rust は、実際には、そもそもこのループを生成することをいくらか困難にします。お互いを指す 2 つの値で終わるためには、それらの 1 つが可変である必要があります。
//! [`Rc`] は、ラップする値への共有参照のみを提供することでメモリの安全性を強化し、これらは直接の変更を許可しないため、これは困難です。
//! 変更する値の一部を [`RefCell`] でラップする必要があります。これにより、*内部変更可能性* が提供されます。これは、共有参照を通じて変更可能性を実現する方法です。
//! [`RefCell`] 実行時に Rust の借用ルールを適用します。
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... その他のフィールド
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... その他のフィールド
//! }
//!
//! fn main() {
//!     // 参照カウントされた `Owner` を作成します。
//!     // 共有参照を介して変更できるように、「ガジェット」の「所有者」の vector を `RefCell` 内に配置していることに注意してください。
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // 前と同じように、`gadget_owner` に属する `ガジェット` を作成します。
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `Owner` に「ガジェット」を追加します。
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` 動的借入はここで終了します。
//!     }
//!
//!     // `ガジェット` を繰り返し、詳細を印刷します。
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` です。
//!         // `Weak` ポインターは割り当てがまだ存在することを保証できないため、`Option<Rc<Gadget>>` を返す `upgrade` を呼び出す必要があります。
//!         //
//!         //
//!         // この場合、割り当てがまだ存在していることがわかっているので、単に `unwrap` `Option` にします。
//!         // より複雑なプログラムでは、`None` の結果に対して適切なエラー処理が必要になる場合があります。
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // 関数の終了時に、`gadget_owner`、`gadget1`、および `gadget2` が破棄されます。
//!     // ガジェットへの強力な (`Rc`) ポインターがないため、ガジェットは破棄されます。
//!     // これにより、ガジェットマンの参照カウントがゼロになるため、ガジェットマンも破壊されます。
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// これは repr(C) から future であり、フィールドの並べ替えの可能性に対して耐性があります。これにより、変換可能な内部タイプの安全な [into|from]_raw() が妨害されます。
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// シングルスレッドの参照カウントポインタ。'Rc' は ' リファレンスの略です
/// Counted'.
///
/// 詳細については、[module-level documentation](./index.html) を参照してください。
///
/// `Rc` の固有のメソッドはすべて関連する関数です。つまり、`value.get_mut()` ではなく [`Rc::get_mut(&mut value)`][get_mut] などとして呼び出す必要があります。
/// これにより、内部タイプ `T` のメソッドとの競合が回避されます。
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // この Rc が生きている間、内部ポインタが有効であることが保証されているため、この安全性は問題ありません。
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// 新しい `Rc<T>` を構築します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // すべてのストロングポインタが所有する暗黙のウィークポインタがあります。これにより、ウィークポインタがストロングポインタ内に格納されている場合でも、ストロングデストラクタの実行中にウィークデストラクタが割り当てを解放することはありません。
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// 自身への弱参照を使用して新しい `Rc<T>` を構築します。
    /// この関数が戻る前に弱参照をアップグレードしようとすると、`None` 値になります。
    ///
    /// ただし、弱参照は自由に複製され、後で使用するために保存される場合があります。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... その他のフィールド
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // 単一の弱参照を使用して、"uninitialized" 状態で内部を構築します。
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // 弱いポインタの所有権を放棄しないことが重要です。そうしないと、`data_fn` が戻るまでにメモリが解放される可能性があります。
        // 本当に所有権を譲渡したい場合は、自分自身に追加の弱ポインターを作成できますが、これにより、弱参照カウントが追加で更新され、それ以外の場合は必要ない場合があります。
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // 強い参照は共有された弱い参照を集合的に所有する必要があるため、古い弱い参照に対してデストラクタを実行しないでください。
        //
        mem::forget(weak);
        strong
    }

    /// 初期化されていない内容で新しい `Rc` を構築します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 初期化されていない内容で新しい `Rc` を構築し、メモリは `0` バイトで満たされます。
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// 新しい `Rc<T>` を構築し、割り当てが失敗した場合にエラーを返します
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // すべてのストロングポインタが所有する暗黙のウィークポインタがあります。これにより、ウィークポインタがストロングポインタ内に格納されている場合でも、ストロングデストラクタの実行中にウィークデストラクタが割り当てを解放することはありません。
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// 初期化されていない内容で新しい `Rc` を構築し、割り当てが失敗した場合はエラーを返します
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// 初期化されていない内容で新しい `Rc` を構築し、メモリは `0` バイトで満たされ、割り当てが失敗した場合はエラーを返します
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// 新しい `Pin<Rc<T>>` を構築します。
    /// `T` が `Unpin` を実装していない場合、`value` はメモリに固定され、移動できなくなります。
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc` に厳密な参照が 1 つしかない場合は、内部値を返します。
    ///
    /// それ以外の場合、[`Err`] は、渡されたのと同じ `Rc` で返されます。
    ///
    ///
    /// これは、顕著な弱い参照がある場合でも成功します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // 含まれているオブジェクトをコピーします

                // ウィークに、ストロングカウントをデクリメントしてプロモートできないことを示し、偽のウィークを作成するだけでドロップロジックを処理しながら、暗黙の "strong weak" ポインターを削除します。
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// 初期化されていないコンテンツを使用して、参照カウントされた新しいスライスを作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 遅延初期化:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// メモリが `0` バイトで満たされている状態で、初期化されていない内容で新しい参照カウントスライスを構築します。
    ///
    ///
    /// このメソッドの正しい使用法と誤った使用法の例については、[`MaybeUninit::zeroed`][zeroed] を参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` に変換します。
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] と同様に、内部値が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、すぐに未定義の動作が発生します。
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // 遅延初期化:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` に変換します。
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] と同様に、内部値が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、すぐに未定義の動作が発生します。
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // 遅延初期化:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` を消費し、ラップされたポインターを返します。
    ///
    /// メモリリークを回避するには、[`Rc::from_raw`][from_raw] を使用してポインタを `Rc` に戻す必要があります。
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// データへの生のポインタを提供します。
    ///
    /// カウントはまったく影響を受けず、`Rc` は消費されません。
    /// `Rc` に強いカウントがある限り、ポインターは有効です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // 安全性: これは Deref::deref または Rc::inner を通過できません。
        // これは、raw/mut の出所を保持するために必要です。
        // `get_mut` Rc が `from_raw` を介して回復された後、ポインタを介して書き込むことができます。
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// 生のポインタから `Rc<T>` を構築します。
    ///
    /// 生のポインタは、[`Rc<U>::into_raw`][into_raw] の呼び出しによって以前に返されている必要があります。ここで、`U` は `T` と同じサイズと配置である必要があります。
    /// `U` が `T` の場合、これは簡単に当てはまります。
    /// `U` が `T` ではなく、同じサイズと配置である場合、これは基本的に、異なるタイプの参照を変換するようなものであることに注意してください。
    /// この場合に適用される制限の詳細については、[`mem::transmute`][transmute] を参照してください。
    ///
    /// `from_raw` のユーザーは、`T` の特定の値が 1 回だけドロップされることを確認する必要があります。
    ///
    /// 返された `Rc<T>` にアクセスしなくても、不適切に使用するとメモリが安全でなくなる可能性があるため、この関数は安全ではありません。
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // 漏れを防ぐために `Rc` に戻します。
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` をさらに呼び出すと、メモリが安全ではなくなります。
    /// }
    ///
    /// // `x` が上記のスコープから外れたときにメモリが解放されたため、`x_ptr` がぶら下がっています。
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // オフセットを逆にして、元の RcBox を見つけます。
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// この割り当てへの新しい [`Weak`] ポインタを作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ぶら下がっている弱点を作成しないようにしてください
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// この割り当てへの [`Weak`] ポインターの数を取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// この割り当てへの強力な (`Rc`) ポインターの数を取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// この割り当てへの他の `Rc` または [`Weak`] ポインターがない場合、`true` を返します。
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// 同じ割り当てへの他の `Rc` または [`Weak`] ポインターがない場合、指定された `Rc` への可変参照を返します。
    ///
    ///
    /// それ以外の場合は、共有値を変更するのは安全ではないため、[`None`] を返します。
    ///
    /// [`make_mut`][make_mut] も参照してください。これは、他のポインターがある場合に内部値を [`clone`][clone] します。
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// チェックなしで、指定された `Rc` への可変参照を返します。
    ///
    /// 安全で適切なチェックを行う [`get_mut`] も参照してください。
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// 同じ割り当てへの他の `Rc` または [`Weak`] ポインターは、返された借用の期間中、逆参照されてはなりません。
    ///
    /// これは、たとえば `Rc::new` の直後など、そのようなポインタが存在しない場合は簡単に当てはまります。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" フィールドをカバーする参照を作成しないように注意してください。これは、参照カウントへのアクセスと競合するためです (例:
        // `Weak` による)。
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// 2 つの `Rc` が同じ割り当てを指している場合 ([`ptr::eq`] と同様に)、`true` を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// 指定された `Rc` への可変参照を作成します。
    ///
    /// 同じ割り当てへの他の `Rc` ポインターがある場合、`make_mut` は、一意の所有権を確保するために、新しい割り当てへの内部値を [`clone`] します。
    /// これは、クローンオンライトとも呼ばれます。
    ///
    /// この割り当てへの他の `Rc` ポインターがない場合、この割り当てへの [`Weak`] ポインターは関連付けが解除されます。
    ///
    /// [`get_mut`] も参照してください。これは、クローンではなく失敗します。
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // 何も複製しません
    /// let mut other_data = Rc::clone(&data);    // 内部データのクローンを作成しません
    /// *Rc::make_mut(&mut data) += 1;        // クローン内部データ
    /// *Rc::make_mut(&mut data) += 1;        // 何も複製しません
    /// *Rc::make_mut(&mut other_data) *= 2;  // 何も複製しません
    ///
    /// // これで、`data` と `other_data` は異なる割り当てを指します。
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ポインタの関連付けが解除されます:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // データのクローンを作成する必要があります。他の Rc があります。
            // 複製された値を直接書き込むことができるように、メモリを事前に割り当てます。
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // データを盗むことができます、残っているのは弱点だけです
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // 暗黙の強弱参照を削除します (ここで偽の弱を作成する必要はありません - 他の弱がクリーンアップできることはわかっています)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // 返されるポインタは、T に返される *唯一の* ポインタであることが保証されているため、この安全性は問題ありません。
        // この時点で参照カウントは 1 であることが保証されており、`Rc<T>` 自体が `mut` である必要があるため、割り当てへの唯一の可能な参照を返します。
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` を具象型にダウンキャストしてみてください。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// 値にレイアウトが指定されている場合に、サイズ変更されていない可能性のある内部値に十分なスペースを備えた `RcBox<T>` を割り当てます。
    ///
    /// 関数 `mem_to_rcbox` は、データポインターを使用して呼び出され、`RcBox<T>` の (潜在的に太い) ポインターを返す必要があります。
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // 指定された値のレイアウトを使用してレイアウトを計算します。
        // 以前は、レイアウトは式 `&*(ptr as* const RcBox<T>)` で計算されていましたが、これにより参照がずれてしまいました (#54908 を参照)。
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// 値にレイアウトが指定されている、サイズが変更されていない可能性のある内部値に十分なスペースを備えた `RcBox<T>` を割り当て、割り当てが失敗した場合はエラーを返します。
    ///
    ///
    /// 関数 `mem_to_rcbox` は、データポインターを使用して呼び出され、`RcBox<T>` の (潜在的に太い) ポインターを返す必要があります。
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // 指定された値のレイアウトを使用してレイアウトを計算します。
        // 以前は、レイアウトは式 `&*(ptr as* const RcBox<T>)` で計算されていましたが、これにより参照がずれてしまいました (#54908 を参照)。
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // レイアウトに割り当てます。
        let ptr = allocate(layout)?;

        // RcBox を初期化します
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// サイズ変更されていない内部値に十分なスペースを持つ `RcBox<T>` を割り当てます
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // 指定された値を使用して `RcBox<T>` に割り当てます。
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // 値をバイトとしてコピー
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // 内容を削除せずに割り当てを解放します
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// 指定された長さの `RcBox<[T]>` を割り当てます。
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// スライスから新しく割り当てられた Rc <\[T\]> に要素をコピーします
    ///
    /// 呼び出し元が所有権を取得するか、`T: Copy` をバインドする必要があるため、安全ではありません
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// 特定のサイズであることがわかっているイテレータから `Rc<[T]>` を構築します。
    ///
    /// サイズが間違っている場合の動作は未定義です。
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // T 要素のクローン作成中の Panic ガード。
        // panic の場合、新しい RcBox に書き込まれた要素は削除され、メモリが解放されます。
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // 最初の要素へのポインタ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // すべて明確です。新しい RcBox が解放されないように、ガードを忘れてください。
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` に使用される特殊化 trait。
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` をドロップします。
    ///
    /// これにより、強い参照カウントが減少します。
    /// 強い参照カウントがゼロに達した場合、他の参照 (存在する場合) は [`Weak`] のみであるため、内部値を `drop` します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // 何も印刷しません
    /// drop(foo2);   // "dropped!" を印刷します
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // 含まれているオブジェクトを破壊する
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // 内容を破棄したので、暗黙の "strong weak" ポインタを削除します。
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` ポインタのクローンを作成します。
    ///
    /// これにより、同じ割り当てへの別のポインタが作成され、強力な参照カウントが増加します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T` の `Default` 値を使用して、新しい `Rc<T>` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` にはメソッドがありますが、`Eq` に特化できるようにするためのハック。
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// `&T` でのより一般的な最適化としてではなく、ここでこの特殊化を行っています。そうしないと、参照のすべての等価性チェックにコストがかかるためです。
/// `Rc` は、複製に時間がかかるが、等しいかどうかをチェックするのに重い大きな値を格納するために使用されると想定しているため、このコストをより簡単に回収できます。
///
/// また、2 つの `＆T` よりも、同じ値を指す 2 つの `Rc` クローンが存在する可能性が高くなります。
///
/// `PartialEq` としての `T: Eq` が意図的に無反射である可能性がある場合にのみ、これを行うことができます。
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// 2 つの `Rc` の等式。
    ///
    /// 2 つの `Rc` は、それらが異なる割り当てで格納されている場合でも、それらの内部値が等しい場合は等しくなります。
    ///
    /// `T` が `Eq` (等式の再帰性を意味する) も実装している場合、同じ割り当てを指す 2 つの `Rc` は常に等しくなります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// 2 つの `Rc` の不等式。
    ///
    /// 2 つの `Rc` は、それらの内部値が等しくない場合、等しくありません。
    ///
    /// `T` が `Eq` (等式の再帰性を意味する) も実装している場合、同じ割り当てを指す 2 つの `Rc` が等しくなることはありません。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// 2 つの `Rc` の部分的な比較。
    ///
    /// 2 つは、内部値で `partial_cmp()` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// 2 つの `Rc` の比較より少ない。
    ///
    /// 2 つは、内部値で `<` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 2 つの `Rc` の「以下」の比較。
    ///
    /// 2 つは、内部値で `<=` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// 2 つの `Rc` の比較よりも大きい。
    ///
    /// 2 つは、内部値で `>` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 2 つの `Rc` の「以上」の比較。
    ///
    /// 2 つは、内部値で `>=` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// 2 つの `Rc` の比較。
    ///
    /// 2 つは、内部値で `cmp()` を呼び出すことによって比較されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// 参照カウントされたスライスを割り当て、`v` のアイテムを複製して埋めます。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// 参照カウントされた文字列スライスを割り当て、`v` をそのスライスにコピーします。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// 参照カウントされた文字列スライスを割り当て、`v` をそのスライスにコピーします。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ボックス化されたオブジェクトを、参照カウントされた新しい割り当てに移動します。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// 参照カウントされたスライスを割り当て、`v` のアイテムをその中に移動します。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vec がメモリを解放できるようにしますが、内容を破壊しないでください
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` の各要素を取得し、`Rc<[T]>` に収集します。
    ///
    /// # 性能特性
    ///
    /// ## 一般的なケース
    ///
    /// 一般的なケースでは、`Rc<[T]>` への収集は、最初に `Vec<T>` への収集によって行われます。つまり、次のように書くとき:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// これは、次のように動作します。
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // 割り当ての最初のセットはここで発生します。
    ///     .into(); // `Rc<[T]>` の 2 番目の割り当てはここで行われます。
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// これにより、`Vec<T>` を構築するために必要な回数だけ割り当てられ、次に `Vec<T>` を `Rc<[T]>` に変換するために 1 回割り当てられます。
    ///
    ///
    /// ## 既知の長さのイテレータ
    ///
    /// `Iterator` が `TrustedLen` を実装し、正確なサイズである場合、`Rc<[T]>` に対して単一の割り当てが行われます。例えば:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // ここでは、1 つの割り当てのみが発生します。
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` への収集に使用される特殊化 trait。
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // これは、`TrustedLen` イテレータの場合です。
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // 安全性: イテレータの長さが正確であることを確認する必要があります。
                Rc::from_iter_exact(self, low)
            }
        } else {
            // 通常の実装にフォールバックします。
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` は、管理対象割り当てへの非所有参照を保持する [`Rc`] のバージョンです。割り当てにアクセスするには、`Weak` ポインタで [`upgrade`] を呼び出します。これにより、[`Option`]`<`[`Rc`] `が返されます。<T>>`。
///
/// `Weak` 参照は所有権にカウントされないため、割り当てに格納されている値が削除されるのを防ぐことはできません。また、`Weak` 自体は、値がまだ存在することを保証しません。
/// したがって、[`upgrade`] d のときに [`None`] を返す場合があります。
/// ただし、`Weak` 参照は、割り当て自体 (バッキングストア) の割り当て解除を *防止* することに注意してください。
///
/// `Weak` ポインターは、内部値がドロップされるのを防ぐことなく、[`Rc`] によって管理される割り当てへの一時的な参照を保持するのに役立ちます。
/// また、相互に所有する参照によって [`Rc`] がドロップされることは決してないため、[`Rc`] ポインター間の循環参照を防ぐためにも使用されます。
/// たとえば、ツリーには、親ノードから子への強力な [`Rc`] ポインターと、子から親に戻る `Weak` ポインターを含めることができます。
///
/// `Weak` ポインターを取得する一般的な方法は、[`Rc::downgrade`] を呼び出すことです。
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // これは、列挙型でこのタイプのサイズを最適化できるようにする `NonNull` ですが、必ずしも有効なポインターであるとは限りません。
    //
    // `Weak::new` これを `usize::MAX` に設定して、ヒープにスペースを割り当てる必要がないようにします。
    // RcBox には少なくとも 2 の配置があるため、これは実際のポインターが持つ値ではありません。
    // これは、`T: Sized` の場合にのみ可能です。サイズのない `T` がぶら下がることはありません。
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// メモリを割り当てずに、新しい `Weak<T>` を構築します。
    /// 戻り値で [`upgrade`] を呼び出すと、常に [`None`] が得られます。
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// データフィールドについてアサーションを作成せずに参照カウントにアクセスできるようにするヘルパータイプ。
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// この `Weak<T>` が指すオブジェクト `T` への生のポインタを返します。
    ///
    /// ポインタは、強い参照がある場合にのみ有効です。
    /// ポインタがぶら下がっている、位置が合っていない、または [`null`] である可能性があります。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // 両方が同じオブジェクトを指しています
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ここの強いものはそれを生かし続けるので、私たちはまだオブジェクトにアクセスすることができます。
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // もうそうじゃない。
    /// // weak.as_ptr() を実行できますが、ポインターにアクセスすると、未定義の動作が発生します。
    /// // assert_eq! ( "hello"、unsafe {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ポインタがぶら下がっている場合は、番兵を直接返します。
            // ペイロードは少なくとも RcBox (usize) と同じように整列されているため、これを有効なペイロードアドレスにすることはできません。
            ptr as *const T
        } else {
            // 安全性: is_dangling が false を返す場合、ポインターは参照解除可能です。
            // ペイロードはこの時点でドロップされる可能性があり、来歴を維持する必要があるため、生のポインター操作を使用します。
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` を消費し、生のポインターに変換します。
    ///
    /// これにより、1 つの弱参照の所有権を保持したまま、弱ポインターが生のポインターに変換されます (弱カウントはこの操作によって変更されません)。
    /// [`from_raw`] で `Weak<T>` に戻すことができます。
    ///
    /// [`as_ptr`] の場合と同じように、ポインタのターゲットにアクセスする際の制限が適用されます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// 以前に [`into_raw`] によって作成された生のポインターを `Weak<T>` に変換し直します。
    ///
    /// これは、強力な参照を安全に取得するため (後で [`upgrade`] を呼び出すことによって)、または `Weak<T>` を削除することによって弱いカウントの割り当てを解除するために使用できます。
    ///
    /// 1 つの弱参照の所有権を取得します ([`new`] によって作成されたポインターを除いて、これらは何も所有していません。メソッドは引き続きそれらに対して機能します)。
    ///
    /// # Safety
    ///
    /// ポインターは [`into_raw`] から発信されている必要があり、潜在的な弱参照を所有している必要があります。
    ///
    /// これを呼び出すときに、ストロングカウントを 0 にすることができます。
    /// それにもかかわらず、これは現在 raw ポインターとして表されている 1 つの弱参照の所有権を取得します (弱カウントはこの操作によって変更されません)。したがって、[`into_raw`] への以前の呼び出しとペアにする必要があります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // 最後の弱いカウントをデクリメントします。
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // 入力ポインターの導出方法のコンテキストについては、Weak::as_ptr を参照してください。

        let ptr = if is_dangling(ptr as *mut T) {
            // これはぶら下がっている弱点です。
            ptr as *mut RcBox<T>
        } else {
            // それ以外の場合は、ポインタがぶら下がっていない弱点からのものであることが保証されます。
            // 安全性: ptr は実際の (ドロップされる可能性のある) T を参照するため、data_offset を安全に呼び出すことができます。
            let offset = unsafe { data_offset(ptr) };
            // したがって、オフセットを逆にして RcBox 全体を取得します。
            // 安全性: ポインターは弱点から発生したため、このオフセットは安全です。
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // 安全性: 元のウィークポインタを復元したので、ウィークを作成できます。
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` ポインターを [`Rc`] にアップグレードしようとし、成功した場合は内部値のドロップを遅らせます。
    ///
    ///
    /// 内部値が削除された場合は、[`None`] を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // すべての強力なポインタを破壊します。
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// この割り当てを指す強力な (`Rc`) ポインターの数を取得します。
    ///
    /// `self` が [`Weak::new`] を使用して作成された場合、これは 0 を返します。
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// この割り当てを指す `Weak` ポインターの数を取得します。
    ///
    /// 強いポインタが残っていない場合、これはゼロを返します。
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // 暗黙の弱い ptr を引く
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// ポインタがぶら下がっていて、割り当てられた `RcBox` がない場合 (つまり、この `Weak` が `Weak::new` によって作成された場合) に `None` を返します。
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // "data" フィールドは同時に変更される可能性があるため、"data" フィールドをカバーする参照を作成しないように注意してください (たとえば、最後の `Rc` が削除された場合、データフィールドはその場で削除されます)。
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// 2 つの `Weak` が同じ割り当てを指している場合 ([`ptr::eq`] と同様)、または両方が割り当てを指していない場合 (`Weak::new()`) で作成されているため)、`true` を返します。
    ///
    ///
    /// # Notes
    ///
    /// これはポインタを比較するため、割り当てを指していない場合でも、`Weak::new()` は互いに等しくなることを意味します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` の比較。
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` ポインタをドロップします。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // 何も印刷しません
    /// drop(foo);        // "dropped!" を印刷します
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // 弱いカウントは 1 から始まり、すべての強いポインターが消えた場合にのみゼロになります。
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// 同じ割り当てを指す `Weak` ポインターのクローンを作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// 新しい `Weak<T>` を構築し、初期化せずに `T` にメモリを割り当てます。
    /// 戻り値で [`upgrade`] を呼び出すと、常に [`None`] が得られます。
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget を安全に処理するために、ここで checked_add を実行しました。特に
// mem::forget Rcs (または Weaks) の場合、ref-count がオーバーフローする可能性があり、未処理の Rcs (または Weaks) が存在する間に割り当てを解放できます。
//
// これは非常に退化したシナリオであり、何が起こるかを気にしないため、中止します。実際のプログラムでこれが発生することはありません。
//
// 所有権と移動セマンティクスのおかげで、Rust で実際にこれらのクローンを作成する必要がないため、これによるオーバーヘッドはごくわずかです。
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // 値を削除するのではなく、オーバーフロー時に中止したいと思います。
        // これが呼び出されたときに、参照カウントがゼロになることはありません。
        // それでも、ここにアボートを挿入して、LLVM に最適化を見逃したことを示唆します。
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // 値を削除するのではなく、オーバーフロー時に中止したいと思います。
        // これが呼び出されたときに、参照カウントがゼロになることはありません。
        // それでも、ここにアボートを挿入して、LLVM に最適化を見逃したことを示唆します。
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ポインターの背後にあるペイロードの `RcBox` 内のオフセットを取得します。
///
/// # Safety
///
/// ポインターは、以前に有効だった T のインスタンスを指している (そして有効なメタデータを持っている) 必要がありますが、T は削除できます。
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // サイズ変更されていない値を RcBox の最後に揃えます。
    // RcBox は repr(C) であるため、常にメモリ内の最後のフィールドになります。
    // 安全性: サイズ変更されていないタイプはスライス、trait オブジェクトのみであるため、
    // および extern タイプの場合、入力安全要件は現在、align_of_val_raw の要件を満たすのに十分です。これは、std の外部では信頼できない可能性のある言語の実装の詳細です。
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}