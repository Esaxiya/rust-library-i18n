//! 割り当て Prelude
//!
//! このモジュールの目的は、モジュールの先頭に glob インポートを追加することにより、`alloc` crate の一般的に使用されるアイテムのインポートを軽減することです。
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;