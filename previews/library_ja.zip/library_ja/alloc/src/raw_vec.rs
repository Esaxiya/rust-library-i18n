#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// 新しいメモリの内容は初期化されていません。
    Uninitialized,
    /// 新しいメモリはゼロになることが保証されています。
    Zeroed,
}

/// 関係するすべてのコーナーケースを心配することなく、ヒープ上のメモリのバッファをより人間工学的に割り当て、再割り当て、および割り当て解除するための低レベルのユーティリティ。
///
/// このタイプは、Vec や VecDeque などの独自のデータ構造を構築するのに最適です。
/// 特に:
///
/// * ゼロサイズタイプで `Unique::dangling()` を生成します。
/// * 長さゼロの割り当てで `Unique::dangling()` を生成します。
/// * `Unique::dangling()` の解放を回避します。
/// * 容量計算ですべてのオーバーフローをキャッチします ("capacity overflow" panics にプロモートします)。
/// * isize::MAX バイトを超える割り当てを行う 32 ビットシステムから保護します。
/// * あなたの長さがあふれるのを防ぎます。
/// * フォールブル割り当てのために `handle_alloc_error` を呼び出します。
/// * `ptr::Unique` が含まれているため、関連するすべての利点をユーザーに提供します。
/// * アロケータから返された超過分を使用して、使用可能な最大容量を使用します。
///
/// このタイプは、管理するメモリを検査しません。ドロップすると、メモリは解放されますが、コンテンツをドロップしようとはしません。
/// `RawVec` 内に *保存* されている実際のものを処理するのは `RawVec` のユーザー次第です。
///
/// サイズがゼロの型の超過は常に無限であるため、`capacity()` は常に `usize::MAX` を返すことに注意してください。
/// これは、`capacity()` では長さが得られないため、このタイプを `Box<[T]>` でラウンドトリップする場合は注意が必要であることを意味します。
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): これは、`#[unstable]` の `const fn` が `min_const_fn` に準拠する必要がなく、`min_const_fn` でも呼び出すことができないために存在します。
    ///
    /// `RawVec<T>::new` または依存関係を変更する場合は、`min_const_fn` に本当に違反するものを導入しないように注意してください。
    ///
    /// NOTE: このハッキングを回避し、`min_const_fn` との適合性を必要とする `#[rustc_force_min_const_fn]` 属性との適合性を確認できますが、`#[rustc_const_unstable(feature = "foo", issue = "01234")]` が存在する場合に `foo` を有効にしない `stable(...) const fn` / ユーザーコードで呼び出すことは必ずしも許可されません。
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// 割り当てずに、(システムヒープ上に) 可能な限り最大の `RawVec` を作成します。
    /// `T` のサイズが正の場合、容量 `0` の `RawVec` になります。
    /// `T` のサイズがゼロの場合、容量 `usize::MAX` の `RawVec` になります。
    /// 遅延割り当ての実装に役立ちます。
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` の容量と配置の要件を正確に満たした `RawVec` を (システムヒープ上に) 作成します。
    /// これは、`capacity` が `0` の場合、または `T` のサイズがゼロの場合に `RawVec::new` を呼び出すのと同じです。
    /// `T` のサイズがゼロの場合、これは、要求された容量の `RawVec` を取得できないことを意味することに注意してください。
    ///
    /// # Panics
    ///
    /// 要求された容量が `isize::MAX` バイトを超える場合は Panics。
    ///
    /// # Aborts
    ///
    /// OOM で中止します。
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` と同様ですが、バッファがゼロになることを保証します。
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ポインターと容量から `RawVec` を再構成します。
    ///
    /// # Safety
    ///
    /// `ptr` は (システムヒープ上で) 割り当てられ、指定された `capacity` で割り当てられる必要があります。
    /// サイズタイプの場合、`capacity` は `isize::MAX` を超えることはできません。(32 ビットシステムでのみ懸念されます)。
    /// ZST vectors の容量は最大 `usize::MAX` です。
    /// `ptr` および `capacity` が `RawVec` からのものである場合、これは保証されます。
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // 小さな Vecs はばかげています。スキップ:
    // - 要素サイズが 1 の場合は 8。ヒープアロケータは 8 バイト未満の要求を少なくとも 8 バイトに切り上げる可能性が高いためです。
    //
    // - 要素が中程度のサイズ (<=1 KiB) の場合は 4。
    // - 1 それ以外の場合は、非常に短い Vec でスペースを浪費しないようにします。
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` と同様ですが、返される `RawVec` のアロケータの選択に対してパラメータ化されています。
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" を意味します。サイズがゼロの型は無視されます。
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` と同様ですが、返される `RawVec` のアロケータの選択に対してパラメータ化されています。
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` と同様ですが、返される `RawVec` のアロケータの選択に対してパラメータ化されています。
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` を `RawVec<T>` に変換します。
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// 指定された `len` でバッファ全体を `Box<[MaybeUninit<T>]>` に変換します。
    ///
    /// これにより、実行された可能性のある `cap` の変更が正しく再構成されることに注意してください。(詳細については、タイプの説明を参照してください。)
    ///
    /// # Safety
    ///
    /// * `len` 最後に要求された容量以上である必要があり、
    /// * `len` `self.capacity()` 以下である必要があります。
    ///
    /// アロケータが割り当て超過になり、要求よりも大きなメモリブロックを返す可能性があるため、要求された容量と `self.capacity()` が異なる可能性があることに注意してください。
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // 健全性 - 安全要件の半分をチェックします (残りの半分はチェックできません)。
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // `unwrap_or_else` は、生成される LLVM IR の量を膨らませるので、ここでは避けます。
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ポインター、容量、およびアロケーターから `RawVec` を再構成します。
    ///
    /// # Safety
    ///
    /// `ptr` は、(指定されたアロケーター `alloc` を介して)、指定された `capacity` で割り当てる必要があります。
    /// サイズタイプの場合、`capacity` は `isize::MAX` を超えることはできません。
    /// (32 ビットシステムでのみ懸念されます)。
    /// ZST vectors の容量は最大 `usize::MAX` です。
    /// `ptr` および `capacity` が `alloc` を介して作成された `RawVec` からのものである場合、これは保証されます。
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// 割り当ての開始への生のポインタを取得します。
    /// `capacity == 0` または `T` のサイズがゼロの場合、これは `Unique::dangling()` であることに注意してください。
    /// 前者の場合は注意が必要です。
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// 割り当ての容量を取得します。
    ///
    /// `T` のサイズがゼロの場合、これは常に `usize::MAX` になります。
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// この `RawVec` をサポートするアロケータへの共有参照を返します。
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // メモリのチャンクが割り当てられているため、ランタイムチェックをバイパスして現在のレイアウトを取得できます。
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// バッファに少なくとも `len + additional` 要素を保持するのに十分なスペースが含まれていることを確認します。
    /// まだ十分な容量がない場合は、十分なスペースと快適なスラックスペースを再割り当てして、*O*(1) の動作を償却します。
    ///
    /// 不必要に panic が発生する場合は、この動作を制限します。
    ///
    /// `len` が `self.capacity()` を超えると、要求されたスペースを実際に割り当てることができない場合があります。
    /// これは実際には安全ではありませんが、この関数の動作に依存する安全でないコード *あなた* が書くと壊れることがあります。
    ///
    /// これは、`extend` のようなバルクプッシュ操作を実装するのに理想的です。
    ///
    /// # Panics
    ///
    /// 新しい容量が `isize::MAX` バイトを超える場合は Panics。
    ///
    /// # Aborts
    ///
    /// OOM で中止します。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // len が `isize::MAX` を超えた場合、予約は中止またはパニックになるため、これをチェックせずに安全に実行できます。
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve` と同じですが、パニックや中止ではなくエラーを返します。
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// バッファに少なくとも `len + additional` 要素を保持するのに十分なスペースが含まれていることを確認します。
    /// まだ行っていない場合は、必要最小限のメモリを再割り当てします。
    /// 通常、これは正確に必要なメモリ量になりますが、原則として、アロケータは私たちが要求した以上の量を自由に返すことができます。
    ///
    ///
    /// `len` が `self.capacity()` を超えると、要求されたスペースを実際に割り当てることができない場合があります。
    /// これは実際には安全ではありませんが、この関数の動作に依存する安全でないコード *あなた* が書くと壊れることがあります。
    ///
    /// # Panics
    ///
    /// 新しい容量が `isize::MAX` バイトを超える場合は Panics。
    ///
    /// # Aborts
    ///
    /// OOM で中止します。
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact` と同じですが、パニックや中止ではなくエラーを返します。
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// 割り当てを指定された量まで縮小します。
    /// 指定された量が 0 の場合、実際には完全に割り当てが解除されます。
    ///
    /// # Panics
    ///
    /// 指定された量が現在の容量より *大きい* 場合は Panics。
    ///
    /// # Aborts
    ///
    /// OOM で中止します。
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// 必要な追加容量を満たすためにバッファーを拡張する必要がある場合に戻ります。
    /// 主に、`grow` をインライン化せずにリザーブコールをインライン化できるようにするために使用されます。
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // このメソッドは通常、何度もインスタンス化されます。したがって、コンパイル時間を改善するために、できるだけ小さくする必要があります。
    // ただし、生成されたコードをより高速に実行できるように、そのコンテンツの多くを可能な限り静的に計算できるようにする必要もあります。
    // したがって、このメソッドは、`T` に依存するすべてのコードがその中に含まれるように注意深く記述されていますが、`T` に依存しないコードの多くは、`T` よりも一般的ではない関数に含まれています。
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // これは、呼び出しコンテキストによって保証されます。
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` が
            // 0、ここに到達することは必然的に `RawVec` がいっぱいであることを意味します。
            return Err(CapacityOverflow);
        }

        // 悲しいことに、これらのチェックについて私たちが実際にできることは何もありません。
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // これにより、指数関数的成長が保証されます。
        // `cap <= isize::MAX` および `cap` のタイプは `usize` であるため、ダブリングはオーバーフローできません。
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ではジェネリックではありません。
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // このメソッドの制約は `grow_amortized` の制約とほとんど同じですが、このメソッドは通常、インスタンス化される頻度が少ないため、それほど重要ではありません。
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // タイプサイズが
            // 0、ここに到達することは必然的に `RawVec` がいっぱいであることを意味します。
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` ではジェネリックではありません。
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// この関数は、コンパイル時間を最小限に抑えるために `RawVec` の外部にあります。詳細については、`RawVec::grow_amortized` の上のコメントを参照してください。
// (実際に見られるさまざまな `A` タイプの数は、`T` タイプの数よりもはるかに少ないため、`A` パラメーターは重要ではありません。)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` のサイズを最小化するには、ここでエラーを確認してください。
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // アロケータはアライメントが等しいかどうかをチェックします
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` が所有するメモリを、その内容を削除しようとせずに解放します。
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// 予約エラー処理の中央機能。
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// 以下を保証する必要があります。
// * `> isize::MAX` バイトサイズのオブジェクトを割り当てることはありません。
// * `usize::MAX` をオーバーフローさせることはなく、実際には割り当てが少なすぎます。
//
// 64 ビットでは、`> isize::MAX` バイトを割り当てようとすると必ず失敗するため、オーバーフローをチェックする必要があります。
// 32 ビットおよび 16 ビットでは、PAE や x32 などのユーザースペースで 4GB すべてを使用できるプラットフォームで実行している場合に備えて、このためのガードを追加する必要があります。
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// 容量オーバーフローの報告を担当する 1 つの中心的な機能。
// これにより、モジュール全体ではなく panics の場所が 1 つしかないため、これらの panics に関連するコード生成が最小限に抑えられます。
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}