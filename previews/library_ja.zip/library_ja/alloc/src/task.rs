#![stable(feature = "wake_trait", since = "1.51.0")]
//! 非同期タスクを操作するためのタイプと Traits。
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// エグゼキュータでタスクをウェイクアップする実装。
///
/// この trait は、[`Waker`] を作成するために使用できます。
/// エグゼキュータは、この trait の実装を定義し、それを使用して、そのエグゼキュータで実行されるタスクに渡す Waker を構築できます。
///
/// この trait は、[`RawWaker`] を構築する代わりに、メモリセーフで人間工学に基づいた代替手段です。
/// これは、タスクのウェイクアップに使用されるデータが [`Arc`] に格納される一般的なエグゼキュータ設計をサポートします。
/// 一部のエグゼキュータ (特に組み込みシステムのエグゼキュータ) はこの API を使用できません。そのため、これらのシステムの代替として [`RawWaker`] が存在します。
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// future を受け取り、現在のスレッドで完了するまで実行する基本的な `block_on` 関数。
///
/// **Note:** この例では、正確さと単純さを交換しています。
/// デッドロックを防ぐために、本番グレードの実装では、ネストされた呼び出しだけでなく、`thread::unpark` への中間呼び出しも処理する必要があります。
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// 呼び出されたときに現在のスレッドをウェイクアップするウェイカー。
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// 現在のスレッドで future を実行して完了します。
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future を固定して、ポーリングできるようにします。
///     let mut fut = Box::pin(fut);
///
///     // future に渡される新しいコンテキストを作成します。
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future を実行して完了します。
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// このタスクを起こします。
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ウェイカーを消費せずにこのタスクをウェイクします。
    ///
    /// エグゼキュータがウェイカーを消費せずにウェイクするためのより安価な方法をサポートしている場合は、このメソッドをオーバーライドする必要があります。
    /// デフォルトでは、[`Arc`] のクローンを作成し、クローンで [`wake`] を呼び出します。
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // 安全性: raw_waker が安全に構築するため、これは安全です
        // Arc の RawWaker<W>。
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: RawWaker を構築するためのこのプライベート関数は、ではなく使用されます
// これを `From<Arc<W>> for RawWaker` impl にインライン化して、`From<Arc<W>> for Waker` の安全性が正しい trait ディスパッチに依存しないようにします。代わりに、両方の impl がこの関数を直接明示的に呼び出します。
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // アークの参照カウントをインクリメントして、クローンを作成します。
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // 値でウェイクし、アークを Wake::wake 関数に移動します
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // 参照によりウェイクアップし、ウェイカーを手動ドロップでラップして、ドロップしないようにします
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ドロップ時のアークの参照カウントをデクリメントします
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}