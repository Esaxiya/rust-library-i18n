// rsbegin.o および rsend.o はいわゆる "compiler runtime startup objects" です。
// これらには、コンパイラランタイムを正しく初期化するために必要なコードが含まれています。
//
// 実行可能ファイルまたは dylib イメージがリンクされている場合、すべてのユーザーコードとライブラリはこれら 2 つのオブジェクトファイル間で "sandwiched" であるため、rsbegin.o のコードまたはデータがイメージのそれぞれのセクションの最初になり、rsend.o のコードとデータが最後になります。
// この効果は、セクションの最初または最後にシンボルを配置したり、必要なヘッダーまたはフッターを挿入したりするために使用できます。
//
// 実際のモジュールエントリポイントは、C ランタイムスタートアップオブジェクト (通常は `crtX.o` と呼ばれます) にあり、他のランタイムコンポーネント (さらに別の特別なイメージセクションを介して登録) の初期化コールバックを呼び出します。
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // スタックフレームアンワインド情報セクションの開始をマークします
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // アンワインダーの内部簿記のためのスクラッチスペース。
    // これは、$ GCC/unwind-dw2-fde.h で `struct object` として定義されています。
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // 情報 registration/deregistration ルーチンをほどきます。
    // libpanic_unwind のドキュメントを参照してください。
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // モジュールの起動時にアンワインド情報を登録する
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // シャットダウン時に登録解除
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW 固有の init/uninit ルーチン登録
    pub mod mingw_init {
        // MinGW のスタートアップオブジェクト (crt0.o/dllcrt0.o) は、起動時と終了時に .ctors セクションと .dtors セクションでグローバルコンストラクターを呼び出します。
        // DLL の場合、これは DLL がロードおよびアンロードされるときに実行されます。
        //
        // リンカはセクションをソートします。これにより、コールバックがリストの最後に配置されます。
        // コンストラクターは逆の順序で実行されるため、これにより、コールバックが最初と最後に実行されます。
        //
        //

        #[link_section = ".ctors.65535"] // .ctors。*: C 初期化コールバック
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors。*: C 終了コールバック
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}