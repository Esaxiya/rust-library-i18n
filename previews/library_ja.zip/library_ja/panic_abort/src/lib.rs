//! プロセスアボートによる Rust panics の実装
//!
//! 巻き戻しによる実装と比較すると、この crate は *はるかに* 単純です! そうは言っても、それはそれほど用途が広いわけではありませんが、ここに行きます!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" 問題のプラットフォームでの関連するアボートへのペイロードとシム。
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // std::sys::abort_internal に電話する
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows では、プロセッサ固有の__fastfail メカニズムを使用します。Windows 8 以降では、これにより、インプロセス例外ハンドラーを実行せずにプロセスがすぐに終了します。
            // Windows の以前のバージョンでは、この一連の命令はアクセス違反として扱われ、プロセスを終了しますが、必ずしもすべての例外ハンドラーをバイパスする必要はありません。
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: これは、libstd の `abort_internal` と同じ実装です。
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// これは... 少し奇妙です。tl; dr; これは正しくリンクするために必要であるということです、より長い説明は以下にあります。
//
// 現在、出荷する libcore/libstd のバイナリはすべて `-C panic=unwind` でコンパイルされています。これは、バイナリが可能な限り多くの状況と最大限に互換性があることを保証するために行われます。
// ただし、コンパイラーは、`-C panic=unwind` でコンパイルされたすべての関数に "personality function" を必要とします。このパーソナリティ関数は、シンボル `rust_eh_personality` にハードコードされており、`eh_personality` lang アイテムによって定義されます。
//
// So...
// ここでその lang アイテムを定義しないのはなぜですか? 良い質問! panic ランタイムがリンクされる方法は、コンパイラの crate ストアの "sort of" であるという点で実際には少し微妙ですが、実際には別のランタイムがリンクされていない場合にのみ実際にリンクされます。
//
// これは、この crate と panic_unwind crate の両方がコンパイラの crate ストアに表示される可能性があることを意味し、両方が `eh_personality` lang 項目を定義している場合、エラーが発生します。
//
// これを処理するために、コンパイラーは、リンクされている panic ランタイムがアンワインドランタイムである場合にのみ `eh_personality` を定義する必要があります。それ以外の場合は、定義する必要はありません (当然のことながら)。
// ただし、この場合、このライブラリはこのシンボルを定義するだけなので、どこかに少なくともある程度の個性があります。
//
// 基本的に、このシンボルは libcore/libstd バイナリに接続するように定義されていますが、アンワインドランタイムではリンクしないため、決して呼び出さないでください。
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-pc-windows-gnu では、すべてのフレームを渡すときに `ExceptionContinueSearch` を返す必要がある独自のパーソナリティ関数を使用します。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // 上記と同様に、これは現在 Emscripten でのみ使用されている `eh_catch_typeinfo` lang アイテムに対応します。
    //
    // panics は例外を生成せず、外部例外は現在 -C panic=abort の UB であるため (これは変更される可能性があります)、catch_unwind 呼び出しでこの typeinfo が使用されることはありません。
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // これら 2 つは、i686-pc-windows-gnu のスタートアップオブジェクトによって呼び出されますが、何もする必要がないため、本体はノープです。
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}