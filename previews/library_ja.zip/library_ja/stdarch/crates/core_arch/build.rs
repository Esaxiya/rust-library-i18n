use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // `#[assert_instr]` アノテーションに、すべての simd 組み込み関数が codegen のテストに使用できることを伝えるために使用されます。これは、現在 `#[target_feature]` に同等のものがない追加の `-Ctarget-feature=+unimplemented-simd128` の背後にゲートされているものがあるためです。
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}