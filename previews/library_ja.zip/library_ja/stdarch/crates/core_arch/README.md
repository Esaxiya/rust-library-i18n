`core::arch` - Rust のコアライブラリアーキテクチャ固有の組み込み関数
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` モジュールは、アーキテクチャに依存する組み込み関数 (SIMD など) を実装します。

# Usage 

`core::arch` `libcore` の一部として利用可能であり、`libstd` によって再エクスポートされます。この crate を介するよりも、`core::arch` または `std::arch` を介して使用することをお勧めします。
不安定な機能は、`feature(stdsimd)` を介して夜間の Rust で利用できることがよくあります。

この crate を介して `core::arch` を使用するには、毎晩 Rust が必要であり、頻繁に破損する可能性があります (実際に破損します)。この crate を介して使用することを検討する必要がある唯一のケースは次のとおりです。

* `core::arch` を自分で再コンパイルする必要がある場合、たとえば、`libcore`/`libstd` で有効になっていない特定のターゲット機能を有効にしている場合。
Note: 非標準のターゲット用に再コンパイルする必要がある場合は、この crate を使用する代わりに、`xargo` を使用し、必要に応じて `libcore`/`libstd` を再コンパイルすることをお勧めします。
  
* 不安定な Rust 機能の背後でも利用できない可能性のあるいくつかの機能を使用します。これらを最小限に抑えるように努めています。
これらの機能の一部を使用する必要がある場合は、問題を開いて、夜間の Rust で公開し、そこから使用できるようにしてください。

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` は主に MIT ライセンスと Apache ライセンス (バージョン 2.0) の両方の条件で配布され、一部はさまざまな BSD ライクなライセンスでカバーされています。

詳細については、LICENSE-APACHE および LICENSE-MIT を参照してください。

# Contribution

特に明記されていない限り、Apache-2.0 ライセンスで定義されているように、`core_arch` に含めるために意図的に提出された貢献は、追加の条件なしで、上記のようにデュアルライセンスされるものとします。


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












