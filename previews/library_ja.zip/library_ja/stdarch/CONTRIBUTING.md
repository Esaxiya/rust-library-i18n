# stdarch への貢献

`stdarch` crate は、寄付を喜んで受け入れます。まず、リポジトリをチェックアウトして、テストに合格することを確認することをお勧めします。

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

ここで、`<your-target-arch>` は、`rustup` で使用されるターゲットトリプルです。たとえば、`x86_x64-unknown-linux-gnu` (先行する `nightly-` などはありません)。
また、このリポジトリには Rust の夜間チャネルが必要であることを忘れないでください。
上記のテストでは、実際には、`rustup default nightly` (および元に戻すには `rustup default stable`) を使用するように設定するために、夜間の rust をシステムのデフォルトにする必要があります。

上記の手順のいずれかが機能しない場合は、 [please let us know][new]!

次に、[find an issue][issues] を使用して支援することができます。特に、いくつかの支援を使用できる [`help wanted`][help] および [`impl-period`][impl] タグが付いたものをいくつか選択しました。
x86 にすべてのベンダー組み込み関数を実装する [#40][vendor] に最も興味があるかもしれません。その問題は、どこから始めるべきかについてのいくつかの良い指針を持っています!

一般的な質問がある場合は、[join us on gitter][gitter] までお気軽に質問してください。質問がある場合は、@BurntSushi または @alexcrichton のいずれかに遠慮なく ping してください。

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# stdarch 組み込み関数の例の書き方

特定の組み込み関数が正しく機能するために有効にする必要のある機能がいくつかあり、その機能が CPU でサポートされている場合にのみ、`cargo test --doc` で例を実行する必要があります。

その結果、`rustdoc` によって生成されるデフォルトの `fn main` は機能しません (ほとんどの場合)。
例が期待どおりに機能することを確認するためのガイドとして、以下を使用することを検討してください。

```rust
/// # // 例が次のようになるようにするには、cfg_target_feature が必要です。
/// # // CPU が機能をサポートしているときに `cargo test --doc` によって実行されます
/// # #![feature(cfg_target_feature)]
/// # // 組み込み関数が機能するには target_feature が必要です
/// # #![feature(target_feature)]
/// #
/// # // rustdoc はデフォルトで `extern crate stdarch` を使用しますが、
/// # // `#[macro_use]`
/// # #[macro_use] extern crate stdarch;
/// #
/// # // 本当の主な機能
/// # fn main() {
/// #     // `<target feature>` がサポートされている場合にのみこれを実行します
/// #     if cfg_feature_enabled! ( "<target feature>") {
/// #         // ターゲット機能の場合にのみ実行される `worker` 関数を作成します
/// #         // がサポートされており、ワーカーで `target_feature` が有効になっていることを確認してください
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         安全でない fn worker() {
/// // ここにあなたの例を書いてください。機能固有の組み込み関数はここで機能します! ワイルドに!
///
/// #         }
///
/// #         安全でない { worker(); }
/// #     }
/// # }
```

上記の構文の一部が見慣れない場合は、[Rust Book] の [Documentation as tests] セクションで `rustdoc` 構文が非常によく説明されています。
いつものように、[join us on gitter][gitter] に気軽にアクセスして、問題が発生したかどうかを確認してください。`stdarch` のドキュメントの改善にご協力いただきありがとうございます。

# 代替テスト手順

通常、`ci/run.sh` を使用してテストを実行することをお勧めします。
ただし、Windows を使用している場合など、これは機能しない可能性があります。

その場合、コード生成をテストするために `cargo +nightly test` と `cargo +nightly test --release -p core_arch` の実行にフォールバックできます。
これらには、夜間のツールチェーンがインストールされ、`rustc` がターゲットトリプルとその CPU について認識している必要があることに注意してください。
特に、`ci/run.sh` の場合と同様に、`TARGET` 環境変数を設定する必要があります。
さらに、ターゲット機能を示すために `RUSTCFLAGS` (`C` が必要) を設定する必要があります。`RUSTCFLAGS="-C -target-features=+avx2"`.
現在の CPU に対して "just" を開発している場合は、`-C -target-cpu=native` を設定することもできます。

これらの代替命令を使用する場合は、[things may go less smoothly than they would with `ci/run.sh`][ci-run-good] などに注意してください。
逆アセンブラが異なる名前を付けたため、命令生成テストが失敗する場合があります。
同じように動作しているにもかかわらず、`aesenc` 命令の代わりに `vaesenc` を生成する場合があります。
また、これらの命令は通常実行されるよりも少ないテストを実行するため、最終的にプルリクエストを実行すると、ここで説明されていないテストでエラーが表示される場合があることに驚かないでください。

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






