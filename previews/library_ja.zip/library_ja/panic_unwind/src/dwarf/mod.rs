//! DWARF でエンコードされたデータストリームを解析するためのユーティリティ。
//! <http://www.dwarfstd.org>、DWARF-4 標準、セクション 7、"Data Representation" を参照してください
//!

// このモジュールは、現時点では x86_64-pc-windows-gnu でのみ使用されていますが、リグレッションを回避するためにどこでもコンパイルしています。
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF ストリームはパックされているため、たとえば、u32 は必ずしも 4 バイト境界に配置されるとは限りません。
    // これにより、アライメント要件が厳しいプラットフォームで問題が発生する可能性があります。
    // "packed" 構造体でデータをラップすることにより、バックエンドに "misalignment-safe" コードを生成するように指示しています。
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 および SLEB128 エンコーディングは、セクション 7.6、"Variable Length Data" で定義されています。
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}