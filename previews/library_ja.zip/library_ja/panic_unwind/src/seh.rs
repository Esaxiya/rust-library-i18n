//! Windows SEH
//!
//! Windows (現在は MSVC のみ) では、デフォルトの例外処理メカニズムは構造化例外処理 (SEH) です。
//! これは、コンパイラ内部の点で Dwarf ベースの例外処理 (たとえば、他の unix プラットフォームが使用するもの) とはかなり異なるため、LLVM は SEH を大幅にサポートする必要があります。
//!
//! 一言で言えば、ここで何が起こるかです:
//!
//! 1. `panic` 関数は、標準の Windows 関数 `_CxxThrowException` を呼び出して、C ++ のような例外をスローし、巻き戻しプロセスをトリガーします。
//! 2.
//! コンパイラーによって生成されたすべてのランディングパッドは、CRT の関数であるパーソナリティ関数 `__CxxFrameHandler3` を使用し、Windows の巻き戻しコードは、このパーソナリティ関数を使用して、スタック上のすべてのクリーンアップコードを実行します。
//!
//! 3. コンパイラによって生成された `invoke` へのすべての呼び出しには、クリーンアップルーチンの開始を示す `cleanuppad` LLVM 命令として設定されたランディングパッドがあります。
//! パーソナリティ (ステップ 2 で CRT で定義) は、クリーンアップルーチンを実行する責任があります。
//! 4. 最終的に、`try` 組み込み関数 (コンパイラーによって生成された) の "catch" コードが実行され、制御が Rust に戻る必要があることを示します。
//! これは、LLVM IR 用語で `catchswitch` と `catchpad` 命令を介して実行され、最終的に `catchret` 命令でプログラムに通常の制御を戻します。
//!
//! gcc ベースの例外処理との特定の違いは次のとおりです。
//!
//! * Rust にはカスタムパーソナリティ機能はなく、代わりに *常に*`__CxxFrameHandler3` です。さらに、追加のフィルタリングは実行されないため、スローしている種類のように見える C++ 例外をキャッチすることになります。
//! とにかく、Rust に例外をスローすることは未定義の動作であるため、これで問題ないことに注意してください。
//! * 巻き戻しの境界を越えて送信するデータ、具体的には `Box<dyn Any + Send>` があります。ドワーフの例外と同様に、これら 2 つのポインターは例外自体にペイロードとして格納されます。
//! ただし、MSVC では、フィルター関数の実行中に呼び出しスタックが保持されるため、追加のヒープ割り当ては必要ありません。
//! これは、ポインターが `_CxxThrowException` に直接渡され、フィルター関数で復元されて `try` 組み込み関数のスタックフレームに書き込まれることを意味します。
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // 参照によって例外をキャッチし、そのデストラクタは C++ ランタイムによって実行されるため、これはオプションである必要があります。
    // Box を例外から除外する場合、Box をダブルドロップせずにデストラクタを実行するには、例外を有効な状態のままにしておく必要があります。
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// まず、たくさんの型定義です。ここにはいくつかのプラットフォーム固有の奇妙な点があり、LLVM から露骨にコピーされたものがたくさんあります。このすべての目的は、`_CxxThrowException` の呼び出しを通じて以下の `panic` 関数を実装することです。
//
// この関数は 2 つの引数を取ります。1 つ目は、渡すデータへのポインターです。この場合は、trait オブジェクトです。見つけるのはとても簡単です! ただし、次はもっと複雑です。
// これは `_ThrowInfo` 構造へのポインタであり、通常、スローされる例外を説明することだけを目的としています。
//
// 現在、このタイプ [1] の定義は少し厄介で、主な奇妙な点 (およびオンライン記事との違い) は、32 ビットではポインターがポインターであるのに対し、64 ビットではポインターが 32 ビットオフセットとして表されることです。`__ImageBase` シンボル。
//
// 以下のモジュールの `ptr_t` および `ptr!` マクロは、これを表現するために使用されます。
//
// タイプ定義の迷路は、LLVM がこの種の操作に対して出力するものにも厳密に従います。たとえば、この C++ コードを MSVC でコンパイルし、LLVMIR を発行する場合:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ボイド foo() { rust_panic a = {0, 1};
//          投げる; }
//
// それは本質的に私たちがエミュレートしようとしているものです。以下の定数値のほとんどは、LLVM からコピーされたものです。
//
// いずれにせよ、これらの構造はすべて同じように構築されており、私たちにとっては少し冗長です。
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ここでは、名前マングリングルールを意図的に無視していることに注意してください。`struct rust_panic` を宣言するだけで C++ が Rust panics をキャッチできないようにする必要があります。
//
//
// 変更するときは、タイプ名の文字列が `compiler/rustc_codegen_llvm/src/intrinsic.rs` で使用されているものと完全に一致していることを確認してください。
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ここでの先頭の `\x01` バイトは、実際には LLVM への魔法の信号であり、`_` 文字のプレフィックスなどの他のマングリングを適用しません。
    //
    //
    // このシンボルは、C ++ の `std::type_info` で使用される vtable です。
    // タイプ `std::type_info` のオブジェクト、タイプ記述子には、このテーブルへのポインタがあります。
    // タイプ記述子は、上記で定義され、以下で構築する C++ EH 構造体によって参照されます。
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// この型記述子は、例外をスローする場合にのみ使用されます。
// catch 部分は、独自の TypeDescriptor を生成する try 組み込み関数によって処理されます。
//
// MSVC ランタイムは、ポインターの同等性ではなく、型名の文字列比較を使用して TypeDescriptors と一致するため、これは問題ありません。
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// C ++ コードが例外をキャプチャし、伝播せずにドロップすることを決定した場合に使用されるデストラクタ。
// try 組み込み関数の catch 部分は、例外オブジェクトの最初のワードを 0 に設定して、デストラクタによってスキップされるようにします。
//
// x86 Windows は、デフォルトの "C" 呼び出し規約ではなく、C ++ メンバー関数の "thiscall" 呼び出し規約を使用することに注意してください。
//
// exception_copy 関数はここでは少し特別です。try/catch ブロックの下で MSVC ランタイムによって呼び出され、ここで生成した panic が例外コピーの結果として使用されます。
//
// これは、C ++ ランタイムによって使用され、std::exception_ptr での例外のキャプチャをサポートします。これは、Box が原因でサポートできません。<dyn Any> クローン化できません。
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException は完全にこのスタックフレームで実行されるため、`data` をヒープに転送する必要はありません。
    // この関数にスタックポインタを渡すだけです。
    //
    // 巻き戻し時に Exception がドロップされないようにするため、ここでは ManuallyDrop が必要です。
    // 代わりに、C ++ ランタイムによって呼び出される exception_cleanup によってドロップされます。
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // これは... 意外に思われるかもしれませんが、当然のことながらそうです。32 ビット MSVC では、これらの構造体間のポインターはまさにそのポインターです。
    // ただし、64 ビット MSVC では、構造体間のポインターは、`__ImageBase` からの 32 ビットオフセットとして表現されます。
    //
    // したがって、32 ビット MSVC では、上記の「静的」でこれらすべてのポインターを宣言できます。
    // 64 ビット MSVC では、ポインターの減算を静的に表現する必要がありますが、これは Rust では現在許可されていないため、実際には実行できません。
    //
    // 次善の策は、実行時にこれらの構造を埋めることです (とにかくパニックはすでに "slow path" です)。
    // したがって、ここでは、これらのポインタフィールドをすべて 32 ビット整数として再解釈し、関連する値を格納します (原子的には、同時 panics が発生する可能性があるため)。
    //
    // 技術的には、ランタイムはおそらくこれらのフィールドの非アトミック読み取りを行いますが、理論的には *間違った* 値を読み取ることはないので、それほど悪くはないはずです...
    //
    // いずれにせよ、静力学でより多くの操作を表現できるようになるまで (そして決してできないかもしれない)、基本的にこのようなことをする必要があります。
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // ここでの NULL ペイロードは、__ rust_try の catch (...) からここに到達したことを意味します。
    // これは、Rust 以外の外部例外がキャッチされた場合に発生します。
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// これはコンパイラーが存在する必要があります (たとえば、lang アイテムです) が、__ C_specific_handler または _except_handler3 は常に使用されるパーソナリティ関数であるため、コンパイラーによって実際に呼び出されることはありません。
//
// したがって、これは単なる中止スタブです。
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}