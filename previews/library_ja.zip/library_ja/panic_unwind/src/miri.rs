//! Miri の panics を巻き戻します。
use alloc::boxed::Box;
use core::any::Any;

// Miri エンジンが巻き戻しを通じて伝播するペイロードのタイプ。
// ポインタサイズである必要があります。
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// ミリは、巻き戻しを開始するための外部機能を提供しました。
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic` に渡すペイロードは、以下の `cleanup` で取得する引数とまったく同じになります。
    // したがって、ポインタサイズのものを取得するために、一度ボックス化するだけです。
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // 基盤となる `Box` を回復します。
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}