//! スタック巻き戻しによる panics の実装
//!
//! この crate は、コンパイル対象のプラットフォームの "most native" スタック巻き戻しメカニズムを使用した Rust での panics の実装です。
//! これは基本的に、現在 3 つのバケットに分類されています。
//!
//! 1. MSVC ターゲットは、`seh.rs` ファイルで SEH を使用します。
//! 2. Emscripten は `emcc.rs` ファイルで C++ 例外を使用します。
//! 3. 他のすべてのターゲットは、`gcc.rs` ファイルで libunwind/libgcc を使用します。
//!
//! 各実装に関する詳細なドキュメントは、それぞれのモジュールにあります。
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` Miri では使用されていないため、無音の警告が表示されます。
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust ランタイムのスタートアップオブジェクトはこれらのシンボルに依存しているため、パブリックにします。
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // 巻き戻しをサポートしていないターゲット。
        // - arch=wasm32
        // - os=none ("bare metal" ターゲット)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Miri ランタイムを使用します。
        // rustc は、そこから特定の lang アイテムが定義されることを想定しているため、上記の通常のランタイムもロードする必要があります。
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // 実際のランタイムを使用します。
        use real_imp as imp;
    }
}

extern "C" {
    /// panic オブジェクトが `catch_unwind` の外部にドロップされたときに呼び出される libstd のハンドラー。
    ///
    fn __rust_drop_panic() -> !;

    /// 外部例外がキャッチされたときに呼び出される libstd のハンドラー。
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// 例外を発生させるためのエントリポイント。プラットフォーム固有の実装に委任するだけです。
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}