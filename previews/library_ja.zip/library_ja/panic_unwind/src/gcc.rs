//! libgcc/libunwind (何らかの形で) に裏打ちされた panics の実装。
//!
//! 例外処理とスタックの巻き戻しの背景については、"Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) とそこからリンクされているドキュメントを参照してください。
//! これらも良い読み物です:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## 簡単な要約
//!
//! 例外処理は、検索フェーズとクリーンアップフェーズの 2 つのフェーズで発生します。
//!
//! 両方のフェーズで、アンワインダーは、現在のプロセスのモジュールのスタックフレームアンワインドセクションからの情報を使用して、スタックフレームを上から下にウォークします (ここでの "module" は、OS モジュール、つまり実行可能ファイルまたはダイナミックライブラリを指します)。
//!
//!
//! スタックフレームごとに、関連付けられた "personality routine" を呼び出します。このアドレスは、アンワインド情報セクションにも格納されます。
//!
//! 検索フェーズでは、パーソナリティルーチンの役割は、スローされている例外オブジェクトを調べて、そのスタックフレームでキャッチする必要があるかどうかを判断することです。ハンドラーフレームが識別されると、クリーンアップフェーズが開始されます。
//!
//! クリーンアップフェーズでは、アンワインダーが各パーソナリティルーチンを再度呼び出します。
//! 今回は、現在のスタックフレームに対して実行する必要があるクリーンアップコード (ある場合) を決定します。その場合、制御は関数本体の特別な branch、デストラクタを呼び出したり、メモリを解放したりする "landing pad" に転送されます。
//! ランディングパッドの終わりで、制御はアンワインダーに戻され、巻き戻しが再開されます。
//!
//! スタックがハンドラーフレームレベルまで巻き戻されると、巻き戻しが停止し、最後のパーソナリティルーチンが制御を catch ブロックに移します。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust の例外クラス識別子。
// これは、パーソナリティルーチンによって使用され、例外が独自のランタイムによってスローされたかどうかを判断します。
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST - ベンダー、言語
    0x4d4f5a_00_52555354
}

// レジスタ ID は、アーキテクチャごとに LLVM の TargetLowering::getExceptionPointerRegister() および TargetLowering::getExceptionSelectorRegister() から削除され、レジスタ定義テーブル (通常はレジスタ定義テーブル) を介して DWARF レジスタ番号にマップされました。<arch>RegisterInfo.td、"DwarfRegNum" を検索)。
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register も参照してください。
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX、EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX、RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0、 X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3、 X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// 次のコードは、GCC の C および C++ パーソナリティルーチンに基づいています。参考までに、以下を参照してください。
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI パーソナリティルーチン。
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS SjLj 巻き戻しを使用するため、代わりにデフォルトのルーチンを使用します。
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM のバックトレースは、状態 ==_US_VIRTUAL_UNWIND_FRAME | でパーソナリティルーチンを呼び出します。_US_FORCE_UNWIND。
                // そのような場合、スタックの巻き戻しを続けたいと思います。そうしないと、すべてのバックトレースが__rust_try で終了します。
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF アンワインダーは、_Unwind_Context が関数や LSDA ポインターなどを保持していることを前提としていますが、ARMEHABI はそれらを例外オブジェクトに配置します。
            // コンテキストポインタのみを受け取る _Unwind_GetLanguageSpecificData() のような関数のシグネチャを保持するために、GCC パーソナリティルーチンは、ARM の "scratch register" (r12) 用に予約された場所を使用して、コンテキスト内の exception_object へのポインタを隠します。
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... より原則的なアプローチは、libunwind バインディングで ARM の _Unwind_Context の完全な定義を提供し、DWARF 互換性関数をバイパスして、そこから必要なデータを直接フェッチすることです。
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI では、パーソナリティルーチンが例外オブジェクトのバリアキャッシュ内の SP 値を更新する必要があります。
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI では、パーソナリティルーチンは、戻る前に 1 つのスタックフレームを実際に巻き戻す責任があります (ARM EHABISec。
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc で定義されています
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // デフォルトのパーソナリティルーチン。ほとんどのターゲットで直接使用され、SEH を介して Windows x86_64 で間接的に使用されます。
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW ターゲットでは、巻き戻しメカニズムは SEH ですが、巻き戻しハンドラーデータ (別名 LSDA) は GCC 互換のエンコーディングを使用します。
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // 私たちのターゲットのほとんどのための人格ルーチン。
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // リターンアドレスは、呼び出し命令の 1 バイト先を指します。これは、LSDA 範囲テーブルの次の IP 範囲にある可能性があります。
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// フレームアンワインド情報登録
//
// 各モジュールのイメージには、フレーム巻き戻し情報セクション (通常は ".eh_frame") が含まれています。モジュールがプロセスに loaded/unloaded である場合、アンワインダーはメモリ内のこのセクションの場所について通知される必要があります。それを達成する方法は、プラットフォームによって異なります。
// 一部 (Linux など) では、アンワインダーが独自にアンワインド情報セクションを検出できます (dl_iterate_phdr() API and finding their ".eh_frame" sections) を介して現在ロードされているモジュールを動的に列挙することにより、Windows などの他のモジュールでは、アンワインダー API を介してアンワインド情報セクションをアクティブに登録する必要があります。
//
//
// このモジュールは、GCC ランタイムに情報を登録するために rsbegin.rs から参照および呼び出される 2 つのシンボルを定義します。
// スタックアンワインドの実装は (今のところ) libgcc_eh に延期されますが、Rust crates は、これらの Rust 固有のエントリポイントを使用して、GCC ランタイムとの潜在的な衝突を回避します。
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}