# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust の実行時にバックトレースを取得するためのライブラリ。
このライブラリは、使用するプログラムインターフェイスを提供することにより、標準ライブラリのサポートを強化することを目的としていますが、libstd の panics のように現在のバックトレースを簡単に印刷することもサポートしています。

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

単純にバックトレースをキャプチャし、それを処理するのを後で延期するために、トップレベルの `Backtrace` タイプを使用できます。

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ただし、実際のトレース機能へのより多くの raw アクセスが必要な場合は、`trace` および `resolve` 関数を直接使用できます。

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // この命令ポインタをシンボル名に解決します
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // 次のフレームに進み続けます
    });
}
```

# License

このプロジェクトは、次のいずれかの下でライセンスされています

 * Apache ライセンス、バージョン 2.0、([LICENSE-APACHE](LICENSE-APACHE)、または http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ライセンス ([LICENSE-MIT](LICENSE-MIT) または http://opensource.org/licenses/MIT)

あなたの選択で。

### Contribution

特に明記されていない限り、Apache-2.0 ライセンスで定義されているように、バックトレース - rs に含めるために意図的に提出された投稿は、追加の条件なしで、上記のように二重ライセンスされるものとします。







