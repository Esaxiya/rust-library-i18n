#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// バックトレース用のフォーマッタ。
///
/// このタイプは、バックトレース自体がどこから来たかに関係なく、バックトレースを印刷するために使用できます。
/// `Backtrace` タイプを使用している場合、その `Debug` 実装はすでにこの印刷形式を使用しています。
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// 私たちが印刷できる印刷のスタイル
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// 理想的には関連情報のみを含むターサーバックトレースを出力します
    Short,
    /// 考えられるすべての情報を含むバックトレースを出力します
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// 提供された `fmt` に出力を書き込む新しい `BacktraceFmt` を作成します。
    ///
    /// `format` 引数は、バックトレースが印刷されるスタイルを制御し、`print_path` 引数は、ファイル名の `BytesOrWideString` インスタンスを印刷するために使用されます。
    /// このタイプ自体はファイル名の印刷を行いませんが、そのためにはこのコールバックが必要です。
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// 印刷しようとしているバックトレースのプリアンブルを印刷します。
    ///
    /// これは、バックトレースを後で完全にシンボリック化するために一部のプラットフォームで必要です。それ以外の場合、これは `BacktraceFmt` の作成後に呼び出す最初のメソッドである必要があります。
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// バックトレース出力にフレームを追加します。
    ///
    /// このコミットは、実際にフレームを印刷するために使用できる `BacktraceFrameFmt` の RAII インスタンスを返し、破棄するとフレームカウンターをインクリメントします。
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// バックトレース出力を完了します。
    ///
    /// これは現在ノーオペレーションですが、バックトレース形式との future 互換性のために追加されています。
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // 現在、操作はありません。この hook を含めて、future の追加を可能にします。
        Ok(())
    }
}

/// バックトレースの 1 フレームのみのフォーマッタ。
///
/// このタイプは、`BacktraceFmt::frame` 関数によって作成されます。
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// このフレームフォーマッタで `BacktraceFrame` を印刷します。
    ///
    /// これにより、`BacktraceFrame` 内のすべての `BacktraceSymbol` インスタンスが再帰的に出力されます。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` 内に `BacktraceSymbol` を印刷します。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: これは私たちが何も印刷しないというのは素晴らしいことではありません
            // utf8 以外のファイル名を使用します。
            // ありがたいことに、ほとんどすべてが utf8 であるため、これはそれほど悪くないはずです。
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 通常、この crate の生のコールバック内から、生のトレースされた `Frame` および `Symbol` を出力します。
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// バックトレース出力に生のフレームを追加します。
    ///
    /// このメソッドは、前のメソッドとは異なり、異なる場所からソースである場合に生の引数を取ります。
    /// これは、1 つのフレームに対して複数回呼び出される場合があることに注意してください。
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// 列情報を含む生のフレームをバックトレース出力に追加します。
    ///
    /// このメソッドは、前と同様に、異なる場所からソースである場合に備えて、生の引数を取ります。
    /// これは、1 つのフレームに対して複数回呼び出される場合があることに注意してください。
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // フクシアはプロセス内でシンボル化できないため、後でシンボル化するために使用できる特別な形式があります。
        // ここで独自の形式で住所を印刷する代わりに、それを印刷します。
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" フレームを印刷する必要はありません。基本的には、システムのバックトレースが非常に遠くまでトレースバックすることに少し熱心だったことを意味します。
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx エンクレーブの TCB サイズを縮小するために、シンボル解決機能を実装する必要はありません。
        // むしろ、ここにアドレスのオフセットを出力できます。これは後で正しい機能にマップできます。
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // フレームのインデックスと、フレームのオプションの命令ポインタを出力します。
        // 適切な空白を印刷するだけで、このフレームの最初のシンボルを超えている場合。
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // 次に、完全なバックトレースの場合は、別のフォーマットを使用してシンボル名を書き出します。
        // ここでは、名前のないシンボルも処理します。
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // 最後に、filename/line 番号が利用可能な場合は、それを印刷します。
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line はシンボル名の下の行に印刷されるので、適切な空白を印刷して、自分自身を右揃えにします。
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // 内部コールバックに委任してファイル名を出力してから、行番号を出力します。
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // 可能な場合は、列番号を追加します。
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // フレームの最初のシンボルだけが気になります
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}