//! プラットフォームに依存するタイプ。

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// 文字列のプラットフォームに依存しない表現。
/// `std` を有効にして作業する場合は、`std` タイプへの変換を提供するための便利な方法をお勧めします。
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// スライス。通常、Unix プラットフォームで提供されます。
    Bytes(&'a [u8]),
    /// 通常 Windows からの幅の広い文字列。
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy は `Cow<str>` に変換され、`Bytes` が無効な UTF-8 の場合、または `BytesOrWideString` が `Wide` の場合に割り当てられます。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` の `Path` 表現を提供します。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}