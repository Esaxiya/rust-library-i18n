// 現在 Linux でのみ使用されているため、他の場所でデッドコードを許可する
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// バイトバッファ用のシンプルなアリーナアロケータ。
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// 指定されたサイズのバッファを割り当て、そのバッファへの可変参照を返します。
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // 安全性: これは、可変を構築する唯一の関数です
        // `self.buffers` への参照。
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // 安全性: `self.buffers` から要素を削除することはないため、リファレンス
        // `self` が存続する限り、任意のバッファ内のデータに存続します。
        &mut buffers[i]
    }
}