//! libbacktrace の DWARF 解析コードを使用した記号化戦略。
//!
//! 通常 gcc とともに配布される libbacktraceC ライブラリは、バックトレースの生成 (実際には使用しません) だけでなく、バックトレースのシンボル化と、インラインフレームなどに関するドワーフデバッグ情報の処理もサポートします。
//!
//!
//! ここではさまざまな懸念があるため、これは比較的複雑ですが、基本的な考え方は次のとおりです。
//!
//! * まず、`backtrace_syminfo` と呼びます。可能であれば、これは動的シンボルテーブルからシンボル情報を取得します。
//! * 次に、`backtrace_pcinfo` と呼びます。これにより、debuginfo テーブルが利用可能な場合に解析され、インラインフレーム、ファイル名、行番号などに関する情報を復元できるようになります。
//!
//! ドワーフテーブルを libbacktrace に入れることには多くのトリックがありますが、うまくいけば、それは世界の終わりではなく、以下を読むと十分に明確です。
//!
//! これは、非 MSVC および非 OSX プラットフォームのデフォルトの記号化戦略です。libstd では、これが OSX のデフォルトの戦略です。
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // 可能であれば、debuginfo から取得した `function` 名を優先します。これは、たとえばインラインフレームの場合は通常より正確です。
                // `symname` で指定されたシンボルテーブル名にフォールバックしても、それが存在しない場合。
                //
                // `function` は、`std::panicking::try::do_call` ではなく `try<i32,closure>` としてリストされているなど、多少精度が低いと感じる場合があることに注意してください。
                //
                // 理由は明確ではありませんが、全体的に `function` の名前の方が正確なようです。
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // 今のところ何もしません
}

/// `syminfo_cb` に渡される `data` ポインターのタイプ
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // 解決を開始するときにこのコールバックが `backtrace_syminfo` から呼び出されると、さらに `backtrace_pcinfo` を呼び出します。
    // `backtrace_pcinfo` 関数は、デバッグ情報を参照し、インラインフレームだけでなく file/line 情報の回復などを実行しようとします。
    // ただし、デバッグ情報がない場合、`backtrace_pcinfo` は失敗するか、ほとんど機能しない可能性があるため、その場合は、`syminfo_cb` から少なくとも 1 つのシンボルを使用してコールバックを呼び出す必要があります。
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `pcinfo_cb` に渡される `data` ポインターのタイプ
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API は状態の作成をサポートしていますが、状態の破棄はサポートしていません。
// 私は個人的にこれを、国家が創造され、そして永遠に生きることを意味していると解釈します。
//
// この状態をクリーンアップする at_exit() ハンドラーを登録したいのですが、libbacktrace にはそれを行う方法がありません。
//
// これらの制約があるため、この関数には静的にキャッシュされた状態があり、これが最初に要求されたときに計算されます。
//
// バックトレースはすべて連続して行われることを忘れないでください (1 つのグローバルロック)。
//
// ここでの同期の欠如は、`resolve` が外部で同期されている必要があるためであることに注意してください。
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // libbacktrace は常に同期された方法で呼び出されるため、スレッドセーフ機能を実行しないでください。
        //
        0,
        error_cb,
        ptr::null_mut(), // 追加のデータはありません
    );

    return STATE;

    // libbacktrace がまったく動作するには、現在の実行可能ファイルの DWARF デバッグ情報を見つける必要があることに注意してください。これは通常、以下を含むがこれらに限定されない多くのメカニズムを介して行われます。
    //
    // * /proc/self/exe サポートされているプラットフォームで
    // * 状態の作成時に明示的に渡されたファイル名
    //
    // libbacktrace ライブラリは、C コードの大きな塊です。これは当然、特に不正な形式の debuginfo を処理する場合に、メモリ安全性の脆弱性があることを意味します。
    // Libstd は歴史的にこれらの多くに遭遇しました。
    //
    // /proc/self/exe が使用されている場合、libbacktrace が "mostly correct" であると想定し、それ以外の場合は "attempted to be correct" dwarf デバッグ情報で奇妙なことを行わないため、通常はこれらを無視できます。
    //
    //
    // ただし、ファイル名を渡すと、一部のプラットフォーム (BSD など) では、悪意のある攻撃者が任意のファイルをその場所に配置する可能性があります。
    // これは、ファイル名について libbacktrace に通知すると、任意のファイルを使用している可能性があり、segfault が発生する可能性があることを意味します。
    // ただし、libbacktrace に何も指示しないと、/proc/self/exe のようなパスをサポートしていないプラットフォームでは何も実行されません。
    //
    // ファイル名を渡さないようにできる限り努力しますが、/proc/self/exe をまったくサポートしていないプラットフォームでは必要です。
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // 理想的には `std::env::current_exe` を使用しますが、ここでは `std` を要求できないことに注意してください。
            //
            // `_NSGetExecutablePath` を使用して、現在の実行可能パスを静的領域にロードします (小さすぎる場合は、あきらめてください)。
            //
            //
            // ここでは、破損した実行可能ファイルで死なないように libbacktrace を真剣に信頼していますが、確かにそうです...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ファイルを開くモードがあり、開いた後は削除できません。
            // これは一般的にここで必要なことです。実行可能ファイルを libbacktrace に渡した後、実行可能ファイルが下から変更されないようにし、任意のデータを libbacktrace に渡す機能 (誤って処理される可能性があります) を軽減したいからです。
            //
            //
            // ここで少しダンスをして、自分のイメージに一種のロックをかけようとしていることを考えると、次のようになります。
            //
            // * 現在のプロセスへのハンドルを取得し、そのファイル名をロードします。
            // * 適切なフラグを使用して、そのファイル名でファイルを開きます。
            // * 現在のプロセスのファイル名をリロードし、同じであることを確認します
            //
            // それがすべて合格した場合、理論的には実際にプロセスのファイルを開いており、変更されないことが保証されています。FWIW これの束は歴史的に libstd からコピーされているので、これは何が起こっていたかについての私の最良の解釈です。
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // これはスタティックメモリにあるので、返すことができます。
                static mut BUF: [i8; N] = [0; N];
                // ... そしてこれは一時的なものなのでスタック上に存在します
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle` をここで意図的にリークします。これを開くと、このファイル名のロックが保持されるためです。
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ヌル文字で終了するスライスを返したいので、すべてが入力され、それが全長に等しい場合、それは失敗と見なされます。
                //
                //
                // それ以外の場合、成功を返すときは、nul バイトがスライスに含まれていることを確認してください。
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // バックトレースエラーは現在、敷物の下で一掃されています
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API を呼び出します。これは (コードの読み取りから) `syminfo_cb` を 1 回だけ呼び出す必要があります (またはおそらくエラーで失敗します)。
    // その後、`syminfo_cb` 内でさらに処理します。
    //
    // `syminfo` はシンボルテーブルを参照し、バイナリにデバッグ情報がない場合でもシンボル名を見つけるため、これを行うことに注意してください。
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}