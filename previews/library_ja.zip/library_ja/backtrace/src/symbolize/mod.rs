use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// シンボルを指定されたクロージャに渡して、アドレスをシンボルに解決します。
///
/// この関数は、ローカルシンボルテーブル、動的シンボルテーブル、または DWARF デバッグ情報 (アクティブ化された実装に応じて) などの領域で指定されたアドレスを検索して、生成するシンボルを見つけます。
///
///
/// 解決を実行できなかった場合、クロージャーを呼び出せない場合があります。また、インライン関数の場合、クロージャーを複数回呼び出すこともできます。
///
/// 生成されたシンボルは、指定された `addr` での実行を表し、そのアドレスの file/line ペアを返します (使用可能な場合)。
///
/// `Frame` を使用している場合は、この機能の代わりに `resolve_frame` 機能を使用することをお勧めします。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
/// # Panics
///
/// この関数は、panic を絶対に使用しないように努めますが、`cb` が panics を提供した場合、一部のプラットフォームでは、二重の panic がプロセスを中止します。
/// 一部のプラットフォームは、巻き戻すことができないコールバックを内部的に使用する C ライブラリを使用するため、`cb` からパニックになると、プロセスが異常終了する可能性があります。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // トップフレームだけを見てください
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// 以前にキャプチャしたフレームをシンボルに解決し、シンボルを指定したクロージャに渡します。
///
/// この関数は、アドレスの代わりに `Frame` を引数として受け取ることを除いて、`resolve` と同じ機能を実行します。
/// これにより、バックトレースの一部のプラットフォーム実装で、より正確なシンボル情報やインラインフレームに関する情報などを提供できます。
///
/// 可能であれば、これを使用することをお勧めします。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
/// # Panics
///
/// この関数は、panic を絶対に使用しないように努めますが、`cb` が panics を提供した場合、一部のプラットフォームでは、二重の panic がプロセスを中止します。
/// 一部のプラットフォームは、巻き戻すことができないコールバックを内部的に使用する C ライブラリを使用するため、`cb` からパニックになると、プロセスが異常終了する可能性があります。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // トップフレームだけを見てください
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// スタックフレームからの IP 値は、通常、実際のスタックトレースである呼び出しの *後* の命令の (always?) です。
// これをオンにシンボル化すると、filename/line 番号が 1 つ先になり、関数の終わり近くにある場合はおそらく無効になります。
//
// これは基本的にすべてのプラットフォームに当てはまるように思われるため、解決された IP から常に 1 を減算して、命令が返されるのではなく、前の呼び出し命令に解決します。
//
//
// 理想的にはこれを行いません。
// 理想的には、ここで `resolve` API の呼び出し元が -1 を手動で実行し、現在ではなく *前の* 命令の位置情報が必要であることを説明する必要があります。
// 理想的には、実際に次の命令または現在のアドレスである場合は、`Frame` でも公開します。
//
// 今のところ、これはかなりニッチな懸念事項ですが、内部的には常に 1 を減算します。
// 消費者は働き続け、かなり良い結果を得る必要があるので、私たちは十分に良いはずです。
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` と同じですが、同期されていないため安全ではありません。
///
/// この関数には同期保証はありませんが、この crate の `std` 機能がコンパイルされていない場合に使用できます。
/// その他のドキュメントと例については、`resolve` 関数を参照してください。
///
/// # Panics
///
/// `cb` のパニックに関する警告については、`resolve` に関する情報を参照してください。
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` と同じですが、同期されていないため安全ではありません。
///
/// この関数には同期保証はありませんが、この crate の `std` 機能がコンパイルされていない場合に使用できます。
/// その他のドキュメントと例については、`resolve_frame` 関数を参照してください。
///
/// # Panics
///
/// `cb` のパニックに関する警告については、`resolve_frame` に関する情報を参照してください。
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ファイル内のシンボルの解像度を表す trait。
///
/// この trait は、`backtrace::resolve` 関数に与えられたクロージャに対する trait オブジェクトとして生成され、その背後にある実装が不明であるため、事実上ディスパッチされます。
///
///
/// シンボルは、名前、ファイル名、行番号、正確なアドレスなど、関数に関するコンテキスト情報を提供できます。
/// ただし、すべての情報がシンボルで常に利用できるわけではないため、すべてのメソッドが `Option` を返します。
///
///
pub struct Symbol {
    // TODO: このライフタイムバウンドは、最終的に `Symbol` まで持続する必要があります。
    // しかし、それは現在、重大な変更です。
    // `Symbol` は参照によってのみ配布され、複製できないため、今のところこれは安全です。
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// この関数の名前を返します。
    ///
    /// 返された構造を使用して、シンボル名に関するさまざまなプロパティを照会できます。
    ///
    ///
    /// * `Display` 実装は、デマングルされたシンボルを出力します。
    /// * シンボルの生の `str` 値にアクセスできます (有効な utf-8 の場合)。
    /// * シンボル名の生のバイトにアクセスできます。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// この関数の開始アドレスを返します。
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// 生のファイル名をスライスとして返します。
    /// これは主に `no_std` 環境で役立ちます。
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// このシンボルが現在実行されている場所の列番号を返します。
    ///
    /// 現在、gimli のみがここで値を提供し、`filename` が `Some` を返す場合にのみ値を提供するため、同様の警告が発生します。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// このシンボルが現在実行されている場所の行番号を返します。
    ///
    /// `filename` が `Some` を返す場合、この戻り値は通常 `Some` であるため、同様の警告が発生します。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// この関数が定義されたファイル名を返します。
    ///
    /// これは現在、libbacktrace または gimli が使用されている場合にのみ使用できます (例:
    /// unix その他のプラットフォーム) およびバイナリが debuginfo でコンパイルされる場合。
    /// これらの条件のいずれも満たされない場合、`None` が返される可能性があります。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // マングルされたシンボルを Rust として解析できなかった場合は、解析された C++ シンボルである可能性があります。
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // `cpp_demangle` 機能を無効にしてもコストがかからないように、このゼロサイズを維持するようにしてください。
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// デマングルされた名前、生のバイト、生の文字列などへの人間工学的アクセサを提供するためのシンボル名のラッパー。
///
// `cpp_demangle` 機能が有効になっていない場合のデッドコードを許可します。
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// 基になる生のバイトから新しいシンボル名を作成します。
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// シンボルが有効な utf-8 の場合、生の (mangled) シンボル名を `str` として返します。
    ///
    /// デマングルバージョンが必要な場合は、`Display` 実装を使用してください。
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// 生のシンボル名をバイトのリストとして返します
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // これは、デマングルされたシンボルが実際に有効でない場合に印刷される可能性があるため、ここでエラーを外側に伝播しないようにして、エラーを適切に処理します。
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// アドレスをシンボリック化するために使用されたキャッシュメモリを再利用してみてください。
///
/// このメソッドは、通常は解析された DWARF 情報などを表す、グローバルまたはスレッドにキャッシュされているグローバルデータ構造を解放しようとします。
///
///
/// # Caveats
///
/// この関数は常に使用可能ですが、ほとんどの実装では実際には何もしません。
/// dbghelp や libbacktrace のようなライブラリは、状態の割り当てを解除し、割り当てられたメモリを管理する機能を提供しません。
/// 今のところ、この crate の `gimli-symbolize` 機能は、この機能が効果を発揮する唯一の機能です。
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}