use core::ffi::c_void;
use core::fmt;

/// 現在のコールスタックを検査し、スタックトレースを計算するために提供されたクロージャにすべてのアクティブなフレームを渡します。
///
/// この関数は、プログラムのスタックトレースを計算する際のこのライブラリの主力製品です。指定されたクロージャ `cb` は、スタック上のその呼び出しフレームに関する情報を表す `Frame` のインスタンスを生成します。
/// クロージャはトップダウン方式でフレームを生成します (最近では関数が最初に呼び出されます)。
///
/// クロージャの戻り値は、バックトレースを続行する必要があるかどうかを示します。`false` の戻り値は、バックトレースを終了し、すぐに戻ります。
///
/// `Frame` を取得したら、`backtrace::resolve` を呼び出して、`ip` (命令ポインタ) またはシンボルアドレスを、名前やファイル名 / 行番号を学習できる `Symbol` に変換することをお勧めします。
///
///
/// これは比較的低レベルの関数であり、たとえば、後で検査するためにバックトレースをキャプチャする場合は、`Backtrace` タイプの方が適切な場合があります。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
/// # Panics
///
/// この関数は、panic を絶対に使用しないように努めますが、`cb` が panics を提供した場合、一部のプラットフォームでは、二重の panic がプロセスを中止します。
/// 一部のプラットフォームは、巻き戻すことができないコールバックを内部的に使用する C ライブラリを使用するため、`cb` からパニックになると、プロセスが異常終了する可能性があります。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // バックトレースを続ける
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// `trace` と同じですが、同期されていないため安全ではありません。
///
/// この関数には同期保証はありませんが、この crate の `std` 機能がコンパイルされていない場合に使用できます。
/// その他のドキュメントと例については、`trace` 関数を参照してください。
///
/// # Panics
///
/// `cb` のパニックに関する警告については、`trace` に関する情報を参照してください。
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// バックトレースの 1 フレームを表す trait は、この crate の `trace` 関数に生成されます。
///
/// トレース関数のクロージャはフレームを生成し、基になる実装は実行時まで常に認識されているとは限らないため、フレームは仮想的にディスパッチされます。
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// このフレームの現在の命令ポインタを返します。
    ///
    /// これは通常、フレーム内で実行する次の命令ですが、すべての実装が 100％の精度でこれをリストしているわけではありません (ただし、一般的にはかなり近いです)。
    ///
    ///
    /// この値を `backtrace::resolve` に渡して、シンボル名に変換することをお勧めします。
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// このフレームの現在のスタックポインタを返します。
    ///
    /// バックエンドがこのフレームのスタックポインタを回復できない場合、null ポインタが返されます。
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// この関数のフレームの開始シンボルアドレスを返します。
    ///
    /// これにより、`ip` によって返された命令ポインターが関数の先頭に巻き戻され、その値が返されます。
    ///
    /// ただし、場合によっては、バックエンドはこの関数から `ip` を返すだけです。
    ///
    /// 上記の `ip` で `backtrace::resolve` が失敗した場合、戻り値が使用されることがあります。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// フレームが属するモジュールのベースアドレスを返します。
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Miri がホストプラットフォームよりも優先されるようにするには、これを最初に行う必要があります
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // dbghelp でのみ使用される symbolize
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}