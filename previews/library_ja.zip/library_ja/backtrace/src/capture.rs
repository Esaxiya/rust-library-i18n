use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// 所有され、自己完結型のバックトレースの表現。
///
/// この構造を使用して、プログラムのさまざまなポイントでバックトレースをキャプチャし、後でその時点でのバックトレースを検査するために使用できます。
///
///
/// `Backtrace` `Debug` 実装によるバックトレースのプリティプリントをサポートします。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ここのフレームは、スタックの上から下にリストされています
    frames: Vec<BacktraceFrame>,
    // 私たちが信じるインデックスは、`Backtrace::new` や `backtrace::trace` のようなフレームを省略した、バックトレースの実際の開始です。
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// バックトレースでキャプチャされたフレームのバージョン。
///
/// このタイプは `Backtrace::frames` からリストとして返され、キャプチャされたバックトレース内の 1 つのスタックフレームを表します。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// バックトレース内のシンボルのキャプチャバージョン。
///
/// このタイプは `BacktraceFrame::symbols` からリストとして返され、バックトレース内のシンボルのメタデータを表します。
///
/// # 必要な機能
///
/// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// この関数の呼び出しサイトでバックトレースをキャプチャし、所有されている表現を返します。
    ///
    /// この関数は、バックトレースを Rust のオブジェクトとして表す場合に役立ちます。この戻り値は、スレッド間で送信して他の場所に出力できます。この値の目的は、完全に自己完結することです。
    ///
    /// 一部のプラットフォームでは、完全なバックトレースを取得して解決すると、非常にコストがかかる可能性があることに注意してください。
    /// アプリケーションにとってコストが高すぎる場合は、代わりに `Backtrace::new_unresolved()` を使用することをお勧めします。これにより、シンボル解決ステップ (通常は最も時間がかかります) が回避され、後日延期できます。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // 削除するフレームがここにあることを確認したい
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` と同様ですが、シンボルを解決しない点が異なりますが、これは単にバックトレースをアドレスのリストとしてキャプチャします。
    ///
    /// 後で `resolve` 関数を呼び出して、このバックトレースのシンボルを読み取り可能な名前に解決できます。
    /// この機能が存在するのは、解決プロセスにかなりの時間がかかる場合があるのに対し、1 つのバックトレースが出力されることはめったにない場合があるためです。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // シンボル名なし
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // シンボル名が表示されるようになりました
    /// ```
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    ///
    #[inline(never)] // 削除するフレームがここにあることを確認したい
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// このバックトレースがキャプチャされたときのフレームを返します。
    ///
    /// このスライスの最初のエントリは関数 `Backtrace::new` である可能性が高く、最後のフレームはこのスレッドまたはメイン関数がどのように開始されたかに関するものである可能性があります。
    ///
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// このバックトレースが `new_unresolved` から作成された場合、この関数はバックトレース内のすべてのアドレスをそれらのシンボリック名に解決します。
    ///
    ///
    /// このバックトレースが以前に解決されているか、`new` を介して作成されている場合、この関数は何もしません。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// このフレームが対応するシンボルのリストを返します。
    ///
    /// 通常、フレームごとに 1 つのシンボルしかありませんが、複数の関数が 1 つのフレームにインライン化されると、複数のシンボルが返される場合があります。
    /// リストされている最初のシンボルは "innermost function" ですが、最後のシンボルは最も外側 (最後の呼び出し元) です。
    ///
    /// このフレームが未解決のバックトレースからのものである場合、これは空のリストを返すことに注意してください。
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` と同じ
    ///
    /// # 必要な機能
    ///
    /// この機能を使用するには、`backtrace` crate の `std` 機能を有効にする必要があり、`std` 機能はデフォルトで有効になっています。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // パスを印刷するときは、cwd が存在する場合はそれを削除しようとします。それ以外の場合は、パスをそのまま印刷します。
        // また、これは短い形式でのみ行うことに注意してください。これは、いっぱいになった場合、おそらくすべてを印刷したいためです。
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}