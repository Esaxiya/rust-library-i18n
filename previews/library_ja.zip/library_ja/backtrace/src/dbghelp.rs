//! Windows での dbghelp バインディングの管理を支援するモジュール
//!
//! Windows (少なくとも MSVC の場合) のバックトレースは、主に `dbghelp.dll` とそれに含まれるさまざまな機能を介して実行されます。
//! これらの関数は現在、`dbghelp.dll` に静的にリンクするのではなく、*動的に* ロードされます。
//! これは現在、標準ライブラリによって実行されています (理論的にはそこで必要です) が、バックトレースは通常かなりオプションであるため、ライブラリの静的 dll 依存関係を減らすための取り組みです。
//!
//! そうは言っても、`dbghelp.dll` はほとんどの場合 Windows に正常にロードされます。
//!
//! ただし、このすべてのサポートを動的にロードしているため、`winapi` で生の定義を実際に使用することはできません。むしろ、関数ポインター型を自分で定義して使用する必要があります。
//! 私たちは本当に winapi を複製するビジネスに従事したくないので、すべてのバインディングが winapi のバインディングと一致し、この機能が CI で有効になっていることを表明する Cargo 機能 `verify-winapi` があります。
//!
//! 最後に、`dbghelp.dll` の dll がアンロードされることはなく、現在は意図的なものであることに注意してください。
//! 考えは、それをグローバルにキャッシュし、API の呼び出しの間に使用して、高価な loads/unloads を回避できるということです。
//! これがリークディテクタなどの問題である場合は、そこに着いたときに橋を渡ることができます。
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Winapi 自体に存在しない `SymGetOptions` および `SymSetOptions` を回避します。
// それ以外の場合、これは、winapi に対して型を再確認する場合にのみ使用されます。
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // winapi ではまだ定義されていません
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // これは winapi で定義されていますが、正しくありません (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // winapi ではまだ定義されていません
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// このマクロは、ロードする可能性のあるすべての関数ポインターを内部的に含む `Dbghelp` 構造を定義するために使用されます。
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` 用にロードされた DLL
            dll: HMODULE,

            // 使用する可能性のある各関数の各関数ポインター
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // 最初は DLL をロードしていません
            dll: 0 as *mut _,
            // 最初は、すべての関数がゼロに設定されており、動的にロードする必要があることを示しています。
            //
            $($name: 0,)*
        };

        // 各関数タイプの便利な typedef。
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` を開こうとします。
            /// 動作する場合は成功を返し、`LoadLibraryW` が失敗する場合はエラーを返します。
            ///
            /// ライブラリがすでにロードされている場合は Panics。
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // 使用したいメソッドごとの関数。
            // 呼び出されると、キャッシュされた関数ポインタを読み取るか、ロードしてロードされた値を返します。
            // ロードは成功するようにアサートされます。
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // クリーンアップロックを使用して dbghelp 関数を参照するための便利なプロキシ。
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// この crate から `dbghelp` API 関数にアクセスするために必要なすべてのサポートを初期化します。
///
///
/// この関数は **安全** であり、内部的に独自の同期があることに注意してください。
/// また、この関数を再帰的に複数回呼び出すのが安全であることに注意してください。
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // 最初に行う必要があるのは、この関数を同期することです。これは、他のスレッドから同時に呼び出すことも、1 つのスレッド内で再帰的に呼び出すこともできます。
        // ただし、ここで使用している `dbghelp` は、このプロセスで `dbghelp` の他のすべての呼び出し元と同期する必要があるため、これよりも注意が必要です。
        //
        // 通常、同じプロセス内で `dbghelp` への呼び出しはそれほど多くはなく、`dbghelp` にアクセスしているのは私たちだけであると安全に推測できます。
        // ただし、皮肉なことに、標準ライブラリには、心配しなければならない主要な他のユーザーが 1 人います。
        // Rust 標準ライブラリは、バックトレースのサポートをこの crate に依存しており、この crate は crates.io にも存在します。
        // これは、標準ライブラリが panic バックトレースを出力している場合、crates.io からのこの crate と競合し、segfault を引き起こす可能性があることを意味します。
        //
        // この同期の問題を解決するために、ここでは Windows 固有のトリックを採用しています (結局のところ、同期に関する Windows 固有の制限です)。
        // この呼び出しを保護するために、mutex という名前の *session-local* を作成します。
        // ここでの目的は、標準ライブラリとこの crate がここで同期するために Rust レベルの API を共有する必要はなく、代わりにバックグラウンドで動作して、相互に同期していることを確認できることです。
        //
        // そうすれば、この関数が標準ライブラリまたは crates.io を介して呼び出されたときに、同じミューテックスが取得されていることを確認できます。
        //
        // つまり、ここで最初に行うことは、Windows 上に名前付きミューテックスである `HANDLE` をアトミックに作成することです。
        // この関数を具体的に共有する他のスレッドとビットを同期し、この関数のインスタンスごとに 1 つのハンドルのみが作成されるようにします。
        // ハンドルがグローバルに保存されると、ハンドルが閉じられることはないことに注意してください。
        //
        // 実際にロックをかけた後、それを取得するだけで、配布する `Init` ハンドルが最終的にロックをドロップする責任を負います。
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // わかった、おい! すべてが安全に同期されたので、実際にすべての処理を開始しましょう。
        // まず、`dbghelp.dll` がこのプロセスで実際にロードされていることを確認する必要があります。
        // 静的な依存関係を回避するために、これを動的に行います。
        // これは歴史的に奇妙なリンクの問題を回避するために行われており、これは主に単なるデバッグユーティリティであるため、バイナリをもう少し移植可能にすることを目的としています。
        //
        //
        // `dbghelp.dll` を開いたら、その中でいくつかの初期化関数を呼び出す必要があります。これについては、以下で詳しく説明します。
        // ただし、これは 1 回だけ行うため、まだ完了しているかどうかを示すグローバルブール値があります。
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` フラグが設定されていることを確認してください。これに関する MSVC の独自のドキュメントによると、"This is the fastest, most efficient way to use the symbol handler." なので、それを実行しましょう。
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // 実際に MSVC でシンボルを初期化します。これは失敗する可能性がありますが、無視することに注意してください。
        // これ自体には多くの先行技術はありませんが、LLVM は内部的にここでの戻り値を無視しているようで、これが失敗した場合、LLVM のサニタイザーライブラリの 1 つは恐ろしい警告を出力しますが、基本的に長期的には無視します。
        //
        //
        // これが Rust でよく発生するケースのひとつは、標準ライブラリと crates.io 上のこの crate の両方が `SymInitializeW` をめぐって競合したいということです。
        // 標準ライブラリは、これまでほとんどの場合、初期化してからクリーンアップすることを望んでいましたが、この crate を使用するようになったため、誰かが最初に初期化を開始し、もう一方がその初期化を取得します。
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}