use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr は、プロセスにリンクされているすべての DSO の dl_phdr_info ポインターを受け取るコールバックを受け取ります。
    // dl_iterate_phdr は、動的リンカーが反復の開始から終了までロックされることも保証します。
    // コールバックがゼロ以外の値を返す場合、反復は早期に終了します。
    // 'data' 各呼び出しのコールバックへの 3 番目の引数として渡されます。
    // 'size' dl_phdr_info のサイズを示します。
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ビルド ID といくつかの基本的なプログラムヘッダーデータを解析する必要があります。つまり、ELF 仕様からも少しのものが必要です。
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ここで、フクシアの現在のダイナミックリンカーで使用されている dl_phdr_info タイプの構造をビットごとに複製する必要があります。
// Chromium には、この ABI 境界とクラッシュパッドもあります。
// 最終的には、これらのケースを elf-search を使用するように移動したいと思いますが、SDK で提供する必要があり、まだ実行されていません。
//
// したがって、私たち (および彼ら) は、フクシア libc との緊密な結合を招くこの方法を使用しなければならないことに固執しています。
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // e_phoff と e_phnum が有効かどうかを確認する方法はありません。
    // ただし、libc はこれを保証する必要があるため、ここでスライスを作成しても安全です。
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr は、ターゲットアーキテクチャのエンディアンにおける 64 ビット ELF プログラムヘッダーを表します。
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr は、有効な ELF プログラムヘッダーとその内容を表します。
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // p_addr または p_memsz が有効かどうかを確認する方法はありません。
    // Fuchsia の libc は最初にメモを解析しますが、ここにあるため、これらのヘッダーは有効である必要があります。
    //
    // NoteIter は、基礎となるデータが有効である必要はありませんが、境界が有効である必要があります。
    // 私たちは、libc がこれがここでの私たちの場合であることを保証したと信じています。
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ビルド ID のメモタイプ。
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr は、ターゲットのエンディアンの ELF ノートヘッダーを表します。
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note は ELF ノート (ヘッダー + コンテンツ) を表します。
// 名前は常に null で終了するわけではなく、rust を使用すると、バイトがどちらの方法でも一致することを簡単に確認できるため、名前は u8 スライスとして残されます。
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter を使用すると、ノートセグメントを安全に反復できます。
// エラーが発生するか、メモがなくなるとすぐに終了します。
// 無効なデータを繰り返すと、メモが見つからなかったかのように機能します。
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // 指定されたポインターとサイズが、すべて読み取ることができる有効なバイト範囲を示すことは、関数の不変条件です。
    // これらのバイトの内容は何でもかまいませんが、これを安全にするには範囲が有効である必要があります。
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to は、'to' が 2 の累乗であると仮定して、'x' を ' から ' へのバイトアラインメントにアラインメントします。
// これは、(x + to、1)＆-to が使用される C/C ++ ELF 解析コードの標準パターンに従います。
// Rust は使用を否定できないので、私は使用します
// 2 の補数変換でそれを再現します。
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 は、スライス (存在する場合) から num バイトを消費し、さらに最終スライスが適切に整列されていることを確認します。
// 要求されたバイト数が多すぎるか、残りのバイトが十分に存在しないためにスライスを後で再調整できない場合、None が返され、スライスは変更されません。
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// この関数には、'bytes' をパフォーマンス (および一部のアーキテクチャーの正確さ) のために調整する必要があることを除いて、呼び出し元が支持しなければならない実際の不変条件はありません。
// Elf_Nhdr フィールドの値は意味がないかもしれませんが、この関数はそのようなことを保証しません。
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // これは十分なスペースがある限り安全であり、上記の if ステートメントでこれが安全でないことはないことを確認しました。
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // sice_of: : に注意してください <Elf_Nhdr> () は常に 4 バイトに揃えられます。
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // 終わりに達したかどうかを確認します。
        if self.base.len() == 0 || self.error {
            return None;
        }
        // nhdr を変換しますが、結果の構造体を慎重に検討します。
        // 私たちは namesz や descsz を信頼せず、タイプに基づいて危険な決定を下すことはありません。
        //
        // ですから、完全なゴミを出しても安全なはずです。
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// セグメントが実行可能であることを示します。
const PERM_X: u32 = 0b00000001;
/// セグメントが書き込み可能であることを示します。
const PERM_W: u32 = 0b00000010;
/// セグメントが読み取り可能であることを示します。
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// 実行時の ELF セグメントを表します。
struct Segment {
    /// このセグメントのコンテンツの実行時仮想アドレスを提供します。
    addr: usize,
    /// このセグメントのコンテンツのメモリサイズを示します。
    size: usize,
    /// ELF ファイルでこのセグメントのモジュール仮想アドレスを提供します。
    mod_rel_addr: usize,
    /// ELF ファイルにあるアクセス許可を付与します。
    /// ただし、これらのアクセス許可は、必ずしも実行時に存在するアクセス許可ではありません。
    flags: Perm,
}

/// DSO からのセグメントを反復処理できます。
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (動的共有オブジェクト) を表します。
/// このタイプは、独自のコピーを作成するのではなく、実際の DSO に格納されているデータを参照します。
struct Dso<'a> {
    /// ダイナミックリンカは、名前が空であっても、常に名前を提供します。
    /// メイン実行可能ファイルの場合、この名前は空になります。
    /// 共有オブジェクトの場合、それは soname になります (DT_SONAME を参照)。
    name: &'a str,
    /// フクシアでは、事実上すべてのバイナリにビルド ID がありますが、これは厳密な要件ではありません。
    /// build_id がない場合、後で DSO 情報を実際の ELF ファイルと照合する方法はないため、すべての DSO にここに 1 つある必要があります。
    ///
    /// build_id のない DSO は無視されます。
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// この DSO のセグメントに対するイテレータを返します。
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// これらのエラーは、各 DSO に関する情報の解析中に発生する問題をエンコードします。
///
enum Error {
    /// NameError は、C スタイルの文字列を rust 文字列に変換中にエラーが発生したことを意味します。
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError は、ビルド ID が見つからなかったことを意味します。
    /// これは、DSO にビルド ID がないか、ビルド ID を含むセグメントの形式が正しくないことが原因である可能性があります。
    ///
    BuildIDError,
}

/// 動的リンカーによってプロセスにリンクされた DSO ごとに 'dso' または 'error' のいずれかを呼び出します。
///
///
/// # Arguments
///
/// * `visitor` - foreachDSO と呼ばれる eats メソッドの 1 つを持つ DsoPrinter。
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr は、info.name が有効な場所を指すようにします。
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// この関数は、DSO に含まれるすべての情報の Fuchsia シンボライザーマークアップを出力します。
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}