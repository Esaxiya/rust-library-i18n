use backtrace::Backtrace;

// 50 文字のモジュール名
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50 文字の構造体名
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// 長い関数名は (MAX_SYM_NAME、1) 文字に切り捨てる必要があります。
// gnu はすべてのフレームに対して "<no info>" を出力するため、このテストは msvc に対してのみ実行してください。
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 構造体名が 10 回繰り返されるため、完全修飾関数名は少なくとも 10 *(50 + 50)* 2=2000 文字の長さになります。
    //
    // `::`、`<>`、および現在のモジュールの名前も含まれているため、実際には長くなります
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}