use backtrace::Backtrace;

// このテストは、シンボルの開始アドレスを報告するフレームに対して `symbol_address` 機能が機能しているプラットフォームでのみ機能します。
// その結果、いくつかのプラットフォームでのみ有効になります。
//
const ENABLED: bool = cfg!(all(
    // Windows は実際にはテストされておらず、OSX は実際に囲んでいるフレームを見つけることをサポートしていないため、これを無効にします
    //
    target_os = "linux",
    // ARM では、囲んでいる関数を見つけることは、単に IP 自体を返すことです。
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}