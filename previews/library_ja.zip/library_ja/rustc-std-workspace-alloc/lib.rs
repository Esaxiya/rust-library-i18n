#![feature(no_core)]
#![no_core]

// この crate が必要な理由については、rustc-std-workspace-core を参照してください。

// liballoc の alloc モジュールとの競合を避けるために、crate の名前を変更します。
extern crate alloc as foo;

pub use foo::*;