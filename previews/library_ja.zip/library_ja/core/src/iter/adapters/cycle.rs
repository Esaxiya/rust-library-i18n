use crate::{iter::FusedIterator, ops::Try};

/// 際限なく繰り返されるイテレータ。
///
/// この `struct` は、[`Iterator`] の [`cycle`] メソッドによって作成されます。
/// 詳細については、そのドキュメントを参照してください。
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // サイクルイテレータが空または無限のいずれか
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // 現在のイテレータを完全に繰り返します。
        // `self.orig` が空でない場合でも、`self.iter` が空になる可能性があるため、これが必要です。
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // サイクルされたイテレーターが空であるかどうかを追跡しながら、完全なサイクルを完了します。
        // 無限ループを防ぐために、イテレーターが空の場合は早期に戻る必要があります
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` は `Cycle` にはあまり意味がなく、デフォルトよりも優れた方法はないため、`fold` のオーバーライドはありません。
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}