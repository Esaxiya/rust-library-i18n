use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// この trait は、次のような条件下で、インタラタアダプタパイプラインのソースステージへの一時的なアクセスを提供します。
/// * イテレータソース `S` 自体が `SourceIter<Source = S>` を実装します
/// * ソースとパイプラインコンシューマーの間のパイプライン内のアダプターごとに、この trait の委任実装があります。
///
/// ソースが所有するイテレータ構造体 (一般に `IntoIter` と呼ばれる) である場合、これは [`FromIterator`] 実装を特殊化する場合、またはイテレータが部分的に使い果たされた後に残りの要素を回復する場合に役立ちます。
///
///
/// 実装は、パイプラインの最も内側のソースへのアクセスを必ずしも提供する必要がないことに注意してください。ステートフル中間アダプターは、パイプラインの一部を熱心に評価し、その内部ストレージをソースとして公開する場合があります。
///
/// 実装者は追加の安全特性を維持する必要があるため、trait は安全ではありません。
/// 詳細については、[`as_inner`] を参照してください。
///
/// # Examples
///
/// 部分的に消費されたソースの取得:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// イテレーターパイプラインのソースステージ。
    type Source: Iterator;

    /// イテレータパイプラインのソースを取得します。
    ///
    /// # Safety
    ///
    /// の実装は、呼び出し元によって置き換えられない限り、存続期間中同じ可変参照を返す必要があります。
    /// 呼び出し元は、反復を停止したときにのみ参照を置き換え、ソースを抽出した後にイテレーターパイプラインを削除できます。
    ///
    /// つまり、イテレーターアダプターは、反復中に変更されないソースに依存できますが、Drop 実装ではソースに依存できません。
    ///
    /// このメソッドを実装するということは、アダプターがソースへのプライベートのみのアクセスを放棄し、メソッドレシーバータイプに基づいて行われた保証にのみ依存できることを意味します。
    /// アクセスが制限されていないため、アダプターは、内部にアクセスできる場合でも、ソースのパブリック API を維持する必要があります。
    ///
    /// 呼び出し元は、ソースとソースの間にあるアダプターが同じアクセス権を持っているため、ソースがパブリック API と一致する任意の状態にあることを期待する必要があります。
    /// 特に、アダプターが厳密に必要以上の要素を消費した可能性があります。
    ///
    /// これらの要件の全体的な目標は、パイプラインの消費者が使用できるようにすることです。
    /// * 反復が停止した後にソースに残っているものは何でも
    /// * 消費イテレータを進めることによって未使用になったメモリ
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// 基礎となるイテレーターが `Result::Ok` 値を生成する限り、出力を生成するイテレーターアダプター。
///
///
/// エラーが発生した場合、イテレーターは停止し、エラーが保存されます。
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// 指定されたイテレーターを、`Result<T, _>` ではなく `T` が生成されたかのように処理します。
/// エラーが発生すると、内部イテレーターが停止し、全体的な結果がエラーになります。
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}