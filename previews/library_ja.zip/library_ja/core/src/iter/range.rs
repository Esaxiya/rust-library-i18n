use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *後続* および *先行* 操作の概念を持つオブジェクト。
///
/// *後続* 操作は、より大きく比較される値に向かって移動します。
/// *先行* 操作は、比較の少ない値に向かって移動します。
///
/// # Safety
///
/// この trait は、`unsafe trait TrustedLen` 実装の安全性のためにその実装が正しい必要があるため、`unsafe` です。それ以外の場合、この trait を使用した結果は、`unsafe` コードによって正しく信頼され、リストされた義務を果たします。
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` から `end` に到達するために必要な *後続* ステップの数を返します。
    ///
    /// ステップ数が `usize` をオーバーフローする場合 (または無限である場合、または `end` に到達しない場合)、`None` を返します。
    ///
    ///
    /// # Invariants
    ///
    /// `a`、`b`、および `n` の場合:
    ///
    /// * `steps_between(&a, &b) == Some(n)` `Step::forward_checked(&a, n) == Some(b)` の場合のみ
    /// * `steps_between(&a, &b) == Some(n)` `Step::backward_checked(&a, n) == Some(a)` の場合のみ
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` の場合のみ
    ///   * 当然の結果: `a == b` の場合に限り `steps_between(&a, &b) == Some(0)`
    ///   * `a <= b` は _not_ が `steps_between(&a, &b) != None` を意味することに注意してください。
    ///     これは、`b` に到達するために `usize::MAX` ステップ以上が必要になる場合です。
    /// * `steps_between(&a, &b) == None` `a > b` の場合
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` 回の *後続* を取得することによって取得される値を返します。
    ///
    /// これが `Self` でサポートされる値の範囲をオーバーフローする場合は、`None` を返します。
    ///
    /// # Invariants
    ///
    /// `a`、`n`、および `m` の場合:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` がオーバーフローしない `a`、`n`、および `m` の場合:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// `a` および `n` の場合:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` 回の *後続* を取得することによって取得される値を返します。
    ///
    /// これが `Self` でサポートされる値の範囲をオーバーフローする場合、この関数は panic、ラップ、または飽和することが許可されます。
    ///
    /// 推奨される動作は、デバッグアサーションが有効になっている場合は panic に、それ以外の場合はラップまたは飽和することです。
    ///
    /// 安全でないコードは、オーバーフロー後の動作の正確さに依存するべきではありません。
    ///
    /// # Invariants
    ///
    /// オーバーフローが発生しない `a`、`n`、および `m` の場合:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// オーバーフローが発生しない `a` および `n` の場合:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` 回の *後続* を取得することによって取得される値を返します。
    ///
    /// # Safety
    ///
    /// `Self` でサポートされている値の範囲をオーバーフローさせることは、この操作の未定義の動作です。
    /// これがオーバーフローしないことを保証できない場合は、代わりに `forward` または `forward_checked` を使用してください。
    ///
    /// # Invariants
    ///
    /// `a` の場合:
    ///
    /// * `b > a` のような `b` が存在する場合は、`Step::forward_unchecked(a, 1)` を呼び出しても安全です。
    /// * `steps_between(&a, &b) == Some(n)` のような `b`、`n` が存在する場合は、任意の `m <= n` に対して `Step::forward_unchecked(a, m)` を呼び出しても安全です。
    ///
    ///
    /// オーバーフローが発生しない `a` および `n` の場合:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` と同等です
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` 回の *先行* を取得することによって取得される値を返します。
    ///
    /// これが `Self` でサポートされる値の範囲をオーバーフローする場合は、`None` を返します。
    ///
    /// # Invariants
    ///
    /// `a`、`n`、および `m` の場合:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// `a` および `n` の場合:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` 回の *先行* を取得することによって取得される値を返します。
    ///
    /// これが `Self` でサポートされる値の範囲をオーバーフローする場合、この関数は panic、ラップ、または飽和することが許可されます。
    ///
    /// 推奨される動作は、デバッグアサーションが有効になっている場合は panic に、それ以外の場合はラップまたは飽和することです。
    ///
    /// 安全でないコードは、オーバーフロー後の動作の正確さに依存するべきではありません。
    ///
    /// # Invariants
    ///
    /// オーバーフローが発生しない `a`、`n`、および `m` の場合:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// オーバーフローが発生しない `a` および `n` の場合:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` 回の *先行* を取得することによって取得される値を返します。
    ///
    /// # Safety
    ///
    /// `Self` でサポートされている値の範囲をオーバーフローさせることは、この操作の未定義の動作です。
    /// これがオーバーフローしないことを保証できない場合は、代わりに `backward` または `backward_checked` を使用してください。
    ///
    /// # Invariants
    ///
    /// `a` の場合:
    ///
    /// * `b < a` のような `b` が存在する場合は、`Step::backward_unchecked(a, 1)` を呼び出しても安全です。
    /// * `steps_between(&b, &a) == Some(n)` のような `b`、`n` が存在する場合は、任意の `m <= n` に対して `Step::backward_unchecked(a, m)` を呼び出しても安全です。
    ///
    ///
    /// オーバーフローが発生しない `a` および `n` の場合:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` と同等です
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// 整数リテラルはさまざまなタイプに解決されるため、これらは引き続きマクロで生成されます。
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // 安全性: 発信者は、`start + n` がオーバーフローしないことを保証する必要があります。
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // 安全性: 発信者は、`start - n` がオーバーフローしないことを保証する必要があります。
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // デバッグビルドでは、オーバーフロー時に panic をトリガーします。
            // これは、リリースビルドで完全に最適化されるはずです。
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // 数学をラッピングして、たとえば `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // デバッグビルドでは、オーバーフロー時に panic をトリガーします。
            // これは、リリースビルドで完全に最適化されるはずです。
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // 数学をラッピングして、たとえば `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // これは $u_narrower <=usize に依存しています
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n が範囲外の場合、`unsigned_start + n` も範囲外です
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n が範囲外の場合、`unsigned_start - n` も範囲外です
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // これは $i_narrower <=usize に依存しています
                        //
                        // isize にキャストすると幅が広がりますが、符号は保持されます。
                        // isize スペースで wrapping_sub を使用し、isize にキャストして、isize の範囲内に収まらない可能性のある差を計算します。
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ラッピングは、200 が i8 の範囲外であっても、`Step::forward(-120_i8, 200) == Some(80_i8)` のようなケースを処理します。
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // 足し算があふれました
                            }
                        }
                        // n が eg の範囲外の場合
                        // u8, その場合、i8 の全範囲よりも大きいため、`any_i8 + n` は必然的に i8 をオーバーフローします。
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ラッピングは、200 が i8 の範囲外であっても、`Step::forward(-120_i8, 200) == Some(80_i8)` のようなケースを処理します。
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // 減算があふれました
                            }
                        }
                        // n が eg の範囲外の場合
                        // u8, その場合、i8 の全範囲よりも大きいため、`any_i8 - n` は必然的に i8 をオーバーフローします。
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // 差が大きすぎる場合など
                            // i128、それはまた、より少ないビットで使用するには大きすぎるでしょう。
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // 安全性: res は有効な Unicode スカラーです
            // (0x110000 より下で、0xD800..0xE000 にはありません)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // 安全性: res は有効な Unicode スカラーです
        // (0x110000 より下で、0xD800..0xE000 にはありません)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // 安全性: 発信者はこれがオーバーフローしないことを保証する必要があります
        // 文字の値の範囲。
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // 安全性: 発信者はこれがオーバーフローしないことを保証する必要があります
            // 文字の値の範囲。
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // 安全性: 以前の契約により、これは保証されています
        // 呼び出し元によって有効な文字になります。
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // 安全性: 発信者はこれがオーバーフローしないことを保証する必要があります
        // 文字の値の範囲。
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // 安全性: 発信者はこれがオーバーフローしないことを保証する必要があります
            // 文字の値の範囲。
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // 安全性: 以前の契約により、これは保証されています
        // 呼び出し元によって有効な文字になります。
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // 安全性: 前提条件を確認しました
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // 安全性: 前提条件を確認しました
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// これらのマクロは、さまざまな範囲タイプの `ExactSizeIterator` impl を生成します。
//
// * `ExactSizeIterator::len` 常に正確な `usize` を返す必要があるため、範囲を `usize::MAX` より長くすることはできません。
//
// * `Range<_>` の整数型の場合、これは `usize` より狭いまたは広い型の場合です。
//   `RangeInclusive<_>` の整数型の場合、これは `usize` よりも *厳密に狭い* 型の場合です。
//   `(0..=u64::MAX).len()` `u64::MAX + 1` になります。
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // これらは上記の理由から正しくありませんが、Rust 1.0.0 で安定しているため、これらを削除すると重大な変更になります。
    // だから例えば
    // `(0..66_000_u32).len()` たとえば、16 ビットプラットフォームではエラーや警告なしでコンパイルされますが、間違った結果が表示され続けます。
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // これらは上記の理由から正しくありませんが、Rust 1.26.0 で安定しているため、これらを削除すると重大な変更になります。
    // だから例えば
    // `(0..=u16::MAX).len()` たとえば、16 ビットプラットフォームではエラーや警告なしでコンパイルされますが、間違った結果が表示され続けます。
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // 安全性: 前提条件を確認しました
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // 安全性: 前提条件を確認しました
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // 安全性: 前提条件を確認しました
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // 安全性: 前提条件を確認しました
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // 安全性: 前提条件を確認しました
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // 安全性: 前提条件を確認しました
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}