use crate::fmt;

/// 各反復が提供されたクロージャ `F: FnMut() -> Option<T>` を呼び出す新しいイテレータを作成します。
///
/// これにより、専用タイプを作成して [`Iterator`] trait を実装するというより冗長な構文を使用せずに、任意の動作でカスタムイテレーターを作成できます。
///
/// `FromFn` イテレータはクロージャの動作について想定しないため、保守的に [`FusedIterator`] を実装したり、デフォルトの `(0, None)` から [`Iterator::size_hint()`] をオーバーライドしたりしないことに注意してください。
///
///
/// クロージャーは、キャプチャとその環境を使用して、反復全体の状態を追跡できます。イテレーターの使用方法によっては、クロージャーに [`move`] キーワードを指定する必要がある場合があります。
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation] からカウンターイテレーターを再実装しましょう。
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // カウントを増やします。これが、ゼロから始めた理由です。
///     count += 1;
///
///     // カウントが終了したかどうかを確認してください。
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// 各反復が提供されたクロージャ `F: FnMut() -> Option<T>` を呼び出すイテレータ。
///
/// この `struct` は、[`iter::from_fn()`] 関数によって作成されます。
/// 詳細については、そのドキュメントを参照してください。
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}