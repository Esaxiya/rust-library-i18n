use crate::iter::{FusedIterator, TrustedLen};

/// 提供されたクロージャーを呼び出すことにより、値を 1 回だけ遅延生成するイテレーターを作成します。
///
/// これは通常、単一の値ジェネレータを他の種類の反復の [`chain()`] に適合させるために使用されます。
/// ほとんどすべてをカバーするイテレータがあるかもしれませんが、特別なケースが必要です。
/// 反復子で機能する関数があるかもしれませんが、処理する必要があるのは 1 つの値だけです。
///
/// [`once()`] とは異なり、この関数は要求に応じて値を遅延生成します。
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::iter;
///
/// // 1 つは最も孤独な数です
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // たった 1 つ、それが私たちが得るすべてです
/// assert_eq!(None, one.next());
/// ```
///
/// 別のイテレーターと一緒にチェーンします。
/// `.foo` ディレクトリの各ファイルだけでなく、構成ファイルも反復処理するとします。
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s のイテレータから PathBufs のイテレータに変換する必要があるため、map を使用します
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 今、私たちの設定ファイルのためだけのイテレータ
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // 2 つのイテレータを 1 つの大きなイテレータにチェーンします
/// let files = dirs.chain(config);
///
/// // これにより、.foo と .foorc のすべてのファイルが提供されます
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// 提供されたクロージャー `F: FnOnce() -> A` を適用することにより、タイプ `A` の単一要素を生成するイテレーター。
///
///
/// この `struct` は、[`once_with()`] 関数によって作成されます。
/// 詳細については、そのドキュメントを参照してください。
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}