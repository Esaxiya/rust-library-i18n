use crate::iter::{FusedIterator, TrustedLen};

/// 提供されたクロージャー、リピーター、を適用することにより、タイプ `A` の要素を際限なく繰り返す新しいイテレーターを作成します。`F: FnMut() -> A`.
///
/// `repeat_with()` 関数は、リピーターを何度も呼び出します。
///
/// `repeat_with()` のような無限イテレーターは、それらを有限にするために、[`Iterator::take()`] のようなアダプターでよく使用されます。
///
/// 必要なイテレーターの要素タイプが [`Clone`] を実装していて、ソース要素をメモリに保持しても問題がない場合は、代わりに [`repeat()`] 関数を使用する必要があります。
///
///
/// `repeat_with()` によって生成されたイテレーターは [`DoubleEndedIterator`] ではありません。
/// [`DoubleEndedIterator`] を返品するために `repeat_with()` が必要な場合は、使用例を説明する GitHub の問題を開いてください。
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::iter;
///
/// // `Clone` ではない、または高価であるためにまだメモリに入れたくないタイプの値があると仮定しましょう。
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 永遠に特定の値:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// 突然変異を使用して有限にする:
///
/// ```rust
/// use std::iter;
///
/// // 2 の 0 乗から 3 乗まで:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... そしてこれで完了です
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 提供されたクロージャー `F: FnMut() -> A` を適用することにより、タイプ `A` の要素を際限なく繰り返すイテレーター。
///
///
/// この `struct` は、[`repeat_with()`] 関数によって作成されます。
/// 詳細については、そのドキュメントを参照してください。
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}