use crate::iter::{FusedIterator, TrustedLen};

/// 要素を 1 回だけ生成するイテレータを作成します。
///
/// これは通常、単一の値を他の種類の反復の [`chain()`] に適合させるために使用されます。
/// ほとんどすべてをカバーするイテレータがあるかもしれませんが、特別なケースが必要です。
/// 反復子で機能する関数があるかもしれませんが、処理する必要があるのは 1 つの値だけです。
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::iter;
///
/// // 1 つは最も孤独な数です
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // たった 1 つ、それが私たちが得るすべてです
/// assert_eq!(None, one.next());
/// ```
///
/// 別のイテレーターと一緒にチェーンします。
/// `.foo` ディレクトリの各ファイルだけでなく、構成ファイルも反復処理するとします。
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // DirEntry-s のイテレータから PathBufs のイテレータに変換する必要があるため、map を使用します
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // 今、私たちの設定ファイルのためだけのイテレータ
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // 2 つのイテレータを 1 つの大きなイテレータにチェーンします
/// let files = dirs.chain(config);
///
/// // これにより、.foo と .foorc のすべてのファイルが提供されます
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// 要素を 1 回だけ生成するイテレーター。
///
/// この `struct` は、[`once()`] 関数によって作成されます。詳細については、そのドキュメントを参照してください。
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}