use crate::iter::{FusedIterator, TrustedLen};

/// 単一の要素を際限なく繰り返す新しいイテレーターを作成します。
///
/// `repeat()` 関数は、単一の値を何度も繰り返します。
///
/// `repeat()` のような無限イテレータは、それらを有限にするために、[`Iterator::take()`] のようなアダプタでよく使用されます。
///
/// 必要なイテレータの要素タイプが `Clone` を実装していない場合、または繰り返される要素をメモリに保持したくない場合は、代わりに [`repeat_with()`] 関数を使用できます。
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::iter;
///
/// // 4 番目の 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // うん、まだ 4 つ
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] で有限化:
///
/// ```
/// use std::iter;
///
/// // その最後の例は四つんばいでした。4 つの 4 だけを持っていきましょう。
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... そしてこれで完了です
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// 要素を際限なく繰り返すイテレータ。
///
/// この `struct` は、[`repeat()`] 関数によって作成されます。詳細については、そのドキュメントを参照してください。
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}