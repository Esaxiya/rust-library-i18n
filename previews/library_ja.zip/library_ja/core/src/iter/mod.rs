//! 構成可能な外部反復。
//!
//! ある種のコレクションを見つけて、そのコレクションの要素に対して操作を実行する必要がある場合は、すぐに 'iterators' に遭遇します。
//! イテレータは慣用的な Rust コードで頻繁に使用されるため、イテレータに精通する価値があります。
//!
//! 詳細を説明する前に、このモジュールがどのように構成されているかについて説明しましょう。
//!
//! # Organization
//!
//! このモジュールは、主にタイプ別に構成されています。
//!
//! * [Traits] これらの traits は、存在するイテレーターの種類と、それらを使用して何ができるかを定義します。これらの traits のメソッドは、追加の学習時間を費やす価値があります。
//! * [Functions] いくつかの基本的なイテレータを作成するためのいくつかの便利な方法を提供します。
//! * [Structs] 多くの場合、このモジュールの traits のさまざまなメソッドの戻りタイプです。通常、`struct` 自体ではなく、`struct` を作成するメソッドを確認する必要があります。
//! 理由の詳細については、「[Implementing Iterator] (#implementing-iterator)」を参照してください。
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! それでおしまい! イテレータを掘り下げてみましょう。
//!
//! # Iterator
//!
//! このモジュールの核心は [`Iterator`] trait です。[`Iterator`] のコアは次のようになります。
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! イテレータにはメソッド [`next`] があり、呼び出されると [`Option`]`を返します。<Item>`。
//! [`next`] 要素がある限り [`Some(Item)`] を返し、要素がすべて使い果たされると、`None` を返し、反復が終了したことを示します。
//! 個々のイテレータは反復を再開することを選択する可能性があるため、[`next`] を再度呼び出すと、ある時点で [`Some(Item)`] が再び返される場合とされない場合があります (たとえば、[`TryIter`] を参照)。
//!
//!
//! [`Iterator`] の完全な定義には、他の多くのメソッドも含まれていますが、これらはデフォルトのメソッドであり、[`next`] の上に構築されているため、無料で入手できます。
//!
//! イテレータも構成可能であり、より複雑な形式の処理を行うためにイテレータをチェーン化するのが一般的です。詳細については、以下の [Adapters](#adapters) セクションを参照してください。
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # 反復の 3 つの形式
//!
//! コレクションからイテレーターを作成できる一般的な方法は 3 つあります。
//!
//! * `iter()`, `&T` を繰り返します。
//! * `iter_mut()`, `&mut T` を繰り返します。
//! * `into_iter()`, `T` を繰り返します。
//!
//! 標準ライブラリのさまざまなものが、必要に応じて 3 つのうちの 1 つ以上を実装する場合があります。
//!
//! # イテレータの実装
//!
//! 独自のイテレーターを作成するには、イテレーターの状態を保持する `struct` を作成することと、その `struct` に [`Iterator`] を実装することの 2 つのステップが含まれます。
//! これが、このモジュールに非常に多くの「構造体」がある理由です。イテレータとイテレータアダプタごとに 1 つあります。
//!
//! `1` から `5` までカウントする `Counter` という名前のイテレータを作成しましょう。
//!
//! ```
//! // まず、構造体:
//!
//! /// 1 から 5 までカウントするイテレーター
//! struct Counter {
//!     count: usize,
//! }
//!
//! // カウントを 1 から開始したいので、new() メソッドを追加してみましょう。
//! // これは必ずしも必要ではありませんが、便利です。
//! // `count` をゼロから開始することに注意してください。その理由は、以下の `next()`'s 実装でわかります。
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 次に、`Counter` に `Iterator` を実装します。
//!
//! impl Iterator for Counter {
//!     // usize でカウントします
//!     type Item = usize;
//!
//!     // next() 必要な唯一の方法です
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // カウントを増やします。これが、ゼロから始めた理由です。
//!         self.count += 1;
//!
//!         // カウントが終了したかどうかを確認してください。
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // そして今、私たちはそれを使うことができます!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! この方法で [`next`] を呼び出すと、繰り返しになります。Rust には、`None` に到達するまで、イテレーターで [`next`] を呼び出すことができる構造があります。次にそれを見てみましょう。
//!
//! また、`Iterator` は、`next` を内部的に呼び出す `nth` や `fold` などのメソッドのデフォルトの実装を提供することにも注意してください。
//! ただし、イテレータが `next` を呼び出さなくてもより効率的に計算できる場合は、`nth` や `fold` などのメソッドのカスタム実装を作成することもできます。
//!
//! # `for` ループと `IntoIterator`
//!
//! Rust の `for` ループ構文は、実際にはイテレーターにとって重要です。`for` の基本的な例を次に示します。
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! これにより、1 から 5 までの数字がそれぞれ独自の行に出力されます。しかし、ここで何かに気付くでしょう。イテレータを生成するために vector で何も呼び出さなかったのです。何が得られますか?
//!
//! 標準ライブラリには、何かをイテレータに変換するための trait があります。[`IntoIterator`].
//! この trait には、[`IntoIterator`] を実装するものをイテレーターに変換する 1 つのメソッド [`into_iter`] があります。
//! その `for` ループをもう一度見て、コンパイラがそれを何に変換するかを見てみましょう。
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust はこれを脱糖します:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! まず、値に対して `into_iter()` を呼び出します。次に、返されるイテレータを照合し、`None` が表示されるまで [`next`] を何度も呼び出します。
//! その時点で、`break` がループから外れ、反復が完了しました。
//!
//! ここにもう 1 つ微妙な点があります。標準ライブラリには、[`IntoIterator`] の興味深い実装が含まれています。
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! 言い換えれば、すべての [`Iterator`] は、自分自身を返すだけで [`IntoIterator`] を実装します。これは 2 つのことを意味します:
//!
//! 1. [`Iterator`] を作成している場合は、`for` ループで使用できます。
//! 2. コレクションを作成している場合、そのコレクションに [`IntoIterator`] を実装すると、コレクションを `for` ループで使用できるようになります。
//!
//! # 参照による反復
//!
//! [`into_iter()`] は値で `self` を受け取るため、`for` ループを使用してコレクションを反復処理すると、そのコレクションが消費されます。多くの場合、コレクションを消費せずに繰り返し処理することをお勧めします。
//! 多くのコレクションは、従来はそれぞれ `iter()` および `iter_mut()` と呼ばれていた、参照に対するイテレーターを提供するメソッドを提供します。
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` はまだこの関数によって所有されています。
//! ```
//!
//! コレクションタイプ `C` が `iter()` を提供する場合、通常は `&C` 用の `IntoIterator` も実装し、実装は `iter()` を呼び出すだけです。
//! 同様に、`iter_mut()` を提供するコレクション `C` は、通常、`iter_mut()` に委任することによって `&mut C` の `IntoIterator` を実装します。これにより、便利な速記が可能になります。
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` と同じ
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` と同じ
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! 多くのコレクションが `iter()` を提供していますが、すべてが `iter_mut()` を提供しているわけではありません。
//! たとえば、[`HashSet<T>`] または [`HashMap<K, V>`] のキーを変更すると、キーハッシュが変更された場合にコレクションが不整合な状態になる可能性があるため、これらのコレクションは `iter()` のみを提供します。
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! [`Iterator`] を受け取り、別の [`Iterator`] を返す関数は、「アダプター」の形式であるため、「イテレーターアダプター」と呼ばれることがよくあります。
//! pattern'.
//!
//! 一般的なイテレータアダプタには、[`map`]、[`take`]、および [`filter`] が含まれます。
//! 詳細については、ドキュメントを参照してください。
//!
//! イテレータアダプタ panics の場合、イテレータは指定されていない (ただしメモリセーフな) 状態になります。
//! この状態は、Rust のバージョン間で同じままであることが保証されていないため、パニックになったイテレーターによって返される正確な値に依存することは避けてください。
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! イテレータ (およびイテレータ [adapters](#adapters)) は *遅延* です。これは、イテレータを作成するだけでは _do_ がそれほど多くないことを意味します。[`next`] を呼び出すまで実際には何も起こりません。
//! これは、副作用のためだけにイテレータを作成するときに混乱の原因となることがあります。
//! たとえば、[`map`] メソッドは、反復する各要素でクロージャを呼び出します。
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! イテレータを使用するのではなく作成しただけなので、これは値を出力しません。コンパイラは、この種の動作について警告します。
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! 副作用のために [`map`] を作成する慣用的な方法は、`for` ループを使用するか、[`for_each`] メソッドを呼び出すことです。
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! イテレータを評価するもう 1 つの一般的な方法は、[`collect`] メソッドを使用して新しいコレクションを作成することです。
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! イテレータは有限である必要はありません。例として、自由形式の範囲は無限のイテレータです。
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! [`take`] イテレータアダプタを使用して、無限イテレータを有限イテレータに変換するのが一般的です。
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! これにより、`0` から `4` までの番号がそれぞれ独自の行に出力されます。
//!
//! 無限反復子のメソッドは、結果が有限時間で数学的に決定できるメソッドであっても、終了しない場合があることに注意してください。
//! 具体的には、[`min`] などのメソッドは、一般的にイテレータ内のすべての要素をトラバースする必要がありますが、無限のイテレータでは正常に返されない可能性があります。
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // 大野! 無限ループ!
//! // `ones.min()` 無限ループが発生するため、このポイントには到達しません。
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;