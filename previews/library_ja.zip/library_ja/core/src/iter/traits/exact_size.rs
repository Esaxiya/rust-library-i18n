/// 正確な長さを知っているイテレータ。
///
/// 多くの [`Iterator`] は、何回反復するかを知りませんが、知っている人もいます。
/// イテレーターが何回イテレートできるかを知っている場合、その情報へのアクセスを提供すると便利です。
/// たとえば、逆方向に反復したい場合、良いスタートは終わりがどこにあるかを知ることです。
///
/// `ExactSizeIterator` を実装する場合は、[`Iterator`] も実装する必要があります。
/// その場合、[`Iterator::size_hint`] の実装は、イテレーターの正確なサイズを返す必要があります。
///
/// [`len`] メソッドにはデフォルトの実装があるため、通常は実装しないでください。
/// ただし、デフォルトよりもパフォーマンスの高い実装を提供できる場合があるため、この場合はオーバーライドするのが理にかなっています。
///
///
/// この trait は安全な trait であるため、返される長さが正しいことを保証することはできません。
/// これは、`unsafe` コードが [`Iterator::size_hint`] の正確さに依存してはならないことを意味します。
/// 不安定で安全でない [`TrustedLen`](super::marker::TrustedLen) trait は、この追加の保証を提供します。
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// // 有限の範囲は、それが何回反復するかを正確に知っています
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] では、[`Iterator`] を実装しました。`Counter`.
/// `ExactSizeIterator` も実装しましょう。
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // 残りの反復回数は簡単に計算できます。
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // そして今、私たちはそれを使うことができます!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// イテレータの正確な長さを返します。
    ///
    /// 実装により、イテレータは [`None`] を返す前に、[`Some(T)`] 値の正確な `len()` 倍を返すことが保証されます。
    ///
    /// このメソッドにはデフォルトの実装があるため、通常は直接実装しないでください。
    /// ただし、より効率的な実装を提供できる場合は、そうすることができます。
    /// 例については、[trait-level] のドキュメントを参照してください。
    ///
    /// この機能は、[`Iterator::size_hint`] 機能と同じ安全性が保証されています。
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 有限の範囲は、それが何回反復するかを正確に知っています
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: このアサーションは過度に防御的ですが、不変条件をチェックします
        // trait によって保証されています。
        // この trait が rust 内部の場合、debug_assert! を使用できます。assert_eq! すべての Rust ユーザー実装もチェックします。
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// イテレーターが空の場合、`true` を返します。
    ///
    /// このメソッドには [`ExactSizeIterator::len()`] を使用したデフォルトの実装があるため、自分で実装する必要はありません。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}