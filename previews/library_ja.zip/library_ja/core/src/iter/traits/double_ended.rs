use crate::ops::{ControlFlow, Try};

/// 両端から要素を生成できるイテレータ。
///
/// `DoubleEndedIterator` を実装するものには、[`Iterator`] を実装するものに比べて、1 つの追加機能があります。それは、前面だけでなく背面からも「アイテム」を取得する機能です。
///
///
/// 前後の両方が同じ範囲で機能し、交差しないことに注意することが重要です。それらが中央で出会うと、反復は終了します。
///
/// [`Iterator`] プロトコルと同様に、`DoubleEndedIterator` が [`next_back()`] から [`None`] を返すと、それを再度呼び出すと、[`Some`] が返される場合とされない場合があります。
/// [`next()`] と [`next_back()`] は、この目的のために交換可能です。
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// イテレーターの最後から要素を削除して返します。
    ///
    /// 要素がなくなると `None` を返します。
    ///
    /// [trait-level] ドキュメントには詳細が含まれています。
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` のメソッドによって生成される要素は、[`Iterator`] のメソッドによって生成される要素とは異なる場合があります。
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// イテレータを `n` 要素だけ後ろから進めます。
    ///
    /// `advance_back_by` [`advance_by`] の逆バージョンです。このメソッドは、[`None`] が検出されるまで、[`next_back`] を `n` 回まで呼び出すことにより、`n` 要素を後ろからスキップします。
    ///
    /// `advance_back_by(n)` イテレータが `n` 要素で正常に前進した場合は [`Ok(())`] を返し、[`None`] が検出された場合は [`Err(k)`] を返します。`k` は、要素がなくなる前にイテレータが前進した要素の数です (つまり、
    /// イテレータの長さ)。
    /// `k` は常に `n` よりも小さいことに注意してください。
    ///
    /// `advance_back_by(0)` を呼び出すと要素が消費されず、常に [`Ok(())`] が返されます。
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` のみがスキップされました
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// イテレータの末尾から `n` 番目の要素を返します。
    ///
    /// これは本質的に [`Iterator::nth()`] の逆バージョンです。
    /// ほとんどのインデックス作成操作と同様に、カウントはゼロから始まるため、`nth_back(0)` は最後から最初の値を返し、`nth_back(1)` は 2 番目の値を返します。
    ///
    ///
    /// 返された要素を含め、最後の要素と返された要素の間のすべての要素が消費されることに注意してください。
    /// これは、同じイテレータで `nth_back(0)` を複数回呼び出すと、異なる要素が返されることも意味します。
    ///
    /// `nth_back()` `n` がイテレータの長さ以上の場合、[`None`] を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` を複数回呼び出しても、イテレータは巻き戻されません。
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1` 要素より少ない場合に `None` を返します。
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// これは [`Iterator::try_fold()`] の逆バージョンです。イテレーターの後ろから始まる要素を取ります。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // 短絡しているため、残りの要素はイテレータを介して引き続き使用できます。
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// イテレータの要素を後ろから始めて単一の最終値に減らすイテレータメソッド。
    ///
    /// これは [`Iterator::fold()`] の逆バージョンです。イテレーターの後ろから始まる要素を取ります。
    ///
    /// `rfold()` 初期値と、'accumulator' と要素の 2 つの引数を持つクロージャの 2 つの引数を取ります。
    /// クロージャは、アキュムレータが次の反復のために持つべき値を返します。
    ///
    /// 初期値は、アキュムレータが最初の呼び出しで持つ値です。
    ///
    /// このクロージャーをイテレーターのすべての要素に適用した後、`rfold()` はアキュムレーターを返します。
    ///
    /// この操作は、'reduce' または 'inject' と呼ばれることもあります。
    ///
    /// 折りたたみは、何かのコレクションがあり、そこから単一の値を生成したい場合に役立ちます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // のすべての要素の合計
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// この例では、初期値から始まり、各要素の後ろから前まで続く文字列を作成します。
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// 述語を満たすイテレータの要素を後ろから検索します。
    ///
    /// `rfind()` `true` または `false` を返すクロージャを取ります。
    /// このクロージャーをイテレーターの各要素に適用し、最後から開始します。いずれかの要素が `true` を返す場合、`rfind()` は [`Some(element)`] を返します。
    /// それらがすべて `false` を返す場合、[`None`] を返します。
    ///
    /// `rfind()` 短絡している; つまり、クロージャが `true` を返すとすぐに処理を停止します。
    ///
    /// `rfind()` は参照を取得し、多くのイテレーターが参照を反復処理するため、これにより、引数が二重参照であるという混乱を招く可能性があります。
    ///
    /// この効果は、`&&x` を使用した以下の例で確認できます。
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// 最初の `true` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}