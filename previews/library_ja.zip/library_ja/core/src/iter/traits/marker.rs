/// 使い果たされたときに常に `None` を生成し続けるイテレータ。
///
/// `None` を 1 回返した融合イテレーターで次に呼び出すと、[`None`] が再び返されることが保証されます。
/// この trait は、[`Iterator::fuse()`] を最適化できるため、このように動作するすべてのイテレーターで実装する必要があります。
///
///
/// Note: 一般に、融合イテレータが必要な場合は、ジェネリック境界で `FusedIterator` を使用しないでください。
/// 代わりに、イテレータで [`Iterator::fuse()`] を呼び出す必要があります。
/// イテレータがすでに融合されている場合、追加の [`Fuse`] ラッパーは、パフォーマンスを低下させることなく、何も実行されません。
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// size_hint を使用して正確な長さを報告するイテレータ。
///
/// イテレータは、正確である (下限が上限に等しい) か、上限が [`None`] であるサイズヒントを報告します。
///
/// 実際のイテレータの長さが [`usize::MAX`] より大きい場合、上限は [`None`] である必要があります。
/// その場合、下限は [`usize::MAX`] である必要があり、[`Iterator::size_hint()`] は `(usize::MAX, None)` になります。
///
/// イテレータは、最後に到達する前に、報告した要素の正確な数を生成するか、発散する必要があります。
///
/// # Safety
///
/// この trait は、契約が守られている場合にのみ実装する必要があります。
/// この trait のコンシューマーは、[`Iterator::size_hint()`]’s の上限を検査する必要があります。
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// アイテムを生成するときに、基礎となる [`SourceIter`] から少なくとも 1 つの要素を取得するイテレーター。
///
/// イテレータを進めるメソッドを呼び出す。
/// [`next()`] または [`try_fold()`] は、各ステップで、イテレーターの基になるソースの少なくとも 1 つの値が移動され、ソースの構造上の制約によりそのような挿入が許可されていると仮定して、イテレーターチェーンの結果をその場所に挿入できることを保証します。
///
/// 言い換えると、この trait は、イテレーターパイプラインを適切に収集できることを示します。
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}