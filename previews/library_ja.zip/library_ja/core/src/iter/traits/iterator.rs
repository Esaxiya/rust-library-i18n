// ignore-tidy-filelength このファイルは、ほぼ排他的に `Iterator` の定義で構成されています。
// それを複数のファイルに分割することはできません。
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// イテレータを処理するためのインターフェイス。
///
/// これはメインイテレーター trait です。
/// 一般的なイテレーターの概念の詳細については、[module-level documentation] を参照してください。
/// 特に、[implement `Iterator`][impl] の方法を知りたい場合があります。
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// 繰り返される要素のタイプ。
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// イテレータを進め、次の値を返します。
    ///
    /// 反復が終了すると [`None`] を返します。
    /// 個々のイテレーターの実装は反復を再開することを選択する可能性があるため、`next()` を再度呼び出すと、ある時点で [`Some(Item)`] が再び返される場合とされない場合があります。
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() を呼び出すと、次の値が返されます...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... そしてそれが終わったら None。
    /// assert_eq!(None, iter.next());
    ///
    /// // より多くの呼び出しが `None` を返す場合と返さない場合があります。ここでは、彼らは常にそうします。
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// イテレータの残りの長さの境界を返します。
    ///
    /// 具体的には、`size_hint()` は、最初の要素が下限で、2 番目の要素が上限であるタプルを返します。
    ///
    /// 返されるタプルの後半は [`Option`]`<`[`usize`] `>` です。
    /// ここでの [`None`] は、既知の上限がないか、上限が [`usize`] より大きいことを意味します。
    ///
    /// # 実装上の注意
    ///
    /// イテレータの実装が宣言された数の要素を生成することは強制されません。バグのあるイテレータは、要素の下限よりも小さいか、上限よりも多くなる可能性があります。
    ///
    /// `size_hint()` 主に、イテレーターの要素用のスペースの予約などの最適化に使用することを目的としていますが、安全でないコードで境界チェックを省略するなど、信頼してはなりません。
    /// `size_hint()` の誤った実装は、メモリ安全違反につながるべきではありません。
    ///
    /// とは言うものの、実装は正しい推定を提供する必要があります。そうしないと、trait のプロトコルに違反することになります。
    ///
    /// デフォルトの実装は ` (0、` [`None`]`) ` を返しますが、これはどのイテレータにも当てはまります。
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// より複雑な例:
    ///
    /// ```
    /// // ゼロから 10 までの偶数。
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ゼロから 10 回繰り返す可能性があります。
    /// // filter() を実行しないと、5 つであることを正確に知ることはできません。
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() でさらに 5 つの数字を追加しましょう
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // 今、両方の境界が 5 増加します
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// 上限として `None` を返す:
    ///
    /// ```
    /// // 無限イテレータには上限がなく、可能な最大の下限があります
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// イテレータを消費し、反復回数をカウントして返します。
    ///
    /// このメソッドは、[`None`] が検出されるまで [`next`] を繰り返し呼び出し、[`Some`] を検出した回数を返します。
    /// イテレータに要素がない場合でも、[`next`] を少なくとも 1 回呼び出す必要があることに注意してください。
    ///
    /// [`next`]: Iterator::next
    ///
    /// # オーバーフロー動作
    ///
    /// このメソッドはオーバーフローを防止しないため、[`usize::MAX`] を超える要素を持つイテレーターの要素をカウントすると、間違った結果または panics が生成されます。
    ///
    /// デバッグアサーションが有効になっている場合、panic が保証されます。
    ///
    /// # Panics
    ///
    /// イテレータに [`usize::MAX`] を超える要素がある場合、この関数は panic になる可能性があります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// イテレータを消費し、最後の要素を返します。
    ///
    /// このメソッドは、[`None`] を返すまでイテレーターを評価します。
    /// そうしている間、それは現在の要素を追跡します。
    /// [`None`] が返された後、`last()` は最後に見た要素を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// イテレータを `n` 要素だけ進めます。
    ///
    /// このメソッドは、[`None`] が検出されるまで [`next`] を最大 `n` 回呼び出すことにより、`n` 要素を熱心にスキップします。
    ///
    /// `advance_by(n)` イテレータが `n` 要素で正常に前進した場合は [`Ok(())`][Ok] を返し、[`None`] が検出された場合は [`Err(k)`][Err] を返します。`k` は、要素がなくなる前にイテレータが前進した要素の数です (つまり、
    /// イテレータの長さ)。
    /// `k` は常に `n` よりも小さいことに注意してください。
    ///
    /// `advance_by(0)` を呼び出すと要素が消費されず、常に [`Ok(())`][Ok] が返されます。
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` のみがスキップされました
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// イテレータの `n` 番目の要素を返します。
    ///
    /// ほとんどのインデックス作成操作と同様に、カウントはゼロから始まるため、`nth(0)` は最初の値を返し、`nth(1)` は 2 番目の値を返します。
    ///
    /// 先行するすべての要素、および返される要素は、イテレーターから消費されることに注意してください。
    /// つまり、前の要素は破棄され、同じイテレータで `nth(0)` を複数回呼び出すと、異なる要素が返されます。
    ///
    ///
    /// `nth()` `n` がイテレータの長さ以上の場合、[`None`] を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` を複数回呼び出しても、イテレータは巻き戻されません。
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1` 要素より少ない場合に `None` を返します。
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// 同じポイントから開始するイテレータを作成しますが、各反復で指定された量だけステップします。
    ///
    /// 注 1: 指定されたステップに関係なく、イテレーターの最初の要素は常に返されます。
    ///
    /// 注 2: 無視された要素がプルされる時間は固定されていません。
    /// `StepBy` シーケンス `next(), nth(step-1), nth(step-1),…` のように動作しますが、シーケンスのように自由に動作することもできます
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// パフォーマンス上の理由から、一部のイテレータではどちらの方法を使用するかが変更される場合があります。
    /// 2 番目の方法は、イテレータを早く進め、より多くのアイテムを消費する可能性があります。
    ///
    /// `advance_n_and_return_first` と同等です:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// 指定されたステップが `0` の場合、メソッドは panic になります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// 2 つのイテレータを取得し、両方に対して順番に新しいイテレータを作成します。
    ///
    /// `chain()` 最初に最初のイテレータからの値を繰り返し、次に 2 番目のイテレータからの値を繰り返し処理する新しいイテレータを返します。
    ///
    /// つまり、2 つのイテレータをチェーンでリンクします。🔗
    ///
    /// [`once`] 通常、単一の値を他の種類の反復のチェーンに適合させるために使用されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` の引数は [`IntoIterator`] を使用するため、[`Iterator`] 自体だけでなく、[`Iterator`] に変換できるものなら何でも渡すことができます。
    /// たとえば、スライス (`&[T]`) は [`IntoIterator`] を実装しているため、`chain()` に直接渡すことができます。
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Windows API を使用している場合は、[`OsStr`] を `Vec<u16>` に変換することをお勧めします。
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 2 つのイテレータをペアの 1 つのイテレータに「ジップアップ」します。
    ///
    /// `zip()` 他の 2 つのイテレータを反復処理する新しいイテレータを返し、最初の要素が最初のイテレータに由来し、2 番目の要素が 2 番目のイテレータに由来するタプルを返します。
    ///
    ///
    /// つまり、2 つのイテレータを 1 つにまとめます。
    ///
    /// いずれかのイテレータが [`None`] を返す場合、zip 形式のイテレータからの [`next`] は [`None`] を返します。
    /// 最初のイテレータが [`None`] を返す場合、`zip` は短絡し、`next` は 2 番目のイテレータで呼び出されません。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` の引数は [`IntoIterator`] を使用するため、[`Iterator`] 自体だけでなく、[`Iterator`] に変換できるものなら何でも渡すことができます。
    /// たとえば、スライス (`&[T]`) は [`IntoIterator`] を実装しているため、`zip()` に直接渡すことができます。
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` 多くの場合、無限の反復子を有限の反復子に圧縮するために使用されます。
    /// これが機能するのは、有限イテレータが最終的に [`None`] を返し、ジッパーを終了するためです。`(0..)` での圧縮は、[`enumerate`] によく似ています。
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// 元のイテレータの隣接するアイテムの間に `separator` のコピーを配置する新しいイテレータを作成します。
    ///
    /// `separator` が [`Clone`] を実装していない場合、または毎回計算する必要がある場合は、[`intersperse_with`] を使用してください。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` の最初の要素。
    /// assert_eq!(a.next(), Some(&100)); // セパレータ。
    /// assert_eq!(a.next(), Some(&1));   // `a` の次の要素。
    /// assert_eq!(a.next(), Some(&100)); // セパレータ。
    /// assert_eq!(a.next(), Some(&2));   // `a` の最後の要素。
    /// assert_eq!(a.next(), None);       // イテレータが終了しました。
    /// ```
    ///
    /// `intersperse` 共通の要素を使用してイテレータのアイテムを結合すると非常に便利です。
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` によって生成されたアイテムを元のイテレーターの隣接するアイテムの間に配置する新しいイテレーターを作成します。
    ///
    /// クロージャは、基になるイテレータからの 2 つの隣接するアイテムの間にアイテムが配置されるたびに 1 回だけ呼び出されます。
    /// 具体的には、基になるイテレーターが 2 つ未満のアイテムを生成し、最後のアイテムが生成された後、クロージャーは呼び出されません。
    ///
    ///
    /// イテレータのアイテムが [`Clone`] を実装している場合は、[`intersperse`] を使用する方が簡単な場合があります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` の最初の要素。
    /// assert_eq!(it.next(), Some(NotClone(99))); // セパレータ。
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` の次の要素。
    /// assert_eq!(it.next(), Some(NotClone(99))); // セパレータ。
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` からの最後の要素。
    /// assert_eq!(it.next(), None);               // イテレータが終了しました。
    /// ```
    ///
    /// `intersperse_with` セパレータを計算する必要がある状況で使用できます。
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // クロージャーは、そのコンテキストを可変的に借用してアイテムを生成します。
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// クロージャを取得し、各要素でそのクロージャを呼び出すイテレータを作成します。
    ///
    /// `map()` 引数を使用して、あるイテレータを別のイテレータに変換します。
    /// [`FnMut`] を実装するもの。元のイテレータの各要素でこのクロージャを呼び出す新しいイテレータを生成します。
    ///
    /// タイプで考えるのが得意な場合は、`map()` を次のように考えることができます。
    /// あるタイプの `A` の要素を提供するイテレーターがあり、他のタイプの `B` のイテレーターが必要な場合は、`map()` を使用して、`A` を受け取り、`B` を返すクロージャーを渡すことができます。
    ///
    ///
    /// `map()` 概念的には [`for`] ループに似ています。ただし、`map()` はレイジーであるため、他のイテレーターを既に使用している場合に最適です。
    /// 副作用のためにある種のループを実行している場合、`map()` よりも [`for`] を使用する方が慣用的であると見なされます。
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ある種の副作用を起こしている場合は、`map()` よりも [`for`] をお勧めします。
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // これをしないでください:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // 怠惰なので実行すらしません。Rust はこれについて警告します。
    ///
    /// // 代わりに、次の目的で使用します。
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// イテレータの各要素でクロージャを呼び出します。
    ///
    /// これは、イテレータで [`for`] ループを使用するのと同じですが、クロージャから `break` と `continue` を使用することはできません。
    /// `for` ループを使用する方が一般的に慣用的ですが、長いイテレーターチェーンの最後でアイテムを処理する場合、`for_each` の方が読みやすい場合があります。
    ///
    /// `for_each` は、`Chain` などのアダプターで内部反復を使用するため、ループよりも高速な場合もあります。
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// このような小さな例では、`for` ループの方がクリーンな場合がありますが、より長いイテレーターで機能的なスタイルを維持するには、`for_each` の方が適している場合があります。
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// クロージャを使用して要素を生成するかどうかを決定するイテレータを作成します。
    ///
    /// 要素が与えられると、クロージャーは `true` または `false` を返す必要があります。返されたイテレーターは、クロージャーが true を返す要素のみを生成します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()` に渡されたクロージャーは参照を取得し、多くのイテレーターが参照を反復処理するため、これにより、クロージャーのタイプが二重参照である、混乱を招く可能性のある状況が発生します。
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // 2 つの * が必要です!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 代わりに、引数に destructuring を使用して、引数を削除するのが一般的です。
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ＆と * の両方
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// または両方:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // 2 つの &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// これらの層の。
    ///
    /// `iter.filter(f).next()` は `iter.find(f)` と同等であることに注意してください。
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// フィルタとマップの両方を行うイテレータを作成します。
    ///
    /// 返されたイテレータは、指定されたクロージャが `Some(value)` を返す `値` のみを生成します。
    ///
    /// `filter_map` [`filter`] と [`map`] のチェーンをより簡潔にするために使用できます。
    /// 以下の例は、`map().filter().map()` を `filter_map` への 1 回の呼び出しに短縮する方法を示しています。
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// これは同じ例ですが、[`filter`] と [`map`] を使用しています。
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// 現在の反復回数と次の値を与えるイテレータを作成します。
    ///
    /// 返されるイテレータはペア `(i, val)` を生成します。ここで、`i` は現在の反復のインデックスであり、`val` はイテレータによって返される値です。
    ///
    ///
    /// `enumerate()` [`usize`] としてカウントを維持します。
    /// 別のサイズの整数でカウントする場合は、[`zip`] 関数が同様の機能を提供します。
    ///
    /// # オーバーフロー動作
    ///
    /// このメソッドはオーバーフローを防止しないため、[`usize::MAX`] を超える要素を列挙すると、間違った結果または panics が生成されます。
    /// デバッグアサーションが有効になっている場合、panic が保証されます。
    ///
    /// # Panics
    ///
    /// 返されるインデックスが [`usize`] をオーバーフローする場合、返されるイテレータは panic になる可能性があります。
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`] を使用して、イテレーターを消費せずにイテレーターの次の要素を調べることができるイテレーターを作成します。
    ///
    /// [`peek`] メソッドをイテレータに追加します。詳細については、そのドキュメントを参照してください。
    ///
    /// [`peek`] が初めて呼び出されたとき、基礎となるイテレータはまだ進んでいることに注意してください。次の要素を取得するために、基礎となるイテレータで [`next`] が呼び出されるため、副作用が発生します (つまり、
    ///
    /// [`next`] メソッドの次の値をフェッチする以外の何かが発生します。
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future を見てみましょう
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // peek() を複数回実行できますが、イテレータは進みません
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // イテレータが終了した後、peek() も終了します
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// 述語に基づいて要素を [`skip`] するイテレータを作成します。
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` 引数としてクロージャを取ります。イテレーターの各要素でこのクロージャーを呼び出し、`false` を返すまで要素を無視します。
    ///
    /// `false` が返された後、`skip_while()`'s ジョブは終了し、残りの要素が生成されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()` に渡されたクロージャは参照を取得し、多くのイテレータが参照を反復処理するため、これにより、クロージャ引数のタイプが二重参照であるという混乱を招く可能性があります。
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // 2 つの * が必要です!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 最初の `false` の後で停止します:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // これは誤りでしたが、すでに誤りがあったため、skip_while() は使用されなくなりました
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// 述語に基づいて要素を生成するイテレータを作成します。
    ///
    /// `take_while()` 引数としてクロージャを取ります。イテレータの各要素でこのクロージャを呼び出し、`true` を返す間に要素を生成します。
    ///
    /// `false` が返された後、`take_while()`'s ジョブは終了し、残りの要素は無視されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` に渡されたクロージャは参照を取得し、多くのイテレータが参照を反復処理するため、これにより、クロージャのタイプが二重参照である、混乱を招く可能性のある状況が発生します。
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // 2 つの * が必要です!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 最初の `false` の後で停止します:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ゼロ未満の要素が他にもありますが、すでに false が発生しているため、take_while() は使用されなくなりました。
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` は、値を含める必要があるかどうかを確認するために値を調べる必要があるため、イテレーターを使用すると、値が削除されていることがわかります。
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` は、反復を停止する必要があるかどうかを確認するために消費されたため、存在しなくなりましたが、反復子に戻されませんでした。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// 述語とマップに基づいて要素を生成するイテレータを作成します。
    ///
    /// `map_while()` 引数としてクロージャを取ります。
    /// イテレータの各要素でこのクロージャを呼び出し、[`Some(_)`][`Some`] を返す間に要素を生成します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// これは同じ例ですが、[`take_while`] と [`map`] を使用しています。
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 最初の [`None`] の後で停止します:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4、5) に収まる要素は他にもありますが、`map_while` は `-3` に対して `None` を返し (`predicate` は `None` を返したため)、`collect` は最初に検出された `None` で停止します。
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` は、値を含める必要があるかどうかを確認するために値を調べる必要があるため、反復子を使用すると、値が削除されていることがわかります。
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` は、反復を停止する必要があるかどうかを確認するために消費されたため、存在しなくなりましたが、反復子に戻されませんでした。
    ///
    /// [`take_while`] とは異なり、このイテレータは融合されていないことに注意してください。
    /// また、最初の [`None`] が返された後にこのイテレータが何を返すかについても指定されていません。
    /// 融合イテレータが必要な場合は、[`fuse`] を使用してください。
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// 最初の `n` 要素をスキップするイテレーターを作成します。
    ///
    /// それらが消費された後、残りの要素が生成されます。
    /// このメソッドを直接オーバーライドするのではなく、代わりに `nth` メソッドをオーバーライドします。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// 最初の `n` 要素を生成するイテレータを作成します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` 有限にするために、無限イテレーターとともに使用されることがよくあります。
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// 使用可能な要素が `n` 未満の場合、`take` は基になるイテレーターのサイズに制限されます。
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`] と同様のイテレーターアダプターで、内部状態を保持し、新しいイテレーターを生成します。
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` 2 つの引数を取ります。内部状態をシードする初期値と、2 つの引数を持つクロージャです。最初は内部状態への可変参照であり、2 番目はイテレータ要素です。
    ///
    /// クロージャーは内部状態に割り当てて、反復間で状態を共有できます。
    ///
    /// 反復時に、クロージャがイテレータの各要素に適用され、クロージャからの戻り値 [`Option`] がイテレータによって生成されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // 反復ごとに、状態に要素を掛けます
    ///     *state = *state * x;
    ///
    ///     // 次に、状態の否定を生成します
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// マップのように機能するイテレーターを作成しますが、ネストされた構造をフラット化します。
    ///
    /// [`map`] アダプターは非常に便利ですが、クロージャ引数が値を生成する場合に限ります。
    /// 代わりにイテレーターを生成する場合は、間接の余分なレイヤーがあります。
    /// `flat_map()` この余分なレイヤーを自動的に削除します。
    ///
    /// `flat_map(f)` は、[`map`] ping と意味的に同等であり、`map(f).flatten()` のように [`flatten`] することができます。
    ///
    /// `flat_map()` についての別の考え方: [`map`] のクロージャーは、要素ごとに 1 つのアイテムを返し、`flat_map()`'s クロージャーは、要素ごとにイテレーターを返します。
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() イテレータを返します
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ネストされた構造をフラット化するイテレータを作成します。
    ///
    /// これは、イテレータのイテレータまたはイテレータに変換できるもののイテレータがあり、1 レベルの間接参照を削除する場合に役立ちます。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// マッピングしてから平坦化:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() イテレータを返します
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// これを [`flat_map()`] で書き直すこともできます。これは、意図をより明確に伝えるため、この場合に適しています。
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() イテレータを返します
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// フラット化により、一度に 1 レベルのネストのみが削除されます。
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// ここでは、`flatten()` が "deep" フラット化を実行しないことがわかります。
    /// 代わりに、1 レベルのネストのみが削除されます。つまり、3 次元配列を `flatten()` すると、結果は 1 次元ではなく 2 次元になります。
    /// 一次元構造を取得するには、もう一度 `flatten()` を実行する必要があります。
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// 最初の [`None`] の後に終了するイテレータを作成します。
    ///
    /// イテレータが [`None`] を返した後、future 呼び出しは [`Some(T)`] を再び生成する場合と生成しない場合があります。
    /// `fuse()` イテレータを適応させ、[`None`] が与えられた後、常に [`None`] を永久に返すようにします。
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // Some と None を交互に繰り返すイテレータ
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // 偶数の場合は Some(i32)、それ以外の場合はなし
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // イテレータが前後に移動するのを見ることができます
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // しかし、一度融合すると...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // 初回以降は常に `None` を返します。
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// イテレータの各要素で何かを実行し、値を渡します。
    ///
    /// イテレーターを使用する場合、多くの場合、イテレーターのいくつかをチェーンします。
    /// このようなコードで作業しているときに、パイプラインのさまざまな部分で何が起こっているかを確認することをお勧めします。これを行うには、`inspect()` への呼び出しを挿入します。
    ///
    /// `inspect()` は、最終的なコードに存在するよりもデバッグツールとして使用されるのが一般的ですが、アプリケーションは、エラーを破棄する前にログに記録する必要がある特定の状況で役立つ場合があります。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // このイテレーターシーケンスは複雑です。
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // 何が起こっているのかを調査するために、いくつかの inspect() 呼び出しを追加しましょう
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// これは印刷されます:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// エラーを破棄する前にログに記録する:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// これは印刷されます:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// イテレータを消費するのではなく、借ります。
    ///
    /// これは、元のイテレーターの所有権を保持したまま、イテレーターアダプターを適用できるようにする場合に役立ちます。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // iter をもう一度使用しようとすると、機能しません。
    /// // 次の行は「エラー: 移動された値の使用: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // もう一度やってみましょう
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // 代わりに、.by_ref() を追加します
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // 今これは問題ありません:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// イテレータをコレクションに変換します。
    ///
    /// `collect()` 反復可能なものは何でも取り、それを関連するコレクションに変えることができます。
    /// これは、さまざまなコンテキストで使用される、標準ライブラリで最も強力なメソッドの 1 つです。
    ///
    /// `collect()` が使用される最も基本的なパターンは、あるコレクションを別のコレクションに変換することです。
    /// コレクションを取得し、そのコレクションで [`iter`] を呼び出し、一連の変換を実行してから、最後に `collect()` を実行します。
    ///
    /// `collect()` 通常のコレクションではないタイプのインスタンスを作成することもできます。
    /// たとえば、[`String`] は [`char`] から構築でき、[`Result<T, E>`][`Result`] アイテムのイテレーターを `Result<Collection<T>, E>` に収集できます。
    ///
    /// 詳細については、以下の例を参照してください。
    ///
    /// `collect()` は非常に一般的であるため、型推論で問題が発生する可能性があります。
    /// そのため、`collect()` は、'turbofish' として愛情を込めて知られている構文を目にする数少ない機会の 1 つです。`::<>`.
    /// これは、推論アルゴリズムが収集しようとしているコレクションを具体的に理解するのに役立ちます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// 左側に `: Vec<i32>` が必要であることに注意してください。これは、たとえば、代わりに [`VecDeque<T>`] に収集できるためです。
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` に注釈を付ける代わりに 'turbofish' を使用する:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` は収集対象のみを考慮しているため、ターボフィッシュで部分型ヒント `_` を使用できます。
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` を使用して [`String`] を作成します。
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// [`結果のリストがある場合 < T, E>`][`Result`] s、`collect()` を使用して、それらのいずれかが失敗したかどうかを確認できます。
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 最初のエラーが発生します
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // 答えのリストを教えてくれます
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// イテレータを消費し、そこから 2 つのコレクションを作成します。
    ///
    /// `partition()` に渡された述部は、`true` または `false` を返すことができます。
    /// `partition()` ペア、`true` を返したすべての要素、および `false` を返したすべての要素を返します。
    ///
    ///
    /// [`is_partitioned()`] および [`partition_in_place()`] も参照してください。
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// `true` を返すすべての要素が、`false` を返すすべての要素よりも優先されるように、指定された述語に従って、このイテレーターの要素を *インプレース* で並べ替えます。
    ///
    /// 見つかった `true` 要素の数を返します。
    ///
    /// パーティション化されたアイテムの相対的な順序は維持されません。
    ///
    /// [`is_partitioned()`] および [`partition()`] も参照してください。
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // 偶数とオッズの間でインプレースに分割
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: カウントがオーバーフローすることを心配する必要がありますか? 以上を持つための唯一の方法
        // `usize::MAX` 可変参照は ZST を使用するため、パーティション化には役立ちません。

        // これらのクロージャー "factory" 関数は、`Self` の汎用性を回避するために存在します。

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // 最初の `false` を繰り返し見つけて、最後の `true` と交換します。
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// このイテレータの要素が、指定された述語に従ってパーティション化されているかどうかを確認します。これにより、`true` を返すすべての要素が `false` を返すすべての要素よりも優先されます。
    ///
    ///
    /// [`partition()`] および [`partition_in_place()`] も参照してください。
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // すべてのアイテムが `true` をテストするか、最初の句が `false` で停止し、その後に `true` アイテムがないことを確認します。
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// 関数が正常に返される限り関数を適用し、単一の最終値を生成するイテレータメソッド。
    ///
    /// `try_fold()` 初期値と、'accumulator' と要素の 2 つの引数を持つクロージャの 2 つの引数を取ります。
    /// クロージャは、アキュムレータが次の反復で持つ必要のある値で正常に戻るか、エラー値で失敗を返し、すぐに (short-circuiting) で呼び出し元に伝播されます。
    ///
    ///
    /// 初期値は、アキュムレータが最初の呼び出しで持つ値です。イテレータのすべての要素に対してクロージャの適用が成功した場合、`try_fold()` は最終的なアキュムレータを成功として返します。
    ///
    /// 折りたたみは、何かのコレクションがあり、そこから単一の値を生成したい場合に役立ちます。
    ///
    /// # 実装者への注記
    ///
    /// 他のいくつかの (forward) メソッドには、これに関してデフォルトの実装があるため、デフォルトの `for` ループ実装よりも優れた処理ができる場合は、これを明示的に実装してみてください。
    ///
    /// 特に、このイテレーターを構成する内部パーツでこの呼び出し `try_fold()` を実行するようにしてください。
    /// 複数の呼び出しが必要な場合、`?` 演算子は、アキュムレータ値を連鎖させるのに便利な場合がありますが、早期に戻る前に維持する必要のある不変条件に注意してください。
    /// これは `&mut self` メソッドであるため、ここでエラーが発生した後、反復を再開できる必要があります。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 配列のすべての要素のチェックされた合計
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // この合計は、100 要素を追加するとオーバーフローします
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // 短絡しているため、残りの要素はイテレータを介して引き続き使用できます。
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// イテレーター内の各アイテムにフォールブル関数を適用し、最初のエラーで停止してそのエラーを返すイテレーターメソッド。
    ///
    ///
    /// これは、[`for_each()`] のフォールブル形式、または [`try_fold()`] のステートレスバージョンと考えることもできます。
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // 短絡したため、残りのアイテムはまだイテレーターにあります。
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// 操作を適用してすべての要素をアキュムレータに折りたたんで、最終結果を返します。
    ///
    /// `fold()` 初期値と、'accumulator' と要素の 2 つの引数を持つクロージャの 2 つの引数を取ります。
    /// クロージャは、アキュムレータが次の反復のために持つべき値を返します。
    ///
    /// 初期値は、アキュムレータが最初の呼び出しで持つ値です。
    ///
    /// このクロージャーをイテレーターのすべての要素に適用した後、`fold()` はアキュムレーターを返します。
    ///
    /// この操作は、'reduce' または 'inject' と呼ばれることもあります。
    ///
    /// 折りたたみは、何かのコレクションがあり、そこから単一の値を生成したい場合に役立ちます。
    ///
    /// Note: `fold()`、およびイテレーター全体をトラバースする同様のメソッドは、結果が有限時間で決定可能な traits であっても、無限イテレーターでは終了しない場合があります。
    ///
    /// Note: アキュムレータタイプとアイテムタイプが同じである場合、[`reduce()`] を使用して最初の要素を初期値として使用できます。
    ///
    /// # 実装者への注記
    ///
    /// 他のいくつかの (forward) メソッドには、これに関してデフォルトの実装があるため、デフォルトの `for` ループ実装よりも優れた処理ができる場合は、これを明示的に実装してみてください。
    ///
    ///
    /// 特に、このイテレーターを構成する内部パーツでこの呼び出し `fold()` を実行するようにしてください。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // 配列のすべての要素の合計
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ここで、反復の各ステップを見ていきましょう。
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// そして、私たちの最終結果は、 `6`.
    ///
    /// イテレーターをあまり使用したことがない人は、結果を作成するためにリストを含む `for` ループを使用するのが一般的です。それらは `fold()`s に変えることができます:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for ループ:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // 彼らは同じです
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// 縮小操作を繰り返し適用することにより、要素を 1 つに縮小します。
    ///
    /// イテレータが空の場合、[`None`] を返します。それ以外の場合は、削減の結果を返します。
    ///
    /// 少なくとも 1 つの要素を持つイテレーターの場合、これは [`fold()`] と同じであり、イテレーターの最初の要素が初期値であり、後続のすべての要素がその中に折りたたまれます。
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// 最大値を見つける:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// イテレータのすべての要素が述語と一致するかどうかをテストします。
    ///
    /// `all()` `true` または `false` を返すクロージャを取ります。このクロージャをイテレータの各要素に適用し、それらがすべて `true` を返す場合は、`all()` も適用します。
    /// それらのいずれかが `false` を返す場合、`false` を返します。
    ///
    /// `all()` 短絡している; つまり、`false` が見つかるとすぐに処理を停止します。他に何が起こっても、結果は `false` になります。
    ///
    ///
    /// 空のイテレータは `true` を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// 最初の `false` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// イテレータのいずれかの要素が述語に一致するかどうかをテストします。
    ///
    /// `any()` `true` または `false` を返すクロージャを取ります。このクロージャーをイテレーターの各要素に適用し、それらのいずれかが `true` を返す場合は、`any()` も適用します。
    /// それらがすべて `false` を返す場合、`false` を返します。
    ///
    /// `any()` 短絡している; つまり、`true` が見つかるとすぐに処理を停止します。他に何が起こっても、結果は `true` になります。
    ///
    ///
    /// 空のイテレータは `false` を返します。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// 最初の `true` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// 述語を満たすイテレーターの要素を検索します。
    ///
    /// `find()` `true` または `false` を返すクロージャを取ります。
    /// このクロージャをイテレータの各要素に適用し、それらのいずれかが `true` を返す場合、`find()` は [`Some(element)`] を返します。
    /// それらがすべて `false` を返す場合、[`None`] を返します。
    ///
    /// `find()` 短絡している; つまり、クロージャが `true` を返すとすぐに処理を停止します。
    ///
    /// `find()` は参照を取得し、多くのイテレータが参照を反復処理するため、これにより、引数が二重参照であるという混乱を招く可能性があります。
    ///
    /// この効果は、`&&x` を使用した以下の例で確認できます。
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// 最初の `true` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` は `iter.filter(f).next()` と同等であることに注意してください。
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// iterator の要素に関数を適用し、最初の none 以外の結果を返します。
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` と同等です。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// iterator の要素に関数を適用し、最初の真の結果または最初のエラーを返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// イテレータ内の要素を検索し、そのインデックスを返します。
    ///
    /// `position()` `true` または `false` を返すクロージャを取ります。
    /// このクロージャをイテレータの各要素に適用し、そのうちの 1 つが `true` を返す場合、`position()` は [`Some(index)`] を返します。
    /// それらすべてが `false` を返す場合、[`None`] を返します。
    ///
    /// `position()` 短絡している; つまり、`true` が見つかるとすぐに処理を停止します。
    ///
    /// # オーバーフロー動作
    ///
    /// このメソッドはオーバーフローを防止しないため、一致しない要素が [`usize::MAX`] を超えると、間違った結果または panics が生成されます。
    ///
    /// デバッグアサーションが有効になっている場合、panic が保証されます。
    ///
    /// # Panics
    ///
    /// イテレータに `usize::MAX` を超える不一致要素がある場合、この関数は panic になる可能性があります。
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// 最初の `true` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // 返されるインデックスはイテレータの状態によって異なります
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// イテレータ内の要素を右から検索し、そのインデックスを返します。
    ///
    /// `rposition()` `true` または `false` を返すクロージャを取ります。
    /// このクロージャーをイテレーターの各要素に最後から適用し、そのうちの 1 つが `true` を返す場合、`rposition()` は [`Some(index)`] を返します。
    ///
    /// それらすべてが `false` を返す場合、[`None`] を返します。
    ///
    /// `rposition()` 短絡している; つまり、`true` が見つかるとすぐに処理を停止します。
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// 最初の `true` で停止:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // より多くの要素があるため、`iter` を引き続き使用できます。
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // `ExactSizeIterator` は、要素の数が `usize` に収まることを意味するため、ここでオーバーフローチェックを行う必要はありません。
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// イテレータの最大要素を返します。
    ///
    /// 複数の要素が等しく最大の場合、最後の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// イテレータの最小要素を返します。
    ///
    /// 複数の要素が等しく最小の場合、最初の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// 指定された関数から最大値を与える要素を返します。
    ///
    ///
    /// 複数の要素が等しく最大の場合、最後の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// 指定された比較関数に関して最大値を与える要素を返します。
    ///
    ///
    /// 複数の要素が等しく最大の場合、最後の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// 指定された関数から最小値を与える要素を返します。
    ///
    ///
    /// 複数の要素が等しく最小の場合、最初の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// 指定された比較関数に関して最小値を与える要素を返します。
    ///
    ///
    /// 複数の要素が等しく最小の場合、最初の要素が返されます。
    /// イテレータが空の場合、[`None`] が返されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// イテレータの方向を逆にします。
    ///
    /// 通常、イテレータは左から右に繰り返します。
    /// `rev()` を使用した後、イテレータは代わりに右から左に繰り返します。
    ///
    /// これは、イテレータに終了がある場合にのみ可能であるため、`rev()` は [`DoubleEndedIterator`] でのみ機能します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ペアのイテレータをコンテナのペアに変換します。
    ///
    /// `unzip()` ペアのイテレーター全体を消費し、2 つのコレクションを生成します。1 つはペアの左側の要素から、もう 1 つは右側の要素からです。
    ///
    ///
    /// この関数は、ある意味で [`zip`] の反対です。
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// すべての要素をコピーするイテレータを作成します。
    ///
    /// これは、`&T` を超えるイテレーターがあるが、`T` を超えるイテレーターが必要な場合に役立ちます。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // コピーされたものは .map(|&x| x) と同じです
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// すべての要素を [`clone`] するイテレータを作成します。
    ///
    /// これは、`&T` を超えるイテレーターがあるが、`T` を超えるイテレーターが必要な場合に役立ちます。
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned は、整数の場合、.map(|&x| x) と同じです。
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// イテレータを際限なく繰り返します。
    ///
    /// [`None`] で停止する代わりに、イテレータは最初から再開します。再度繰り返した後、最初からやり直します。そしてまた。
    /// そしてまた。
    /// Forever.
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// イテレータの要素を合計します。
    ///
    /// 各要素を取得し、それらを合計して、結果を返します。
    ///
    /// 空のイテレータは、型のゼロ値を返します。
    ///
    /// # Panics
    ///
    /// `sum()` を呼び出し、プリミティブ整数型が返される場合、計算がオーバーフローし、デバッグアサーションが有効になっていると、このメソッドは panic になります。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// イテレータ全体を反復処理し、すべての要素を乗算します
    ///
    /// 空のイテレータは、型の 1 つの値を返します。
    ///
    /// # Panics
    ///
    /// `product()` を呼び出し、プリミティブ整数型が返される場合、計算がオーバーフローし、デバッグアサーションが有効になっていると、メソッドは panic になります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) この [`Iterator`] の要素を別の要素と比較します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 指定された比較関数に関して、この [`Iterator`] の要素を別の要素と比較します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) この [`Iterator`] の要素を別の要素と比較します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) 指定された比較関数に関して、この [`Iterator`] の要素を別の要素と比較します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// この [`Iterator`] の要素が別の要素と等しいかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// この [`Iterator`] の要素が、指定された等式関数に関して別の要素と等しいかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// この [`Iterator`] の要素が他の要素と等しくないかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// この [`Iterator`] の要素が他の要素より [lexicographically](Ord#lexicographical-comparison) 小さいかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// この [`Iterator`] の要素が他の要素の [lexicographically](Ord#lexicographical-comparison) 以下であるかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// この [`Iterator`] の要素が他の要素より [lexicographically](Ord#lexicographical-comparison) 大きいかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// この [`Iterator`] の要素が他の要素の [lexicographically](Ord#lexicographical-comparison) 以上であるかどうかを判別します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// このイテレータの要素がソートされているかどうかを確認します。
    ///
    /// つまり、各要素 `a` とそれに続く要素 `b` について、`a <= b` が保持される必要があります。イテレータが正確にゼロまたは 1 つの要素を生成する場合、`true` が返されます。
    ///
    /// `Self::Item` が `PartialOrd` のみであり、`Ord` ではない場合、上記の定義は、2 つの連続する項目が比較できない場合、この関数が `false` を返すことを意味することに注意してください。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// このイテレータの要素が、指定されたコンパレータ関数を使用してソートされているかどうかを確認します。
    ///
    /// この関数は、`PartialOrd::partial_cmp` を使用する代わりに、指定された `compare` 関数を使用して、2 つの要素の順序を決定します。
    /// それを除けば、[`is_sorted`] と同等です。詳細については、そのドキュメントを参照してください。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// このイテレータの要素が、指定されたキー抽出関数を使用してソートされているかどうかを確認します。
    ///
    /// この関数は、イテレーターの要素を直接比較する代わりに、`f` によって決定された要素のキーを比較します。
    /// それを除けば、[`is_sorted`] と同等です。詳細については、そのドキュメントを参照してください。
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] を参照してください
    // 異常な名前は、メソッド解決での名前の衝突を回避するためのものです。#76479 を参照してください。
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}