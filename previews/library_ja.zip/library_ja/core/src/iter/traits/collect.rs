/// [`Iterator`] からの変換。
///
/// タイプに `FromIterator` を実装することにより、イテレーターから `FromIterator` を作成する方法を定義します。
/// これは、ある種のコレクションを記述するタイプで一般的です。
///
/// [`FromIterator::from_iter()`] 明示的に呼び出されることはめったになく、代わりに [`Iterator::collect()`] メソッドを介して使用されます。
///
/// その他の例については、[`Iterator::collect()`]'s のドキュメントを参照してください。
///
/// 参照: [`IntoIterator`].
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] を使用して暗黙的に `FromIterator` を使用する:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// タイプに `FromIterator` を実装する:
///
/// ```
/// use std::iter::FromIterator;
///
/// // サンプルコレクション、これは Vec の単なるラッパーです <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // いくつかのメソッドを与えて、作成して追加できるようにします。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // FromIterator を実装します
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // これで、新しいイテレーターを作成できます...
/// let iter = (0..5).into_iter();
///
/// // ... そしてそれから MyCollection を作成します
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // 作品も集めよう!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// イテレータから値を作成します。
    ///
    /// 詳細については、[module-level documentation] を参照してください。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] への変換。
///
/// タイプに `IntoIterator` を実装することにより、イテレーターに変換する方法を定義します。
/// これは、ある種のコレクションを記述するタイプで一般的です。
///
/// `IntoIterator` を実装する利点の 1 つは、タイプが [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) になることです。
///
///
/// 参照: [`FromIterator`].
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// タイプに `IntoIterator` を実装する:
///
/// ```
/// // サンプルコレクション、これは Vec の単なるラッパーです <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // いくつかのメソッドを与えて、作成して追加できるようにします。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // IntoIterator を実装します
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // これで、新しいコレクションを作成できます...
/// let mut c = MyCollection::new();
///
/// // ... それにいくつかのものを追加します ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... そしてそれをイテレーターに変えます:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` を trait bound として使用するのが一般的です。これにより、入力コレクションタイプは、それがイテレーターである限り変更できます。
/// 追加の境界は、に制限することで指定できます
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// 繰り返される要素のタイプ。
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// これをどの種類のイテレータに変えていますか?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// 値からイテレーターを作成します。
    ///
    /// 詳細については、[module-level documentation] を参照してください。
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// イテレーターのコンテンツでコレクションを拡張します。
///
/// イテレーターは一連の値を生成し、コレクションは一連の値と考えることもできます。
/// `Extend` trait はこのギャップを埋め、そのイテレーターのコンテンツを含めることでコレクションを拡張できるようにします。
/// 既存のキーを使用してコレクションを拡張すると、そのエントリが更新されます。同じキーを持つ複数のエントリを許可するコレクションの場合は、そのエントリが挿入されます。
///
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// // 文字列をいくつかの文字で拡張できます。
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` の実装:
///
/// ```
/// // サンプルコレクション、これは Vec の単なるラッパーです <T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // いくつかのメソッドを与えて、作成して追加できるようにします。
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection には i32 のリストがあるため、Extend for i32 を実装します
/// impl Extend<i32> for MyCollection {
///
///     // これは、具体的なタイプの署名を使用すると少し簡単になります。i32 を提供するイテレーターに変換できるものなら何でも extend を呼び出すことができます。
///     // MyCollection に入れるには i32 が必要だからです。
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // 実装は非常に簡単です。イテレータをループし、各要素を add() でループします。
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // コレクションをさらに 3 つの数字で拡張しましょう
/// c.extend(vec![1, 2, 3]);
///
/// // これらの要素を最後に追加しました
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// イテレーターの内容でコレクションを拡張します。
    ///
    /// これがこの trait に必要な唯一の方法であるため、[trait-level] ドキュメントには詳細が含まれています。
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 文字列をいくつかの文字で拡張できます。
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// 正確に 1 つの要素でコレクションを拡張します。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// 指定された数の追加要素のコレクションの容量を予約します。
    ///
    /// デフォルトの実装は何もしません。
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}