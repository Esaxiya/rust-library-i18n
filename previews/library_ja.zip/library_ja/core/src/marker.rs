//! プリミティブ traits と、タイプの基本的なプロパティを表すタイプ。
//!
//! Rust タイプは、固有のプロパティに応じてさまざまな便利な方法で分類できます。
//! これらの分類は、traits として表されます。
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// スレッドの境界を越えて転送できるタイプ。
///
/// この trait は、コンパイラーが適切であると判断したときに自動的に実装されます。
///
/// 非 `Send` タイプの例は、参照カウントポインタ [`rc::Rc`][`Rc`] です。
/// 2 つのスレッドが同じ参照カウント値を指す [`Rc`] のクローンを作成しようとすると、[`Rc`] はアトミック操作を使用しないため、参照カウントを同時に更新しようとする可能性があります。これは [undefined behavior][ub] です。
///
/// そのいとこである [`sync::Arc`][arc] は、アトミック操作を使用するため (オーバーヘッドが発生します)、したがって `Send` です。
///
/// 詳細については、[the Nomicon](../../nomicon/send-and-sync.html) を参照してください。
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// コンパイル時に既知の一定サイズのタイプ。
///
/// すべてのタイプパラメータには、`Sized` の暗黙の境界があります。適切でない場合は、特別な構文 `?Sized` を使用してこの境界を削除できます。
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // 構造体 FooUse(Foo<[i32]>);// エラー: Sized は [i32] に実装されていません
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// 1 つの例外は、trait の暗黙的な `Self` タイプです。
/// trait には暗黙の `Sized` バインドがありません。これは、[trait オブジェクト] と互換性がないためです。定義上、trait はすべての可能な実装者と連携する必要があるため、任意のサイズにすることができます。
///
///
/// Rust を使用すると `Sized` を trait にバインドできますが、後でそれを使用して trait オブジェクトを形成することはできません。
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn バー = &Impl;// エラー: trait `Bar` をオブジェクトにすることはできません
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // たとえば、デフォルトの場合、`[T]: !Default` が評価可能である必要があります
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// "unsized" から動的サイズのタイプになり得るタイプ。
///
/// たとえば、サイズ変更された配列タイプ `[i8; 2]` は、`Unsize<[i8]>` および `Unsize<dyn fmt::Debug>` を実装します。
///
/// `Unsize` のすべての実装は、コンパイラによって自動的に提供されます。
///
/// `Unsize` 以下のために実装されています:
///
/// - `[T; N]` `Unsize<[T]>` です
/// - `T` `T: Trait` の場合は `Unsize<dyn Trait>` です
/// - `Foo<..., T, ...>` 次の場合は `Unsize<Foo<..., U, ...>>` です。
///   - `T: Unsize<U>`
///   - Foo は構造体です
///   - `Foo` の最後のフィールドのみが `T` を含むタイプを持っています
///   - `T` 他のフィールドのタイプの一部ではありません
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo` の最後のフィールドのタイプが `Bar<T>` の場合
///
/// `Unsize` [`ops::CoerceUnsized`] とともに使用され、[`Rc`] などの "user-defined" コンテナに動的なサイズのタイプを含めることができます。
/// 詳細については、[DST coercion RFC][RFC982] および [the nomicon entry on coercion][nomicon-coerce] を参照してください。
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// パターン一致で使用される定数には trait が必要です。
///
/// `PartialEq` を派生させるタイプは、タイプパラメータが `Eq` を実装するかどうかに関係なく、この trait を自動的に実装します。
///
/// `const` アイテムにこの trait を実装しない型が含まれている場合、その型は (1.) が `PartialEq` を実装しない (つまり、定数はコード生成が使用可能であると想定する比較メソッドを提供しない) か、(2.) が独自に実装します。* `PartialEq` のバージョン (構造的同等性の比較に準拠していないと想定)。
///
///
/// 上記の 2 つのシナリオのいずれかで、パターン一致でのこのような定数の使用を拒否します。
///
/// 属性ベースの設計からこの trait への移行の動機となった [structural match RFC][RFC1445] および [issue 63438] も参照してください。
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// パターン一致で使用される定数には trait が必要です。
///
/// `Eq` を派生するすべての型は、その型パラメーターが `Eq` を実装するかどうかに関係なく、この trait を自動的に実装します。
///
/// これは、型システムの制限を回避するためのハックです。
///
/// # Background
///
/// パターン一致で使用される定数のタイプに属性 `#[derive(PartialEq, Eq)]` が必要です。
///
/// より理想的な世界では、特定のタイプが `StructuralPartialEq` trait *と*`Eq` trait の両方を実装していることを確認するだけで、その要件を確認できます。
/// ただし、`derive(PartialEq, Eq)` を *実行* する ADT を使用することができ、コンパイラーに受け入れてもらいたい場合でも、定数の型は `Eq` を実装できません。
///
/// つまり、次のような場合です。
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (上記のコードの問題は、`for <'a> fn(&'a _)` does not implement those traits.) であるため、`Wrap<fn(&())>` が `PartialEq` も `Eq` も実装していないことです。
///
/// したがって、`StructuralPartialEq` と単なる `Eq` の単純なチェックに依存することはできません。
///
/// これを回避するためのハックとして、2 つの派生 (`#[derive(PartialEq)]` と `#[derive(Eq)]`) のそれぞれによって注入された 2 つの別々の traits を使用し、構造一致チェックの一部として両方が存在することを確認します。
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ビットをコピーするだけで値を複製できるタイプ。
///
/// デフォルトでは、変数バインディングには「移動セマンティクス」があります。言い換えると:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` に移行したため、使用できません
///
/// // println! ( "{: ? }"、x) ;// エラー: 移動した値の使用
/// ```
///
/// ただし、型が `Copy` を実装している場合は、代わりに「コピーセマンティクス」があります。
///
/// ```
/// // `Copy` の実装を導き出すことができます。
/// // `Clone` `Copy` のスーパートレイトであるため、これも必要です。
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` のコピーです
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// これらの 2 つの例では、割り当て後に `x` へのアクセスが許可されるかどうかだけが異なることに注意してください。
/// 内部的には、コピーと移動の両方でビットがメモリにコピーされる可能性がありますが、これは最適化されていない場合もあります。
///
/// ## `Copy` を実装するにはどうすればよいですか?
///
/// タイプに `Copy` を実装する方法は 2 つあります。最も簡単なのは `derive` を使用することです。
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` および `Clone` を手動で実装することもできます。
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// 2 つの間に小さな違いがあります。`derive` 戦略では、タイプパラメータに `Copy` バインドも配置されますが、これは常に必要なわけではありません。
///
/// ## `Copy` と `Clone` の違いは何ですか?
///
/// コピーは、たとえば割り当て `y = x` の一部として暗黙的に発生します。`Copy` の動作は過負荷ではありません。それは常に単純なビット単位のコピーです。
///
/// クローン作成は明示的なアクション、`x.clone()` です。[`Clone`] の実装は、値を安全に複製するために必要なタイプ固有の動作を提供できます。
/// たとえば、[`String`] 用の [`Clone`] の実装では、ポイントされた文字列バッファをヒープにコピーする必要があります。
/// [`String`] 値の単純なビット単位のコピーは、ポインタをコピーするだけであり、行の途中でダブルフリーになります。
/// このため、[`String`] は [`Clone`] ですが、`Copy` ではありません。
///
/// [`Clone`] は `Copy` のスーパートレイトであるため、`Copy` であるすべてのものも [`Clone`] を実装する必要があります。
/// タイプが `Copy` の場合、その [`Clone`] 実装は `*self` を返すだけで済みます (上記の例を参照)。
///
/// ## 私のタイプはいつ `Copy` になりますか?
///
/// すべてのコンポーネントが `Copy` を実装している場合、型は `Copy` を実装できます。たとえば、この構造は `Copy` になります。
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// 構造体は `Copy` にすることができ、[`i32`] は `Copy` であるため、`Point` は `Copy` になる資格があります。
/// 対照的に、考慮してください
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// [`Vec<T>`] は `Copy` ではないため、構造体 `PointList` は `Copy` を実装できません。`Copy` 実装を導出しようとすると、エラーが発生します。
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// 共有参照 (`&T`) も `Copy` であるため、`Copy` ではないタイプ `T` の共有参照を保持している場合でも、タイプを `Copy` にすることができます。
/// `Copy` を実装できる次の構造について考えてみます。これは、上からの非 `Copy` タイプ `PointList` への *共有参照* のみを保持しているためです。
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## 私のタイプを `Copy` にすることが *できない* のはいつですか?
///
/// 一部のタイプは安全にコピーできません。たとえば、`&mut T` をコピーすると、エイリアス化された可変参照が作成されます。
/// [`String`] をコピーすると、[`String`] のバッファを管理する責任が重複し、ダブルフリーになります。
///
/// 後者の場合を一般化すると、[`Drop`] を実装するタイプは、独自の [`size_of::<T>`] バイト以外のリソースを管理しているため、`Copy` にすることはできません。
///
/// `Copy` 以外のデータを含む構造体または列挙型に `Copy` を実装しようとすると、エラー [E0204] が発生します。
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## 私のタイプはいつ `Copy` にする必要がありますか?
///
/// 一般的に、タイプ _can_ が `Copy` を実装している場合は、実装する必要があります。
/// ただし、`Copy` の実装は、タイプのパブリック API の一部であることに注意してください。
/// future でタイプが非 `Copy` になる可能性がある場合は、API の変更が壊れるのを防ぐために、ここで `Copy` 実装を省略するのが賢明かもしれません。
///
/// ## 追加の実装者
///
/// [implementors listed below][impls] に加えて、次のタイプも `Copy` を実装します。
///
/// * 関数アイテムタイプ (つまり、関数ごとに定義された個別のタイプ)
/// * 関数ポインタ型 (例: `fn() -> i32`)
/// * アイテムタイプが `Copy` (`[i32; 123456]` など) も実装している場合の、すべてのサイズの配列タイプ
/// * 各コンポーネントが `Copy` (`()`、`(i32, bool)` など) も実装している場合のタプルタイプ
/// * クロージャータイプ。環境から値をキャプチャしない場合、またはキャプチャされたすべての値が `Copy` 自体を実装する場合。
///   共有参照によってキャプチャされた変数は常に `Copy` を実装しますが (参照先が実装していなくても)、可変参照によってキャプチャされた変数は `Copy` を実装しないことに注意してください。
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) これにより、有効期間の境界が満たされていないために `Copy` を実装していない型をコピーできます (`A<'static>: Copy` と `A<'_>: Clone` のみの場合は `A<'_>` をコピーします)。
// `Copy` には、標準ライブラリにすでに存在する多くの既存の特殊化があり、現在この動作を安全に行う方法がないため、現時点ではこの属性があります。
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy` の実装を生成するマクロを導出します。
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// スレッド間で参照を共有しても安全なタイプ。
///
/// この trait は、コンパイラーが適切であると判断したときに自動的に実装されます。
///
/// 正確な定義は次のとおりです。`&T` が [`Send`] である場合に限り、タイプ `T` は [`Sync`] です。
/// つまり、スレッド間で `&T` 参照を渡すときに、[undefined behavior][ub] (データ競合を含む) の可能性がない場合。
///
/// 当然のことながら、[`u8`] や [`f64`] などのプリミティブ型はすべて [`Sync`] であり、タプル、構造体、列挙型など、それらを含む単純な集計型も同様です。
/// 基本的な [`Sync`] タイプのその他の例には、`&T` などの "immutable" タイプや、[`Box<T>`][box]、[`Vec<T>`][vec]、その他のほとんどのコレクションタイプなどの単純な継承された可変性を持つタイプがあります。
///
/// (コンテナを [`Sync`] にするには、汎用パラメータを [`Sync`] にする必要があります。)
///
/// 定義のやや意外な結果は、`&mut T` が `Sync` (`T` が `Sync` の場合) であるということですが、同期されていない突然変異を提供する可能性があるようです。
/// 秘訣は、共有参照 (つまり、`& &mut T`) の背後にある可変参照が、`& &T` であるかのように読み取り専用になることです。
/// したがって、データ競合のリスクはありません。
///
/// `Sync` 以外のタイプは、[`Cell`][cell] や [`RefCell`][refcell] など、スレッドセーフではない形式の "interior mutability" を持つタイプです。
/// これらのタイプは、不変の共有参照を介してもコンテンツの変更を可能にします。
/// たとえば、[`Cell<T>`][cell] の `set` メソッドは `&self` を使用するため、共有参照 [`&Cell<T>`][cell] のみが必要です。
/// このメソッドは同期を実行しないため、[`Cell`][cell] を `Sync` にすることはできません。
///
/// 非 `Sync` タイプの別の例は、参照カウントポインタ [`Rc`][rc] です。
/// 任意の参照 [`&Rc<T>`][rc] が与えられると、新しい [`Rc<T>`][rc] のクローンを作成して、非アトミックな方法で参照カウントを変更できます。
///
/// スレッドセーフな内部可変性が必要な場合のために、Rust は [atomic data types] と、[`sync::Mutex`][mutex] および [`sync::RwLock`][rwlock] を介した明示的なロックを提供します。
/// これらのタイプは、突然変異がデータ競合を引き起こさないことを保証します。したがって、タイプは `Sync` です。
/// 同様に、[`sync::Arc`][arc] は [`Rc`][rc] のスレッドセーフなアナログを提供します。
///
/// 内部可変性を備えたタイプは、共有参照を介して突然変異させることができる value(s) の周りの [`cell::UnsafeCell`][unsafecell] ラッパーも使用する必要があります。
/// これを行わないのは [undefined behavior][ub] です。
/// たとえば、[`transmute`][transmute]-`&T` から `&mut T` への変換は無効です。
///
/// `Sync` の詳細については、[the Nomicon][nomicon-send-and-sync] を参照してください。
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): `rustc_on_unimplemented` でメモを追加するためのサポートがベータ版になり、クロージャが要件チェーンのどこかにあるかどうかを確認するために拡張されたら、(#48534) のように拡張します。
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like" が `T` を所有していることを示すために使用されるゼロサイズのタイプ。
///
/// `PhantomData<T>` フィールドを型に追加すると、実際にはそうではない場合でも、型が `T` 型の値を格納しているかのように動作することがコンパイラに通知されます。
/// この情報は、特定の安全特性を計算するときに使用されます。
///
/// `PhantomData<T>` の使用方法の詳細については、[the Nomicon](../../nomicon/phantom-data.html) を参照してください。
///
/// # 恐ろしいメモ👻👻👻
///
/// どちらも怖い名前ですが、`PhantomData` と「ファントムタイプ」は関連していますが、同一ではありません。ファントムタイプパラメータは、使用されることのない単なるタイプパラメータです。
/// Rust では、これによりコンパイラが文句を言うことがよくあります。解決策は、`PhantomData` を介して "dummy" の使用を追加することです。
///
/// # Examples
///
/// ## 未使用の寿命パラメータ
///
/// おそらく、`PhantomData` の最も一般的な使用例は、通常は安全でないコードの一部として、未使用のライフタイムパラメータを持つ構造です。
/// たとえば、`*const T` 型の 2 つのポインタがあり、おそらくどこかの配列を指している構造体 `Slice` を次に示します。
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// 基礎となるデータは `'a` の有効期間のみ有効であるため、`Slice` は `'a` よりも長生きしないようにする必要があります。
/// ただし、この意図はコードでは表現されていません。これは、ライフタイム `'a` が使用されておらず、どのデータに適用されるかが明確でないためです。
/// これを修正するには、`Slice` 構造に参照 `&'a T` が含まれているかのように動作するようにコンパイラに指示します。
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// これには、注釈 `T: 'a` も必要です。これは、`T` 内のすべての参照が `'a` の存続期間にわたって有効であることを示します。
///
/// `Slice` を初期化するときは、フィールド `phantom` に値 `PhantomData` を指定するだけです。
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## 未使用のタイプパラメータ
///
/// そのデータが実際には構造自体に見つからない場合でも、構造が "tied" であるデータのタイプを示す未使用の型パラメーターがある場合があります。
/// これが [FFI] で発生する例を次に示します。
/// 外部インターフェイスは、タイプ `*mut ()` のハンドルを使用して、さまざまなタイプの Rust 値を参照します。
/// ハンドルをラップする構造体 `ExternalResource` のファントムタイプパラメーターを使用して、Rust タイプを追跡します。
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## 所有権とドロップチェック
///
/// タイプ `PhantomData<T>` のフィールドを追加すると、そのタイプがタイプ `T` のデータを所有していることを示します。これは、タイプがドロップされると、タイプ `T` の 1 つ以上のインスタンスがドロップされる可能性があることを意味します。
/// これは、Rust コンパイラの [drop check] 分析に関係しています。
///
/// 構造体が実際にタイプ `T` のデータを *所有* していない場合は、所有権を示さないように、`PhantomData<&'a T>` (ideally) や `PhantomData<*const T>` (有効期間が適用されない場合) などの参照タイプを使用することをお勧めします。
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// コンパイラ内部の trait は、列挙型識別子のタイプを示すために使用されます。
///
/// この trait はすべてのタイプに自動的に実装され、[`mem::Discriminant`] に保証を追加するものではありません。
/// `DiscriminantKind::Discriminant` と `mem::Discriminant` の間で変換するのは **未定義の動作** です。
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` で要求される trait bounds を満たす必要がある判別式のタイプ。
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// コンパイラ内部の trait は、型に `UnsafeCell` が内部に含まれているかどうかを判断するために使用されますが、間接的には含まれていません。
///
/// これは、たとえば、そのタイプの `static` が読み取り専用の静的メモリに配置されるか書き込み可能な静的メモリに配置されるかに影響します。
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// 固定後に安全に移動できるタイプ。
///
/// Rust 自体には不動のタイプの概念がなく、移動 (割り当てや [`mem::replace`] など) は常に安全であると見なされます。
///
/// 代わりに、[`Pin`][Pin] タイプを使用して、型システムを通過するのを防ぎます。[`Pin<P<T>>`][Pin] ラッパーでラップされたポインター `P<T>` を移動することはできません。
/// 固定の詳細については、[`pin` module] のドキュメントを参照してください。
///
/// `T` に `Unpin` trait を実装すると、タイプを固定する際の制限がなくなり、[`mem::replace`] などの機能を使用して `T` を [`Pin<P<T>>`][Pin] から移動できるようになります。
///
///
/// `Unpin` 固定されていないデータにはまったく影響しません。
/// 特に、[`mem::replace`] は `!Unpin` データを喜んで移動します (`T: Unpin` の場合だけでなく、すべての `&mut T` で機能します)。
/// ただし、[`Pin<P<T>>`][Pin] にラップされたデータで [`mem::replace`] を使用することはできません。これは、必要な `&mut T` を取得できないためです。これが、このシステムを機能させる理由です。
///
/// したがって、これは、たとえば、`Unpin` を実装するタイプでのみ実行できます。
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace` を呼び出すには、変更可能な参照が必要です。
/// // `Pin::deref_mut` を呼び出す (implicitly) によってこのような参照を取得できますが、これは `String` が `Unpin` を実装しているためにのみ可能です。
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// この trait は、ほぼすべてのタイプに自動的に実装されます。
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` を実装していないマーカータイプ。
///
/// タイプに `PhantomPinned` が含まれている場合、デフォルトでは `Unpin` は実装されません。
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// プリミティブ型の `Copy` の実装。
///
/// Rust で記述できない実装は、`rustc_trait_selection` の `traits::SelectionContext::copy_clone_conditions()` で実装されます。
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// 共有参照はコピーできますが、可変参照は *できません*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}