//! このモジュールは `Any` trait を実装します。これにより、ランタイムリフレクションを通じて任意の `'static` 型の動的型付けが可能になります。
//!
//! `Any` それ自体を使用して `TypeId` を取得でき、trait オブジェクトとして使用するとより多くの機能があります。
//! `&dyn Any` (借用された trait オブジェクト) として、`is` メソッドと `downcast_ref` メソッドがあり、含まれている値が特定の型であるかどうかをテストし、内部値への参照を型として取得します。
//! `&mut dyn Any` として、内部値への可変参照を取得するための `downcast_mut` メソッドもあります。
//! `Box<dyn Any>` `Box<T>` への変換を試みる `downcast` メソッドを追加します。
//! 詳細については、[`Box`] のドキュメントを参照してください。
//!
//! `&dyn Any` は、値が指定された具象型であるかどうかのテストに限定されており、型が trait を実装しているかどうかのテストには使用できないことに注意してください。
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # スマートポインタと `dyn Any`
//!
//! 特に `Box<dyn Any>` や `Arc<dyn Any>` などのタイプで `Any` を trait オブジェクトとして使用する場合に留意すべき動作のひとつは、値に対して `.type_id()` を呼び出すだけで、基になる trait オブジェクトではなく *コンテナ* の `TypeId` が生成されることです。
//!
//! これは、代わりにスマートポインタを `&dyn Any` に変換することで回避できます。これにより、オブジェクトの `TypeId` が返されます。
//! 例えば:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // あなたはこれを望む可能性が高いです:
//! let actual_id = (&*boxed).type_id();
//! // ... これより:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! 関数に渡された値をログアウトしたい状況を考えてみましょう。
//! 作業中の値が Debug を実装していることはわかっていますが、その具体的なタイプはわかりません。特定のタイプに特別な処理を加えたいと考えています。この場合、文字列値の長さを値の前に出力します。
//! コンパイル時に値の具体的なタイプがわからないため、代わりにランタイムリフレクションを使用する必要があります。
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // デバッグを実装するすべてのタイプのロガー関数。
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // 値を `String` に変換してみてください。
//!     // 成功した場合は、String` の長さとその値を出力します。
//!     // そうでない場合は、別のタイプです。装飾せずに印刷するだけです。
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // この関数は、作業を行う前にパラメーターをログアウトしたいと考えています。
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... 他の仕事をする
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// 任意の trait
///////////////////////////////////////////////////////////////////////////////

/// 動的型付けをエミュレートする trait。
///
/// ほとんどのタイプは `Any` を実装しています。ただし、「静的」以外の参照を含む型は含まれません。
/// 詳細については、[module-level documentation][mod] を参照してください。
///
/// [mod]: crate::any
// この trait は安全ではありませんが、安全でないコード (`downcast` など) での唯一の impl の `type_id` 関数の詳細に依存しています。通常、これは問題になりますが、`Any` の唯一の実装は包括的実装であるため、他のコードで `Any` を実装することはできません。
//
// この trait を安全でないものにする可能性があります (すべての実装を制御しているため、破損の原因にはなりません) が、実際には必要ではなく、安全でない traits と安全でないメソッドの区別についてユーザーを混乱させる可能性があるため、そうしないことを選択します (つまり、`type_id` は引き続き安全に呼び出すことができますが、ドキュメントにそのように記載することをお勧めします)。
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` の `TypeId` を取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// 任意の trait オブジェクトの拡張メソッド。
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// たとえば、スレッドを結合した結果を印刷して、`unwrap` で使用できることを確認します。
// ディスパッチがアップキャスティングで機能する場合、最終的には不要になる可能性があります。
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// ボックスタイプが `T` と同じ場合、`true` を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // この関数がインスタンス化されるタイプの `TypeId` を取得します。
        let t = TypeId::of::<T>();

        // trait オブジェクト (`self`) のタイプの `TypeId` を取得します。
        let concrete = self.type_id();

        // 両方の `TypeId` を同等に比較します。
        t == concrete
    }

    /// タイプが `T` の場合はボックス化された値への参照を返し、そうでない場合は `None` を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // 安全性: 正しいタイプを指しているかどうかを確認しただけで、信頼できます
            // すべてのタイプに Any を実装しているため、メモリの安全性をチェックします。他の impl は、私たちの impl と競合するため、存在できません。
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// タイプが `T` の場合はボックス化された値への可変参照を返し、そうでない場合は `None` を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // 安全性: 正しいタイプを指しているかどうかを確認しただけで、信頼できます
            // すべてのタイプに Any を実装しているため、メモリの安全性をチェックします。他の impl は、私たちの impl と競合するため、存在できません。
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// タイプ `Any` で定義されたメソッドに転送します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID とそのメソッド
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` は、タイプのグローバル一意識別子を表します。
///
/// 各 `TypeId` は不透明なオブジェクトであり、内部の検査はできませんが、クローン作成、比較、印刷、表示などの基本的な操作はできます。
///
///
/// `TypeId` は現在、`'static` に起因するタイプでのみ使用できますが、この制限は future で削除される可能性があります。
///
/// `TypeId` は `Hash`、`PartialOrd`、および `Ord` を実装していますが、ハッシュと順序は Rust リリース間で異なることに注意してください。
/// コード内でそれらに依存することに注意してください!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// このジェネリック関数がインスタンス化されたタイプの `TypeId` を返します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// 型の名前を文字列スライスとして返します。
///
/// # Note
///
/// これは診断用です。
/// 返される文字列の正確な内容と形式は、タイプのベストエフォートの説明であることを除いて、指定されていません。
/// たとえば、`type_name::<Option<String>>()` が返す可能性のある文字列には、`"Option<String>"` と `"std::option::Option<std::string::String>"` があります。
///
///
/// 複数のタイプが同じタイプ名にマップされる可能性があるため、返される文字列をタイプの一意の識別子と見なしてはなりません。
/// 同様に、型のすべての部分が返される文字列に表示されるという保証はありません。たとえば、現在、ライフタイム指定子は含まれていません。
/// さらに、コンパイラのバージョン間で出力が変わる場合があります。
///
/// 現在の実装では、コンパイラ診断および debuginfo と同じインフラストラクチャを使用していますが、これは保証されていません。
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// ポイントされた値のタイプの名前を文字列スライスとして返します。
/// これは `type_name::<T>()` と同じですが、変数の型が簡単に利用できない場合に使用できます。
///
/// # Note
///
/// これは診断用です。文字列の正確な内容と形式は、タイプのベストエフォートの説明であることを除いて、指定されていません。
/// たとえば、`type_name_of_val::<Option<String>>(None)` は `"Option<String>"` または `"std::option::Option<std::string::String>"` を返すことができますが、`"foobar"` は返しません。
///
/// さらに、コンパイラのバージョン間で出力が変わる場合があります。
///
/// この関数は trait オブジェクトを解決しません。つまり、`type_name_of_val(&7u32 as &dyn Debug)` は `"dyn Debug"` を返す可能性がありますが、`"u32"` は返しません。
///
/// タイプ名は、タイプの一意の識別子と見なされるべきではありません。
/// 複数のタイプが同じタイプ名を共有する場合があります。
///
/// 現在の実装では、コンパイラ診断および debuginfo と同じインフラストラクチャを使用していますが、これは保証されていません。
///
/// # Examples
///
/// デフォルトの整数型と浮動小数点型を出力します。
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}