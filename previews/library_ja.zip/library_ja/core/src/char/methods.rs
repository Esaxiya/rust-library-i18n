//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` が持つことができる最も高い有効なコードポイント。
    ///
    /// `char` は [Unicode Scalar Value] です。つまり、[Code Point] ですが、特定の範囲内にあるものだけです。
    /// `MAX` は、有効な [Unicode Scalar Value] である最も高い有効なコードポイントです。
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () は、デコードエラーを表すために Unicode で使用されます。
    ///
    /// これは、たとえば、不正な形式の UTF-8 バイトを [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) に与えるときに発生する可能性があります。
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` および `str` メソッドの Unicode 部分が基づいている [Unicode](http://www.unicode.org/) のバージョン。
    ///
    /// Unicode の新しいバージョンが定期的にリリースされ、その後、Unicode に依存する標準ライブラリのすべてのメソッドが更新されます。
    /// したがって、一部の `char` および `str` メソッドの動作と、この定数の値は時間の経過とともに変化します。
    /// これは、重大な変更とは見なされません。
    ///
    /// バージョン番号付けスキームは [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) で説明されています。
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` の UTF-16 エンコードコードポイント上にイテレーターを作成し、ペアになっていないサロゲートを `Err` として返します。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// 非可逆デコーダーは、`Err` の結果を置換文字に置き換えることで取得できます。
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` を `char` に変換します。
    ///
    /// すべての `char` は有効な [`u32`] であり、
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ただし、その逆は当てはまりません。すべての有効な [`u32`] が有効な `char` であるとは限りません。
    /// `from_u32()` 入力が `char` の有効な値でない場合、`None` を返します。
    ///
    /// これらのチェックを無視するこの関数の安全でないバージョンについては、[`from_u32_unchecked`] を参照してください。
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// 入力が有効な `char` でない場合に `None` を返す:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// 有効性を無視して、`u32` を `char` に変換します。
    ///
    /// すべての `char` は有効な [`u32`] であり、
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ただし、その逆は当てはまりません。すべての有効な [`u32`] が有効な `char` であるとは限りません。
    /// `from_u32_unchecked()` これを無視し、盲目的に `char` にキャストし、無効なものを作成する可能性があります。
    ///
    ///
    /// # Safety
    ///
    /// この関数は、無効な `char` 値を作成する可能性があるため、安全ではありません。
    ///
    /// この関数の安全なバージョンについては、[`from_u32`] 関数を参照してください。
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // 安全性: 安全契約は発信者が支持する必要があります。
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// 指定された基数の桁を `char` に変換します。
    ///
    /// ここでの 'radix' は、'base' と呼ばれることもあります。
    /// 2 の基数は、2 進数、10 の基数、10 進数、および 16 の基数、16 進数を示し、いくつかの一般的な値を示します。
    ///
    /// 任意の基数がサポートされています。
    ///
    /// `from_digit()` 入力が指定された基数の数字でない場合、`None` を返します。
    ///
    /// # Panics
    ///
    /// 36 より大きい基数が指定されている場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 10 進数の 11 は、基数 16 の 1 桁です。
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// 入力が数字でない場合に `None` を返す:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// 大きな基数を渡すと、panic が発生します。
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char` が指定された基数の数字であるかどうかを確認します。
    ///
    /// ここでの 'radix' は、'base' と呼ばれることもあります。
    /// 2 の基数は、2 進数、10 の基数、10 進数、および 16 の基数、16 進数を示し、いくつかの一般的な値を示します。
    ///
    /// 任意の基数がサポートされています。
    ///
    /// [`is_numeric()`] と比較して、この関数は文字 `0-9`、`a-z`、および `A-Z` のみを認識します。
    ///
    /// 'Digit' 次の文字のみとして定義されています。
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' のより包括的な理解については、[`is_numeric()`] を参照してください。
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 より大きい基数が指定されている場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// 大きな基数を渡すと、panic が発生します。
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` を指定された基数の数字に変換します。
    ///
    /// ここでの 'radix' は、'base' と呼ばれることもあります。
    /// 2 の基数は、2 進数、10 の基数、10 進数、および 16 の基数、16 進数を示し、いくつかの一般的な値を示します。
    ///
    /// 任意の基数がサポートされています。
    ///
    /// 'Digit' 次の文字のみとして定義されています。
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` が指定された基数の数字を参照していない場合、`None` を返します。
    ///
    /// # Panics
    ///
    /// 36 より大きい基数が指定されている場合は Panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// 数字以外を渡すと失敗します:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// 大きな基数を渡すと、panic が発生します。
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` が一定で、10 以下の場合の実行速度を向上させるために、コードはここで分割されます
        //
        let val = if likely(radix <= 10) {
            // 数字でない場合は、基数より大きい数値が作成されます。
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// 文字の 16 進数の Unicode エスケープを `char`s として生成するイテレータを返します。
    ///
    /// これにより、`\u{NNNNNN}` 形式の Rust 構文の文字がエスケープされます。`NNNNNN` は 16 進表現です。
    ///
    ///
    /// # Examples
    ///
    /// イテレータとして:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` を直接使用する:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// どちらも次と同等です。
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` の使用:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // または - ing1 は、c==0 の場合、コードが 1 桁を出力する必要があることを計算し、(同じ) (31、32) アンダーフローを回避することを保証します。
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // 最上位の 16 進数のインデックス
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// オプションで拡張書記素コードポイントのエスケープを許可する `escape_debug` の拡張バージョン。
    /// これにより、文字列の先頭にあるときに、非スペーシングマークなどの文字をより適切にフォーマットできます。
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// 文字のリテラルエスケープコードを `char`s として生成するイテレータを返します。
    ///
    /// これにより、`str` または `char` の `Debug` 実装と同様の文字がエスケープされます。
    ///
    ///
    /// # Examples
    ///
    /// イテレータとして:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` を直接使用する:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// どちらも次と同等です。
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` の使用:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// 文字のリテラルエスケープコードを `char`s として生成するイテレータを返します。
    ///
    /// デフォルトは、C ++ 11 や同様の C ファミリ言語を含むさまざまな言語で合法であるリテラルを生成することに偏って選択されています。
    /// 正確なルールは次のとおりです。
    ///
    /// * タブは `\t` としてエスケープされます。
    /// * キャリッジリターンは `\r` としてエスケープされます。
    /// * 改行は `\n` としてエスケープされます。
    /// * 一重引用符は `\'` としてエスケープされます。
    /// * 二重引用符は `\"` としてエスケープされます。
    /// * バックスラッシュは `\\` としてエスケープされます。
    /// * ' 印刷可能な ASCII' 範囲 `0x20`..`0x7e` を含む文字はエスケープされません。
    /// * 他のすべての文字には、16 進数の Unicode エスケープが与えられます。[`escape_unicode`] を参照してください。
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// イテレータとして:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` を直接使用する:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// どちらも次と同等です。
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` の使用:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 でエンコードされた場合にこの `char` が必要とするバイト数を返します。
    ///
    /// そのバイト数は常に 1 から 4 の間です。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` タイプは、その内容が UTF-8 であることを保証するため、各コードポイントが `char` として表された場合と `&str` 自体で表された場合の長さを比較できます。
    ///
    ///
    /// ```
    /// // 文字として
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // 両方とも 3 バイトとして表すことができます
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // &str として、これら 2 つは UTF-8 でエンコードされます
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // 合計 6 バイトかかることがわかります...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str と同じように
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 でエンコードされた場合にこの `char` が必要とする 16 ビットコードユニットの数を返します。
    ///
    ///
    /// この概念の詳細については、[`len_utf8()`] のドキュメントを参照してください。
    /// この関数はミラーですが、UTF-8 ではなく UTF-16 用です。
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// この文字を UTF-8 として提供されたバイトバッファにエンコードしてから、エンコードされた文字を含むバッファのサブスライスを返します。
    ///
    ///
    /// # Panics
    ///
    /// バッファが十分に大きくない場合は Panics。
    /// 長さ 4 のバッファーは、`char` をエンコードするのに十分な大きさです。
    ///
    /// # Examples
    ///
    /// これらの例の両方で、'ß' はエンコードに 2 バイトかかります。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 小さすぎるバッファ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // 安全性: `char` は代理ではないため、これは有効な UTF-8 です。
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// この文字を UTF-16 として提供された `u16` バッファーにエンコードしてから、エンコードされた文字を含むバッファーのサブスライスを返します。
    ///
    ///
    /// # Panics
    ///
    /// バッファが十分に大きくない場合は Panics。
    /// 長さ 2 のバッファーは、`char` をエンコードするのに十分な大きさです。
    ///
    /// # Examples
    ///
    /// これらの例の両方で、'𝕊' はエンコードに 2 つの `u16` を取ります。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 小さすぎるバッファ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// この `char` に `Alphabetic` プロパティがある場合、`true` を返します。
    ///
    /// `Alphabetic` [Unicode Standard] の第 4 章 (文字プロパティ) で説明されており、[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] で指定されています。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // 愛は多くのものですが、アルファベットではありません
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// この `char` に `Lowercase` プロパティがある場合、`true` を返します。
    ///
    /// `Lowercase` [Unicode Standard] の第 4 章 (文字プロパティ) で説明されており、[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] で指定されています。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // さまざまな中国語のスクリプトと句読点には大文字と小文字が区別されないため、次のようになります。
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// この `char` に `Uppercase` プロパティがある場合、`true` を返します。
    ///
    /// `Uppercase` [Unicode Standard] の第 4 章 (文字プロパティ) で説明されており、[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] で指定されています。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // さまざまな中国語のスクリプトと句読点には大文字と小文字が区別されないため、次のようになります。
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// この `char` に `White_Space` プロパティがある場合、`true` を返します。
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] で指定されています。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ノーブレークスペース
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// この `char` が [`is_alphabetic()`] または [`is_numeric()`] のいずれかを満たす場合、`true` を返します。
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// この `char` に制御コードの一般カテゴリがある場合、`true` を返します。
    ///
    /// 制御コード (`Cc` の一般カテゴリのコードポイント) は、[Unicode Standard] の第 4 章 (文字プロパティ) で説明されており、[Unicode Character Database][ucd] [`UnicodeData.txt`] で指定されています。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // U + 009C、ストリングターミネータ
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// この `char` に `Grapheme_Extend` プロパティがある場合、`true` を返します。
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] で説明され、[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] で指定されています。
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// この `char` に数値の一般的なカテゴリの 1 つがある場合、`true` を返します。
    ///
    /// 数字の一般的なカテゴリ (10 進数の場合は `Nd`、文字のような数字の場合は `Nl`、その他の数字の場合は `No`) は、[Unicode Character Database][ucd] [`UnicodeData.txt`] で指定されています。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// この `char` の小文字のマッピングを 1 つ以上として生成するイテレータを返します
    /// `char`s.
    ///
    /// この `char` に小文字のマッピングがない場合、イテレーターは同じ `char` を生成します。
    ///
    /// この `char` に [Unicode Character Database][ucd] [`UnicodeData.txt`] によって指定された 1 対 1 の小文字のマッピングがある場合、イテレーターはその `char` を生成します。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// この `char` で特別な考慮事項 (複数の `char` など) が必要な場合、イテレータは [`SpecialCasing.txt`] で指定された `char` を生成します。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// この操作は、調整せずに無条件のマッピングを実行します。つまり、変換はコンテキストや言語に依存しません。
    ///
    /// [Unicode Standard] では、第 4 章 (文字のプロパティ) で一般的なケースマッピングについて説明し、第 3 章 (Conformance) でケース変換のデフォルトのアルゴリズムについて説明します。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// イテレータとして:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` を直接使用する:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// どちらも次と同等です。
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` の使用:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // 結果が複数の文字になる場合があります。
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // 大文字と小文字の両方を持たない文字は、それ自体に変換されます。
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// この `char` の大文字のマッピングを 1 つ以上として生成するイテレーターを返します
    /// `char`s.
    ///
    /// この `char` に大文字のマッピングがない場合、イテレーターは同じ `char` を生成します。
    ///
    /// この `char` に [Unicode Character Database][ucd] [`UnicodeData.txt`] によって指定された 1 対 1 の大文字のマッピングがある場合、イテレーターはその `char` を生成します。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// この `char` で特別な考慮事項 (複数の `char` など) が必要な場合、イテレータは [`SpecialCasing.txt`] で指定された `char` を生成します。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// この操作は、調整せずに無条件のマッピングを実行します。つまり、変換はコンテキストや言語に依存しません。
    ///
    /// [Unicode Standard] では、第 4 章 (文字のプロパティ) で一般的なケースマッピングについて説明し、第 3 章 (Conformance) でケース変換のデフォルトのアルゴリズムについて説明します。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// イテレータとして:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` を直接使用する:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// どちらも次と同等です。
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` の使用:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // 結果が複数の文字になる場合があります。
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // 大文字と小文字の両方を持たない文字は、それ自体に変換されます。
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ロケールに関する注意
    ///
    /// トルコ語では、ラテン語の 'i' に相当するものには、2 つではなく 5 つの形式があります。
    ///
    /// * 'Dotless': 私 /ı、時々書かれる ï
    /// * 'Dotted': İ/i
    ///
    /// 小文字の点線の 'i' はラテン語と同じであることに注意してください。したがって:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ここでの `upper_i` の値は、テキストの言語に依存します。`en-US` を使用している場合は、`"I"` である必要がありますが、`tr_TR` を使用している場合は、`"İ"` である必要があります。
    /// `to_uppercase()` これは考慮されていないため、次のようになります。
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// 言語を超えて保持します。
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// 値が ASCII 範囲内にあるかどうかを確認します。
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// 同等の ASCII 大文字の値のコピーを作成します。
    ///
    /// ASCII 文字 'a' から 'z' は 'A' から 'Z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を大文字にするには、[`make_ascii_uppercase()`] を使用します。
    ///
    /// 非 ASCII 文字に加えて ASCII 文字を大文字にするには、[`to_uppercase()`] を使用します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 同等の ASCII 小文字の値のコピーを作成します。
    ///
    /// ASCII 文字 'A' から 'Z' は 'a' から 'z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// インプレースで値を小文字にするには、[`make_ascii_lowercase()`] を使用します。
    ///
    /// 非 ASCII 文字に加えて ASCII 文字を小文字にするには、[`to_lowercase()`] を使用します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 2 つの値が ASCII の大文字と小文字を区別しない一致であることを確認します。
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` と同等です。
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// このタイプをインプレースで同等の ASCII 大文字に変換します。
    ///
    /// ASCII 文字 'a' から 'z' は 'A' から 'Z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// 既存の値を変更せずに新しい大文字の値を返すには、[`to_ascii_uppercase()`] を使用します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// このタイプをインプレースで同等の ASCII 小文字に変換します。
    ///
    /// ASCII 文字 'A' から 'Z' は 'a' から 'z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// 既存の値を変更せずに新しい小文字の値を返すには、[`to_ascii_lowercase()`] を使用します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// 値が ASCII 英字であるかどうかを確認します。
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z'、または
    /// - U + 0061 'a' ..=U + 007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// 値が ASCII 大文字であるかどうかを確認します。
    /// U + 0041 'A' ..=U + 005A 'Z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// 値が ASCII 小文字であるかどうかを確認します。
    /// U + 0061 'a' ..=U + 007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// 値が ASCII 英数字であるかどうかを確認します。
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z'、または
    /// - U + 0061 'a' ..=U + 007A 'z'、または
    /// - U + 0030 '0' ..=U + 0039 '9' ..
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// 値が ASCII10 進数であるかどうかを確認します。
    /// U + 0030 '0' ..=U + 0039 '9' ..
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// 値が ASCII16 進数であるかどうかを確認します。
    ///
    /// - U + 0030 '0' ..=U + 0039 '9'、または
    /// - U + 0041 'A' ..=U + 0046 'F'、または
    /// - U + 0061 'a' ..=U + 0066 'f' ..
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// 値が ASCII 句読文字であるかどうかを確認します。
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`、または
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`、または
    /// - U + 005B ..=U + 0060 ``[\] ^ _``、または
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// 値が ASCII グラフィック文字であるかどうかを確認します。
    /// U + 0021 '!' ..=U + 007E '~' ..
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// 値が ASCII 空白文字であるかどうかを確認します。
    /// U + 0020 スペース、U + 0009 水平タブ、U + 000A ラインフィード、U + 000C フォームフィード、または U + 000D キャリッジリターン。
    ///
    /// Rust は、WhatWG InfraStandard の [definition of ASCII whitespace][infra-aw] を使用します。広く使用されている他のいくつかの定義があります。
    /// たとえば、[the POSIX locale][pct] には U + 000B VERTICAL TAB と上記のすべての文字が含まれていますが、まったく同じ仕様から、[Bourne shell の "field splitting" のデフォルトルール][bfs] はスペース、水平タブ、および空白としての LINEFEED。
    ///
    ///
    /// 既存のファイル形式を処理するプログラムを作成している場合は、この関数を使用する前に、その形式の空白の定義を確認してください。
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// 値が ASCII 制御文字であるかどうかを確認します。
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR、または U + 007FDELETE。
    /// ほとんどの ASCII 空白文字は制御文字ですが、SPACE はそうではないことに注意してください。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// 生の u32 値を UTF-8 として提供されたバイトバッファーにエンコードし、エンコードされた文字を含むバッファーのサブスライスを返します。
///
///
/// `char::encode_utf8` とは異なり、このメソッドはサロゲート範囲のコードポイントも処理します。
/// (代理範囲での `char` の作成は UB です。) 結果は有効な [generalized UTF-8] ですが、有効な UTF-8 ではありません。
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// バッファが十分に大きくない場合は Panics。
/// 長さ 4 のバッファーは、`char` をエンコードするのに十分な大きさです。
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// 生の u32 値を UTF-16 として提供された `u16` バッファーにエンコードし、エンコードされた文字を含むバッファーのサブスライスを返します。
///
///
/// `char::encode_utf16` とは異なり、このメソッドは代理範囲のコードポイントも処理します。
/// (代理範囲で `char` を作成するのは UB です。)
///
/// # Panics
///
/// バッファが十分に大きくない場合は Panics。
/// 長さ 2 のバッファーは、`char` をエンコードするのに十分な大きさです。
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // 安全性: 各アームは、書き込むのに十分なビットがあるかどうかをチェックします
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP は失敗します
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // 補助飛行機は代理に侵入します。
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}