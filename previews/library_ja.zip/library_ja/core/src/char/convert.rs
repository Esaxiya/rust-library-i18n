//! 文字変換。

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` を `char` に変換します。
///
/// すべての [`char`] は有効な [`u32`] であり、
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ただし、その逆は当てはまりません。すべての有効な [`u32`] が有効な [`char`] であるとは限りません。
/// `from_u32()` 入力が [`char`] の有効な値でない場合、`None` を返します。
///
/// これらのチェックを無視するこの関数の安全でないバージョンについては、[`from_u32_unchecked`] を参照してください。
///
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// 入力が有効な [`char`] でない場合に `None` を返す:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// 有効性を無視して、`u32` を `char` に変換します。
///
/// すべての [`char`] は有効な [`u32`] であり、
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ただし、その逆は当てはまりません。すべての有効な [`u32`] が有効な [`char`] であるとは限りません。
/// `from_u32_unchecked()` これを無視し、盲目的に [`char`] にキャストし、無効なものを作成する可能性があります。
///
///
/// # Safety
///
/// この関数は、無効な `char` 値を作成する可能性があるため、安全ではありません。
///
/// この関数の安全なバージョンについては、[`from_u32`] 関数を参照してください。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // 安全性: 呼び出し元は、`i` が有効な char 値であることを保証する必要があります。
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] を [`u32`] に変換します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] を [`u64`] に変換します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // char はコードポイントの値にキャストされ、64 ビットにゼロ拡張されます。
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] を参照してください
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] を [`u128`] に変換します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // char はコードポイントの値にキャストされ、128 ビットにゼロ拡張されます。
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] を参照してください
        c as u128
    }
}

/// 0x00 ..=0xFF のバイトを、コードポイントが同じ値の `char` (U + 0000 ..=U + 00FF) にマップします。
///
/// Unicode は、IANA が ISO-8859-1 と呼ぶ文字エンコードでバイトを効果的にデコードするように設計されています。
/// このエンコーディングは ASCII と互換性があります。
///
/// これは ISO/IEC 8859-1 別名とは異なることに注意してください
/// ISO 8859-1 (ハイフンが 1 つ少ない)。これにより、どの文字にも割り当てられていない "blanks" バイト値が残ります。
/// ISO-8859-1 (IANA のもの) はそれらを C0 および C1 制御コードに割り当てます。
///
/// これは Windows-1252 別名とは *また* 異なることに注意してください
/// コードページ 1252 は、句読点やさまざまなラテン文字にいくつかの (すべてではない! ) 空白を割り当てるスーパーセット ISO/IEC 8859-1 です。
///
/// さらに混乱させるために、[on the Web](https://encoding.spec.whatwg.org/) `ascii`、`iso-8859-1`、および `windows-1252` はすべて、残りの空白を対応する C0 および C1 制御コードで埋める Windows-1252 のスーパーセットのエイリアスです。
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] を [`char`] に変換します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// 文字を解析するときに返される可能性のあるエラー。
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // 安全性: それが正当な Unicode 値であることを確認しました
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32 から char への変換が失敗したときに返されるエラータイプ。
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// 指定された基数の桁を `char` に変換します。
///
/// ここでの 'radix' は、'base' と呼ばれることもあります。
/// 2 の基数は、2 進数、10 の基数、10 進数、および 16 の基数、16 進数を示し、いくつかの一般的な値を示します。
///
/// 任意の基数がサポートされています。
///
/// `from_digit()` 入力が指定された基数の数字でない場合、`None` を返します。
///
/// # Panics
///
/// 36 より大きい基数が指定されている場合は Panics。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // 10 進数の 11 は、基数 16 の 1 桁です。
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// 入力が数字でない場合に `None` を返す:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// 大きな基数を渡すと、panic が発生します。
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}