use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// ポインタが null の場合、`true` を返します。
    ///
    /// サイズ変更されていない型には、長さや vtable などではなく、生データポインターのみが考慮されるため、多くの可能な null ポインターがあることに注意してください。
    /// したがって、null である 2 つのポインターは、互いに等しく比較できない場合があります。
    ///
    /// ## const 評価中の動作
    ///
    /// この関数を const 評価中に使用すると、実行時に null であることが判明したポインターに対して `false` が返される場合があります。
    /// 具体的には、あるメモリへのポインタがその境界を超えてオフセットされ、結果のポインタが null になった場合でも、関数は `false` を返します。
    ///
    /// CTFE がそのメモリの絶対位置を知る方法がないため、ポインタが null かどうかを判断できません。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // キャストを介して細いポインターと比較するため、太いポインターは "data" 部分のみが null であると見なします。
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// 別のタイプのポインターにキャストします。
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// (おそらく幅の広い) ポインタをアドレスおよびメタデータコンポーネントに分解します。
    ///
    /// ポインタは後で [`from_raw_parts`] で再構築できます。
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// ポインタが null の場合は `None` を返し、そうでない場合は `Some` でラップされた値への共有参照を返します。値が初期化されていない可能性がある場合は、代わりに [`as_uninit_ref`] を使用する必要があります。
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、ポインタが NULL であるか、次のすべてが真であることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * ポインタは、`T` の初期化されたインスタンスを指している必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    /// (初期化に関する部分はまだ完全には決定されていませんが、完全に決定されるまで、唯一の安全なアプローチは、それらが実際に初期化されていることを確認することです。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # ヌル - チェックされていないバージョン
    ///
    /// ポインタが null になることはなく、`Option<&T>` ではなく `&T` を返すような `as_ref_unchecked` を探している場合は、ポインタを直接逆参照できることを知っておいてください。
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // 安全性: 発信者は `self` が有効であることを保証する必要があります
        // null でない場合の参照用。
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// ポインタが null の場合は `None` を返し、そうでない場合は `Some` でラップされた値への共有参照を返します。
    /// [`as_ref`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、ポインタが NULL であるか、次のすべてが真であることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // 安全性: 発信者は、`self` がすべての
        // 参照の要件。
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// ポインタからのオフセットを計算します。
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// 次の条件のいずれかに違反すると、結果は未定義の動作になります。
    ///
    /// * 開始ポインタと結果ポインタの両方が、同じ割り当てられたオブジェクトの範囲内か、終了を 1 バイト超えている必要があります。
    /// Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// * 計算されたオフセット (**バイト単位**) は、`isize` をオーバーフローさせることはできません。
    ///
    /// * 範囲内にあるオフセットは、"wrapping around" アドレス空間に依存できません。つまり、**バイト単位** の無限精度の合計は、usize に収まる必要があります。
    ///
    /// コンパイラと標準ライブラリは通常、オフセットが懸念されるサイズに割り当てが到達しないように努めます。
    /// たとえば、`Vec` と `Box` は、`isize::MAX` バイトを超えて割り当てないことを保証するため、`vec.as_ptr().add(vec.len())` は常に安全です。
    ///
    /// ほとんどのプラットフォームは、基本的にそのような割り当てを構築することさえできません。
    /// たとえば、既知の 64 ビットプラットフォームは、ページテーブルの制限またはアドレス空間の分割のために <sup>263</sup> バイトの要求を処理できません。
    /// ただし、一部の 32 ビットおよび 16 ビットプラットフォームは、物理アドレス拡張などを使用して、`isize::MAX` バイトを超える要求を正常に処理する場合があります。
    ///
    /// そのため、アロケータまたはメモリマップファイルから直接取得されたメモリは、この関数で処理するには大きすぎる可能性があります。
    ///
    /// これらの制約を満たすことが難しい場合は、代わりに [`wrapping_offset`] の使用を検討してください。
    /// この方法の唯一の利点は、より積極的なコンパイラの最適化が可能になることです。
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // 安全性: 発信者は `offset` の安全契約を守る必要があります。
        unsafe { intrinsics::offset(self, count) }
    }

    /// ラッピング演算を使用して、ポインターからのオフセットを計算します。
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// この操作自体は常に安全ですが、結果のポインターを使用することは安全ではありません。
    ///
    /// 結果のポインタは、`self` が指すのと同じ割り当てられたオブジェクトにアタッチされたままになります。
    /// 割り当てられた別のオブジェクトにアクセスするために使用することは *できません*。Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// 言い換えると、`T` のサイズが `1` でオーバーフローがないと仮定しても、`let z = x.wrapping_offset((y as isize) - (x as isize))` は `z` を `y` と同じにしません。`z` は `x` がアタッチされているオブジェクトにアタッチされたままであり、`x` と `y` は、割り当てられた同じオブジェクトを指します。
    ///
    /// [`offset`] と比較すると、このメソッドは基本的に、割り当てられた同じオブジェクト内にとどまるという要件を遅らせます。[`offset`] は、オブジェクトの境界を越えるときの即時の未定義の動作です。`wrapping_offset` はポインターを生成しますが、ポインターが接続されているオブジェクトの範囲外にあるときにポインターが逆参照されると、未定義の動作につながります。
    /// [`offset`] より適切に最適化できるため、パフォーマンスに敏感なコードで推奨されます。
    ///
    /// 遅延チェックでは、逆参照されたポインターの値のみが考慮され、最終結果の計算中に使用される中間値は考慮されません。
    /// たとえば、`x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` は常に `x` と同じです。つまり、割り当てられたオブジェクトを残して、後で再入力することが許可されます。
    ///
    /// オブジェクトの境界を越える必要がある場合は、ポインターを整数にキャストし、そこで算術演算を実行します。
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 2 つの要素の増分で生のポインタを使用して繰り返します
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // このループは "1, 3, 5, " を出力します
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // 安全性: `arith_offset` 組み込みには、呼び出す必要のある前提条件はありません。
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// 2 つのポインタ間の距離を計算します。戻り値は T の単位です。バイト単位の距離は `mem::size_of::<T>()` で除算されます。
    ///
    /// この関数は [`offset`] の逆です。
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// 次の条件のいずれかに違反すると、結果は未定義の動作になります。
    ///
    /// * 開始ポインタと他のポインタの両方が、同じ割り当てられたオブジェクトの範囲内か、終了を 1 バイト超えている必要があります。
    /// Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// * 両方のポインタは、同じオブジェクトへのポインタから *派生* する必要があります。
    ///   (例については、以下を参照してください。)
    ///
    /// * ポインター間の距離 (バイト単位) は、`T` のサイズの正確な倍数である必要があります。
    ///
    /// * ポインタ間の距離 (**バイト単位**) は、`isize` をオーバーフローさせることはできません。
    ///
    /// * 範囲内にある距離は、"wrapping around" アドレス空間に依存することはできません。
    ///
    /// Rust タイプが `isize::MAX` より大きくなることはなく、Rust 割り当てがアドレス空間をラップアラウンドすることはないため、Rust タイプ `T` の値内の 2 つのポインターは、常に最後の 2 つの条件を満たすことになります。
    ///
    /// また、標準ライブラリは通常、オフセットが懸念されるサイズに割り当てが到達しないことを保証します。
    /// たとえば、`Vec` と `Box` は、`isize::MAX` バイトを超えて割り当てないことを保証するため、`ptr_into_vec.offset_from(vec.as_ptr())` は常に最後の 2 つの条件を満たす。
    ///
    /// ほとんどのプラットフォームは、基本的に、このような大規模な割り当てを構築することさえできません。
    /// たとえば、既知の 64 ビットプラットフォームは、ページテーブルの制限またはアドレス空間の分割のために <sup>263</sup> バイトの要求を処理できません。
    /// ただし、一部の 32 ビットおよび 16 ビットプラットフォームは、物理アドレス拡張などを使用して、`isize::MAX` バイトを超える要求を正常に処理する場合があります。
    /// そのため、アロケータまたはメモリマップファイルから直接取得されたメモリは、この関数で処理するには大きすぎる可能性があります。
    /// ([`offset`] と [`add`] にも同様の制限があるため、このような大規模な割り当てにも使用できないことに注意してください。)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// `T` がゼロサイズタイプ ("ZST") の場合、この関数 panics。
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *間違った* 使用法:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // ptr2_other を ptr2 の "alias" にしますが、ptr1 から派生します。
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // ptr2_other と ptr2 は異なるオブジェクトへのポインターから派生しているため、同じアドレスを指している場合でも、オフセットの計算は未定義の動作です。
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // 未定義の動作
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // 安全性: 発信者は `ptr_offset_from` の安全契約を守る必要があります。
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// 2 つのポインタが等しいことが保証されているかどうかを返します。
    ///
    /// 実行時、この関数は `self == other` のように動作します。
    /// ただし、一部のコンテキスト (コンパイル時の評価など) では、2 つのポインターが等しいかどうかを常に判断できるとは限らないため、この関数は、後で実際に等しいことが判明したポインターに対して `false` を誤って返す場合があります。
    ///
    /// ただし、`true` を返す場合、ポインターは等しいことが保証されます。
    ///
    /// この関数は [`guaranteed_ne`] のミラーですが、その逆ではありません。両方の関数が `false` を返すポインター比較があります。
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// 戻り値はコンパイラのバージョンによって変わる可能性があり、安全でないコードは健全性のためにこの関数の結果に依存しない可能性があります。
    /// この関数は、この関数による偽の `false` 戻り値が結果に影響を与えず、パフォーマンスのみに影響を与えるパフォーマンスの最適化にのみ使用することをお勧めします。
    /// このメソッドを使用してランタイムコードとコンパイル時コードの動作を変えることの結果は、調査されていません。
    /// この方法は、そのような違いを導入するために使用されるべきではありません。また、この問題をよりよく理解する前に、この方法を安定させるべきではありません。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// 2 つのポインタが等しくないことが保証されているかどうかを返します。
    ///
    /// 実行時、この関数は `self != other` のように動作します。
    /// ただし、一部のコンテキスト (コンパイル時の評価など) では、2 つのポインターの不等式を常に判別できるとは限らないため、この関数は、後で実際には等しくないことが判明したポインターに対して `false` を誤って返す場合があります。
    ///
    /// ただし、`true` を返す場合、ポインターは等しくないことが保証されます。
    ///
    /// この関数は [`guaranteed_eq`] のミラーですが、その逆ではありません。両方の関数が `false` を返すポインター比較があります。
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// 戻り値はコンパイラのバージョンによって変わる可能性があり、安全でないコードは健全性のためにこの関数の結果に依存しない可能性があります。
    /// この関数は、この関数による偽の `false` 戻り値が結果に影響を与えず、パフォーマンスのみに影響を与えるパフォーマンスの最適化にのみ使用することをお勧めします。
    /// このメソッドを使用してランタイムコードとコンパイル時コードの動作を変えることの結果は、調査されていません。
    /// この方法は、そのような違いを導入するために使用されるべきではありません。また、この問題をよりよく理解する前に、この方法を安定させるべきではありません。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// ポインタからのオフセットを計算します (`.offset(count as isize)`) の場合は便利です。
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// 次の条件のいずれかに違反すると、結果は未定義の動作になります。
    ///
    /// * 開始ポインタと結果ポインタの両方が、同じ割り当てられたオブジェクトの範囲内か、終了を 1 バイト超えている必要があります。
    /// Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// * 計算されたオフセット (**バイト単位**) は、`isize` をオーバーフローさせることはできません。
    ///
    /// * 範囲内にあるオフセットは、"wrapping around" アドレス空間に依存できません。つまり、無限精度の合計は `usize` に収まる必要があります。
    ///
    /// コンパイラと標準ライブラリは通常、オフセットが懸念されるサイズに割り当てが到達しないように努めます。
    /// たとえば、`Vec` と `Box` は、`isize::MAX` バイトを超えて割り当てないことを保証するため、`vec.as_ptr().add(vec.len())` は常に安全です。
    ///
    /// ほとんどのプラットフォームは、基本的にそのような割り当てを構築することさえできません。
    /// たとえば、既知の 64 ビットプラットフォームは、ページテーブルの制限またはアドレス空間の分割のために <sup>263</sup> バイトの要求を処理できません。
    /// ただし、一部の 32 ビットおよび 16 ビットプラットフォームは、物理アドレス拡張などを使用して、`isize::MAX` バイトを超える要求を正常に処理する場合があります。
    ///
    /// そのため、アロケータまたはメモリマップファイルから直接取得されたメモリは、この関数で処理するには大きすぎる可能性があります。
    ///
    /// これらの制約を満たすことが難しい場合は、代わりに [`wrapping_add`] の使用を検討してください。
    /// この方法の唯一の利点は、より積極的なコンパイラの最適化が可能になることです。
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 安全性: 発信者は `offset` の安全契約を守る必要があります。
        unsafe { self.offset(count as isize) }
    }

    /// ポインタからのオフセットを計算します ( `.offset ( (isize).wrapping_neg())`) としてカウントするのに便利です。
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// 次の条件のいずれかに違反すると、結果は未定義の動作になります。
    ///
    /// * 開始ポインタと結果ポインタの両方が、同じ割り当てられたオブジェクトの範囲内か、終了を 1 バイト超えている必要があります。
    /// Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// * 計算されたオフセットは `isize::MAX`**バイト** を超えることはできません。
    ///
    /// * 範囲内にあるオフセットは、"wrapping around" アドレス空間に依存できません。つまり、無限精度の合計は usize に収まる必要があります。
    ///
    /// コンパイラと標準ライブラリは通常、オフセットが懸念されるサイズに割り当てが到達しないように努めます。
    /// たとえば、`Vec` と `Box` は、`isize::MAX` バイトを超えて割り当てないことを保証するため、`vec.as_ptr().add(vec.len()).sub(vec.len())` は常に安全です。
    ///
    /// ほとんどのプラットフォームは、基本的にそのような割り当てを構築することさえできません。
    /// たとえば、既知の 64 ビットプラットフォームは、ページテーブルの制限またはアドレス空間の分割のために <sup>263</sup> バイトの要求を処理できません。
    /// ただし、一部の 32 ビットおよび 16 ビットプラットフォームは、物理アドレス拡張などを使用して、`isize::MAX` バイトを超える要求を正常に処理する場合があります。
    ///
    /// そのため、アロケータまたはメモリマップファイルから直接取得されたメモリは、この関数で処理するには大きすぎる可能性があります。
    ///
    /// これらの制約を満たすことが難しい場合は、代わりに [`wrapping_sub`] の使用を検討してください。
    /// この方法の唯一の利点は、より積極的なコンパイラの最適化が可能になることです。
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // 安全性: 発信者は `offset` の安全契約を守る必要があります。
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// ラッピング演算を使用して、ポインターからのオフセットを計算します。
    /// (`.wrapping_offset(count as isize)`) の利便性
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// この操作自体は常に安全ですが、結果のポインターを使用することは安全ではありません。
    ///
    /// 結果のポインタは、`self` が指すのと同じ割り当てられたオブジェクトにアタッチされたままになります。
    /// 割り当てられた別のオブジェクトにアクセスするために使用することは *できません*。Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// 言い換えると、`T` のサイズが `1` でオーバーフローがないと仮定しても、`let z = x.wrapping_add((y as usize) - (x as usize))` は `z` を `y` と同じにしません。`z` は `x` がアタッチされているオブジェクトにアタッチされたままであり、`x` と `y` は、割り当てられた同じオブジェクトを指します。
    ///
    /// [`add`] と比較すると、このメソッドは基本的に、割り当てられた同じオブジェクト内にとどまるという要件を遅らせます。[`add`] は、オブジェクトの境界を越えるときの即時の未定義の動作です。`wrapping_add` はポインターを生成しますが、ポインターが接続されているオブジェクトの範囲外にあるときにポインターが逆参照されると、未定義の動作につながります。
    /// [`add`] より適切に最適化できるため、パフォーマンスに敏感なコードで推奨されます。
    ///
    /// 遅延チェックでは、逆参照されたポインターの値のみが考慮され、最終結果の計算中に使用される中間値は考慮されません。
    /// たとえば、`x.wrapping_add(o).wrapping_sub(o)` は常に `x` と同じです。つまり、割り当てられたオブジェクトを残して、後で再入力することが許可されます。
    ///
    /// オブジェクトの境界を越える必要がある場合は、ポインターを整数にキャストし、そこで算術演算を実行します。
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 2 つの要素の増分で生のポインタを使用して繰り返します
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // このループは "1, 3, 5, " を出力します
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// ラッピング演算を使用して、ポインターからのオフセットを計算します。
    /// ( `.wrapping_offset ( (isize).wrapping_neg())`) としてカウント) の利便性
    ///
    /// `count` T の単位です。たとえば、`count` が 3 の場合、`3 * size_of::<T>()` バイトのポインタオフセットを表します。
    ///
    /// # Safety
    ///
    /// この操作自体は常に安全ですが、結果のポインターを使用することは安全ではありません。
    ///
    /// 結果のポインタは、`self` が指すのと同じ割り当てられたオブジェクトにアタッチされたままになります。
    /// 割り当てられた別のオブジェクトにアクセスするために使用することは *できません*。Rust では、すべての (stack-allocated) 変数が個別に割り当てられたオブジェクトと見なされることに注意してください。
    ///
    /// 言い換えると、`T` のサイズが `1` でオーバーフローがないと仮定しても、`let z = x.wrapping_sub((x as usize) - (y as usize))` は `z` を `y` と同じにしません。`z` は `x` がアタッチされているオブジェクトにアタッチされたままであり、`x` と `y` は、割り当てられた同じオブジェクトを指します。
    ///
    /// [`sub`] と比較すると、このメソッドは基本的に、割り当てられた同じオブジェクト内にとどまるという要件を遅らせます。[`sub`] は、オブジェクトの境界を越えるときの即時の未定義の動作です。`wrapping_sub` はポインターを生成しますが、ポインターが接続されているオブジェクトの範囲外にあるときにポインターが逆参照されると、未定義の動作につながります。
    /// [`sub`] より適切に最適化できるため、パフォーマンスに敏感なコードで推奨されます。
    ///
    /// 遅延チェックでは、逆参照されたポインターの値のみが考慮され、最終結果の計算中に使用される中間値は考慮されません。
    /// たとえば、`x.wrapping_add(o).wrapping_sub(o)` は常に `x` と同じです。つまり、割り当てられたオブジェクトを残して、後で再入力することが許可されます。
    ///
    /// オブジェクトの境界を越える必要がある場合は、ポインターを整数にキャストし、そこで算術演算を実行します。
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// // 2 つの要素 (backwards) の増分で生のポインターを使用して反復します
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // このループは "5, 3, 1, " を出力します
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// ポインタ値を `ptr` に設定します。
    ///
    /// `self` がサイズなしタイプへの (fat) ポインターである場合、この操作はポインター部分にのみ影響しますが、サイズ付きタイプへの (thin) ポインターの場合、これは単純な割り当てと同じ効果があります。
    ///
    /// 結果のポインターの出所は `val` になります。つまり、ファットポインターの場合、この操作は、データポインター値が `val` で、メタデータが `self` の新しいファットポインターを作成するのと意味的に同じです。
    ///
    ///
    /// # Examples
    ///
    /// この関数は主に、太い可能性のあるポインターに対してバイト単位のポインター演算を可能にする場合に役立ちます。
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // "3" を印刷します
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // 安全性: 細いポインターの場合、この操作は同じです
        // 簡単な割り当てに。
        // ファットポインタの場合、現在のファットポインタレイアウトの実装では、そのようなポインタの最初のフィールドは常にデータポインタであり、同様に割り当てられます。
        //
        unsafe { *thin = val };
        self
    }

    /// 移動せずに `self` から値を読み取ります。
    /// これにより、`self` のメモリは変更されません。
    ///
    /// 安全上の懸念と例については、[`ptr::read`] を参照してください。
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // 安全性: 発信者は `read` の安全契約を守る必要があります。
        unsafe { read(self) }
    }

    /// `self` から値を移動せずに、その値の揮発性読み取りを実行します。これにより、`self` のメモリは変更されません。
    ///
    /// 揮発性操作は I/O メモリで動作することを目的としており、他の揮発性操作全体でコンパイラによって削除または並べ替えられないことが保証されています。
    ///
    ///
    /// 安全上の懸念と例については、[`ptr::read_volatile`] を参照してください。
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // 安全性: 発信者は `read_volatile` の安全契約を守る必要があります。
        unsafe { read_volatile(self) }
    }

    /// 移動せずに `self` から値を読み取ります。
    /// これにより、`self` のメモリは変更されません。
    ///
    /// `read` とは異なり、ポインターが整列していない可能性があります。
    ///
    /// 安全上の懸念と例については、[`ptr::read_unaligned`] を参照してください。
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // 安全性: 発信者は `read_unaligned` の安全契約を守る必要があります。
        unsafe { read_unaligned(self) }
    }

    /// `count * size_of<T>` バイトを `self` から `dest` にコピーします。
    /// ソースと宛先が重複している可能性があります。
    ///
    /// NOTE: これは、[`ptr::copy`] と *同じ* 引数の順序になります。
    ///
    /// 安全上の懸念と例については、[`ptr::copy`] を参照してください。
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 安全性: 発信者は `copy` の安全契約を守る必要があります。
        unsafe { copy(self, dest, count) }
    }

    /// `count * size_of<T>` バイトを `self` から `dest` にコピーします。
    /// ソースと宛先は重複しない場合があります。
    ///
    /// NOTE: これは、[`ptr::copy_nonoverlapping`] と *同じ* 引数の順序になります。
    ///
    /// 安全上の懸念と例については、[`ptr::copy_nonoverlapping`] を参照してください。
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // 安全性: 発信者は `copy_nonoverlapping` の安全契約を守る必要があります。
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// `align` に揃えるために、ポインターに適用する必要のあるオフセットを計算します。
    ///
    /// ポインタを揃えることができない場合、実装は `usize::MAX` を返します。
    /// 実装が *常に*`usize::MAX` を返すことは許容されます。
    /// アルゴリズムのパフォーマンスのみが、その正確さではなく、ここで使用可能なオフセットを取得することに依存する可能性があります。
    ///
    /// オフセットは、バイトではなく、`T` 要素の数で表されます。返された値は、`wrapping_add` メソッドで使用できます。
    ///
    /// ポインタのオフセットがオーバーフローしたり、ポインタが指す割り当てを超えたりしないという保証はありません。
    ///
    /// 返されたオフセットがアライメント以外のすべての点で正しいことを確認するのは、呼び出し元の責任です。
    ///
    /// # Panics
    ///
    /// `align` が 2 の累乗でない場合、関数 panics。
    ///
    /// # Examples
    ///
    /// 隣接する `u8` に `u16` としてアクセスする
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ポインタは `offset` を介して位置合わせできますが、割り当ての外側を指します。
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // 安全性: `align` は上記の 2 の累乗であることが確認されています
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// 生のスライスの長さを返します。
    ///
    /// 戻り値は、バイト数ではなく、**要素** の数です。
    ///
    /// この関数は、ポインターが null または整列されていないために、生のスライスをスライス参照にキャストできない場合でも安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // 安全性: `*const [T]` と `FatPtr<T>` のレイアウトは同じであるため、これは安全です。
            // `std` のみがこの保証を行うことができます。
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// スライスのバッファへの生のポインタを返します。
    ///
    /// これは、`self` を `*const T` にキャストするのと同じですが、よりタイプセーフです。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// 境界チェックを行わずに、要素またはサブスライスへの生のポインタを返します。
    ///
    /// 範囲外のインデックスを使用して、または `self` が参照解除できないときにこのメソッドを呼び出すと、結果のポインターが使用されない場合でも *[未定義の動作]* になります。
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // 安全性: 呼び出し元は、`self` が参照解除可能であり、`index` がインバウンドであることを確認します。
        unsafe { index.get_unchecked(self) }
    }

    /// ポインタが null の場合は `None` を返し、そうでない場合は `Some` でラップされた値に共有スライスを返します。
    /// [`as_ref`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、ポインタが NULL であるか、次のすべてが真であることを確認する必要があります。
    ///
    /// * `ptr.len() * mem::size_of::<T>()` のバイト数を読み取るには、ポインターは [valid] である必要があり、適切に整列されている必要があります。これは特に次のことを意味します。
    ///
    ///     * このスライスのメモリ範囲全体は、割り当てられた単一のオブジェクト内に含まれている必要があります。
    ///       スライスは、割り当てられた複数のオブジェクトにまたがることはできません。
    ///
    ///     * 長さがゼロのスライスの場合でも、ポインタを揃える必要があります。
    ///     この理由の 1 つは、列挙型レイアウトの最適化では、他のデータと区別するために、参照 (任意の長さのスライスを含む) が整列され、null 以外であることに依存する場合があるためです。
    ///
    ///     [`NonNull::dangling()`] を使用して、長さゼロのスライスの `data` として使用できるポインターを取得できます。
    ///
    /// * スライスの合計サイズ `ptr.len() * mem::size_of::<T>()` は `isize::MAX` 以下でなければなりません。
    ///   [`pointer::offset`] の安全文書を参照してください。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [`slice::from_raw_parts`][] も参照してください。
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // 安全性: 発信者は `as_uninit_slice` の安全契約を守る必要があります。
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// ポインターの平等
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// ポインターの比較
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}