use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// このラッパーの所有者が指示対象を所有していることを示す、生の非 null `*mut T` のラッパー。
/// `Box<T>`、`Vec<T>`、`String`、`HashMap<K, V>` などの抽象化を構築するのに役立ちます。
///
/// `*mut T` とは異なり、`Unique<T>` は "as if" として動作し、`T` のインスタンスでした。
/// `T` が `Send`/`Sync` の場合、`Send`/`Sync` を実装します。
/// また、`T` のインスタンスが期待できる強力なエイリアシングの種類が保証されることも意味します。
/// ポインタの指示対象は、それを所有する一意への一意のパスなしで変更しないでください。
///
/// 目的に `Unique` を使用することが正しいかどうかわからない場合は、セマンティクスが弱い `NonNull` の使用を検討してください。
///
///
/// `*mut T` とは異なり、ポインターが逆参照されない場合でも、ポインターは常に null 以外である必要があります。
/// これは、列挙型がこの禁止値を判別式として使用できるようにするためです。`Option<Unique<T>>` のサイズは `Unique<T>` と同じです。
/// ただし、逆参照されていない場合、ポインターはまだぶら下がっている可能性があります。
///
/// `*mut T` とは異なり、`Unique<T>` は `T` と共変です。
/// これは、Unique のエイリアシング要件を支持するすべてのタイプに対して常に正しいはずです。
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: このマーカーは分散に影響を与えませんが、必要です
    // dropck が `T` を論理的に所有していることを理解するため。
    //
    // 詳細については、以下を参照してください。
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ポインターが参照するデータはエイリアス化されていないため、`T` が `Send` の場合、ポインターは `Send` です。
/// このエイリアシング不変条件は、型システムによって強制されないことに注意してください。`Unique` を使用した抽象化はそれを強制する必要があります。
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ポインターが参照するデータはエイリアス化されていないため、`T` が `Sync` の場合、ポインターは `Sync` です。
/// このエイリアシング不変条件は、型システムによって強制されないことに注意してください。`Unique` を使用した抽象化はそれを強制する必要があります。
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ぶら下がっているが、適切に配置された新しい `Unique` を作成します。
    ///
    /// これは、`Vec::new` のように、遅延して割り当てるタイプを初期化する場合に役立ちます。
    ///
    /// ポインタ値は `T` への有効なポインタを表す可能性があることに注意してください。つまり、これを "not yet initialized" 番兵値として使用してはなりません。
    /// 遅延割り当てするタイプは、他の方法で初期化を追跡する必要があります。
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // 安全性: mem::align_of() は、有効な null 以外のポインターを返します。ザ・
        // したがって、new_unchecked() を呼び出すための条件が尊重されます。
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// 新しい `Unique` を作成します。
    ///
    /// # Safety
    ///
    /// `ptr` null 以外である必要があります。
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 安全性: 呼び出し元は、`ptr` が null でないことを保証する必要があります。
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` が null 以外の場合、新しい `Unique` を作成します。
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 安全性: ポインターはすでにチェックされており、null ではありません。
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// 基になる `*mut` ポインターを取得します。
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// コンテンツを逆参照します。
    ///
    /// 結果として得られるライフタイムは自己にバインドされるため、これは "as if" で動作し、実際には借用されている T のインスタンスでした。
    /// より長い (unbound) 寿命が必要な場合は、`&*my_ptr.as_ptr()` を使用してください。
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 安全性: 発信者は、`self` がすべての
        // 参照の要件。
        unsafe { &*self.as_ptr() }
    }

    /// コンテンツを相互に逆参照します。
    ///
    /// 結果として得られるライフタイムは自己にバインドされるため、これは "as if" で動作し、実際には借用されている T のインスタンスでした。
    /// より長い (unbound) 寿命が必要な場合は、`&mut *my_ptr.as_ptr()` を使用してください。
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 安全性: 発信者は、`self` がすべての
        // 可変参照の要件。
        unsafe { &mut *self.as_ptr() }
    }

    /// 別のタイプのポインターにキャストします。
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // 安全性: Unique::new_unchecked() は新しいユニークなニーズを生み出します
        // 指定されたポインタが null にならないようにします。
        // 自分自身をポインタとして渡しているので、null にすることはできません。
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 安全性: 可変参照を null にすることはできません
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}