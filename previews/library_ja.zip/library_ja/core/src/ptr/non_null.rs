use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` しかし、非ゼロで共変です。
///
/// これは、生のポインタを使用してデータ構造を構築するときに使用するのが正しいことですが、追加のプロパティがあるため、最終的には使用するのがより危険です。`NonNull<T>` を使用する必要があるかどうかわからない場合は、`*mut T` を使用してください。
///
/// `*mut T` とは異なり、ポインターが逆参照されない場合でも、ポインターは常に null 以外である必要があります。これは、列挙型がこの禁止値を判別式として使用できるようにするためです。`Option<NonNull<T>>` のサイズは `* mut T` と同じです。
/// ただし、逆参照されていない場合、ポインターはまだぶら下がっている可能性があります。
///
/// `*mut T` とは異なり、`NonNull<T>` は `T` よりも共変であるように選択されました。これにより、共変型を構築するときに `NonNull<T>` を使用できるようになりますが、実際には共変であってはならない型で使用すると、不健全になるリスクが生じます。
/// (技術的には安全でない関数を呼び出すことによってのみ不健全さが引き起こされる可能性がありますが、`*mut T` では反対の選択が行われました。)
///
/// 共分散は、`Box`、`Rc`、`Arc`、`Vec`、`LinkedList` などの最も安全な抽象化に適しています。これは、Rust の通常の共有 XOR 可変ルールに従うパブリック API を提供するためです。
///
/// タイプを安全に共変できない場合は、不変性を提供するために追加のフィールドが含まれていることを確認する必要があります。多くの場合、このフィールドは `PhantomData<Cell<T>>` や `PhantomData<&'a mut T>` などの [`PhantomData`] タイプになります。
///
/// `NonNull<T>` には `&T` 用の `From` インスタンスがあることに注意してください。ただし、これによって、(から派生した) 共有参照を介した変更が [`UnsafeCell<T>`] 内で発生しない限り、未定義の動作であるという事実は変わりません。共有参照から変更可能な参照を作成する場合も同様です。
///
/// `UnsafeCell<T>` なしでこの `From` インスタンスを使用する場合、`as_mut` が呼び出されないようにし、`as_ptr` がミューテーションに使用されないようにするのはユーザーの責任です。
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ポインターが参照するデータはエイリアスである可能性があるため、ポインターは `Send` ではありません。
// 注意、この impl は不要ですが、より良いエラーメッセージを提供するはずです。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ポインターが参照するデータはエイリアスである可能性があるため、ポインターは `Sync` ではありません。
// 注意、この impl は不要ですが、より良いエラーメッセージを提供するはずです。
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ぶら下がっているが、適切に配置された新しい `NonNull` を作成します。
    ///
    /// これは、`Vec::new` のように、遅延して割り当てるタイプを初期化する場合に役立ちます。
    ///
    /// ポインタ値は `T` への有効なポインタを表す可能性があることに注意してください。つまり、これを "not yet initialized" 番兵値として使用してはなりません。
    /// 遅延割り当てするタイプは、他の方法で初期化を追跡する必要があります。
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // 安全性: mem::align_of() はゼロ以外の usize を返し、それがキャストされます
        // * mutT に。
        // したがって、`ptr` は null ではなく、new_unchecked() を呼び出すための条件が尊重されます。
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// 値への共有参照を返します。[`as_ref`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// 変更可能な対応物については、[`as_uninit_mut`] を参照してください。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // 安全性: 発信者は、`self` がすべての
        // 参照の要件。
        unsafe { &*self.cast().as_ptr() }
    }

    /// 値への一意の参照を返します。[`as_mut`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// 共有の対応物については、[`as_uninit_ref`] を参照してください。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///
    ///   特に、この存続期間中、ポインタが指すメモリは、他のポインタを介してアクセス (読み取りまたは書き込み) されてはなりません。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // 安全性: 発信者は、`self` がすべての
        // 参照の要件。
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// 新しい `NonNull` を作成します。
    ///
    /// # Safety
    ///
    /// `ptr` null 以外である必要があります。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // 安全性: 呼び出し元は、`ptr` が null でないことを保証する必要があります。
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` が null 以外の場合、新しい `NonNull` を作成します。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // 安全性: ポインタはすでにチェックされており、null ではありません
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// 生の `*const` ポインターではなく、`NonNull` ポインターが返されることを除いて、[`std::ptr::from_raw_parts`] と同じ機能を実行します。
    ///
    ///
    /// 詳細については、[`std::ptr::from_raw_parts`] のドキュメントを参照してください。
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // 安全性: `data_address` は null であるため、`ptr::from::raw_parts_mut` の結果は null ではありません。
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// (おそらく幅の広い) ポインタをアドレスおよびメタデータコンポーネントに分解します。
    ///
    /// ポインタは後で [`NonNull::from_raw_parts`] で再構築できます。
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// 基になる `*mut` ポインターを取得します。
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// 値への共有参照を返します。値が初期化されていない可能性がある場合は、代わりに [`as_uninit_ref`] を使用する必要があります。
    ///
    /// 変更可能な対応物については、[`as_mut`] を参照してください。
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * ポインタは、`T` の初期化されたインスタンスを指している必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    /// (初期化に関する部分はまだ完全には決定されていませんが、完全に決定されるまで、唯一の安全なアプローチは、それらが実際に初期化されていることを確認することです。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // 安全性: 発信者は、`self` がすべての
        // 参照の要件。
        unsafe { &*self.as_ptr() }
    }

    /// 値への一意の参照を返します。値が初期化されていない可能性がある場合は、代わりに [`as_uninit_mut`] を使用する必要があります。
    ///
    /// 共有の対応物については、[`as_ref`] を参照してください。
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * ポインタを正しく配置する必要があります。
    ///
    /// * [the module documentation] で定義されている意味で "dereferencable" である必要があります。
    ///
    /// * ポインタは、`T` の初期化されたインスタンスを指している必要があります。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///
    ///   特に、この存続期間中、ポインタが指すメモリは、他のポインタを介してアクセス (読み取りまたは書き込み) されてはなりません。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    /// (初期化に関する部分はまだ完全には決定されていませんが、完全に決定されるまで、唯一の安全なアプローチは、それらが実際に初期化されていることを確認することです。)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // 安全性: 発信者は、`self` がすべての
        // 可変参照の要件。
        unsafe { &mut *self.as_ptr() }
    }

    /// 別のタイプのポインターにキャストします。
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // 安全性: `self` は `NonNull` ポインターであり、必ず null 以外です。
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// シンポインタと長さから null 以外の生のスライスを作成します。
    ///
    /// `len` 引数は、バイト数ではなく、**要素** の数です。
    ///
    /// この関数は安全ですが、戻り値の逆参照は安全ではありません。
    /// スライスの安全要件については、[`slice::from_raw_parts`] のドキュメントを参照してください。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // 最初の要素へのポインタから始めるときにスライスポインタを作成する
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (この例は、このメソッドの使用法を人為的に示していますが、`let スライス = NonNull::from(&x[..]);` would be a better way to write code like this.) であることに注意してください。
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // 安全性: `data` は `NonNull` ポインターであり、必ず null 以外です。
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// null 以外の生スライスの長さを返します。
    ///
    /// 戻り値は、バイト数ではなく、**要素** の数です。
    ///
    /// この関数は、ポインタに有効なアドレスがないために null 以外の raw スライスをスライスに逆参照できない場合でも安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// スライスのバッファへの null 以外のポインタを返します。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // 安全性: `self` が null ではないことはわかっています。
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// スライスのバッファへの生のポインタを返します。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// 初期化されていない可能性のある値のスライスへの共有参照を返します。[`as_ref`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// 変更可能な対応物については、[`as_uninit_slice_mut`] を参照してください。
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * `ptr.len() * mem::size_of::<T>()` のバイト数を読み取るには、ポインターは [valid] である必要があり、適切に整列されている必要があります。これは特に次のことを意味します。
    ///
    ///     * このスライスのメモリ範囲全体は、割り当てられた単一のオブジェクト内に含まれている必要があります。
    ///       スライスは、割り当てられた複数のオブジェクトにまたがることはできません。
    ///
    ///     * 長さがゼロのスライスの場合でも、ポインタを揃える必要があります。
    ///     この理由の 1 つは、列挙型レイアウトの最適化では、他のデータと区別するために、参照 (任意の長さのスライスを含む) が整列され、null 以外であることに依存する場合があるためです。
    ///
    ///     [`NonNull::dangling()`] を使用して、長さゼロのスライスの `data` として使用できるポインターを取得できます。
    ///
    /// * スライスの合計サイズ `ptr.len() * mem::size_of::<T>()` は `isize::MAX` 以下でなければなりません。
    ///   [`pointer::offset`] の安全文書を参照してください。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///   特に、この存続期間中、ポインタが指すメモリは変更されてはなりません (`UnsafeCell` 内を除く)。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [`slice::from_raw_parts`] も参照してください。
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // 安全性: 発信者は `as_uninit_slice` の安全契約を守る必要があります。
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// 初期化されていない可能性のある値のスライスへの一意の参照を返します。[`as_mut`] とは対照的に、これは値を初期化する必要はありません。
    ///
    /// 共有の対応物については、[`as_uninit_slice`] を参照してください。
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// このメソッドを呼び出すときは、次のすべてが当てはまることを確認する必要があります。
    ///
    /// * `ptr.len() * mem::size_of::<T>()` の多くのバイトの読み取りおよび書き込みの場合、ポインターは [valid] である必要があり、適切に整列されている必要があります。これは特に次のことを意味します。
    ///
    ///     * このスライスのメモリ範囲全体は、割り当てられた単一のオブジェクト内に含まれている必要があります。
    ///       スライスは、割り当てられた複数のオブジェクトにまたがることはできません。
    ///
    ///     * 長さがゼロのスライスの場合でも、ポインタを揃える必要があります。
    ///     この理由の 1 つは、列挙型レイアウトの最適化では、他のデータと区別するために、参照 (任意の長さのスライスを含む) が整列され、null 以外であることに依存する場合があるためです。
    ///
    ///     [`NonNull::dangling()`] を使用して、長さゼロのスライスの `data` として使用できるポインターを取得できます。
    ///
    /// * スライスの合計サイズ `ptr.len() * mem::size_of::<T>()` は `isize::MAX` 以下でなければなりません。
    ///   [`pointer::offset`] の安全文書を参照してください。
    ///
    /// * 返されるライフタイム `'a` は任意に選択され、データの実際のライフタイムを必ずしも反映しないため、Rust のエイリアシングルールを適用する必要があります。
    ///   特に、この存続期間中、ポインタが指すメモリは、他のポインタを介してアクセス (読み取りまたは書き込み) されてはなりません。
    ///
    /// これは、このメソッドの結果が使用されていない場合でも適用されます。
    ///
    /// [`slice::from_raw_parts_mut`] も参照してください。
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` は `memory.len()` の多くのバイトの読み取りと書き込みに有効であるため、これは安全です。
    /// // コンテンツが初期化されていない可能性があるため、ここでは `memory.as_mut()` の呼び出しは許可されていないことに注意してください。
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // 安全性: 発信者は `as_uninit_slice_mut` の安全契約を守る必要があります。
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// 境界チェックを行わずに、要素またはサブスライスへの生のポインタを返します。
    ///
    /// 範囲外のインデックスを使用して、または `self` が参照解除できないときにこのメソッドを呼び出すと、結果のポインターが使用されない場合でも *[未定義の動作]* になります。
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // 安全性: 呼び出し元は、`self` が参照解除可能であり、`index` がインバウンドであることを確認します。
        // 結果として、結果のポインターを NULL にすることはできません。
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // 安全性: 一意のポインタを null にすることはできないため、
        // new_unchecked() 尊重されます。
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // 安全性: 可変参照を null にすることはできません。
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // 安全性: 参照を null にすることはできないため、
        // new_unchecked() 尊重されます。
        unsafe { NonNull { pointer: reference as *const T } }
    }
}