#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ポイントされたタイプのポインターメタデータタイプを提供します。
///
/// # ポインターメタデータ
///
/// Rust の生のポインター型と参照型は、次の 2 つの部分で構成されていると考えることができます。
/// 値のメモリアドレスといくつかのメタデータを含むデータポインタ。
///
/// 静的サイズの型 (`Sized` traits を実装する) および `extern` 型の場合、ポインターは「薄い」と言われます。メタデータはゼロサイズであり、その型は `()` です。
///
///
/// [dynamically-sized types][dst] へのポインターは「ワイド」または「ファット」と呼ばれ、ゼロ以外のサイズのメタデータがあります。
///
/// * 最後のフィールドが DST である構造体の場合、メタデータは最後のフィールドのメタデータです
/// * `str` タイプの場合、メタデータは `usize` としてのバイト単位の長さです。
/// * `[T]` のようなスライスタイプの場合、メタデータは `usize` としてのアイテムの長さです
/// * `dyn SomeTrait` などの trait オブジェクトの場合、メタデータは [`DynMetadata<Self>`][DynMetadata] (`DynMetadata<dyn SomeTrait>` など) です。
///
/// future では、Rust 言語は、異なるポインターメタデータを持つ新しい種類の型を取得する場合があります。
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// この trait のポイントは、`Metadata` に関連付けられたタイプであり、上記のように `()`、`usize`、または `DynMetadata<_>` です。
/// すべてのタイプに自動的に実装されます。
/// 対応する境界がなくても、一般的なコンテキストで実装されていると見なすことができます。
///
/// # Usage
///
/// 生のポインターは、[`to_raw_parts`] メソッドを使用してデータアドレスとメタデータコンポーネントに分解できます。
///
/// または、[`metadata`] 関数を使用してメタデータのみを抽出することもできます。
/// 参照を [`metadata`] に渡して、暗黙的に強制変換することができます。
///
/// (possibly-wide) ポインターは、[`from_raw_parts`] または [`from_raw_parts_mut`] を使用して、アドレスとメタデータから元に戻すことができます。
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// `Self` へのポインターおよび参照のメタデータのタイプ。
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` で trait bounds を保持します
    //
    // ここにあるものと同期する `library/core/src/ptr/metadata.rs` で:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// この trait エイリアスを実装するタイプへのポインタは「薄い」です。
///
/// これには、静的に `Sized` タイプと `extern` タイプが含まれます。
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait エイリアスが言語で安定する前に、これを安定させませんか?
pub trait Thin = Pointee<Metadata = ()>;

/// ポインターのメタデータコンポーネントを抽出します。
///
/// タイプ `*mut T`、`&T`、または `&mut T` の値は、暗黙的に `* const T` に強制変換されるため、この関数に直接渡すことができます。
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // 安全性: * const T なので、`PtrRepr` ユニオンから値にアクセスするのは安全です。
    // および PtrComponents<T> 同じメモリレイアウトを持っています。
    // std のみがこの保証を行うことができます。
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// データアドレスとメタデータから (possibly-wide) raw ポインターを形成します。
///
/// この関数は安全ですが、返されたポインターは必ずしも安全に逆参照できるとは限りません。
/// スライスについては、安全要件について [`slice::from_raw_parts`] のドキュメントを参照してください。
/// trait オブジェクトの場合、メタデータは、同じ基になる消去されたタイプへのポインターから取得する必要があります。
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // 安全性: * const T なので、`PtrRepr` ユニオンから値にアクセスするのは安全です。
    // および PtrComponents<T> 同じメモリレイアウトを持っています。
    // std のみがこの保証を行うことができます。
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// 生の `*const` ポインターではなく、生の `* mut` ポインターが返されることを除いて、[`from_raw_parts`] と同じ機能を実行します。
///
///
/// 詳細については、[`from_raw_parts`] のドキュメントを参照してください。
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // 安全性: * const T なので、`PtrRepr` ユニオンから値にアクセスするのは安全です。
    // および PtrComponents<T> 同じメモリレイアウトを持っています。
    // std のみがこの保証を行うことができます。
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` のバインドを回避するには、手動で実装する必要があります。
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` のバインドを回避するには、手動で実装する必要があります。
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait オブジェクトタイプのメタデータ。
///
/// これは、trait オブジェクト内に格納されている具象型を操作するために必要なすべての情報を表す vtable (仮想呼び出しテーブル) へのポインターです。
/// 特に vtable には次のものが含まれています。
///
/// * タイプサイズ
/// * タイプの配置
/// * タイプの `drop_in_place` impl へのポインター (plain-old-data の場合は no-op の可能性があります)
/// * タイプの trait の実装のためのすべてのメソッドへのポインター
///
/// 最初の 3 つは、trait オブジェクトの割り当て、削除、および割り当て解除に必要なため、特別であることに注意してください。
///
/// `dyn` trait オブジェクト (たとえば `DynMetadata<u64>`) ではない型パラメーターを使用してこの構造体に名前を付けることは可能ですが、その構造体の意味のある値を取得することはできません。
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// すべての vtable に共通のプレフィックス。その後に、trait メソッドの関数ポインターが続きます。
///
/// `DynMetadata::size_of` などのプライベート実装の詳細。
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// この vtable に関連付けられているタイプのサイズを返します。
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// この vtable に関連付けられているタイプの配置を返します。
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// サイズと配置を一緒に `Layout` として返します
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // 安全性: コンパイラは、具体的な Rust タイプに対してこの vtable を発行しました。
        // 有効なレイアウトがあることがわかっています。`Layout::for_value` と同じ理論的根拠。
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` の境界を回避するには、手動の実装が必要です。

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}