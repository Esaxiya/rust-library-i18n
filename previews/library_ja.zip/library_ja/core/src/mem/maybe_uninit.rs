use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` の初期化されていないインスタンスを構築するためのラッパータイプ。
///
/// # 初期化不変
///
/// 一般に、コンパイラは、変数の型の要件に従って変数が適切に初期化されることを前提としています。たとえば、参照型の変数は整列され、NULL 以外である必要があります。
/// これは不変条件であり、安全でないコードであっても、*常に* 支持する必要があります。
/// 結果として、参照タイプの変数をゼロで初期化すると、その参照がメモリへのアクセスに使用されるかどうかに関係なく、瞬時に [undefined behavior][ub] が発生します。
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // 未定義の動作! ⚠️
/// // `MaybeUninit<&i32>` と同等のコード:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // 未定義の動作! ⚠️
/// ```
///
/// これは、ランタイムチェックの省略や、`enum` レイアウトの最適化など、さまざまな最適化のためにコンパイラによって利用されます。
///
/// 同様に、完全に初期化されていないメモリにはコンテンツが含まれている可能性がありますが、`bool` は常に `true` または `false` である必要があります。したがって、初期化されていない `bool` を作成することは、未定義の動作です。
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // 未定義の動作! ⚠️
/// // `MaybeUninit<bool>` と同等のコード:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // 未定義の動作! ⚠️
/// ```
///
/// さらに、初期化されていないメモリは、固定値 ("fixed" は "it won't change without being written to" を意味します) を持たないという点で特別です。同じ初期化されていないバイトを複数回読み取ると、異なる結果が得られる可能性があります。
/// これにより、変数が整数型であっても、初期化されていないデータが変数に含まれることは未定義の動作になります。整数型でない場合は、任意の *固定* ビットパターンを保持できます。
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // 未定義の動作! ⚠️
/// // `MaybeUninit<i32>` と同等のコード:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // 未定義の動作! ⚠️
/// ```
/// (初期化されていない整数に関するルールはまだ確定されていませんが、確定するまでは回避することをお勧めします。)
///
/// その上、ほとんどのタイプには、タイプレベルで初期化されたと見なされるだけでなく、追加の不変条件があることに注意してください。
/// たとえば、`1` で初期化された [`Vec<T>`] は初期化されたと見なされます (現在の実装では、これは安定した保証を構成しません)。コンパイラがそれについて知っている唯一の要件は、データポインタが null 以外でなければならないことです。
/// このような `Vec<T>` を作成しても、*即時* の未定義の動作は発生しませんが、最も安全な操作 (ドロップを含む) で未定義の動作が発生します。
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` 安全でないコードが初期化されていないデータを処理できるようにするのに役立ちます。
/// これは、ここのデータが初期化されていない可能性があることを示すコンパイラへの信号です。
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // 明示的に初期化されていない参照を作成します。
/// // コンパイラは、`MaybeUninit<T>` 内のデータが無効である可能性があることを認識しているため、これは UB ではありません。
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // 有効な値に設定してください。
/// unsafe { x.as_mut_ptr().write(&0); }
/// // 初期化されたデータを抽出します - これは、`x` を適切に初期化した *後に* のみ許可されます!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// コンパイラは、このコードに対して誤った仮定や最適化を行わないことを認識します。
///
/// `MaybeUninit<T>` は `Option<T>` に少し似ていると考えることができますが、ランタイムトラッキングも、安全性チェックもありません。
///
/// ## out-pointers
///
/// `MaybeUninit<T>` を使用して "out-pointers" を実装できます。関数からデータを返す代わりに、(uninitialized) メモリへのポインタを渡して結果を入れます。
/// これは、結果が格納されるメモリの割り当て方法を呼び出し元が制御することが重要であり、不要な移動を回避したい場合に役立ちます。
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` 重要な古いコンテンツを削除しません。
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // これで、`v` が初期化されたことがわかりました。これにより、vector が適切にドロップされることも確認されます。
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## 要素ごとに配列を初期化する
///
/// `MaybeUninit<T>` 大きな配列を要素ごとに初期化するために使用できます。
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` の初期化されていない配列を作成します。
///     // ここで初期化したと主張しているタイプは、初期化を必要としない一連の `MaybeUninit` であるため、`assume_init` は安全です。
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` をドロップしても何も起こりません。
///     // したがって、`ptr::write` の代わりに生のポインタ割り当てを使用しても、初期化されていない古い値が削除されることはありません。
/////
///     // また、このループ中に panic が発生した場合、メモリリークが発生しますが、メモリの安全性の問題はありません。
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // すべてが初期化されます。
///     // 配列を初期化されたタイプに変換します。
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// 低レベルのデータ構造に見られる、部分的に初期化された配列を操作することもできます。
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` の初期化されていない配列を作成します。
/// // ここで初期化したと主張しているタイプは、初期化を必要としない一連の `MaybeUninit` であるため、`assume_init` は安全です。
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // 割り当てた要素の数を数えます。
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // 配列内の各アイテムについて、割り当てた場合はドロップします。
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## フィールドごとの構造体の初期化
///
/// `MaybeUninit<T>` および [`std::ptr::addr_of_mut`] マクロを使用して、フィールドごとに構造体を初期化できます。
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` フィールドの初期化
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` フィールドの初期化ここに panic がある場合、`name` フィールドの `String` がリークします。
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // すべてのフィールドが初期化されるため、`assume_init` を呼び出して初期化された Foo を取得します。
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` と同じサイズ、配置、および ABI を持つことが保証されています。
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ただし、`MaybeUninit<T>` を *含む* タイプは必ずしも同じレイアウトではないことに注意してください。Rust は、`T` と `U` のサイズと配置が同じであっても、`Foo<T>` のフィールドが `Foo<U>` と同じ順序であることを一般的に保証するものではありません。
///
/// さらに、どのビット値も `MaybeUninit<T>` に有効であるため、コンパイラーは non-zero/niche-filling 最適化を適用できず、サイズが大きくなる可能性があります。
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` が FFI セーフである場合、`MaybeUninit<T>` も同様です。
///
/// `MaybeUninit` は `#[repr(transparent)]` ですが (`T` と同じサイズ、配置、および ABI が保証されることを示します)、これは以前の警告を変更しません。
/// `Option<T>` また、`Option<MaybeUninit<T>>` のサイズは異なる場合があり、タイプ `T` のフィールドを含むタイプは、そのフィールドが `MaybeUninit<T>` の場合とは異なるレイアウト (およびサイズ) になる場合があります。
/// `MaybeUninit` は共用体型であり、共用体の `#[repr(transparent)]` は不安定です ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) を参照)。
/// 時間の経過とともに、ユニオンでの `#[repr(transparent)]` の正確な保証は進化する可能性があり、`MaybeUninit` は `#[repr(transparent)]` のままである場合とそうでない場合があります。
/// そうは言っても、`MaybeUninit<T>` は、`T` と同じサイズ、配置、および ABI を *常に* 保証します。`MaybeUninit` がその保証を実装する方法が進化するかもしれないということだけです。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// 他のタイプを包むことができるようにラングアイテム。これはジェネレーターに役立ちます。
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` を呼び出さないため、そのために十分に初期化されているかどうかを知ることはできません。
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// 指定された値で初期化された新しい `MaybeUninit<T>` を作成します。
    /// この関数の戻り値で [`assume_init`] を呼び出しても安全です。
    ///
    /// `MaybeUninit<T>` をドロップしても、`T` のドロップコードは呼び出されないことに注意してください。
    /// `T` が初期化された場合、それがドロップされることを確認するのはあなたの責任です。
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// 初期化されていない状態で新しい `MaybeUninit<T>` を作成します。
    ///
    /// `MaybeUninit<T>` をドロップしても、`T` のドロップコードは呼び出されないことに注意してください。
    /// `T` が初期化された場合、それがドロップされることを確認するのはあなたの責任です。
    ///
    /// いくつかの例については、[type-level documentation][MaybeUninit] を参照してください。
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// 初期化されていない状態で、`MaybeUninit<T>` アイテムの新しい配列を作成します。
    ///
    /// Note: future Rust バージョンでは、配列リテラル構文で [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) が許可されている場合、このメソッドは不要になる可能性があります。
    ///
    /// 以下の例では、`let mut buf = [MaybeUninit::<u8>::uninit(); 32];` を使用できます。
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// 実際に読み取られたデータの (おそらく小さい) スライスを返します
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // 安全性: 初期化されていない `[MaybeUninit<_>; LEN]` は有効です。
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// 初期化されていない状態で新しい `MaybeUninit<T>` を作成し、メモリを `0` バイトで埋めます。それがすでに適切な初期化につながるかどうかは `T` に依存します。
    ///
    /// たとえば、`MaybeUninit<usize>::zeroed()` は初期化されますが、参照が null であってはならないため、`MaybeUninit<&'static i32>::zeroed()` は初期化されません。
    ///
    /// `MaybeUninit<T>` をドロップしても、`T` のドロップコードは呼び出されないことに注意してください。
    /// `T` が初期化された場合、それがドロップされることを確認するのはあなたの責任です。
    ///
    /// # Example
    ///
    /// この関数の正しい使用法: 構造体をゼロで初期化します。構造物のすべてのフィールドは、ビットパターン 0 を有効な値として保持できます。
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// この関数の *誤った* 使用法: `0` がタイプの有効なビットパターンでない場合に `x.zeroed().assume_init()` を呼び出す:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ペアの中に、有効な判別式を持たない `NotZero` を作成します。
    /// // これは未定義の動作です。⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // 安全性: `u.as_mut_ptr()` は割り当てられたメモリを指します。
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` の値を設定します。
    /// これにより、以前の値が削除されずに上書きされるため、デストラクタの実行をスキップする場合を除いて、これを 2 回使用しないように注意してください。
    ///
    /// 便宜上、これは `self` の (現在は安全に初期化されている) コンテンツへの可変参照も返します。
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // 安全性: この値を初期化しました。
        unsafe { self.assume_init_mut() }
    }

    /// 含まれている値へのポインタを取得します。
    /// `MaybeUninit<T>` が初期化されていない限り、このポインターからの読み取りまたは参照への変換は未定義の動作です。
    /// このポインタ (non-transitively) が指すメモリへの書き込みは、未定義の動作です (`UnsafeCell<T>` 内を除く)。
    ///
    /// # Examples
    ///
    /// この方法の正しい使用法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` への参照を作成します。初期化したので問題ありません。
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// このメソッドの *誤った* 使用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // 初期化されていない vector への参照を作成しました! これは未定義の動作です。⚠️
    /// ```
    ///
    /// (初期化されていないデータへの参照に関するルールはまだ確定されていませんが、確定するまでは回避することをお勧めします。)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` と `ManuallyDrop` は両方とも `repr(transparent)` なので、ポインターをキャストできます。
        self as *const _ as *const T
    }

    /// 含まれている値への可変ポインタを取得します。
    /// `MaybeUninit<T>` が初期化されていない限り、このポインターからの読み取りまたは参照への変換は未定義の動作です。
    ///
    /// # Examples
    ///
    /// この方法の正しい使用法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` への参照を作成します。
    /// // 初期化したので問題ありません。
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// このメソッドの *誤った* 使用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // 初期化されていない vector への参照を作成しました! これは未定義の動作です。⚠️
    /// ```
    ///
    /// (初期化されていないデータへの参照に関するルールはまだ確定されていませんが、確定するまでは回避することをお勧めします。)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` と `ManuallyDrop` は両方とも `repr(transparent)` なので、ポインターをキャストできます。
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` コンテナから値を抽出します。結果の `T` は通常のドロップ処理の対象となるため、これはデータが確実にドロップされるようにするための優れた方法です。
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` が実際に初期化された状態にあることを保証するのは、呼び出し元の責任です。コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、すぐに未定義の動作が発生します。
    /// [type-level documentation][inv] には、この初期化不変条件に関する詳細情報が含まれています。
    ///
    /// [inv]: #initialization-invariant
    ///
    /// その上、ほとんどのタイプには、タイプレベルで初期化されたと見なされるだけでなく、追加の不変条件があることに注意してください。
    /// たとえば、`1` で初期化された [`Vec<T>`] は初期化されたと見なされます (現在の実装では、これは安定した保証を構成しません)。コンパイラがそれについて知っている唯一の要件は、データポインタが null 以外でなければならないことです。
    ///
    /// このような `Vec<T>` を作成しても、*即時* の未定義の動作は発生しませんが、最も安全な操作 (ドロップを含む) で未定義の動作が発生します。
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// この方法の正しい使用法:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// このメソッドの *誤った* 使用法:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` まだ初期化されていないため、この最後の行で未定義の動作が発生しました。⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // 安全性: 呼び出し元は、`self` が初期化されることを保証する必要があります。
        // これは、`self` が `value` バリアントでなければならないことも意味します。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` コンテナから値を読み取ります。結果として得られる `T` は、通常のドロップ処理の対象となります。
    ///
    /// 可能な限り、代わりに [`assume_init`] を使用することをお勧めします。これにより、`MaybeUninit<T>` のコンテンツが重複するのを防ぐことができます。
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` が実際に初期化された状態にあることを保証するのは、呼び出し元の責任です。コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。
    /// [type-level documentation][inv] には、この初期化不変条件に関する詳細情報が含まれています。
    ///
    /// さらに、これにより、同じデータのコピーが `MaybeUninit<T>` に残ります。
    /// データの複数のコピーを使用する場合 (`assume_init_read` を複数回呼び出すか、最初に `assume_init_read` を呼び出してから [`assume_init`] を呼び出す)、データが実際に複製される可能性があることを確認するのはユーザーの責任です。
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// この方法の正しい使用法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` なので、複数回読み取る場合があります。
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` 値を複製しても問題ないため、複数回読み取る場合があります。
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// このメソッドの *誤った* 使用法:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // 同じ vector のコピーを 2 つ作成しました。両方がドロップされると、ダブルフリーの⚠️になります。
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // 安全性: 呼び出し元は、`self` が初期化されることを保証する必要があります。
        // `self` を初期化する必要があるため、`self.as_ptr()` からの読み取りは安全です。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// 含まれている値を所定の位置にドロップします。
    ///
    /// `MaybeUninit` の所有権がある場合は、代わりに [`assume_init`] を使用できます。
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` が実際に初期化された状態にあることを保証するのは、呼び出し元の責任です。コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。
    ///
    /// さらに、`T` (またはそのメンバー) の `Drop` 実装はこれに依存する可能性があるため、タイプ `T` のすべての追加の不変条件が満たされる必要があります。
    /// たとえば、`1` で初期化された [`Vec<T>`] は初期化されたと見なされます (現在の実装では、これは安定した保証を構成しません)。コンパイラがそれについて知っている唯一の要件は、データポインタが null 以外でなければならないことです。
    ///
    /// ただし、そのような `Vec<T>` をドロップすると、未定義の動作が発生します。
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // 安全性: 発信者は、`self` が初期化されていることを保証する必要があります。
        // `T` のすべての不変条件を満たします。
        // その場合は、値を所定の位置にドロップしても安全です。
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// 含まれている値への共有参照を取得します。
    ///
    /// これは、初期化されているが `MaybeUninit` の所有権を持たない (`.assume_init()`) の使用を防ぐ) `MaybeUninit` にアクセスする場合に役立ちます。
    ///
    /// # Safety
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。`MaybeUninit<T>` が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    ///
    /// # Examples
    ///
    /// ### この方法の正しい使用法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` を初期化します。
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // `MaybeUninit<_>` が初期化されていることがわかったので、`MaybeUninit<_>` への共有参照を作成しても問題ありません。
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // 安全性: `x` が初期化されました。
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### このメソッドの *誤った* 使用法:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // 初期化されていない vector への参照を作成しました! これは未定義の動作です。⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` を使用して `MaybeUninit` を初期化します。
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // 初期化されていない `Cell<bool>` への参照: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // 安全性: 呼び出し元は、`self` が初期化されることを保証する必要があります。
        // これは、`self` が `value` バリアントでなければならないことも意味します。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// 含まれている値への可変 (unique) 参照を取得します。
    ///
    /// これは、初期化されているが `MaybeUninit` の所有権を持たない (`.assume_init()`) の使用を防ぐ) `MaybeUninit` にアクセスする場合に役立ちます。
    ///
    /// # Safety
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。`MaybeUninit<T>` が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    /// たとえば、`.assume_init_mut()` を使用して `MaybeUninit` を初期化することはできません。
    ///
    /// # Examples
    ///
    /// ### この方法の正しい使用法:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// 入力バッファの *すべて* のバイトを初期化します。
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` を初期化します。
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // これで、`buf` が初期化されたことがわかったので、`.assume_init()` を実行できます。
    /// // ただし、`.assume_init()` を使用すると、2048 バイトの `memcpy` がトリガーされる場合があります。
    /// // バッファをコピーせずに初期化されたことを表明するには、`&mut MaybeUninit<[u8; 2048]>` を `&mut [u8; 2048]` にアップグレードします。
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // 安全性: `buf` が初期化されました。
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // これで、`buf` を通常のスライスとして使用できます。
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### このメソッドの *誤った* 使用法:
    ///
    /// `.assume_init_mut()` を使用して値を初期化することはできません。
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // 初期化されていない `bool` への (mutable) 参照を作成しました!
    ///     // これは未定義の動作です。⚠️
    /// }
    /// ```
    ///
    /// たとえば、初期化されていないバッファに [`Read`] を入れることはできません。
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) 初期化されていないメモリへの参照!
    ///                             // これは未定義の動作です。
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// また、直接フィールドアクセスを使用して、フィールドごとの段階的な初期化を行うこともできません。
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 初期化されていないメモリへの参照!
    ///                  // これは未定義の動作です。
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) 初期化されていないメモリへの参照!
    ///                  // これは未定義の動作です。
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): 現在、上記が正しくないことに依存しています。つまり、初期化されていないデータへの参照があります (たとえば、`libcore/fmt/float.rs`)。
    // 安定化する前に、ルールについて最終決定を下す必要があります。
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // 安全性: 呼び出し元は、`self` が初期化されることを保証する必要があります。
        // これは、`self` が `value` バリアントでなければならないことも意味します。
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` コンテナの配列から値を抽出します。
    ///
    /// # Safety
    ///
    /// 配列のすべての要素が初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // 安全性: すべての要素を初期化したので安全になりました
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * 呼び出し元は、配列のすべての要素が初期化されることを保証します
        // * `MaybeUninit<T>` と T は同じレイアウトであることが保証されています
        // * たぶん Unint はドロップしないので、ダブルフリーはありません。したがって、変換は安全です。
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// すべての要素が初期化されていると仮定して、それらにスライスを取得します。
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 要素が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。
    ///
    /// 詳細と例については、[`assume_init_ref`] を参照してください。
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // 安全性: 発信者が次のことを保証するため、`*const [T]` にスライスをキャストすることは安全です
        // `slice` が初期化され、`MaybeUninit` は `T` と同じレイアウトになることが保証されています。
        // 得られたポインタは、参照である `slice` が所有するメモリを参照しているため有効であり、読み取りに対して有効であることが保証されています。
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// すべての要素が初期化されていると仮定して、それらに可変スライスを取得します。
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` 要素が実際に初期化された状態にあることを保証するのは呼び出し元の責任です。
    ///
    /// コンテンツがまだ完全に初期化されていないときにこれを呼び出すと、未定義の動作が発生します。
    ///
    /// 詳細と例については、[`assume_init_mut`] を参照してください。
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // 安全性: `slice_get_ref` の安全性に関する注意事項に似ていますが、
        // 書き込みにも有効であることが保証されている可変参照。
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// 配列の最初の要素へのポインタを取得します。
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// 配列の最初の要素への可変ポインターを取得します。
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// 要素を `src` から `this` にコピーし、現在初期化されている `this` のコンテンツへの変更可能な参照を返します。
    ///
    /// `T` が `Copy` を実装していない場合は、[`write_slice_cloned`] を使用してください
    ///
    /// これは [`slice::copy_from_slice`] に似ています。
    ///
    /// # Panics
    ///
    /// 2 つのスライスの長さが異なる場合、この関数は panic になります。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 安全性: len のすべての要素を予備の容量にコピーしました
    /// // vec の最初の src.len() 要素が有効になりました。
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // 安全性:＆[T] および＆[MaybeUninit<T>] 同じレイアウト
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // 安全性: 有効な要素が `this` にコピーされたばかりなので、初期化されます
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// 要素を `src` から `this` に複製し、現在初期化されている `this` のコンテンツへの変更可能な参照を返します。
    /// すでに初期化されている要素は削除されません。
    ///
    /// `T` が `Copy` を実装している場合は、[`write_slice`] を使用します
    ///
    /// これは [`slice::clone_from_slice`] に似ていますが、既存の要素を削除しません。
    ///
    /// # Panics
    ///
    /// この関数は、2 つのスライスの長さが異なる場合、または `Clone` panics の実装の場合、panic になります。
    ///
    /// panic がある場合、すでに複製された要素は削除されます。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // 安全性: len のすべての要素を予備の容量に複製しました
    /// // vec の最初の src.len() 要素が有効になりました。
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice とは異なり、これはスライスで clone_from_slice を呼び出しません。これは、`MaybeUninit<T: Clone>` が Clone を実装していないためです。
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // 安全性: この生のスライスには、初期化されたオブジェクトのみが含まれます
                // そのため、ドロップすることが許可されています。
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: それらを同じ長さに明示的にスライスする必要があります
        // 境界チェックを省略し、オプティマイザは単純な場合 (たとえば、T= u8) の memcpy を生成します。
        //
        let len = this.len();
        let src = &src[..len];

        // ガードが必要です b/c panic はクローン中に発生する可能性があります
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // 安全性: 有効な要素が `this` に書き込まれたばかりなので、初期化されます
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}