//! メモリを扱うための基本的な機能。
//!
//! このモジュールには、タイプのサイズと配置を照会し、メモリを初期化および操作するための関数が含まれています。
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// **デストラクタを実行せずに** 値について所有権と "forgets" を取得します。
///
/// ヒープメモリやファイルハンドルなど、値が管理するリソースは、到達不能な状態で永久に残ります。ただし、このメモリへのポインタが有効なままであるとは限りません。
///
/// * メモリをリークしたい場合は、[`Box::leak`] を参照してください。
/// * メモリへの生のポインタを取得する場合は、[`Box::into_raw`] を参照してください。
/// * デストラクタを実行して値を適切に破棄する場合は、[`mem::drop`] を参照してください。
///
/// # Safety
///
/// `forget` Rust の安全保証には、デストラクタが常に実行されるという保証が含まれていないため、`unsafe` としてマークされていません。
/// たとえば、プログラムは [`Rc`][rc] を使用して参照サイクルを作成したり、[`process::exit`][exit] を呼び出してデストラクタを実行せずに終了したりできます。
/// したがって、安全なコードから `mem::forget` を許可しても、Rust の安全保証は根本的に変わりません。
///
/// とはいえ、メモリや I/O オブジェクトなどのリソースのリークは通常望ましくありません。
/// FFI または安全でないコードのいくつかの特殊なユースケースで必要が生じますが、それでも、通常は [`ManuallyDrop`] が推奨されます。
///
/// 値を忘れることは許可されているため、作成する `unsafe` コードはすべてこの可能性を考慮に入れる必要があります。値を返すことはできず、呼び出し元が必ず値のデストラクタを実行することを期待できません。
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` の標準的な安全な使用法は、`Drop` trait によって実装された値のデストラクタを回避することです。たとえば、これは `File` をリークします。
/// 変数が使用するスペースを再利用しますが、基になるシステムリソースを閉じないでください。
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// これは、基になるリソースの所有権が以前に Rust の外部のコードに転送された場合、たとえば生のファイル記述子を C コードに送信することによって役立ちます。
///
/// # `ManuallyDrop` との関係
///
/// `mem::forget` を使用して *メモリ* の所有権を転送することもできますが、そうするとエラーが発生しやすくなります。
/// [`ManuallyDrop`] 代わりに使用する必要があります。たとえば、次のコードについて考えてみます。
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` のコンテンツを使用して `String` を構築します
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` のメモリが `s` によって管理されるようになったため、`v` がリークする
/// mem::forget(v);  // エラー、v は無効であり、関数に渡してはなりません
/// assert_eq!(s, "Az");
/// // `s` 暗黙的に削除され、そのメモリの割り当てが解除されます。
/// ```
///
/// 上記の例には 2 つの問題があります。
///
/// * `String` の構築と `mem::forget()` の呼び出しの間にコードが追加された場合、同じメモリが `v` と `s` の両方で処理されるため、その中の panic によってダブルフリーが発生します。
/// * `v.as_mut_ptr()` を呼び出し、データの所有権を `s` に送信した後、`v` 値は無効です。
/// 値が `mem::forget` に移動されたばかりの場合 (検査されません) でも、一部のタイプには値に厳しい要件があり、ぶら下がっているときや所有されていないときに無効になります。
/// 関数への受け渡しや関数からの返送など、何らかの方法で無効な値を使用すると、未定義の動作が構成され、コンパイラーによる想定が破られる可能性があります。
///
/// `ManuallyDrop` に切り替えると、次の両方の問題が回避されます。
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // `v` を未加工の部品に分解する前に、落下しないことを確認してください。
/////
/// let mut v = ManuallyDrop::new(v);
/// // `v` を分解します。これらの操作は panic できないため、リークが発生することはありません。
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // 最後に、`String` を作成します。
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` 暗黙的に削除され、そのメモリの割り当てが解除されます。
/// ```
///
/// `ManuallyDrop` 他のことをする前に `v` のデストラクタを無効にするため、ダブルフリーを確実に防ぎます。
/// `mem::forget()` 引数を消費するため、これは許可されません。`v` から必要なものを抽出した後でのみ呼び出す必要があります。
/// `ManuallyDrop` の構築と文字列の構築の間に panic が導入されたとしても (これは、示されているコードでは発生しません)、リークが発生し、ダブルフリーではありません。
/// 言い換えると、`ManuallyDrop` は、(ダブル) ドロップの側でエラーを起こすのではなく、リークの側でエラーを起こします。
///
/// また、`ManuallyDrop` は、所有権を `s` に譲渡した後に "touch" `v` を実行する必要がないようにします。`v` と対話して、デストラクタを実行せずに破棄する最後のステップは完全に回避されます。
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] と同様ですが、サイズのない値も受け入れます。
///
/// この機能は、`unsized_locals` 機能が安定したときに削除することを目的としたシムです。
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// 型のサイズをバイト単位で返します。
///
/// より具体的には、これは、配列のパディングを含むそのアイテムタイプを持つ配列内の連続する要素間のバイト単位のオフセットです。
///
/// したがって、タイプ `T` および長さ `n` の場合、`[T; n]` のサイズは `n * size_of::<T>()` になります。
///
/// 一般に、型のサイズはコンパイル間で安定していませんが、プリミティブなどの特定の型は安定しています。
///
/// 次の表に、プリミティブのサイズを示します。
///
/// タイプ | のサイズ: : \<Type> ()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 文字 | 4
///
/// さらに、`usize` と `isize` のサイズは同じです。
///
/// タイプ `*const T`、`&T`、`Box<T>`、`Option<&T>`、および `Option<Box<T>>` はすべて同じサイズです。
/// `T` がサイズ設定されている場合、これらのタイプはすべて `usize` と同じサイズになります。
///
/// ポインタの可変性はそのサイズを変更しません。そのため、`&T` と `&mut T` のサイズは同じです。
/// `*const T` と `* mut T` についても同様です。
///
/// # `#[repr(C)]` アイテムのサイズ
///
/// アイテムの `C` 表現には、定義済みのレイアウトがあります。
/// このレイアウトでは、すべてのフィールドのサイズが安定している限り、アイテムのサイズも安定しています。
///
/// ## 構造体のサイズ
///
/// `structs` の場合、サイズは次のアルゴリズムによって決定されます。
///
/// 宣言順で並べられた構造体の各フィールドについて:
///
/// 1. フィールドのサイズを追加します。
/// 2. 現在のサイズを次のフィールドの [alignment] の最も近い倍数に切り上げます。
///
/// 最後に、構造体のサイズを [alignment] の最も近い倍数に丸めます。
/// 構造体の配置は通常、そのすべてのフィールドの最大の配置です。これは、`repr(align(N))` を使用して変更できます。
///
/// `C` とは異なり、サイズがゼロの構造体はサイズが 1 バイトに切り上げられません。
///
/// ## 列挙型のサイズ
///
/// 判別式以外のデータを持たない列挙型は、コンパイル対象のプラットフォーム上の C 列挙型と同じサイズです。
///
/// ## ユニオンのサイズ
///
/// ユニオンのサイズは、その最大のフィールドのサイズです。
///
/// `C` とは異なり、サイズがゼロの共用体はサイズが 1 バイトに切り上げられません。
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // いくつかのプリミティブ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // いくつかの配列
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // ポインタサイズの同等性
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` を使用します。
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // 最初のフィールドのサイズは 1 なので、サイズに 1 を追加します。サイズは 1 です。
/// // 2 番目のフィールドの配置は 2 なので、パディングのサイズに 1 を追加します。サイズは 2 です。
/// // 2 番目のフィールドのサイズは 2 なので、サイズに 2 を追加します。サイズは 4 です。
/// // 3 番目のフィールドの配置は 1 なので、パディングのサイズに 0 を追加します。サイズは 4 です。
/// // 3 番目のフィールドのサイズは 1 なので、サイズに 1 を追加します。サイズは 5 です。
/// // 最後に、構造の配置は 2 です (フィールド間の最大の配置は 2 であるため)。したがって、パディングのサイズに 1 を追加します。
/// // サイズは 6 です。
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // タプル構造体は同じルールに従います。
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // フィールドを並べ替えるとサイズが小さくなる可能性があることに注意してください。
/// // `second` の前に `third` を置くことで、両方のパディングバイトを削除できます。
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ユニオンサイズは、最大のフィールドのサイズです。
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// ポイントされた値のサイズをバイト単位で返します。
///
/// これは通常 `size_of::<T>()` と同じです。
/// ただし、`T` に静的に既知のサイズが *ない* 場合 (スライス [`[T]`][slice] や [trait object] など)、`size_of_val` を使用して動的に既知のサイズを取得できます。
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全性: `val` は参照であるため、有効な生のポインターです
    unsafe { intrinsics::size_of_val(val) }
}

/// ポイントされた値のサイズをバイト単位で返します。
///
/// これは通常 `size_of::<T>()` と同じです。ただし、`T` に静的に既知のサイズが *ない* 場合 (スライス [`[T]`][slice] または [trait object] など)、`size_of_val_raw` を使用して動的に既知のサイズを取得できます。
///
/// # Safety
///
/// この関数は、次の条件が当てはまる場合にのみ安全に呼び出すことができます。
///
/// - `T` が `Sized` の場合、この関数はいつでも安全に呼び出すことができます。
/// - `T` のサイズのないテールが次の場合:
///     - [slice] の場合、スライステールの長さは初期化された整数である必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
///     - [trait object] の場合、ポインターの vtable 部分は、サイズ変更の強制によって取得された有効な vtable を指している必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
///
///     - (unstable) [extern type] の場合、この関数は常に安全に呼び出すことができますが、extern タイプのレイアウトが不明であるため、panic またはその他の方法で間違った値を返す可能性があります。
///     これは、extern タイプのテールを持つタイプへの参照での [`size_of_val`] と同じ動作です。
///     - それ以外の場合、この関数を呼び出すことは控えめに許可されていません。
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 安全性: 発信者は有効な生のポインタを提供する必要があります
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI] に必要なタイプの最小配置を返します。
///
/// タイプ `T` の値へのすべての参照は、この数値の倍数である必要があります。
///
/// これは、構造体フィールドに使用される配置です。推奨される配置よりも小さい場合があります。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` が指す値のタイプの [ABI] に必要な最小配置を返します。
///
/// タイプ `T` の値へのすべての参照は、この数値の倍数である必要があります。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全性: val は参照であるため、有効な生のポインターです
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] に必要なタイプの最小配置を返します。
///
/// タイプ `T` の値へのすべての参照は、この数値の倍数である必要があります。
///
/// これは、構造体フィールドに使用される配置です。推奨される配置よりも小さい場合があります。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` が指す値のタイプの [ABI] に必要な最小配置を返します。
///
/// タイプ `T` の値へのすべての参照は、この数値の倍数である必要があります。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // 安全性: val は参照であるため、有効な生のポインターです
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` が指す値のタイプの [ABI] に必要な最小配置を返します。
///
/// タイプ `T` の値へのすべての参照は、この数値の倍数である必要があります。
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// この関数は、次の条件が当てはまる場合にのみ安全に呼び出すことができます。
///
/// - `T` が `Sized` の場合、この関数はいつでも安全に呼び出すことができます。
/// - `T` のサイズのないテールが次の場合:
///     - [slice] の場合、スライステールの長さは初期化された整数である必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
///     - [trait object] の場合、ポインターの vtable 部分は、サイズ変更の強制によって取得された有効な vtable を指している必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
///
///     - (unstable) [extern type] の場合、この関数は常に安全に呼び出すことができますが、extern タイプのレイアウトが不明であるため、panic またはその他の方法で間違った値を返す可能性があります。
///     これは、extern タイプのテールを持つタイプへの参照での [`align_of_val`] と同じ動作です。
///     - それ以外の場合、この関数を呼び出すことは控えめに許可されていません。
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // 安全性: 発信者は有効な生のポインタを提供する必要があります
    unsafe { intrinsics::min_align_of_val(val) }
}

/// タイプ `T` の値を削除することが重要な場合は、`true` を返します。
///
/// これは純粋に最適化のヒントであり、控えめに実装できます。
/// 実際にドロップする必要のないタイプの場合は、`true` が返される場合があります。
/// そのため、常に `true` を返すことは、この関数の有効な実装になります。ただし、この関数が実際に `false` を返す場合は、`T` を削除しても副作用がないことを確認できます。
///
/// データを手動で削除する必要があるコレクションなどの低レベルの実装では、この関数を使用して、データが破棄されたときにすべてのコンテンツを不必要に削除しようとしないようにする必要があります。
///
/// これはリリースビルド (副作用のないループを簡単に検出して排除する) では違いがないかもしれませんが、デバッグビルドにとっては大きなメリットになることがよくあります。
///
/// [`drop_in_place`] はすでにこのチェックを実行しているため、ワークロードを少数の [`drop_in_place`] 呼び出しに減らすことができる場合は、これを使用する必要はありません。
/// 特に、スライスを [`drop_in_place`] できることに注意してください。これにより、すべての値に対して 1 回の needs_drop チェックが実行されます。
///
/// したがって、Vec のようなタイプは、`needs_drop` を明示的に使用せずに `drop_in_place(&mut self[..])` だけを使用します。
/// 一方、[`HashMap`] のようなタイプは、一度に 1 つずつ値を削除する必要があり、この API を使用する必要があります。
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// コレクションが `needs_drop` をどのように利用するかの例を次に示します。
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // データを削除します
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// オールゼロのバイトパターンで表されるタイプ `T` の値を返します。
///
/// これは、たとえば、`(u8, u16)` のパディングバイトが必ずしもゼロにされていないことを意味します。
///
/// オールゼロのバイトパターンが `T` タイプの有効な値を表すという保証はありません。
/// たとえば、すべてゼロのバイトパターンは、参照型 ( `＆T`、`&mut T`) および関数ポインタの有効な値ではありません。
/// このようなタイプで `zeroed` を使用すると、初期化されたと見なされる変数に常に有効な値が存在する [the Rust compiler assumes][inv] が発生するため、すぐに [undefined behavior][ub] が発生します。
///
///
/// これは [`MaybeUninit::zeroed().assume_init()`][zeroed] と同じ効果があります。
/// これは FFI に役立つ場合がありますが、通常は避ける必要があります。
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// この関数の正しい使用法: ゼロで整数を初期化します。
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// この関数の *誤った* 使用法: ゼロで参照を初期化しています。
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // 未定義の動作!
/// let _y: fn() = unsafe { mem::zeroed() }; // そしてまた!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // 安全性: 呼び出し元は、`T` に対してすべてゼロの値が有効であることを保証する必要があります。
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// 何もせずに、タイプ `T` の値を生成するふりをして、Rust の通常のメモリ初期化チェックをバイパスします。
///
/// **この関数は非推奨です。** 代わりに [`MaybeUninit<T>`] を使用してください。
///
/// 非推奨の理由は、この関数は基本的に正しく使用できないためです。[`MaybeUninit::uninit().assume_init()`][uninit] と同じ効果があります。
///
/// [`assume_init` documentation][assume_init] が説明しているように、[the Rust compiler assumes][inv] の値は適切に初期化されています。
/// 結果として、例えば
/// `mem::uninitialized::<bool>()` `true` でも `false` でもない `bool` を返すと、すぐに未定義の動作が発生します。
/// さらに悪いことに、ここで返されるような真に初期化されていないメモリは、コンパイラが固定値を持たないことを認識しているという点で特別です。
/// これにより、変数が整数型であっても、変数に初期化されていないデータが含まれることは未定義の動作になります。
/// (初期化されていない整数に関するルールはまだ確定されていませんが、確定するまでは回避することをお勧めします。)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // 安全性: 呼び出し元は、単位化された値が `T` に対して有効であることを保証する必要があります。
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// どちらか一方を非初期化せずに、2 つの可変位置で値を交換します。
///
/// * デフォルト値またはダミー値と交換する場合は、[`take`] を参照してください。
/// * 渡された値と交換して古い値を返す場合は、[`replace`] を参照してください。
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // 安全性: 生のポインターは、すべてを満たす安全な可変参照から作成されています
    // `ptr::swap_nonoverlapping_one` の制約
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` をデフォルト値の `T` に置き換え、以前の `dest` 値を返します。
///
/// * 2 つの変数の値を置き換える場合は、[`swap`] を参照してください。
/// * デフォルト値の代わりに渡された値に置き換える場合は、[`replace`] を参照してください。
///
/// # Examples
///
/// 簡単な例:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` 構造体フィールドを "empty" 値に置き換えることにより、構造体フィールドの所有権を取得できます。
/// `take` がないと、次のような問題が発生する可能性があります。
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` は必ずしも [`Clone`] を実装しているわけではないため、`self.buf` のクローンを作成してリセットすることもできません。
/// ただし、`take` を使用して、`self.buf` の元の値と `self` の関連付けを解除し、次の値を返すことができます。
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` を参照されている `dest` に移動し、前の `dest` 値を返します。
///
/// どちらの値も削除されません。
///
/// * 2 つの変数の値を置き換える場合は、[`swap`] を参照してください。
/// * デフォルト値に置き換える場合は、[`take`] を参照してください。
///
/// # Examples
///
/// 簡単な例:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` 構造体フィールドを別の値に置き換えることで、構造体フィールドを使用できるようにします。
/// `replace` がないと、次のような問題が発生する可能性があります。
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` は必ずしも [`Clone`] を実装しているわけではないため、移動を回避するために `self.buf[i]` のクローンを作成することさえできないことに注意してください。
/// ただし、`replace` を使用して、そのインデックスの元の値と `self` の関連付けを解除し、次の値を返すことができます。
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // 安全性: `dest` から読み取りますが、後で `src` を直接書き込みます。
    // 古い値が複製されないようにします。
    // 何もドロップされず、ここでは何も panic できません。
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// 値を破棄します。
///
/// これは、引数の [`Drop`][drop] の実装を呼び出すことによって行われます。
///
/// これは、`Copy` を実装するタイプに対しては事実上何もしません。
/// integers.
/// このような値はコピーされ、_then_ が関数に移動されるため、この関数呼び出し後も値は保持されます。
///
///
/// この関数は魔法ではありません。それは文字通り次のように定義されます
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` は関数に移動されるため、関数が戻る前に自動的に削除されます。
///
/// [drop]: Drop
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector を明示的にドロップします
/// ```
///
/// [`RefCell`] は実行時に借用ルールを適用するため、`drop` は [`RefCell`] 借用を解放できます。
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // このスロットの可変借入を放棄する
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] を実装する整数およびその他のタイプは、`drop` の影響を受けません。
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` のコピーが移動およびドロップされます
/// drop(y); // `y` のコピーが移動およびドロップされます
///
/// println!("x: {}, y: {}", x, y.0); // まだ利用可能です
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` をタイプ `&U` として解釈し、含まれている値を移動せずに `src` を読み取ります。
///
/// この関数は、`&T` を `&U` に変換してから `&U` を読み取ることにより、ポインター `src` が [`size_of::<U>`][size_of] バイトに対して有効であると安全に想定しません (ただし、`&U` が `&T` よりも厳しいアライメント要件を作成する場合でも正しい方法で実行されます)。
/// また、`src` から移動する代わりに、含まれている値のコピーを安全に作成しません。
///
/// `T` と `U` のサイズが異なる場合はコンパイル時エラーではありませんが、`T` と `U` のサイズが同じである場合にのみこの関数を呼び出すことを強くお勧めします。`U` が `T` より大きい場合、この関数は [undefined behavior][ub] をトリガーします。
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' からデータをコピーし、'Foo' として扱います
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // コピーしたデータを変更する
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' の内容は変更されるべきではありません
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U のアライメント要件が高い場合、src が適切にアライメントされていない可能性があります。
    if align_of::<U>() > align_of::<T>() {
        // 安全性: `src` は、読み取りに対して有効であることが保証されている参照です。
        // 呼び出し元は、実際の核変換が安全であることを保証する必要があります。
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // 安全性: `src` は、読み取りに対して有効であることが保証されている参照です。
        // `src as *const U` が正しく位置合わせされていることを確認しました。
        // 呼び出し元は、実際の核変換が安全であることを保証する必要があります。
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// 列挙型の判別式を表す不透明 (OPAQUE) 型。
///
/// 詳細については、このモジュールの [`discriminant`] 関数を参照してください。
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. T に境界が必要ないため、これらの trait 実装を導出することはできません。

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` の列挙型バリアントを一意に識別する値を返します。
///
/// `T` が列挙型でない場合、この関数を呼び出しても未定義の動作は発生しませんが、戻り値は指定されていません。
///
///
/// # Stability
///
/// 列挙型の定義が変更されると、列挙型バリアントの判別式が変更される場合があります。
/// 一部のバリアントの判別式は、同じコンパイラを使用したコンパイル間で変更されません。
///
/// # Examples
///
/// これは、実際のデータを無視して、データを運ぶ列挙型を比較するために使用できます。
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// 列挙型 `T` のバリアントの数を返します。
///
/// `T` が列挙型でない場合、この関数を呼び出しても未定義の動作は発生しませんが、戻り値は指定されていません。
/// 同様に、`T` が `usize::MAX` よりも多くのバリアントを持つ列挙型である場合、戻り値は指定されていません。
/// 無人の亜種がカウントされます。
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}