use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// コンパイラが `T` のデストラクタを自動的に呼び出さないようにするラッパー。
/// このラッパーは 0 コストです。
///
/// `ManuallyDrop<T>` `T` と同じレイアウト最適化の対象となります。
/// 結果として、コンパイラがその内容について行う仮定には *影響* はありません。
/// たとえば、[`mem::zeroed`] で `ManuallyDrop<&mut T>` を初期化することは未定義の動作です。
/// 初期化されていないデータを処理する必要がある場合は、代わりに [`MaybeUninit<T>`] を使用してください。
///
/// `ManuallyDrop<T>` 内の値にアクセスするのは安全であることに注意してください。
/// つまり、コンテンツが削除された `ManuallyDrop<T>` は、パブリックセーフ API を介して公開されてはなりません。
/// 同様に、`ManuallyDrop::drop` は安全ではありません。
///
/// # `ManuallyDrop` とドロップオーダー。
///
/// Rust には、明確に定義された [drop order] の値があります。
/// フィールドまたはローカルが特定の順序でドロップされるようにするには、暗黙のドロップ順序が正しいものになるように宣言を並べ替えます。
///
/// `ManuallyDrop` を使用してドロップ順序を制御することは可能ですが、これには安全でないコードが必要であり、巻き戻しがある場合に正しく実行するのは困難です。
///
///
/// たとえば、特定のフィールドが他のフィールドの後にドロップされるようにする場合は、それを構造体の最後のフィールドにします。
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` の後にドロップされます。
///     // Rust は、フィールドが宣言順にドロップされることを保証します。
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// 手動で削除する値をラップします。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // あなたはまだ安全に値を操作することができます
    /// assert_eq!(*x, "Hello");
    /// // ただし、`Drop` はここでは実行されません
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` コンテナから値を抽出します。
    ///
    /// これにより、値を再度ドロップできます。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // これにより、`Box` がドロップされます。
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` コンテナから値を取り出します。
    ///
    /// この方法は、主に値をドロップで移動することを目的としています。
    /// [`ManuallyDrop::drop`] を使用して手動で値を削除する代わりに、このメソッドを使用して値を取得し、必要に応じて使用できます。
    ///
    /// 可能な限り、代わりに [`into_inner`][`ManuallyDrop::into_inner`] を使用することをお勧めします。これにより、`ManuallyDrop<T>` のコンテンツが重複するのを防ぐことができます。
    ///
    ///
    /// # Safety
    ///
    /// この関数は、このコンテナの状態を変更せずに、それ以上の使用を妨げることなく、含まれている値を意味的に移動します。
    /// この `ManuallyDrop` が再び使用されないようにするのはあなたの責任です。
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // 安全性: 私たちは参照から読んでいます、それは保証されています
        // 読み取りに有効です。
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// 含まれている値を手動で削除します。これは、含まれている値へのポインタを使用して [`ptr::drop_in_place`] を呼び出すこととまったく同じです。
    /// そのため、含まれている値がパック構造でない限り、デストラクタは値を移動せずにインプレースで呼び出されるため、[pinned] データを安全にドロップするために使用できます。
    ///
    /// 値の所有権がある場合は、代わりに [`ManuallyDrop::into_inner`] を使用できます。
    ///
    /// # Safety
    ///
    /// この関数は、含まれている値のデストラクタを実行します。
    /// デストラクタ自体によって行われた変更を除いて、メモリは変更されないままであり、コンパイラに関する限り、`T` 型に有効なビットパターンを保持します。
    ///
    ///
    /// ただし、この "zombie" 値を安全なコードに公開したり、この関数を複数回呼び出したりしないでください。
    /// ドロップされた後に値を使用したり、値を複数回ドロップしたりすると、未定義の動作が発生する可能性があります (`drop` の動作によって異なります)。
    /// これは通常、タイプシステムによって防止されますが、`ManuallyDrop` のユーザーは、コンパイラの支援なしにこれらの保証を維持する必要があります。
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // 安全性: 可変参照が指す値を削除します
        // これは書き込みに有効であることが保証されています。
        // `slot` が再びドロップされないようにするのは、呼び出し元の責任です。
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}