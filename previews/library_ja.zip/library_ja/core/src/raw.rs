#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! コンパイラ組み込み型のレイアウトの構造体定義が含まれています。
//!
//! これらは、生の表現を直接操作するための安全でないコードの変換のターゲットとして使用できます。
//!
//!
//! それらの定義は、`rustc_middle::ty::layout` で定義されている ABI と常に一致する必要があります。
//!

/// `&dyn SomeTrait` のような trait オブジェクトの表現。
///
/// この構造体は、`&dyn SomeTrait` や `Box<dyn AnotherTrait>` などのタイプと同じレイアウトです。
///
/// `TraitObject` はレイアウトと一致することが保証されていますが、trait オブジェクトのタイプではありません (たとえば、フィールドは `&dyn SomeTrait` で直接アクセスできません)。また、そのレイアウトを制御しません (定義を変更しても `&dyn SomeTrait` のレイアウトは変更されません)。
///
/// これは、低レベルの詳細を操作する必要がある安全でないコードによってのみ使用されるように設計されています。
///
/// すべての trait オブジェクトを一般的に参照する方法はないため、このタイプの値を作成する唯一の方法は、[`std::mem::transmute`][transmute] などの関数を使用することです。
/// 同様に、`TraitObject` 値から真の trait オブジェクトを作成する唯一の方法は、`transmute` を使用することです。
///
/// [transmute]: crate::intrinsics::transmute
///
/// 型が一致しない trait オブジェクト (vtable がデータポインターが指す値の型に対応していないオブジェクト) を合成すると、未定義の動作が発生する可能性が高くなります。
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // 例 trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // コンパイラに trait オブジェクトを作成させます
/// let object: &dyn Foo = &value;
///
/// // 生の表現を見てください
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // データポインタは `value` のアドレスです
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` から `i32` vtable を使用するように注意しながら、別の `i32` を指す新しいオブジェクトを作成します
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // `other_value` から直接 trait オブジェクトを作成した場合と同じように機能するはずです。
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}