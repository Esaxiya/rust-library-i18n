// rust-memchr から取得した元の実装。
// Copyright 2015 Andrew Gallant、bluss and Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// 切り捨てを使用します。
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` にゼロバイトが含まれている場合は `true` を返します。
///
/// *Matters Computational* から、J。Arndt:
///
/// 「アイデアは、各バイトから 1 を減算してから、借用が最も重要なバイトにまで伝播したバイトを探すことです。
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` のバイト `x` に一致する最初のインデックスを返します。
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // 小さなスライスの高速パス
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // 一度に 2 つの `usize` ワードを読み取って、1 バイト値をスキャンします。
    //
    // `text` を 3 つの部分に分割
    // - テキストの最初の単語に位置合わせされたアドレスの前の、位置合わせされていない最初の部分
    // - 本体、一度に 2 ワードずつスキャン
    // - 最後の残りの部分、<2 ワードサイズ

    // 整列した境界まで検索
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // テキストの本文を検索する
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // 安全性: while の述語は、少なくとも 2 * usize_bytes の距離を保証します
        // オフセットとスライスの終わりの間。
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // 一致するバイトがある場合はブレーク
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ボディループが停止したポイントの後のバイトを見つけます。
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` のバイト `x` に一致する最後のインデックスを返します。
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // 一度に 2 つの `usize` ワードを読み取って、1 バイト値をスキャンします。
    //
    // `text` を 3 つの部分に分割します。
    // - テキスト内の最後の単語の整列されたアドレスの後の整列されていないテール、
    // - ボディ、一度に 2 ワードずつスキャン、
    // - 最初の残りのバイト、<2 ワードサイズ。
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // 接頭辞と接尾辞の長さを取得するためだけにこれを呼び出します。
        // 途中で、常に 2 つのチャンクを一度に処理します。
        // 安全性: `[u8]` から `[usize]` への変換は、`align_to` によって処理されるサイズの違いを除いて安全です。
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // テキストの本文を検索し、min_aligned_offset を超えないようにします。
    // オフセットは常に調整されるため、`>` をテストするだけで十分であり、オーバーフローの可能性を回避できます。
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // 安全性: オフセットは、それがより大きい限り、len、suffix.len() から始まります
        // min_aligned_offset (prefix.len()) 残りの距離は少なくとも 2 * chunk_bytes です。
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // 一致するバイトがある場合は中断します。
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ボディループが停止したポイントの前のバイトを見つけます。
    text[..offset].iter().rposition(|elt| *elt == x)
}