// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `mid` の要素が最初の要素になるように、範囲 `[mid-left, mid+right)` を回転します。同様に、範囲 `left` 要素を左に回転するか、`right` 要素を右に回転します。
///
/// # Safety
///
/// 指定された範囲は、読み取りと書き込みに有効である必要があります。
///
/// # Algorithm
///
/// アルゴリズム 1 は、`left + right` の値が小さい場合または `T` が大きい場合に使用されます。
/// 要素は、`mid - left` から開始し、`left + right` を法として `right` ステップで進むと、一度に 1 つずつ最終位置に移動するため、一時的な要素は 1 つだけ必要です。
/// 最終的に、`mid - left` に戻ります。
/// ただし、`gcd(left + right, right)` が 1 でない場合、上記の手順は要素をスキップします。
/// 例えば:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// 幸い、ファイナライズされた要素間でスキップされる要素の数は常に等しいので、開始位置をオフセットしてさらにラウンドを実行できます (ラウンドの総数は `gcd(left + right, right)` value) です)。
///
/// 最終的な結果として、すべての要素が 1 回だけファイナライズされます。
///
/// アルゴリズム 2 は、`left + right` が大きいが、`min(left, right)` がスタックバッファに収まるほど小さい場合に使用されます。
/// `min(left, right)` 要素がバッファにコピーされ、`memmove` が他の要素に適用され、バッファ上の要素が元の場所の反対側の穴に戻されます。
///
/// `left + right` が十分に大きくなると、ベクトル化できるアルゴリズムは上記よりも優れたパフォーマンスを発揮します。
/// アルゴリズム 1 は、一度に多数のラウンドをチャンク化して実行することでベクトル化できますが、`left + right` が巨大になるまで、平均してラウンドが少なすぎ、単一ラウンドの最悪のケースが常に存在します。
/// 代わりに、アルゴリズム 3 は、小さな回転の問題が残るまで、`min(left, right)` 要素の繰り返しスワッピングを利用します。
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` の場合、代わりに左からスワッピングが発生します。
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. これらのケースがチェックされていない場合、以下のアルゴリズムは失敗する可能性があります
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // アルゴリズム 1 マイクロベンチマークは、ランダムシフトの平均パフォーマンスが約 `left + right == 32` までずっと優れていることを示していますが、最悪の場合のパフォーマンスは約 16 でさえ壊れます。
            // 中間点として 24 が選ばれました。
            // `T` のサイズが 4`usize` より大きい場合、このアルゴリズムは他のアルゴリズムよりも優れています。
            //
            //
            let x = unsafe { mid.sub(left) };
            // 最初のラウンドの始まり
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` を計算することで事前に見つけることができますが、副作用として gcd を計算する 1 つのループを実行してから、残りのチャンクを実行する方が高速です。
            //
            //
            let mut gcd = right;
            // ベンチマークでは、一時的なものを 1 回読み取り、逆方向にコピーして、最後にその一時的なものを書き込むよりも、一時的なものを完全に交換する方が高速であることが明らかになっています。
            // これは、一時的なものを交換または置換するときに、2 つを管理する必要がなく、ループ内で 1 つのメモリアドレスのみを使用するという事実が原因である可能性があります。
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` をインクリメントしてから範囲外かどうかを確認する代わりに、次の増分で `i` が範囲外になるかどうかを確認します。
                // これにより、ポインタまたは `usize` の折り返しが防止されます。
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // 最初のラウンドの終わり
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` の場合、この条件はここにある必要があります
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // より多くのラウンドでチャンクを終了します
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ゼロサイズタイプではないので、サイズで割っても大丈夫です。
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // アルゴリズム 2 ここでの `[T; 0]` は、これが T に対して適切に調整されていることを確認するためのものです。
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // アルゴリズム 3 このアルゴリズムの最後のスワップがどこにあるかを見つけ、このアルゴリズムのように隣接するチャンクをスワップする代わりに、その最後のチャンクを使用してスワップする別のスワップ方法がありますが、この方法はさらに高速です。
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // アルゴリズム 3、 `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}