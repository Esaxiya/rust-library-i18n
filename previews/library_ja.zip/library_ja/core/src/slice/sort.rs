//! スライスソーティング
//!
//! このモジュールには、OrsonPeters のパターンを打ち負かすクイックソートに基づくソートアルゴリズムが含まれています。<https://github.com/orlp/pdqsort>
//!
//!
//! 不安定な並べ替えは、安定した並べ替えの実装とは異なり、メモリを割り当てないため、libcore と互換性があります。
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ドロップすると、`src` から `dest` にコピーします。
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // 安全性: これはヘルパークラスです。
        //          正確さについては、その使用法を参照してください。
        //          つまり、`src` と `dst` が `ptr::copy_nonoverlapping` で要求されているようにオーバーラップしないことを確認する必要があります。
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// それ以上の要素に遭遇するまで、最初の要素を右にシフトします。
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 安全性: 以下の安全でない操作には、境界チェックなしのインデックス作成が含まれます (`get_unchecked` および `get_unchecked_mut`)
    // メモリ (`ptr::copy_nonoverlapping`) をコピーします。
    //
    // a。インデックス作成:
    //  1. 配列のサイズを >=2 にチェックしました。
    //  2. 私たちが行うすべてのインデックス作成は、常に最大で {0 <= index < len} の間です。
    //
    // b。メモリコピー
    //  1. 有効であることが保証されている参照へのポインタを取得しています。
    //  2. スライスの差分インデックスへのポインタを取得するため、これらをオーバーラップさせることはできません。
    //     つまり、`i` と `i-1` です。
    //  3. スライスが適切に配置されている場合、要素は適切に配置されています。
    //     スライスが適切に配置されていることを確認するのは、呼び出し元の責任です。
    //
    // 詳細については、以下のコメントを参照してください。
    unsafe {
        // 最初の 2 つの要素が故障している場合...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // 最初の要素をスタックに割り当てられた変数に読み込みます。
            // 次の比較操作 panics の場合、`hole` はドロップされ、要素をスライスに自動的に書き戻します。
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // `i` 番目の要素を 1 つ左に移動して、穴を右に移動します。
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ドロップされるため、`tmp` を `v` の残りの穴にコピーします。
        }
    }
}

/// 小さいか等しい要素に遭遇するまで、最後の要素を左にシフトします。
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // 安全性: 以下の安全でない操作には、境界チェックなしのインデックス作成が含まれます (`get_unchecked` および `get_unchecked_mut`)
    // メモリ (`ptr::copy_nonoverlapping`) をコピーします。
    //
    // a。インデックス作成:
    //  1. 配列のサイズを >=2 にチェックしました。
    //  2. 私たちが行うすべてのインデックス作成は、常に最大で `0 <= index < len-1` の間です。
    //
    // b。メモリコピー
    //  1. 有効であることが保証されている参照へのポインタを取得しています。
    //  2. スライスの差分インデックスへのポインタを取得するため、これらをオーバーラップさせることはできません。
    //     つまり、`i` と `i+1` です。
    //  3. スライスが適切に配置されている場合、要素は適切に配置されています。
    //     スライスが適切に配置されていることを確認するのは、呼び出し元の責任です。
    //
    // 詳細については、以下のコメントを参照してください。
    unsafe {
        // 最後の 2 つの要素が故障している場合...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // 最後の要素をスタックに割り当てられた変数に読み込みます。
            // 次の比較操作 panics の場合、`hole` はドロップされ、要素をスライスに自動的に書き戻します。
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // `i` 番目の要素を 1 つ右に移動して、穴を左に移動します。
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ドロップされるため、`tmp` を `v` の残りの穴にコピーします。
        }
    }
}

/// いくつかの順不同の要素をシフトすることにより、スライスを部分的にソートします。
///
/// スライスが最後にソートされている場合は `true` を返します。この関数は *O*(*n*) 最悪の場合です。
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // シフトされる隣接する順序外のペアの最大数。
    const MAX_STEPS: usize = 5;
    // スライスがこれより短い場合は、要素をシフトしないでください。
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // 安全性: `i < len` を使用して境界チェックを明示的に実行しました。
        // 以降のすべてのインデックス作成は、`0 <= index < len` の範囲のみです。
        unsafe {
            // 隣接する順序が正しくない要素の次のペアを見つけます。
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // 終わりましたか?
        if i == len {
            return true;
        }

        // パフォーマンスコストがかかる短い配列で要素をシフトしないでください。
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // 見つかった要素のペアを交換します。これにより、それらが正しい順序になります。
        v.swap(i - 1, i);

        // 小さい方の要素を左にシフトします。
        shift_tail(&mut v[..i], is_less);
        // 大きい方の要素を右にシフトします。
        shift_head(&mut v[i..], is_less);
    }

    // 限られたステップ数でスライスを並べ替えることができませんでした。
    false
}

/// 挿入ソートを使用してスライスをソートします。これは、最悪の場合 *O*(*n*^ 2) です。
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ヒープソートを使用して `v` をソートします。これにより、*O*(*n*\*log(* n*)) の最悪の場合が保証されます。
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // このバイナリヒープは、不変の `parent >= child` を尊重します。
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` の子:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // 大きい子を選択してください。
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // 不変条件が `node` で保持される場合は停止します。
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` を大きい方の子と交換し、1 つ下に移動して、ふるいにかけ続けます。
            v.swap(node, greater);
            node = greater;
        }
    };

    // 線形時間でヒープを構築します。
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ヒープから最大の要素をポップします。
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` を `pivot` より小さい要素に分割し、その後に `pivot` 以上の要素を分割します。
///
///
/// `pivot` より小さい要素の数を返します。
///
/// 分割は、分岐操作のコストを最小限に抑えるために、ブロックごとに実行されます。
/// このアイデアは [BlockQuicksort][pdf] ペーパーで提示されています。
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // 典型的なブロック内の要素の数。
    const BLOCK: usize = 128;

    // パーティショニングアルゴリズムは、完了するまで次の手順を繰り返します。
    //
    // 1. 左側からブロックをトレースして、ピボット以上の要素を特定します。
    // 2. 右側からブロックをトレースして、ピボットよりも小さい要素を特定します。
    // 3. 識別された要素を左側と右側の間で交換します。
    //
    // 要素のブロックに対して次の変数を保持します。
    //
    // 1. `block` - ブロック内の要素の数。
    // 2. `start` - `offsets` 配列へのポインタを開始します。
    // 3. `end` - `offsets` 配列へのポインタを終了します。
    // 4. ` オフセット、ブロック内の順序が正しくない要素のインデックス。

    // 左側の現在のブロック (`l` から `l.add(block_l)`) まで)。
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // 右側の現在のブロック (`r.sub(block_r)` to `r`) から)。
    // 安全性: .add() のドキュメントには、`vec.as_ptr().add(vec.len())` は常に安全であると具体的に記載されています `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLA を取得したら、長さ `min(v.len()、2 * BLOCK) ` の配列を 1 つ作成してみてください。
    // 長さ `BLOCK` の 2 つの固定サイズ配列より。VLA の方がキャッシュ効率が高い可能性があります。

    // ポインタ `l` (inclusive) と `r` (exclusive) の間の要素数を返します。
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` と `r` が非常に近づくと、ブロックごとのパーティション分割が完了します。
        // 次に、残りの要素を間に分割するために、いくつかのパッチアップ作業を行います。
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // 残りの要素の数 (まだピボットと比較されていません)。
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // 左右のブロックが重ならないようにブロックサイズを調整しますが、残りのギャップ全体をカバーするように完全に位置合わせします。
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // 左側から `block_l` 要素をトレースします。
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // 安全性: 以下の安全でない操作には、`offset` の使用が含まれます。
                //         関数に必要な条件に従って、次の理由でそれらを満たします。
                //         1. `offsets_l` はスタックに割り当てられるため、個別に割り当てられたオブジェクトと見なされます。
                //         2. 関数 `is_less` は `bool` を返します。
                //            `bool` をキャストしても、`isize` がオーバーフローすることはありません。
                //         3. `block_l` が `<= BLOCK` になることを保証しました。
                //            さらに、`end_l` は当初、スタックで宣言された `offsets_` の開始ポインターに設定されていました。
                //            したがって、最悪の場合 (`is_less` のすべての呼び出しが false を返す) でも、最後を通過するのは最大で 1 バイトだけであることがわかります。
                //        ここでのもう 1 つの安全でない操作は、`elem` の逆参照です。
                //        ただし、`elem` は当初、常に有効なスライスへの開始ポインターでした。
                unsafe {
                    // ブランチレス比較。
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` 要素を右側からトレースします。
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // 安全性: 以下の安全でない操作には、`offset` の使用が含まれます。
                //         関数に必要な条件に従って、次の理由でそれらを満たします。
                //         1. `offsets_r` はスタックに割り当てられるため、個別に割り当てられたオブジェクトと見なされます。
                //         2. 関数 `is_less` は `bool` を返します。
                //            `bool` をキャストしても、`isize` がオーバーフローすることはありません。
                //         3. `block_r` が `<= BLOCK` になることを保証しました。
                //            さらに、`end_r` は当初、スタックで宣言された `offsets_` の開始ポインターに設定されていました。
                //            したがって、最悪の場合 (`is_less` のすべての呼び出しが true を返す) でも、最後を通過するのは最大で 1 バイトのみであることがわかります。
                //        ここでのもう 1 つの安全でない操作は、`elem` の逆参照です。
                //        ただし、`elem` は最初は終了を過ぎた `1 *sizeof(T)` であり、アクセスする前に `1* sizeof(T)` でデクリメントします。
                //        さらに、`block_r` は `BLOCK` 未満であると主張されたため、`elem` はせいぜいスライスの先頭を指します。
                unsafe {
                    // ブランチレス比較。
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // 左側と右側の間で交換する順序が正しくない要素の数。
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // 一度に 1 つのペアを交換する代わりに、巡回置換を実行する方が効率的です。
            // これは厳密にはスワッピングと同等ではありませんが、より少ないメモリ操作で同様の結果が得られます。
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // 左側のブロックのすべての異常な要素が移動されました。次のブロックに移動します。
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // 右側のブロックのすべての異常な要素が移動されました。前のブロックに移動します。
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // 現在残っているのは、移動する必要のある順序が正しくない要素を含む最大 1 つのブロック (左または右) だけです。
    // このような残りの要素は、ブロック内の最後に単純にシフトできます。
    //

    if start_l < end_l {
        // 左のブロックは残ります。
        // 残りの順不同の要素を右端に移動します。
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // 右のブロックは残ります。
        // 残りの順不同の要素を左端に移動します。
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // 他に何もすることはありません、私たちは終わりました。
        width(v.as_mut_ptr(), l)
    }
}

/// `v` を `v[pivot]` より小さい要素に分割し、その後に `v[pivot]` 以上の要素を分割します。
///
///
/// 次のタプルを返します。
///
/// 1. `v[pivot]` より小さい要素の数。
/// 2. `v` がすでにパーティション化されている場合は True。
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // ピボットをスライスの先頭に配置します。
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // 効率を上げるために、ピボットをスタックに割り当てられた変数に読み込みます。
        // 次の比較操作 panics の場合、ピボットは自動的にスライスに書き戻されます。
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // 順序が正しくない要素の最初のペアを見つけます。
        let mut l = 0;
        let mut r = v.len();

        // 安全性: 以下の安全性には、配列のインデックス作成が含まれます。
        // 最初のものについて: 私たちはすでに `l < r` でここで境界チェックを行っています。
        // 2 番目の場合: 最初は `l == 0` と `r == v.len()` があり、すべてのインデックス作成操作で `l < r` を確認しました。
        //                     ここから、`r` は少なくとも `r == l` である必要があり、最初のものから有効であることが示されていることがわかります。
        unsafe {
            // ピボット以上の最初の要素を見つけます。
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // ピボットよりも小さい最後の要素を見つけます。
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` スコープ外に出て、ピボット (スタックに割り当てられた変数) を元のスライスに書き戻します。
        // このステップは、安全を確保する上で重要です。
        //
    };

    // 2 つのパーティションの間にピボットを配置します。
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` を `v[pivot]` に等しい要素に分割し、その後に `v[pivot]` より大きい要素を続けます。
///
/// ピボットに等しい要素の数を返します。
/// `v` には、ピボットよりも小さい要素が含まれていないと想定されています。
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ピボットをスライスの先頭に配置します。
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // 効率を上げるために、ピボットをスタックに割り当てられた変数に読み込みます。
    // 次の比較操作 panics の場合、ピボットは自動的にスライスに書き戻されます。
    // 安全性: ここでのポインターは、スライスへの参照から取得されるため、有効です。
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // 次に、スライスを分割します。
    let mut l = 0;
    let mut r = v.len();
    loop {
        // 安全性: 以下の安全性には、配列のインデックス作成が含まれます。
        // 最初のものについて: 私たちはすでに `l < r` でここで境界チェックを行っています。
        // 2 番目の場合: 最初は `l == 0` と `r == v.len()` があり、すべてのインデックス作成操作で `l < r` を確認しました。
        //                     ここから、`r` は少なくとも `r == l` である必要があり、最初のものから有効であることが示されていることがわかります。
        unsafe {
            // ピボットよりも大きい最初の要素を見つけます。
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // ピボットに等しい最後の要素を見つけます。
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // 終わりましたか?
            if l >= r {
                break;
            }

            // 見つかった順序が正しくない要素のペアを交換します。
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // `l` 要素がピボットに等しいことがわかりました。ピボット自体を説明するために 1 を追加します。
    l + 1

    // `_pivot_guard` スコープ外に出て、ピボット (スタックに割り当てられた変数) を元のスライスに書き戻します。
    // このステップは、安全を確保する上で重要です。
}

/// クイックソートで不均衡なパーティションを引き起こす可能性のあるパターンを壊そうとして、いくつかの要素を分散させます。
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // GeorgeMarsaglia による "Xorshift RNGs" ペーパーからの疑似乱数ジェネレータ。
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // この数を法として乱数を取ります。
        // `len` は `isize::MAX` 以下であるため、数値は `usize` に収まります。
        let modulus = len.next_power_of_two();

        // 一部のピボット候補は、このインデックスの近くにあります。それらをランダム化しましょう。
        let pos = len / 4 * 2;

        for i in 0..3 {
            // `len` を法とする乱数を生成します。
            // ただし、コストのかかる操作を回避するために、最初に 2 の累乗を法として取り、次に `[0, len - 1]` の範囲に収まるまで `len` ずつ減らします。
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` 未満であることが保証されています。
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` でピボットを選択し、スライスがすでにソートされている可能性がある場合はインデックスと `true` を返します。
///
/// `v` の要素は、プロセス中に並べ替えられる場合があります。
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // 中央値の中央値法を選択するための最小の長さ。
    // 短いスライスは、単純な 3 の中央値の方法を使用します。
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // この関数で実行できるスワップの最大数。
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ピボットを選択する 3 つのインデックス。
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // インデックスの並べ替え中に実行しようとしているスワップの総数をカウントします。
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` になるようにインデックスを交換します。
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` になるようにインデックスを交換します。
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` の中央値を見つけ、インデックスを `a` に格納します。
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`、`b`、および `c` の近傍の中央値を見つけます。
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`、`b`、および `c` の中央値を見つけます。
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // スワップの最大数が実行されました。
        // スライスが下降しているか、ほとんどが下降している可能性があるため、逆にすると、おそらくより速くソートするのに役立ちます。
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` を再帰的にソートします。
///
/// スライスの元の配列に先行があった場合、`pred` として指定されます。
///
/// `limit` `heapsort` に切り替える前に許可される不均衡なパーティションの数です。
/// ゼロの場合、この関数はすぐにヒープソートに切り替わります。
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // この長さまでのスライスは、挿入ソートを使用してソートされます。
    const MAX_INSERTION: usize = 20;

    // 最後のパーティショニングが適度にバランスが取れていれば真です。
    let mut was_balanced = true;
    // 最後のパーティション分割で要素がシャッフルされなかった場合は True (スライスはすでにパーティション分割されています)。
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // 非常に短いスライスは、挿入ソートを使用してソートされます。
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // 悪いピボットの選択が多すぎる場合は、`O(n * log(n))` の最悪のケースを保証するために、ヒープソートにフォールバックするだけです。
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // 最後の分割が不均衡だった場合は、いくつかの要素をシャッフルしてスライスのパターンを壊してみてください。
        // 今回はより良いピボットを選択することを願っています。
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ピボットを選択し、スライスがすでにソートされているかどうかを推測してみてください。
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // 最後のパーティショニングが適切にバランスされ、要素をシャッフルしなかった場合、およびピボット選択でスライスがすでにソートされている可能性が高いと予測された場合...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // いくつかの異常な要素を特定し、それらを正しい位置にシフトしてみてください。
            // スライスが完全にソートされた場合は、完了です。
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // 選択したピボットが前のピボットと等しい場合、それはスライス内の最小の要素です。
        // スライスをピボットに等しい要素とピボットより大きい要素に分割します。
        // このケースは通常、スライスに多数の重複要素が含まれている場合に発生します。
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ピボットより大きい要素の並べ替えを続行します。
                v = &mut { v }[mid..];
                continue;
            }
        }

        // スライスを分割します。
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // スライスを `left`、`pivot`、および `right` に分割します。
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // 再帰呼び出しの総数を最小限に抑え、スタックスペースの消費を減らすために、短い側にのみ再帰します。
        // 次に、長い方の側を続行します (これは末尾再帰に似ています)。
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// パターンを無効にするクイックソートを使用して `v` をソートします。これは、*O*(*n*\*log(* n*)) の最悪の場合です。
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // サイズがゼロの型では、並べ替えは意味のある動作をしません。
    if mem::size_of::<T>() == 0 {
        return;
    }

    // 不均衡なパーティションの数を `floor(log2(len)) + 1` に制限します。
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // この長さまでのスライスの場合、単純に並べ替える方がおそらく高速です。
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ピボットを選択
        let (pivot, _) = choose_pivot(v, is_less);

        // 選択したピボットが前のピボットと等しい場合、それはスライス内の最小の要素です。
        // スライスをピボットに等しい要素とピボットより大きい要素に分割します。
        // このケースは通常、スライスに多数の重複要素が含まれている場合に発生します。
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // インデックスに合格した場合は、問題ありません。
                if mid > index {
                    return;
                }

                // それ以外の場合は、ピボットより大きい要素の並べ替えを続行します。
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // スライスを `left`、`pivot`、および `right` に分割します。
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // mid==index の場合、これで完了です。partition() は、mid 以降のすべての要素が mid 以上であることを保証しているためです。
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // サイズがゼロの型では、並べ替えは意味のある動作をしません。何もしない。
    } else if index == v.len() - 1 {
        // max 要素を見つけて、配列の最後の位置に配置します。
        // v が空であってはならないことがわかっているので、ここでは `unwrap()` を自由に使用できます。
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // min 要素を見つけて、配列の最初の位置に配置します。
        // v が空であってはならないことがわかっているので、ここでは `unwrap()` を自由に使用できます。
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}