//! `&[T]` および `&mut [T]` を作成するための無料の関数。

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// ポインタと長さからスライスを形成します。
///
/// `len` 引数は、バイト数ではなく、**要素** の数です。
///
/// # Safety
///
/// 次の条件のいずれかに違反した場合の動作は定義されていません。
///
/// * `data` `len * mem::size_of::<T>()` の多くのバイトを読み取るには、[valid] である必要があり、適切に配置されている必要があります。これは特に次のことを意味します。
///
///     * このスライスのメモリ範囲全体は、割り当てられた単一のオブジェクト内に含まれている必要があります。
///       スライスは、割り当てられた複数のオブジェクトにまたがることはできません。これを誤って考慮していない例については、[below](#incorrect-usage) を参照してください。
///     * `data` 長さがゼロのスライスの場合でも、null 以外で、整列されている必要があります。
///     この理由の 1 つは、列挙型レイアウトの最適化では、他のデータと区別するために、参照 (任意の長さのスライスを含む) が整列され、null 以外であることに依存する場合があるためです。
///     [`NonNull::dangling()`] を使用して、長さゼロのスライスの `data` として使用できるポインターを取得できます。
///
/// * `data` タイプ `T` の `len` 連続した適切に初期化された値を指している必要があります。
///
/// * 返されたスライスによって参照されるメモリは、`UnsafeCell` 内を除いて、`'a` の存続期間中は変更しないでください。
///
/// * スライスの合計サイズ `len * mem::size_of::<T>()` は `isize::MAX` 以下でなければなりません。
///   [`pointer::offset`] の安全文書を参照してください。
///
/// # Caveat
///
/// 返されたスライスの有効期間は、その使用状況から推測されます。
/// 偶発的な誤用を防ぐために、スライスのホスト値のライフタイムを取得するヘルパー関数を提供するか、明示的な注釈を付けるなどして、コンテキストで安全なソースライフタイムにライフタイムを関連付けることをお勧めします。
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // 単一の要素のスライスを明示する
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### 誤った使用法
///
/// 次の `join_slices` 関数は **不健全** です⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // 上記のアサーションは、`fst` と `snd` が連続していることを保証しますが、_different allocated objects_ 内に含まれている可能性があります。その場合、このスライスの作成は未定義の動作です。
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` と `b` は異なる割り当てられたオブジェクトです。
///     let a = 42;
///     let b = 27;
///     // ... それにもかかわらず、メモリ内に連続して配置される可能性があります。a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 安全性: 発信者は `from_raw_parts` の安全契約を守る必要があります。
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// 可変スライスが返されることを除いて、[`from_raw_parts`] と同じ機能を実行します。
///
/// # Safety
///
/// 次の条件のいずれかに違反した場合の動作は定義されていません。
///
/// * `data` `len * mem::size_of::<T>()` の多くのバイトの読み取りと書き込みの両方で [valid] である必要があり、適切に配置されている必要があります。これは特に次のことを意味します。
///
///     * このスライスのメモリ範囲全体は、割り当てられた単一のオブジェクト内に含まれている必要があります。
///       スライスは、割り当てられた複数のオブジェクトにまたがることはできません。
///     * `data` 長さがゼロのスライスの場合でも、null 以外で、整列されている必要があります。
///     この理由の 1 つは、列挙型レイアウトの最適化では、他のデータと区別するために、参照 (任意の長さのスライスを含む) が整列され、null 以外であることに依存する場合があるためです。
///
///     [`NonNull::dangling()`] を使用して、長さゼロのスライスの `data` として使用できるポインターを取得できます。
///
/// * `data` タイプ `T` の `len` 連続した適切に初期化された値を指している必要があります。
///
/// * 返されたスライスによって参照されるメモリは、存続期間 `'a` の間、他のポインタ (戻り値から派生していない) を介してアクセスしてはなりません。
///   読み取りアクセスと書き込みアクセスの両方が禁止されています。
///
/// * スライスの合計サイズ `len * mem::size_of::<T>()` は `isize::MAX` 以下でなければなりません。
///   [`pointer::offset`] の安全文書を参照してください。
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // 安全性: 発信者は `from_raw_parts_mut` の安全契約を守る必要があります。
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T への参照を長さ 1 のスライスに変換します (コピーなし)。
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T への参照を長さ 1 のスライスに変換します (コピーなし)。
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}