//! スライスのイテレータによって使用されるマクロ。

// is_empty と len をインライン化すると、パフォーマンスに大きな違いが生じます
macro_rules! is_empty {
    // ZST イテレータの長さをエンコードする方法で、これは ZST と非 ZST の両方で機能します。
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// いくつかの境界チェック (`position` を参照) を取り除くために、やや予想外の方法で長さを計算します。
// ( `codegen/lice-position-bounds-check` によってテストされています。)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // 安全でないブロック内で使用されることがあります

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // この _cannot_ は `unchecked_sub` を使用します。これは、長い ZST スライスイテレータの長さを表すためにラッピングに依存しているためです。
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end` は、署名付きで処理する必要がある `offset_from` よりも優れていることがわかっています。
            // ここで適切なフラグを設定することで、LLVM にこれを伝えることができ、境界チェックを削除するのに役立ちます。
            // 安全性: タイプ不変によって、 `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // また、ポインターが型サイズの正確な倍数だけ離れていることを LLVM に通知することで、`len() == 0` を `(end - start) < size` ではなく `start == end` まで最適化できます。
            //
            // 安全性: タイプ不変によって、ポインターは次のように整列されます。
            //         それらの間の距離は、尖ったサイズの倍数でなければなりません
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` および `IterMut` イテレータの共有定義
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // 最初の要素を返し、イテレータの開始を 1 だけ前方に移動します。
        // インライン関数と比較して、パフォーマンスが大幅に向上します。
        // イテレータは空であってはなりません。
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // 最後の要素を返し、イテレータの終わりを 1 だけ後方に移動します。
        // インライン関数と比較して、パフォーマンスが大幅に向上します。
        // イテレータは空であってはなりません。
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T が ZST の場合、イテレータの端を `n` だけ後方に移動して、イテレータを縮小します。
        // `n` `self.len()` を超えてはなりません。
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // イテレータからスライスを作成するためのヘルパー関数。
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // 安全性: イテレータはポインタ付きのスライスから作成されました
                // `self.ptr` と長さ `len!(self)`。
                // これにより、`from_raw_parts` のすべての前提条件が満たされることが保証されます。
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // イテレータの開始を `offset` 要素だけ前方に移動し、古い開始を返すためのヘルパー関数。
            //
            // オフセットは `self.len()` を超えてはならないため、安全ではありません。
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // 安全性: 発信者は、`offset` が `self.len()` を超えないことを保証します。
                    // したがって、この新しいポインタは `self` 内にあるため、null 以外であることが保証されます。
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // イテレータの終わりを `offset` 要素だけ後方に移動し、新しい終わりを返すためのヘルパー関数。
            //
            // オフセットは `self.len()` を超えてはならないため、安全ではありません。
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // 安全性: 発信者は、`offset` が `self.len()` を超えないことを保証します。
                    // `isize` をオーバーフローさせないことが保証されています。
                    // また、結果のポインターは `slice` の範囲内にあり、`offset` の他の要件を満たしています。
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // スライスを使用して実装できますが、これにより境界チェックが回避されます

                // 安全性: スライスの開始ポインターなので、`assume` 呼び出しは安全です
                // null 以外である必要があり、ZST 以外のスライスにも null 以外の終了ポインターが必要です。
                // 最初にイテレータが空かどうかを確認するため、`next_unchecked!` の呼び出しは安全です。
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // このイテレータは空になりました。
                    if mem::size_of::<T>() == 0 {
                        // `ptr` が 0 になることはないかもしれないが、`end` は (ラッピングのために) 0 になる可能性があるため、この方法で行う必要があります。
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // 安全性: ptr が 0 ではなく、end>=ptr であるため、T が ZST でない場合、end を 0 にすることはできません。
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // 安全性: 私たちは限界にあります。`post_inc_start` は、ZST に対しても正しいことを行います。
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            // また、`assume` は境界チェックを回避します。
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // 安全性: ループ不変条件によって範囲内にあることが保証されます:
                        // `i >= n` の場合、`self.next()` は `None` を返し、ループが中断します。
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` を使用するデフォルトの実装をオーバーライドします。これは、この単純な実装では LLVM IR の生成が少なく、コンパイルが高速であるためです。
            // また、`assume` は境界チェックを回避します。
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // 安全性: `i` は `n` から始まるため、`n` よりも低くする必要があります
                        // 減少しているだけです。
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // 安全性: 発信者は、`i` が次の範囲内にあることを保証する必要があります
                // 基になるスライスであるため、`i` は `isize` をオーバーフローできず、返される参照はスライスの要素を参照することが保証されているため、有効であることが保証されます。
                //
                // また、呼び出し元は、同じインデックスで二度と呼び出されないこと、およびこのサブスライスにアクセスする他のメソッドが呼び出されないことも保証するため、返された参照が次の場合に変更可能であることが有効であることに注意してください。
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // スライスを使用して実装できますが、これにより境界チェックが回避されます

                // 安全性: スライスの開始ポインターは null 以外でなければならないため、`assume` 呼び出しは安全です。
                // また、非 ZST 上のスライスにも、null 以外の終了ポインターが必要です。
                // 最初にイテレータが空かどうかを確認するため、`next_back_unchecked!` の呼び出しは安全です。
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // このイテレータは空になりました。
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // 安全性: 私たちは限界にあります。`pre_dec_end` は、ZST に対しても正しいことを行います。
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}