//! ASCII `[u8]` での操作。

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// このスライスのすべてのバイトが ASCII 範囲内にあるかどうかを確認します。
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// 2 つのスライスが ASCII の大文字と小文字を区別しない一致であることを確認します。
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` と同じですが、一時的なものを割り当てたりコピーしたりする必要はありません。
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// このスライスを ASCII 大文字に相当するインプレースに変換します。
    ///
    /// ASCII 文字 'a' から 'z' は 'A' から 'Z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// 既存の値を変更せずに新しい大文字の値を返すには、[`to_ascii_uppercase`] を使用します。
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// このスライスを ASCII 小文字の同等のインプレースに変換します。
    ///
    /// ASCII 文字 'A' から 'Z' は 'a' から 'z' にマップされますが、非 ASCII 文字は変更されません。
    ///
    /// 既存の値を変更せずに新しい小文字の値を返すには、[`to_ascii_lowercase`] を使用します。
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// ワード `v` のいずれかのバイトが nonascii (>=128) の場合、`true` を返します。
/// utf8 検証と同様のことを行う `../str/mod.rs` から Snarfed。
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// バイトアットアタイム操作の代わりに usize-at-a-time 操作を使用する最適化された ASCII テスト (可能な場合)。
///
/// ここで使用するアルゴリズムは非常に単純です。`s` が短すぎる場合は、各バイトをチェックして処理を完了します。さもないと:
///
/// - 負荷が調整されていない最初の単語を読みます。
/// - ポインターを整列させ、整列された負荷で終了するまで後続の単語を読み取ります。
/// - 負荷が調整されていない `s` から最後の `usize` を読み取ります。
///
/// これらの負荷のいずれかが `contains_nonascii` (above) が true を返すものを生成する場合、答えは false であることがわかります。
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // 一度に 1 ワードずつ実装しても何も得られない場合は、スカラーループにフォールバックします。
    //
    // これは、奇妙な edge の場合であるため、`size_of::<usize>()` が `usize` に対して十分な配置ではないアーキテクチャに対しても行います。
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // 私たちは常に最初の単語を整列せずに読みます。つまり、`align_offset` は
    // 0、整列された読み取りに対して同じ値を再度読み取ります。
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // 安全性: 上記の `len < USIZE_SIZE` を確認します。
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // やや暗黙のうちに、上記でこれを確認しました。
    // `offset_to_aligned` は `align_offset` または `USIZE_SIZE` のいずれかであり、両方とも上記で明示的にチェックされていることに注意してください。
    //
    debug_assert!(offset_to_aligned <= len);

    // 安全性: word_ptr は、(適切に配置された) usize ptr であり、
    // スライスの中央のチャンク。
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` のバイトインデックスであり、ループ終了チェックに使用されます。
    let mut byte_pos = offset_to_aligned;

    // パラノイアは、整列されていない負荷をたくさん実行しようとしているので、整列についてチェックします。
    // ただし、実際には、`align_offset` のバグがなければ、これは不可能です。
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // テールチェックで後で行われる最後に整列された単語自体を除いて、最後に整列された単語まで後続の単語を読み取り、テールが常に最大で 1 つの `usize` から余分な branch `byte_pos == len` になるようにします。
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // 読み取りが範囲内にあることの健全性チェック
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // そして、`byte_pos` に関する私たちの仮定が成り立つこと。
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // 安全性: `word_ptr` が適切に調整されていることがわかっています (
        // `align_offset`)、`word_ptr` と最後の間に十分なバイトがあることがわかっています
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // 安全性: `byte_pos <= len - USIZE_SIZE` は、つまり
        // この `add` の後、`word_ptr` はせいぜい過去 1 つになります。
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // `usize` が実際に 1 つだけ残っていることを確認するための健全性チェック。
    // これは、ループ条件によって保証されます。
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // 安全性: これは、最初にチェックする `len >= USIZE_SIZE` に依存しています。
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}