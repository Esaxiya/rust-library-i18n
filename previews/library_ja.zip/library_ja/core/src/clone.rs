//! ' 暗黙的にコピーできない ' タイプの `Clone` trait。
//!
//! Rust では、いくつかの単純なタイプは "implicitly copyable" であり、それらを割り当てるか、引数として渡すと、レシーバーはコピーを取得し、元の値をそのまま残します。
//! これらのタイプは、コピーするための割り当てを必要とせず、ファイナライザーもありません (つまり、所有ボックスが含まれていないか、[`Drop`] を実装していません)。したがって、コンパイラーは、それらを安価で安全にコピーできると見なします。
//!
//! 他のタイプの場合は、慣例により [`Clone`] trait を実装し、[`clone`] メソッドを呼び出すことにより、コピーを明示的に作成する必要があります。
//!
//! [`clone`]: Clone::clone
//!
//! 基本的な使用例:
//!
//! ```
//! let s = String::new(); // 文字列型はクローンを実装します
//! let copy = s.clone(); // クローンを作成できます
//! ```
//!
//! クローン trait を簡単に実装するために、`#[derive(Clone)]` を使用することもできます。例:
//!
//! ```
//! #[derive(Clone)] // クローン trait を Morpheus 構造に追加します
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // そして今、私たちはそれを複製することができます!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// オブジェクトを明示的に複製する機能の一般的な trait。
///
/// [`Copy`] は暗黙的で非常に安価であるという点で、[`Copy`] とは異なりますが、`Clone` は常に明示的であり、高価な場合とそうでない場合があります。
/// これらの特性を強制するために、Rust では [`Copy`] を再実装することはできませんが、`Clone` を再実装して任意のコードを実行することはできます。
///
/// `Clone` は [`Copy`] よりも一般的であるため、[`Copy`] を `Clone` にすることもできます。
///
/// ## Derivable
///
/// この trait は、すべてのフィールドが `Clone` の場合、`#[derive]` で使用できます。[`Clone`] の「派生」実装は、各フィールドで [`clone`] を呼び出します。
///
/// [`clone`]: Clone::clone
///
/// ジェネリック構造体の場合、`#[derive]` は、ジェネリックパラメーターにバインドされた `Clone` を追加することにより、条件付きで `Clone` を実装します。
///
/// ```
/// // `derive` 読書のためのクローンを実装します <T>T がクローンの場合。
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## `Clone` を実装するにはどうすればよいですか?
///
/// [`Copy`] であるタイプには、`Clone` の簡単な実装が必要です。より正式には:
/// `T: Copy`、`x: T`、および `y: &T` の場合、`let x = y.clone();` は `let x = *y;` と同等です。
/// 手動実装では、この不変条件を維持するように注意する必要があります。ただし、安全でないコードは、メモリの安全性を確保するためにそれに依存してはなりません。
///
/// 例として、関数ポインターを保持する汎用構造体があります。この場合、`Clone` の実装を「派生」させることはできませんが、次のように実装できます。
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## 追加の実装者
///
/// [implementors listed below][impls] に加えて、次のタイプも `Clone` を実装します。
///
/// * 関数アイテムタイプ (つまり、関数ごとに定義された個別のタイプ)
/// * 関数ポインタ型 (例: `fn() -> i32`)
/// * アイテムタイプが `Clone` (`[i32; 123456]` など) も実装している場合の、すべてのサイズの配列タイプ
/// * 各コンポーネントが `Clone` (`()`、`(i32, bool)` など) も実装している場合のタプルタイプ
/// * クロージャータイプ。環境から値をキャプチャしない場合、またはキャプチャされたすべての値が `Clone` 自体を実装する場合。
///   共有参照によってキャプチャされた変数は常に `Clone` を実装しますが (参照元が実装していない場合でも)、可変参照によってキャプチャされた変数は `Clone` を実装しないことに注意してください。
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// 値のコピーを返します。
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str クローンを実装します
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` からコピー割り当てを実行します。
    ///
    /// `a.clone_from(&b)` 機能的には `a = b.clone()` と同等ですが、オーバーライドして `a` のリソースを再利用し、不要な割り当てを回避できます。
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` の実装を生成するマクロを導出します。
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): これらの構造体は、型のすべてのコンポーネントがクローンまたはコピーを実装していることを表明するために、#[derive] によってのみ使用されます。
//
//
// これらの構造体は、ユーザーコードに表示されるべきではありません。
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// プリミティブ型の `Clone` の実装。
///
/// Rust で記述できない実装は、`rustc_trait_selection` の `traits::SelectionContext::copy_clone_conditions()` で実装されます。
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 共有参照は複製できますが、可変参照は *できません*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// 共有参照は複製できますが、可変参照は *できません*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}