//! 共有可能な可変コンテナ。
//!
//! Rust のメモリ安全性は、次のルールに基づいています。オブジェクト `T` が与えられた場合、次のいずれかのみが可能です。
//!
//! - オブジェクトへの (`&T`) への不変の参照がいくつかあります (**エイリアシング** とも呼ばれます)。
//! - オブジェクトへの 1 つの可変参照 ( `＆mut T`) (**可変性** とも呼ばれます) を持つ。
//!
//! これは、Rust コンパイラーによって実施されます。ただし、このルールが十分に柔軟でない場合があります。オブジェクトへの複数の参照が必要な場合がありますが、それを変更する必要があります。
//!
//! 共有可能な可変コンテナは、エイリアシングが存在する場合でも、制御された方法で可変性を可能にするために存在します。[`Cell<T>`] と [`RefCell<T>`] はどちらも、シングルスレッドの方法でこれを行うことができます。
//! ただし、`Cell<T>` も `RefCell<T>` もスレッドセーフではありません ([`Sync`] を実装していません)。
//! 複数のスレッド間でエイリアスとミューテーションを行う必要がある場合は、[`Mutex<T>`]、[`RwLock<T>`]、または [`atomic`] タイプを使用できます。
//!
//! `Cell<T>` および `RefCell<T>` タイプの値は、共有参照を介して変更できます (つまり、
//! 一般的な `&T` タイプ)、ほとんどの Rust タイプは、一意の ( `＆mut T`) 参照を介してのみ変更できます。
//! `Cell<T>` と `RefCell<T>` は、「継承された可変性」を示す典型的な Rust タイプとは対照的に、「内部可変性」を提供すると言います。
//!
//! セルタイプには、`Cell<T>` と `RefCell<T>` の 2 つのフレーバーがあります。`Cell<T>` は、値を `Cell<T>` に出し入れすることにより、内部の可変性を実装します。
//! 値の代わりに参照を使用するには、`RefCell<T>` タイプを使用して、変更する前に書き込みロックを取得する必要があります。`Cell<T>` は、現在の内部値を取得および変更するためのメソッドを提供します。
//!
//!  - [`Copy`] を実装する型の場合、[`get`](Cell::get) メソッドは現在の内部値を取得します。
//!  - [`Default`] を実装するタイプの場合、[`take`](Cell::take) メソッドは現在の内部値を [`Default::default()`] に置き換え、置き換えられた値を返します。
//!  - すべてのタイプで、[`replace`](Cell::replace) メソッドは現在の内部値を置き換えて置き換えられた値を返し、[`into_inner`](Cell::into_inner) メソッドは `Cell<T>` を消費して内部値を返します。
//!  さらに、[`set`](Cell::set) メソッドは内部値を置き換え、置き換えられた値を削除します。
//!
//! `RefCell<T>` Rust のライフタイムを使用して、「動的借用」を実装します。これは、内部値への一時的、排他的、変更可能なアクセスを要求できるプロセスです。
//! `RefCell の借用 <T> コンパイル時に完全に静的に追跡される Rust のネイティブ参照型とは異なり、「s は実行時に」追跡されます。
//! `RefCell<T>` の借用は動的であるため、すでに可変的に借用されている値の借用を試みることができます。これが発生すると、スレッド panic になります。
//!
//! # 内部の可変性を選択するタイミング
//!
//! 値を変更するために一意のアクセス権が必要な、より一般的な継承された変更可能性は、Rust がポインターのエイリアスについて強く推論し、クラッシュバグを静的に防止できるようにする主要な言語要素の 1 つです。
//! そのため、継承された可変性が優先され、内部の可変性は最後の手段のようなものです。
//! 細胞型は、他の方法では許可されない突然変異を可能にするため、内部の突然変異性が適切である場合や、使用する必要がある場合もあります。
//!
//! * 不変のものの可変性 'inside' の紹介
//! * 論理的に不変のメソッドの実装の詳細。
//! * [`Clone`] の実装の変更。
//!
//! ## 不変のものの可変性 'inside' の紹介
//!
//! [`Rc<T>`] や [`Arc<T>`] を含む多くの共有スマートポインタータイプは、クローンを作成して複数の関係者間で共有できるコンテナーを提供します。
//! 含まれている値は多重エイリアス化される可能性があるため、`&mut` ではなく `&` でのみ借用できます。
//! セルがなければ、これらのスマートポインター内のデータを変更することはまったく不可能です。
//!
//! `RefCell<T>` を共有ポインタ型の中に入れて可変性を再導入することは非常に一般的です。
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // 新しいブロックを作成して、動的借用の範囲を制限します
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // キャッシュの以前の借用をスコープから外さなかった場合、後続の借用により動的スレッド panic が発生することに注意してください。
//!     //
//!     // これは、`RefCell` を使用することの主な危険です。
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! この例では、`Arc<T>` ではなく `Rc<T>` を使用していることに注意してください。`RefCell<T>` はシングルスレッドシナリオ用です。マルチスレッドの状況で共有の可変性が必要な場合は、[`RwLock<T>`] または [`Mutex<T>`] の使用を検討してください。
//!
//! ## 論理的に不変のメソッドの実装の詳細
//!
//! "under the hood" で発生しているミューテーションがあることを API で公開しないことが望ましい場合があります。
//! これは、論理的には操作が不変であることが原因である可能性がありますが、たとえば、キャッシュによって実装に変更が強制されます。または、元々`&self` を取るように定義された trait メソッドを実装するには、ミューテーションを使用する必要があるためです。
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // 高価な計算はここに行きます
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` の実装の変更
//!
//! これは単に特別ですが、前の一般的なケースです。不変に見える操作の可変性を非表示にします。
//! [`clone`](Clone::clone) メソッドはソース値を変更しないことが期待されており、`&mut self` ではなく `&self` を取るように宣言されています。
//! したがって、`clone` メソッドで発生する突然変異は、セルタイプを使用する必要があります。
//! たとえば、[`Rc<T>`] はその参照カウントを `Cell<T>` 内に維持します。
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// 可変メモリ位置。
///
/// # Examples
///
/// この例では、`Cell<T>` が不変の構造体内でミューテーションを有効にしていることがわかります。
/// つまり、"interior mutability" を有効にします。
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // エラー: `my_struct` は不変です
/// // my_struct.regular_field =new_value;
///
/// // 動作: `my_struct` は不変ですが、`special_field` は `Cell` であり、
/// // いつでも変更できます
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T の `Default` 値を使用して `Cell<T>` を作成します。
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// 指定された値を含む新しい `Cell` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// 含まれる値を設定します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// 2 つのセルの値を交換します。
    /// `std::mem::swap` との違いは、この関数が `&mut` 参照を必要としないことです。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // 安全性: これは、別々のスレッドから呼び出された場合はリスクを伴う可能性がありますが、`Cell`
        // `!Sync` なので、これは起こりません。
        // `Cell` は、これらの `Cell` のいずれかを指しているものが他にないことを確認するため、これによってポインターが無効になることもありません。
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// 含まれている値を `val` に置き換え、古い含まれている値を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // 安全性: これにより、別のスレッドから呼び出された場合にデータの競合が発生する可能性があります。
        // ただし、`Cell` は `!Sync` であるため、これは発生しません。
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// 値をアンラップします。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// 含まれている値のコピーを返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // 安全性: これにより、別のスレッドから呼び出された場合にデータの競合が発生する可能性があります。
        // ただし、`Cell` は `!Sync` であるため、これは発生しません。
        unsafe { *self.value.get() }
    }

    /// 関数を使用して含まれている値を更新し、新しい値を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// このセルの基になるデータへの生のポインタを返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 基になるデータへの可変参照を返します。
    ///
    /// この呼び出しは、`Cell` を (コンパイル時に) 可変的に借用します。これにより、唯一の参照を所有することが保証されます。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T` から `&Cell<T>` を返します
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // 安全性: `&mut` は独自のアクセスを保証します。
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// セルの値を取得し、`Default::default()` をその場所に残します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>` から `&[Cell<T>]` を返します
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // 安全性: `Cell<T>` のメモリレイアウトは `T` と同じです。
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// 動的にチェックされた借用ルールを持つ可変メモリ位置
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] によって返されたエラー。
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] によって返されたエラー。
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// 正の値は、アクティブな `Ref` の数を表します。負の値は、アクティブな `RefMut` の数を表します。
// 複数の `RefMut` は、`RefCell` の重複しない別個のコンポーネント (たとえば、スライスの異なる範囲) を参照する場合にのみ、一度にアクティブにできます。
//
// `Ref` と `RefMut` はどちらもサイズが 2 ワードであるため、`usize` 範囲の半分をオーバーフローするのに十分な `Ref` または `RefMut` が存在することはおそらくありません。
// したがって、`BorrowFlag` はおそらくオーバーフローまたはアンダーフローすることはありません。
// ただし、病理学的プログラムが mem::forget `Ref` または `RefMut` を繰り返し作成してから作成する可能性があるため、これは保証ではありません。
// したがって、すべてのコードは、安全性を回避するためにオーバーフローとアンダーフローを明示的にチェックするか、少なくともオーバーフローまたはアンダーフローが発生した場合に正しく動作する必要があります (たとえば、BorrowRef::new を参照)。
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` を含む新しい `RefCell` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` を消費し、ラップされた値を返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // この関数は値で `self` (`RefCell`) を受け取るため、コンパイラーは静的にそれが現在借用されていないことを確認します。
        //
        self.value.into_inner()
    }

    /// ラップされた値を新しい値に置き換え、どちらも初期化を解除せずに古い値を返します。
    ///
    ///
    /// この関数は [`std::mem::replace`](../mem/fn.replace.html) に対応します。
    ///
    /// # Panics
    ///
    /// 値が現在借用されている場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ラップされた値を `f` から計算された新しい値に置き換え、どちらも初期化を解除せずに古い値を返します。
    ///
    ///
    /// # Panics
    ///
    /// 値が現在借用されている場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` のラップされた値を `other` のラップされた値と交換しますが、どちらも初期化を解除しません。
    ///
    ///
    /// この関数は [`std::mem::swap`](../mem/fn.swap.html) に対応します。
    ///
    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ラップされた値を不変に借用します。
    ///
    /// 借用は、返された `Ref` がスコープを終了するまで続きます。
    /// 複数の不変の借用を同時に行うことができます。
    ///
    /// # Panics
    ///
    /// 値が現在可変的に借用されている場合は Panics。
    /// パニックにならないバリアントの場合は、[`try_borrow`](#method.try_borrow) を使用します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic の例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// ラップされた値を不変に借用し、値が現在可変的に借用されている場合はエラーを返します。
    ///
    ///
    /// 借用は、返された `Ref` がスコープを終了するまで続きます。
    /// 複数の不変の借用を同時に行うことができます。
    ///
    /// これは、[`borrow`](#method.borrow) のパニックにならないバリアントです。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // 安全性: `BorrowRef` は、不変のアクセスのみが存在することを保証します
            // 借りている間の価値に。
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// ラップされた値を可変的に借用します。
    ///
    /// 借用は、返された `RefMut` またはそれから派生したすべての `RefMut` がスコープを終了するまで続きます。
    ///
    /// この借用がアクティブな間は、値を借用することはできません。
    ///
    /// # Panics
    ///
    /// 値が現在借用されている場合は Panics。
    /// パニックにならないバリアントの場合は、[`try_borrow_mut`](#method.try_borrow_mut) を使用します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic の例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// ラップされた値を可変的に借用し、値が現在借用されている場合はエラーを返します。
    ///
    ///
    /// 借用は、返された `RefMut` またはそれから派生したすべての `RefMut` がスコープを終了するまで続きます。
    /// この借用がアクティブな間は、値を借用することはできません。
    ///
    /// これは、[`borrow_mut`](#method.borrow_mut) のパニックにならないバリアントです。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // 安全性: `BorrowRef` は独自のアクセスを保証します。
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// このセルの基になるデータへの生のポインタを返します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 基になるデータへの可変参照を返します。
    ///
    /// この呼び出しは `RefCell` を (コンパイル時に) 可変的に借用するため、動的チェックは必要ありません。
    ///
    /// ただし、注意が必要です。このメソッドでは、`self` が可変であることが想定されていますが、`RefCell` を使用する場合は通常そうではありません。
    ///
    /// `self` が変更可能でない場合は、代わりに [`borrow_mut`] メソッドを確認してください。
    ///
    /// また、この方法は特別な状況のためだけであり、通常はあなたが望むものではないことに注意してください。
    /// 疑わしい場合は、代わりに [`borrow_mut`] を使用してください。
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` の借用状態に対するリークされたガードの影響を元に戻します。
    ///
    /// この呼び出しは [`get_mut`] に似ていますが、より専門的です。
    /// `RefCell` を可変的に借用して借用が存在しないことを確認してから、共有借用を追跡する状態をリセットします。
    /// これは、一部の `Ref` または `RefMut` の借用がリークされた場合に関連します。
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// ラップされた値を不変に借用し、値が現在可変的に借用されている場合はエラーを返します。
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` とは異なり、このメソッドは `Ref` を返さないため安全ではなく、借用フラグは変更されません。
    /// このメソッドによって返される参照が生きている間に `RefCell` を可変的に借用することは、未定義の動作です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // 安全性: 現在、誰も積極的に執筆していないことを確認していますが、
            // 返された参照が使用されなくなるまで誰も書き込みを行わないようにする呼び出し元の責任。
            // また、`self.value.get()` は、`self` が所有する値を参照するため、`self` の存続期間中有効であることが保証されます。
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// ラップされた値を取得し、`Default::default()` をその場所に残します。
    ///
    /// # Panics
    ///
    /// 値が現在借用されている場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// 値が現在可変的に借用されている場合は Panics。
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T の `Default` 値を使用して `RefCell<T>` を作成します。
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// いずれかの `RefCell` の値が現在借用されている場合は、Panics。
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // 次の場合、借用を増やすと、非読み取り値 (<=0) になる可能性があります。
            // 1. 0 未満でした。つまり、書き込みボローがあるため、Rust の参照エイリアシングルールのために読み取りボローを許可できません。
            // 2.
            // それは isize::MAX (読み取りボローの最大量) であり、isize::MIN (書き込みボローの最大量) にオーバーフローしたため、isize はそれほど多くの読み取りボローを表すことができないため、追加の読み取りボローを許可できません (これは次の場合にのみ発生する可能性があります) mem::forget が一定量の `Ref` を超える場合、これは適切な方法ではありません)
            //
            //
            //
            //
            None
        } else {
            // 次の場合、借用を増やすと、読み取り値 (> 0) になる可能性があります。
            // 1. =0 でした。つまり、借用されておらず、最初の読み取り借用を行っています。
            // 2. それは > 0 かつ < isize::MAX でした、すなわち
            // 読み取り借用があり、isize はもう 1 つの読み取り借用があることを表すのに十分な大きさです
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // この参照が存在するため、借用フラグが読み取り借用であることがわかります。
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ボローカウンターが書き込みボローにオーバーフローするのを防ぎます。
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// 借用した参照を `RefCell` ボックスの値にラップします。
/// `RefCell<T>` から不変に借用された値のラッパータイプ。
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` をコピーします。
    ///
    /// `RefCell` はすでに不変に借用されているため、これが失敗することはありません。
    ///
    /// これは、`Ref::clone(...)` として使用する必要がある関連関数です。
    /// `Clone` の実装またはメソッドは、`RefCell` のコンテンツを複製するための `r.borrow().clone()` の広範な使用を妨害します。
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// 借用したデータのコンポーネント用に新しい `Ref` を作成します。
    ///
    /// `RefCell` はすでに不変に借用されているため、これが失敗することはありません。
    ///
    /// これは、`Ref::map(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// 借用データのオプションコンポーネント用に新しい `Ref` を作成します。
    /// クロージャーが `None` を返す場合、元のガードは `Err(..)` として返されます。
    ///
    /// `RefCell` はすでに不変に借用されているため、これが失敗することはありません。
    ///
    /// これは、`Ref::filter_map(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// `Ref` を、借用したデータのさまざまなコンポーネントの複数の「参照」に分割します。
    ///
    /// `RefCell` はすでに不変に借用されているため、これが失敗することはありません。
    ///
    /// これは、`Ref::map_split(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// 基になるデータへの参照に変換します。
    ///
    /// 基盤となる `RefCell` は、二度と変更可能に借用することはできず、常に不変に借用されているように見えます。
    ///
    /// 一定数以上の参照をリークすることはお勧めできません。
    /// 合計で発生したリークの数が少ない場合は、`RefCell` を不変に再度借りることができます。
    ///
    /// これは、`Ref::leak(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // この Ref を忘れることで、RefCell の借用カウンターが `'b` の有効期間内に UNUSED に戻らないようにします。
        // 参照追跡状態をリセットするには、借用した RefCell への一意の参照が必要になります。
        // 元のセルからこれ以上変更可能な参照を作成することはできません。
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// 借用データのコンポーネント (列挙型バリアントなど) の新しい `RefMut` を作成します。
    ///
    /// `RefCell` はすでに可変的に借用されているため、これが失敗することはありません。
    ///
    /// これは、`RefMut::map(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): 借用チェックを修正
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// 借用データのオプションコンポーネント用に新しい `RefMut` を作成します。
    /// クロージャーが `None` を返す場合、元のガードは `Err(..)` として返されます。
    ///
    /// `RefCell` はすでに可変的に借用されているため、これが失敗することはありません。
    ///
    /// これは、`RefMut::filter_map(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): 借用チェックを修正
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // 安全性: 関数は、その期間中、排他的な参照を保持します
        // `orig` を介した呼び出しの場合、ポインターは関数呼び出し内でのみ逆参照され、排他参照をエスケープすることはできません。
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // 安全性: 上記と同じ。
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// 借用したデータのさまざまなコンポーネントに対して、`RefMut` を複数の `RefMut` に分割します。
    ///
    /// 基になる `RefCell` は、返された両方の `RefMut` がスコープ外になるまで、変更可能に借用されたままになります。
    ///
    /// `RefCell` はすでに可変的に借用されているため、これが失敗することはありません。
    ///
    /// これは、`RefMut::map_split(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// 基になるデータへの可変参照に変換します。
    ///
    /// 基になる `RefCell` は再度借用することはできず、常に可変的に借用されているように見え、返された参照は内部のみになります。
    ///
    ///
    /// これは、`RefMut::leak(...)` として使用する必要がある関連関数です。
    /// メソッドは、`Deref` を介して使用される `RefCell` のコンテンツで同じ名前のメソッドに干渉します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // この BorrowRefMut を忘れることで、RefCell の借用カウンターが `'b` の有効期間内に UNUSED に戻らないようにします。
        // 参照追跡状態をリセットするには、借用した RefCell への一意の参照が必要になります。
        // その存続期間内に元のセルからそれ以上の参照を作成することはできず、現在の借用が残りの存続期間の唯一の参照になります。
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone とは異なり、イニシャルを作成するために new が呼び出されます
        // 可変参照であるため、現在、既存の参照があってはなりません。
        // したがって、clone は可変 refcount をインクリメントしますが、ここでは明示的に UNUSED から UNUSED への移行のみを許可します 1。
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` のクローンを作成します。
    //
    // これは、各 `BorrowRefMut` を使用して、元のオブジェクトの重複しない個別の範囲への可変参照を追跡する場合にのみ有効です。
    //
    // これは Cloneimpl にはないため、コードはこれを暗黙的に呼び出しません。
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // ボローカウンターがアンダーフローしないようにします。
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` から可変的に借用された値のラッパータイプ。
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust の内部可変性のコアプリミティブ。
///
/// 参照 `&T` がある場合、通常、Rust では、コンパイラは `&T` が不変のデータを指しているという知識に基づいて最適化を実行します。たとえばエイリアスを介して、または `&T` を `&mut T` に変換することによってそのデータを変更することは、未定義の動作と見なされます。
/// `UnsafeCell<T>` `&T` の不変性保証のオプトアウト: 共有参照 `&UnsafeCell<T>` は、変更されているデータを指している可能性があります。これは "interior mutability" と呼ばれます。
///
/// `Cell<T>` や `RefCell<T>` など、内部可変性を許可する他のすべてのタイプは、内部で `UnsafeCell` を使用してデータをラップします。
///
/// `UnsafeCell` の影響を受けるのは、共有参照の不変性の保証のみであることに注意してください。可変参照の一意性の保証は影響を受けません。`UnsafeCell<T>` を使用していても、エイリアシング `&mut` を取得する合法的な方法は *ありません*。
///
/// `UnsafeCell` API 自体は技術的に非常に単純です。[`.get()`] は、その内容への生のポインター `*mut T` を提供します。その生のポインタを正しく使用するのは、抽象化デザイナとして _you_ 次第です。
///
/// [`.get()`]: `UnsafeCell::get`
///
/// 正確な Rust エイリアシングルールは多少流動的ですが、要点は論争の余地がありません。
///
/// - 安全なコードでアクセスできる有効期間 `'a` (`&T` または `&mut T` 参照のいずれか) を使用して安全な参照を作成する場合 (たとえば、データを返したため)、残りの参照と矛盾する方法でデータにアクセスしてはなりません。`'a` の。
/// たとえば、これは、`UnsafeCell<T>` から `*mut T` を取得して `&T` にキャストする場合、その参照の有効期限が切れるまで、`T` のデータは不変のままでなければならないことを意味します (もちろん、`T` 内で見つかった `UnsafeCell` データを法として)。
/// 同様に、安全なコードにリリースされる `&mut T` 参照を作成する場合は、その参照の有効期限が切れるまで `UnsafeCell` 内のデータにアクセスしないでください。
///
/// - 常に、データの競合を回避する必要があります。複数のスレッドが同じ `UnsafeCell` にアクセスできる場合、他のすべてのアクセスとの関係の前に、すべての書き込みが適切に行われる必要があります (またはアトミックを使用します)。
///
/// 適切な設計を支援するために、次のシナリオはシングルスレッドコードに対して正当であると明示的に宣言されています。
///
/// 1. `&T` 参照は安全なコードにリリースでき、そこで他の `&T` 参照と共存できますが、`&mut T` とは共存できません。
///
/// 2. `&mut T` リファレンスは、他の `&mut T` も `&T` も共存しない限り、安全なコードにリリースされる可能性があります。`&mut T` は常に一意である必要があります。
///
/// `&UnsafeCell<T>` の内容を変更することは (他の `&UnsafeCell<T>` 参照がセルをエイリアスしている場合でも) 問題ありませんが (上記の不変条件を他の方法で適用する場合)、複数の `&mut UnsafeCell<T>` エイリアスを持つことは未定義の動作であることに注意してください。
/// つまり、`UnsafeCell` は、`&UnsafeCell<_>` 参照を介して _shared_ accesses (_i.e._ と特別な相互作用を持つように設計されたラッパーです。`&mut UnsafeCell<_>` を介して _exclusive_ accesses (_e.g._ を処理する場合、魔法はまったくありません) : その `&mut` の借用の間、セルもラップされた値もエイリアス化できません。
///
/// これは、`&mut T` を生成する _safe_ getter である [`.get_mut()`] アクセサーによって示されます。
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// セルをエイリアスする複数の参照があるにもかかわらず、`UnsafeCell<_>` のコンテンツを適切に変更する方法を示す例を次に示します。
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // 同じ `x` への複数の / 同時 / 共有参照を取得します。
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // 安全性: この範囲内では、`x` の内容への他の参照はありません。
///     // だから私たちのものは事実上ユニークです。
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- 借りる -+
///     *p1_exclusive += 27; // |
/// } // <---------- このポイントを超えることはできません -------------------+
///
/// unsafe {
///     // 安全性: この範囲内では、誰も `x` のコンテンツに排他的にアクセスできるとは期待していません。
///     // そのため、複数の共有アクセスを同時に行うことができます。
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// 次の例は、`UnsafeCell<T>` への排他的アクセスがその `T` への排他的アクセスを意味するという事実を示しています。
///
/// ```rust
/// #![forbid(unsafe_code)] // 排他的アクセスで、
///                         // `UnsafeCell` は透過的な no-op ラッパーであるため、ここでは `unsafe` は必要ありません。
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` へのコンパイル時にチェックされた一意の参照を取得します。
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // 排他的な参照で、私たちは無料で内容を変更することができます。
/// *p_unique.get_mut() = 0;
/// // または、同等に:
/// x = UnsafeCell::new(0);
///
/// // 値を所有している場合は、コンテンツを無料で抽出できます。
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// 指定された値をラップする `UnsafeCell` の新しいインスタンスを構築します。
    ///
    ///
    /// メソッドを介した内部値へのすべてのアクセスは `unsafe` です。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// 値をアンラップします。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// ラップされた値への可変ポインターを取得します。
    ///
    /// これは、あらゆる種類のポインタにキャストできます。
    /// `&mut T` にキャストするときにアクセスが一意 (アクティブな参照がない、変更可能かどうか) であることを確認し、`&T` にキャストするときに変更または変更可能なエイリアスが発生していないことを確認します
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] があるため、ポインタを `UnsafeCell<T>` から `T` にキャストできます。
        // これは libstd の特別なステータスを悪用します。これがコンパイラの future バージョンで機能するというユーザーコードの保証はありません。
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// 基になるデータへの可変参照を返します。
    ///
    /// この呼び出しは、`UnsafeCell` を (コンパイル時に) 可変的に借用します。これにより、唯一の参照を所有することが保証されます。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// ラップされた値への可変ポインターを取得します。
    /// [`get`] との違いは、この関数が生のポインターを受け入れることです。これは、一時的な参照の作成を回避するのに役立ちます。
    ///
    /// 結果は、あらゆる種類のポインターにキャストできます。
    /// `&mut T` にキャストするときにアクセスが一意 (アクティブな参照がない、変更可能かどうか) であることを確認し、`&T` にキャストするときに変更または変更可能なエイリアスが発生していないことを確認します。
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `get` を呼び出すには、初期化されていないデータへの参照を作成する必要があるため、`UnsafeCell` を段階的に初期化するには `raw_get` が必要です。
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] があるため、ポインタを `UnsafeCell<T>` から `T` にキャストできます。
        // これは libstd の特別なステータスを悪用します。これがコンパイラの future バージョンで機能するというユーザーコードの保証はありません。
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T の `Default` 値を使用して `UnsafeCell` を作成します。
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}