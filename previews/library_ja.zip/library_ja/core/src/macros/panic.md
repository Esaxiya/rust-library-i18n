Panics 現在のスレッド。

これにより、プログラムをすぐに終了し、プログラムの呼び出し元にフィードバックを提供できます。
`panic!` プログラムが回復不能な状態に達したときに使用する必要があります。

このマクロは、サンプルコードおよびテストで条件をアサートするのに最適な方法です。
`panic!` [`Option`][ounwrap] 列挙型と [`Result`][runwrap] 列挙型の両方の `unwrap` メソッドと密接に関連しています。
どちらの実装も、[`None`] または [`Err`] バリアントに設定されている場合、`panic!` を呼び出します。

`panic!()` を使用する場合、[`format!`] 構文を使用して構築された文字列ペイロードを指定できます。
このペイロードは、呼び出し元の Rust スレッドに panic を注入するときに使用され、スレッドを完全に panic にします。

デフォルトの `std` hook の動作、つまり
panic が呼び出された直後に実行されるコードは、`panic!()` 呼び出しの file/line/column 情報とともにメッセージペイロードを `stderr` に出力することです。

[`std::panic::set_hook()`] を使用して、panic hook をオーバーライドできます。
hook 内では、panic に `&dyn Any + Send` としてアクセスできます。これには、通常の `panic!()` 呼び出し用の `&str` または `String` のいずれかが含まれています。
他のタイプの値を持つ panic には、[`panic_any`] を使用できます。

[`Result`] 多くの場合、列挙型は `panic!` マクロを使用するよりもエラーから回復するためのより良いソリューションです。
このマクロは、外部ソースなどからの誤った値の使用を回避するために使用する必要があります。
エラー処理の詳細については、[book] を参照してください。

コンパイル中にエラーが発生する場合は、マクロ [`compile_error!`] も参照してください。

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# 現在の実装

メインスレッドが panics の場合、すべてのスレッドが終了し、コード `101` でプログラムが終了します。

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





