#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // 発信者のエディションに応じて、`$crate::panic::panic_2015` または `$crate::panic::panic_2021` のいずれかに展開されます。
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// 2 つの式が互いに等しいことを表明します ([`PartialEq`] を使用)。
///
/// panic では、このマクロは式の値とそのデバッグ表現を出力します。
///
///
/// [`assert!`] と同様に、このマクロには 2 番目の形式があり、カスタム panic メッセージを提供できます。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 以下の再借用は意図的なものです。
                    // それらがないと、値が比較される前でもボローのスタックスロットが初期化され、顕著な速度低下につながります。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // 以下の再借用は意図的なものです。
                    // それらがないと、値が比較される前でもボローのスタックスロットが初期化され、顕著な速度低下につながります。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 2 つの式が互いに等しくないことを表明します ([`PartialEq`] を使用)。
///
/// panic では、このマクロは式の値とそのデバッグ表現を出力します。
///
///
/// [`assert!`] と同様に、このマクロには 2 番目の形式があり、カスタム panic メッセージを提供できます。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 以下の再借用は意図的なものです。
                    // それらがないと、値が比較される前でもボローのスタックスロットが初期化され、顕著な速度低下につながります。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // 以下の再借用は意図的なものです。
                    // それらがないと、値が比較される前でもボローのスタックスロットが初期化され、顕著な速度低下につながります。
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// 実行時にブール式が `true` であることを表明します。
///
/// 指定された式を実行時に `true` に評価できない場合、これにより [`panic!`] マクロが呼び出されます。
///
/// [`assert!`] と同様に、このマクロにも 2 番目のバージョンがあり、カスタム panic メッセージを提供できます。
///
/// # Uses
///
/// [`assert!`] とは異なり、`debug_assert!` ステートメントは、デフォルトで最適化されていないビルドでのみ有効になります。
/// 最適化されたビルドは、`-C debug-assertions` がコンパイラーに渡されない限り、`debug_assert!` ステートメントを実行しません。
/// これにより、`debug_assert!` は、リリースビルドに含めるにはコストがかかりすぎるが、開発中には役立つ可能性があるチェックに役立ちます。
/// `debug_assert!` を拡張した結果は、常にタイプチェックされます。
///
/// チェックされていないアサーションにより、一貫性のない状態のプログラムが実行を継続できます。これは予期しない結果をもたらす可能性がありますが、これが安全なコードでのみ発生する限り、安全性を損なうことはありません。
///
/// ただし、アサーションのパフォーマンスコストは、一般的に測定できません。
/// したがって、[`assert!`] を `debug_assert!` に置き換えることは、完全なプロファイリングの後でのみ、そしてさらに重要なことに、安全なコードでのみ推奨されます。
///
/// # Examples
///
/// ```
/// // これらのアサーションの panic メッセージは、指定された式の文字列化された値です。
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // 非常にシンプルな機能
/// debug_assert!(some_expensive_computation());
///
/// // カスタムメッセージでアサート
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// 2 つの式が互いに等しいことを表明します。
///
/// panic では、このマクロは式の値とそのデバッグ表現を出力します。
///
/// [`assert_eq!`] とは異なり、`debug_assert_eq!` ステートメントは、デフォルトで最適化されていないビルドでのみ有効になります。
/// 最適化されたビルドは、`-C debug-assertions` がコンパイラに渡されない限り、`debug_assert_eq!` ステートメントを実行しません。
/// これにより、`debug_assert_eq!` は、リリースビルドに含めるにはコストがかかりすぎるが、開発中には役立つ可能性があるチェックに役立ちます。
///
/// `debug_assert_eq!` を拡張した結果は、常にタイプチェックされます。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// 2 つの式が互いに等しくないことを表明します。
///
/// panic では、このマクロは式の値とそのデバッグ表現を出力します。
///
/// [`assert_ne!`] とは異なり、`debug_assert_ne!` ステートメントは、デフォルトで最適化されていないビルドでのみ有効になります。
/// 最適化されたビルドは、`-C debug-assertions` がコンパイラーに渡されない限り、`debug_assert_ne!` ステートメントを実行しません。
/// これにより、`debug_assert_ne!` は、リリースビルドに含めるにはコストがかかりすぎるが、開発中には役立つ可能性があるチェックに役立ちます。
///
/// `debug_assert_ne!` を拡張した結果は、常にタイプチェックされます。
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// 指定された式が指定されたパターンのいずれかに一致するかどうかを返します。
///
/// `match` 式と同様に、パターンの後にはオプションで `if` と、パターンによってバインドされた名前にアクセスできるガード式を続けることができます。
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// 結果をアンラップするか、エラーを伝播します。
///
/// `try!` の代わりに `?` 演算子が追加されたため、代わりに使用する必要があります。
/// さらに、`try` は Rust 2018 の予約語であるため、使用する必要がある場合は、[raw-identifier syntax][ris] を使用する必要があります。`r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` 指定された [`Result`] に一致します。`Ok` バリアントの場合、式にはラップされた値の値があります。
///
/// `Err` バリアントの場合、内部エラーを取得します。次に、`try!` は `From` を使用して変換を実行します。
/// これにより、特殊なエラーとより一般的なエラーの間の自動変換が提供されます。
/// 結果のエラーはすぐに返されます。
///
/// `try!` は早期に返されるため、[`Result`] を返す関数でのみ使用できます。
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // エラーをすばやく返すための推奨される方法
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // エラーをすばやく返す以前の方法
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // これは次と同等です。
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// フォーマットされたデータをバッファに書き込みます。
///
/// このマクロは、'writer'、フォーマット文字列、および引数のリストを受け入れます。
/// 引数は指定されたフォーマット文字列に従ってフォーマットされ、結果はライターに渡されます。
/// ライターは、`write_fmt` メソッドを使用する任意の値にすることができます。通常、これは [`fmt::Write`] または [`io::Write`] trait のいずれかの実装に由来します。
/// マクロは、`write_fmt` メソッドが返すものをすべて返します。通常、[`fmt::Result`] または [`io::Result`] です。
///
/// フォーマット文字列構文の詳細については、[`std::fmt`] を参照してください。
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// オブジェクトは通常両方を実装しないため、モジュールは `std::fmt::Write` と `std::io::Write` の両方をインポートし、どちらかを実装するオブジェクトで `write!` を呼び出すことができます。
///
/// ただし、モジュールは、名前が競合しないように、修飾された traits をインポートする必要があります。
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt を使用
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt を使用
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: このマクロは、`no_std` セットアップでも使用できます。
/// `no_std` セットアップでは、コンポーネントの実装の詳細を担当します。
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// 改行を追加して、フォーマットされたデータをバッファーに書き込みます。
///
/// すべてのプラットフォームで、改行は LINE FEED 文字 (`\n`/`U+000A`) のみです (追加の CARRIAGE RETURN (`\r`/`U+000D`) はありません)。
///
/// 詳細については、[`write!`] を参照してください。フォーマット文字列の構文については、[`std::fmt`] を参照してください。
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// オブジェクトは通常両方を実装しないため、モジュールは `std::fmt::Write` と `std::io::Write` の両方をインポートし、どちらかを実装するオブジェクトで `write!` を呼び出すことができます。
/// ただし、モジュールは、名前が競合しないように、修飾された traits をインポートする必要があります。
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt を使用
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt を使用
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// 到達不能コードを示します。
///
/// これは、コンパイラが一部のコードに到達できないと判断できない場合に役立ちます。例えば:
///
/// * 武器をガード条件に合わせます。
/// * 動的に終了するループ。
/// * 動的に終了するイテレータ。
///
/// コードが到達不能であるとの判断が正しくないことが判明した場合、プログラムは [`panic!`] で即座に終了します。
///
/// このマクロの安全でない対応物は [`unreachable_unchecked`] 関数であり、コードに到達すると未定義の動作が発生します。
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// これは常に [`panic!`] になります。
///
/// # Examples
///
/// マッチアーム:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // コメントアウトされた場合のコンパイルエラー
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 の最も貧弱な実装の 1 つ
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" のメッセージでパニックになり、実装されていないコードを示します。
///
/// これにより、コードで型チェックが可能になります。これは、すべてを使用する予定のない複数のメソッドを必要とする trait のプロトタイプを作成したり、実装したりする場合に便利です。
///
/// `unimplemented!` と [`todo!`] の違いは、`todo!` は後で機能を実装する意図を伝え、メッセージは "not yet implemented" ですが、`unimplemented!` はそのような主張をしないことです。
/// そのメッセージは "not implemented" です。
/// また、一部の IDE は「todo!」をマークします。
///
/// # Panics
///
/// `unimplemented!` は `panic!` の省略形であり、固定された特定のメッセージがあるため、これは常に [`panic!`] になります。
///
/// `panic!` と同様に、このマクロにはカスタム値を表示するための 2 番目の形式があります。
///
/// # Examples
///
/// trait `Foo` があるとします。
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' に `Foo` を実装したいのですが、何らかの理由で `bar()` 関数を実装することだけが理にかなっています。
/// `baz()` `qux()` は `Foo` の実装で定義する必要がありますが、定義で `unimplemented!` を使用して、コードをコンパイルできるようにすることができます。
///
/// 実装されていないメソッドに到達した場合でも、プログラムの実行を停止させたいと考えています。
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` と `MyStruct` には意味がないため、ここにはロジックがまったくありません。
/////
///         // "thread 'main' panicked at 'not implemented'" が表示されます。
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ここにいくつかのロジックがあります。実装されていないものにメッセージを追加できます。私たちの省略を表示します。
///         // これは次のように表示されます。"thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// 未完成のコードを示します。
///
/// これは、プロトタイピングを行っていて、コードのタイプチェックを行うだけの場合に役立ちます。
///
/// [`unimplemented!`] と `todo!` の違いは、`todo!` は後で機能を実装する意図を伝え、メッセージは "not yet implemented" ですが、`unimplemented!` はそのような主張をしないことです。
/// そのメッセージは "not implemented" です。
/// また、一部の IDE は「todo!」をマークします。
///
/// # Panics
///
/// これは常に [`panic!`] になります。
///
/// # Examples
///
/// 進行中のコードの例を次に示します。trait `Foo` があります:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// いずれかのタイプに `Foo` を実装したいのですが、最初に `bar()` だけで作業したいと思います。コードをコンパイルするには、`baz()` を実装する必要があるため、`todo!` を使用できます。
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // 実装はここにあります
///     }
///
///     fn baz(&self) {
///         // 今のところ baz() の実装について心配する必要はありません
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // baz() も使用していないので、これで問題ありません。
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// 組み込みマクロの定義。
///
/// マクロ入力を出力に変換する拡張関数を除いて、ほとんどのマクロプロパティ (安定性、可視性など) は、ここのソースコードから取得されます。これらの関数は、コンパイラによって提供されます。
///
///
pub(crate) mod builtin {

    /// 発生すると、指定されたエラーメッセージでコンパイルが失敗します。
    ///
    /// このマクロは、crate が条件付きコンパイル戦略を使用して、誤った条件に対してより適切なエラーメッセージを提供する場合に使用する必要があります。
    ///
    /// これは [`panic!`] のコンパイラレベルの形式ですが、*実行時* ではなく *コンパイル* 中にエラーを発行します。
    ///
    /// # Examples
    ///
    /// そのような 2 つの例は、マクロと `#[cfg]` 環境です。
    ///
    /// マクロに無効な値が渡された場合、より適切なコンパイラエラーを発行します。
    /// 最後の branch がなくても、コンパイラはエラーを出力しますが、エラーのメッセージには 2 つの有効な値が記載されていません。
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// いくつかの機能の 1 つが使用できない場合は、コンパイラエラーを発行します。
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 他の文字列フォーマットマクロのパラメータを作成します。
    ///
    /// このマクロは、渡された追加の引数ごとに `{}` を含むフォーマット文字列リテラルを取得することによって機能します。
    /// `format_args!` 出力を文字列として解釈できるように追加のパラメーターを準備し、引数を単一の型に正規化します。
    /// [`Display`] trait を実装する値はすべて `format_args!` に渡すことができ、[`Debug`] 実装はフォーマット文字列内で `{:?}` に渡すことができます。
    ///
    ///
    /// このマクロは、タイプ [`fmt::Arguments`] の値を生成します。この値は、有用なリダイレクトを実行するために [`std::fmt`] 内のマクロに渡すことができます。
    /// 他のすべてのフォーマットマクロ ([`format! `]、[`write!`]、[`println!`] など) は、このマクロを介してプロキシされます。
    /// `format_args!`, 派生マクロとは異なり、ヒープの割り当てを回避します。
    ///
    /// 以下に示すように、`format_args!` が `Debug` および `Display` コンテキストで返す [`fmt::Arguments`] 値を使用できます。
    /// この例は、`Debug` と `Display` が同じものにフォーマットされていることも示しています。`format_args!` の補間されたフォーマット文字列です。
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// 詳細については、[`std::fmt`] のドキュメントを参照してください。
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` と同じですが、最後に新しい行を追加します。
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// コンパイル時に環境変数を検査します。
    ///
    /// このマクロは、コンパイル時に指定された環境変数の値に展開され、タイプ `&'static str` の式を生成します。
    ///
    ///
    /// 環境変数が定義されていない場合、コンパイルエラーが発行されます。
    /// コンパイルエラーを出さないようにするには、代わりに [`option_env!`] マクロを使用してください。
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// 2 番目のパラメータとして文字列を渡すことにより、エラーメッセージをカスタマイズできます。
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` 環境変数が定義されていない場合、次のエラーが発生します。
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// オプションで、コンパイル時に環境変数を検査します。
    ///
    /// 名前付き環境変数がコンパイル時に存在する場合、これは、値が環境変数の値の `Some` であるタイプ `Option<&'static str>` の式に展開されます。
    /// 環境変数が存在しない場合、これは `None` に展開されます。
    /// このタイプの詳細については、[`Option<T>`][Option] を参照してください。
    ///
    /// このマクロを使用すると、環境変数が存在するかどうかに関係なく、コンパイル時エラーが発生することはありません。
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 識別子を 1 つの識別子に連結します。
    ///
    /// このマクロは、コンマ区切りの識別子をいくつでも受け取り、それらをすべて 1 つに連結して、新しい識別子である式を生成します。
    /// 衛生状態により、このマクロはローカル変数をキャプチャできないことに注意してください。
    /// また、原則として、マクロはアイテム、ステートメント、または式の位置でのみ許可されます。
    /// つまり、このマクロを使用して既存の変数、関数、モジュールなどを参照することはできますが、新しいマクロを定義することはできません。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new、fun、name) { }// この方法では使用できません!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// リテラルを静的文字列スライスに連結します。
    ///
    /// このマクロは、コンマで区切られたリテラルをいくつでも受け取り、左から右に連結されたすべてのリテラルを表す `&'static str` 型の式を生成します。
    ///
    ///
    /// 整数リテラルと浮動小数点リテラルは、連結するために文字列化されます。
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 呼び出された行番号に展開されます。
    ///
    /// [`column!`] および [`file!`] では、これらのマクロは、ソース内の場所に関するデバッグ情報を開発者に提供します。
    ///
    /// 展開された式のタイプは `u32` で、1 ベースであるため、各ファイルの最初の行は 1 と評価され、2 番目の行は 2 と評価されます。
    /// これは、一般的なコンパイラまたは一般的なエディタによるエラーメッセージと一致しています。
    /// 返される行は、`line!` 呼び出し自体の行である必要はありませんが、`line!` マクロの呼び出しにつながる最初のマクロ呼び出しです。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// 呼び出された列番号に展開されます。
    ///
    /// [`line!`] および [`file!`] では、これらのマクロは、ソース内の場所に関するデバッグ情報を開発者に提供します。
    ///
    /// 展開された式のタイプは `u32` で、1 から始まるため、各行の最初の列は 1 と評価され、2 番目の列は 2 と評価されます。
    /// これは、一般的なコンパイラまたは一般的なエディタによるエラーメッセージと一致しています。
    /// 返される列は、`column!` 呼び出し自体の行である必要はありませんが、`column!` マクロの呼び出しにつながる最初のマクロ呼び出しです。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// 呼び出されたファイル名に展開されます。
    ///
    /// [`line!`] および [`column!`] では、これらのマクロは、ソース内の場所に関するデバッグ情報を開発者に提供します。
    ///
    /// 展開された式のタイプは `&'static str` であり、返されるファイルは `file!` マクロ自体の呼び出しではなく、`file!` マクロの呼び出しにつながる最初のマクロ呼び出しです。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// その引数を文字列化します。
    ///
    /// このマクロは、マクロに渡されたすべての tokens の文字列化であるタイプ `&'static str` の式を生成します。
    /// マクロ呼び出し自体の構文に制限はありません。
    ///
    /// 入力 tokens の展開された結果は、future で変更される可能性があることに注意してください。出力に依存する場合は注意が必要です。
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 でエンコードされたファイルを文字列として含めます。
    ///
    /// ファイルは、現在のファイルを基準にして配置されます (モジュールの検索方法と同様)。
    /// 提供されたパスは、コンパイル時にプラットフォーム固有の方法で解釈されます。
    /// したがって、たとえば、バックスラッシュ `\` を含む Windows パスを使用した呼び出しは、Unix では正しくコンパイルされません。
    ///
    ///
    /// このマクロは、ファイルの内容であるタイプ `&'static str` の式を生成します。
    ///
    /// # Examples
    ///
    /// 同じディレクトリに次の内容の 2 つのファイルがあるとします。
    ///
    /// ファイル 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ファイル 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' をコンパイルし、結果のバイナリを実行すると、"adiós" が出力されます。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// バイト配列への参照としてファイルを含めます。
    ///
    /// ファイルは、現在のファイルを基準にして配置されます (モジュールの検索方法と同様)。
    /// 提供されたパスは、コンパイル時にプラットフォーム固有の方法で解釈されます。
    /// したがって、たとえば、バックスラッシュ `\` を含む Windows パスを使用した呼び出しは、Unix では正しくコンパイルされません。
    ///
    ///
    /// このマクロは、ファイルの内容であるタイプ `&'static [u8; N]` の式を生成します。
    ///
    /// # Examples
    ///
    /// 同じディレクトリに次の内容の 2 つのファイルがあるとします。
    ///
    /// ファイル 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ファイル 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' をコンパイルし、結果のバイナリを実行すると、"adiós" が出力されます。
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 現在のモジュールパスを表す文字列に展開されます。
    ///
    /// 現在のモジュールパスは、crate root に戻るモジュールの階層と考えることができます。
    /// 返されるパスの最初のコンポーネントは、現在コンパイルされている crate の名前です。
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// コンパイル時に構成フラグのブール値の組み合わせを評価します。
    ///
    /// `#[cfg]` 属性に加えて、このマクロは、構成フラグのブール式評価を可能にするために提供されています。
    /// これにより、コードの重複が少なくなることがよくあります。
    ///
    /// このマクロに与えられる構文は、[`cfg`] 属性と同じ構文です。
    ///
    /// `cfg!`, `#[cfg]` とは異なり、コードは削除されず、true または false と評価されるだけです。
    /// たとえば、`cfg!` が条件に使用される場合、`cfg!` が何を評価しているかに関係なく、if/else 式のすべてのブロックが有効である必要があります。
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// コンテキストに応じて、ファイルを式またはアイテムとして解析します。
    ///
    /// ファイルは、現在のファイルを基準にして配置されます (モジュールの検索方法と同様)。提供されたパスは、コンパイル時にプラットフォーム固有の方法で解釈されます。
    /// したがって、たとえば、バックスラッシュ `\` を含む Windows パスを使用した呼び出しは、Unix では正しくコンパイルされません。
    ///
    /// このマクロを使用することは、ファイルが式として解析される場合、非衛生的に周囲のコードに配置されるため、しばしば悪い考えです。
    /// これにより、現在のファイルに同じ名前の変数または関数がある場合、変数または関数がファイルの予想とは異なる可能性があります。
    ///
    ///
    /// # Examples
    ///
    /// 同じディレクトリに次の内容の 2 つのファイルがあるとします。
    ///
    /// ファイル 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ファイル 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' をコンパイルし、結果のバイナリを実行すると、"🙈🙊🙉🙈🙊🙉" が出力されます。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// 実行時にブール式が `true` であることを表明します。
    ///
    /// 指定された式を実行時に `true` に評価できない場合、これにより [`panic!`] マクロが呼び出されます。
    ///
    /// # Uses
    ///
    /// アサーションは、デバッグビルドとリリースビルドの両方で常にチェックされ、無効にすることはできません。
    /// デフォルトでリリースビルドで有効になっていないアサーションについては、[`debug_assert!`] を参照してください。
    ///
    /// 安全でないコードは、`assert!` に依存して実行時の不変条件を適用し、違反した場合に安全性が失われる可能性があります。
    ///
    /// `assert!` の他のユースケースには、安全なコードで実行時の不変条件をテストおよび適用することが含まれます (その違反が安全性を損なうことはありません)。
    ///
    ///
    /// # カスタムメッセージ
    ///
    /// このマクロには 2 番目の形式があり、カスタム panic メッセージをフォーマット用の引数の有無にかかわらず提供できます。
    /// このフォームの構文については、[`std::fmt`] を参照してください。
    /// フォーマット引数として使用される式は、アサーションが失敗した場合にのみ評価されます。
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // これらのアサーションの panic メッセージは、指定された式の文字列化された値です。
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // 非常にシンプルな機能
    ///
    /// assert!(some_computation());
    ///
    /// // カスタムメッセージでアサート
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// インラインアセンブリ。
    ///
    /// 使用法については [unstable book] をお読みください。
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM スタイルのインラインアセンブリ。
    ///
    /// 使用法については [unstable book] をお読みください。
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// モジュールレベルのインラインアセンブリ。
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// 渡された tokens を標準出力に出力します。
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// 他のマクロのデバッグに使用されるトレース機能を有効または無効にします。
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// 派生マクロを適用するために使用される属性マクロ。
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// 関数に適用される属性マクロで、関数をユニットテストに変換します。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// 関数をベンチマークテストに変換するために関数に適用される属性マクロ。
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` および `#[bench]` マクロの実装の詳細。
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// スタティックに適用され、グローバルアロケータとして登録する属性マクロ。
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) も参照してください。
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// 渡されたパスにアクセスできる場合は適用されているアイテムを保持し、そうでない場合は削除します。
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// 適用されるコードフラグメント内のすべての `#[cfg]` および `#[cfg_attr]` 属性を展開します。
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` コンパイラの不安定な実装の詳細。使用しないでください。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` コンパイラの不安定な実装の詳細。使用しないでください。
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}