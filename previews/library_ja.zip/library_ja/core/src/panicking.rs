//! libcore の Panic サポート
//!
//! コアライブラリはパニックを定義できませんが、パニックを *宣言* します。
//! これは、libcore 内の関数が panic に許可されていることを意味しますが、アップストリームの crate が有用であるためには、libcore が使用するためのパニックを定義する必要があります。
//! パニックの現在のインターフェースは次のとおりです。
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! この定義では、一般的なメッセージでパニックを起こすことはできますが、`Box<Any>` 値で失敗することはできません。
//! (`PanicInfo` には `&(dyn Any + Send)` が含まれているだけで、`PanicInfo: : internal_constructor` にダミー値を入力します。) これは、libcore が割り当てを許可されていないためです。
//!
//!
//! このモジュールには他にもいくつかのパニック関数が含まれていますが、これらはコンパイラーに必要な lang 項目にすぎません。すべての panics は、この 1 つの関数を介して集中されます。
//! 実際のシンボルは、`#[panic_handler]` 属性を介して宣言されます。
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// 書式設定が使用されていない場合の libcore の `panic!` マクロの基本的な実装。
#[cold]
// コールサイトでのコードの膨張を可能な限り回避するために、panic_immediate_abort を除いて、インライン化しないでください
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // オーバーフローおよびその他の `Assert` MIR ターミネータで panic の codegen に必要
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // format_args! ( "{}"、expr) の代わりに Arguments::new_v1 を使用して、サイズのオーバーヘッドを削減できる可能性があります。
    // format_args! マクロは str の Display trait を使用して expr を書き込みます。expr は Formatter::pad を呼び出します。これは、文字列の切り捨てとパディングに対応する必要があります (ここでは何も使用されていません)。
    //
    // Arguments::new_v1 を使用すると、コンパイラーは出力バイナリーから Formatter::pad を省略して、最大数キロバイトを節約できる場合があります。
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // const-evaluated panics に必要
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice アクセスで panic の codegen に必要
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// フォーマットが使用される場合の libcore の `panic!` マクロの基本的な実装。
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // 注この関数は FFI 境界を越えることはありません。`#[panic_handler]` 関数に解決されるのは Rust から Rust への呼び出しです。
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // 安全性: `panic_impl` は安全な Rust コードで定義されているため、安全に呼び出すことができます。
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` および `assert_ne!` マクロの内部関数
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}