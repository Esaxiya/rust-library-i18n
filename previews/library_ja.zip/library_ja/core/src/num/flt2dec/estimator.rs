//! 指数推定量。

/// `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` のような `k_0` を検索します。
///
/// これは `k = ceil(log_10 (mant * 2^exp))` を概算するために使用されます。
/// 真の `k` は `k_0` または `k_0+1` のいずれかです。
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits (mant> 0 の場合)
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) したがって、これは常に過小評価 (または正確) ですが、それほど多くはありません。
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}