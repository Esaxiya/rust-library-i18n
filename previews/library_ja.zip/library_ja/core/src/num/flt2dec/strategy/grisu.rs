//! 「整数を使用した浮動小数点数の迅速かつ正確な印刷」[^ 1] で説明されている Grisu3 アルゴリズムの Rust 適応。
//! 約 1KB の事前計算されたテーブルを使用し、ほとんどの入力に対して非常に高速です。
//!
//! [^1]: Florian ロイッチ。2010. 浮動小数点数をすばやく印刷して
//!   整数で正確に。SIGPLAN ではありません。45、6 (2010 年 6 月)、233-243。
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// 理論的根拠については、`format_shortest_opt` のコメントを参照してください。
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i、80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f、e、k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// `x > 0` を指定すると、`10^k <= x < 10^(k+1)` となるように `(k, 10^k)` を返します。
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Grisu の最短モードの実装。
///
/// それ以外の場合は不正確な表現を返す場合は `None` を返します。
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // 少なくとも 3 ビットの追加精度が必要です

    // 共有指数を使用して正規化された値から開始します
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // `ALPHA <= minusk + plus.e + 64 <= GAMMA` のような `cached = 10^minusk` を見つけます。
    // `plus` は正規化されているため、これは `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)` を意味します。
    // `ALPHA` と `GAMMA` の選択を考えると、これにより `plus * cached` が `[4, 2^32)` に配置されます。
    //
    // `GAMMA - ALPHA` を最大化することが明らかに望ましいので、10 の累乗をキャッシュする必要はありませんが、いくつかの考慮事項があります。
    //
    //
    // 1. コストのかかる分割が必要なため、`floor(plus * cached)` を `u32` 内に維持したいと考えています。
    //    (これは実際には避けられません。精度の見積もりには残りが必要です。)
    // 2.
    // `floor(plus * cached)` の余りは繰り返し 10 倍になり、オーバーフローしてはなりません。
    //
    // 1 つ目は `64 + GAMMA <= 32` を提供し、2 つ目は `10 * 2^-ALPHA <= 2^64` を提供します。
    // -60 -32 はこの制約のある最大範囲であり、V8 もそれらを使用します。
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // スケール fps。これにより、最大誤差 1 ulp が得られます (定理 5.1 から証明)。
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +- マイナスの実際の範囲
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // `minus` より上では、`v` および `plus` は *量子化* された近似値です (エラー < 1 ulp)。
    // 誤差が正か負かわからないため、等間隔の 2 つの近似を使用し、最大誤差は 2ulps です。
    //
    // "unsafe region" は、最初に生成するリベラルな間隔です。
    // "safe region" は、私たちが受け入れるだけの控えめな間隔です。
    // 安全でない領域内の正しい repr から始めて、同じく安全な領域内にある `v` に最も近い repr を見つけようとします。
    // できない場合はあきらめます。
    //
    let plus1 = plus.f + 1;
    // plus0 = plus.f、1 とします。// 説明のためだけに minus0 = minus.f + 1;// 説明のみ
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // 共有指数

    // `plus1` を整数部分と小数部分に分割します。
    // キャッシュされた電力は `plus < 2^32` を保証し、正規化された `plus.f` は精度要件のために常に `2^64 - 2^4` 未満であるため、一体型部品は u32 に適合することが保証されています。
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // `plus1` (したがって `plus1 < 10^(max_kappa+1)`) 以下の最大の `10^max_kappa` を計算します。
    // これは、以下の `kappa` の上限です。
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 定理 6.2: `k` が最大の整数 st である場合
    // `0 <= y mod 10^k <= y - x`,              その場合、`V = floor(y / 10^k) * 10^k` は `[x, y]` にあり、その範囲内で最も短い表現の 1 つ (有効桁数が最小) です。
    //
    //
    // 定理 6.2 に従って、`(minus1, plus1)` 間の桁長 `kappa` を見つけます。
    // 定理 6.2 は、代わりに `y mod 10^k < y - x` を要求することにより、`x` を除外するために採用できます。
    // (たとえば、`x` =32000、`y` =32777、`y mod 10 ^ 3=777 <y、x=777` であるため `kappa` =2) アルゴリズムは、後の検証フェーズに依存して `y` を除外します。
    //
    let delta1 = plus1 - minus1;
    // delta1int= (delta1 >> e) を使用するようにします。// 説明のみ
    let delta1frac = delta1 & ((1 << e) - 1);

    // 各ステップで精度をチェックしながら、一体型パーツをレンダリングします。
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // まだレンダリングされていない数字
    loop {
        // `plus1 >= 10^kappa` 不変条件として、レンダリングする桁は常に少なくとも 1 つあります。
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = plus1int % 10^(kappa+1)` に続く)
        //
        //

        // `remainder` を `10^kappa` で割ります。どちらも `2^-e` でスケーリングされます。
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // == (plus1％10 ^ カッパ) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; 正しい `kappa` が見つかりました。
            let ten_kappa = (ten_kappa as u64) << e; // 10 ^ kappa を共有指数にスケールバックします
            return round_and_weed(
                // 安全性: 上記のメモリを初期化しました。
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // すべての整数桁をレンダリングしたら、ループを解除します。
        // 正確な桁数は `max_kappa + 1` と `plus1 < 10^(max_kappa+1)` です。
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 不変条件を復元する
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 各ステップで精度を確認しながら、小数部分をレンダリングします。
    // 今回は、除算によって精度が失われるため、乗算の繰り返しに依存します。
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // 次の桁は、不変条件を分割する前にテストしたため、重要であるはずです。ここで、`m = max_kappa + 1` (整数部分の桁数) :
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // オーバーフローしません、 `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` を `10^kappa` で割ります。
        // どちらも `2^e / 10^kappa` によってスケーリングされるため、後者はここでは暗黙的に示されています。
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // 暗黙の除数
            return round_and_weed(
                // 安全性: 上記のメモリを初期化しました。
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // 不変条件を復元する
        kappa -= 1;
        remainder = r;
    }

    // `plus1` の有効数字をすべて生成しましたが、それが最適な数字かどうかはわかりません。
    // たとえば、`minus1` が 3.14153 ... で、`plus1` が 3.14158 ... の場合、3.14154 から 3.14158 までの 5 つの異なる最短表現がありますが、最大のものしかありません。
    // 最後の桁を連続して減らし、これが最適な表現であるかどうかを確認する必要があります。
    // 最大で 9 つの候補 (..1 から..9) があるので、これはかなり速いです。("rounding" フェーズ)
    //
    // この関数は、この "optimal" repr が実際に ulp 範囲内にあるかどうかをチェックします。また、丸め誤差のために "second-to-optimal" repr が実際に最適である可能性もあります。
    // いずれの場合も、これは `None` を返します。
    // ("weeding" フェーズ)
    //
    // ここでのすべての引数は、共通の (ただし暗黙の) 値 `k` によってスケーリングされるため、次のようになります。
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (そしてまた、`remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (また、以前の不変条件からの `threshold > plus1v`)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps 内で `v` (実際には `plus1 - v`) の 2 つの近似を生成します。
        // 結果の表現は、両方に最も近い表現である必要があります。
        //
        // ここでは、overflow/underflow を回避するために `plus1` に関して計算が行われるため、`plus1 - v` が使用されます (したがって、名前が入れ替わったように見えます)。
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v、1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // 最後の桁を減らし、`v + 1 ulp` に最も近い表現で停止します。
        let mut plus1w = remainder; // plus1w(n) = plus1、w(n)
        {
            let last = buf.last_mut().unwrap();

            // 最初は `plus1 - plus1 % 10^kappa` に等しい概算の数字 `w(n)` を使用します。ループ本体を `n` 回実行した後、 `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` を設定します (したがって、チェックを簡略化するために `remainder= plus1w(0)`) です。
            // `plus1w(n)` は常に増加していることに注意してください。
            //
            // 終了する条件は 3 つあります。それらのいずれかを使用すると、ループを続行できなくなりますが、いずれにせよ、`v + 1 ulp` に最も近いことがわかっている有効な表現が少なくとも 1 つあります。
            // 簡潔にするために、それらを TC1 から TC3 と表記します。
            //
            // TC1: `w(n) <= v + 1 ulp`、つまり、これは最も近い repr になる可能性のある最後の repr です。
            // これは `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` と同等です。
            // TC2 (`w(n+1)` is valid) かどうかをチェックします。これにより、`plus1w(n)` の計算で発生する可能性のあるオーバーフローが防止されます。
            //
            // TC2: `w(n+1) < minus1`、つまり、次の repr は間違いなく `v` に丸められません。
            // これは `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` と同等です。
            // 左側はオーバーフローする可能性がありますが、`threshold > plus1v` がわかっているため、TC1 が false の場合、`threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` であり、代わりに `threshold - plus1w(n) < 10^kappa` かどうかを安全にテストできます。
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`、つまり次の repr は
            // 現在の repr よりも `v + 1 ulp` に近くありません。
            // `z(n) = plus1v_up - plus1w(n)` が与えられると、これは `abs(z(n)) <= abs(z(n+1))` になります。再び TC1 が偽であると仮定すると、`z(n) > 0` があります。考慮すべき 2 つのケースがあります。
            //
            // - `z(n+1) >= 0` の場合: TC3 が `z(n) <= z(n+1)` になります。
            // `plus1w(n)` が増加するにつれて、`z(n)` は減少するはずであり、これは明らかに誤りです。
            // - `z(n+1) < 0` の場合:
            //   - TC3a: 前提条件は `plus1v_up < plus1w(n) + 10^kappa` です。TC2 が false であると仮定すると、`threshold >= plus1w(n) + 10^kappa` であるため、オーバーフローすることはありません。
            //   - TC3b: TC3 は `z(n) <= -z(n+1)` になります。つまり、 `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   否定された TC1 は `plus1v_up > plus1w(n)` を提供するため、TC3a と組み合わせたときにオーバーフローまたはアンダーフローすることはできません。
            //
            // したがって、`TC1 || TC2 || (TC3a && TC3b)` のときに停止する必要があります。以下はその逆に等しい、 `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // 最短の repr は `0` で終了できません
                plus1w += ten_kappa;
            }
        }

        // この表現が `v - 1 ulp` に最も近い表現でもあるかどうかを確認してください。
        //
        // これは、`v + 1 ulp` の終了条件とまったく同じですが、代わりにすべての `plus1v_up` が `plus1v_down` に置き換えられます。
        // オーバーフロー分析も同様に成り立ちます。
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // これで、`plus1` と `minus1` の間で `v` に最も近い表現ができました。
        // ただし、これはリベラルすぎるため、`plus0` と `minus0` の間にない `w(n)`、つまり `plus1 - plus1w(n) <= minus0` または `plus1 - plus1w(n) >= plus0` を拒否します。
        // `threshold = plus1 - minus1` と `plus1 - plus0 = minus0 - minus1 = 2 ulp` という事実を利用しています。
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ドラゴンフォールバックを使用した Grisu の最短モードの実装。
///
/// これはほとんどの場合に使用する必要があります。
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // 安全性: ボローチェッカーは、`buf` を使用できるほど賢くありません
    // 2 番目の branch で、ここでライフタイムを洗濯します。
    // ただし、`format_shortest_opt` が `None` を返した場合にのみ、`buf` を再利用するため、これで問題ありません。
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Grisu の正確な固定モードの実装。
///
/// それ以外の場合は不正確な表現を返す場合は `None` を返します。
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // 少なくとも 3 ビットの追加精度が必要です
    assert!(!buf.is_empty());

    // `v` を正規化およびスケーリングします。
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` を整数部分と小数部分に分割します。
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // 古い `v` と新しい `v` (`10^-k` でスケーリング) の両方に、1 ulp 未満のエラーがあります (定理 5.1)。
    // 誤差が正か負かわからないため、等間隔に配置された 2 つの近似を使用し、最大誤差は 2 ulps です (最短の場合と同じ)。
    //
    //
    // 目標は、`v - 1 ulp` と `v + 1 ulp` の両方に共通する正確に丸められた一連の数字を見つけて、最大限の自信を持てるようにすることです。
    // これが不可能な場合は、どちらが `v` の正しい出力であるかわからないため、あきらめてフォールバックします。
    //
    // `err` ここでは `1 ulp * 2^e` として定義され (`vfrac` の ulp と同じ)、`v` がスケーリングされるたびにスケーリングします。
    //
    //
    //
    let mut err = 1;

    // `v` (したがって `v < 10^(max_kappa+1)`) 以下の最大の `10^max_kappa` を計算します。
    // これは、以下の `kappa` の上限です。
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 最後の桁の制限を使用している場合は、二重丸めを回避するために、実際のレンダリングの前にバッファーを短くする必要があります。
    //
    // 切り上げが発生した場合は、バッファを再度拡大する必要があることに注意してください。
    let len = if exp <= limit {
        // おっと、私たちは *1* 桁を生成することさえできません。
        // これは、たとえば、9.5 のようなものがあり、10 に丸められている場合に可能です。
        //
        // 原則として、空のバッファーを使用して `possibly_round` をすぐに呼び出すことができますが、`max_ten_kappa << e` を 10 でスケーリングすると、オーバーフローが発生する可能性があります。
        //
        // したがって、ここではだらしなく、エラー範囲を 10 倍に広げています。
        // これにより、偽陰性率が増加しますが、ごくわずかです。
        // 仮数が 60 ビットより大きい場合にのみ顕著に問題になります。
        //
        // 安全性: `len=0` なので、このメモリを初期化する義務は簡単です。
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // 一体型パーツをレンダリングします。
    // エラーは完全に小数であるため、この部分でチェックする必要はありません。
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // まだレンダリングされていない数字
    loop {
        // 不変条件をレンダリングするために、常に少なくとも 1 桁の数字があります。
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (`remainder = vint % 10^(kappa+1)` に続く)
        //
        //

        // `remainder` を `10^kappa` で割ります。どちらも `2^-e` でスケーリングされます。
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // バッファがいっぱいですか? 余りで丸めパスを実行します。
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // == (v％10 ^ カッパ) * 2 ^ e
            // 安全性: `len` を何バイトも初期化しました。
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // すべての整数桁をレンダリングしたら、ループを解除します。
        // 正確な桁数は `max_kappa + 1` と `plus1 < 10^(max_kappa+1)` です。
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // 不変条件を復元する
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // 小数部分をレンダリングします。
    //
    // 原則として、利用可能な最後の桁まで続行して、正確さを確認できます。
    // 残念ながら、有限サイズの整数を使用しているため、オーバーフローを検出するための基準が必要です。
    // V8 `remainder > err` を使用します。これは、`v - 1 ulp` と `v` の最初の `i` 有効数字が異なる場合に false になります。
    // ただし、これにより、有効な入力が多すぎて拒否されます。
    //
    // 後のフェーズには正しいオーバーフロー検出があるため、代わりに、より厳密な基準を使用します。
    // `err` が `10^kappa / 2` を超えるまで続行するため、`v - 1 ulp` と `v + 1 ulp` の間の範囲には、2 つ以上の丸められた表現が確実に含まれます。
    //
    // これは、参考のために、`possibly_round` からの最初の 2 つの比較と同じです。
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // 不変量、ここで `m = max_kappa + 1` (整数部分の桁数) :
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // オーバーフローしません、 `2^e * 10 < 2^64`
        err *= 10; // オーバーフローしません、 `err * 10 < 2^e * 5 < 2^64`

        // `remainder` を `10^kappa` で割ります。
        // どちらも `2^e / 10^kappa` によってスケーリングされるため、後者はここでは暗黙的に示されています。
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // バッファがいっぱいですか? 余りで丸めパスを実行します。
        if i == len {
            // 安全性: `len` を何バイトも初期化しました。
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // 不変条件を復元する
        remainder = r;
    }

    // それ以上の計算は役に立たないので (`possibly_round` は間違いなく失敗します)、あきらめます。
    return None;

    // `v` の要求されたすべての数字を生成しました。これは、`v - 1 ulp` の対応する数字とも同じである必要があります。
    // ここで、`v - 1 ulp` と `v + 1 ulp` の両方で共有される一意の表現があるかどうかを確認します。これは、生成された数字、またはそれらの数字の切り上げバージョンのいずれかと同じである可能性があります。
    //
    // 範囲に同じ長さの複数の表現が含まれている場合、確信が持てないため、代わりに `None` を返す必要があります。
    //
    // ここでのすべての引数は、共通の (ただし暗黙の) 値 `k` によってスケーリングされるため、次のようになります。
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // 安全性: `buf` の最初の `len` バイトを初期化する必要があります。
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (参考までに、点線は指定された桁数で可能な表現の正確な値を示しています。)
        //
        //
        // エラーが大きすぎるため、`v - 1 ulp` と `v + 1 ulp` の間に少なくとも 3 つの可能な表現があります。
        // どちらが正しいかを判断することはできません。
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // 実際、1/2 ulp は、2 つの可能な表現を導入するのに十分です。
        // (`v - 1 ulp` と `v + 1 ulp` の両方に一意の表現が必要であることを忘れないでください。) 最初のチェックの `ulp < ten_kappa` のように、これはオーバーフローしません。
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // `v + 1 ulp` が切り捨てられた表現 (すでに `buf` にある) に近い場合は、安全に戻ることができます。
        // `v - 1 ulp` は現在の表現よりも小さくすることができますが、`1 ulp < 10^kappa / 2` としては、この条件で十分であることに注意してください。
        // `v - 1 ulp` と現在の表現の間の距離は `10^kappa / 2` を超えることはできません。
        //
        // 条件は `remainder + ulp < 10^kappa / 2` に等しくなります。
        // これは簡単にオーバーフローする可能性があるため、最初に `remainder < 10^kappa / 2` かどうかを確認してください。
        // `ulp < 10^kappa / 2` はすでに検証済みですが、`10^kappa` がオーバーフローしない限り、2 番目のチェックは問題ありません。
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // 安全性: 呼び出し元がそのメモリを初期化しました。
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <------- 残り --- ---> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // 一方、`v - 1 ulp` が切り上げられた表現に近い場合は、切り上げて戻る必要があります。
        // 同じ理由で、`v + 1 ulp` をチェックする必要はありません。
        //
        // 条件は `remainder - ulp >= 10^kappa / 2` に等しくなります。
        // ここでも、最初に `remainder > ulp` かどうかを確認します (`10^kappa` がゼロになることはないため、これは `remainder >= ulp` ではないことに注意してください)。
        //
        // また、`remainder - ulp <= 10^kappa` であるため、2 番目のチェックがオーバーフローしないことにも注意してください。
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // 安全性: 呼び出し元はそのメモリを初期化しておく必要があります。
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // 固定精度が要求された場合にのみ、数字を追加します。
                // また、元のバッファが空の場合、`exp == limit` (edge の場合) の場合にのみ追加の桁を追加できることを確認する必要があります。
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // 安全性: 私たちと私たちの呼び出し元はそのメモリを初期化しました。
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // そうでなければ、私たちは運命にあり (つまり、`v - 1 ulp` と `v + 1 ulp` の間のいくつかの値は切り捨てられ、他の値は切り上げられます)、あきらめます。
        //
        None
    }
}

/// ドラゴンフォールバックを使用した Grisu の正確な固定モードの実装。
///
/// これはほとんどの場合に使用する必要があります。
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // 安全性: ボローチェッカーは、`buf` を使用できるほど賢くありません
    // 2 番目の branch で、ここでライフタイムを洗濯します。
    // ただし、`format_exact_opt` が `None` を返した場合にのみ、`buf` を再利用するため、これで問題ありません。
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}