//! 「浮動小数点数の迅速かつ正確な印刷」[^ 1] の図 3 のほぼ直接的な (ただしわずかに最適化された) Rust 変換。
//!
//!
//! [^1]: Burger, RG および Dybvig、RK1996。浮動小数点数の印刷。
//!   迅速かつ正確に。SIGPLAN ではありません。31、5 (1996 年 5 月)、108-116。

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) の `Digit` の事前計算された配列
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` の場合にのみ使用できます。`scaleN` は `scale.mul_small(N)` である必要があります
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Dragon の最短モードの実装。
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // フォーマットする `v` の数は次のようになっています。
    // - `mant * 2^exp` に等しい;
    // - 元のタイプの `(mant - 2 *minus)* 2^exp` が前に付きます。そして
    // - 元のタイプの `(mant + 2 *plus)* 2^exp` が続きます。
    //
    // 明らかに、`minus` と `plus` をゼロにすることはできません。(無限大の場合、範囲外の値を使用します。) また、少なくとも 1 桁が生成されると想定します。つまり、`mant` もゼロにすることはできません。
    //
    // これは、`low = (mant - minus)*2^exp` と `high = (mant + plus)* 2^exp` の間の任意の数がこの正確な浮動小数点数にマップされ、元の仮数が偶数の場合 (つまり、`!mant_was_odd`) に境界が含まれることも意味します。
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` です
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` を満たす元の入力から `k_0` を推定します。
    // `10^(k-1) < high <= 10^k` を満たすタイトバウンド `k` は後で計算されます。
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` を分数形式に変換して、次のようにします。
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` を `10^k` で割ります。今 `scale / 10 < mant + plus <= scale * 10`。
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (または `>=`) の場合の修正。
    // 代わりに最初の乗算をスキップできるため、実際には `scale` を変更していません。
    // これで `scale < mant + plus <= scale * 10` になり、数字を生成する準備が整いました。
    //
    // `scale - plus < mant < scale` の場合、`d[0]` はゼロになる可能性があることに注意してください。
    // この場合、切り上げ条件 (以下の `up`) がすぐにトリガーされます。
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` を 10 でスケーリングするのと同等
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 桁生成用に `(2, 4, 8) * scale` をキャッシュします。
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` はこれまでに生成された数字である不変量:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (したがって `mant / scale < 10`) ここで、`d[i..j]` は `d [i] * 10 ^ (ji) + .. の省略形です。
        // + d [j-1] * 10 + d[j]`。

        // 1 桁を生成します: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // これは、変更された Dragon アルゴリズムの簡単な説明です。
        // 多くの中間的な導出と完全性の議論は、便宜上省略されています。
        //
        // `n` を更新したので、変更された不変条件から始めます。
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `d[0..n-1]` が `low` と `high` の間の最短表現であると想定します。つまり、`d[0..n-1]` は次の両方を満たしますが、`d[0..n-2]` は満たしていません。
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (双方向性: 数字は `v` に丸められます) ; そして
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (最後の桁は正しいです)。
        //
        // 2 番目の条件は `2 * mant <= scale` に単純化されます。
        // `mant`、`low`、および `high` に関して不変条件を解くと、最初の条件のより単純なバージョンが生成されます。`-plus < mant < minus`.
        // `-plus < 0 <= mant` 以降、`mant < minus` と `2 * mant <= scale` の場合の正しい最短表現があります。
        // (前者は、元の仮数が偶数の場合、`mant <= minus` になります。)
        //
        // 2 番目が成り立たない場合 ( `2 * mant> scale`)、最後の桁を増やす必要があります。
        // これは、その状態を復元するのに十分です。数字の生成によって `0 <= v / 10^(k-n) - d[0..n-1] < 1` が保証されることはすでにわかっています。
        // この場合、最初の条件は `-plus < mant - scale < minus` になります。
        // 生成後の `mant < scale` 以降、`scale < mant + plus` があります。
        // (ここでも、元の仮数が偶数の場合、これは `scale <= mant + plus` になります。)
        //
        // 要するに:
        // - `mant < minus` (または `<=`) の場合は、`down` を停止して丸めます (数字はそのままにします)。
        // - `scale < mant + plus` (または `<=`) の場合、`up` を停止して丸めます (最後の桁を増やします)。
        // - それ以外の場合は生成を続けます。
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // 表現が最も短いので、丸めに進みます

        // 不変条件を復元します。
        // これにより、アルゴリズムは常に終了します。`minus` と `plus` は常に増加しますが、`mant` は `scale` を法としてクリップされ、`scale` は修正されます。
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // 切り上げは、i) 切り上げ条件のみがトリガーされた場合、または ii) 両方の条件がトリガーされ、タイブレークが切り上げを優先する場合に発生します。
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // 切り上げによって長さが変わる場合は、指数も変わるはずです。
        // この条件を満たすのは非常に難しい (おそらく不可能) ようですが、ここでは安全で一貫性があります。
        //
        // 安全性: 上記のメモリを初期化しました。
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // 安全性: 上記のメモリを初期化しました。
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Dragon の正確な固定モードの実装。
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` を満たす元の入力から `k_0` を推定します。
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` を `10^k` で割ります。今 `scale / 10 < mant <= scale * 10`。
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` の場合の修正、ここで `plus / scale = 10^-buf.len() / 2`。
    // 固定サイズの bignum を維持するために、実際には `mant + floor(plus) >= scale` を使用します。
    // 代わりに最初の乗算をスキップできるため、実際には `scale` を変更していません。
    // ここでも最短のアルゴリズムを使用すると、`d[0]` はゼロになる可能性がありますが、最終的には切り上げられます。
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` を 10 でスケーリングするのと同等
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // 最後の桁の制限を使用している場合は、二重丸めを回避するために、実際のレンダリングの前にバッファーを短くする必要があります。
    //
    // 切り上げが発生した場合は、バッファを再度拡大する必要があることに注意してください。
    let mut len = if k < limit {
        // おっと、私たちは *1* 桁を生成することさえできません。
        // これは、たとえば、9.5 のようなものがあり、10 に丸められている場合に可能です。
        // `k == limit` のときに発生し、正確に 1 桁を生成する必要がある後の切り上げの場合を除いて、空のバッファーを返します。
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // 桁生成用に `(2, 4, 8) * scale` をキャッシュします。
        // (これはコストがかかる可能性があるため、バッファーが空のときに計算しないでください。)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // 次の桁はすべてゼロです。ここで停止します。丸めを実行しようとしないでください。むしろ、残りの桁を埋めます。
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // 安全性: 上記のメモリを初期化しました。
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // 次の桁が正確に 5000 の場合、桁の途中で停止した場合は切り上げます...、前の桁を確認し、偶数に丸めてみます (つまり、前の桁が偶数の場合は切り上げを避けます)。
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // 安全性: `buf[len-1]` が初期化されます。
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // 切り上げによって長さが変わる場合は、指数も変わるはずです。
        // ただし、固定桁数が要求されているため、バッファを変更しないでください...
        // 安全性: 上記のメモリを初期化しました。
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... 代わりに固定精度が要求されていない限り。
            // また、元のバッファが空の場合、`k == limit` (edge の場合) の場合にのみ追加の桁を追加できることを確認する必要があります。
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // 安全性: 上記のメモリを初期化しました。
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}