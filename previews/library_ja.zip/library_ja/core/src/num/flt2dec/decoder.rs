//! 浮動小数点値を個々の部分とエラー範囲にデコードします。

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// 次のようなデコードされた符号なし有限値:
///
/// - 元の値は `mant * 2^exp` に等しくなります。
///
/// - `(mant - minus)*2^exp` から `(mant + plus)* 2^exp` までの数値は、元の値に丸められます。
/// 範囲は、`inclusive` が `true` の場合にのみ含まれます。
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// スケーリングされた仮数。
    pub mant: u64,
    /// 低いエラー範囲。
    pub minus: u64,
    /// エラーの上限範囲。
    pub plus: u64,
    /// 基数 2 の共有指数。
    pub exp: i16,
    /// エラー範囲が含まれる場合は True。
    ///
    /// IEEE 754 では、これは元の仮数が偶数であったときに当てはまります。
    pub inclusive: bool,
}

/// デコードされた符号なしの値。
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// 正または負の無限大。
    Infinite,
    /// ゼロ、正または負のいずれか。
    Zero,
    /// さらにデコードされたフィールドを持つ有限数。
    Finite(Decoded),
}

/// `デコード` できる浮動小数点型。
pub trait DecodableFloat: RawFloat + Copy {
    /// 正の正規化された最小値。
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// 指定された浮動小数点数から符号 (負の場合は true) と `FullDecoded` 値を返します。
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ネイバー: (mant、2、exp) - (mant、exp) - (mant + 2、exp)
            // Float::integer_decode 常に指数を保持するため、仮数は非正規化数に合わせてスケーリングされます。
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ネイバー: (maxmant、exp、1) - (minnormmant、exp) - (minnormmant + 1、exp)
                // ここで、maxmant=minnormmant * 2、1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ネイバー: (mant、1、exp) - (mant、exp) - (mant + 1、exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}