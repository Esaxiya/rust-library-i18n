/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// これは広範囲にわたって文書化されていますが、これは原則として非公開であり、テストのためにのみ公開されています。
// 私たちをさらさないでください。
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// 数字生成アルゴリズム。
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// 最短モードに必要なバッファの最小サイズ。
///
/// 導出するのは少し簡単ではありませんが、これは 1 に、フォーマットアルゴリズムからの有効な 10 進数の最大数を加えたものであり、結果は最短になります。
///
/// 正確な式は `ceil(# bits in mantissa * log_10 2 + 1)` です。
pub const MAX_SIG_DIGITS: usize = 17;

/// `d` に 10 進数が含まれている場合は、最後の桁を増やしてキャリーを伝搬します。
/// 長さが変化すると、次の桁を返します。
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] はすべて 9 です
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 指数を増やして 1000..000 に丸めます
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // 空のバッファは切り上げられます (少し奇妙ですが合理的です)
            Some(b'1')
        }
    }
}

/// フォーマットされたパーツ。
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// 与えられたゼロ桁数。
    Zero(usize),
    /// 5 桁までのリテラル数。
    Num(u16),
    /// 指定されたバイトの逐語的なコピー。
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// 指定された部分の正確なバイト長を返します。
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// 指定されたバッファにパーツを書き込みます。
    /// 書き込まれたバイト数を返します。バッファが十分でない場合は `None` を返します。
    /// (それでも部分的に書き込まれたバイトがバッファに残る可能性があります。それに依存しないでください。)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// 1 つ以上のパーツを含むフォーマットされた結果。
/// これは、バイトバッファに書き込むか、割り当てられた文字列に変換できます。
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`、`"-"`、または `"+"` のいずれかの符号を表すバイトスライス。
    pub sign: &'static str,
    /// 記号とオプションのゼロパディングの後にレンダリングされるフォーマット済みパーツ。
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// 結合されたフォーマット済み結果の正確なバイト長を返します。
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// フォーマットされたすべてのパーツを、指定されたバッファーに書き込みます。
    /// 書き込まれたバイト数を返します。バッファが十分でない場合は `None` を返します。
    /// (それでも部分的に書き込まれたバイトがバッファに残る可能性があります。それに依存しないでください。)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// 指定された 10 進数 `0.<...buf...> * 10^exp` を、少なくとも指定された小数桁数の 10 進数形式にフォーマットします。
///
/// 結果は提供されたパーツ配列に格納され、書き込まれたパーツのスライスが返されます。
///
/// `frac_digits` `buf` の実際の小数桁数より少なくすることができます。
/// 無視され、全桁が出力されます。レンダリングされた数字の後に追加のゼロを印刷するためにのみ使用されます。
/// したがって、`frac_digits` が 0 の場合は、指定された数字のみを出力し、他には何も出力しないことを意味します。
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // 最後の桁の位置に制限がある場合、`buf` には仮想ゼロが左に埋め込まれていると見なされます。
    // 仮想ゼロの数 `nzeroes` は `max(0, exp + frac_digits - buf.len())` に等しいため、最後の桁 `exp - buf.len() - nzeroes` の位置は `-frac_digits` 以下です。
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> | ゼロ | exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` オーバーフローを回避するために、ケースごとに個別に計算されます。
    //

    if exp <= 0 {
        // 小数点はレンダリングされた数字の前にあります: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // 安全性: 要素 `..4` を初期化しました。
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // 安全性: 要素 `..3` を初期化しました。
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // 小数点はレンダリングされた数字の内側にあります。[12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // 安全性: 要素 `..4` を初期化しました。
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // 安全性: 要素 `..3` を初期化しました。
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // 小数点はレンダリングされた数字の後にあります: [1234][____0000] または [1234][__][.][__]。
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // 安全性: 要素 `..4` を初期化しました。
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // 安全性: 要素 `..2` を初期化しました。
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// 指定された 10 進数 `0.<...buf...> * 10^exp` を、少なくとも指定された有効桁数の指数形式にフォーマットします。
///
/// `upper` が `true` の場合、指数の前には `E` が付きます。それ以外の場合は `e` です。
/// 結果は提供されたパーツ配列に格納され、書き込まれたパーツのスライスが返されます。
///
/// `min_digits` `buf` の実際の有効桁数より少なくすることができます。
/// 無視され、全桁が出力されます。レンダリングされた数字の後に追加のゼロを印刷するためにのみ使用されます。
/// したがって、`min_digits == 0` は、指定された数字のみを印刷し、他には何も印刷しないことを意味します。
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // exp が i16::MIN の場合、アンダーフローを回避します
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // 安全性: 要素 `..n + 2` を初期化しました。
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// 書式設定オプションに署名します。
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// ゼロ以外の負の値に対してのみ `-` を出力します。
    Minus, // -inf -1 0 0 1 inf nan
    /// 負の値 (負のゼロを含む) に対してのみ `-` を出力します。
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// ゼロ以外の負の値の場合は `-` を出力し、それ以外の場合は `+` を出力します。
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// 負の値 (負のゼロを含む) の場合は `-` を出力し、それ以外の場合は `+` を出力します。
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// フォーマットする符号に対応する静的バイト文字列を返します。
/// `""`、`"+"`、または `"-"` のいずれかです。
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// 指定された浮動小数点数を、少なくとも指定された小数桁数の 10 進形式にフォーマットします。
/// 結果は、指定されたバイトバッファーをスクラッチとして使用しながら、指定されたパーツ配列に格納されます。
/// `upper` 現在は使用されていませんが、future が非有限値、つまり `inf` と `nan` の大文字と小文字を変更する決定を下すために残されています。
///
/// レンダリングされる最初の部分は常に `Part::Sign` です (記号がレンダリングされていない場合は空の文字列になる可能性があります)。
///
/// `format_shortest` 基礎となる数字生成機能である必要があります。
/// 初期化したバッファの部分を返す必要があります。
/// あなたはおそらくこれのために `strategy::grisu::format_shortest` が欲しいでしょう。
///
/// `frac_digits` `v` の実際の小数桁数より少なくすることができます。
/// 無視され、全桁が出力されます。レンダリングされた数字の後に追加のゼロを印刷するためにのみ使用されます。
/// したがって、`frac_digits` が 0 の場合は、指定された数字のみを出力し、他には何も出力しないことを意味します。
///
/// バイトバッファは、少なくとも `MAX_SIG_DIGITS` バイトの長さである必要があります。
/// `[+][0.][0000][2][0000]` と `frac_digits = 10` のような最悪のケースのため、少なくとも 4 つのパーツが利用可能である必要があります。
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // 安全性: 要素 `..2` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // 安全性: 要素 `..1` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// 結果の指数に応じて、指定された浮動小数点数を 10 進形式または指数形式にフォーマットします。
/// 結果は、指定されたバイトバッファーをスクラッチとして使用しながら、指定されたパーツ配列に格納されます。
/// `upper` は、非有限値 (`inf` および `nan`) の場合、または指数接頭辞 (`e` または `E`) の場合を判別するために使用されます。
/// レンダリングされる最初の部分は常に `Part::Sign` です (記号がレンダリングされていない場合は空の文字列になる可能性があります)。
///
/// `format_shortest` 基礎となる数字生成機能である必要があります。
/// 初期化したバッファの部分を返す必要があります。
/// あなたはおそらくこれのために `strategy::grisu::format_shortest` が欲しいでしょう。
///
/// `dec_bounds` はタプル `(lo, hi)` であり、`10^lo <= V < 10^hi` の場合にのみ数値が 10 進数としてフォーマットされます。
/// これは実際の `v` ではなく *見かけの*`V` であることに注意してください。したがって、指数形式で印刷された指数をこの範囲に含めることはできず、混乱を避けることができます。
///
///
/// バイトバッファは、少なくとも `MAX_SIG_DIGITS` バイトの長さである必要があります。
/// `[+][1][.][2345][e][-][6]` のような最悪のケースのため、少なくとも 6 つのパーツが利用可能である必要があります。
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// 指定されたデコードされた指数から計算された最大バッファーサイズのかなり大まかな近似 (上限) を返します。
///
/// 正確な制限は次のとおりです。
///
/// - `exp < 0` の場合、最大長は `ceil(log_10 (5^-exp * (2^64 - 1)))` です。
/// - `exp >= 0` の場合、最大長は `ceil(log_10 (2^exp * (2^64 - 1)))` です。
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` は `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` 未満であり、`ceil(log_10 (2^64 - 1)) + ceil(exp* log_10 x)` は `20 + (1 + exp * log_10 x)` 未満です。
/// `log_10 2 < 5/16` と `log_10 5 < 12/16` という事実を使用します。これは私たちの目的には十分です。
///
/// なぜ私たちはこれが必要なのですか? `format_exact` 関数は、最後の桁の制限によって制限されない限り、バッファー全体を埋めますが、要求される桁数が途方もなく多い (たとえば、30,000 桁) 可能性があります。
///
/// バッファの大部分はゼロで埋められるため、事前にすべてのバッファを割り当てる必要はありません。
/// したがって、任意の引数について、
/// `f64` には、826 バイトのバッファで十分です。これを最悪の場合の実際の数である 770 バイト (`exp = -1074` の場合) と比較してください。
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// 指定された浮動小数点数を、正確に指定された有効桁数の指数形式にフォーマットします。
/// 結果は、指定されたバイトバッファーをスクラッチとして使用しながら、指定されたパーツ配列に格納されます。
/// `upper` 指数接頭辞 (`e` または `E`) の大文字と小文字を判別するために使用されます。
/// レンダリングされる最初の部分は常に `Part::Sign` です (記号がレンダリングされていない場合は空の文字列になる可能性があります)。
///
/// `format_exact` 基礎となる数字生成機能である必要があります。
/// 初期化したバッファの部分を返す必要があります。
/// あなたはおそらくこれのために `strategy::grisu::format_exact` が欲しいでしょう。
///
/// `ndigits` が大きすぎて固定桁数しか書き込まれない場合を除いて、バイトバッファは少なくとも `ndigits` バイト長である必要があります。
/// (`f64` の転換点は約 800 なので、1000 バイトで十分です。) `[+][1][.][2345][e][-][6]` のような最悪のケースのため、少なくとも 6 つのパーツが使用可能である必要があります。
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // 安全性: 要素 `..3` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // 安全性: 要素 `..1` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// 指定された浮動小数点数を、正確に指定された小数桁数の 10 進形式にフォーマットします。
/// 結果は、指定されたバイトバッファーをスクラッチとして使用しながら、指定されたパーツ配列に格納されます。
/// `upper` 現在は使用されていませんが、future が非有限値、つまり `inf` と `nan` の大文字と小文字を変更する決定を下すために残されています。
/// レンダリングされる最初の部分は常に `Part::Sign` です (記号がレンダリングされていない場合は空の文字列になる可能性があります)。
///
/// `format_exact` 基礎となる数字生成機能である必要があります。
/// 初期化したバッファの部分を返す必要があります。
/// あなたはおそらくこれのために `strategy::grisu::format_exact` が欲しいでしょう。
///
/// `frac_digits` が大きすぎて固定桁数しか書き込まれない場合を除いて、出力にはバイトバッファで十分です。
/// (`f64` の転換点は約 800 で、1000 バイトで十分です。) `[+][0.][0000][2][0000]` と `frac_digits = 10` のような最悪のケースのため、少なくとも 4 つのパーツが使用可能である必要があります。
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // 安全性: 要素 `..1` を初期化しました。
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // 安全性: 要素 `..2` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // 安全性: 要素 `..1` を初期化しました。
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // `frac_digits` が途方もなく大きい可能性があります。
            // `format_exact` この場合、`maxlen` によって厳密に制限されているため、数字のレンダリングははるかに早く終了します。
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // 制限を満たすことができなかったので、`exp` があったとしても、これはゼロのようにレンダリングされるはずです。
                // これには、最終的な切り上げ後にのみ制限が満たされた場合は含まれません。これは `exp = limit + 1` の通常のケースです。
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // 安全性: 要素 `..2` を初期化しました。
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // 安全性: 要素 `..1` を初期化しました。
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}