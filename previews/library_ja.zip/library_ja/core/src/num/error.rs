//! 整数型への変換のエラー型。

use crate::convert::Infallible;
use crate::fmt;

/// チェックされた整数型変換が失敗したときに返されるエラー型。
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` が `!` のエイリアスになったときに、上記の `From<Infallible> for TryFromIntError` のようなコードが機能し続けることを確認するために、強制するのではなく一致させます。
        //
        //
        match never {}
    }
}

/// 整数を解析するときに返される可能性のあるエラー。
///
/// このエラーは、[`i8::from_str_radix`] などのプリミティブ整数型の `from_str_radix()` 関数のエラー型として使用されます。
///
/// # 考えられる原因
///
/// 他の原因の中でも、`ParseIntError` は、文字列の先頭または末尾の空白が原因でスローされる可能性があります。たとえば、標準入力から取得された場合などです。
///
/// [`str::trim()`] メソッドを使用すると、解析前に空白が残らないようになります。
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// 整数の解析が失敗する原因となる可能性のあるさまざまなタイプのエラーを格納する列挙型。
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// 解析される値は空です。
    ///
    /// 他の原因の中でも、このバリアントは空の文字列を解析するときに作成されます。
    Empty,
    /// コンテキストに無効な数字が含まれています。
    ///
    /// 他の原因の中でも、このバリアントは、非 ASCII 文字を含む文字列を解析するときに作成されます。
    ///
    /// このバリアントは、`+` または `-` がそれ自体で、または数値の途中で文字列内に誤って配置された場合にも作成されます。
    ///
    ///
    InvalidDigit,
    /// 整数が大きすぎて、ターゲットの整数型に格納できません。
    PosOverflow,
    /// 整数が小さすぎて、ターゲットの整数型に格納できません。
    NegOverflow,
    /// 値はゼロでした
    ///
    /// このバリアントは、解析文字列の値がゼロの場合に発行されます。これは、ゼロ以外のタイプでは無効です。
    ///
    Zero,
}

impl ParseIntError {
    /// 整数の解析に失敗した詳細な原因を出力します。
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}