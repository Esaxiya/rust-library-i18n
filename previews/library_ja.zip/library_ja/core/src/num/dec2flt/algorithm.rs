//! 論文からのさまざまなアルゴリズム。

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp の仮数ビット数
const P: u32 = 64;

// *すべての* 指数の最適な近似値を格納するだけなので、変数 "h" および関連する条件は省略できます。
// これは、パフォーマンスを数キロバイトのスペースと交換します。

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// ほとんどのアーキテクチャでは、浮動小数点演算には明示的なビットサイズがあるため、計算の精度は演算ごとに決定されます。
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 では、SSE/SSE2 拡張機能が使用できない場合、x87 FPU がフロート操作に使用されます。
// x87 FPU は、デフォルトで 80 ビットの精度で動作します。つまり、演算は 80 ビットに丸められ、値が最終的に次のように表されるときに倍精度が発生します。
//
// 32/64 ビット浮動小数点値。これを克服するために、FPU 制御ワードを設定して、計算が目的の精度で実行されるようにすることができます。
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// FPU 制御ワードの元の値を保持するために使用される構造体。これにより、構造体がドロップされたときに復元できます。
    ///
    ///
    /// x87 FPU は、フィールドが次の 16 ビットレジスタです。
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// すべてのフィールドのドキュメントは、IA-32 アーキテクチャソフトウェア開発者マニュアル (第 1 巻) にあります。
    ///
    /// 次のコードに関連する唯一のフィールドは、PC、PrecisionControl です。
    /// このフィールドは、FPU によって実行される操作の精度を決定します。
    /// 次のように設定できます。
    ///  - 0b00、単精度、つまり 32 ビット
    ///  - 0b10、倍精度、つまり 64 ビット
    ///  - 0b11、二重拡張精度、つまり 80 ビット (デフォルト状態) 0b01 値は予約されているため、使用しないでください。
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // 安全性: `fldcw` 命令は、正しく機能するように監査されています
        // 任意の `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: LLVM8 と LLVM9 をサポートするために ATT 構文を使用しています。
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU の精度フィールドを `T` に設定し、`FPUControlWord` を返します。
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // `T` に適切な PrecisionControl フィールドの値を計算します。
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ビット
            8 => 0x0200, // 64 ビット
            _ => 0x0300, // デフォルト、80 ビット
        };

        // `FPUControlWord` 構造体がドロップされたときに、制御ワードの元の値を取得して後で復元します。安全性: `fnstcw` 命令は、任意の `u16` で正しく機能するように監査されています。
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: LLVM8 と LLVM9 をサポートするために ATT 構文を使用しています。
                options(att_syntax, nostack),
            )
        }

        // 制御ワードを希望の精度に設定します。
        // これは、古い精度 (ビット 8 および 9、0x300) をマスクして、上記で計算された精度フラグに置き換えることで実現されます。
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// マシンサイズの整数と浮動小数点数を使用した Bellerophon の高速パス。
///
/// これは別の関数に抽出されるため、bignum を作成する前に試行できます。
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) 〜15.95。
    // 正確な値を最後の方で MAX_SIG と比較します。これは、迅速で安価な拒否です (また、残りのコードをアンダーフローの心配から解放します)。
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // 高速パスは、中間の丸めなしで正しいビット数に丸められる算術に大きく依存します。
    // x86 (SSE または SSE2 なし) では、x87 FPU スタックの精度を変更して、64/32 ビットに直接丸める必要があります。
    // `set_precision` 関数は、グローバル状態を変更することによって精度を設定する必要があるアーキテクチャの精度の設定を処理します (x87 FPU の制御ワードなど)。
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // e <0 の場合、他の branch に折りたたむことはできません。
    // 負の累乗は、2 進数で小数部分を繰り返し、丸められます。これにより、最終結果で実際の (場合によっては非常に重要な) エラーが発生します。
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// アルゴリズム Bellerophon は、自明ではない数値解析によって正当化される自明なコードです。
///
/// ``f`` を 64 ビット仮数の float に丸め、`10^e` の最良の近似値 (同じ浮動小数点形式) で乗算します。多くの場合、これで正しい結果を得ることができます。
/// ただし、結果が 2 つの隣接する (ordinary) フロートの中間に近い場合、2 つの近似値を乗算することによる複合丸め誤差は、結果が数ビットずれている可能性があることを意味します。
/// これが発生すると、反復アルゴリズム R が問題を修正します。
///
/// 手で波打つ "close to halfway" は、紙の数値解析によって正確に作られています。
/// クリンガーの言葉で:
///
/// > 最下位ビットの単位で表されるスロップは、エラーの包括的境界です。
/// > f * 10 ^ e の近似の浮動小数点計算中に累積されます。(スロップは
/// > 真の誤差の範囲ではありませんが、近似 z との差を制限します
/// > 仮数の p ビットを使用する可能な限り最良の近似。)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) の場合は fast_path() にあります
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // スロップは、n ビットに丸めるときに違いを生むのに十分な大きさですか?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// `f * 10^e` の浮動小数点近似を改善する反復アルゴリズム。
///
/// 各反復は、最後の場所で 1 つのユニットを近づけます。もちろん、`z0` が少しでもずれている場合、収束するのに非常に長い時間がかかります。
/// 幸い、Bellerophon のフォールバックとして使用すると、開始時の近似値は最大で 1 つの ULP だけずれます。
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // `x / y` が正確に `(f *10^e) / (m* 2^k)` になるように、正の整数 `x`、`y` を見つけます。
        // これにより、`e` と `k` の符号の処理が回避されるだけでなく、`10^e` と `2^k` に共通する 2 つの累乗がなくなり、数値が小さくなります。
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // bignum は負の数をサポートしていないため、これは少し厄介に書かれているため、絶対値 + 符号情報を使用します。
        // m_digits との乗算はオーバーフローできません。
        // `x` または `y` がオーバーフローを心配する必要があるほど大きい場合は、`make_ratio` が分数を 2 ^ 64 以上削減するのに十分な大きさでもあります。
        //
        //
        let (d2, d_negative) = if x >= y {
            // X はもう必要ありません。clone() を保存してください。
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // まだ y が必要です、コピーを作成してください。
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// `x = f` と `y = m` が与えられ、`f` は通常どおり入力小数桁を表し、`m` は浮動小数点近似の仮数であるため、比率 `x / y` を `(f *10^e) / (m* 2^k)` に等しくし、2 の累乗で減らすことができます。
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e、y=m* 2 ^ k ですが、分数を 2 の累乗で減らす点が異なります。
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)、y=m 正の `e` と負の `k` が必要なため、オーバーフローすることはありません。これは、1 に非常に近い値でのみ発生する可能性があります。つまり、`e` と `k` は比較的小さくなります。
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f、y=m *10^abs(e)* 2 ^ k これもオーバーフローできません。上記を参照してください。
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k)、y=m* 10^abs(e)、ここでも 2 の一般的な累乗で減少します。
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// 概念的には、アルゴリズム M は、小数を浮動小数点に変換する最も簡単な方法です。
///
/// `f * 10^e` に等しい比率を形成し、有効な浮動小数点仮数が得られるまで 2 の累乗を投入します。
/// 2 進指数 `k` は、分子または分母に 2 を掛けた回数です。つまり、常に `f *10^e` は `(u / v)* 2^k` に等しくなります。
/// 仮数が見つかったら、除算の残りの部分を調べることによって丸めるだけで済みます。これは、さらに下のヘルパー関数で実行されます。
///
///
/// このアルゴリズムは、`quick_start()` で説明されている最適化を使用しても、非常に低速です。
/// ただし、オーバーフロー、アンダーフロー、および異常な結果に適応するのは、最も単純なアルゴリズムです。
/// この実装は、Bellerophon と AlgorithmR が圧倒されたときに引き継ぎます。
/// アンダーフローとオーバーフローの検出は簡単です。比率はまだ範囲内の仮数ではありませんが、minimum/maximum 指数に達しています。
/// オーバーフローの場合、単に無限大を返します。
///
/// アンダーフローと非正規化数の処理は注意が必要です。
/// 大きな問題の 1 つは、最小の指数では、比率が仮数に対して大きすぎる可能性があることです。
/// 詳細については、underflow() を参照してください。
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME の可能な最適化: big_to_fp を一般化して、二重丸めなしでのみ、ここで fp_to_float(big_to_fp(u)) と同等の処理を実行できるようにします。
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // 最小の指数で停止する必要があります。`k < T::MIN_EXP_INT` まで待つと、2 倍オフになります。
            // 残念ながら、これは、最小の指数を持つ正規数を特殊なケースにする必要があることを意味します。
            // FIXME はよりエレガントな定式化を見つけますが、`tiny-pow10` テストを実行して、それが実際に正しいことを確認してください。
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// ビット長をチェックすることにより、ほとんどのアルゴリズム M の反復をスキップします。
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // ビット長は、2 を底とする対数の推定値であり、log(u / v) = log(u)、log(v) です。
    // 推定値は最大で 1 ずれていますが、常に過小評価であるため、log(u) と log(v) のエラーは同じ符号であり、キャンセルされます (両方が大きい場合)。
    // したがって、log(u / v) のエラーも最大で 1 つです。
    // 目標比率は、u/v が範囲内の仮数にある比率です。したがって、終了条件は、log2(u / v) が仮数ビット、plus/minus が仮数ビットです。
    // FIXME 2 番目のビットを見ると、見積もりが改善され、さらに分割されるのを防ぐことができます。
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // アンダーフローまたは異常。main 関数にお任せください。
            break;
        }
        if *k == T::MAX_EXP_INT {
            // オーバーフロー。main 関数にお任せください。
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // 比率は最小の指数を持つ範囲内の仮数ではないため、余分なビットを四捨五入し、それに応じて指数を調整する必要があります。
    // 実際の値は次のようになります。
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q 切り捨て。(rem で表されます)
    //
    // したがって、四捨五入されたビットが! = 0.5 ULP の場合、四捨五入は独自に決定します。
    // それらが等しく、残りがゼロ以外の場合でも、値を切り上げる必要があります。
    // 四捨五入されたビットが 1/2 で、余りがゼロの場合にのみ、半分から偶数の状況になります。
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// 通常の四捨五入、除算の余りに基づいて四捨五入する必要があるため難読化されています。
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}