//! メソッドに変換するのにあまり意味がない bignum のユーティリティ関数。

// FIXME 他のモジュールも `core::num` をインポートするため、このモジュールの名前は少し残念です。

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` よりも重要度の低いすべてのビットを切り捨てると、0.5 ULP よりも小さい、等しい、または大きい相対誤差が発生するかどうかをテストします。
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // 残りのすべてのビットがゼロの場合は = 0.5 ULP、それ以外の場合は > 0.5 ビットがない場合 (half_bit==0)、以下も正しく Equal を返します。
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// 10 進数のみを含む ASCII 文字列を `u64` に変換します。
///
/// オーバーフローまたは無効な文字のチェックを実行しないため、呼び出し元が注意しないと、結果は偽であり、panic になる可能性があります (ただし、`unsafe` にはなりません)。
/// さらに、空の文字列はゼロとして扱われます。
/// この機能が存在するのは
///
/// 1. `&[u8]` で `FromStr` を使用するには、`from_utf8_unchecked` が必要ですが、これは悪いことです。
/// 2. `integral.parse()` と `fractional.parse()` の結果をつなぎ合わせるのは、この関数全体よりも複雑です。
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII 数字の文字列を bignum に変換します。
///
/// `from_str_unchecked` と同様に、この関数はパーサーに依存して非数字を取り除きます。
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// bignum を 64 ビット整数にアンラップします。数が多すぎる場合は Panics。
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// ビットの範囲を抽出します。

/// インデックス 0 は最下位ビットであり、範囲は通常どおりハーフオープンです。
/// Panics は、戻りタイプに収まらないより多くのビットを抽出するように要求された場合。
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}