//! 次の形式の 10 進文字列の検証と分解:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! 言い換えると、2 つの例外を除いて、標準の浮動小数点構文です。符号なし、および "inf" と "NaN" の処理なしです。これらは、ドライバー関数 (super::dec2flt) によって処理されます。
//!
//! 有効な入力の認識は比較的簡単ですが、このモジュールは無数の無効なバリエーションを拒否し、panic を拒否し、他のモジュールが panic (またはオーバーフロー) を行わないように多数のチェックを実行する必要があります。
//!
//! さらに悪いことに、すべてが入力の 1 回のパスで発生します。
//! したがって、何かを変更するときは注意し、他のモジュールと再確認してください。
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// 10 進文字列の興味深い部分。
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// 10 進数の指数。18 桁未満であることが保証されています。
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// 入力文字列が有効な浮動小数点数であるかどうかを確認し、有効な場合は、その中の整数部分、小数部分、および指数を見つけます。
/// 兆候を処理しません。
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' の前に数字はありません
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ポイントの前後に少なくとも 1 桁必要です。
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // 小数部分の後の後続のがらくた
            }
        }
        _ => Invalid, // 最初の桁の文字列の後の末尾のジャンク
    }
}

/// 最初の非数字までの 10 進数を切り取ります。
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// 指数抽出とエラーチェック。
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // 指数の後の末尾のジャンク
    }
    if number.is_empty() {
        return Invalid; // 空の指数
    }
    // この時点で、確かに有効な数字の文字列があります。`i64` に入れるには長すぎるかもしれませんが、それが非常に大きい場合、入力は確かにゼロまたは無限大です。
    // 10 進数の各ゼロは、指数を +/-1 だけ調整するため、exp=10 ^ 18 の場合、有限に近づくには、入力はゼロの 17 エクサバイト (!) である必要があります。
    //
    // これは、私たちが対応する必要のあるユースケースではありません。
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}