//! 正の IEEE754 フロートを少しいじる。負の数は処理されず、処理する必要もありません。
//! 通常の浮動小数点数は、値が 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>))、ここで N はビット数) であるように、(frac、exp) として正規表現されます。
//!
//! 非正規化数はわずかに異なり、奇妙ですが、同じ原理が適用されます。
//!
//! ただし、ここでは、値が f * となるように、f を正の (sig、k) として表します。
//! <sup>2e</sup>。"hidden bit" を明示的にすることに加えて、これはいわゆる仮数シフトによって指数を変更します。
//!
//! 言い換えると、通常、フロートは (1) として記述されますが、ここでは (2) として記述されます。
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) を **分数表現**、(2) を **積分表現** と呼びます。
//!
//! このモジュールの多くの関数は、正規数のみを処理します。dec2flt ルーチンは、非常に小さい数と非常に大きい数に対して、保守的に、普遍的に正しい低速パス (アルゴリズム M) を使用します。
//! そのアルゴリズムは、非正規化数とゼロを処理する next_float() のみを必要とします。
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// 基本的に `f32` と `f64` のすべての変換コードの重複を避けるためのヘルパー trait。
///
/// これが必要な理由については、親モジュールのドキュメントコメントを参照してください。
///
/// 他のタイプに実装したり、dec2flt モジュールの外部で使用したりしないでください。
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` および `from_bits` で使用されるタイプ。
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// 整数への生の変換を実行します。
    fn to_bits(self) -> Self::Bits;

    /// 整数から生の核変換を実行します。
    fn from_bits(v: Self::Bits) -> Self;

    /// この番号が該当するカテゴリを返します。
    fn classify(self) -> FpCategory;

    /// 仮数、指数、および符号を整数として返します。
    fn integer_decode(self) -> (u64, i16, i8);

    /// フロートをデコードします。
    fn unpack(self) -> Unpacked;

    /// 正確に表現できる小さな整数からキャストします。
    /// Panic 整数を表現できない場合、このモジュールの他のコードは、それが発生しないようにします。
    fn from_int(x: u64) -> Self;

    /// 事前に計算されたテーブルから値 <sup>10e を</sup> 取得します。
    /// `e >= CEIL_LOG5_OF_MAX_SIG` の場合は Panics。
    fn short_fast_pow10(e: usize) -> Self;

    /// 名前が言うこと。
    /// 組み込み関数をジャグリングして LLVM 定数がそれを折りたたむことを期待するよりもハードコーディングする方が簡単です。
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // オーバーフローまたはゼロを生成できない入力の 10 進数の控えめな境界、または
    /// 非正規化数。おそらく最大正規値の 10 進指数であるため、この名前が付けられています。
    const MAX_NORMAL_DIGITS: usize;

    /// 最上位の 10 進数の桁の値がこれより大きい場合、数値は確実に無限大に丸められます。
    ///
    const INF_CUTOFF: i64;

    /// 最上位の 10 進数の桁の値がこれよりも小さい場合、数値は確実にゼロに丸められます。
    ///
    const ZERO_CUTOFF: i64;

    /// 指数のビット数。
    const EXP_BITS: u8;

    /// 隠しビットを *含む* 仮数のビット数。
    const SIG_BITS: u8;

    /// 隠しビットを *除外* した仮数のビット数。
    const EXPLICIT_SIG_BITS: u8;

    /// 分数表現の最大法定指数。
    const MAX_EXP: i16;

    /// 非正規化数を除く、分数表現の最小法定指数。
    const MIN_EXP: i16;

    /// `MAX_EXP` 積分表現の場合、つまりシフトが適用された場合。
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` エンコードされた (つまり、オフセットバイアスあり)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` 積分表現の場合、つまりシフトが適用された場合。
    const MIN_EXP_INT: i16;

    /// 積分表現における最大正規化仮数。
    const MAX_SIG: u64;

    /// 積分表現における最小の正規化された仮数。
    const MIN_SIG: u64;
}

// 主に #34344 の回避策です。
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// 仮数、指数、および符号を整数として返します。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // 指数バイアス + 仮数シフト
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe は、`as` がすべてのプラットフォームで正しく丸められるかどうかは不明です。
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// 仮数、指数、および符号を整数として返します。
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // 指数バイアス + 仮数シフト
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe は、`as` がすべてのプラットフォームで正しく丸められるかどうかは不明です。
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` を最も近いマシンフロートタイプに変換します。
/// 異常な結果を処理しません。
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f は 64 ビットであるため、xe の仮数シフトは 63 です。
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64 ビットの仮数を T::SIG_BITS ビットに半から偶数に丸めます。
/// 指数オーバーフローを処理しません。
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // 仮数シフトを調整する
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// 正規化された数値の `RawFloat::unpack()` の逆数。
/// 仮数または指数が正規化された数値に対して有効でない場合は、Panics。
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // 隠されたビットを削除します
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // 指数バイアスと仮数シフトの指数を調整します
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 符号ビットを 0 ("+") のままにします。数値はすべて正です。
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// サブノーマルを構築します。0 の仮数が許可され、ゼロを構成します。
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // エンコードされた指数は 0、符号ビットは 0 なので、ビットを再解釈する必要があります。
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp で bignum を近似します。0.5 ULP 内で半分から偶数に丸めます。
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // インデックス `start` の前のすべてのビットを切り取ります。つまり、`start` の量だけ効果的に右シフトするため、これも必要な指数です。
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // 切り捨てられたビットに応じて (half-to-even) を丸めます。
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// 引数よりも厳密に小さい最大の浮動小数点数を検索します。
/// 非正規化数、ゼロ、または指数アンダーフローを処理しません。
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// 引数よりも厳密に大きい最小の浮動小数点数を見つけます。
// この操作は飽和状態です。つまり、next_float(inf) ==inf です。
// このモジュールのほとんどのコードとは異なり、この関数はゼロ、非正規化数、および無限大を処理します。
// ただし、ここにある他のすべてのコードと同様に、NaN と負の数は処理しません。
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // これは真実ではないように思えますが、機能します。
        // 0.0 オールゼロワードとしてエンコードされます。非正規化数は 0x000m ... m です。ここで、m は仮数です。
        // 特に、最小のサブノーマルは 0x0 ... 01 で、最大のサブノーマルは 0x000F ... F です。
        // 最小の正規数は 0x0010 ... 0 であるため、このコーナーケースも同様に機能します。
        // インクリメントが仮数をオーバーフローした場合、キャリービットは必要に応じて指数をインクリメントし、仮数ビットはゼロになります。
        // 隠されたビットの慣習のため、これもまさに私たちが望んでいることです!
        // 最後に、f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY。
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}