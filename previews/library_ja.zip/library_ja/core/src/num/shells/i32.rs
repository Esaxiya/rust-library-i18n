//! 32 ビット符号付き整数型の定数。
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! 新しいコードでは、関連する定数をプリミティブ型で直接使用する必要があります。

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }