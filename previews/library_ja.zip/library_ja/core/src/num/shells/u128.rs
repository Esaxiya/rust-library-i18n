//! 128 ビットの符号なし整数型の定数。
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! 新しいコードでは、関連する定数をプリミティブ型で直接使用する必要があります。

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }