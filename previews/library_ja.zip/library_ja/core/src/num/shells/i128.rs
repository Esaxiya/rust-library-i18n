//! 128 ビットの符号付き整数型の定数。
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! 新しいコードでは、関連する定数をプリミティブ型で直接使用する必要があります。

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }