//! カスタム任意精度の数値 (bignum) の実装。
//!
//! これは、スタックメモリを犠牲にしてヒープ割り当てを回避するように設計されています。
//! 最も使用される bignum タイプである `Big32x40` は、32×40=1,280 ビットに制限されており、最大 160 バイトのスタックメモリを使用します。
//! これは、考えられるすべての有限 `f64` 値をラウンドトリップするのに十分すぎるほどです。
//!
//! 原則として、異なる入力に対して複数の bignum タイプを使用することは可能ですが、コードの膨張を避けるためにそうしません。
//!
//! 各 bignum は引き続き実際の使用状況について追跡されるため、通常は問題になりません。
//!

// このモジュールは dec2flt と flt2dec 専用であり、コアテストのために公開されています。
// 安定させることを意図したものではありません。
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// bignum に必要な算術演算。
pub trait FullOps: Sized {
    /// `carry' * 2^W + v' = self + other + carry` となる `(carry', v')` を返します。ここで、`W` は `Self` のビット数です。
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `carry'*2^W + v' = self* other + carry` となる `(carry', v')` を返します。ここで、`W` は `Self` のビット数です。
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `carry'*2^W + v' = self* other + other2 + carry` となる `(carry', v')` を返します。ここで、`W` は `Self` のビット数です。
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `borrow *2^W + self = quo* other + rem` および `0 <= rem < other` となるような `(quo, rem)` を返します。ここで、`W` は `Self` のビット数です。
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // これはオーバーフローできません。出力は `0` と `2 * 2^nbits - 1` の間にあります。
                    // FIXME: LLVM はこれを ADC または同様のものに最適化しますか?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // これはオーバーフローできません。
                    // 出力は `0` と `2^nbits * (2^nbits - 1)` の間にあります。
                    // FIXME: LLVM はこれを ADC または同様のものに最適化しますか?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // これはオーバーフローできません。
                    // 出力は `0` と `2^nbits * (2^nbits - 1)` の間にあります。
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // これはオーバーフローできません。出力は `0` と `other * (2^nbits - 1)` の間にあります。
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // これを有効にするには、RFC #521 を参照してください。
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// 数字で表現できる 5 の累乗の表。具体的には、5 の累乗である最大の {u8, u16, u32} 値に、対応する指数を加えたものです。
/// `mul_pow5` で使用されます。
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// スタックに割り当てられた任意精度 (特定の制限まで) の整数。
        ///
        /// これは、特定のタイプ ("digit") の固定サイズの配列によって支えられています。
        /// 配列はそれほど大きくありませんが (通常は数百バイト)、無謀にコピーするとパフォーマンスが低下する可能性があります。
        ///
        /// したがって、これは意図的に `Copy` ではありません。
        ///
        /// オーバーフローの場合に bignums panic で使用可能なすべての操作。
        /// 呼び出し元は、十分な大きさの bignum 型を使用する責任があります。
        pub struct $name {
            /// 1 に加えて、使用中の最大 "digit" へのオフセット。
            /// これは減少しないので、計算順序に注意してください。
            /// `base[size..]` ゼロである必要があります。
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` を表します。ここで、`W` は数字タイプのビット数です。
            base: [$ty; $n],
        }

        impl $name {
            /// 1 桁から bignum を作成します。
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` 値から bignum を作成します。
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// 数値が `a + b *2^W + c* 2^(2W) + ...` になるように内部桁をスライス `[a, b, c, ...]` として返します。ここで、`W` は桁タイプのビット数です。
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// ビット 0 が最下位ビットである `i` 番目のビットを返します。
            /// 言い換えれば、重みが `2^i` のビットです。
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// bignum がゼロの場合、`true` を返します。
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// この値を表すために必要なビット数を返します。
            /// ゼロは 0 ビットを必要とすると見なされることに注意してください。
            pub fn bit_length(&self) -> usize {
                // ゼロである最上位桁をスキップします。
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // ゼロ以外の数字はありません。つまり、数値はゼロです。
                    return 0;
                }
                // これは leading_zeros() とビットシフトで最適化できますが、おそらく面倒な価値はありません。
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` をそれ自体に追加し、独自の可変参照を返します。
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` をそれ自体から減算し、それ自体の可変参照を返します。
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// 数字サイズの `other` を乗算し、独自の可変参照を返します。
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// 自身に `2^bits` を乗算し、独自の可変参照を返します。
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` ビットずつシフト
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` ビットずつシフト
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. Digits] はゼロであり、シフトする必要はありません
                }

                self.size = sz;
                self
            }

            /// 自身に `5^e` を乗算し、独自の可変参照を返します。
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n には正確に n 個の後続ゼロがあり、関連する桁サイズは 2 の累乗であるため、これはテーブルに適したインデックスです。
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // 可能な限り最大の 1 桁の累乗を掛けます...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... その後、残りを終了します。
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (`W` は桁タイプのビット数) で記述された数値を乗算し、独自の可変参照を返します。
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // 内部ルーチン。aa.len() <= bb.len() の場合に最適に機能します。
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// 自分自身を桁サイズの `other` で除算し、それ自体の可変参照 *と* 残りを返します。
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// 自己を別の bignum で除算し、`q` を商で上書きし、`r` を余りで上書きします。
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // から取られた愚かな遅い base-2 筆算
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME は、筆算に大きなベース ($ty) を使用します。
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // q のビット `i` を 1 に設定します。
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` の数字タイプ。
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// これはテストにのみ使用されます。
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}