use crate::marker::Unsize;

/// Trait は、これがポインターまたはラッパーであることを示します。ここで、ポインティに対してサイズ変更を実行できます。
///
/// 詳細については、[DST coercion RFC][dst-coerce] および [the nomicon entry on coercion][nomicon-coerce] を参照してください。
///
/// 組み込みポインター型の場合、`T` へのポインターは、`T: Unsize<U>` の場合、シンポインターからファットポインターに変換することにより、`U` へのポインターに強制変換されます。
///
/// カスタムタイプの場合、ここでの強制は、`CoerceUnsized<Foo<U>> for Foo<T>` の実装が存在する場合に `Foo<T>` を `Foo<U>` に強制することによって機能します。
/// このような impl は、`Foo<T>` に `T` を含む非ファントムデータフィールドが 1 つしかない場合にのみ書き込むことができます。
/// そのフィールドのタイプが `Bar<T>` の場合、`CoerceUnsized<Bar<U>> for Bar<T>` の実装が存在する必要があります。
/// 強制は、`Bar<T>` フィールドを `Bar<U>` に強制し、`Foo<T>` の残りのフィールドに入力して `Foo<U>` を作成することによって機能します。
/// これにより、ポインタフィールドに効果的にドリルダウンし、それを強制します。
///
/// 一般に、スマートポインターの場合、`CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` を実装し、オプションの `?Sized` を `T` 自体にバインドします。
/// `Cell<T>` や `RefCell<T>` などの `T` を直接埋め込むラッパータイプの場合、`CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` を直接実装できます。
///
/// これにより、`Cell<Box<T>>` のようなタイプの強制が機能します。
///
/// [`Unsize`][unsize] ポインタの背後にある場合に DST に強制変換できるタイプをマークするために使用されます。コンパイラによって自動的に実装されます。
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// これは、オブジェクトの安全性のために使用され、メソッドのレシーバータイプをディスパッチできることを確認します。
///
/// trait の実装例:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}