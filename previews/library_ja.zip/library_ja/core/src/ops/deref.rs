/// `*v` などの不変の逆参照操作に使用されます。
///
/// `Deref` は、不変のコンテキストで (unary) `*` 演算子を使用した明示的な逆参照操作に使用されるだけでなく、多くの状況でコンパイラーによって暗黙的に使用されます。
/// このメカニズムは ['`Deref` coercion'][more] と呼ばれます。
/// 可変コンテキストでは、[`DerefMut`] が使用されます。
///
/// スマートポインタに `Deref` を実装すると、その背後にあるデータに簡単にアクセスできるため、`Deref` を実装します。
/// 一方、`Deref` と [`DerefMut`] に関するルールは、スマートポインターに対応するために特別に設計されました。
/// このため、混乱を避けるために、**`Deref` はスマートポインタ** にのみ実装する必要があります。
///
/// 同様の理由で、**この trait は決して失敗しないはずです**。`Deref` が暗黙的に呼び出された場合、逆参照中の失敗は非常に混乱する可能性があります。
///
/// # `Deref` 強制の詳細
///
/// `T` が `Deref<Target = U>` を実装し、`x` がタイプ `T` の値である場合、次のようになります。
///
/// * 不変のコンテキストでは、`*x` (`T` は参照でも生のポインターでもありません) は `* Deref::deref(&x)` と同等です。
/// * タイプ `&T` の値は、タイプ `&U` の値に強制されます。
/// * `T` タイプ `U` のすべての (immutable) メソッドを暗黙的に実装します。
///
/// 詳細については、[the chapter in *The Rust Programming Language*][book]、および [the dereference operator][ref-deref-op]、[method resolution]、[type coercions] のリファレンスセクションをご覧ください。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 構造体を逆参照することでアクセスできる単一のフィールドを持つ構造体。
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// 逆参照後の結果の型。
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// 値を逆参照します。
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` のように、変更可能な逆参照操作に使用されます。
///
/// `DerefMut` は、可変コンテキストで (unary) `*` 演算子を使用した明示的な逆参照操作に使用されるだけでなく、多くの状況でコンパイラーによって暗黙的に使用されます。
/// このメカニズムは ['`Deref` coercion'][more] と呼ばれます。
/// 不変のコンテキストでは、[`Deref`] が使用されます。
///
/// スマートポインターに `DerefMut` を実装すると、その背後にあるデータを簡単に変更できるため、`DerefMut` を実装します。
/// 一方、[`Deref`] と `DerefMut` に関するルールは、スマートポインターに対応するために特別に設計されました。
/// このため、混乱を避けるために、**`DerefMut` はスマートポインタ** にのみ実装する必要があります。
///
/// 同様の理由で、**この trait は決して失敗しないはずです**。`DerefMut` が暗黙的に呼び出された場合、逆参照中の失敗は非常に混乱する可能性があります。
///
/// # `Deref` 強制の詳細
///
/// `T` が `DerefMut<Target = U>` を実装し、`x` がタイプ `T` の値である場合、次のようになります。
///
/// * 可変コンテキストでは、`*x` (`T` は参照でも raw ポインターでもありません) は `* DerefMut::deref_mut(&mut x)` と同等です。
/// * タイプ `&mut T` の値は、タイプ `&mut U` の値に強制されます。
/// * `T` タイプ `U` のすべての (mutable) メソッドを暗黙的に実装します。
///
/// 詳細については、[the chapter in *The Rust Programming Language*][book]、および [the dereference operator][ref-deref-op]、[method resolution]、[type coercions] のリファレンスセクションをご覧ください。
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// 構造体を逆参照することで変更可能な単一のフィールドを持つ構造体。
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// 値を相互に逆参照します。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` 機能なしで、構造体をメソッドレシーバーとして使用できることを示します。
///
/// これは、`Box<T>`、`Rc<T>`、`&T`、`Pin<P>` などの stdlib ポインター型によって実装されます。
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}