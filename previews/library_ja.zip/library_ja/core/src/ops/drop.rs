/// デストラクタ内のカスタムコード。
///
/// 値が不要になると、Rust はその値に対して "destructor" を実行します。
/// 値が不要になる最も一般的な方法は、値がスコープ外になるときです。デストラクタは他の状況でも実行される可能性がありますが、ここでは例の範囲に焦点を当てます。
/// これらの他のケースのいくつかについては、デストラクタに関する [the reference] セクションを参照してください。
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// このデストラクタは、次の 2 つのコンポーネントで構成されています。
/// - この特別な `Drop` trait がそのタイプに実装されている場合、その値に対する `Drop::drop` の呼び出し。
/// - この値のすべてのフィールドのデストラクタを再帰的に呼び出す、自動生成された "drop glue"。
///
/// Rust は、含まれているすべてのフィールドのデストラクタを自動的に呼び出すため、ほとんどの場合、`Drop` を実装する必要はありません。
/// ただし、リソースを直接管理するタイプなど、便利な場合もあります。
/// そのリソースはメモリ、ファイル記述子、ネットワークソケットの場合があります。
/// そのタイプの値が使用されなくなると、メモリを解放するか、ファイルまたはソケットを閉じることによって、リソースを "clean up" する必要があります。
/// これはデストラクタの仕事であり、したがって `Drop::drop` の仕事です。
///
/// ## Examples
///
/// デストラクタの動作を確認するために、次のプログラムを見てみましょう。
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust は、最初に `_x` に対して `Drop::drop` を呼び出し、次に `_x.one` と `_x.two` の両方に対して呼び出します。つまり、これを実行すると印刷されます。
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// `HasTwoDrop` 用の `Drop` の実装を削除しても、そのフィールドのデストラクタは引き続き呼び出されます。
/// これにより、
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` を自分で呼び出すことはできません
///
/// `Drop::drop` は値のクリーンアップに使用されるため、メソッドが呼び出された後にこの値を使用するのは危険な場合があります。
/// `Drop::drop` は入力の所有権を取得しないため、Rust は、`Drop::drop` を直接呼び出さないようにすることで、誤用を防ぎます。
///
/// つまり、上記の例で `Drop::drop` を明示的に呼び出そうとすると、コンパイラエラーが発生します。
///
/// 値のデストラクタを明示的に呼び出したい場合は、代わりに [`mem::drop`] を使用できます。
///
/// [`mem::drop`]: drop
///
/// ## ドロップオーダー
///
/// ただし、2 つの `HasDrop` のどちらが最初にドロップしますか? 構造体の場合、宣言されている順序と同じです。最初に `one`、次に `two` です。
/// これを自分で試してみたい場合は、上記の `HasDrop` を変更して整数などのデータを含め、`Drop` 内の `println!` で使用できます。
/// この動作は言語によって保証されています。
///
/// 構造体の場合とは異なり、ローカル変数は逆の順序で削除されます。
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// これは印刷されます
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// 完全なルールについては、[the reference] を参照してください。
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` および `Drop` は排他的です
///
/// [`Copy`] と `Drop` の両方を同じタイプに実装することはできません。`Copy` の型はコンパイラによって暗黙的に複製されるため、デストラクタがいつ、どのくらいの頻度で実行されるかを予測するのは非常に困難です。
///
/// そのため、これらのタイプにデストラクタを含めることはできません。
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// このタイプのデストラクタを実行します。
    ///
    /// このメソッドは、値がスコープ外になると暗黙的に呼び出され、明示的に呼び出すことはできません (これはコンパイラエラー [E0040] です)。
    /// ただし、prelude の [`mem::drop`] 関数を使用して、引数の `Drop` 実装を呼び出すことができます。
    ///
    /// このメソッドが呼び出されたとき、`self` はまだ割り当て解除されていません。
    /// これは、メソッドが終了した後にのみ発生します。
    /// そうでない場合、`self` はぶら下がっている参照になります。
    ///
    /// # Panics
    ///
    /// [`panic!`] が巻き戻し時に `drop` を呼び出すことを考えると、`drop` 実装の [`panic!`] はすべて中止される可能性があります。
    ///
    /// この panics であっても、値は削除されたと見なされることに注意してください。
    /// `drop` を再度呼び出さないでください。
    /// これは通常、コンパイラによって自動的に処理されますが、安全でないコードを使用すると、特に [`ptr::drop_in_place`] を使用している場合に、意図せずに発生することがあります。
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}