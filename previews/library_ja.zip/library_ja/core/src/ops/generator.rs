use crate::marker::Unpin;
use crate::pin::Pin;

/// 発電機の再開の結果。
///
/// この列挙型は `Generator::resume` メソッドから返され、ジェネレーターの可能な戻り値を示します。
/// 現在、これは一時停止ポイント (`Yielded`) または終了ポイント (`Complete`) のいずれかに対応します。
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// ジェネレーターは値で中断されました。
    ///
    /// この状態は、ジェネレーターが一時停止されたことを示し、通常は `yield` ステートメントに対応します。
    /// このバリアントで提供される値は、`yield` に渡される式に対応し、ジェネレーターが生成するたびに値を提供できるようにします。
    ///
    ///
    Yielded(Y),

    /// ジェネレータは戻り値で完了しました。
    ///
    /// この状態は、ジェネレーターが指定された値で実行を終了したことを示します。
    /// ジェネレーターが `Complete` を返すと、`resume` を再度呼び出すことはプログラマーエラーと見なされます。
    ///
    Complete(R),
}

/// 組み込みのジェネレータータイプによって実装された trait。
///
/// 一般にコルーチンとも呼ばれるジェネレーターは、現在 Rust の実験的な言語機能です。
/// [RFC 2033] ジェネレーターに追加されたものは、現在、主に async/await 構文の構成要素を提供することを目的としていますが、イテレーターやその他のプリミティブの人間工学的定義も提供するように拡張される可能性があります。
///
///
/// ジェネレーターの構文とセマンティクスは不安定であり、安定化のためにさらに RFC が必要になります。ただし、現時点では、構文はクロージャのようなものです。
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// ジェネレーターの詳細については、不安定な本を参照してください。
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// このジェネレーターが生成する値のタイプ。
    ///
    /// この関連付けられたタイプは、`yield` 式と、ジェネレーターが生成するたびに返されることが許可されている値に対応します。
    ///
    /// たとえば、ジェネレータとしてのイテレータは、このタイプを `T` として持つ可能性が高く、タイプは繰り返されます。
    ///
    type Yield;

    /// このジェネレータが返す値のタイプ。
    ///
    /// これは、`return` ステートメントを使用して、またはジェネレータリテラルの最後の式として暗黙的にジェネレータから返される型に対応します。
    /// たとえば、futures は、完成した future を表すため、これを `Result<T, E>` として使用します。
    ///
    ///
    type Return;

    /// このジェネレーターの実行を再開します。
    ///
    /// この関数は、ジェネレーターの実行を再開するか、まだ実行していない場合は実行を開始します。
    /// この呼び出しは、ジェネレーターの最後の一時停止ポイントに戻り、最新の `yield` から実行を再開します。
    /// ジェネレーターは、yield または return のいずれかになるまで実行を継続し、その時点でこの関数が戻ります。
    ///
    /// # 戻り値
    ///
    /// この関数から返される `GeneratorState` 列挙型は、ジェネレーターが戻ったときにどのような状態にあるかを示します。
    /// `Yielded` バリアントが返される場合、ジェネレーターは一時停止ポイントに到達し、値が生成されています。
    /// この状態のジェネレーターは、後で再開できます。
    ///
    /// `Complete` が返された場合、ジェネレーターは指定された値で完全に終了しています。ジェネレーターを再開することは無効です。
    ///
    /// # Panics
    ///
    /// この関数は、`Complete` バリアントが以前に返された後に呼び出された場合、panic になる可能性があります。
    /// 言語のジェネレータリテラルは、`Complete` の後に再開すると、panic に保証されますが、これは、`Generator` trait のすべての実装で保証されるわけではありません。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}