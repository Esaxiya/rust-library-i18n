/// `?` オペレーターの動作をカスタマイズするための trait。
///
/// `Try` を実装するタイプは、success/failure の二分法の観点からそれを表示するための標準的な方法を備えたタイプです。
/// この trait を使用すると、既存のインスタンスからこれらの成功または失敗の値を抽出することと、成功または失敗の値から新しいインスタンスを作成することができます。
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// 成功したと見なされたときのこの値のタイプ。
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// 失敗したと見なされたときのこの値のタイプ。
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" 演算子を適用します。`Ok(t)` が返されるということは、実行が正常に続行されることを意味し、`?` の結果は値 `t` になります。
    /// `Err(e)` が返されるということは、実行が branch を最も内側の囲んでいる `catch` に移動するか、関数から戻る必要があることを意味します。
    ///
    /// `Err(e)` の結果が返される場合、値 `e` は、囲んでいるスコープの戻り型の "wrapped" になります (それ自体が `Try` を実装する必要があります)。
    ///
    /// 具体的には、値 `X::from_error(From::from(e))` が返されます。ここで、`X` は囲んでいる関数の戻りタイプです。
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// エラー値をラップして、複合結果を作成します。
    /// たとえば、`Result::Err(x)` と `Result::from_error(x)` は同等です。
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// OK 値をラップして、複合結果を作成します。
    /// たとえば、`Result::Ok(x)` と `Result::from_ok(x)` は同等です。
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}