//! オーバーロード可能な演算子。
//!
//! これらの traits を実装すると、特定の演算子をオーバーロードできます。
//!
//! これらの traits の一部は prelude によってインポートされるため、すべての Rust プログラムで使用できます。traits に裏打ちされた演算子のみがオーバーロードできます。
//! たとえば、加算演算子 (`+`) は [`Add`] trait を介してオーバーロードできますが、代入演算子 (`=`) にはバッキング trait がないため、そのセマンティクスをオーバーロードする方法はありません。
//! さらに、このモジュールは、新しい演算子を作成するためのメカニズムを提供しません。
//! 特性のないオーバーロードまたはカスタム演算子が必要な場合は、マクロまたはコンパイラプラグインを使用して、Rust の構文を拡張する必要があります。
//!
//! 演算子 traits の実装は、通常の意味と [operator precedence] を念頭に置いて、それぞれのコンテキストで驚くべきことではありません。
//! たとえば、[`Mul`] を実装する場合、演算は乗算にある程度類似している必要があります (そして、結合性などの期待されるプロパティを共有する必要があります)。
//!
//! `&&` および `||` 演算子は短絡していることに注意してください。つまり、結果に寄与する場合にのみ 2 番目のオペランドを評価します。この動作は traits によって強制できないため、`&&` および `||` はオーバーロード可能な演算子としてサポートされていません。
//!
//! 演算子の多くは、オペランドを値で受け取ります。組み込み型を含む非ジェネリックコンテキストでは、これは通常問題ではありません。
//! ただし、ジェネリックコードでこれらの演算子を使用する場合、演算子に値を消費させるのではなく、値を再利用する必要がある場合は注意が必要です。1 つのオプションは、[`clone`] を時々使用することです。
//! 別のオプションは、参照用の追加の演算子実装を提供するために必要なタイプに依存することです。
//! たとえば、追加をサポートすることになっているユーザー定義型 `T` の場合、`T` と `&T` の両方に traits [`Add<T>`][`Add`] と [`Add<&T>`][`Add`] を実装して、不要なクローンを作成せずに汎用コードを記述できるようにすることをお勧めします。
//!
//!
//! # Examples
//!
//! この例では、[`Add`] と [`Sub`] を実装する `Point` 構造体を作成し、2 つの `Point` の加算と減算を示します。
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! 実装例については、各 trait のドキュメントを参照してください。
//!
//! [`Fn`]、[`FnMut`]、および [`FnOnce`] traits は、関数のように呼び出すことができる型によって実装されます。[`Fn`] は `&self` を取り、[`FnMut`] は `&mut self` を取り、[`FnOnce`] は `self` を取ります。
//! これらは、インスタンスで呼び出すことができる 3 種類のメソッド (参照による呼び出し、可変参照による呼び出し、および値による呼び出し) に対応します。
//! これらの traits の最も一般的な使用法は、関数またはクロージャを引数として取る高レベル関数の境界として機能することです。
//!
//! [`Fn`] をパラメーターとして使用する:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] をパラメーターとして使用する:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] をパラメーターとして使用する:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` キャプチャされた変数を消費するため、複数回実行することはできません
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` を再度呼び出そうとすると、`func` に対して `use of moved value` エラーがスローされます。
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` この時点で呼び出すことはできなくなりました
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;