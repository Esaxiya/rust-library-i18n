/// 不変のレシーバーを使用する呼び出し演算子のバージョン。
///
/// `Fn` のインスタンスは、状態を変更せずに繰り返し呼び出すことができます。
///
/// *この trait (`Fn`) を [function pointers] (`fn`) と混同しないでください。*
///
/// `Fn` (safe) [function pointers] と同様に、キャプチャされた変数への不変の参照のみを取得するか、まったくキャプチャしないクロージャによって自動的に実装されます (いくつかの注意点があります。詳細については、ドキュメントを参照してください)。
///
/// さらに、`Fn` を実装するすべてのタイプ `F` の場合、`&F` は `Fn` も実装します。
///
/// [`FnMut`] と [`FnOnce`] はどちらも `Fn` のスーパートレイトであるため、`Fn` の任意のインスタンスを、[`FnMut`] または [`FnOnce`] が予期されるパラメーターとして使用できます。
///
/// 関数のようなタイプのパラメーターを受け入れ、状態を変更せずに繰り返し呼び出す必要がある場合 (たとえば、同時に呼び出す場合) は、`Fn` を境界として使用します。
/// このような厳密な要件が必要ない場合は、境界として [`FnMut`] または [`FnOnce`] を使用してください。
///
/// このトピックの詳細については、[chapter on closures in *The Rust Programming Language*][book] を参照してください。
///
/// `Fn` traits の特別な構文も注目に値します (例:
/// `Fn(usize, bool) -> usize`)。これの技術的な詳細に興味がある人は [the relevant section in the *Rustonomicon*][nomicon] を参照することができます。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## クロージャを呼び出す
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` パラメーターの使用
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex がその `&str: !FnMut` を信頼できるように
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// 呼び出し操作を実行します。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// 可変レシーバーを使用する呼び出し演算子のバージョン。
///
/// `FnMut` のインスタンスは繰り返し呼び出すことができ、状態を変更する場合があります。
///
/// `FnMut` キャプチャされた変数への可変参照を取得するクロージャ、および [`Fn`] を実装するすべてのタイプ ((safe) [function pointers] など) によって自動的に実装されます (`FnMut` は [`Fn`] のスーパートレイトであるため)。
/// さらに、`FnMut` を実装するすべてのタイプ `F` の場合、`&mut F` は `FnMut` も実装します。
///
/// [`FnOnce`] は `FnMut` のスーパートレイトであるため、[`FnOnce`] が期待される場所で `FnMut` の任意のインスタンスを使用でき、[`Fn`] は `FnMut` のサブトレイトであるため、`FnMut` が期待される場所で [`Fn`] の任意のインスタンスを使用できます。
///
/// 関数のようなタイプのパラメーターを受け入れ、状態を変更できるようにしながら繰り返し呼び出す必要がある場合は、`FnMut` を境界として使用します。
/// パラメーターの状態を変更したくない場合は、[`Fn`] を境界として使用します。繰り返し呼び出す必要がない場合は、[`FnOnce`] を使用してください。
///
/// このトピックの詳細については、[chapter on closures in *The Rust Programming Language*][book] を参照してください。
///
/// `Fn` traits の特別な構文も注目に値します (例:
/// `Fn(usize, bool) -> usize`)。これの技術的な詳細に興味がある人は [the relevant section in the *Rustonomicon*][nomicon] を参照することができます。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## 可変キャプチャクロージャを呼び出す
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` パラメーターの使用
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex がその `&str: !FnMut` を信頼できるように
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// 呼び出し操作を実行します。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// 値による受信者を受け取る呼び出し演算子のバージョン。
///
/// `FnOnce` のインスタンスは呼び出すことができますが、複数回呼び出すことはできません。このため、型についてわかっているのが `FnOnce` を実装していることだけである場合、それを呼び出すことができるのは 1 回だけです。
///
/// `FnOnce` キャプチャされた変数を消費する可能性のあるクロージャ、および [`FnMut`] を実装するすべてのタイプ ((safe) [function pointers] など) によって自動的に実装されます (`FnOnce` は [`FnMut`] のスーパートレイトであるため)。
///
///
/// [`Fn`] と [`FnMut`] はどちらも `FnOnce` のサブトレイトであるため、`FnOnce` が必要な場合は [`Fn`] または [`FnMut`] の任意のインスタンスを使用できます。
///
/// 関数のようなタイプのパラメーターを受け入れ、それを 1 回だけ呼び出す必要がある場合は、`FnOnce` を境界として使用します。
/// パラメータを繰り返し呼び出す必要がある場合は、境界として [`FnMut`] を使用してください。状態を変更しないためにも必要な場合は、[`Fn`] を使用してください。
///
/// このトピックの詳細については、[chapter on closures in *The Rust Programming Language*][book] を参照してください。
///
/// `Fn` traits の特別な構文も注目に値します (例:
/// `Fn(usize, bool) -> usize`)。これの技術的な詳細に興味がある人は [the relevant section in the *Rustonomicon*][nomicon] を参照することができます。
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` パラメーターの使用
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` キャプチャされた変数を消費するため、複数回実行することはできません。
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` を再度呼び出そうとすると、`func` に対して `use of moved value` エラーがスローされます。
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` この時点で呼び出すことはできなくなりました
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // regex がその `&str: !FnMut` を信頼できるように
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// 呼び出し演算子が使用された後に返される型。
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// 呼び出し操作を実行します。
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}