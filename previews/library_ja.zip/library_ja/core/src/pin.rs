//! データをメモリ内のその場所に固定するタイプ。
//!
//! メモリ内の配置が変更されないという意味で、移動しないことが保証されているオブジェクトがあると便利な場合があります。そのため、オブジェクトを信頼できます。
//! このようなシナリオの代表的な例は、自己参照構造体の構築です。これは、オブジェクトをそれ自体へのポインターとともに移動すると、オブジェクトが無効になり、未定義の動作が発生する可能性があるためです。
//!
//! 高レベルでは、[`Pin<P>`] は、任意のポインタ型 `P` のポインタがメモリ内で安定した場所にあることを保証します。つまり、他の場所に移動したり、ドロップされるまでメモリの割り当てを解除したりすることはできません。ポインティは "pinned" と言います。固定されたデータと固定されていないデータを組み合わせるタイプについて議論するとき、物事はより微妙になります。詳細については、[see below](#projections-and-structural-pinning) を参照してください。
//!
//! デフォルトでは、Rust のすべてのタイプが移動可能です。
//! Rust を使用すると、すべての型を値で渡すことができ、[`Box<T>`] や `&mut T` などの一般的なスマートポインター型を使用すると、含まれている値を置き換えて移動できます。[`Box<T>`] から移動することも、[`mem::swap`] を使用することもできます。
//! [`Pin<P>`] ポインタ型 `P` をラップするため、[`Pin`]`<`[`Box`] `<T>>` は通常のように機能します
//!
//! [`Box<T>`]: when [`ピン`] `<` [`ボックス`] `<T>>` が削除されるので、その内容も削除され、メモリが取得されます
//!
//! 割り当て解除。同様に、[`Pin`]`<＆mutT>` は `&mut T` によく似ています。ただし、[`Pin<P>`] では、クライアントが実際に [`Box<T>`] または `&mut T` をピン留めされたデータに取得することはできません。これは、[`mem::swap`] などの操作を使用できないことを意味します。
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` が必要ですが、入手できません。
//!     // 私たちは立ち往生しており、これらの参照の内容を交換することはできません。
//!     // `Pin::get_unchecked_mut` を使用することもできますが、それは次の理由で安全ではありません。
//!     // `Pin` から物を移動するために使用することは許可されていません。
//! }
//! ```
//!
//! [`Pin<P>`] は、Rust コンパイラがすべての型を移動可能と見なすという事実を *変更しない* ことを繰り返す価値があります。[`mem::swap`] は、どの `T` でも引き続き呼び出し可能です。代わりに、[`Pin<P>`] は、`&mut T` を必要とするメソッド ([`mem::swap`] など) を呼び出せないようにすることで、特定の *値*([`Pin<P>`] でラップされたポインターが指す) が移動するのを防ぎます。
//!
//! [`Pin<P>`] 任意のポインタ型 `P` をラップするために使用できるため、[`Deref`] および [`DerefMut`] と相互作用します。`P: Deref` をピン留めされた `P::Target` の "`P`-style pointer" と見なす必要がある [`Pin<P>`] - したがって、[`ピン`] `<` [`ボックス`] `<T>>` は、固定された `T` への所有ポインターであり、[`Pin`] `<` [`Rc`]`<T>>` は、固定された `T` への参照カウントポインタです。
//! 正確さのために、[`Pin<P>`] は [`Deref`] および [`DerefMut`] の実装に依存しており、`self` パラメーターから移動せず、ピン留めされたポインターで呼び出されたときにのみ、ピン留めされたデータへのポインターを返します。
//!
//! # `Unpin`
//!
//! 多くのタイプは、安定したアドレスを持つことに依存しないため、固定されている場合でも常に自由に移動できます。これには、すべての基本タイプ ([`bool`]、[`i32`]、参照など) と、これらのタイプのみで構成されるタイプが含まれます。ピン留めを気にしないタイプは、[`Pin<P>`] の効果をキャンセルする [`Unpin`] auto-trait を実装します。
//! `T: Unpin` の場合、[`ピン`] `<` [`ボックス`] `<T>>` と [`Box<T>`] は、[`Pin`] `<＆mut T>` と `&mut T` と同様に、同じように機能します。
//!
//! ピン留めと [`Unpin`] は、[`Pin<P>`] にラップされたポインター型 `P` 自体ではなく、ポイントされた型 `P::Target` にのみ影響することに注意してください。たとえば、[`Box<T>`] が [`Unpin`] であるかどうかは、[`Pin`]`<`[`Box`] `の動作には影響しません。<T>>` (ここでは、`T` がポイント型です)。
//!
//! # 例: 自己参照構造体
//!
//! `Pin<T>` に関連する保証と選択について詳しく説明する前に、`Pin<T>` の使用方法の例について説明します。
//! [skip to where the theoretical discussion continues](#drop-guarantee) までお気軽に。
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // スライスフィールドがデータフィールドを指しているため、これは自己参照構造体です。
//! // このパターンは通常の借用規則では記述できないため、通常の参照ではコンパイラに通知できません。
//! //
//! // 代わりに、生のポインタを使用しますが、文字列を指していることがわかっているため、null ではないことがわかっています。
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // 関数が戻ったときにデータが移動しないようにするために、オブジェクトの存続期間中データが保持されるヒープにデータを配置します。データにアクセスする唯一の方法は、データへのポインターを使用することです。
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // データが配置された後でのみポインタを作成します。そうしないと、開始する前にデータがすでに移動していることになります。
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // フィールドを変更しても構造体全体が移動しないため、これは安全であることがわかっています。
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // 構造体が移動していない限り、ポインタは正しい場所を指している必要があります。
//! //
//! // その間、ポインタを自由に動かすことができます。
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // 私たちのタイプは Unpin を実装していないので、これはコンパイルに失敗します:
//! // mut new_unmoved= Unmovable::new("world".to_string()); とします。
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # 例: 煩わしい二重リンクリスト
//!
//! 煩わしい二重リンクリストでは、コレクションは実際には要素自体にメモリを割り当てません。
//! 割り当てはクライアントによって制御され、要素はコレクションよりも短いスタックフレーム上に存在できます。
//!
//! これを機能させるために、すべての要素には、リスト内の先行および後続へのポインターがあります。要素を移動するとポインタが無効になるため、要素は固定されている場合にのみ追加できます。さらに、リンクリスト要素の [`Drop`] 実装は、リストからそれ自体を削除するために、その先行および後続のポインターにパッチを適用します。
//!
//! 重要なのは、[`drop`] が呼び出されることに依存できる必要があるということです。[`drop`] を呼び出さずに要素の割り当てを解除したり無効にしたりできると、隣接する要素から要素へのポインタが無効になり、データ構造が破損します。
//!
//! したがって、ピン留めには [`drop`] 関連の保証も付いています。
//!
//! # `Drop` guarantee
//!
//! 固定の目的は、メモリ内の一部のデータの配置に依存できるようにすることです。
//! これを機能させるには、データの移動だけでなく制限もあります。データの保存に使用されるメモリの割り当て解除、転用、または無効化も制限されます。
//! 具体的には、固定されたデータの場合、*固定された瞬間から [`drop`] が呼び出されるまで、そのメモリが無効化または再利用されない* という不変条件を維持する必要があります。[`drop`] が戻るか panics になったら、メモリを再利用できます。
//!
//! メモリは、割り当て解除によって "invalidated" にすることができますが、[`Some(v)`] を [`None`] に置き換えるか、vector からいくつかの要素を [`Vec::set_len`] から "kill" に呼び出すことによっても使用できます。[`ptr::write`] を使用して、最初にデストラクタを呼び出さずに上書きすることで、再利用できます。[`drop`] を呼び出さずに、固定されたデータに対してこれを行うことはできません。
//!
//! これはまさに、前のセクションの侵入型リンクリストが正しく機能する必要があることを保証するものです。
//!
//! この保証は、メモリがリークしないことを意味するわけではないことに注意してください。固定された要素で [`drop`] を呼び出さなくても完全に問題ありません (たとえば、[`Pin`]`<`[`Box`] `で [`mem::forget`] を呼び出すことはできます。<T>>`)。二重リンクリストの例では、その要素はリストにとどまります。ただし、[`drop`] * を呼び出さずにストレージを解放または再利用することはできません。
//!
//! # `Drop` implementation
//!
//! タイプでピン留めを使用している場合 (上記の 2 つの例など)、[`Drop`] を実装する際には注意が必要です。[`drop`] 関数は `&mut self` を取りますが、これは *タイプが以前に固定されていたとしても* 呼び出されます! これは、コンパイラが自動的に [`Pin::get_unchecked_mut`] を呼び出したかのようです。
//!
//! 固定に依存する型を実装するには安全でないコードが必要になるため、これによって安全なコードで問題が発生することはありませんが、型で固定を使用することを決定することに注意してください (たとえば、[`Pin`]`<＆Self で何らかの操作を実装することによって>` または [`Pin`] `<＆mut Self>`) は、[`Drop`] 実装にも影響を及ぼします。タイプの要素が固定されている可能性がある場合は、[`Drop`] を暗黙的に [`Pin`]`<＆mut を取るものとして扱う必要があります。自己>`。
//!
//!
//! たとえば、次のように `Drop` を実装できます。
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` この値が削除された後は二度と使用されないことがわかっているので、問題ありません。
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // 実際のドロップコードはここにあります。
//!         }
//!     }
//! }
//! ```
//!
//! 関数 `inner_drop` は、[`drop`] が持つべきタイプであるため、ピン留めと競合する方法で誤って `self`/`this` を使用しないようにします。
//!
//! さらに、タイプが `#[repr(packed)]` の場合、コンパイラーはフィールドを自動的に移動してドロップできるようにします。たまたま十分に整列されているフィールドに対しても、それが行われる可能性があります。結果として、`#[repr(packed)]` タイプではピン留めを使用できません。
//!
//! # 投影と構造ピンニング
//!
//! 固定された構造体を操作する場合、[`Pin`]`<＆mut Struct>` だけを使用するメソッドでその構造体のフィールドにアクセスするにはどうすればよいかという疑問が生じます。
//! 通常のアプローチは、[`Pin`]`<＆mut Struct>` をフィールドへの参照に変換するヘルパーメソッド (いわゆる *プロジェクション*) を作成することですが、その参照にはどのタイプが必要ですか? [`Pin`]`<＆mut Field>` または `&mut Field` ですか?
//! `enum` のフィールドでも、[`Vec<T>`]、[`Box<T>`]、[`RefCell<T>`] などの container/wrapper タイプを検討する場合にも、同じ質問が発生します。
//! (この質問は、可変参照と共有参照の両方に当てはまります。ここでは、説明のために、より一般的な可変参照のケースを使用しています。)
//!
//! 特定のフィールドのピン留めされた射影が [`Pin`]`<＆mut Struct>` を [`Pin`] `<＆mut Field>` に変換するか、`&mut Field`。ただし、いくつかの制約があり、最も重要な制約は *一貫性* です。
//! すべてのフィールドは、固定された参照に投影するか、投影の一部として固定を削除することができます。
//! 両方が同じフィールドに対して行われた場合、それはおそらく不健全になります!
//!
//! データ構造の作成者は、"propagates" をこのフィールドに固定するかどうかを各フィールドで決定できます。
//! 伝播するピン留めは、タイプの構造に従うため、"structural" とも呼ばれます。
//! 次のサブセクションでは、どちらの選択に対しても行う必要のある考慮事項について説明します。
//!
//! ## `field` のピン留めは構造的ではありません
//!
//! 固定された構造体のフィールドが固定されていない可能性があることは直感に反するように思われるかもしれませんが、実際にはそれが最も簡単な選択です。[`Pin`]`<＆mut Field>` が作成されない場合、何も問題はありません。したがって、一部のフィールドに構造的なピン留めがないと判断した場合は、そのフィールドへのピン留めされた参照を作成しないようにする必要があります。
//!
//! 構造体のピン留めのないフィールドには、[`Pin`]`<＆mut Struct>` を `&mut Field` に変換する射影方法がある場合があります。
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // `field` は固定されているとは見なされないため、これは問題ありません。
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! `field` のタイプが [`Unpin`] でなくても、`impl Unpin for Struct` を使用することもできます。[`Pin`]`<＆mut Field>` が作成されていない場合、そのタイプがピン留めについて考えることは関係ありません。
//!
//! ## 固定は `field` の構造的です
//!
//! もう 1 つのオプションは、ピン留めが `field` に対して "structural" であることを決定することです。つまり、構造体がピン留めされている場合、フィールドもピン留めされます。
//!
//! これにより、[`Pin`]`<＆mut Field>` を作成するプロジェクションを記述できるため、フィールドが固定されていることがわかります。
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // `self` が固定されているときに `field` が固定されているため、これは問題ありません。
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! ただし、構造的な固定には、いくつかの追加要件があります。
//!
//! 1. すべての構造体フィールドが [`Unpin`] である場合、構造体は [`Unpin`] である必要があります。これがデフォルトですが、[`Unpin`] は安全な trait であるため、構造体の作成者は `impl<T> Unpin for Struct<T>` のようなものを追加することは *できません*。
//! (プロジェクション操作を追加するには安全でないコードが必要であることに注意してください。したがって、[`Unpin`] が安全な trait であるという事実は、「安全でない」を使用する場合にのみこれについて心配する必要があるという原則に違反しません。)
//! 2. 構造体のデストラクタは、構造体フィールドを引数から移動してはなりません。これは、[previous section][drop-impl] で発生した正確なポイントです。`drop` は `&mut self` を取りますが、構造体 (したがってそのフィールド) は以前に固定されている可能性があります。
//!     [`Drop`] 実装内でフィールドを移動しないことを保証する必要があります。
//!     特に、前に説明したように、これは構造体が `#[repr(packed)]` であってはならないことを意味します。
//!     コンパイラが誤ってピン留めを壊さないように [`drop`] を作成する方法については、そのセクションを参照してください。
//! 3. [`Drop` guarantee][drop-guarantee] を支持していることを確認する必要があります。
//!     構造体が固定されると、コンテンツのデストラクタを呼び出さずに、コンテンツを含むメモリが上書きされたり、割り当てが解除されたりすることはありません。
//!     [`VecDeque<T>`] に見られるように、これは注意が必要な場合があります。デストラクタの 1 つが panics の場合、[`VecDeque<T>`] のデストラクタはすべての要素で [`drop`] を呼び出せない可能性があります。これは、デストラクタが呼び出されずに要素の割り当てが解除される可能性があるため、[`Drop`] の保証に違反します。([`VecDeque<T>`] にはピン留めの突起がないため、不調は発生しません。)
//! 4. タイプが固定されたときにデータが構造フィールドから移動する可能性のある他の操作を提供してはなりません。たとえば、構造に [`Option<T>`] が含まれていて、タイプ `fn(Pin<&mut Struct<T>>) -> Option<T>` の「take」のような操作がある場合、その操作を使用して、固定された `Struct<T>` から `T` を移動できます。つまり、これを保持するフィールドに対して固定を構造化することはできません。データ。
//!
//!     固定タイプからデータを移動するより複雑な例については、[`RefCell<T>`] にメソッド `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` があるかどうかを想像してください。
//!     次に、次のことを実行できます。
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     これは壊滅的です。つまり、最初に [`RefCell<T>`] のコンテンツを (`RefCell::get_pin_mut` を使用して) 固定し、次に後で取得した可変参照を使用してそのコンテンツを移動できます。
//!
//! ## Examples
//!
//! [`Vec<T>`] のようなタイプの場合、両方の可能性 (構造的なピン留めかどうか) は理にかなっています。
//! 構造的に固定された [`Vec<T>`] には、要素への固定された参照を取得するための `get_pin`/`get_pin_mut` メソッドがあります。ただし、(構造的に固定された) コンテンツが移動するため、固定された [`Vec<T>`] で [`pop`][Vec::pop] を呼び出すことは *できません*。また、[`push`][Vec::push] を許可することもできません。これにより、コンテンツが再割り当てされて移動する可能性があります。
//!
//! 構造的な固定がない [`Vec<T>`] は `impl<T> Unpin for Vec<T>` になる可能性があります。これは、内容が固定されることはなく、[`Vec<T>`] 自体も移動しても問題がないためです。
//! その時点で、ピン留めは vector にまったく影響を与えません。
//!
//! 標準ライブラリでは、ポインタタイプには通常、構造的なピン留めがないため、ピン留めの投影は提供されません。これが、`Box<T>: Unpin` がすべての `T` に当てはまる理由です。
//! `Box<T>` を移動しても実際には `T` は移動しないため、ポインタータイプに対してこれを行うのは理にかなっています。`T` が移動しなくても、[`Box<T>`] は自由に移動できます (別名 `Unpin`)。実際、[`ピン`] `<` [`ボックス`] `でさえ <T>>` と [`Pin`] `<＆mut T>` は、同じ理由で常に [`Unpin`] 自体です。それらのコンテンツ (`T`) は固定されていますが、ポインター自体は固定されたデータを移動せずに移動できます。
//! [`Box<T>`] と [`ピン`] `<` [`ボックス`] `の両方 <T>>`、コンテンツが固定されているかどうかは、ポインタが固定されているかどうかとは完全に独立しています。つまり、固定は構造的ではありません。
//!
//! [`Future`] コンビネータを実装する場合、[`poll`] を呼び出すためにそれらへの固定参照を取得する必要があるため、通常、ネストされた futures の構造的な固定が必要になります。
//! ただし、コンビネータにピン留めする必要のない他のデータが含まれている場合は、それらのフィールドを構造化しないようにして、[`Pin`]`<＆mut Self>` (独自の [`poll`] 実装のように)。
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// 固定されたポインター。
///
/// これは、ある種のポインターのラッパーであり、そのポインター "pin" をその値に設定し、[`Unpin`] を実装しない限り、そのポインターによって参照される値が移動されないようにします。
///
///
/// *固定の説明については、[`pin` module] のドキュメントを参照してください。*
///
/// [`pin` module]: self
///
// Note: 以下の `Clone` 派生は、実装可能であるため、不健全を引き起こします
// `Clone` 可変参照用。
// 詳細については、<https://internals.rust-lang.org/t/unsoundness-in-pin/11311> を参照してください。
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// 以下の実装は、健全性の問題を回避するために派生したものではありません。
// `&self.pointer` 信頼できない trait 実装にアクセスできないようにする必要があります。
//
// 詳細については、<https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> を参照してください。
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`] を実装するタイプのデータへのポインターの周りに新しい `Pin<P>` を作成します。
    ///
    /// `Pin::new_unchecked` とは異なり、このメソッドは安全です。これは、ポインター `P` が [`Unpin`] タイプを逆参照し、ピン留めの保証がキャンセルされるためです。
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // 安全性: 指定された値は `Unpin` であるため、要件はありません
        // 固定の周り。
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// この `Pin<P>` をアンラップして、基になるポインターを返します。
    ///
    /// これには、この `Pin` 内のデータが [`Unpin`] である必要があります。これにより、ラップを解除するときにピン留めの不変条件を無視できます。
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` を実装する場合と実装しない場合があるタイプの一部のデータへの参照を中心に新しい `Pin<P>` を作成します。
    ///
    /// `pointer` が `Unpin` タイプを間接参照する場合は、代わりに `Pin::new` を使用する必要があります。
    ///
    /// # Safety
    ///
    /// `pointer` が指すデータが固定されることを保証できないため、このコンストラクターは安全ではありません。つまり、データが削除されるまで、データが移動されたり、ストレージが無効になったりすることはありません。
    /// 構築された `Pin<P>` が、`P` が指すデータが固定されることを保証しない場合、それは API コントラクトの違反であり、後の (safe) 操作で未定義の動作につながる可能性があります。
    ///
    /// このメソッドを使用することにより、`P::Deref` および `P::DerefMut` の実装 (存在する場合) について promise を作成します。
    /// 最も重要なことは、`self` 引数から移動してはならないことです。`Pin::as_mut` と `Pin::as_ref` は、*ピン留めされたポインター* で `DerefMut::deref_mut` と `Deref::deref` を呼び出し、これらのメソッドがピン留めの不変条件を維持することを期待します。
    /// さらに、このメソッドを呼び出すことにより、参照 `P` が逆参照する promise が再び移動されることはありません。特に、`&mut P::Target` を取得してから、その参照から移動できないようにする必要があります (たとえば、[`mem::swap`] を使用)。
    ///
    ///
    /// たとえば、`&'a mut T` で `Pin::new_unchecked` を呼び出すことは安全ではありません。これは、指定されたライフタイム `'a` の間 `Pin::new_unchecked` を固定することはできますが、`'a` が終了した後に固定されたままにするかどうかを制御できないためです。
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // これは、ポインティ `a` が二度と移動できないことを意味するはずです。
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a` のアドレスが `b` のスタックスロットに変更されたため、以前に固定したにもかかわらず、`a` が移動しました。固定 API 契約に違反しました。
    /////
    /// }
    /// ```
    ///
    /// 固定された値は、永久に固定されたままである必要があります (その型が `Unpin` を実装している場合を除く)。
    ///
    /// 同様に、`Rc<T>` で `Pin::new_unchecked` を呼び出すことは、固定制限の対象ではない同じデータへのエイリアスが存在する可能性があるため、安全ではありません。
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // これは、先のとがった人が二度と動くことができないことを意味するはずです。
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // ここで、`x` が唯一の参照である場合、上で固定したデータへの変更可能な参照があり、前の例で見たように、それを使用してデータを移動できます。
    ///     // 固定 API 契約に違反しました。
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// この固定されたポインタから固定された共有参照を取得します。
    ///
    /// これは、`&Pin<Pointer<T>>` から `Pin<&T>` に移行するための一般的な方法です。
    /// `Pin::new_unchecked` の契約の一環として、`Pin<Pointer<T>>` が作成された後、ポインティは移動できないため、安全です。
    ///
    /// "Malicious" `Pointer::Deref` の実装も、`Pin::new_unchecked` の契約によって同様に除外されます。
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // 安全性: この機能に関するドキュメントを参照してください
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// この `Pin<P>` をアンラップして、基になるポインターを返します。
    ///
    /// # Safety
    ///
    /// この機能は安全ではありません。`Pin` 型の不変条件を維持できるように、この関数を呼び出した後も、ポインター `P` を引き続き固定されたものとして扱うことを保証する必要があります。
    /// 結果の `P` を使用するコードが、API コントラクトの違反であり、後の (safe) 操作で未定義の動作につながる可能性があるピン留め不変条件を維持し続けない場合。
    ///
    ///
    /// 基になるデータが [`Unpin`] の場合は、代わりに [`Pin::into_inner`] を使用する必要があります。
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// この固定されたポインタから固定された可変参照を取得します。
    ///
    /// これは、`&mut Pin<Pointer<T>>` から `Pin<&mut T>` に移行するための一般的な方法です。
    /// `Pin::new_unchecked` の契約の一環として、`Pin<Pointer<T>>` が作成された後、ポインティは移動できないため、安全です。
    ///
    /// "Malicious" `Pointer::DerefMut` の実装も、`Pin::new_unchecked` の契約によって同様に除外されます。
    ///
    /// このメソッドは、固定されたタイプを消費する関数に対して複数の呼び出しを行う場合に役立ちます。
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // 何かをする
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` を消費するため、`as_mut` を介して `Pin<&mut Self>` を再借用します。
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // 安全性: この機能に関するドキュメントを参照してください
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// 固定された参照の背後にあるメモリに新しい値を割り当てます。
    ///
    /// これにより、固定されたデータが上書きされますが、問題ありません。そのデストラクタは上書きされる前に実行されるため、固定の保証に違反することはありません。
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// 内部値をマッピングして新しいピンを作成します。
    ///
    /// たとえば、何かのフィールドの `Pin` を取得したい場合は、これを使用して、1 行のコードでそのフィールドにアクセスできます。
    /// ただし、これらの "pinning projections" にはいくつかの落とし穴があります。
    /// このトピックの詳細については、[`pin` module] のドキュメントを参照してください。
    ///
    /// # Safety
    ///
    /// この機能は安全ではありません。
    /// 引数値が移動しない限り (たとえば、その値のフィールドの 1 つであるため)、返されるデータが移動しないこと、および受け取った引数から移動しないことを保証する必要があります。インテリア機能。
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // 安全性: `new_unchecked` の安全契約は
        // 発信者によって支持されました。
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// ピンから共有参照を取得します。
    ///
    /// 共有参照から移動することはできないため、これは安全です。
    /// ここでは内部の可変性に問題があるように見えるかもしれません。実際、`T` を `&RefCell<T>` から移動することは *可能* です。
    /// ただし、同じデータを指す `Pin<&T>` も存在しない限り、これは問題ではありません。また、`RefCell<T>` では、そのコンテンツへの固定参照を作成できません。
    ///
    /// 詳細については、["pinning projections"] の説明を参照してください。
    ///
    /// Note: `Pin` は、ターゲットに `Deref` も実装します。これは、内部値にアクセスするために使用できます。
    /// ただし、`Deref` は、`Pin` 自体の存続期間ではなく、`Pin` の借用期間中存続する参照のみを提供します。
    /// この方法により、`Pin` を元の `Pin` と同じ寿命のリファレンスに変えることができます。
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// この `Pin<&mut T>` を同じ寿命の `Pin<&T>` に変換します。
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// この `Pin` 内のデータへの可変参照を取得します。
    ///
    /// これには、この `Pin` 内のデータが `Unpin` である必要があります。
    ///
    /// Note: `Pin` は、データに `DerefMut` も実装します。これは、内部値にアクセスするために使用できます。
    /// ただし、`DerefMut` は、`Pin` 自体の存続期間ではなく、`Pin` の借用期間中存続する参照のみを提供します。
    ///
    /// この方法により、`Pin` を元の `Pin` と同じ寿命のリファレンスに変えることができます。
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// この `Pin` 内のデータへの可変参照を取得します。
    ///
    /// # Safety
    ///
    /// この機能は安全ではありません。
    /// `Pin` タイプの不変条件を維持できるように、この関数を呼び出すときに受け取る可変参照からデータを移動しないことを保証する必要があります。
    ///
    ///
    /// 基になるデータが `Unpin` の場合は、代わりに `Pin::get_mut` を使用する必要があります。
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// 内部値をマッピングして、新しいピンを作成します。
    ///
    /// たとえば、何かのフィールドの `Pin` を取得したい場合は、これを使用して、1 行のコードでそのフィールドにアクセスできます。
    /// ただし、これらの "pinning projections" にはいくつかの落とし穴があります。
    /// このトピックの詳細については、[`pin` module] のドキュメントを参照してください。
    ///
    /// # Safety
    ///
    /// この機能は安全ではありません。
    /// 引数値が移動しない限り (たとえば、その値のフィールドの 1 つであるため)、返されるデータが移動しないこと、および受け取った引数から移動しないことを保証する必要があります。インテリア機能。
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // 安全性: 発信者は移動しない責任があります
        // この参照からの値。
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // 安全性: `this` の値は
        // 移動されたため、この `new_unchecked` への呼び出しは安全です。
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// 静的参照から固定された参照を取得します。
    ///
    /// `T` は `'static` の存続期間中借用され、終了することはないため、これは安全です。
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // 安全性: ' 静的借用は、データが次のようにならないことを保証します
        // moved/invalidated それが落とされるまで (決してそうはなりません)。
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// 静的な可変参照から固定された可変参照を取得します。
    ///
    /// `T` は `'static` の存続期間中借用され、終了することはないため、これは安全です。
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // 安全性: ' 静的借用は、データが次のようにならないことを保証します
        // moved/invalidated それが落とされるまで (決してそうはなりません)。
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: これは、からの強制を可能にする `CoerceUnsized` の実装を意味します
// `Deref<Target=impl !Unpin>` を暗示するタイプから `Deref<Target=Unpin>` を暗示するタイプは不健全です。
// ただし、そのような impl は他の理由でおそらく不健全になるため、そのような impl が std に到達しないように注意する必要があります。
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}