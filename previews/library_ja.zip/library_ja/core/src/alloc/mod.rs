//! メモリ割り当て API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` エラーは、指定された入力引数をこのアロケータと組み合わせたときに、リソースの枯渇または何か問題が原因である可能性がある割り当ての失敗を示します。
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (これは、trait エラーのダウンストリーム実装に必要です)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` の実装では、[`Layout`][] を介して記述されたデータの任意のブロックを割り当て、拡大、縮小、および割り当て解除できます。
///
/// `Allocator` `MyAlloc([u8; N])` のようなアロケータを使用すると、割り当てられたメモリへのポインタを更新しないと移動できないため、ZST、参照、またはスマートポインタに実装するように設計されています。
///
/// [`GlobalAlloc`][] とは異なり、`Allocator` ではゼロサイズの割り当てが許可されます。
/// 基礎となるアロケータがこれをサポートしない場合 (jemalloc など)、または null ポインタを返す場合 (`libc::malloc` など)、これを実装でキャッチする必要があります。
///
/// ### 現在割り当てられているメモリ
///
/// 一部の方法では、メモリブロックをアロケータを介して *現在割り当て* する必要があります。この意味は:
///
/// * そのメモリブロックの開始アドレスは、以前に [`allocate`]、[`grow`]、または [`shrink`] によって返され、
///
/// * その後、メモリブロックの割り当てが解除されていません。ブロックは、[`deallocate`] に渡されることによって直接割り当てが解除されるか、`Ok` を返す [`grow`] または [`shrink`] に渡されることによって変更されます。
///
/// `grow` または `shrink` が `Err` を返した場合、渡されたポインターは有効なままです。
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### メモリーフィッティング
///
/// 一部の方法では、レイアウトがメモリブロックに *適合する* 必要があります。
/// "fit" へのレイアウトのメモリブロック (または同等に、"fit" へのメモリブロックのレイアウト) が意味することは、次の条件が満たされなければならないということです。
///
/// * ブロックは、[`layout.align()`] と同じ配置で割り当てる必要があります。
///
/// * 提供される [`layout.size()`] は、`min ..= max` の範囲内にある必要があります。
///   - `min` ブロックの割り当てに最近使用されたレイアウトのサイズであり、
///   - `max` [`allocate`]、[`grow`]、または [`shrink`] から返される最新の実際のサイズです。
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * アロケータから返されるメモリブロックは、有効なメモリを指し、インスタンスとそのすべてのクローンが削除されるまでその有効性を保持する必要があります。
///
/// * アロケータのクローンを作成または移動して、このアロケータから返されたメモリブロックを無効にしないでください。複製されたアロケータは、同じアロケータのように動作する必要があり、
///
/// * [*currently allocated*] であるメモリブロックへのポインタは、アロケータの他のメソッドに渡すことができます。
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// メモリのブロックを割り当てようとします。
    ///
    /// 成功すると、`layout` のサイズと配置の保証を満たす [`NonNull<[u8]>`][NonNull] を返します。
    ///
    /// 返されるブロックのサイズは `layout.size()` で指定されているサイズよりも大きい場合があり、内容が初期化されている場合とされていない場合があります。
    ///
    /// # Errors
    ///
    /// `Err` を返すことは、メモリが使い果たされているか、`layout` がアロケータのサイズまたは配置の制約を満たしていないことを示します。
    ///
    /// 実装では、パニックや中止ではなく、メモリが枯渇したときに `Err` を返すことをお勧めしますが、これは厳密な要件ではありません。
    /// (具体的には、この trait を、メモリの枯渇時に中止する基礎となるネイティブ割り当てライブラリの上に実装することは *合法* です。)
    ///
    /// 割り当てエラーに応答して計算を中止したいクライアントは、`panic!` などを直接呼び出すのではなく、[`handle_alloc_error`] 関数を呼び出すことをお勧めします。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` のように動作しますが、返されるメモリがゼロで初期化されることも保証します。
    ///
    /// # Errors
    ///
    /// `Err` を返すことは、メモリが使い果たされているか、`layout` がアロケータのサイズまたは配置の制約を満たしていないことを示します。
    ///
    /// 実装では、パニックや中止ではなく、メモリが枯渇したときに `Err` を返すことをお勧めしますが、これは厳密な要件ではありません。
    /// (具体的には、この trait を、メモリの枯渇時に中止する基礎となるネイティブ割り当てライブラリの上に実装することは *合法* です。)
    ///
    /// 割り当てエラーに応答して計算を中止したいクライアントは、`panic!` などを直接呼び出すのではなく、[`handle_alloc_error`] 関数を呼び出すことをお勧めします。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // 安全性: `alloc` は有効なメモリブロックを返します
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` によって参照されるメモリの割り当てを解除します。
    ///
    /// # Safety
    ///
    /// * `ptr` このアロケータを介してメモリ [*currently allocated*] のブロックを示す必要があります。
    /// * `layout` そのメモリブロックを [*fit*] する必要があります。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// メモリブロックを拡張しようとします。
    ///
    /// ポインタと割り当てられたメモリの実際のサイズを含む新しい [`NonNull<[u8]>`][NonNull] を返します。ポインタは、`new_layout` によって記述されたデータを保持するのに適しています。
    /// これを実現するために、アロケータは `ptr` によって参照される割り当てを拡張して、新しいレイアウトに合わせることができます。
    ///
    /// これが `Ok` を返す場合、`ptr` によって参照されるメモリブロックの所有権はこのアロケータに転送されています。
    /// メモリは解放されている場合とされていない場合があり、このメソッドの戻り値を介して呼び出し元に再度転送されない限り、使用不可と見なす必要があります。
    ///
    /// このメソッドが `Err` を返す場合、メモリブロックの所有権はこのアロケータに譲渡されておらず、メモリブロックの内容は変更されていません。
    ///
    /// # Safety
    ///
    /// * `ptr` このアロケータを介してメモリ [*currently allocated*] のブロックを示す必要があります。
    /// * `old_layout` そのメモリブロックを [*fit*] する必要があります (`new_layout` 引数はそれに適合する必要はありません)。
    /// * `new_layout.size()` `old_layout.size()` 以上である必要があります。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 新しいレイアウトがアロケーターのサイズとアロケーターの配置制約を満たしていない場合、またはそれ以外の場合の拡張が失敗した場合は、`Err` を返します。
    ///
    /// 実装では、パニックや中止ではなく、メモリが枯渇したときに `Err` を返すことをお勧めしますが、これは厳密な要件ではありません。
    /// (具体的には、この trait を、メモリの枯渇時に中止する基礎となるネイティブ割り当てライブラリの上に実装することは *合法* です。)
    ///
    /// 割り当てエラーに応答して計算を中止したいクライアントは、`panic!` などを直接呼び出すのではなく、[`handle_alloc_error`] 関数を呼び出すことをお勧めします。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 安全性: `new_layout.size()` は以上でなければならないため
        // `old_layout.size()`, 古いメモリ割り当てと新しいメモリ割り当ての両方が、`old_layout.size()` バイトの読み取りと書き込みに有効です。
        // また、古い割り当てはまだ割り当て解除されていないため、`new_ptr` と重複することはできません。
        // したがって、`copy_nonoverlapping` への呼び出しは安全です。
        // `dealloc` の安全契約は、発信者が支持する必要があります。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` のように動作しますが、返される前に新しいコンテンツがゼロに設定されていることも確認します。
    ///
    /// の呼び出しが成功すると、メモリブロックには次の内容が含まれます。
    /// `grow_zeroed`:
    ///   * バイト `0..old_layout.size()` は、元の割り当てから保持されます。
    ///   * バイト `old_layout.size()..old_size` は、アロケータの実装に応じて、保持またはゼロ化されます。
    ///   `old_size` `grow_zeroed` 呼び出し前のメモリブロックのサイズを指します。これは、割り当て時に最初に要求されたサイズよりも大きい場合があります。
    ///   * バイト `old_size..new_size` はゼロになります。`new_size` は、`grow_zeroed` 呼び出しによって返されるメモリブロックのサイズを指します。
    ///
    /// # Safety
    ///
    /// * `ptr` このアロケータを介してメモリ [*currently allocated*] のブロックを示す必要があります。
    /// * `old_layout` そのメモリブロックを [*fit*] する必要があります (`new_layout` 引数はそれに適合する必要はありません)。
    /// * `new_layout.size()` `old_layout.size()` 以上である必要があります。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 新しいレイアウトがアロケーターのサイズとアロケーターの配置制約を満たしていない場合、またはそれ以外の場合の拡張が失敗した場合は、`Err` を返します。
    ///
    /// 実装では、パニックや中止ではなく、メモリが枯渇したときに `Err` を返すことをお勧めしますが、これは厳密な要件ではありません。
    /// (具体的には、この trait を、メモリの枯渇時に中止する基礎となるネイティブ割り当てライブラリの上に実装することは *合法* です。)
    ///
    /// 割り当てエラーに応答して計算を中止したいクライアントは、`panic!` などを直接呼び出すのではなく、[`handle_alloc_error`] 関数を呼び出すことをお勧めします。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // 安全性: `new_layout.size()` は以上でなければならないため
        // `old_layout.size()`, 古いメモリ割り当てと新しいメモリ割り当ての両方が、`old_layout.size()` バイトの読み取りと書き込みに有効です。
        // また、古い割り当てはまだ割り当て解除されていないため、`new_ptr` と重複することはできません。
        // したがって、`copy_nonoverlapping` への呼び出しは安全です。
        // `dealloc` の安全契約は、発信者が支持する必要があります。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// メモリブロックを縮小しようとします。
    ///
    /// ポインタと割り当てられたメモリの実際のサイズを含む新しい [`NonNull<[u8]>`][NonNull] を返します。ポインタは、`new_layout` によって記述されたデータを保持するのに適しています。
    /// これを実現するために、アロケータは `ptr` によって参照される割り当てを縮小して、新しいレイアウトに合わせることができます。
    ///
    /// これが `Ok` を返す場合、`ptr` によって参照されるメモリブロックの所有権はこのアロケータに転送されています。
    /// メモリは解放されている場合とされていない場合があり、このメソッドの戻り値を介して呼び出し元に再度転送されない限り、使用不可と見なす必要があります。
    ///
    /// このメソッドが `Err` を返す場合、メモリブロックの所有権はこのアロケータに譲渡されておらず、メモリブロックの内容は変更されていません。
    ///
    /// # Safety
    ///
    /// * `ptr` このアロケータを介してメモリ [*currently allocated*] のブロックを示す必要があります。
    /// * `old_layout` そのメモリブロックを [*fit*] する必要があります (`new_layout` 引数はそれに適合する必要はありません)。
    /// * `new_layout.size()` `old_layout.size()` 以下である必要があります。
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// 新しいレイアウトがアロケーターのサイズとアロケーターの配置制約を満たしていない場合、または縮小が失敗した場合は、`Err` を返します。
    ///
    /// 実装では、パニックや中止ではなく、メモリが枯渇したときに `Err` を返すことをお勧めしますが、これは厳密な要件ではありません。
    /// (具体的には、この trait を、メモリの枯渇時に中止する基礎となるネイティブ割り当てライブラリの上に実装することは *合法* です。)
    ///
    /// 割り当てエラーに応答して計算を中止したいクライアントは、`panic!` などを直接呼び出すのではなく、[`handle_alloc_error`] 関数を呼び出すことをお勧めします。
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // 安全性: `new_layout.size()` は以下でなければならないため
        // `old_layout.size()`, 古いメモリ割り当てと新しいメモリ割り当ての両方が、`new_layout.size()` バイトの読み取りと書き込みに有効です。
        // また、古い割り当てはまだ割り当て解除されていないため、`new_ptr` と重複することはできません。
        // したがって、`copy_nonoverlapping` への呼び出しは安全です。
        // `dealloc` の安全契約は、発信者が支持する必要があります。
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` のこのインスタンス用の "by reference" アダプターを作成します。
    ///
    /// 返されたアダプタも `Allocator` を実装しており、これを借用するだけです。
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // 安全性: 安全契約は発信者が支持する必要があります
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全性: 安全契約は発信者が支持する必要があります
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全性: 安全契約は発信者が支持する必要があります
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // 安全性: 安全契約は発信者が支持する必要があります
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}