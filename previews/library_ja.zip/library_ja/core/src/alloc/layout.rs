use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// この関数は 1 つの場所で使用され、その実装はインライン化できますが、以前の試みでは rustc が遅くなりました。
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// メモリブロックのレイアウト。
///
/// `Layout` のインスタンスは、メモリの特定のレイアウトを記述します。
/// アロケータに与える入力として `Layout` を構築します。
///
/// すべてのレイアウトには、関連するサイズと 2 の累乗の配置があります。
///
/// (`GlobalAlloc` ではすべてのメモリ要求のサイズがゼロ以外である必要がありますが、レイアウトのサイズがゼロ以外である必要は *ありません*。
/// 発信者は、このような条件が満たされていることを確認するか、要件が緩い特定のアロケータを使用するか、より寛大な `Allocator` インターフェイスを使用する必要があります。)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // 要求されたメモリブロックのサイズ。バイト単位で測定されます。
    size_: usize,

    // バイト単位で測定された、要求されたメモリブロックの配置。
    // `posix_memalign` のような API はそれを必要とし、レイアウトコンストラクターに課すのは合理的な制約であるため、これが常に 2 の累乗であることを保証します。
    //
    //
    // (ただし、同様に `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) は必要ありません。
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// 指定された `size` および `align` から `Layout` を構築するか、次の条件のいずれかが満たされない場合は `LayoutError` を返します。
    ///
    /// * `align` ゼロであってはなりません、
    ///
    /// * `align` 2 の累乗でなければなりません、
    ///
    /// * `size`, `align` の最も近い倍数に切り上げられる場合、オーバーフローしてはなりません (つまり、切り上げられた値は `usize::MAX` 以下である必要があります)。
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (2 の累乗は整列! =0 を意味します。)

        // 切り上げサイズは次のとおりです。
        //   size_rounded_up= (size + align、1)＆! (align、1) ;
        //
        // 上から、整列! =0 であることがわかります。
        // 追加 (align、1) がオーバーフローしない場合は、切り上げで問題ありません。
        //
        // 逆に、! (align、1) を使用した＆- マスキングは、下位ビットのみを減算します。
        // したがって、合計でオーバーフローが発生した場合、＆マスクはそのオーバーフローを元に戻すのに十分な減算を行うことができません。
        //
        //
        // 上記は、合計オーバーフローのチェックが必要かつ十分であることを意味します。
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // 安全性: `from_size_align_unchecked` の条件は
        // 上記を確認してください。
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// すべてのチェックをバイパスして、レイアウトを作成します。
    ///
    /// # Safety
    ///
    /// この関数は、[`Layout::from_size_align`] からの前提条件を検証しないため、安全ではありません。
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // 安全性: 発信者は、`align` がゼロより大きいことを確認する必要があります。
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// このレイアウトのメモリブロックの最小サイズ (バイト単位)。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// このレイアウトのメモリブロックの最小バイトアラインメント。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// タイプ `T` の値を保持するのに適した `Layout` を構築します。
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // 安全性: 整列は Rust によって 2 の累乗であることが保証されています
        // size + align コンボは、アドレススペースに収まることが保証されています。
        // 結果として、ここでチェックされていないコンストラクターを使用して、十分に最適化されていない場合に panics というコードを挿入しないようにします。
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (trait またはスライスのような他のサイズのないタイプ) のバッキング構造を割り当てるために使用できるレコードを説明するレイアウトを生成します。
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 安全性: これが安全でないバリアントを使用している理由については、`new` の理論的根拠を参照してください
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` (trait またはスライスのような他のサイズのないタイプ) のバッキング構造を割り当てるために使用できるレコードを説明するレイアウトを生成します。
    ///
    /// # Safety
    ///
    /// この関数は、次の条件が当てはまる場合にのみ安全に呼び出すことができます。
    ///
    /// - `T` が `Sized` の場合、この関数はいつでも安全に呼び出すことができます。
    /// - `T` のサイズのないテールが次の場合:
    ///     - [slice] の場合、スライステールの長さは初期化された整数である必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
    ///     - [trait object] の場合、ポインターの vtable 部分は、サイズ変更の強制によって取得されたタイプ `T` の有効な vtable を指している必要があり、*全体の値*(動的テール長 + 静的サイズのプレフィックス) のサイズは `isize` に収まる必要があります。
    ///
    ///     - (unstable) [extern type] の場合、この関数は常に安全に呼び出すことができますが、extern タイプのレイアウトが不明であるため、panic またはその他の方法で間違った値を返す可能性があります。
    ///     これは、extern タイプのテールへの参照での [`Layout::for_value`] と同じ動作です。
    ///     - それ以外の場合、この関数を呼び出すことは控えめに許可されていません。
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // 安全性: これらの関数の前提条件を呼び出し元に渡します
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // 安全性: これが安全でないバリアントを使用している理由については、`new` の理論的根拠を参照してください
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ぶら下がっているが、このレイアウトに適切に配置された `NonNull` を作成します。
    ///
    /// ポインター値は有効なポインターを表す可能性があることに注意してください。つまり、これを "not yet initialized" 番兵値として使用してはなりません。
    /// 遅延割り当てするタイプは、他の方法で初期化を追跡する必要があります。
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // 安全性: 整列はゼロ以外であることが保証されています
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` と同じレイアウトの値を保持できるが、位置合わせ `align` (バイト単位で測定) にも位置合わせされるレコードを記述するレイアウトを作成します。
    ///
    ///
    /// `self` がすでに規定の位置合わせを満たしている場合は、`self` を返します。
    ///
    /// このメソッドは、返されるレイアウトの配置が異なるかどうかに関係なく、全体のサイズにパディングを追加しないことに注意してください。
    /// つまり、`K` のサイズが 16 の場合、`K.align_to(32)` のサイズは *まだ* です。
    ///
    /// `self.size()` と指定された `align` の組み合わせが、[`Layout::from_size_align`] にリストされている条件に違反している場合、エラーを返します。
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// 次のアドレスが `align` (バイト単位で測定) を満たすことを保証するために、`self` の後に挿入する必要があるパディングの量を返します。
    ///
    /// たとえば、`self.size()` が 9 の場合、`self.padding_needed_for(4)` は 3 を返します。これは、4 整列アドレスを取得するために必要なパディングの最小バイト数であるためです (対応するメモリブロックが 4 整列アドレスで始まると仮定)。
    ///
    ///
    /// `align` が 2 の累乗でない場合、この関数の戻り値は意味がありません。
    ///
    /// 戻り値のユーティリティでは、`align` が、割り当てられたメモリブロック全体の開始アドレスの配置以下である必要があることに注意してください。この制約を満たす 1 つの方法は、`align <= self.align()` を確保することです。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // 切り上げられた値は次のとおりです。
        //   len_rounded_up= (len + align、1)＆! (align、1) ;
        // 次に、パディングの差を返します。`len_rounded_up - len`.
        //
        // 全体を通してモジュラー演算を使用します。
        //
        // 1. align は > 0 であることが保証されているため、align、1 は常に有効です。
        //
        // 2.
        // `len + align - 1` 最大で `align - 1` までオーバーフローする可能性があるため、`!(align - 1)` を使用した＆マスクにより、オーバーフローが発生した場合、`len_rounded_up` 自体が 0 になります。
        //
        //    したがって、返されたパディングを `len` に追加すると、0 が生成されます。これは、アライメント `align` を簡単に満たします。
        //
        // (もちろん、上記の方法でサイズとパディングがオーバーフローするメモリのブロックを割り当てようとすると、アロケータはとにかくエラーを生成するはずです。)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// このレイアウトのサイズをレイアウトの配置の倍数に切り上げて、レイアウトを作成します。
    ///
    ///
    /// これは、`padding_needed_for` の結果をレイアウトの現在のサイズに追加することと同じです。
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // これはオーバーフローできません。レイアウトの不変条件からの引用:
        // > `size`, `align` の最も近い倍数に切り上げた場合、
        // > オーバーフローしてはなりません (つまり、丸められた値は以下でなければなりません)
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` の `n` インスタンスのレコードを説明するレイアウトを作成し、各インスタンスに要求されたサイズと配置が確実に与えられるように、それぞれの間に適切な量のパディングを配置します。
    /// 成功すると、`(k, offs)` を返します。ここで、`k` は配列のレイアウトであり、`offs` は配列内の各要素の開始間の距離です。
    ///
    /// 算術オーバーフローの場合、`LayoutError` を返します。
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // これはオーバーフローできません。レイアウトの不変条件からの引用:
        // > `size`, `align` の最も近い倍数に切り上げた場合、
        // > オーバーフローしてはなりません (つまり、丸められた値は以下でなければなりません)
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // 安全性: self.align はすでに有効であることがわかっており、alloc_size は有効です。
        // すでにパディングされています。
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` の後に `next` が続くレコードを説明するレイアウトを作成します。これには、`next` が適切に配置されるようにするために必要なパディングが含まれますが、*末尾のパディングはありません*。
    ///
    /// C 表現レイアウト `repr(C)` に一致させるには、すべてのフィールドでレイアウトを拡張した後、`pad_to_align` を呼び出す必要があります。
    /// (デフォルトの Rust 表現レイアウト `repr(Rust)`, as it is unspecified.) に一致させる方法はありません
    ///
    /// 結果のレイアウトの配置は、両方のパーツの配置を確実にするために、`self` と `next` の配置の最大値になることに注意してください。
    ///
    /// `Ok((k, offset))` を返します。ここで、`k` は連結されたレコードのレイアウトであり、`offset` は連結されたレコード内に埋め込まれた `next` の開始の相対位置 (バイト単位) です (レコード自体がオフセット 0 で開始すると想定)。
    ///
    ///
    /// 算術オーバーフローの場合、`LayoutError` を返します。
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` 構造のレイアウトと、そのフィールドのレイアウトからのフィールドのオフセットを計算するには、次のようにします。
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` でファイナライズすることを忘れないでください!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // それが機能することをテストする
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` の `n` インスタンスのレコードを説明するレイアウトを作成し、各インスタンス間にパディングはありません。
    ///
    /// `repeat` とは異なり、`repeat_packed` は、`self` の特定のインスタンスが適切に配置されている場合でも、`self` の繰り返しインスタンスが適切に配置されることを保証しないことに注意してください。
    /// つまり、`repeat_packed` によって返されるレイアウトを使用して配列を割り当てる場合、配列内のすべての要素が適切に配置されるとは限りません。
    ///
    /// 算術オーバーフローの場合、`LayoutError` を返します。
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self` とそれに続く `next` のレコードを説明するレイアウトを作成し、2 つの間に追加のパディングはありません。
    /// パディングが挿入されていないため、`next` の配置は関係なく、結果のレイアウトに *まったく* 組み込まれません。
    ///
    ///
    /// 算術オーバーフローの場合、`LayoutError` を返します。
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` のレコードを説明するレイアウトを作成します。
    ///
    /// 算術オーバーフローの場合、`LayoutError` を返します。
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` またはその他の `Layout` コンストラクターに指定されたパラメーターは、文書化された制約を満たしていません。
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (これは、trait エラーのダウンストリーム実装に必要です)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}