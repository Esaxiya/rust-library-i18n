//! コンパイラ組み込み関数。
//!
//! 対応する定義は `compiler/rustc_codegen_llvm/src/intrinsic.rs` にあります。
//! 対応する const の実装は `compiler/rustc_mir/src/interpret/intrinsics.rs` にあります
//!
//! # Const の本質
//!
//! Note: 組み込み関数の恒常性に対する変更については、言語チームと話し合う必要があります。
//! これには、恒常性の安定性の変化が含まれます。
//!
//! コンパイル時に組み込み関数を使用可能にするには、実装を <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> から `compiler/rustc_mir/src/interpret/intrinsics.rs` にコピーし、`#[rustc_const_unstable(feature = "foo", issue = "01234")]` を組み込み関数に追加する必要があります。
//!
//!
//! 組み込みが `rustc_const_stable` 属性を持つ `const fn` から使用されることになっている場合、組み込みの属性も `rustc_const_stable` である必要があります。
//! このような変更は、コンパイラのサポートなしではユーザーコードで複製できない機能を言語に組み込むため、T-lang の協議なしに行うべきではありません。
//!
//! # Volatiles
//!
//! 揮発性組み込み関数は、I/O メモリで動作することを目的とした操作を提供します。これは、他の揮発性組み込み関数間でコンパイラによって並べ替えられないことが保証されています。[[volatile]] の LLVM ドキュメントを参照してください。
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! アトミック組み込み関数は、複数の可能なメモリ順序で、マシンワードに対する一般的なアトミック操作を提供します。それらは、C ++ 11 と同じセマンティクスに従います。[[atomics]] の LLVM ドキュメントを参照してください。
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! メモリオーダリングの簡単な復習:
//!
//! * ロックを取得するための障壁を取得します。後続の読み取りと書き込みは、バリアの後で行われます。
//! * 解放、ロックを解放するための障壁。先行する読み取りと書き込みは、バリアの前で行われます。
//! * 逐次一貫性、逐次一貫性のある操作が順番に行われることが保証されています。これはアトミックタイプを操作するための標準モードであり、Java の `volatile` と同等です。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// これらのインポートは、ドキュメント内リンクを簡素化するために使用されます
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 安全性: `ptr::drop_in_place` を参照
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // 注意: これらの組み込み関数は、エイリアスメモリを変更するため、生のポインタを取ります。これは、`&` または `&mut` のどちらにも無効です。
    //

    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::SeqCst`] を渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::Acquire`] を渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Release`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::AcqRel`] を `success` として、[`Ordering::Acquire`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::Relaxed`] を渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::SeqCst`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::SeqCst`] を `success` として、[`Ordering::Acquire`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Acquire`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::AcqRel`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::SeqCst`] を渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::Acquire`] を渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Release`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::AcqRel`] を `success` として、[`Ordering::Acquire`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、`success` パラメーターと `failure` パラメーターの両方として [`Ordering::Relaxed`] を渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    ///
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::SeqCst`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::SeqCst`] を `success` として、[`Ordering::Acquire`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Acquire`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 現在の値が `old` 値と同じである場合、値を格納します。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::AcqRel`] を `success` として、[`Ordering::Relaxed`] を `failure` パラメーターとして渡すことにより、`compare_exchange_weak` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ポインタの現在の値をロードします。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`load` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// ポインタの現在の値をロードします。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`load` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// ポインタの現在の値をロードします。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`load` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// 指定されたメモリ位置に値を格納します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`store` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// 指定されたメモリ位置に値を格納します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`store` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// 指定されたメモリ位置に値を格納します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`store` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// 指定されたメモリ位置に値を格納し、古い値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`swap` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// 指定されたメモリ位置に値を格納し、古い値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`swap` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 指定されたメモリ位置に値を格納し、古い値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`swap` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 指定されたメモリ位置に値を格納し、古い値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`swap` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 指定されたメモリ位置に値を格納し、古い値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`swap` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 現在の値に追加し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_add` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値に追加し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_add` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値に追加し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_add` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値に追加し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_add` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値に追加し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_add` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 現在の値から減算し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_sub` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値から減算し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_sub` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値から減算し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_sub` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値から減算し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_sub` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値から減算し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_sub` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ビット単位で現在の値を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_and` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位で現在の値を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_and` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位で現在の値を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_and` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位で現在の値を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_and` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位で現在の値を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_and` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 現在の値をビット単位で nand し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_nand` メソッドを介して [`AtomicBool`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値をビット単位で nand し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_nand` メソッドを介して [`AtomicBool`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値をビット単位で nand し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_nand` メソッドを介して [`AtomicBool`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値をビット単位で nand し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_nand` メソッドを介して [`AtomicBool`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値をビット単位で nand し、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_nand` メソッドを介して [`AtomicBool`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ビット単位または現在の値で、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_or` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位または現在の値で、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_or` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位または現在の値で、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_or` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位または現在の値で、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_or` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ビット単位または現在の値で、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_or` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 現在の値とビット単位の xor を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_xor` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値とビット単位の xor を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_xor` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値とビット単位の xor を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_xor` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値とビット単位の xor を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_xor` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値とビット単位の xor を使用して、前の値を返します。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_xor` メソッドを介して [`atomic`] タイプで使用できます。
    /// 例えば、 [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 符号付き比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値で最大。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 現在の値で最大。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 符号付き比較を使用した現在の値での最小値。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値での最小値。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値での最小値。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値での最小値。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号付き比較を使用した現在の値での最小値。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号付き整数型で使用できます。
    /// 例えば、 [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 符号なし比較を使用した現在の値での最小値。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値での最小値。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値での最小値。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値での最小値。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値での最小値。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_min` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 符号なし比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値で最大。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値で最大。
    ///
    /// この組み込み関数の安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 符号なし比較を使用した現在の値で最大。
    ///
    /// この組み込み型の安定化バージョンは、[`Ordering::Relaxed`] を `order` として渡すことにより、`fetch_max` メソッドを介して [`atomic`] 符号なし整数型で使用できます。
    /// 例えば、 [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` 組み込み関数は、サポートされている場合にプリフェッチ命令を挿入するためのコードジェネレーターへのヒントです。それ以外の場合は、何もしません。
    /// プリフェッチはプログラムの動作には影響しませんが、パフォーマンス特性を変更する可能性があります。
    ///
    /// `locality` 引数は定数整数である必要があり、(0) (局所性なし) から (3) (非常にローカルなキャッシュ内保持) までの範囲の時間的局所性指定子です。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` 組み込み関数は、サポートされている場合にプリフェッチ命令を挿入するためのコードジェネレーターへのヒントです。それ以外の場合は、何もしません。
    /// プリフェッチはプログラムの動作には影響しませんが、パフォーマンス特性を変更する可能性があります。
    ///
    /// `locality` 引数は定数整数である必要があり、(0) (局所性なし) から (3) (非常にローカルなキャッシュ内保持) までの範囲の時間的局所性指定子です。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` 組み込み関数は、サポートされている場合にプリフェッチ命令を挿入するためのコードジェネレーターへのヒントです。それ以外の場合は、何もしません。
    /// プリフェッチはプログラムの動作には影響しませんが、パフォーマンス特性を変更する可能性があります。
    ///
    /// `locality` 引数は定数整数である必要があり、(0) (局所性なし) から (3) (非常にローカルなキャッシュ内保持) までの範囲の時間的局所性指定子です。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` 組み込み関数は、サポートされている場合にプリフェッチ命令を挿入するためのコードジェネレーターへのヒントです。それ以外の場合は、何もしません。
    /// プリフェッチはプログラムの動作には影響しませんが、パフォーマンス特性を変更する可能性があります。
    ///
    /// `locality` 引数は定数整数である必要があり、(0) (局所性なし) から (3) (非常にローカルなキャッシュ内保持) までの範囲の時間的局所性指定子です。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// アトミックフェンス。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、[`atomic::fence`] で使用できます。
    ///
    ///
    pub fn atomic_fence();
    /// アトミックフェンス。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、[`atomic::fence`] で使用できます。
    ///
    ///
    pub fn atomic_fence_acq();
    /// アトミックフェンス。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、[`atomic::fence`] で使用できます。
    ///
    ///
    pub fn atomic_fence_rel();
    /// アトミックフェンス。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、[`atomic::fence`] で使用できます。
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// コンパイラのみのメモリバリア。
    ///
    /// メモリアクセスは、コンパイラによってこのバリアを越えて並べ替えられることはありませんが、命令は発行されません。
    /// これは、シグナルハンドラーと対話する場合など、プリエンプトされる可能性のある同じスレッドでの操作に適しています。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::SeqCst`] を `order` として渡すことにより、[`atomic::compiler_fence`] で使用できます。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// コンパイラのみのメモリバリア。
    ///
    /// メモリアクセスは、コンパイラによってこのバリアを越えて並べ替えられることはありませんが、命令は発行されません。
    /// これは、シグナルハンドラーと対話する場合など、プリエンプトされる可能性のある同じスレッドでの操作に適しています。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Acquire`] を `order` として渡すことにより、[`atomic::compiler_fence`] で使用できます。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// コンパイラのみのメモリバリア。
    ///
    /// メモリアクセスは、コンパイラによってこのバリアを越えて並べ替えられることはありませんが、命令は発行されません。
    /// これは、シグナルハンドラーと対話する場合など、プリエンプトされる可能性のある同じスレッドでの操作に適しています。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::Release`] を `order` として渡すことにより、[`atomic::compiler_fence`] で使用できます。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// コンパイラのみのメモリバリア。
    ///
    /// メモリアクセスは、コンパイラによってこのバリアを越えて並べ替えられることはありませんが、命令は発行されません。
    /// これは、シグナルハンドラーと対話する場合など、プリエンプトされる可能性のある同じスレッドでの操作に適しています。
    ///
    /// この組み込みの安定化バージョンは、[`Ordering::AcqRel`] を `order` として渡すことにより、[`atomic::compiler_fence`] で使用できます。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// 関数に付加された属性からその意味を引き出す魔法の本質。
    ///
    /// たとえば、dataflow はこれを使用して静的アサーションを挿入し、`rustc_peek(potentially_uninitialized)` が実際に、データフローが制御フローのその時点で初期化されていないことを実際に計算したことを再確認します。
    ///
    ///
    /// この組み込み関数は、コンパイラの外部で使用しないでください。
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// プロセスの実行を中止します。
    ///
    /// この操作のよりユーザーフレンドリーで安定したバージョンは [`std::process::abort`](../../std/process/fn.abort.html) です。
    ///
    pub fn abort() -> !;

    /// コード内のこのポイントに到達できないことをオプティマイザーに通知し、さらに最適化できるようにします。
    ///
    /// 注意: これは `unreachable!()` マクロとは大きく異なります。実行時に panics であるマクロとは異なり、この関数でマークされたコードに到達することは *未定義の動作* です。
    ///
    ///
    /// この組み込みの安定化バージョンは [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) です。
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// 条件が常に真であることをオプティマイザに通知します。
    /// 条件が false の場合、動作は未定義です。
    ///
    /// この組み込み関数のコードは生成されませんが、オプティマイザーはパス間でコード (およびその状態) を保持しようとします。これにより、周囲のコードの最適化が妨げられ、パフォーマンスが低下する可能性があります。
    /// 不変条件がオプティマイザー自体で検出できる場合、または重要な最適化が有効になっていない場合は、使用しないでください。
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch 条件が真である可能性が高いというコンパイラーへのヒント。
    /// 渡された値を返します。
    ///
    /// `if` ステートメント以外で使用しても、おそらく効果はありません。
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch 条件が false である可能性が高いというコンパイラーへのヒント。
    /// 渡された値を返します。
    ///
    /// `if` ステートメント以外で使用しても、おそらく効果はありません。
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// デバッガーによる検査のために、ブレークポイントトラップを実行します。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn breakpoint();

    /// タイプのサイズ (バイト単位)。
    ///
    /// より具体的には、これは、配置パディングを含む、同じタイプの連続するアイテム間のバイト単位のオフセットです。
    ///
    ///
    /// この組み込みの安定化バージョンは [`core::mem::size_of`](crate::mem::size_of) です。
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// タイプの最小配置。
    ///
    /// この組み込みの安定化バージョンは [`core::mem::align_of`](crate::mem::align_of) です。
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// タイプの優先配置。
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// 参照される値のサイズ (バイト単位)。
    ///
    /// この組み込みの安定化バージョンは [`mem::size_of_val`] です。
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// 参照値の必要な配置。
    ///
    /// この組み込みの安定化バージョンは [`core::mem::align_of_val`](crate::mem::align_of_val) です。
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// タイプの名前を含む静的文字列スライスを取得します。
    ///
    /// この組み込みの安定化バージョンは [`core::any::type_name`](crate::any::type_name) です。
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// 指定されたタイプにグローバルに一意の識別子を取得します。
    /// この関数は、呼び出された crate に関係なく、型に対して同じ値を返します。
    ///
    ///
    /// この組み込みの安定化バージョンは [`core::any::TypeId::of`](crate::any::TypeId::of) です。
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` が無人の場合に実行できない安全でない機能のガード:
    /// これは静的に panic になるか、何もしません。
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` がゼロ初期化を許可しない場合に実行できない安全でない関数のガード: これは静的に panic になるか、何もしません。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn assert_zero_valid<T>();

    /// `T` に無効なビットパターンがある場合に実行できない安全でない関数のガード: これは静的に panic になるか、何もしません。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn assert_uninit_valid<T>();

    /// 呼び出された場所を示す静的 `Location` への参照を取得します。
    ///
    /// 代わりに [`core::panic::Location::caller`](crate::panic::Location::caller) の使用を検討してください。
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ドロップグルーを実行せずに値をスコープ外に移動します。
    ///
    /// これは [`mem::forget_unsized`] にのみ存在します。通常の `forget` は代わりに `ManuallyDrop` を使用します。
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// あるタイプの値のビットを別のタイプとして再解釈します。
    ///
    /// 両方のタイプは同じサイズである必要があります。
    /// オリジナルも結果も [invalid value](../../nomicon/what-unsafe-does.html) ではない可能性があります。
    ///
    /// `transmute` あるタイプから別のタイプへのビット単位の移動と意味的に同等です。ソース値からデスティネーション値にビットをコピーしてから、元の値を忘れます。
    /// これは、`transmute_copy` と同様に、内部の C の `memcpy` と同等です。
    ///
    /// `transmute` は値による操作であるため、*変換された値自体* の整列は問題ではありません。
    /// 他の関数と同様に、コンパイラは `T` と `U` の両方が適切に配置されていることをすでに確認しています。
    /// ただし、*他の場所を指す* 値 (ポインター、参照、ボックスなど) を変換する場合、呼び出し元は、ポイントされた値の適切な配置を確認する必要があります。
    ///
    /// `transmute` **信じられないほど** 安全ではありません。この機能で [undefined behavior][ub] を発生させる方法は多数あります。`transmute` は絶対的な最後の手段でなければなりません。
    ///
    /// [nomicon](../../nomicon/transmutes.html) には追加のドキュメントがあります。
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` が本当に役立つことがいくつかあります。
    ///
    /// ポインタを関数ポインタに変える。これは、関数ポインタとデータポインタのサイズが異なるマシンには移植できません。
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// 寿命を延ばす、または不変の寿命を短くする。これは高度で、非常に危険な Rust です!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// 絶望しないでください。`transmute` の多くの用途は他の方法で実現できます。
    /// 以下は、より安全な構成に置き換えることができる `transmute` の一般的なアプリケーションです。
    ///
    /// 生の bytes(`&[u8]`) を `u32`、`f64` などに変える:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // 代わりに `u32::from_ne_bytes` を使用してください
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // または `u32::from_le_bytes` または `u32::from_be_bytes` を使用してエンディアンネスを指定します
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// ポインタを `usize` に変換する:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // 代わりに `as` キャストを使用してください
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` を `&mut T` に変える:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // 代わりに再借用を使用してください
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` を `&mut U` に変える:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ここで、`as` をまとめて再借用します。`as` `as` の連鎖は推移的ではないことに注意してください。
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` を `&[u8]` に変える:
    ///
    /// ```
    /// // これはこれを行うための良い方法ではありません。
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // `str::as_bytes` を使用できます
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // または、文字列リテラルを制御できる場合は、バイト文字列を使用します
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` を `Vec<Option<&T>>` に変える。
    ///
    /// コンテナの内容の内部タイプを変換するには、コンテナの不変条件に違反しないようにする必要があります。
    /// `Vec` の場合、これは、内部タイプのサイズ *と配置* の両方が一致する必要があることを意味します。
    /// 他のコンテナーは、タイプ、配置、または `TypeId` のサイズに依存する場合があります。その場合、コンテナーの不変条件に違反しない限り、変換はまったく不可能です。
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // 後で再利用するため、vector のクローンを作成します
    /// let v_clone = v_orig.clone();
    ///
    /// // トランスミュートの使用: これは `Vec` の不特定のデータレイアウトに依存します。これは悪い考えであり、未定義の動作を引き起こす可能性があります。
    /////
    /// // ただし、コピーはありません。
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // これは、提案された安全な方法です。
    /// // ただし、vector 全体を新しい配列にコピーします。
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // これは、データレイアウトに依存せずに、"transmuting" と `Vec` の適切なコピーなしの安全でない方法です。
    /// // 文字通り `transmute` を呼び出す代わりに、ポインターキャストを実行しますが、元の内部タイプ (`&i32`) を新しいタイプ (`Option<&i32>`) に変換するという点では、これにはすべて同じ注意点があります。
    /////
    /// // 上記の情報に加えて、[`from_raw_parts`] のドキュメントも参照してください。
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXMEvec_into_raw_parts が安定したときにこれを更新します。
    ///     // 元の vector がドロップされていないことを確認してください。
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` の実装:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // これを行うには複数の方法があり、次の (transmute) の方法には複数の問題があります。
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // まず、トランスミュートはタイプセーフではありません。チェックするのは T と
    ///         // U は同じサイズです。
    ///         // 次に、ここには、同じメモリを指す 2 つの可変参照があります。
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // これにより、型安全性の問題が解消されます。`&mut *` は、`&mut T` または `* mut T` から `&mut T` を *のみ* 提供します。
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ただし、同じメモリを指す 2 つの可変参照がまだあります。
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // これは、標準ライブラリがそれを行う方法です。
    /// // このようなことをする必要がある場合は、これが最良の方法です
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // これには、同じメモリを指す 3 つの可変参照があります。`slice`、右辺値 ret.0、および右辺値 ret.1。
    ///         // `slice` `let ptr = ...` 以降は使用されないため、"dead" として扱うことができます。したがって、実際の可変スライスは 2 つしかありません。
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: これにより固有の const が安定しますが、constfn にいくつかのカスタムコードがあります
    // `const fn` 内での使用を防ぐチェック。
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` として指定された実際のタイプにドロップグルーが必要な場合は、`true` を返します。`T` に提供された実際のタイプが `Copy` を実装している場合、`false` を返します。
    ///
    ///
    /// 実際の型がドロップグルーを必要とせず、`Copy` を実装していない場合、この関数の戻り値は指定されていません。
    ///
    /// この組み込みの安定化バージョンは [`mem::needs_drop`](crate::mem::needs_drop) です。
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// ポインタからのオフセットを計算します。
    ///
    /// これは、整数への変換と整数からの変換を回避するための組み込み関数として実装されます。これは、変換によってエイリアシング情報が破棄されるためです。
    ///
    /// # Safety
    ///
    /// 開始ポインタと結果ポインタの両方が、割り当てられたオブジェクトの範囲内か、終了を 1 バイト超えている必要があります。
    /// いずれかのポインタが範囲外であるか、算術オーバーフローが発生した場合、戻り値をさらに使用すると、未定義の動作が発生します。
    ///
    ///
    /// この組み込みの安定化バージョンは [`pointer::offset`] です。
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ポインタからのオフセットを計算し、場合によっては折り返します。
    ///
    /// 変換によって特定の最適化が妨げられるため、これは整数への変換と整数からの変換を回避するための組み込み関数として実装されます。
    ///
    /// # Safety
    ///
    /// `offset` 組み込み関数とは異なり、この組み込み関数は、割り当てられたオブジェクトの終わりを指すように、または 1 バイト先を指すように結果のポインターを制限せず、2 の補数演算でラップします。
    /// 結果の値は、実際にメモリにアクセスするために使用するのに必ずしも有効ではありません。
    ///
    /// この組み込みの安定化バージョンは [`pointer::wrapping_offset`] です。
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 適切な `llvm.memcpy.p0i8.0i8.*` 組み込みと同等で、サイズは `count`*`size_of::<T>()` で、配置は
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile パラメータは `true` に設定されているため、サイズがゼロに等しくない限り、最適化されません。
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 適切な `llvm.memmove.p0i8.0i8.*` 組み込みと同等で、サイズは `count* size_of::<T>()`、配置は
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile パラメータは `true` に設定されているため、サイズがゼロに等しくない限り、最適化されません。
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 適切な `llvm.memset.p0i8.*` 組み込みと同等で、サイズは `count* size_of::<T>()`、配置は `min_align_of::<T>()` です。
    ///
    ///
    /// volatile パラメータは `true` に設定されているため、サイズがゼロに等しくない限り、最適化されません。
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` ポインタから揮発性ロードを実行します。
    ///
    /// この組み込みの安定化バージョンは [`core::ptr::read_volatile`](crate::ptr::read_volatile) です。
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` ポインターへの揮発性ストアを実行します。
    ///
    /// この組み込みの安定化バージョンは [`core::ptr::write_volatile`](crate::ptr::write_volatile) です。
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` ポインターから揮発性ロードを実行します。ポインターを整列させる必要はありません。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` ポインターへの揮発性ストアを実行します。
    /// ポインタを揃える必要はありません。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` の平方根を返します
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` の平方根を返します
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` を整数乗します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` を整数乗します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` のサインを返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` のサインを返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` のコサインを返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` のコサインを返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` を `f32` の累乗にします。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` を `f64` の累乗にします。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` の指数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` の指数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` の累乗で 2 を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` の累乗で 2 を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` の自然対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` の自然対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` の底 10 の対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` の常用対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` の底 2 の対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` の 2 を底とする対数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` 値に対して `a * b + c` を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` 値に対して `a * b + c` を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` の絶対値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` の絶対値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// 最小 2 つの `f32` 値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// 最小 2 つの `f64` 値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// 最大 2 つの `f32` 値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// 最大 2 つの `f64` 値を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` 値の符号を `y` から `x` にコピーします。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` 値の符号を `y` から `x` にコピーします。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` 以下の最大の整数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` 以下の最大の整数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` 以上の最小の整数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` 以上の最小の整数を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` の整数部分を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` の整数部分を返します。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` に最も近い整数を返します。
    /// 引数が整数でない場合、不正確な浮動小数点例外が発生する可能性があります。
    pub fn rintf32(x: f32) -> f32;
    /// `f64` に最も近い整数を返します。
    /// 引数が整数でない場合、不正確な浮動小数点例外が発生する可能性があります。
    pub fn rintf64(x: f64) -> f64;

    /// `f32` に最も近い整数を返します。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` に最も近い整数を返します。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` に最も近い整数を返します。中間のケースをゼロから丸めます。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` に最も近い整数を返します。中途半端なケースをゼロから丸めます。
    ///
    /// この本質的なものの安定化されたバージョンは
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// 代数的ルールに基づく最適化を可能にするフロート加算。
    /// 入力が有限であると想定する場合があります。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// 代数的ルールに基づく最適化を可能にするフロート減算。
    /// 入力が有限であると想定する場合があります。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// 代数規則に基づく最適化を可能にする浮動小数点乗算。
    /// 入力が有限であると想定する場合があります。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// 代数規則に基づく最適化を可能にする浮動小数点除算。
    /// 入力が有限であると想定する場合があります。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// 代数規則に基づく最適化を可能にする浮動剰余。
    /// 入力が有限であると想定する場合があります。
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM の fptoui/fptosi で変換します。これにより、範囲外の値に対して undef が返される場合があります。
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] および [`f64::to_int_unchecked`] として安定化。
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// 整数型 `T` に設定されているビット数を返します
    ///
    /// この組み込み関数の安定化バージョンは、`count_ones` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// 整数型 `T` の先頭の未設定ビット (zeroes) の数を返します。
    ///
    /// この組み込み関数の安定化バージョンは、`leading_zeros` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// 値が `0` の `x` は、`T` のビット幅を返します。
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` と同様ですが、値 `0` の `x` が与えられると `undef` を返すため、非常に安全ではありません。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// 整数型 `T` の末尾の未設定ビット (zeroes) の数を返します。
    ///
    /// この組み込み関数の安定化バージョンは、`trailing_zeros` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// 値が `0` の `x` は、`T` のビット幅を返します。
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` と同様ですが、値 `0` の `x` が与えられると `undef` を返すため、非常に安全ではありません。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// 整数型 `T` のバイトを反転します。
    ///
    /// この組み込み関数の安定化バージョンは、`swap_bytes` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// 整数型 `T` のビットを反転します。
    ///
    /// この組み込み関数の安定化バージョンは、`reverse_bits` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// チェック整数加算を実行します。
    ///
    /// この組み込み関数の安定化バージョンは、`overflowing_add` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// チェック整数減算を実行します
    ///
    /// この組み込み関数の安定化バージョンは、`overflowing_sub` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// チェック整数乗算を実行します
    ///
    /// この組み込み関数の安定化バージョンは、`overflowing_mul` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 正確な除算を実行し、`x % y != 0` または `y == 0` または `x == T::MIN && y == -1` の未定義の動作をもたらします
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// 未チェックの除算を実行し、`y == 0` または `x == T::MIN && y == -1` で未定義の動作を引き起こします
    ///
    ///
    /// この組み込み関数の安全なラッパーは、`checked_div` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// 未チェックの除算の余りを返します。`y == 0` または `x == T::MIN && y == -1` の場合、未定義の動作になります。
    ///
    ///
    /// この組み込み関数の安全なラッパーは、`checked_rem` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// チェックされていない左シフトを実行し、`y < 0` または `y >= N` の場合に未定義の動作を引き起こします。ここで、N はビット単位の T の幅です。
    ///
    ///
    /// この組み込み関数の安全なラッパーは、`checked_shl` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// チェックされていない右シフトを実行し、`y < 0` または `y >= N` の場合に未定義の動作を引き起こします。ここで、N はビット単位の T の幅です。
    ///
    ///
    /// この組み込み関数の安全なラッパーは、`checked_shr` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// チェックされていない加算の結果を返します。`x + y > T::MAX` または `x + y < T::MIN` の場合は未定義の動作になります。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// チェックされていない減算の結果を返します。`x - y > T::MAX` または `x - y < T::MIN` の場合は未定義の動作になります。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// 未チェックの乗算の結果を返します。`x *y > T::MAX` または `x* y < T::MIN` の場合は未定義の動作になります。
    ///
    ///
    /// この組み込みには、安定した対応物がありません。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// 左回転を行います。
    ///
    /// この組み込み関数の安定化バージョンは、`rotate_left` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// 右回転を実行します。
    ///
    /// この組み込み関数の安定化バージョンは、`rotate_right` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (a + b) mod 2 <sup>N を</sup> 返します。ここで、N はビット単位の T の幅です。
    ///
    /// この組み込み関数の安定化バージョンは、`wrapping_add` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (a、b) mod 2 <sup>N を</sup> 返します。ここで、N はビット単位の T の幅です。
    ///
    /// この組み込み関数の安定化バージョンは、`wrapping_sub` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (a * b) mod 2 <sup>N を</sup> 返します。ここで、N はビット単位の T の幅です。
    ///
    /// この組み込み関数の安定化バージョンは、`wrapping_mul` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` を計算し、数値の境界で飽和します。
    ///
    /// この組み込み関数の安定化バージョンは、`saturating_add` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` を計算し、数値の境界で飽和します。
    ///
    /// この組み込み関数の安定化バージョンは、`saturating_sub` メソッドを介して整数プリミティブで使用できます。
    /// 例えば、
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' のバリアントの判別式の値を返します。
    /// `T` に判別式がない場合は、`0` を返します。
    ///
    /// この組み込みの安定化バージョンは [`core::mem::discriminant`](crate::mem::discriminant) です。
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `usize` にキャストされたタイプ `T` のバリアントの数を返します。
    /// `T` にバリアントがない場合、`0` を返します。無人の亜種がカウントされます。
    ///
    /// この組み込みの安定化予定バージョンは [`mem::variant_count`] です。
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// データポインタ `data` を使用して関数ポインタ `try_fn` を呼び出す Rust の "try catch" 構造。
    ///
    /// 3 番目の引数は、panic が発生した場合に呼び出される関数です。
    /// この関数は、データポインターと、キャッチされたターゲット固有の例外オブジェクトへのポインターを受け取ります。
    ///
    /// 詳細については、コンパイラのソースと std の catch 実装を参照してください。
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM に従って `!nontemporal` ストアを発行します (ドキュメントを参照してください)。
    /// おそらく安定することはないでしょう。
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// 詳細については、`<*const T>::offset_from` のドキュメントを参照してください。
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// 詳細については、`<*const T>::guaranteed_eq` のドキュメントを参照してください。
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// 詳細については、`<*const T>::guaranteed_ne` のドキュメントを参照してください。
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// コンパイル時に割り当てます。実行時に呼び出さないでください。
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// 一部の関数は、このモジュールで誤って安定版で使用可能になったため、ここで定義されています。
// <https://github.com/rust-lang/rust/issues/15702> を参照してください。
// (`transmute` もこのカテゴリに分類されますが、`T` と `U` のサイズが同じであることが確認されているため、ラップできません。)
//

/// `ptr` が `align_of::<T>()` に対して適切に位置合わせされているかどうかを確認します。
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count * size_of::<T>()` バイトを `src` から `dst` にコピーします。ソースと宛先は重複してはなりません。
///
/// オーバーラップする可能性のあるメモリ領域については、代わりに [`copy`] を使用してください。
///
/// `copy_nonoverlapping` 意味的には C の [`memcpy`] と同等ですが、引数の順序が入れ替わっています。
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// 次の条件のいずれかに違反した場合の動作は定義されていません。
///
/// * `src` `count * size_of::<T>()` バイトの読み取りには [valid] である必要があります。
///
/// * `dst` `count * size_of::<T>()` バイトの書き込みには [valid] である必要があります。
///
/// * `src` と `dst` の両方を適切に位置合わせする必要があります。
///
/// * サイズが `count の `src` で始まるメモリの領域 *
///   のサイズ: : <T> () ` バイトは、同じサイズの `dst` で始まるメモリ領域と重複してはなりません。
///
/// [`read`] と同様に、`copy_nonoverlapping` は、`T` が [`Copy`] であるかどうかに関係なく、`T` のビット単位のコピーを作成します。
/// `T` が [`Copy`] でない場合、`*src` で始まる領域と `* dst` で始まる領域の *両方* の値を使用すると、[violate memory safety][read-ownership] になります。
///
///
/// 効果的にコピーされたサイズ ( `count * size_of: :<T> () `) は `0` であり、ポインタは NULL 以外であり、適切に配置されている必要があります。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] を手動で実装します。
///
/// ```
/// use std::ptr;
///
/// /// `src` のすべての要素を `dst` に移動し、`src` を空のままにします。
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` にすべての `src` を保持するのに十分な容量があることを確認してください。
///     dst.reserve(src_len);
///
///     unsafe {
///         // `Vec` は `isize::MAX` バイトを超えて割り当てることはないため、offset の呼び出しは常に安全です。
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // 内容を削除せずに `src` を切り捨てます。
///         // panics のさらに下に何かが発生した場合の問題を回避するために、最初にこれを行います。
///         src.set_len(0);
///
///         // 可変参照はエイリアスを作成しないため、2 つの領域をオーバーラップさせることはできず、2 つの異なる vectors が同じメモリを所有することはできません。
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `src` の内容が保持されていることを `dst` に通知します。
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: これらのチェックは実行時にのみ実行してください
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // codegen の影響を小さく保つために慌てる必要はありません。
        abort();
    }*/

    // 安全性: `copy_nonoverlapping` の安全契約は
    // 発信者によって支持されました。
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` バイトを `src` から `dst` にコピーします。ソースと宛先が重複している可能性があります。
///
/// ソースと宛先が重複しない場合は、代わりに [`copy_nonoverlapping`] を使用できます。
///
/// `copy` 意味的には C の [`memmove`] と同等ですが、引数の順序が入れ替わっています。
/// コピーは、バイトが `src` から一時配列にコピーされてから、配列から `dst` にコピーされたかのように行われます。
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// 次の条件のいずれかに違反した場合の動作は定義されていません。
///
/// * `src` `count * size_of::<T>()` バイトの読み取りには [valid] である必要があります。
///
/// * `dst` `count * size_of::<T>()` バイトの書き込みには [valid] である必要があります。
///
/// * `src` と `dst` の両方を適切に位置合わせする必要があります。
///
/// [`read`] と同様に、`copy` は、`T` が [`Copy`] であるかどうかに関係なく、`T` のビット単位のコピーを作成します。
/// `T` が [`Copy`] でない場合、`*src` で始まる領域と `* dst` で始まる領域の両方の値を使用すると、[violate memory safety][read-ownership] を実行できます。
///
///
/// 効果的にコピーされたサイズ ( `count * size_of: :<T> () `) は `0` であり、ポインタは NULL 以外であり、適切に配置されている必要があります。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 安全でないバッファから Rust vector を効率的に作成します。
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` タイプがゼロ以外の場合は正しく配置する必要があります。
/// /// * `ptr` タイプ `T` の `elts` 連続要素の読み取りに有効である必要があります。
/// /// * `T: Copy` でない限り、この関数を呼び出した後は、これらの要素を使用しないでください。
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // 安全性: 私たちの前提条件は、ソースが整列され、有効であることを保証します、
///     // `Vec::with_capacity` は、それらを書き込むための使用可能なスペースがあることを保証します。
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // 安全性: 以前はこれだけの容量で作成しましたが、
///     // 以前の `copy` はこれらの要素を初期化しました。
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: これらのチェックは実行時にのみ実行してください
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // codegen の影響を小さく保つために慌てる必要はありません。
        abort();
    }*/

    // 安全性: `copy` の安全契約は、発信者が守る必要があります。
    unsafe { copy(src, dst, count) }
}

/// `dst` から始まる `count * size_of::<T>()` バイトのメモリを `val` に設定します。
///
/// `write_bytes` C の [`memset`] に似ていますが、`count * size_of::<T>()` バイトを `val` に設定します。
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// 次の条件のいずれかに違反した場合の動作は定義されていません。
///
/// * `dst` `count * size_of::<T>()` バイトの書き込みには [valid] である必要があります。
///
/// * `dst` 適切に位置合わせする必要があります。
///
/// さらに、呼び出し元は、メモリの指定された領域に `count * size_of::<T>()` バイトを書き込むと、`T` の有効な値になることを確認する必要があります。
/// `T` の無効な値を含む `T` として入力されたメモリ領域を使用することは、未定義の動作です。
///
/// 効果的にコピーされたサイズ ( `count * size_of: :<T> () `) は `0` であり、ポインタは NULL 以外であり、適切に配置されている必要があります。
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// 無効な値の作成:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` を null ポインターで上書きすることにより、以前に保持されていた値をリークします。
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // この時点で、`v` を使用または削除すると、未定義の動作が発生します。
/// // drop(v); // ERROR
///
/// // `v` "uses" をリークすることさえあり、したがって未定義の動作です。
/// // mem::forget(v); // ERROR
///
/// // 実際、`v` は基本的な型レイアウトの不変条件によれば無効であるため、`v` に触れる *すべての* 操作は未定義の動作です。
/////
/// // v2 =v とします。// エラー
///
/// unsafe {
///     // 代わりに有効な値を入力しましょう
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // 今、箱は大丈夫です
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // 安全性: `write_bytes` の安全契約は、発信者が守る必要があります。
    unsafe { write_bytes(dst, val, count) }
}