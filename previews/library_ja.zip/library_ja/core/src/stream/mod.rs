//! 構成可能な非同期反復。
//!
//! futures が非同期値の場合、ストリームは非同期イテレーターです。
//! ある種の非同期コレクションを使用していて、そのコレクションの要素に対して操作を実行する必要がある場合は、すぐに 'streams' に遭遇します。
//! ストリームは慣用的な非同期 Rust コードで頻繁に使用されるため、それらに精通する価値があります。
//!
//! 詳細を説明する前に、このモジュールがどのように構成されているかについて説明しましょう。
//!
//! # Organization
//!
//! このモジュールは、主にタイプ別に構成されています。
//!
//! * [Traits] これらの traits は、存在するストリームの種類と、それらを使用して何ができるかを定義します。これらの traits のメソッドは、追加の学習時間を費やす価値があります。
//! * 関数は、いくつかの基本的なストリームを作成するためのいくつかの便利な方法を提供します。
//! * 構造体は、多くの場合、このモジュールの traits のさまざまなメソッドの戻り型です。通常、`struct` 自体ではなく、`struct` を作成するメソッドを確認する必要があります。
//! 理由の詳細については、「[Implementing Stream] (#implementing-stream)」を参照してください。
//!
//! [Traits]: #traits
//!
//! それでおしまい! ストリームを掘り下げてみましょう。
//!
//! # Stream
//!
//! このモジュールの核心は [`Stream`] trait です。[`Stream`] のコアは次のようになります。
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! `Iterator` とは異なり、`Stream` は、`Stream` を実装するときに使用される [`poll_next`] メソッドと、ストリームを消費するときに使用される (to-be-implemented) `next` メソッドを区別します。
//!
//! `Stream` のコンシューマーは、`next` を考慮するだけで済みます。これは、呼び出されると、`Option<Stream::Item>` を生成する future を返します。
//!
//! `next` によって返される future は、要素がある限り `Some(Item)` を生成し、要素がすべて使い果たされると、反復が終了したことを示す `None` を生成します。
//! 非同期で解決するのを待っている場合、future は、ストリームが再び生成される準備ができるまで待機します。
//!
//! 個々のストリームは反復を再開することを選択する可能性があるため、`next` を再度呼び出すと、ある時点で `Some(Item)` が再び生成される場合と生成されない場合があります。
//!
//! [`Stream`] の完全な定義には他の多くのメソッドも含まれていますが、これらはデフォルトのメソッドであり、[`poll_next`] の上に構築されているため、無料で入手できます。
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # ストリームの実装
//!
//! 独自のストリームを作成するには、ストリームの状態を保持する `struct` を作成することと、その `struct` に [`Stream`] を実装することの 2 つのステップが含まれます。
//!
//! `1` から `5` までカウントする `Counter` という名前のストリームを作成しましょう。
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // まず、構造体:
//!
//! /// 1 から 5 までカウントするストリーム
//! struct Counter {
//!     count: usize,
//! }
//!
//! // カウントを 1 から開始したいので、new() メソッドを追加してみましょう。
//! // これは必ずしも必要ではありませんが、便利です。
//! // `count` をゼロから開始することに注意してください。その理由は、以下の `poll_next()`'s 実装でわかります。
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // 次に、`Counter` に `Stream` を実装します。
//!
//! impl Stream for Counter {
//!     // usize でカウントします
//!     type Item = usize;
//!
//!     // poll_next() 必要な唯一の方法です
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // カウントを増やします。これが、ゼロから始めた理由です。
//!         self.count += 1;
//!
//!         // カウントが終了したかどうかを確認してください。
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! ストリームは *怠惰* です。これは、ストリームを作成するだけでは _do_ がそれほど多くないことを意味します。`next` を呼び出すまで、実際には何も起こりません。
//! これは、副作用のためだけにストリームを作成するときに混乱の原因となることがあります。
//! コンパイラは、この種の動作について警告します。
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;