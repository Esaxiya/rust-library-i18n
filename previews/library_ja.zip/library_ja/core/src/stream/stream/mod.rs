use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 非同期イテレータを処理するためのインターフェイス。
///
/// これはメインストリーム trait です。
/// 一般的なストリームの概念の詳細については、[module-level documentation] を参照してください。
/// 特に、[implement `Stream`][impl] の方法を知りたい場合があります。
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// ストリームによって生成されたアイテムのタイプ。
    type Item;

    /// このストリームの次の値を引き出し、値がまだ利用できない場合はウェイクアップ用に現在のタスクを登録し、ストリームが使い果たされた場合は `None` を返します。
    ///
    /// # 戻り値
    ///
    /// いくつかの可能な戻り値があり、それぞれが異なるストリーム状態を示します。
    ///
    /// - `Poll::Pending` このストリームの次の値はまだ準備ができていないことを意味します。実装により、次の値の準備ができたときに現在のタスクに通知されるようになります。
    ///
    /// - `Poll::Ready(Some(val))` ストリームが値 `val` を正常に生成し、後続の `poll_next` 呼び出しでさらに値を生成する可能性があることを意味します。
    ///
    /// - `Poll::Ready(None)` ストリームが終了し、`poll_next` を再度呼び出さないことを意味します。
    ///
    /// # Panics
    ///
    /// ストリームが終了すると (`Ready(None)` from `poll_next`) が返され、その `poll_next` メソッドを再度呼び出すと、panic、永久にブロック、またはその他の種類の問題が発生する可能性があります。`Stream` trait は、そのような呼び出しの効果に要件を課しません。
    ///
    /// ただし、`poll_next` メソッドには `unsafe` のマークが付いていないため、Rust の通常のルールが適用されます。ストリームの状態に関係なく、呼び出しによって未定義の動作 (メモリの破損、`unsafe` 関数の誤った使用など) が発生することはありません。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// ストリームの残りの長さの境界を返します。
    ///
    /// 具体的には、`size_hint()` は、最初の要素が下限で、2 番目の要素が上限であるタプルを返します。
    ///
    /// 返されるタプルの後半は [`Option`]`<`[`usize`] `>` です。
    /// ここでの [`None`] は、既知の上限がないか、上限が [`usize`] より大きいことを意味します。
    ///
    /// # 実装上の注意
    ///
    /// ストリームの実装が宣言された数の要素を生成することは強制されません。バギーストリームは、要素の下限よりも小さいか、または上限よりも多くなる可能性があります。
    ///
    /// `size_hint()` 主に、ストリームの要素用のスペースの予約などの最適化に使用することを目的としていますが、安全でないコードで境界チェックを省略するなど、信頼してはなりません。
    /// `size_hint()` の誤った実装は、メモリ安全違反につながるべきではありません。
    ///
    /// とは言うものの、実装は正しい推定を提供する必要があります。そうしないと、trait のプロトコルに違反することになります。
    ///
    /// デフォルトの実装は ` (0、` [`None`]`) ` を返しますが、これはどのストリームにも当てはまります。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}