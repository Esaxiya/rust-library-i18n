#![stable(feature = "futures_api", since = "1.36.0")]

//! 非同期値。

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// このタイプが必要な理由は次のとおりです。
///
/// a) ジェネレーターは `for<'a, 'b> Generator<&'a mut Context<'b>>` を実装できないため、生のポインターを渡す必要があります (<https://github.com/rust-lang/rust/issues/68923> を参照)。
///
/// b) 生のポインターと `NonNull` は `Send` でも `Sync` でもないので、すべての future non-Send/Sync も作成されますが、これは望ましくありません。
///
/// また、`.await` の HIR 低下を簡素化します。
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ジェネレーターを future でラップします。
///
/// この関数は下に `GenFuture` を返しますが、`impl Trait` で非表示にして、より適切なエラーメッセージ (`GenFuture<[closure.....]>` ではなく `impl Future`) を提供します。
///
// これは、`const async fn` から回復した後の余分なエラーを回避するための `const` です。
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // 基盤となるジェネレーターで自己参照の借用を作成するために、async/await futures は不動であるという事実に依存しています。
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // 安全性: 私たちは !Unpin + !Drop であるため安全であり、これは単なるフィールドプロジェクションです。
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context` を `NonNull` raw ポインターに変えて、ジェネレーターを再開します。
            // `.await` の下降は、それを `&mut Context` に安全にキャストバックします。
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // 安全性: 発信者は、`cx.0` が有効なポインターであることを保証する必要があります
    // これは、可変参照のすべての要件を満たします。
    unsafe { &mut *cx.0.as_ptr().cast() }
}