#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future は、非同期計算を表します。
///
/// future は、まだ計算が終了していない可能性のある値です。
/// この種の "asynchronous value" を使用すると、スレッドは、値が使用可能になるのを待つ間、有用な作業を続行できます。
///
///
/// # `poll` メソッド
///
/// future のコアメソッドである `poll` は、future を最終値に解決しようと *試みます*。
/// 値の準備ができていない場合、このメソッドはブロックしません。
/// 代わりに、現在のタスクは、再度「ポーリング」することでさらに進行できるときにウェイクアップされるようにスケジュールされています。
/// `poll` メソッドに渡された `context` は、現在のタスクをウェイクアップするためのハンドルである [`Waker`] を提供できます。
///
/// future を使用する場合、通常は `poll` を直接呼び出すのではなく、`.await` の値を呼び出します。
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// 完了時に生成される値のタイプ。
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future を最終値に解決しようとします。値がまだ使用できない場合は、現在のタスクをウェイクアップ用に登録します。
    ///
    /// # 戻り値
    ///
    /// この関数は以下を返します。
    ///
    /// - [`Poll::Pending`] future の準備がまだできていない場合
    /// - [`Poll::Ready(val)`] 正常に終了した場合、この future の結果は `val` になります。
    ///
    /// future が終了したら、クライアントはそれを再度 `poll` しないでください。
    ///
    /// future の準備がまだできていない場合、`poll` は `Poll::Pending` を返し、現在の [`Context`] からコピーされた [`Waker`] のクローンを格納します。
    /// この [`Waker`] は、future が進行できるようになると、ウェイクアップされます。
    /// たとえば、ソケットが読み取り可能になるのを待機している future は、[`Waker`] で `.clone()` を呼び出し、それを格納します。
    /// ソケットが読み取り可能であることを示す信号が他の場所に到着すると、[`Waker::wake`] が呼び出され、ソケット future のタスクが起動されます。
    /// タスクがウェイクアップされると、future の `poll` を再度試行する必要があります。これにより、最終的な値が生成される場合とされない場合があります。
    ///
    /// `poll` への複数の呼び出しでは、ウェイクアップを受信するようにスケジュールする必要があるのは、最新の呼び出しに渡された [`Context`] からの [`Waker`] のみであることに注意してください。
    ///
    /// # ランタイム特性
    ///
    /// Futures だけが *不活性* です。進行するには、*積極的に*「ポーリング」する必要があります。つまり、現在のタスクがウェイクアップされるたびに、まだ関心がある futures が保留されている間は積極的に「ポーリング」する必要があります。
    ///
    /// `poll` 関数は、タイトループで繰り返し呼び出されることはありません。代わりに、future が進行の準備ができていることを示した場合にのみ呼び出す必要があります (`wake()`) を呼び出すことによって)。
    /// Unix での `poll(2)` または `select(2)` システムコールに精通している場合、futures は通常 "all wakeups must poll all events" と同じ問題を *受けない* ことに注意してください。`epoll(4)` に似ています。
    ///
    /// `poll` の実装は、迅速に戻るように努める必要があり、ブロックするべきではありません。すばやく戻ると、スレッドやイベントループが不必要に詰まるのを防ぐことができます。
    /// `poll` の呼び出しに時間がかかることが事前にわかっている場合は、`poll` が迅速に戻ることができるように、作業をスレッドプール (または同様のもの) にオフロードする必要があります。
    ///
    /// # Panics
    ///
    /// future が完了すると (`poll` から `Ready` が返される)、その `poll` メソッドを再度呼び出すと、panic が停止したり、永久にブロックされたり、その他の種類の問題が発生したりする可能性があります。`Future` trait は、そのような呼び出しの効果に要件を課しません。
    /// ただし、`poll` メソッドには `unsafe` のマークが付いていないため、Rust の通常のルールが適用されます。future の状態に関係なく、呼び出しによって未定義の動作 (メモリの破損、`unsafe` 関数の誤った使用など) が発生することはありません。
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}