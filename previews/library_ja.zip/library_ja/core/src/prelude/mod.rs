//! libcore prelude
//!
//! このモジュールは、libstd にもリンクしていない libcore のユーザーを対象としています。
//! このモジュールは、`#![no_std]` が標準ライブラリの prelude と同じ方法で使用される場合、デフォルトでインポートされます。
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// コア prelude の 2015 バージョン。
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// コア prelude の 2018 バージョン。
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// コア prelude の 2021 バージョン。
///
/// 詳細については、[module-level documentation](self) を参照してください。
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: さらに追加します。
}