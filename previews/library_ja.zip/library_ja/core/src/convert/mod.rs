//! タイプ間の変換用の Traits。
//!
//! このモジュールの traits は、あるタイプから別のタイプに変換する方法を提供します。
//! 各 trait は、異なる目的を果たします。
//!
//! - 安価なリファレンスからリファレンスへの変換のために [`AsRef`] trait を実装する
//! - 安価な可変から可変への変換のために [`AsMut`] trait を実装します
//! - 値から値への変換を消費するために [`From`] trait を実装します
//! - [`Into`] trait を実装して、現在の crate 外の型への値から値への変換を使用します
//! - [`TryFrom`] および [`TryInto`] traits は [`From`] および [`Into`] と同様に動作しますが、変換が失敗する可能性がある場合に実装する必要があります。
//!
//! このモジュールの traits は、複数の型の引数がサポートされるように、ジェネリック関数の trait bounds としてよく使用されます。例については、各 trait のドキュメントを参照してください。
//!
//! [`From`] と [`TryFrom`] は柔軟性が高く、同等の [`Into`] または [`TryInto`] 実装を無料で提供するため、ライブラリの作成者は常に [`Into<U>`][`Into`] または [`TryInto<U>`][`TryInto`] ではなく [`From<T>`][`From`] または [`TryFrom<T>`][`TryFrom`] を実装することをお勧めします。これは、標準ライブラリの包括的な実装のおかげです。
//! Rust 1.41 より前のバージョンを対象とする場合、現在の crate 以外のタイプに変換するときに、[`Into`] または [`TryInto`] を直接実装する必要がある場合があります。
//!
//! # 一般的な実装
//!
//! - [`AsRef`] 内部タイプが参照の場合、[`AsMut`] 自動逆参照
//! - [`<U>From`]`for T` は、[`Into`]`を意味します</u><T><U>U` のために</u>
//! - [`TryFrom`]`<U>for</u> T` は、[`TryInto`]`<U> を意味します</u><T><U>U` のために</u>
//! - [`From`] および [`Into`] は反射的です。つまり、すべてのタイプが `into` 自体および `from` 自体に対応できます。
//!
//! 使用例については、各 trait を参照してください。
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// 恒等関数。
///
/// この関数について注意することが重要な 2 つのこと:
///
/// - クロージャは `x` を別のタイプに強制変換する可能性があるため、`|x| x` のようなクロージャと常に同等であるとは限りません。
///
/// - 関数に渡された入力 `x` を移動します。
///
/// 入力を返すだけの関数があるのは奇妙に思えるかもしれませんが、いくつかの興味深い使用法があります。
///
///
/// # Examples
///
/// `identity` を使用して、他の興味深い一連の機能で何もしない:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // 1 つ追加するのが面白い関数だとしましょう。
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// 条件付きの "do nothing" ベースケースとして `identity` を使用する:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // もっと面白いことをしてください...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` を使用して、`Option<T>` のイテレータの `Some` バリアントを保持します。
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// 安価な参照から参照への変換を行うために使用されます。
///
/// この trait は、可変参照間の変換に使用される [`AsMut`] に似ています。
/// コストのかかる変換を行う必要がある場合は、タイプ `&T` で [`From`] を実装するか、カスタム関数を作成することをお勧めします。
///
/// `AsRef` [`Borrow`] と同じ署名がありますが、[`Borrow`] はいくつかの点で異なります。
///
/// - `AsRef` とは異なり、[`Borrow`] には任意の `T` 用の包括的実装があり、参照または値のいずれかを受け入れるために使用できます。
/// - [`Borrow`] また、借用価値の [`Hash`]、[`Eq`]、および [`Ord`] は、所有価値のものと同等である必要があります。
/// このため、構造体の 1 つのフィールドのみを借用する場合は、`AsRef` を実装できますが、[`Borrow`] は実装できません。
///
/// **Note: この trait は失敗してはなりません **。変換が失敗する可能性がある場合は、[`Option<T>`] または [`Result<T, E>`] を返す専用のメソッドを使用してください。
///
/// # 一般的な実装
///
/// - `AsRef` 内部タイプが参照または可変参照の場合、自動逆参照 (例: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds を使用することにより、指定されたタイプ `T` に変換できる限り、さまざまなタイプの引数を受け入れることができます。
///
/// 例: `AsRef<str>` を受け取るジェネリック関数を作成することにより、[`&str`] に変換できるすべての参照を引数として受け入れたいことを表現します。
/// [`String`] と [`&str`] の両方が `AsRef<str>` を実装しているため、両方を入力引数として受け入れることができます。
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// 変換を実行します。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// 安価な可変から可変の参照変換を行うために使用されます。
///
/// この trait は [`AsRef`] に似ていますが、可変参照間の変換に使用されます。
/// コストのかかる変換を行う必要がある場合は、タイプ `&mut T` で [`From`] を実装するか、カスタム関数を作成することをお勧めします。
///
/// **Note: この trait は失敗してはなりません **。変換が失敗する可能性がある場合は、[`Option<T>`] または [`Result<T, E>`] を返す専用のメソッドを使用してください。
///
/// # 一般的な実装
///
/// - `AsMut` 内部タイプが可変参照である場合、自動逆参照 (例: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ジェネリック関数の trait bound として `AsMut` を使用すると、タイプ `&mut T` に変換できるすべての可変参照を受け入れることができます。
/// [`Box<T>`] は `AsMut<T>` を実装しているため、`&mut u64` に変換できるすべての引数を受け取る関数 `add_one` を記述できます。
/// [`Box<T>`] は `AsMut<T>` を実装しているため、`add_one` はタイプ `&mut Box<u64>` の引数も受け入れます。
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// 変換を実行します。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// 入力値を消費する値から値への変換。[`From`] の反対です。
///
/// [`Into`] の実装を避け、代わりに [`From`] を実装する必要があります。
/// [`From`] を実装すると、標準ライブラリの包括的な実装のおかげで、[`Into`] の実装が自動的に提供されます。
///
/// ジェネリック関数で trait bounds を指定する場合は、[`From`] よりも [`Into`] を使用して、[`Into`] のみを実装する型も使用できるようにすることをお勧めします。
///
/// **Note: この trait は失敗してはなりません **。変換が失敗する可能性がある場合は、[`TryInto`] を使用してください。
///
/// # 一般的な実装
///
/// - [`From`]`<T>U` は `Into<U> for T` を意味します
/// - [`Into`] 反射的です。つまり、`Into<T> for T` が実装されています。
///
/// # 古いバージョンの Rust で外部タイプに変換するための [`Into`] の実装
///
/// Rust 1.41 より前は、宛先タイプが現在の crate の一部ではなかった場合、[`From`] を直接実装することはできませんでした。
/// たとえば、次のコードを考えてみましょう。
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Rust の孤立したルールは以前はもう少し厳格だったため、これは古いバージョンの言語ではコンパイルに失敗します。
/// これを回避するには、[`Into`] を直接実装します。
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`] は [`From`] 実装を提供しないことを理解することが重要です ([`From`] は [`Into`] で提供します)。
/// したがって、常に [`From`] の実装を試みてから、[`From`] を実装できない場合は [`Into`] にフォールバックする必要があります。
///
/// # Examples
///
/// [`String`] [`Into`]`<`[`Vec`] `<` [`u8`]`>>` を実装します:
///
/// 指定されたタイプ `T` に変換できるすべての引数を汎用関数が受け取ることを表現するために、[`Into`]`の trait bound を使用できます。<T>`。
///
/// 例: 関数 `is_hello` は、[`Vec`]`<`[`u8`] `>` に変換できるすべての引数を取ります。
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// 変換を実行します。
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// 入力値を消費しながら値から値への変換を行うために使用されます。[`Into`] の逆数です。
///
/// `From` を実装すると、標準ライブラリの包括的な実装のおかげで [`Into`] の実装が自動的に提供されるため、[`Into`] よりも `From` の実装を常に優先する必要があります。
///
///
/// [`Into`] を実装するのは、Rust 1.41 より前のバージョンをターゲットにして、現在の crate 以外のタイプに変換する場合のみです。
/// `From` Rust の孤立したルールのため、以前のバージョンではこれらのタイプの変換を実行できませんでした。
/// 詳細については、[`Into`] を参照してください。
///
/// 汎用関数で trait bounds を指定する場合は、`From` を使用するよりも [`Into`] を使用することをお勧めします。
/// このように、[`Into`] を直接実装する型も引数として使用できます。
///
/// `From` は、エラー処理を実行するときにも非常に役立ちます。失敗する可能性のある関数を作成する場合、戻り値の型は通常 `Result<T, E>` の形式になります。
/// `From` trait は、関数が複数のエラータイプをカプセル化する単一のエラータイプを返すことを可能にすることにより、エラー処理を簡素化します。詳細については、"Examples" セクションおよび [the book][book] を参照してください。
///
/// **Note: この trait は失敗してはなりません **。変換が失敗する可能性がある場合は、[`TryFrom`] を使用してください。
///
/// # 一般的な実装
///
/// - `From<T> for U` T`の [`Into`]`<U>を</u> 意味します
/// - `From` 反射的です。つまり、`From<T> for T` が実装されています。
///
/// # Examples
///
/// [`String`] `From<&str>` を実装します。
///
/// `&str` から文字列への明示的な変換は次のように行われます。
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// エラー処理を実行している間、独自のエラータイプに `From` を実装すると便利なことがよくあります。
/// 根本的なエラータイプを、根本的なエラータイプをカプセル化する独自のカスタムエラータイプに変換することにより、根本的な原因に関する情報を失うことなく、単一のエラータイプを返すことができます。
/// '?' オペレーターは、`From` の実装時に自動的に提供される `Into<CliError>::into` を呼び出すことにより、基になるエラータイプをカスタムエラータイプに自動的に変換します。
/// 次に、コンパイラは `Into` のどの実装を使用するかを推測します。
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// 変換を実行します。
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` を消費する変換の試行。これは、費用がかかる場合とそうでない場合があります。
///
/// ライブラリの作成者は通常、この trait を直接実装するべきではありませんが、標準ライブラリの包括的な実装のおかげで、柔軟性が高く、同等の `TryInto` 実装を無料で提供する [`TryFrom`] trait を実装することをお勧めします。
/// 詳細については、[`Into`] のドキュメントを参照してください。
///
/// # `TryInto` の実装
///
/// これには、[`Into`] の実装と同じ制限と理由があります。詳細については、こちらを参照してください。
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// 変換エラーが発生した場合に返される型。
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 変換を実行します。
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// 状況によっては制御された方法で失敗する可能性のある、単純で安全な型変換。[`TryInto`] の逆数です。
///
/// これは、簡単に成功する可能性があるが、特別な処理が必要になる可能性がある型変換を行う場合に役立ちます。
/// たとえば、[`From`] trait を使用して [`i64`] を [`i32`] に変換する方法はありません。これは、[`i64`] に [`i32`] が表すことができない値が含まれている可能性があり、変換によってデータが失われるためです。
///
/// これは、[`i64`] を [`i32`] に切り捨てる (基本的に [`i64`] の値を [`i32::MAX`] を法として与える) か、単に [`i32::MAX`] を返すか、または他の方法で処理できます。
/// [`From`] trait は完全な変換を目的としているため、`TryFrom` trait は、型変換がうまくいかない可能性がある場合にプログラマーに通知し、その処理方法を決定できるようにします。
///
/// # 一般的な実装
///
/// - `TryFrom<T> for U` T`の [`TryInto`]`<U>を</u> 意味します
/// - [`try_from`] は再帰的です。つまり、`TryFrom<T> for T` が実装されており、失敗することはありません。タイプ `T` の値で `T::try_from()` を呼び出すための関連する `Error` タイプは [`Infallible`] です。
/// [`!`] タイプが安定すると、[`Infallible`] と [`!`] は同等になります。
///
/// `TryFrom<T>` 次のように実装できます。
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// 説明したように、[`i32`] は `TryFrom <` [`i64`]`>` を実装します。
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number` をサイレントに切り捨て、事後に切り捨てを検出して処理する必要があります。
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` が大きすぎて `i32` に収まらないため、エラーを返します。
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` を返します。
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// 変換エラーが発生した場合に返される型。
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// 変換を実行します。
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ジェネリック IMPLS
////////////////////////////////////////////////////////////////////////////////

// リフトオーバー＆
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut を超えるリフトとして
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742):＆/＆mut の上記の impl を、次のより一般的なものに置き換えます。
// // Deref を持ち上げるとき
// impl <D: ?Sized + Deref<Target: AsRef<U>>、U: ? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut は &mut を超えて上昇します
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut の上記の impl を次のより一般的なものに置き換えます。
// // AsMut が DerefMut を持ち上げます
// impl <D: ?Sized + Deref<Target: AsMut<U>>、U: ? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// From は Into を意味します
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (したがって Into) は反射的です
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **安定性に関する注意:** この impl はまだ存在しませんが、future に追加する "reserving space" です。
/// 詳細については、[rust-lang/rust#64715][#64715] を参照してください。
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): 代わりに原則的な修正を行ってください。
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom は TryInto を意味します
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// 間違いのない変換は、無人のエラータイプの間違いのある変換と意味的に同等です。
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// コンクリート IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// エラーなしのエラータイプ
////////////////////////////////////////////////////////////////////////////////

/// 発生する可能性のないエラーのエラータイプ。
///
/// この列挙型にはバリアントがないため、このタイプの値が実際に存在することはありません。
/// これは、[`Result`] を使用し、エラータイプをパラメータ化して、結果が常に [`Ok`] であることを示す汎用 API に役立ちます。
///
/// たとえば、[`TryFrom`] trait ([`Result`] を返す変換) には、逆 [`Into`] 実装が存在するすべてのタイプの包括的実装があります。
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future の互換性
///
/// この列挙型は、このバージョンの Rust では不安定な [the `!`“never”type][never] と同じ役割を果たします。
/// `!` が安定したら、`Infallible` をタイプエイリアスにする予定です。
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …そして最終的に `Infallible` を非推奨にします。
///
/// ただし、`!` が本格的な型として安定する前に、`!` 構文を使用できる場合が 1 つあります。それは、関数の戻り型の位置です。
/// 具体的には、2 つの異なる関数ポインタタイプの実装が可能です。
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` が列挙型であるため、このコードは有効です。
/// ただし、`Infallible` が never type のエイリアスになると、2 つの `impl` がオーバーラップし始めるため、言語の trait コヒーレンスルールによって許可されなくなります。
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}