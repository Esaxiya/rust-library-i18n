//! 借用したデータを操作するためのモジュール。

#![stable(feature = "rust1", since = "1.0.0")]

/// データを借用するための trait。
///
/// Rust では、さまざまなユースケースにタイプのさまざまな表現を提供するのが一般的です。
/// たとえば、値の保存場所と管理は、[`Box<T>`] や [`Rc<T>`] などのポインタタイプを介して、特定の用途に応じて具体的に選択できます。
/// 任意のタイプで使用できるこれらの汎用ラッパー以外に、一部のタイプは、潜在的にコストのかかる機能を提供するオプションのファセットを提供します。
/// このようなタイプの例は、基本的な [`str`] に文字列を拡張する機能を追加する [`String`] です。
/// これには、単純で不変の文字列に追加情報を不要に保つ必要があります。
///
/// これらのタイプは、そのデータのタイプへの参照を通じて、基になるデータへのアクセスを提供します。それらは「そのタイプとして借用されている」と言われています。
/// たとえば、[`Box<T>`] は `T` として借用でき、[`String`] は `str` として借用できます。
///
/// タイプは、`Borrow<T>` を実装し、trait の [`borrow`] メソッドで `T` への参照を提供することにより、タイプ `T` として借用できることを表します。タイプはいくつかの異なるタイプとして自由に借りることができます。
/// タイプとして可変的に借用したい場合は、基になるデータを変更できるようにするために、[`BorrowMut<T>`] を追加で実装できます。
///
/// さらに、追加の traits の実装を提供する場合、その基礎となるタイプの表現として機能する結果として、それらが基礎となるタイプの実装と同じように動作する必要があるかどうかを考慮する必要があります。
/// 一般的なコードは、これらの追加の trait 実装と同じ動作に依存する場合、通常 `Borrow<T>` を使用します。
/// これらの traits は、追加の trait bounds として表示される可能性があります。
///
/// 特に、`Eq`、`Ord`、および `Hash` は、借用値と所有値で同等である必要があります。`x.borrow() == y.borrow()` は、`x == y` と同じ結果をもたらす必要があります。
///
/// 汎用コードが、関連するタイプ `T` への参照を提供できるすべてのタイプに対して機能する必要があるだけの場合は、より多くのタイプが安全に実装できるため、[`AsRef<T>`] を使用する方がよい場合がよくあります。
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// データ収集として、[`HashMap<K, V>`] はキーと値の両方を所有します。ただし、キーの実際のデータが何らかの管理タイプにラップされている場合でも、キーのデータへの参照を使用して値を検索することは可能です。
/// たとえば、キーが文字列の場合、ハッシュマップとともに [`String`] として保存される可能性がありますが、[`&str`][`str`] を使用して検索できるはずです。
/// したがって、`insert` は `String` で動作する必要があり、`get` は `&str` を使用できる必要があります。
///
/// 少し簡略化すると、`HashMap<K, V>` の関連部分は次のようになります。
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // フィールドを省略
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// ハッシュマップ全体は、キータイプ `K` に対して一般的です。これらのキーはハッシュマップとともに保存されるため、このタイプはキーのデータを所有する必要があります。
/// キーと値のペアを挿入すると、マップにはそのような `K` が与えられ、正しいハッシュバケットを見つけて、その `K` に基づいてキーがすでに存在するかどうかを確認する必要があります。したがって、`K: Hash + Eq` が必要です。
///
/// ただし、マップで値を検索する場合、検索するキーとして `K` への参照を提供する必要があるため、常にそのような所有値を作成する必要があります。
/// 文字列キーの場合、これは、`str` のみが使用可能な場合の検索のためだけに `String` 値を作成する必要があることを意味します。
///
/// 代わりに、`get` メソッドは、上記のメソッドシグネチャで `Q` と呼ばれる、基になるキーデータのタイプに対してジェネリックです。`K` は、`K: Borrow<Q>` を要求することにより、`Q` として借用すると述べています。
/// さらに `Q: Hash + Eq` を要求することにより、`K` と `Q` に同じ結果を生成する `Hash` と `Eq` traits の実装があるという要件を示します。
///
/// `get` の実装は、`K` 値から計算されたハッシュ値に基づいてキーを挿入した場合でも、`Q` 値で `Hash::hash` を呼び出してキーのハッシュバケットを決定することにより、`Hash` の同一の実装に特に依存しています。
///
///
/// 結果として、`Q` 値をラップする `K` が `Q` とは異なるハッシュを生成すると、ハッシュマップが壊れます。たとえば、文字列を折り返すが、大文字と小文字を区別せずに ASCII 文字を比較するタイプがあるとします。
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// 2 つの等しい値が同じハッシュ値を生成する必要があるため、`Hash` の実装も ASCII ケースを無視する必要があります。
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` は `Borrow<str>` を実装できますか? 含まれている所有文字列を介して、文字列スライスへの参照を確実に提供できます。
/// ただし、`Hash` の実装が異なるため、`str` とは動作が異なり、実際には `Borrow<str>` を実装してはなりません。
/// 基盤となる `str` への他のユーザーのアクセスを許可したい場合は、追加の要件を持たない `AsRef<str>` を介してそれを行うことができます。
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// 所有する値から不変に借用します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// データを可変的に借用するための trait。
///
/// [`Borrow<T>`] のコンパニオンとして、この trait は、可変参照を提供することにより、型が基になる型として借用できるようにします。
/// 別のタイプとしての借用の詳細については、[`Borrow<T>`] を参照してください。
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// 所有する価値から可変的に借ります。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}