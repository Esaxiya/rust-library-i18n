//! 原子タイプ
//!
//! アトミックタイプは、スレッド間の基本的な共有メモリ通信を提供し、他の並行タイプの構成要素です。
//!
//! このモジュールは、[`AtomicBool`]、[`AtomicIsize`]、[`AtomicUsize`]、[`AtomicI8`]、[`AtomicU16`] などを含む選択された数のプリミティブタイプのアトミックバージョンを定義します。
//! アトミックタイプは、正しく使用されると、スレッド間で更新を同期する操作を示します。
//!
//! 各メソッドは、その操作のメモリバリアの強度を表す [`Ordering`] を取ります。これらの順序は [C++20 atomic orderings][1] と同じです。詳細については、[nomicon][2] を参照してください。
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! アトミック変数はスレッド間で安全に共有できます ([`Sync`] を実装します) が、それ自体は共有のメカニズムを提供せず、Rust の [threading model](../../../std/thread/index.html#the-threading-model) に従います。
//!
//! アトミック変数を共有する最も一般的な方法は、[`Arc`][arc] (アトミック参照でカウントされる共有ポインター) に配置することです。
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! アトミックタイプは静的変数に格納され、[`AtomicBool::new`] などの定数初期化子を使用して初期化されます。原子静力学は、怠惰なグローバル初期化によく使用されます。
//!
//! # Portability
//!
//! このモジュールのすべてのアトミックタイプは、使用可能な場合は [lock-free] であることが保証されています。これは、グローバルミューテックスを内部的に取得しないことを意味します。アトミックタイプと操作は、待機なしであることが保証されていません。
//! これは、`fetch_or` のような操作がコンペアアンドスワップループで実装される可能性があることを意味します。
//!
//! アトミック操作は、より大きなサイズのアトミックを使用して命令層で実装できます。たとえば、一部のプラットフォームは 4 バイトのアトミック命令を使用して `AtomicI8` を実装します。
//! このエミュレーションはコードの正確さに影響を与えるべきではないことに注意してください。これは注意すべき点です。
//!
//! このモジュールのアトミックタイプは、すべてのプラットフォームで使用できるとは限りません。ただし、ここでのアトミックタイプはすべて広く利用可能であり、通常は既存のものに依存できます。いくつかの注目すべき例外は次のとおりです。
//!
//! * PowerPC 32 ビットポインタを備えた MIPS プラットフォームには、`AtomicU64` または `AtomicI64` タイプがありません。
//! * ARM Linux 用ではない `armv5te` のようなプラットフォームは、`load` および `store` 操作のみを提供し、`swap`、`fetch_add` などの (CAS) の比較および交換操作をサポートしません。
//! さらに、Linux では、これらの CAS 操作は [operating system support] を介して実装されるため、パフォーマンスが低下する可能性があります。
//! * ARM `thumbv6m` を使用するターゲットは、`load` および `store` 操作のみを提供し、`swap`、`fetch_add` などの (CAS) の比較および交換操作をサポートしません。
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! 一部のアトミック操作もサポートしていない future プラットフォームが追加される場合があることに注意してください。最大限に移植可能なコードは、どのアトミックタイプが使用されるかについて注意する必要があります。
//! `AtomicUsize` および `AtomicIsize` は一般的に最もポータブルですが、それでもどこでも利用できるわけではありません。
//! 参考までに、`std` ライブラリにはポインタサイズのアトミックが必要ですが、`core` には必要ありません。
//!
//! 現在、主にアトミックを使用してコードを条件付きでコンパイルするには、`#[cfg(target_arch)]` を使用する必要があります。future で安定する可能性のある不安定な `#[cfg(target_has_atomic)]` もあります。
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! 単純なスピンロック:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // 他のスレッドがロックを解放するのを待ちます
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! ライブスレッドのグローバルカウントを維持します。
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// スレッド間で安全に共有できるブール型。
///
/// このタイプは、[`bool`] と同じメモリ内表現を持っています。
///
/// **注**: このタイプは、`u8` のアトミックロードとストアをサポートするプラットフォームでのみ使用できます。
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` に初期化された `AtomicBool` を作成します。
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send は AtomicBool に暗黙的に実装されています。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// スレッド間で安全に共有できる生のポインタ型。
///
/// このタイプは、`*mut T` と同じメモリ内表現を持っています。
///
/// **注**: このタイプは、アトミックロードとポインターのストアをサポートするプラットフォームでのみ使用できます。
/// そのサイズは、ターゲットポインタのサイズによって異なります。
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// null `AtomicPtr<T>` を作成します。
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// 原子メモリの順序
///
/// メモリの順序は、アトミック操作がメモリを同期する方法を指定します。
/// 最も弱い [`Ordering::Relaxed`] では、操作によって直接触れられたメモリのみが同期されます。
/// 一方、[`Ordering::SeqCst`] 操作のストアとロードのペアは、他のメモリを同期すると同時に、すべてのスレッドにわたってそのような操作の全順序を維持します。
///
///
/// Rust のメモリオーダリングは [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) です。
///
/// 詳細については、[nomicon] を参照してください。
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// 順序の制約はなく、アトミック操作のみです。
    ///
    /// C ++ 20 の [`memory_order_relaxed`] に対応します。
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ストアと組み合わせると、以前のすべての操作は、[`Acquire`] (またはそれ以上) の順序でこの値がロードされる前に順序付けられます。
    ///
    /// 特に、以前のすべての書き込みは、この値の [`Acquire`] (またはそれ以上) のロードを実行するすべてのスレッドに表示されます。
    ///
    /// ロードとストアを組み合わせる操作にこの順序を使用すると、[`Relaxed`] ロード操作につながることに注意してください。
    ///
    /// この順序は、ストアを実行できる操作にのみ適用されます。
    ///
    /// C ++ 20 の [`memory_order_release`] に対応します。
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ロードと組み合わせると、ロードされた値が [`Release`] (またはそれ以上) の順序でストア操作によって書き込まれた場合、後続のすべての操作はそのストアの後に順序付けられます。
    /// 特に、後続のすべてのロードでは、ストアの前に書き込まれたデータが表示されます。
    ///
    /// ロードとストアを組み合わせる操作にこの順序を使用すると、[`Relaxed`] ストア操作につながることに注意してください。
    ///
    /// この順序は、ロードを実行できる操作にのみ適用されます。
    ///
    /// C ++ 20 の [`memory_order_acquire`] に対応します。
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] と [`Release`] の両方の効果が一緒にあります:
    /// ロードの場合、[`Acquire`] の順序を使用します。店舗の場合は、[`Release`] の注文を使用します。
    ///
    /// `compare_and_swap` の場合、操作がストアを実行しなくなる可能性があるため、[`Acquire`] の順序だけであることに注意してください。
    ///
    /// ただし、`AcqRel` は [`Relaxed`] アクセスを実行しません。
    ///
    /// この順序は、ロードとストアの両方を組み合わせた操作にのみ適用されます。
    ///
    /// C ++ 20 の [`memory_order_acq_rel`] に対応します。
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// [`Acquire`]/[`Release`]/[`AcqRel`] (それぞれ、load、store、load-with-store 操作用) のように、すべてのスレッドがすべての順次一貫性のある操作を同じ順序で参照するという追加の保証があります。
    ///
    ///
    /// C ++ 20 の [`memory_order_seq_cst`] に対応します。
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// `false` に初期化された [`AtomicBool`]。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// 新しい `AtomicBool` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// 基になる [`bool`] への可変参照を返します。
    ///
    /// 可変参照は、他のスレッドがアトミックデータに同時にアクセスしないことを保証するため、これは安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // 安全性: 可変参照は一意の所有権を保証します。
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` へのアトミックアクセスを取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // 安全性: 可変参照は一意の所有権を保証し、
        // `bool` と `Self` の両方の配置は 1 です。
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// アトミックを消費し、含まれている値を返します。
    ///
    /// `self` を値で渡すと、他のスレッドが同時にアトミックデータにアクセスしないことが保証されるため、これは安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool から値をロードします。
    ///
    /// `load` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// 可能な値は、[`SeqCst`]、[`Acquire`]、および [`Relaxed`] です。
    ///
    /// # Panics
    ///
    /// `order` が [`Release`] または [`AcqRel`] の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // 安全性: データの競合は、アトミック組み込み関数と生の組み込み関数によって防止されます
        // 渡されたポインタは、参照から取得したため有効です。
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool に値を格納します。
    ///
    /// `store` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// 可能な値は、[`SeqCst`]、[`Release`]、および [`Relaxed`] です。
    ///
    /// # Panics
    ///
    /// `order` が [`Acquire`] または [`AcqRel`] の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // 安全性: データの競合は、アトミック組み込み関数と生の組み込み関数によって防止されます
        // 渡されたポインタは、参照から取得したため有効です。
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// 値を bool に格納し、前の値を返します。
    ///
    /// `swap` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// 現在の値が `current` 値と同じである場合、値を [`bool`] に格納します。
    ///
    /// 戻り値は常に前の値です。`current` と等しい場合、値が更新されました。
    ///
    /// `compare_and_swap` また、この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// [`AcqRel`] を使用している場合でも、操作が失敗する可能性があるため、`Acquire` ロードを実行するだけで、`Release` セマンティクスがないことに注意してください。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になります。
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # `compare_exchange` および `compare_exchange_weak` への移行
    ///
    /// `compare_and_swap` `compare_exchange` と同等であり、メモリ順序のマッピングは次のとおりです。
    ///
    /// オリジナル | 成功 | 失敗
    /// -------- | ------- | -------
    /// リラックス | リラックス | リラックスした取得 | 取得 | リリースの取得 | リリース | リラックスした AcqRel |AcqRel |SeqCst を取得する | SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` コンペア・アンド・スワップがループで使用されている場合、コンパイラーはより良いアセンブリー・コードを生成できるようになります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 現在の値が `current` 値と同じである場合、値を [`bool`] に格納します。
    ///
    /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
    /// 成功すると、この値は `current` に等しくなることが保証されます。
    ///
    /// `compare_exchange` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
    /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
    ///
    /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 現在の値が `current` 値と同じである場合、値を [`bool`] に格納します。
    ///
    /// [`AtomicBool::compare_exchange`] とは異なり、この関数は、比較が成功した場合でも誤って失敗することが許可されているため、一部のプラットフォームではコードがより効率的になる可能性があります。
    ///
    /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
    ///
    /// `compare_exchange_weak` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
    /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
    /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ブール値を持つ論理 "and"。
    ///
    /// 現在の値と引数 `val` に対して論理 "and" 演算を実行し、新しい値を結果に設定します。
    ///
    /// 前の値を返します。
    ///
    /// `fetch_and` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// ブール値を持つ論理 "nand"。
    ///
    /// 現在の値と引数 `val` に対して論理 "nand" 演算を実行し、新しい値を結果に設定します。
    ///
    /// 前の値を返します。
    ///
    /// `fetch_nand` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // 無効な値を持つ bool になる可能性があるため、ここでは atomic_nand を使用できません。
        // これは、アトミック操作が内部で 8 ビット整数を使用して実行され、上位 7 ビットが設定されるために発生します。
        //
        // したがって、代わりに fetch_xor または swap を使用します。
        if val {
            // ! (x＆true) == !x bool を反転する必要があります。
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x＆false) ==true bool を true に設定する必要があります。
            //
            self.swap(true, order)
        }
    }

    /// ブール値を持つ論理 "or"。
    ///
    /// 現在の値と引数 `val` に対して論理 "or" 演算を実行し、新しい値を結果に設定します。
    ///
    /// 前の値を返します。
    ///
    /// `fetch_or` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// ブール値を持つ論理 "xor"。
    ///
    /// 現在の値と引数 `val` に対して論理 "xor" 演算を実行し、新しい値を結果に設定します。
    ///
    /// 前の値を返します。
    ///
    /// `fetch_xor` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// 基になる [`bool`] への可変ポインターを返します。
    ///
    /// 結果の整数に対して非アトミックな読み取りと書き込みを行うと、データの競合が発生する可能性があります。
    /// このメソッドは、関数シグネチャが `&AtomicBool` の代わりに `*mut bool` を使用する可能性がある FFI で主に役立ちます。
    ///
    /// アトミックタイプは内部の可変性で機能するため、このアトミックへの共有参照から `*mut` ポインターを返すことは安全です。
    /// アトミックのすべての変更は、共有参照を介して値を変更し、アトミック操作を使用している限り、安全に変更できます。
    /// 返された raw ポインターを使用するには、`unsafe` ブロックが必要ですが、それでも同じ制限を守る必要があります。それに対する操作はアトミックである必要があります。
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// 値を取得し、オプションの新しい値を返す関数を適用します。関数が `Some(_)` を返した場合は、`Ok(previous_value)` の `Result` を返します。それ以外の場合は、`Err(previous_value)` を返します。
    ///
    /// Note: 関数が `Some(_)` を返す限り、その間に値が他のスレッドから変更された場合、これは関数を複数回呼び出すことができますが、関数は格納された値に 1 回だけ適用されます。
    ///
    ///
    /// `fetch_update` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// 1 つ目は、操作が最終的に成功するときに必要な順序を説明し、2 つ目は、ロードに必要な順序を説明します。
    /// これらは、それぞれ [`AtomicBool::compare_exchange`] の成功と失敗の順序に対応しています。
    ///
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作の一部である [`Relaxed`] になり、[`Release`] を使用すると、最終的に成功したロード [`Relaxed`] になります。
    /// (failed) のロード順序は、[`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、`u8` でのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// 新しい `AtomicPtr` を作成します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// 基になるポインタへの可変参照を返します。
    ///
    /// 可変参照は、他のスレッドがアトミックデータに同時にアクセスしないことを保証するため、これは安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ポインタへのアトミックアクセスを取得します。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - 可変参照は一意の所有権を保証します。
        //  - `*mut T` と `Self` の配置は、上記で確認したように、rust でサポートされているすべてのプラットフォームで同じです。
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// アトミックを消費し、含まれている値を返します。
    ///
    /// `self` を値で渡すと、他のスレッドが同時にアトミックデータにアクセスしないことが保証されるため、これは安全です。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// ポインタから値をロードします。
    ///
    /// `load` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// 可能な値は、[`SeqCst`]、[`Acquire`]、および [`Relaxed`] です。
    ///
    /// # Panics
    ///
    /// `order` が [`Release`] または [`AcqRel`] の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// ポインタに値を格納します。
    ///
    /// `store` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// 可能な値は、[`SeqCst`]、[`Release`]、および [`Relaxed`] です。
    ///
    /// # Panics
    ///
    /// `order` が [`Acquire`] または [`AcqRel`] の場合は Panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ポインタに値を格納し、前の値を返します。
    ///
    /// `swap` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
    ///
    ///
    /// **Note:** このメソッドは、ポインターのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// 現在の値が `current` 値と同じである場合、値をポインタに格納します。
    ///
    /// 戻り値は常に前の値です。`current` と等しい場合、値が更新されました。
    ///
    /// `compare_and_swap` また、この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
    /// [`AcqRel`] を使用している場合でも、操作が失敗する可能性があるため、`Acquire` ロードを実行するだけで、`Release` セマンティクスがないことに注意してください。
    /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になります。
    ///
    /// **Note:** このメソッドは、ポインターのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # `compare_exchange` および `compare_exchange_weak` への移行
    ///
    /// `compare_and_swap` `compare_exchange` と同等であり、メモリ順序のマッピングは次のとおりです。
    ///
    /// オリジナル | 成功 | 失敗
    /// -------- | ------- | -------
    /// リラックス | リラックス | リラックスした取得 | 取得 | リリースの取得 | リリース | リラックスした AcqRel |AcqRel |SeqCst を取得する | SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` コンペア・アンド・スワップがループで使用されている場合、コンパイラーはより良いアセンブリー・コードを生成できるようになります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 現在の値が `current` 値と同じである場合、値をポインタに格納します。
    ///
    /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
    /// 成功すると、この値は `current` に等しくなることが保証されます。
    ///
    /// `compare_exchange` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
    /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
    ///
    /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、ポインターのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// 現在の値が `current` 値と同じである場合、値をポインタに格納します。
    ///
    /// [`AtomicPtr::compare_exchange`] とは異なり、この関数は、比較が成功した場合でも誤って失敗することが許可されているため、一部のプラットフォームではコードがより効率的になる可能性があります。
    ///
    /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
    ///
    /// `compare_exchange_weak` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
    /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
    /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、ポインターのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // 安全性: この組み込み関数は、生のポインターで動作するため、安全ではありません
        // しかし、ポインターが有効であることは確かであり (参照により、`UnsafeCell` から取得したばかりです)、アトミック操作自体により、`UnsafeCell` の内容を安全に変更できます。
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// 値を取得し、オプションの新しい値を返す関数を適用します。関数が `Some(_)` を返した場合は、`Ok(previous_value)` の `Result` を返します。それ以外の場合は、`Err(previous_value)` を返します。
    ///
    /// Note: 関数が `Some(_)` を返す限り、その間に値が他のスレッドから変更された場合、これは関数を複数回呼び出すことができますが、関数は格納された値に 1 回だけ適用されます。
    ///
    ///
    /// `fetch_update` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
    /// 1 つ目は、操作が最終的に成功するときに必要な順序を説明し、2 つ目は、ロードに必要な順序を説明します。
    /// これらは、それぞれ [`AtomicPtr::compare_exchange`] の成功と失敗の順序に対応しています。
    ///
    /// [`Acquire`] を成功注文として使用すると、ストアはこの操作の一部である [`Relaxed`] になり、[`Release`] を使用すると、最終的に成功したロード [`Relaxed`] になります。
    /// (failed) のロード順序は、[`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功順序と同等かそれよりも弱い必要があります。
    ///
    /// **Note:** このメソッドは、ポインターのアトミック操作をサポートするプラットフォームでのみ使用できます。
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` を `AtomicBool` に変換します。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // このマクロは、一部のアーキテクチャでは使用されなくなります。
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// スレッド間で安全に共有できる整数型。
        ///
        /// この型は、基になる整数型 [` と同じメモリ内表現を持っています
        ///
        #[doc = $s_int_type]
        /// `].
        /// アトミックタイプと非アトミックタイプの違い、およびこのタイプの移植性の詳細については、[module-level documentation] を参照してください。
        ///
        ///
        /// **Note:** このタイプは、[` のアトミックロードとストアをサポートするプラットフォームでのみ使用できます。
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0` に初期化されたアトミック整数。
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // 送信は暗黙的に実装されます。
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// 新しいアトミック整数を作成します。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// 基になる整数への可変参照を返します。
            ///
            /// 可変参照は、他のスレッドがアトミックデータに同時にアクセスしないことを保証するため、これは安全です。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int、100) ;
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - 可変参照は一意の所有権を保証します。
                //  - `$int_type` と `Self` の配置は、$cfg_align によって約束され、上記で検証されたものと同じです。
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// アトミックを消費し、含まれている値を返します。
            ///
            /// `self` を値で渡すと、他のスレッドが同時にアトミックデータにアクセスしないことが保証されるため、これは安全です。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// アトミック整数から値をロードします。
            ///
            /// `load` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
            /// 可能な値は、[`SeqCst`]、[`Acquire`]、および [`Relaxed`] です。
            ///
            /// # Panics
            ///
            /// `order` が [`Release`] または [`AcqRel`] の場合は Panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// 値をアトミック整数に格納します。
            ///
            /// `store` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
            ///  可能な値は、[`SeqCst`]、[`Release`]、および [`Relaxed`] です。
            ///
            /// # Panics
            ///
            /// `order` が [`Acquire`] または [`AcqRel`] の場合は Panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// 値をアトミック整数に格納し、前の値を返します。
            ///
            /// `swap` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// 現在の値が `current` 値と同じである場合、値をアトミック整数に格納します。
            ///
            /// 戻り値は常に前の値です。`current` と等しい場合、値が更新されました。
            ///
            /// `compare_and_swap` また、この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。
            /// [`AcqRel`] を使用している場合でも、操作が失敗する可能性があるため、`Acquire` ロードを実行するだけで、`Release` セマンティクスがないことに注意してください。
            ///
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になります。
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` および `compare_exchange_weak` への移行
            ///
            /// `compare_and_swap` `compare_exchange` と同等であり、メモリ順序のマッピングは次のとおりです。
            ///
            /// オリジナル | 成功 | 失敗
            /// -------- | ------- | -------
            /// リラックス | リラックス | リラックスした取得 | 取得 | リリースの取得 | リリース | リラックスした AcqRel |AcqRel |SeqCst を取得する | SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` コンペア・アンド・スワップがループで使用されている場合、コンパイラーはより良いアセンブリー・コードを生成できるようになります。
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// 現在の値が `current` 値と同じである場合、値をアトミック整数に格納します。
            ///
            /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
            /// 成功すると、この値は `current` に等しくなることが保証されます。
            ///
            /// `compare_exchange` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
            /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
            /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
            /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
            ///
            /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// 現在の値が `current` 値と同じである場合、値をアトミック整数に格納します。
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// この関数は、比較が成功した場合でも誤って失敗することが許可されているため、一部のプラットフォームではコードがより効率的になる可能性があります。
            /// 戻り値は、新しい値が書き込まれたかどうかを示し、前の値が含まれている結果です。
            ///
            /// `compare_exchange_weak` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
            /// `success` `current` との比較が成功した場合に実行される、読み取り - 変更 - 書き込み操作に必要な順序について説明します。
            /// `failure` 比較が失敗したときに行われるロード操作に必要な順序について説明します。
            /// [`Acquire`] を成功注文として使用すると、ストアはこの操作 [`Relaxed`] の一部になり、[`Release`] を使用するとロードが成功します [`Relaxed`] になります。
            ///
            /// 失敗の順序は [`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功の順序と同等かそれよりも弱い必要があります。
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// ループ {letnew=old * 2;
            ///     val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, } に一致}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// 現在の値に追加し、前の値を返します。
            ///
            /// この操作はオーバーフロー時にラップアラウンドします。
            ///
            /// `fetch_add` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// 現在の値から減算し、前の値を返します。
            ///
            /// この操作はオーバーフロー時にラップアラウンドします。
            ///
            /// `fetch_sub` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// 現在の値のビット単位の "and"。
            ///
            /// 現在の値と引数 `val` に対してビット単位の "and" 演算を実行し、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_and` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// 現在の値のビット単位の "nand"。
            ///
            /// 現在の値と引数 `val` に対してビット単位の "nand" 演算を実行し、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_nand` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13＆0x31) ) ;
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// 現在の値のビット単位の "or"。
            ///
            /// 現在の値と引数 `val` に対してビット単位の "or" 演算を実行し、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_or` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// 現在の値のビット単位の "xor"。
            ///
            /// 現在の値と引数 `val` に対してビット単位の "xor" 演算を実行し、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_xor` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// 値を取得し、オプションの新しい値を返す関数を適用します。関数が `Some(_)` を返した場合は、`Ok(previous_value)` の `Result` を返します。それ以外の場合は、`Err(previous_value)` を返します。
            ///
            /// Note: 関数が `Some(_)` を返す限り、その間に値が他のスレッドから変更された場合、これは関数を複数回呼び出すことができますが、関数は格納された値に 1 回だけ適用されます。
            ///
            ///
            /// `fetch_update` この操作のメモリ順序を記述するために、2 つの [`Ordering`] 引数を取ります。
            /// 1 つ目は、操作が最終的に成功するときに必要な順序を説明し、2 つ目は、ロードに必要な順序を説明します。これらは、の成功と失敗の順序に対応しています。
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] を成功注文として使用すると、ストアはこの操作の一部である [`Relaxed`] になり、[`Release`] を使用すると、最終的に成功したロード [`Relaxed`] になります。
            /// (failed) のロード順序は、[`SeqCst`]、[`Acquire`]、または [`Relaxed`] のみであり、成功順序と同等かそれよりも弱い必要があります。
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst、Ordering::SeqCst、| x | Some(x + 1))、 Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst、Ordering::SeqCst、| x | Some(x + 1))、 Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// 現在の値で最大。
            ///
            /// 現在の値と引数 `val` の最大値を見つけ、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_max` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// バー = 42 とします。
            /// max_foo=foo.fetch_max (bar、 Ordering::SeqCst).max(bar);
            /// アサート! (max_foo==42) ;
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// 現在の値で最小。
            ///
            /// 現在の値と引数 `val` の最小値を見つけ、新しい値を結果に設定します。
            ///
            /// 前の値を返します。
            ///
            /// `fetch_min` この操作のメモリ順序を説明する [`Ordering`] 引数を取ります。すべての注文モードが可能です。
            /// [`Acquire`] を使用すると、この操作のストア部分が [`Relaxed`] になり、[`Release`] を使用すると、ロード部分が [`Relaxed`] になることに注意してください。
            ///
            ///
            /// **注**: このメソッドは、でアトミック操作をサポートするプラットフォームでのみ使用できます
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// バー = 12 とします。
            /// min_foo=foo.fetch_min (bar、 Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo、12) ;
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // 安全性: データの競合は、アトミック組み込み関数によって防止されます。
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// 基になる整数への可変ポインタを返します。
            ///
            /// 結果の整数に対して非アトミックな読み取りと書き込みを行うと、データの競合が発生する可能性があります。
            /// このメソッドは、関数シグネチャが使用する可能性がある FFI で主に役立ちます
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// アトミックタイプは内部の可変性で機能するため、このアトミックへの共有参照から `*mut` ポインターを返すことは安全です。
            /// アトミックのすべての変更は、共有参照を介して値を変更し、アトミック操作を使用している限り、安全に変更できます。
            /// 返された raw ポインターを使用するには、`unsafe` ブロックが必要ですが、それでも同じ制限を守る必要があります。それに対する操作はアトミックである必要があります。
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) を無視する
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // 安全性: `my_atomic_op` がアトミックである限り安全です。
            /// 安全ではない {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // 安全性: 発信者は `atomic_store` の安全契約を守る必要があります。
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_load` の安全契約を守る必要があります。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_swap` の安全契約を守る必要があります。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// 以前の値を返します (__sync_fetch_and_add など)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_add` の安全契約を守る必要があります。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// 以前の値を返します (__sync_fetch_and_sub など)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_sub` の安全契約を守る必要があります。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 安全性: 発信者は `atomic_compare_exchange` の安全契約を守る必要があります。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // 安全性: 発信者は `atomic_compare_exchange_weak` の安全契約を守る必要があります。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_and` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_nand` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_or` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_xor` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// 最大値を返します (符号付き比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_max` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// 最小値を返します (符号付き比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_min` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// 最大値を返します (符号なし比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_umax` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// 最小値を返します (符号なし比較)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // 安全性: 発信者は `atomic_umin` の安全契約を守る必要があります
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// アトミックフェンス。
///
/// 指定された順序に応じて、フェンスはコンパイラと CPU がその周囲の特定のタイプのメモリ操作を並べ替えることを防ぎます。
/// これにより、他のスレッドのアトミック操作またはフェンスとの同期が作成されます。
///
/// (少なくとも) [`Release`] 順序付けセマンティクスを持つフェンス 'A' は、操作 X と Y が存在する場合に限り、(少なくとも) [`Acquire`] セマンティクスを持つフェンス 'B' と同期します。両方とも、A が前にシーケンスされるように何らかのアトミックオブジェクト 'M' で動作します。X、Y は、B と Y が M への変更を監視する前に同期されます。
/// これにより、A と B の間の依存関係が発生する前に発生します。
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] または [`Acquire`] セマンティクスを使用したアトミック操作は、フェンスと同期することもできます。
///
/// [`Acquire`] セマンティクスと [`Release`] セマンティクスの両方を持つことに加えて、[`SeqCst`] 順序を持つフェンスは、他の [`SeqCst`] 操作および / またはフェンスのグローバルプログラム順序に参加します。
///
/// [`Acquire`]、[`Release`]、[`AcqRel`]、および [`SeqCst`] の注文を受け入れます。
///
/// # Panics
///
/// `order` が [`Relaxed`] の場合は Panics。
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // スピンロックに基づく相互排除プリミティブ。
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // 古い値が `false` になるまで待ちます。
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // このフェンスは、`unlock` のストアと同期します。
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // 安全性: アトミックフェンスの使用は安全です。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// コンパイラのメモリフェンス。
///
/// `compiler_fence` マシンコードを出力しませんが、コンパイラが実行できるメモリの並べ替えの種類を制限します。具体的には、指定された [`Ordering`] セマンティクスによっては、コンパイラーは、`compiler_fence` への呼び出しの反対側への呼び出しの前後から読み取りまたは書き込みを移動することを許可されない場合があります。*ハードウェア* がそのような再注文を行うことを **妨げない** ことに注意してください。
///
/// これは、シングルスレッドの実行コンテキストでは問題になりませんが、他のスレッドが同時にメモリを変更する可能性がある場合は、[`fence`] などのより強力な同期プリミティブが必要です。
///
/// 異なる順序付けセマンティクスによって防止される再順序付けは次のとおりです。
///
///  - [`SeqCst`] では、この時点での読み取りと書き込みの並べ替えは許可されていません。
///  - [`Release`] では、先行する読み取りと書き込みを後続の書き込みを超えて移動することはできません。
///  - [`Acquire`] では、後続の読み取りと書き込みを先行する読み取りの前に移動することはできません。
///  - [`AcqRel`] では、上記の両方のルールが適用されます。
///
/// `compiler_fence` 通常、スレッドが *それ自体と* 競合するのを防ぐためにのみ役立ちます。つまり、特定のスレッドが 1 つのコードを実行していて、その後中断され、別の場所でコードの実行を開始した場合 (同じスレッド内にあり、概念的には同じコア上にある場合)。従来のプログラムでは、これはシグナルハンドラーが登録されている場合にのみ発生する可能性があります。
/// より低レベルのコードでは、このような状況は、割り込みを処理するとき、プリエンプションを使用してグリーンスレッドを実装するときなどにも発生する可能性があります。
/// 好奇心旺盛な読者は、Linux カーネルの [memory barriers] に関する説明を読むことをお勧めします。
///
/// # Panics
///
/// `order` が [`Relaxed`] の場合は Panics。
///
/// # Examples
///
/// `compiler_fence` がないと、すべてが単一のスレッドで発生しているにもかかわらず、次のコードの `assert_eq!` が成功することは *保証されません*。
/// 理由を理解するために、コンパイラーはストアを `IMPORTANT_VARIABLE` と `IS_READ` の両方が `Ordering::Relaxed` であるため、自由にスワップできることを覚えておいてください。含まれている場合、`IS_READY` が更新された直後にシグナルハンドラーが呼び出されると、シグナルハンドラーには `IS_READY=1` が表示されますが、`IMPORTANT_VARIABLE=0` が表示されます。
/// `compiler_fence` を使用すると、この状況が改善されます。
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // 以前の書き込みがこのポイントを超えて移動するのを防ぎます
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // 安全性: アトミックフェンスの使用は安全です。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ビジー待機スピンループ (「スピンロック」) 内にあることをプロセッサに通知します。
///
/// この関数は廃止され、[`hint::spin_loop`] が採用されました。
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}