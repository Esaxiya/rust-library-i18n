//! utf8 エラータイプを定義します。

use crate::fmt;

/// [`u8`] のシーケンスを文字列として解釈しようとしたときに発生する可能性のあるエラー。
///
/// そのため、たとえば、[`String`] と [`＆str`] の両方の関数とメソッドの `from_utf8` ファミリは、このエラーを利用します。
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// このエラータイプのメソッドを使用すると、ヒープメモリを割り当てずに `String::from_utf8_lossy` と同様の機能を作成できます。
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// 有効な UTF-8 が検証されたまでの指定された文字列のインデックスを返します。
    ///
    /// `from_utf8(&input[..index])` が `Ok(_)` を返すような最大インデックスです。
    ///
    ///
    /// # Examples
    ///
    /// 基本的な使用法:
    ///
    /// ```
    /// use std::str;
    ///
    /// // vector 内のいくつかの無効なバイト
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 Utf8Error を返します
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // 2 番目のバイトはここでは無効です
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// 障害に関する詳細情報を提供します。
    ///
    /// * `None`: 予期せず入力の終わりに達しました。
    ///   `self.valid_up_to()` 入力の終わりから 1〜3 バイトです。
    ///   バイトストリーム (ファイルやネットワークソケットなど) がインクリメンタルにデコードされている場合、これは、UTF-8 バイトシーケンスが複数のチャンクにまたがっている有効な `char` である可能性があります。
    ///
    ///
    /// * `Some(len)`: 予期しないバイトが検出されました。
    ///   提供される長さは、`valid_up_to()` で指定されたインデックスで始まる無効なバイトシーケンスの長さです。
    ///   非可逆デコードの場合は、そのシーケンスの後 ([`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] を挿入した後) にデコードを再開する必要があります。
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] を使用して `bool` を解析するとエラーが返されますが失敗します
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}