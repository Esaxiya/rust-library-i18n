//! UTF-8 検証に関連する操作。

use crate::mem;

use super::Utf8Error;

/// 最初のバイトの初期コードポイントアキュムレータを返します。
/// 最初のバイトは特別で、幅 2 には下位 5 ビット、幅 3 には 4 ビット、幅 4 には 3 ビットのみが必要です。
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// 継続バイト `byte` で更新された `ch` の値を返します。
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// バイトが UTF-8 継続バイトであるかどうかをチェックします (つまり、ビット `10` で始まります)。
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// バイトイテレータから次のコードポイントを読み取ります (UTF-8 のようなエンコーディングを想定)。
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 をデコードします
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // マルチバイトの場合は、次のバイトの組み合わせからデコードします: [[[x y] z] w]
    //
    // NOTE: パフォーマンスはここでの正確な定式化に敏感です
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] ケース
        // 0xE0 の 5 番目のビット..0xEF は常にクリアであるため、`init` は引き続き有効です。
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ケースは `init` の下位 3 ビットのみを使用します
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// バイトイテレータから最後のコードポイントを読み取ります (UTF-8 のようなエンコーディングを想定)。
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 をデコードします
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // マルチバイトの場合は、次のバイトの組み合わせからデコードします。[x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// u64 を usize に適合させるために切り捨てを使用する
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// ワード `x` のいずれかのバイトが nonascii (>=128) の場合、`true` を返します。
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// `v` をウォークスルーして、それが有効な UTF-8 シーケンスであることを確認し、その場合は `Ok(())` を返します。無効な場合は、 `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // データが必要でしたが、何もありませんでした: エラー!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 バイトエンコーディングは、コードポイント \u {0080} から \u {07ff} の最初の C2 80 最後の DFBF 用です。
            // 3 バイトエンコーディングは、コードポイント \u {0800} から \u {ffff} までです。最初の E0 A0 80 最後の EFBF BF (代理コードポイントを除く) \u {d800} から \u {dfff} ED A0 80 から EDBF BF
            // 4 バイトエンコーディングはコードポイント用です \u {1000} 0 から \u {10ff} ff 最初の F0 90 8080 最後の F4 8F BF BF
            //
            // RFC の UTF-8 構文を使用する
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=％x00-7F UTF8-2=％xC2-DFUTF8 - テール UTF8-3= %xE0％xA0-BF UTF8 - テール /％xE1-EC 2( UTF8-tail )/%xED％x80-9F UTF8 - テール /％xEE-EF 2( UTF8-tail ) UTF8-4= %xF0％x90-BF 2( UTF8-tail )/％xF1-F3 3( UTF8-tail )/%xF4％x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // アスキーの場合は、すぐにスキップしてみてください。
            // ポインタが整列したら、ASCII 以外のバイトを含むワードが見つかるまで、反復ごとに 2 ワードのデータを読み取ります。
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // 安全性: `align - index` と `ascii_block_size` は
                    // `usize_bytes` の倍数、`block = ptr.add(index)` は常に `usize` と位置合わせされるため、`block` と `block.offset(1)` の両方を間接参照しても安全です。
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // 非 ascii バイトがある場合はブレーク
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ワードワイズループが停止したポイントからのステップ
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// 最初のバイトを指定して、この UTF-8 文字のバイト数を決定します。
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// 継続バイトの値ビットのマスク。
const CONT_MASK: u8 = 0b0011_1111;
/// 継続バイトのタグビット (タグマスクは !CONT_MASK) の値。
const TAG_CONT_U8: u8 = 0b1000_0000;

// `&str` を最大で `max` に等しい長さに切り捨てると、切り捨てられた場合は `true` が返され、新しい str が返されます。
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}