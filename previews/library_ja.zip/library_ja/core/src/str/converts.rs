//! バイトスライスから `str` を作成する方法。

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// バイトのスライスを文字列スライスに変換します。
///
/// 文字列スライス ([`&str`]) はバイト ([`u8`]) で構成され、バイトスライス ([`&[u8]`][byteslice]) はバイトで構成されているため、この関数は 2 つの間で変換します。
/// ただし、すべてのバイトスライスが有効な文字列スライスであるとは限りません。[`&str`] では、有効な UTF-8 である必要があります。
/// `from_utf8()` バイトが有効な UTF-8 であることを確認してから、変換を実行します。
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// バイトスライスが有効な UTF-8 であることが確実であり、有効性チェックのオーバーヘッドを発生させたくない場合は、この関数の安全でないバージョンである [`from_utf8_unchecked`] があります。これは同じ動作をしますが、チェックをスキップします。
///
///
/// `&str` の代わりに `String` が必要な場合は、[`String::from_utf8`][string] を検討してください。
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// `[u8; N]` をスタック割り当てでき、その [`&[u8]`][byteslice] を取得できるため、この関数はスタック割り当て文字列を作成する 1 つの方法です。以下の例のセクションにこの例があります。
///
/// [byteslice]: slice
///
/// # Errors
///
/// スライスが UTF-8 でない場合は、提供されたスライスが UTF-8 でない理由の説明とともに `Err` を返します。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::str;
///
/// // vector 内のいくつかのバイト
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // これらのバイトが有効であることがわかっているので、`unwrap()` を使用してください。
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// 不正なバイト:
///
/// ```
/// use std::str;
///
/// // vector 内のいくつかの無効なバイト
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// 返される可能性のあるエラーの種類の詳細については、[`Utf8Error`] のドキュメントを参照してください。
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // スタックに割り当てられた配列内のいくつかのバイト
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // これらのバイトが有効であることがわかっているので、`unwrap()` を使用してください。
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // 安全性: 検証を実行しただけです。
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// バイトの可変スライスを可変文字列スライスに変換します。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" 可変 vector として
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // これらのバイトが有効であることがわかっているので、`unwrap()` を使用できます
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// 不正なバイト:
///
/// ```
/// use std::str;
///
/// // 可変 vector のいくつかの無効なバイト
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// 返される可能性のあるエラーの種類の詳細については、[`Utf8Error`] のドキュメントを参照してください。
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // 安全性: 検証を実行しただけです。
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// 文字列に有効な UTF-8 が含まれていることを確認せずに、バイトのスライスを文字列スライスに変換します。
///
/// 詳細については、安全なバージョンである [`from_utf8`] を参照してください。
///
/// # Safety
///
/// この関数は、渡されたバイトが有効な UTF-8 であるかどうかをチェックしないため、安全ではありません。
/// この制約に違反すると、Rust の残りの部分が [`＆str`] が有効な UTF-8 であると想定するため、未定義の動作が発生します。
///
///
/// [`&str`]: str
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::str;
///
/// // vector 内のいくつかのバイト
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // 安全性: 呼び出し元は、バイト `v` が有効な UTF-8 であることを保証する必要があります。
    // また、同じレイアウトの `&str` と `&[u8]` に依存しています。
    unsafe { mem::transmute(v) }
}

/// 文字列に有効な UTF-8 が含まれていることを確認せずに、バイトのスライスを文字列スライスに変換します。可変バージョン。
///
///
/// 詳細については、不変バージョンの [`from_utf8_unchecked()`] を参照してください。
///
/// # Examples
///
/// 基本的な使用法:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // 安全性: 呼び出し元はバイト `v` を保証する必要があります
    // は有効な UTF-8 であるため、`*mut str` へのキャストは安全です。
    // また、ポインタは書き込みに有効であることが保証されている参照から取得されるため、ポインタの逆参照は安全です。
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}