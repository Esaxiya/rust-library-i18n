//! 文字列パターン API。
//!
//! パターン API は、文字列を検索するときにさまざまなパターンタイプを使用するための一般的なメカニズムを提供します。
//!
//! 詳細については、traits [`Pattern`]、[`Searcher`]、[`ReverseSearcher`]、および [`DoubleEndedSearcher`] を参照してください。
//!
//! この API は不安定ですが、[`str`] タイプの安定した API を介して公開されます。
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`]、[`char`]、[`char`] のスライス、および `FnMut(char) -> bool` を実装する関数とクロージャの安定した API の [implemented][pattern-impls] です。
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // 文字パターン
//! assert_eq!(s.find('n'), Some(2));
//! // 文字パターンのスライス
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // クロージャパターン
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// 文字列パターン。
///
/// `Pattern<'a>` は、実装タイプを [`&'a str`][str] で検索するための文字列パターンとして使用できることを表します。
///
/// たとえば、`'a'` と `"aa"` はどちらも、文字列 `"baaaab"` のインデックス `1` で一致するパターンです。
///
/// trait 自体は、関連する [`Searcher`] タイプのビルダーとして機能し、文字列内のパターンの出現を見つける実際の作業を行います。
///
///
/// パターンのタイプに応じて、[`str::find`] や [`str::contains`] などのメソッドの動作が変わる可能性があります。
/// 次の表は、これらの動作の一部を示しています。
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// このパターンに関連する検索者
    type Searcher: Searcher<'a>;

    /// `self` および `haystack` から関連するサーチャーを構築して検索します。
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// パターンが干し草の山のどこかに一致するかどうかを確認します
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// 干し草の山の前でパターンが一致するかどうかを確認します
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// 干し草の山の後ろでパターンが一致するかどうかを確認します
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// 一致する場合は、干し草の山の前面からパターンを削除します。
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // 安全性: `Searcher` は有効なインデックスを返すことが知られています。
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// 一致する場合は、干し草の山の後ろからパターンを削除します。
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // 安全性: `Searcher` は有効なインデックスを返すことが知られています。
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] または [`ReverseSearcher::next_back()`] を呼び出した結果。
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// パターンの一致が `haystack[a..b]` で見つかったことを表します。
    ///
    Match(usize, usize),
    /// `haystack[a..b]` がパターンの一致の可能性として拒否されたことを表します。
    ///
    /// 2 つの `Match` の間に複数の `Reject` が存在する可能性があることに注意してください。それらを 1 つに結合する必要はありません。
    ///
    ///
    Reject(usize, usize),
    /// 干し草の山のすべてのバイトが訪問され、反復が終了したことを表します。
    ///
    Done,
}

/// 文字列パターンのサーチャー。
///
/// この trait は、文字列の先頭の (left) から始まるパターンの重複しない一致を検索するためのメソッドを提供します。
///
/// これは、[`Pattern`] trait の関連する `Searcher` タイプによって実装されます。
///
/// [`next()`][Searcher::next] メソッドによって返されるインデックスは、干し草の山の有効な utf8 境界上にある必要があるため、trait は安全でないとマークされます。
/// これにより、この trait のコンシューマーは、追加のランタイムチェックなしで干し草の山をスライスできます。
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// 検索対象の基になる文字列の Getter
    ///
    /// 常に同じ [`&str`][str] を返します。
    fn haystack(&self) -> &'a str;

    /// 正面から次の検索ステップを実行します。
    ///
    /// - `haystack[a..b]` がパターンに一致する場合、[`Match(a, b)`][SearchStep::Match] を返します。
    /// - `haystack[a..b]` が部分的にでもパターンと一致しない場合、[`Reject(a, b)`][SearchStep::Reject] を返します。
    /// - 干し草の山のすべてのバイトが訪問された場合、[`Done`][SearchStep::Done] を返します。
    ///
    /// [`Done`][SearchStep::Done] までの [`Match`][SearchStep::Match] および [`Reject`][SearchStep::Reject] 値のストリームには、隣接し、重複せず、干し草の山全体をカバーし、utf8 の境界にあるインデックス範囲が含まれます。
    ///
    ///
    /// [`Match`][SearchStep::Match] の結果には、一致したパターン全体が含まれている必要がありますが、[`Reject`][SearchStep::Reject] の結果は、任意の数の隣接するフラグメントに分割される場合があります。両方の範囲の長さがゼロの場合があります。
    ///
    /// 例として、パターン `"aaa"` と干し草の山 `"cbaaaaab"` がストリームを生成する場合があります
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// 次の [`Match`][SearchStep::Match] 結果を検索します。[`next()`][Searcher::next] を参照してください。
    ///
    /// [`next()`][Searcher::next] とは異なり、これと [`next_reject`][Searcher::next_reject] の返される範囲が重複するという保証はありません。
    /// これにより、`(start_match, end_match)` が返されます。ここで、start_match は一致が開始される場所のインデックスであり、end_match は一致の終了後のインデックスです。
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// 次の [`Reject`][SearchStep::Reject] 結果を検索します。[`next()`][Searcher::next] および [`next_match()`][Searcher::next_match] を参照してください。
    ///
    /// [`next()`][Searcher::next] とは異なり、これと [`next_match`][Searcher::next_match] の返される範囲が重複するという保証はありません。
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// 文字列パターンの逆サーチャー。
///
/// この trait は、文字列の後ろの (right) から始まるパターンの重複しない一致を検索するためのメソッドを提供します。
///
/// パターンが後方からの検索をサポートしている場合は、[`Pattern`] trait の関連する [`Searcher`] タイプによって実装されます。
///
///
/// この trait によって返されるインデックス範囲は、逆方向の順方向検索のインデックス範囲と正確に一致する必要はありません。
///
/// この trait が安全でないとマークされている理由については、親 trait [`Searcher`] を参照してください。
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// 後ろから次の検索ステップを実行します。
    ///
    /// - `haystack[a..b]` がパターンに一致する場合、[`Match(a, b)`][SearchStep::Match] を返します。
    /// - `haystack[a..b]` が部分的にでもパターンと一致しない場合、[`Reject(a, b)`][SearchStep::Reject] を返します。
    /// - 干し草の山のすべてのバイトが訪問された場合、[`Done`][SearchStep::Done] を返します
    ///
    /// [`Done`][SearchStep::Done] までの [`Match`][SearchStep::Match] および [`Reject`][SearchStep::Reject] 値のストリームには、隣接し、重複せず、干し草の山全体をカバーし、utf8 の境界にあるインデックス範囲が含まれます。
    ///
    ///
    /// [`Match`][SearchStep::Match] の結果には、一致したパターン全体が含まれている必要がありますが、[`Reject`][SearchStep::Reject] の結果は、任意の数の隣接するフラグメントに分割される場合があります。両方の範囲の長さがゼロの場合があります。
    ///
    /// 例として、パターン `"aaa"` と干し草の山 `"cbaaaaab"` は、ストリーム `[Reject(7, 8)、Match(4, 7)、Reject(1, 4)、 Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// 次の [`Match`][SearchStep::Match] 結果を検索します。
    /// [`next_back()`][ReverseSearcher::next_back] を参照してください。
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// 次の [`Reject`][SearchStep::Reject] 結果を検索します。
    /// [`next_back()`][ReverseSearcher::next_back] を参照してください。
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`ReverseSearcher`] を [`DoubleEndedIterator`] 実装に使用できることを表すマーカー trait。
///
/// このため、[`Searcher`] および [`ReverseSearcher`] の実装は次の条件に従う必要があります。
///
/// - `next()` のすべての結果は、逆の順序で `next_back()` の結果と同一である必要があります。
/// - `next()` `next_back()` は、値の範囲の両端として動作する必要があります。つまり、"walk past each other" は動作できません。
///
/// # Examples
///
/// `char::Searcher` [`char`] を検索するには、一度に 1 つずつ調べるだけでよく、両端から同じように動作するため、は `DoubleEndedSearcher` です。
///
/// `(&str)::Searcher` 干し草の山 `"aaa"` のパターン `"aa"` は、検索される側に応じて `"[aa]a"` または `"a[aa]"` のいずれかとして一致するため、は `DoubleEndedSearcher` ではありません。
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// 文字の実装
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` に関連付けられたタイプ。
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // 安全性不変条件: `finger`/`finger_back` は `haystack` の有効な utf8 バイトインデックスである必要がありますこの不変条件は、next_match および next_match_back 内で壊すことができますが、有効なコードポイント境界で指で終了する必要があります。
    //
    //
    /// `finger` 前方検索の現在のバイトインデックスです。
    /// インデックスのバイトの前に存在すると想像してください。
    /// `haystack[finger]` 前方検索中に検査する必要があるスライスの最初のバイトです
    ///
    finger: usize,
    /// `finger_back` は、逆検索の現在のバイトインデックスです。
    /// インデックスのバイトの後に存在すると想像してください。
    /// haystack [finger_back、1] は、前方検索中に検査する必要があるスライスの最後のバイトです (したがって、next_back()) を呼び出すときに検査される最初のバイトです。
    ///
    finger_back: usize,
    /// 検索されているキャラクター
    needle: char,

    // 安全性不変: `utf8_size` は 5 未満でなければなりません
    /// utf8 でエンコードされたときに `needle` が占めるバイト数。
    utf8_size: usize,
    /// `needle` の utf8 エンコードコピー
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // 安全性: 1-4 は `get_unchecked` の安全性を保証します
        // 1. `self.finger` および `self.finger_back` は Unicode 境界に保持されます (これは不変です)
        // 2. `self.finger >= 0` 0 から始まり、増加するだけなので
        // 3. `self.finger < self.finger_back` そうしないと、char `iter` が `SearchStep::Done` を返すためです。
        // 4.
        // `self.finger` `self.finger_back` は最後から始まり、減少するだけなので、干し草の山の終わりの前に来る
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 として再エンコードせずに、現在の文字のバイトオフセットを追加します
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // 最後に見つかった文字の後に干し草の山を取得します
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 でエンコードされた針の最後のバイト安全性: `utf8_size < 5` という不変条件があります
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // 新しい finger は、見つかったバイトのインデックスに 1 を加えたものです。これは、文字の最後のバイトを memchr したためです。
                //
                // これにより、UTF8 の境界に常に指が届くとは限らないことに注意してください。
                // 文字が *見つからなかった* 場合は、3 バイトまたは 4 バイトの文字の最後以外のバイトにインデックスを付けた可能性があります。
                // ꁁ (U + A041 YI SYLLABLE PA)、utf-8 `EA 81 81` のような文字では、3 番目のバイトを検索するときに常に 2 番目のバイトが見つかるため、次の有効な開始バイトにスキップすることはできません。
                //
                //
                // しかし、これはまったく問題ありません。
                // self.finger が UTF8 境界上にあるという不変条件がありますが、この不変条件はこのメソッド内では依存されません (CharSearcher::next()) で依存されます)。
                //
                // 文字列の最後に到達したとき、または何かが見つかった場合にのみ、このメソッドを終了します。何かが見つかると、`finger` は UTF8 境界に設定されます。
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // 何も見つかりませんでした、終了します
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // next_reject に、サーチャー trait のデフォルトの実装を使用させます
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // 安全性: 上記の next() のコメントを参照してください
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 として再エンコードせずに、現在の文字のバイトオフセットを減算します
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // 干し草の山を取得しますが、最後に検索した文字は含まれません
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 でエンコードされた針の最後のバイト安全性: `utf8_size < 5` という不変条件があります
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // self.finger によってオフセットされたスライスを検索し、self.finger を追加して元のインデックスを取り戻しました
                //
                let index = self.finger + index;
                // memrchr は、検索したいバイトのインデックスを返します。
                // ASCII 文字の場合、これは確かに私たちが新しい指になりたいと思っていたものです ("after" は逆反復のパラダイムで見つかった文字です)。
                //
                // マルチバイト文字の場合、ASCII よりも多いバイト数だけスキップする必要があります
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // 見つかった文字の前 (つまり、開始インデックス) に指を移動します
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ここでは finger_back=index、size +1 を使用できません。
                // 異なるサイズの文字の最後の文字 (または異なる文字の中央のバイト) が見つかった場合は、finger_back を `index` に下げる必要があります。
                // これにより、同様に `finger_back` が境界上になくなる可能性がありますが、境界上で、または干し草の山が完全に検索されたときにのみこの関数を終了するため、これは問題ありません。
                //
                //
                // next_match とは異なり、最後のバイトを検索しているため、utf-8 でバイトが繰り返されるという問題はありません。また、逆に検索した場合にのみ最後のバイトを見つけることができます。
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // 何も見つかりませんでした、終了します
                return None;
            }
        }
    }

    // next_reject_back に、サーチャー trait のデフォルトの実装を使用させます
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// 指定された [`char`] に等しい文字を検索します。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq ラッパーの実装
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // 内部バイトスライスイテレータの長さを比較して、現在の文字の長さを見つけます
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // 内部バイトスライスイテレータの長さを比較して、現在の文字の長さを見つけます
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// ＆[char] の実装
/////////////////////////////////////////////////////////////////////////////

// Todo: 意味のあいまいさのために変更 / 削除します。

/// `<&[char] as Pattern<'a>>::Searcher` に関連付けられたタイプ。
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// スライス内の [`char`] のいずれかに等しい文字を検索します。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F の実装: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` に関連付けられたタイプ。
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// 指定された述語に一致する [`char`] を検索します。
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&str の実装
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl に委任します。
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str の実装
/////////////////////////////////////////////////////////////////////////////

/// 割り当てられていない部分文字列検索。
///
/// パターン `""` を、各文字境界で空の一致を返すものとして処理します。
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// 干し草の山の前でパターンが一致するかどうかを確認します。
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// 一致する場合は、干し草の山の前面からパターンを削除します。
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // 安全性: プレフィックスが存在することが確認されました。
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// 干し草の山の後ろでパターンが一致するかどうかを確認します。
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// 一致する場合は、干し草の山の後ろからパターンを削除します。
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // 安全性: サフィックスが存在することが確認されました。
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// 双方向部分文字列サーチャー
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` に関連付けられたタイプ。
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // 空の針はすべての文字を拒否し、それらの間のすべての空の文字列に一致します
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher は、正しいマッチングを行い、干し草の山と針が有効である限り、char 境界で分割される有効な *Match* インデックスを生成します。UTF-8 アルゴリズムからの *拒否* は任意のインデックスに該当する可能性がありますが、手動で次の文字境界に移動します、utf-8 で安全になります。
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // 次の文字境界にスキップ
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` ケースと `false` ケースを書き出して、コンパイラーが 2 つのケースを別々に特殊化するように促します。
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // 次の文字境界にスキップ
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` のように `true` と `false` を書き出す
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// 双方向部分文字列検索アルゴリズムの内部状態。
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// 重要な因数分解指数
    crit_pos: usize,
    /// 逆針の臨界因数分解指数
    crit_pos_back: usize,
    period: usize,
    /// `byteset` 拡張機能です (双方向アルゴリズムの一部ではありません)。
    /// これは 64 ビットの "fingerprint" であり、各セットビット `j` は針に存在する (バイトと 63) ==j に対応します。
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// 前にすでに一致している針へのインデックス
    memory: usize,
    /// 針にインデックスを付けた後、すでに一致しています
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ここで何が起こっているかについての特に読みやすい説明は、Crochemore and Rytter の本 "Text Algorithms"、ch13 にあります。
        // 具体的には、"Algorithm CP" のコードを参照してください。
        // 323.
        //
        // 何が起こっているのかというと、針のいくつかの重要な因数分解 (u、v) があり、u が＆v [..period] の接尾辞であるかどうかを判別したいということです。
        // そうである場合は、"Algorithm CP1" を使用します。
        // それ以外の場合は、針の周期が長い場合に最適化された "Algorithm CP2" を使用します。
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // 短周期の場合 - 周期は正確であり、逆針の個別の臨界因数分解を計算します x=u'v ' ここで、| v' |<period(x)。
            //
            // これは、すでに知られている期間によってスピードアップされます。
            // x= "acba" のような場合は、正確に順方向に因数分解され (crit_pos=1、期間 = 3)、逆方向のおおよその期間で因数分解される (crit_pos=2、期間 = 2) ことに注意してください。
            // 与えられた逆因数分解を使用しますが、正確な期間を維持します。
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // 長期の場合 - 実際の期間の概算があり、暗記は使用しません。
            //
            //
            // 期間を下限 max(|u|, |v|) + 1 で概算します。
            // 重要な因数分解は、順方向検索と逆方向検索の両方に使用するのに効率的です。
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // 期間が長いことを示すダミー値
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Two-Way の主なアイデアの 1 つは、針を 2 つの半分 (u、v) に分解し、左から右にスキャンして干し草の山から v を見つけようとすることです。
    // v が一致する場合、右から左にスキャンして u を一致させようとします。
    // 不一致に遭遇したときにどこまでジャンプできるかは、すべて (u、v) が針の重要な因数分解であるという事実に基づいています。
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` をカーソルとして使用します
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // スライスが isize の範囲で囲まれていると仮定した場合、位置 + needle_last で検索する余地があることを確認してください。
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // サブストリングに関係のない大部分をすばやくスキップする
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // 針の右側が一致するかどうかを確認します
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // 針の左側が一致するかどうかを確認します
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // 一致するものが見つかりました!
            let match_pos = self.position;

            // Note: needle.len() の代わりに self.period を追加して、一致するものを重複させます
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // 重複する一致の場合は needle.len()、self.period に設定
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` のアイデアに従います。
    //
    // 定義は対称であり、period(x) = period(reverse(x)) および local_period(u, v) = local_period(reverse(v)、reverse(u)) であるため、(u、v) が重要な因数分解である場合、(reverse(v) も同様です。reverse(u)).
    //
    //
    // 逆の場合、臨界因数分解 x=u'v ' (フィールド `crit_pos_back`) を計算しました。| u | が必要です < フォワードケースの場合は period(x)、したがって | v '|< 逆の場合は period(x)。
    //
    // 干し草の山を逆に検索するには、最初に u '、次に v' に一致する、逆の針で逆の干し草の山を前方に検索します。
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` をカーソルとして使用するため、`next()` と `next_back()` は独立しています。
        //
        let old_end = self.end;
        'search: loop {
            // 最後に検索する余地があることを確認してください。needle.len() は余地がなくなると折り返されますが、スライスの長さの制限により、干し草の山の長さに戻ることはできません。
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // サブストリングに関係のない大部分をすばやくスキップする
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // 針の左側が一致するかどうかを確認します
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // 針の右側が一致するかどうかを確認します
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // 一致するものが見つかりました!
            let match_pos = self.end - needle.len();
            // Note: needle.len() の代わりにサブ self.period を使用して、一致を重複させます
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` の最大サフィックスを計算します。
    //
    // 最大の接尾辞は、`arr` の可能な重要な因数分解 (u、v) です。
    //
    // ( `i`、`p`) を返します。ここで、`i` は v の開始インデックスであり、`p` は v の期間です。
    //
    // `order_greater` 辞書式順序が `<` であるか `>` であるかを判別します。
    // 両方の次数を計算する必要があります。`i` が最大の順序は、重要な因数分解を提供します。
    //
    //
    // 長期間の場合、結果の期間は正確ではありません (短すぎます)。
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // 論文の i に対応
        let mut right = 1; // 論文の j に対応
        let mut offset = 0; // 論文の k に対応しますが、0 から始まります
        // 0 ベースのインデックスに一致します。
        let mut period = 1; // 論文の p に対応

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` の場合はインバウンドになります。
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // これまでのところ、サフィックスは小さく、ピリオドはプレフィックス全体です。
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // 現在の期間の繰り返しを通して進みます。
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // サフィックスが大きいので、現在の場所からやり直してください。
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` の逆の最大接尾辞を計算します。
    //
    // 最大の接尾辞は、`arr` の可能な重要な因数分解 (u '、v') です。
    //
    // `i` を返します。ここで、`i` は v ' の開始インデックスです。
    // `known_period` の期間に達するとすぐに戻ります。
    //
    // `order_greater` 辞書式順序が `<` であるか `>` であるかを判別します。
    // 両方の次数を計算する必要があります。`i` が最大の順序は、重要な因数分解を提供します。
    //
    //
    // 長期間の場合、結果の期間は正確ではありません (短すぎます)。
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // 論文の i に対応
        let mut right = 1; // 論文の j に対応
        let mut offset = 0; // 論文の k に対応しますが、0 から始まります
        // 0 ベースのインデックスに一致します。
        let mut period = 1; // 論文の p に対応
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // これまでのところ、サフィックスは小さく、ピリオドはプレフィックス全体です。
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // 現在の期間の繰り返しを通して進みます。
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // サフィックスが大きいので、現在の場所からやり直してください。
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy を使用すると、アルゴリズムは不一致をできるだけ早くスキップするか、拒否を比較的速く発行するモードで動作することができます。
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// できるだけ早く間隔を一致させるためにスキップします
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// 定期的に拒否を発行
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}