#![stable(feature = "core_hint", since = "1.27.0")]

//! コードの発行方法または最適化方法に影響を与えるコンパイラーへのヒント。
//! ヒントは、コンパイル時または実行時です。

use crate::intrinsics;

/// コードのこのポイントに到達できないことをコンパイラに通知し、さらに最適化できるようにします。
///
/// # Safety
///
/// この関数に到達することは、完全に *未定義の動作*(UB) です。特に、コンパイラーは、すべての UB が発生してはならないことを前提としているため、`unreachable_unchecked()` の呼び出しに到達するすべてのブランチを排除します。
///
/// UB のすべてのインスタンスと同様に、この仮定が間違っていることが判明した場合、つまり、`unreachable_unchecked()` 呼び出しがすべての可能な制御フローの中で実際に到達可能である場合、コンパイラは間違った最適化戦略を適用し、一見無関係に見えるコードを破損して、困難を引き起こす可能性があります - to - デバッグの問題。
///
///
/// この関数は、コードが決して呼び出さないことを証明できる場合にのみ使用してください。
/// それ以外の場合は、[`unreachable!`] マクロの使用を検討してください。これは最適化を許可しませんが、実行時に panic になります。
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` は常に正 (ゼロではない) であるため、`checked_div` が `None` を返すことはありません。
/////
///     // したがって、else branch には到達できません。
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // 安全性: `intrinsics::unreachable` の安全契約は
    // 発信者に支持されます。
    unsafe { intrinsics::unreachable() }
}

/// ビジーウェイトスピンループ (「スピンロック」) で実行されていることをプロセッサに通知するためのマシン命令を発行します。
///
/// スピンループ信号を受信すると、プロセッサは、たとえば、電力を節約したり、hyper スレッドを切り替えたりすることで、その動作を最適化できます。
///
/// この関数は、システムのスケジューラに直接譲る [`thread::yield_now`] とは異なりますが、`spin_loop` はオペレーティングシステムと対話しません。
///
/// `spin_loop` の一般的な使用例は、同期プリミティブの CAS ループに制限付きの楽観的スピニングを実装することです。
/// 優先順位の反転などの問題を回避するために、有限の反復回数の後にスピンループを終了し、適切なブロッキング syscall を実行することを強くお勧めします。
///
///
/// **注**: スピンループヒントの受信をサポートしていないプラットフォームでは、この関数は何もしません。
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // スレッドが調整に使用する共有アトミック値
/// let live = Arc::new(AtomicBool::new(false));
///
/// // バックグラウンドスレッドでは、最終的に値を設定します
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // いくつかの作業を行ってから、価値を生かしてください
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // 現在のスレッドに戻り、値が設定されるのを待ちます
/// while !live.load(Ordering::Acquire) {
///     // スピンループは、私たちが待っている CPU へのヒントですが、おそらくそれほど長くはありません
/////
///     hint::spin_loop();
/// }
///
/// // これで値が設定されました
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // 安全性: `cfg` 属性は、x86 ターゲットでのみこれを実行することを保証します。
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // 安全性: `cfg` 属性は、x86_64 ターゲットでのみこれを実行することを保証します。
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // 安全性: `cfg` 属性は、aarch64 ターゲットでのみこれを実行することを保証します。
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // 安全性: `cfg` 属性は、これをアームターゲットでのみ実行することを保証します
            // v6 機能のサポート付き。
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// `black_box` で何ができるかについて最大限に悲観的になるようにコンパイラーに *__ヒント__* する恒等関数。
///
/// [`std::convert::identity`] とは異なり、Rust コンパイラは、呼び出し元のコードに未定義の動作を導入することなく、`black_box` が Rust コードで許可されている有効な方法で `dummy` を使用できると想定することをお勧めします。
///
/// このプロパティにより、`black_box` は、ベンチマークなど、特定の最適化が望ましくないコードの記述に役立ちます。
///
/// ただし、`black_box` は "best-effort" ベースでのみ提供される (および提供される可能性がある) ことに注意してください。最適化をブロックできる範囲は、使用するプラットフォームとコード生成バックエンドによって異なる場合があります。
/// プログラムは、`black_box` に *正確さ* を依存することはできません。
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // LLVM がイントロスペクトできない方法で引数を "use" する必要があり、それをサポートするターゲットでは、通常、インラインアセンブリを利用してこれを行うことができます。
    // インラインアセンブリの LLVM の解釈は、それがブラックボックスであるということです。
    // これはおそらく私たちが望む以上に最適化を解除するため、最高の実装ではありませんが、これまでのところ十分です。
    //
    //

    #[cfg(not(miri))] // これは単なるヒントなので、Miri ではスキップしても問題ありません。
    // 安全性: インラインアセンブリはノーオペレーションです。
    unsafe {
        // FIXME: MIPS およびその他のアーキテクチャをサポートしていないため、`asm!` は使用できません。
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}