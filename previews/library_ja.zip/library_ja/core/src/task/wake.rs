#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` を使用すると、タスクエグゼキュータの実装者は、カスタマイズされたウェイクアップ動作を提供する [`Waker`] を作成できます。
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// これは、データポインタと `RawWaker` の動作をカスタマイズする [virtual function pointer table (vtable)][vtable] で構成されています。
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// エグゼキュータの必要に応じて任意のデータを格納するために使用できるデータポインタ。
    /// これは例えば
    /// タスクに関連付けられている `Arc` への型消去されたポインター。
    /// このフィールドの値は、最初のパラメーターとして vtable の一部であるすべての関数に渡されます。
    ///
    data: *const (),
    /// このウェイカーの動作をカスタマイズする仮想関数ポインターテーブル。
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// 提供された `data` ポインターと `vtable` から新しい `RawWaker` を作成します。
    ///
    /// `data` ポインターは、エグゼキューターの必要に応じて任意のデータを格納するために使用できます。これは例えば
    /// タスクに関連付けられている `Arc` への型消去されたポインター。
    /// このポインターの値は、最初のパラメーターとして `vtable` の一部であるすべての関数に渡されます。
    ///
    /// `vtable` は、`RawWaker` から作成される `Waker` の動作をカスタマイズします。
    /// `Waker` での操作ごとに、基になる `RawWaker` の `vtable` 内の関連する関数が呼び出されます。
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// [`RawWaker`] の動作を指定する仮想関数ポインタテーブル (vtable)。
///
/// vtable 内のすべての関数に渡されるポインターは、囲んでいる [`RawWaker`] オブジェクトからの `data` ポインターです。
///
/// この構造体内の関数は、[`RawWaker`] 実装内から適切に構築された [`RawWaker`] オブジェクトの `data` ポインターでのみ呼び出されることを目的としています。
/// 他の `data` ポインターを使用して、含まれている関数の 1 つを呼び出すと、未定義の動作が発生します。
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// この関数は、[`RawWaker`] が複製されたとき、たとえば [`RawWaker`] が格納されている [`Waker`] が複製されたときに呼び出されます。
    ///
    /// この関数の実装は、[`RawWaker`] のこの追加インスタンスおよび関連タスクに必要なすべてのリソースを保持する必要があります。
    /// 結果の [`RawWaker`] で `wake` を呼び出すと、元の [`RawWaker`] によって起こされたのと同じタスクがウェイクアップするはずです。
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// この関数は、[`Waker`] で `wake` が呼び出されたときに呼び出されます。
    /// この [`RawWaker`] に関連付けられているタスクをウェイクアップする必要があります。
    ///
    /// この関数の実装では、[`RawWaker`] のこのインスタンスおよび関連するタスクに関連付けられているすべてのリソースを必ず解放する必要があります。
    ///
    ///
    wake: unsafe fn(*const ()),

    /// この関数は、[`Waker`] で `wake_by_ref` が呼び出されたときに呼び出されます。
    /// この [`RawWaker`] に関連付けられているタスクをウェイクアップする必要があります。
    ///
    /// この関数は `wake` に似ていますが、提供されたデータポインターを消費してはなりません。
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// この関数は、[`RawWaker`] がドロップされたときに呼び出されます。
    ///
    /// この関数の実装では、[`RawWaker`] のこのインスタンスおよび関連するタスクに関連付けられているすべてのリソースを必ず解放する必要があります。
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// 提供されている `clone`、`wake`、`wake_by_ref`、および `drop` 関数から新しい `RawWakerVTable` を作成します。
    ///
    /// # `clone`
    ///
    /// この関数は、[`RawWaker`] が複製されたとき、たとえば [`RawWaker`] が格納されている [`Waker`] が複製されたときに呼び出されます。
    ///
    /// この関数の実装は、[`RawWaker`] のこの追加インスタンスおよび関連タスクに必要なすべてのリソースを保持する必要があります。
    /// 結果の [`RawWaker`] で `wake` を呼び出すと、元の [`RawWaker`] によって起こされたのと同じタスクがウェイクアップするはずです。
    ///
    /// # `wake`
    ///
    /// この関数は、[`Waker`] で `wake` が呼び出されたときに呼び出されます。
    /// この [`RawWaker`] に関連付けられているタスクをウェイクアップする必要があります。
    ///
    /// この関数の実装では、[`RawWaker`] のこのインスタンスおよび関連するタスクに関連付けられているすべてのリソースを必ず解放する必要があります。
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// この関数は、[`Waker`] で `wake_by_ref` が呼び出されたときに呼び出されます。
    /// この [`RawWaker`] に関連付けられているタスクをウェイクアップする必要があります。
    ///
    /// この関数は `wake` に似ていますが、提供されたデータポインターを消費してはなりません。
    ///
    /// # `drop`
    ///
    /// この関数は、[`RawWaker`] がドロップされたときに呼び出されます。
    ///
    /// この関数の実装では、[`RawWaker`] のこのインスタンスおよび関連するタスクに関連付けられているすべてのリソースを必ず解放する必要があります。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// 非同期タスクの `Context`。
///
/// 現在、`Context` は、現在のタスクをウェイクアップするために使用できる `&Waker` へのアクセスを提供するためにのみ機能します。
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ライフタイムを不変にすることにより、分散の変化に対して future の証明を確実にします (引数位置のライフタイムは反変であり、リターン位置のライフタイムは共変です)。
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker` から新しい `Context` を作成します。
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// 現在のタスクの `Waker` への参照を返します。
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` は、実行の準備ができていることをエグゼキュータに通知することにより、タスクをウェイクアップするためのハンドルです。
///
/// このハンドルは、エグゼキュータ固有のウェイクアップ動作を定義する [`RawWaker`] インスタンスをカプセル化します。
///
///
/// [`Clone`]、[`Send`]、および [`Sync`] を実装します。
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// この `Waker` に関連付けられているタスクをウェイクアップします。
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // 実際のウェイクアップ呼び出しは、仮想関数呼び出しを介して、エグゼキュータによって定義された実装に委任されます。
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` を呼び出さないでください - ウェイカーは `wake` によって消費されます。
        crate::mem::forget(self);

        // 安全性: `Waker::from_raw` が唯一の方法であるため、これは安全です
        // `wake` および `data` を初期化するには、ユーザーが `RawWaker` の契約が守られていることを確認する必要があります。
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` を消費せずに、この `Waker` に関連付けられたタスクをウェイクアップします。
    ///
    /// これは `wake` に似ていますが、所有している `Waker` が使用可能な場合、効率が少し低下する可能性があります。
    /// このメソッドは、`waker.clone().wake()` を呼び出すよりも優先する必要があります。
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // 実際のウェイクアップ呼び出しは、仮想関数呼び出しを介して、エグゼキュータによって定義された実装に委任されます。
        //

        // 安全性: `wake` を参照
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// この `Waker` と別の `Waker` が同じタスクを起動した場合、`true` を返します。
    ///
    /// この関数はベストエフォートベースで機能し、`Waker` が同じタスクを起動する場合でも false を返す場合があります。
    /// ただし、この関数が `true` を返す場合、`Waker` が同じタスクを起動することが保証されます。
    ///
    /// この関数は、主に最適化の目的で使用されます。
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] から新しい `Waker` を作成します。
    ///
    /// [`RawWaker`] および [`RawWakerVTable`] のドキュメントで定義されているコントラクトがサポートされていない場合、返される `Waker` の動作は未定義です。
    ///
    /// したがって、この方法は安全ではありません。
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // 安全性: `Waker::from_raw` が唯一の方法であるため、これは安全です
            // `clone` および `data` を初期化するには、ユーザーが [`RawWaker`] の契約が守られていることを確認する必要があります。
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // 安全性: `Waker::from_raw` が唯一の方法であるため、これは安全です
        // `drop` および `data` を初期化するには、ユーザーが `RawWaker` の契約が守られていることを確認する必要があります。
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}