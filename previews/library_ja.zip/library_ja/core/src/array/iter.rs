//! `IntoIter` が所有する配列のイテレータを定義します。

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// 値による [array] イテレータ。
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// これは、繰り返し処理する配列です。
    ///
    /// `alive.start <= i < alive.end` がまだ生成されておらず、有効な配列エントリであるインデックス `i` の要素。
    /// インデックスが `i < alive.start` または `i >= alive.end` の要素はすでに生成されているため、アクセスしないでください。それらの死んだ要素は完全に初期化されていない状態にあるかもしれません!
    ///
    ///
    /// したがって、不変条件は次のとおりです。
    /// - `data[alive]` 生きている (つまり、有効な要素が含まれている)
    /// - `data[..alive.start]` と `data[alive.end..]` は死んでいます (つまり、要素はすでに読み取られているので、もう触れてはいけません! )
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// まだ生成されていない `data` の要素。
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// 指定された `array` 上に新しいイテレータを作成します。
    ///
    /// *注*: このメソッドは、[`IntoIterator` is implemented for arrays][array-into-iter] 以降の future で非推奨になる可能性があります。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` のタイプは、ここでは `&i32` ではなく `i32` です。
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // 安全性: ここでの核変換は実際には安全です。`MaybeUninit` のドキュメント
        // promise:
        //
        // > `MaybeUninit<T>` 同じサイズと配置であることが保証されています
        // > `T` として。
        //
        // ドキュメントには、`MaybeUninit<T>` の配列から `T` の配列への変換も示されています。
        //
        //
        // これにより、この初期化は不変条件を満たします。

        // FIXME(LukasKalbertodt): const ジェネリックで動作するようになったら、実際にここで `mem::transmute` を使用します。
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // それまでは、`mem::transmute_copy` を使用して別のタイプとしてビット単位のコピーを作成し、`array` を忘れてドロップされないようにすることができます。
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// まだ生成されていないすべての要素の不変スライスを返します。
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // 安全性: `alive` 内のすべての要素が適切に初期化されていることがわかっています。
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// まだ生成されていないすべての要素の可変スライスを返します。
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // 安全性: `alive` 内のすべての要素が適切に初期化されていることがわかっています。
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // 正面から次のインデックスを取得します。
        //
        // `alive.start` を 1 増やすと、`alive` に関する不変条件が維持されます。
        // ただし、この変更により、しばらくの間、アライブゾーンは `data[alive]` ではなく `data[idx..alive.end]` になります。
        //
        self.alive.next().map(|idx| {
            // 配列から要素を読み取ります。
            // 安全性: `idx` は、の以前の "alive" 領域へのインデックスです。
            // アレイ。この要素を読み取ることは、`data[idx]` が現在死んでいると見なされることを意味します (つまり、触れないでください)。
            // `idx` がアライブゾーンの始まりだったので、アライブゾーンは再び `data[alive]` になり、すべての不変条件が復元されます。
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // 後ろから次のインデックスを取得します。
        //
        // `alive.end` を 1 減らすと、`alive` に関する不変条件が維持されます。
        // ただし、この変更により、しばらくの間、アライブゾーンは `data[alive]` ではなく `data[alive.start..=idx]` になります。
        //
        self.alive.next_back().map(|idx| {
            // 配列から要素を読み取ります。
            // 安全性: `idx` は、の以前の "alive" 領域へのインデックスです。
            // アレイ。この要素を読み取ることは、`data[idx]` が現在死んでいると見なされることを意味します (つまり、触れないでください)。
            // `idx` がアライブゾーンの終わりだったので、アライブゾーンは再び `data[alive]` になり、すべての不変条件が復元されます。
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // 安全性: これは安全です: `as_mut_slice` は正確にサブスライスを返します
        // まだ移動されておらず、削除されたままの要素の数。
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // 不変の `alive.start <= のため、アンダーフローすることはありません
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// イテレータは確かに正しい長さを報告します。
// "alive" 要素の数 (引き続き生成されます) は、範囲 `alive` の長さです。
// この範囲は、`next` または `next_back` のいずれかで長さが減少します。
// これらのメソッドでは常に 1 ずつデクリメントされますが、`Some(_)` が返される場合に限ります。
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // 完全に同じ生存範囲に一致する必要はないため、`self` がどこにあるかに関係なく、オフセット 0 にクローンを作成できることに注意してください。
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // 生きているすべての要素のクローンを作成します。
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // 新しいアレイにクローンを書き込み、その存続範囲を更新します。
            // panics のクローンを作成する場合、前のアイテムを正しく削除します。
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // まだ生成されていない要素のみを出力します。生成された要素にはアクセスできなくなります。
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}