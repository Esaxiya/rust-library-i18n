//! これは、ifmt! によって使用される内部モジュールです。ランタイム。これらの構造体は静的配列に出力され、フォーマット文字列を事前にプリコンパイルします。
//!
//! これらの定義は、同等の `ct` に似ていますが、静的に割り当てることができ、ランタイム用にわずかに最適化されているという点で異なります。
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// 書式設定ディレクティブの一部として要求できる可能な配置。
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// 内容を左揃えにする必要があることを示します。
    Left,
    /// 内容を右揃えにする必要があることを示します。
    Right,
    /// コンテンツを中央揃えにする必要があることを示します。
    Center,
    /// 調整は要求されませんでした。
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) および [precision](https://doc.rust-lang.org/std/fmt/#precision) 指定子によって使用されます。
#[derive(Copy, Clone)]
pub enum Count {
    /// リテラル番号で指定され、値を格納します
    Is(usize),
    /// `$` および `*` 構文を使用して指定され、インデックスを `args` に格納します
    Param(usize),
    /// 指定されていない
    Implied,
}