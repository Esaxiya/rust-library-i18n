use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // ミリは遅すぎる
fn exact_sanity_test() {
    // このテストは、使用している C ランタイムで定義されている `exp2` ライブラリ関数のちょっとしたケースであると私が推測できるものを実行することになります。
    // VS 2013 では、リンクするとこのテストが失敗するため、この関数には明らかにバグがありましたが、VS 2015 では、テストが正常に実行されるため、バグが修正されたように見えます。
    //
    // バグは `exp2(-1057)` の戻り値の違いのようです。ここで、VS 2013 ではビットパターン 0x2 で double を返し、VS2015 では 0x20000 を返します。
    //
    //
    // とにかく他の場所でテストされており、各プラットフォームの exp2 実装をテストすることにあまり関心がないため、今のところ、MSVC でこのテストを完全に無視してください。
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}