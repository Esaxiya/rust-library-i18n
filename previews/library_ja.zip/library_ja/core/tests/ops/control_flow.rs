use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // これは安定した表面積ではありませんが、LLVM が現在常にそれを利用できるとは限らない場合でも、`?` をそれらの間で安価に保つのに役立ちます。
    //
    // (残念ながら、結果とオプションに一貫性がないため、ControlFlow は両方に一致することはできません。)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}