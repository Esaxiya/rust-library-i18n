`core::arch` - perpustakaan core intrinsics arsitektur-spésifik Rust urang
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` nerapkeun intrinsik gumantung arsitektur (contona SIMD).

# Usage 

`core::arch` geus sadia sakumaha bagian tina `libcore` sarta biasa ulang diékspor ku `libstd`.Resep nganggo ngalangkungan `core::arch` atanapi `std::arch` tibatan ngalangkungan crate ieu.
Fitur anu henteu stabil sering sayogi dina wengi Rust ngalangkungan `feature(stdsimd)`.

Ngagunakeun `core::arch` ngalangkungan crate ieu meryogikeun nightly Rust, sareng éta tiasa (sareng henteu) sering rusak.Hiji-hijina kasus anu anjeun kedah nimbangkeun ngalangkunganana ngalangkungan crate ieu nyaéta:

* upami anjeun kedah nyusun deui `core::arch` nyalira, contona, ku fitur-target khusus diaktipkeun anu henteu diaktipkeun pikeun `libcore`/`libstd`.
Note: upami anjeun kedah nyusun deui pikeun target anu teu standar, punten langkung resep nganggo `xargo` sareng nyusun deui `libcore`/`libstd` sakumaha pantes tibatan nganggo crate ieu.
  
* ngagunakeun sababaraha fitur anu bisa jadi teu sadia malah balik stabil Rust pitur.Urang coba tetep ieu ka minimum a.
Lamun perlu make sababaraha fitur ieu, mangga buka hiji masalah ku kituna urang tiasa ngalaan éta di nightly Rust jeung anjeun bisa make eta ti dinya.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` Utamana disebarkeun dina kaayaan lisénsi MIT sareng Lisénsi Apache (Versi 2.0), kalayan bagian anu ditutupan ku sababaraha lisénsi sapertos BSD.

Tingali LICENSE-APACHE, sareng LICENSE-MIT pikeun detil.

# Contribution

Iwal mun kuduna kaayaan disebutkeun, sagala kontribusi ngahaja dikintunkeun keur citakan dina `core_arch` ku anjeun, sakumaha didefinisikeun dina Apache-2.0 lisénsi, bakal jadi dual dilisensikeun sakumaha di luhur, tanpa wae istilah atawa kaayaan tambahan.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












