use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Dipaké pikeun ngabejaan annotations `#[assert_instr]` urang nu kabéh intrinsics simd nu sadia pikeun nguji codegen maranéhanana, saprak sababaraha anu gated tukangeun hiji `-Ctarget-feature=+unimplemented-simd128` tambahan nu teu ngagaduhan sarimbag dina `#[target_feature]` ayeuna.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}