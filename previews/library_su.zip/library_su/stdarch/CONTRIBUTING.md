# Nyumbang ka stdarch

`stdarch` crate langkung daék narima sumbangan!Mimiti anjeun sigana bakal hoyong parios gudang sareng pastikeun tés lulus pikeun anjeun:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Dimana `<your-target-arch>` mangrupikeun triple target sapertos anu dianggo ku `rustup`, misal `x86_x64-unknown-linux-gnu` (tanpa `nightly-` sateuacanna atanapi anu sami).
Ogé inget yen Repository ieu merlukeun saluran nightly of Rust!
The tés luhur ngalakukeun dina kanyataanana merlukeun nightly rust jadi standar dina Sistim anjeun, pikeun nyetél éta pamakéan `rustup default nightly` (jeung `rustup default stable` dibalikkeun).

Upami salah sahiji léngkah di luhur henteu jalan, [please let us know][new]!

Salajengna anjeun tiasa [find an issue][issues] pikeun ngabantosan, kami parantos milih sababaraha tag [`help wanted`][help] sareng [`impl-period`][impl] anu khususna tiasa nganggo sababaraha bantosan. 
Anjeun panginten paling resep kana [#40][vendor], nerapkeun sadaya instrinsik vendor dina x86.Anu ngaluarkeun urang ngagaduhan sababaraha pointers alus ngeunaan dimana ngamimitian!

Lamun saena patarosan umum ngarasa Luncat ka [join us on gitter][gitter] jeung nanya sabudeureun!Ngarasa Luncat ka ping boh@BurntSushi atanapi@alexcrichton kalayan patarosan.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cara nulis conto pikeun intrinsics stdarch

Aya sababaraha ciri nu kudu diaktipkeun keur intrinsik dibikeun ka karya leres tur conto nu kedah ngan bisa dijalankeun ku `cargo test --doc` nalika fitur kasebut dirojong ku CPU dina.

Hasilna, dina standar `fn main` nu dihasilkeun ku `rustdoc` iyeu moal jalan mun (di hal nu ilahar).
Pertimbangkeun ngagunakeun ieu salaku pitunjuk pikeun mastikeun conto anjeun tiasa dianggo sapertos anu diarepkeun.

```rust
/// # // Urang peryogi cfg_target_feature pikeun mastikeun conto na waé
/// # // dijalankeun ku `cargo test --doc` nalika CPU nu ngarojong fitur nu
/// # #![feature(cfg_target_feature)]
/// # // Urang peryogi target_fitur kanggo intrinsik jalan
/// # #![feature(target_feature)]
/// #
/// # // rustdoc sacara standar nganggo `extern crate stdarch`, tapi urang peryogi
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Fungsi utama nyata
/// # fn main() {
/// #     // Ngan ngajalankeun ieu upami `<target feature>` dirojong
/// #     lamun cfg_feature_enabled! ("<target feature>"){
/// #         // Ngadamel fungsi `worker` anu ngan bakal dijalankeun upami fitur target
/// #         // ieu dirojong jeung mastikeun yén `target_feature` diaktipkeun pikeun worker Anjeun
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         unsafe FN worker() {
/// // Tulis conto anjeun didieu.intrinsics fitur husus bakal dianggo didieu!Buka liar!
///
/// #         }
///
/// #         unsafe { worker(); }
/// #     }
/// # }
```

Upami sababaraha sintaksis di luhur henteu katingal biasa, bagian [Documentation as tests] tina [Rust Book] ngajelaskeun sintaksis `rustdoc` rada saé.
Salaku salawasna, ngarasa bébas [join us on gitter][gitter] jeung nanya kami lamun pencét snags wae, sareng hatur nuhun pikeun nulungan pikeun ngaronjatkeun dokuméntasi tina `stdarch`!

# Parentah Pangujian Alternatip

Hal ieu umumna Dianjurkeun yén Anjeun ngagunakeun `ci/run.sh` kana ngajalankeun tés.
Nanging ieu panginten tiasa dianggo pikeun anjeun, misal upami anjeun nganggo Windows.

Bisi nu bisa digolongkeun deui ngajalankeun `cargo +nightly test` na `cargo +nightly test --release -p core_arch` pikeun nguji generasi kode.
Catet yén ieu meryogikeun toolchain wengi kanggo dipasang sareng kanggo `rustc` terang ngeunaan target triple sareng CPU na.
Hususna nu kudu nangtukeun variabel lingkungan `TARGET` Anjeun ngalakukeunana pikeun `ci/run.sh`.
Salaku tambahan anjeun kedah nyetél `RUSTCFLAGS` (peryogi `C`) kanggo nunjukkeun fitur target, misal `RUSTCFLAGS="-C -target-features=+avx2"`.
Anjeun oge tiasa nyetel `-C -target-cpu=native` lamun nuju "just" ngembang ngalawan CPU anjeun ayeuna.

Jadi miélingkeun yén mun anjeun migunakeun ieu parentah alternatif, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], misalna
tés generasi instruksi tiasa gagal kusabab anu ngabongkar namina béda-béda, misal
éta tiasa ngahasilkeun `vaesenc` tibatan paréntah `aesenc` sanaos aranjeunna sami-sami polah.
Ogé pitunjuk ieu ngaéksekusi langkung kirang tés tibatan biasana bakal dilakukeun, janten entong héran nalika pamustunganana narik-pamundut sababaraha kasalahan tiasa muncul pikeun tés anu teu katutupan di dieu.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






