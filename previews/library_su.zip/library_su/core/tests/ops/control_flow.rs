use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ieu henteu stabil permukaan, tapi ngabantosan `?` tetep mirah di antawisna, sanaos LLVM henteu tiasa teras ngamangpaatkeun éta ayeuna.
    //
    // (Sedih hasilna tur Pilihan anu inconsistent, jadi ControlFlow teu cocog duanana.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}