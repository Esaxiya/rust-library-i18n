use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri lambat teuing
fn exact_sanity_test() {
    // Tés ieu tungtungna ngajalankeun naon anu kuring ukur tiasa anggap nyaéta sababaraha sudut sudut fungsi perpustakaan `exp2`, ditetepkeun dina naon waé C runtime anu kami anggo.
    // Dina bobodoran 2013 fungsi ieu tétéla miboga bug minangka uji ieu gagal lamun dikaitkeun, tapi kalawan bobodoran 2015 bug nu nembongan dibereskeun salaku tes ngalir ngan rupa.
    //
    // Bug éta sigana bédana dina nilai balikna `exp2(-1057)`, dimana di VS 2013 éta mulih ganda sareng pola bit 0x2 sareng di VS 2015 éta mulih 0x20000.
    //
    //
    // Pikeun ayeuna ngan ukur teu malire tés ieu sacara lengkep dina MSVC sabab éta diuji di tempat sanésna sareng kami henteu resep pisan nguji palaksanaan exp2 unggal platform.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}