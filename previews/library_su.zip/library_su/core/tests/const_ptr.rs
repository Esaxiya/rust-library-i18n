// Blok kana dua bait
const DATA: [u16; 2] = [u16::from_ne_bytes([0x01, 0x23]), u16::from_ne_bytes([0x45, 0x67])];

const fn unaligned_ptr() -> *const u16 {
    // Kusabab DATA.as_ptr() dijejerankeun ka dua bait, nambihan 1 bait kana anu ngahasilkeun * const u16 anu henteu dijantenkeun
    unsafe { (DATA.as_ptr() as *const u8).add(1) as *const u16 }
}

#[test]
fn read() {
    use core::ptr;

    const FOO: i32 = unsafe { ptr::read(&42 as *const i32) };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { ptr::read_unaligned(&42 as *const i32) };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { ptr::read_unaligned(UNALIGNED_PTR) };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn const_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *const u16 = unaligned_ptr();

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

#[test]
fn mut_ptr_read() {
    const FOO: i32 = unsafe { (&42 as *const i32 as *mut i32).read() };
    assert_eq!(FOO, 42);

    const ALIGNED: i32 = unsafe { (&42 as *const i32 as *mut i32).read_unaligned() };
    assert_eq!(ALIGNED, 42);

    const UNALIGNED_PTR: *mut u16 = unaligned_ptr() as *mut u16;

    const UNALIGNED: u16 = unsafe { UNALIGNED_PTR.read_unaligned() };
    assert_eq!(UNALIGNED, u16::from_ne_bytes([0x23, 0x45]));
}

// #[test]
// FN write() {pamakéan core::ptr;
//
//    const fn write_aligned()-> i32 {hayu mut res=0;
//        teu aman {
//            ptr::write(&mut res as *mut _, 42);
//        }
//        res} const Blok: i32 = write_aligned();
//    negeskeun_eq! (DIKASARKEUN, 42);
//
//    const FN write_unaligned()-> [u16; 2] {hayu mut two_aligned= [0u16; 2];
//        teu aman {let unaligned_ptr= (two_aligned.as_mut_ptr() as *mut u8).add(1) as* mut u16;
//            ptr: : write_unaligned (unaligned_ptr, u16::from_ne_bytes([0x23, 0x45]));} two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//

// #[test]
// fn mut_ptr_write() {const fn aligned()-> i32 {hayu mut res=0;
//        unsafe { (&mut res as *mut i32).write(42); } res} const Blok: i32 = aligned();
//
//    negeskeun_eq! (DIKASARKEUN, 42);
//
//    const FN write_unaligned()-> [u16; 2] {hayu mut two_aligned= [0u16; 2];
//        teu aman {let unaligned_ptr= (two_aligned.as_mut_ptr() as *mut u8).add(1) as* mut u16;
//            unaligned_ptr.write_unaligned(u16::from_ne_bytes([0x23, 0x45]));
//        }
//        two_aligned} const UNALIGNED: [u16; 2] = write_unaligned();
//    assert_eq! (UNALIGNED, [u16::from_ne_bytes([0x00, 0x23]), u16::from_ne_bytes([0x45, 0x00])]);}
//
//
//
//
//
//
//
//
//
//
//