//! `Clone` trait pikeun jinis anu teu tiasa 'disalin sacara implisit'.
//!
//! Dina Rust, sababaraha jinis saderhana nyaéta "implicitly copyable" sareng nalika anjeun napelkeun atanapi ngalirkeunana salaku alesan, panarima bakal kéngingkeun salinan, ningalkeun nilai aslina dina tempatna.
//! jenis ieu teu merlukeun alokasi pikeun nyalin jeung teu boga finalizers (ie, aranjeunna teu ngandung buleud milik atawa nerapkeun [`Drop`]), sahingga compiler anu ngemutan aranjeunna mirah tur aman nyalin.
//!
//! Kanggo jinis sanés salinan kedah dilakukeun sacara jelas, ku konvénsi ngalaksanakeun [`Clone`] trait sareng nyauran metode [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! pamakéan dasar conto:
//!
//! ```
//! let s = String::new(); // Jenis senar ngalaksanakeun Klon
//! let copy = s.clone(); // sahingga urang tiasa dikloningkeun
//! ```
//!
//! Pikeun gampang ngalaksanakeun Clone trait, anjeun ogé tiasa nganggo `#[derive(Clone)]`.Conto:
//!
//! ```
//! #[derive(Clone)] // urang tambahkeun Klon trait ka Morpheus strukt
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // tur ayeuna urang tiasa clone dinya!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait umum pikeun kamampuan pikeun eksplisit ngaduplikasi obyék.
///
/// Béda ti [`Copy`] dina [`Copy`] anu implisit sareng murah pisan, sedengkeun `Clone` sok jelas sareng meureun atanapi henteu mahal.
/// Dina raraga ngalaksanakeun ciri-ciri ieu, Rust henteu ngijinkeun anjeun ngalaksanakeun deui [`Copy`], tapi anjeun tiasa ngalaksanakeun `Clone` sareng ngajalankeun kode sawenang-wenang.
///
/// Kusabab `Clone` langkung umum tibatan [`Copy`], anjeun sacara otomatis tiasa ngadamel naon waé [`Copy`] janten `Clone` ogé.
///
/// ## Derivable
///
/// trait ieu tiasa dianggo nganggo `#[derive]` upami sadaya bidang `Clone`.Palaksanaan `turunan`d [`Clone`] nyaéta panggero [`clone`] dina unggal lapangan.
///
/// [`clone`]: Clone::clone
///
/// Pikeun struct generik, `#[derive]` implements `Clone` conditionally ku nambahkeun kabeungkeut `Clone` on parameter generik.
///
/// ```
/// // `derive` ngalaksanakeun Klon kanggo Maca<T>nalika T nyaéta Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kumaha kuring tiasa nerapkeun `Clone`?
///
/// Jenis anu [`Copy`] kedah ngagaduhan implementasi sepele `Clone`.Langkung resmi:
/// lamun `T: Copy`, `x: T`, sarta `y: &T`, teras `let x = y.clone();` sarua jeung `let x = *y;`.
/// Palaksanaan manual kedah ati-ati pikeun ngajagaan invariant ieu;kumaha oge, kode unsafe teu kudu ngandelkeun deui pikeun mastikeun kasalametan memori.
///
/// Conto mangrupikeun struktur generik anu nyekel pointer fungsi.Dina hal ieu, palaksanaan `Clone` henteu tiasa `diturunkeun`d, tapi tiasa dilaksanakeun salaku:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Palaksana tambahan
///
/// Salaku tambahan kana [implementors listed below][impls], jinis-jinis ieu ogé nerapkeun `Clone`:
///
/// * jenis fungsi item (ie, jenis béda diartikeun pikeun tiap fungsi)
/// * Fungsi pointer (sapertos, `fn() -> i32`)
/// * Jenis Array, pikeun sadaya ukuran, upami jinis barang ogé ngalaksanakeun `Clone` (misal, `[i32; 123456]`)
/// * Jenis tuple, upami masing-masing komponén ogé ngalaksanakeun `Clone` (misal, `()`, `(i32, bool)`)
/// * Jenis panutupan, upami aranjeunna henteu néwak nilai tina lingkungan atanapi upami sadaya nilai anu dicandak sapertos nerapkeun `Clone` nyalira.
///   Catetan yen variabel direbut ku rujukan dibagikeun salawasna nerapkeun `Clone` (sanajan referent nu henteu), bari variabel direbut ku rujukan mutable pernah nerapkeun `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Mulih salinan tina nilai nu.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ngalaksanakeun Klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Ngajalankeun salinan-ngerjakeun ti `source`.
    ///
    /// `a.clone_from(&b)` sarimbag sareng `a = b.clone()` dina fungsionalitas, tapi tiasa ditimpa pikeun nganggo deui sumber daya `a` pikeun nyingkahan alokasi anu teu perlu.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Nurunkeun makro ngahasilkeun impl tina trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): strukturna ieu dianggo ngan ukur ku#[nurunkeun] pikeun negeskeun yén unggal komponén jinis ngalaksanakeun Klon atanapi Salin.
//
//
// structs ieu kedah pernah muncul dina kode pamaké.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Palaksanaan `Clone` pikeun jinis primitif.
///
/// Palaksanaan anu teu tiasa dijelaskeun dina Rust dilaksanakeun di `traits::SelectionContext::copy_clone_conditions()` dina `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// rujukan dibagikeun bisa diklon, tapi rujukan mutable *teu bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// rujukan dibagikeun bisa diklon, tapi rujukan mutable *teu bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}