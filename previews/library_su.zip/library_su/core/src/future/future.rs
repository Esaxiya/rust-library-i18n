#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future ngagambarkeun komputasi anu teu sinkron.
///
/// future mangrupikeun nilai anu teu acan réngsé réngsé komputasi.
/// "asynchronous value" jenis ieu ngamungkinkeun pikeun utas pikeun neraskeun padamelan anu mangpaat bari ngantosan nilaina janten sayogi.
///
///
/// # Metodeu `poll`
///
/// Metode inti future, `poll`,*nyobian* pikeun ngarengsekeun future kana nilai akhir.
/// Cara ieu henteu ngahalangan upami nilaina henteu siap.
/// Sabalikna, tugas anu ayeuna dijadwalkeun dihudangkeun nalika dimungkinkeun pikeun maju deui ku `polling` deui.
/// The `context` diliwatan kana metoda `poll` bisa méré [`Waker`], nu mangrupakeun cecekelan pikeun bangun up tugas ayeuna.
///
/// Lamun maké future, anjeun umum moal nelepon `poll` langsung, tapi gantina `.await` nilai.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Jenis nilai anu dihasilkeun saatos parantosan.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Nyobian ngabéréskeun nu future ka nilai ahir, ngadaptar tugas ayeuna keur wakeup lamun nilai nu teu acan aya.
    ///
    /// # Nilai balik
    ///
    /// Pungsi ieu mulih:
    ///
    /// - [`Poll::Pending`] upami future teu acan siap
    /// - [`Poll::Ready(val)`] kalayan hasil `val` tina future ieu upami réngsé hasil.
    ///
    /// Sakali a future parantos réngsé, klien henteu kedah `poll` deui.
    ///
    /// Nalika future teu acan siap, `poll` mulih `Poll::Pending` sareng nyimpen klon [`Waker`] anu disalin ti [`Context`] ayeuna.
    /// [`Waker`] ieu teras dihudangkeun sakali future tiasa maju.
    /// Salaku conto, future ngantosan stop kontak janten tiasa dibaca bakal nyauran `.clone()` dina [`Waker`] sareng nyimpenna.
    /// Nalika sinyal dugi ka tempat sanés anu nunjukkeun yén stop kontak tiasa dibaca, [`Waker::wake`] disebat sareng tugas stop kontak future dihudangkeun.
    /// Sakali tugas parantos gugah, éta kedah nyobian `poll` future deui, anu tiasa atanapi henteu ngahasilkeun nilai akhir.
    ///
    /// Catet yén dina sababaraha telepon kana `poll`, ngan [`Waker`] ti [`Context`] anu diliwatan kana telepon anu paling anyar anu kedah dijadwalkeun nampi hudang.
    ///
    /// # Karakteristik waktos
    ///
    /// Futures nyalira aya *inert*;aranjeunna kedah janten *aktip*`poll`ed kanggo kamajuan, hartosna yén unggal-unggal tugas ayeuna dihudangkeun, éta kedah aktip deui`pololl` pending futures yén éta masih ngagaduhan minat.
    ///
    /// Fungsi `poll` henteu disebut sababaraha kali dina loop anu ketang-tibatan, éta ngan ukur kedah disebat nalika future nunjukkeun yén éta siap maju (ku nelepon `wake()`).
    /// Upami anjeun wawuh sareng `poll(2)` atanapi `select(2)` syscalls di Unix, perhatoskeun yén futures biasana henteu * henteu ngalaman masalah anu sami tina "all wakeups must poll all events";aranjeunna langkung sapertos `epoll(4)`.
    ///
    /// Hiji palaksanaan `poll` kedah narékahan pikeun balik gancang, teu kedah meungpeuk.Balik gancang nyegah unnecessarily clogging up threads atawa puteran acara.
    /// Upami dipikanyaho sateuacana yén telepon ka `poll` tiasa tungtungna sakedap, padamelan kedah diturunkeun ka kolam renang benang (atanapi anu sami) pikeun mastikeun yén `poll` tiasa balik gancang.
    ///
    /// # Panics
    ///
    /// Sakali a future parantos réngsé (balik `Ready` ti `poll`), nyauran metode `poll` na deui meureun panic, meungpeuk salamina, atanapi nyababkeun jinis masalah anu sanés;`Future` trait nempatkeun henteu sarat pikeun épék panggero sapertos kitu.
    /// Nanging, salaku padika `poll` henteu ditandaan `unsafe`, aturan Rust biasa diterapkeun: telepon kedah pernah nyababkeun tingkah laku anu teu ditangtoskeun (korupsi mémori, panggunaan fungsi `unsafe` anu salah, atanapi anu sapertosna), henteu paduli kaayaan future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}