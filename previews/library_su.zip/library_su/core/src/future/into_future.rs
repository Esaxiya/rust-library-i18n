use crate::future::Future;

/// Konversi kana `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Kaluaran anu future bakal ngahasilkeun saatos parantosan.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Jenis future anu mana anu urang jantenkeun ieu?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Nyiptakeun future tina nilai a.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}