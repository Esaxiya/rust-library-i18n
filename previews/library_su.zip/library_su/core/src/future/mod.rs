#![stable(feature = "futures_api", since = "1.36.0")]

//! Nilai teu sinkron.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Jenis ieu diperyogikeun kumargi:
///
/// a) Generators teu tiasa nerapkeun `for<'a, 'b> Generator<&'a mut Context<'b>>`, sangkan kudu lulus hiji pointer atah (tingali <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Nunjuk atah sareng `NonNull` sanés `Send` atanapi `Sync`, janten anu bakal ngajantenkeun unggal future non-Send/Sync ogé, sareng kami henteu hoyong éta.
///
/// Éta ogé saderhana nurunkeun HIR tina `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Bungkus generator dina future.
///
/// Pungsi ieu mulih a underneath `GenFuture` tapi hides eta di `impl Trait` méré pesen kasalahan hadé (`impl Future` tinimbang `GenFuture<[closure.....]>`).
///
// Ieu `const` pikeun nyingkahan kasalahan tambahan saatos urang pulih tina `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Urang ngandelkeun kanyataan yén async/await futures anu immovable guna nyieun borrows timer referential dina generator kaayaan.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // Kasalametan: Aman sabab urang geus !Unpin + !Drop, sarta ieu ngan hiji proyéksi sawah.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Ngahanca generator nu, péngkolan ka `&mut Context` kana pointer atah `NonNull`.
            // Nurunkeun `.await` bakal aman nempatkeun éta deui `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // Kasalametan: nu garansi panelepon must yén `cx.0` mangrupakeun pointer valid
    // anu minuhan sadaya sarat pikeun rujukan anu tiasa dirobih.
    unsafe { &mut *cx.0.as_ptr().cast() }
}