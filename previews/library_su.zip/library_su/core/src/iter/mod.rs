//! Iterasi éksternal anu tiasa diatur.
//!
//! Upami anjeun parantos mendakan diri anjeun sareng sababaraha jenis, sareng anjeun kedah ngalakukeun operasi kana unsur-unsur koleksi cenah, anjeun bakal gancang lumpat kana 'iterators'.
//! Iterators anu beurat dipaké dina kode Rust idiomatic, ku kituna urang patut jadi akrab jeung éta.
//!
//! Sateuacan ngajelaskeun langkung seueur, hayu urang ngobrol ngeunaan kumaha modul ieu terstruktur:
//!
//! # Organization
//!
//! modul ieu sakitu legana diayakeun ku tipe:
//!
//! * [Traits] mangrupa bagian inti: traits ieu nangtukeun jenis iterators aya na naon anjeun tiasa ngalakukeun sareng maranehna.Métode traits ieu pantes nempatkeun sababaraha waktos diajar tambahan.
//! * [Functions] nyadiakeun sabagian cara mantuan pikeun nyieun sababaraha iterators dasar.
//! * [Structs] sering mangrupikeun jinis balik tina sababaraha jinis dina modul ieu's traits.Anjeun biasana gé hayang nempo metodeu nu nyiptakeun `struct`, tinimbang `struct` sorangan.
//! Pikeun leuwih jéntré ngeunaan naha, tingali '[ngalaksanakeun Iterator](#ngalaksanakeun-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Éta pisan!Hayu urang ngagali iterator.
//!
//! # Iterator
//!
//! Jantung sareng jiwa modul ieu nyaéta [`Iterator`] trait.Inti [`Iterator`] siga kieu:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Hiji iterator boga metoda, [`next`], nu lamun disebut, mulih hiji [`Option`]`<Item>`.
//! [`next`] bakal balikkeun [`Some(Item)`] salami aya elemen, sareng saatos aranjeunna sadayana parantos béak, bakal balikkeun `None` pikeun nunjukkeun yén pengulangan parantos réngsé.
//! iterators individu bisa milih neruskeun Iteration, sarta jadi nelepon [`next`] deui bisa atawa teu ahirna ngamimitian balik [`Some(Item)`] deui di sawatara titik (contona, tingali [`TryIter`]).
//!
//!
//! Definisi lengkep [Iterator`] kalebet sababaraha padika anu sanés ogé, tapi éta metode standar, diwangun di luhur [`next`], sahingga anjeun kéngingkeun gratis.
//!
//! Iterators oge composable, sarta biasa eta urang keur ranté aranjeunna babarengan pikeun ngalakukeun bentuk leuwih kompleks pamrosésan.Tingali bagian [Adapters](#adapters) di handap pikeun langkung jelasna.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tilu wangun Iteration
//!
//! Aya tilu cara nu ilahar nu bisa nyieun iterators tina kempelan a:
//!
//! * `iter()`, nu iterates langkung `&T`.
//! * `iter_mut()`, nu iterates leuwih `&mut T`.
//! * `into_iter()`, nu iterates leuwih `T`.
//!
//! Rupa-rupa hal dina perpustakaan standar tiasa nerapkeun hiji atanapi langkung tina tilu, dimana pantes.
//!
//! # ngalaksanakeun Iterator
//!
//! Nyieun hiji iterator of sorangan ngalibatkeun dua hambalan: nyieun hiji `struct` nyekel nagara iterator urang, lajeng ngalaksanakeun [`Iterator`] keur nu `struct`.
//! Ieu naha aya kitu loba `struct`s dina modul ieu: aya hiji pikeun tiap iterator na adaptor iterator.
//!
//! Hayu urang ngadamel iterator namina `Counter` anu diitung tina `1` dugi ka `5`:
//!
//! ```
//! // Kahiji, struct nu:
//!
//! /// Hiji iterator nu diitung ti hiji nepi ka lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami hoyong itungan urang mimitian ti hiji, janten hayu urang tambahkeun padika new() pikeun ngabantosan.
//! // Ieu henteu diperyogikeun ketat, tapi langkung merenah.
//! // Catet yén urang ngamimitian `count` dina nol, urang bakal ningali kunaon dina `next()`'s palaksanaan di handap.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Lajeng, urang nerapkeun `Iterator` pikeun `Counter` kami:
//!
//! impl Iterator for Counter {
//!     // kami bakal cacah jeung usize
//!     type Item = usize;
//!
//!     // next() nya éta métode déskriptif wungkul diperlukeun
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Increment count urang.Ieu naha urang dimimitian di nol.
//!         self.count += 1;
//!
//!         // Pariksa pikeun ningali naha urang parantos réngsé ngitung atanapi henteu.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Sareng ayeuna urang tiasa nganggo!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Nelepon [`next`] cara kieu meunang repetitive.Rust ngabogaan nyusunna nu bisa nelepon [`next`] on iterator anjeun, nepika ngahontal `None`.Hayu urang teraskeun anu salajengna.
//!
//! Ogé dicatet yén `Iterator` nyadiakeun palaksanaan standar sahiji metodeu kayaning `nth` na `fold` nu nelepon `next` internal.
//! Sanajan kitu, eta oge mungkin nulis palaksanaan custom sahiji metodeu kawas `nth` na `fold` lamun hiji iterator bisa ngitung aranjeunna langkung éfisién tanpa nelepon `next`.
//!
//! # `for` puteran sarta `IntoIterator`
//!
//! sintaksis loop `for` Rust urang sabenerna gula pikeun iterators.Ieu conto dasar `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ieu bakal nyetak nomer hiji dugi ka lima, masing-masing dina garisna nyalira.Tapi maneh bakal aya bewara hal dieu: urang pernah disebut nanaon dina vector urang pikeun ngahasilkeun iterator.Naon masihan?
//!
//! Aya hiji trait dina perpustakaan baku pikeun ngarobah hal kana hiji iterator: [`IntoIterator`].
//! trait ieu salah metoda, [`into_iter`], nu ngarobah hal ngalaksanakeun [`IntoIterator`] kana hiji iterator.
//! Hayu urang tingali éta `for` loop deui, sareng naon panyusunna ngarobih kana:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-gula ieu kana:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Mimiti, urang nyauran `into_iter()` dina nilaina.Lajeng, urang cocog dina iterator nu mulih, nelepon [`next`] leuwih sarta leuwih dugi kami ningali hiji `None`.
//! Dina titik nu kami `break` kaluar tina loop, sarta kami geus rengse iterating.
//!
//! Aya hiji bit leuwih halus dieu: perpustakaan standar ngandung hiji palaksanaan metot [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Dina basa sejen, sakabeh [`Iterator`] s nerapkeun [`IntoIterator`], ku ngan balik sorangan.Ieu ngandung harti dua hal:
//!
//! 1. Lamun nuju nulis hiji [`Iterator`], Anjeun bisa make eta ku loop `for`.
//! 2. Lamun nuju nyieun kempelan anu, ngalaksanakeun [`IntoIterator`] pikeun nagara éta bakal ngijinkeun kempelan anjeun pikeun dipaké jeung loop `for`.
//!
//! # Iterating ku rujukan
//!
//! Kusabab [`into_iter()`] nyokot `self` ku nilai, maké loop `for` mun iterate leuwih koleksi meakeun eta kempelan.Mindeng, Anjeun meureun hoyong iterate leuwih kempelan tanpa consuming eta.
//! Seueur koleksi nawiskeun metode anu nyayogikeun iterator langkung seueur tina rujukan, sacara konvensional disebat `iter()` sareng `iter_mut()` masing-masing:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` masih milik fungsi ieu.
//! ```
//!
//! Mun hiji tipe kempelan `C` nyadiakeun `iter()`, éta biasana ogé implements `IntoIterator` pikeun `&C`, kalawan hiji palaksanaan eta ngan nyaéta panggero `iter()`.
//! Kitu ogé, kumpulan `C` anu nyayogikeun `iter_mut()` umumna ngalaksanakeun `IntoIterator` pikeun `&mut C` ku ngadelegasi ka `iter_mut()`.Ieu nyandak pondok pondok:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sami sareng `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sami sareng `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Bari seueur koleksi nawiskeun `iter()`, teu sadayana nawiskeun `iter_mut()`.
//! Contona, mutating kenop a [`HashSet<T>`] atanapi [`HashMap<K, V>`] bisa nempatkeun koleksi kana hiji kaayaan inconsistent lamun konci hashes robah, jadi kumpulan ieu ngan nawiskeun `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fungsi nu nyandak hiji [`Iterator`] sarta balik [`Iterator`] sejen nu ilahar disebut 'iterator adapters', sakumaha aranjeunna geus mangrupa formulir tina 'adaptor
//! pattern'.
//!
//! adapters iterator umum ngawengku [`map`], [`take`], sarta [`filter`].
//! Kanggo langkung seueur, tingali dokuméntasi na.
//!
//! Upami adaptor iterator panics, iterator bakal aya dina kaayaan anu teu ditangtoskeun (tapi memori aman).
//! kaayaan ieu ogé teu dijamin tetep sami di sakuliah versi tina Rust, jadi Anjeun kudu ulah aya gumantung kana nilai pasti dipulang ku hiji iterator nu panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (jeung iterator [adapters](#adapters)) téh *kedul*. Ieu hartosna yén ngan nyieun hiji iterator teu _do_ sacara gembleng loba. Euweuh bener kajadian dugi ka nelepon [`next`].
//! Ieu kadang mangrupa sumber ngabingungkeun nalika nyieun hiji iterator solely keur efek samping na.
//! Contona, metoda [`map`] nyaéta panggero anu panutupanana on unggal unsur eta iterates leuwih:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ieu moal nyitak nilai wae, sakumaha urang ukur dijieun hiji iterator, tinimbang make eta.kompiler bakal ngingetkeun urang ngeunaan jenis ieu kabiasaan:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Cara idiomatic nulis [`map`] keur efek samping na téh mun ngagunakeun loop `for` atanapi nelepon metoda [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Cara séjén ilahar evaluate hiji iterator nyaeta ngagunakeun padika [`collect`] ngahasilkeun kempelan anyar.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterator henteu kedah terhingga.Salaku conto, kisaran terbuka nyaéta iterator tanpa wates:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Ilahar ngagunakeun adaptor iterator [`take`] pikeun ngarobih iterator tanpa wates kana anu terhingga:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ieu bakal nyitak angka `0` ngaliwatan `4`, unggal dina garis sorangan.
//!
//! Bear di pikiran yén métode dina iterators wates, sanajan eta nu hasilna bisa ditangtukeun matematis dina jangka waktu terhingga, bisa jadi teu nungtungan.
//! Husus, métode kayaning [`min`], nu dina kasus umum merlukeun traversing unggal unsur dina iterator, aya kamungkinan teu balik hasil keur naon iterators wates.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh henteu!Gelung anu teu aya watesna!
//! // `ones.min()` ngabalukarkeun hiji loop wates, sangkan moal ngahontal titik ieu!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;