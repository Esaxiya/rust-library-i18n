use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait Ieu nyadiakeun aksés transitive kana sumber-tahap dina pipa interator-adaptor dina kaayaan nu
/// * sumber iterator `S` sorangan implements `SourceIter<Source = S>`
/// * aya hiji palaksanaan delegating of trait ieu tiap adaptor dina pipa antara sumber sarta pipa konsumen.
///
/// Nalika sumberna mangrupikeun strukturna iterator (ilahar disebat `IntoIter`) maka ieu tiasa manpaat pikeun ngahususkeun palaksanaan [`FromIterator`] atanapi nyéépkeun unsur-unsur sésana saatos iterator parantos parsial paré.
///
///
/// Catet yén palaksanaan henteu kedah nyayogikeun aksés kana sumber pipa jero-paling tina pipa.A adaptor panengah stateful bisa eagerly evaluate bagian tina pipa jeung ngalaan panyimpenan internal salaku sumber.
///
/// trait henteu aman sabab palaksana kedah ngajaga sipat kaamanan tambahan.
/// Tingali [`as_inner`] pikeun detil.
///
/// # Examples
///
/// Nyandak sumber anu dikonsumsi sawaréh:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Hiji tahap sumber dina pipa iterator.
    type Source: Iterator;

    /// Candak sumber pipa iterator.
    ///
    /// # Safety
    ///
    /// Implementations sahiji must balik rujukan mutable sami for hirupna maranéhanana, iwal diganti ku panelepon a.
    /// Nelepon ukur bisa ngaganti rujukan nalika aranjeunna dieureunkeun Iteration jeung leupaskeun pipa iterator sanggeus extracting sumberna.
    ///
    /// hartosna kieu iterator adapters bisa ngandelkeun sumber nu teu ngarobah mangsa Iteration tapi maranéhna teu bisa ngandelkeun eta di implementations serelek maranéhanana.
    ///
    /// Ngalaksanakeun metode ieu hartosna adaptor ngaleupaskeun aksés pribadi-nyalira kana sumberna sareng ngan ukur tiasa ngandelkeun jaminan anu didamel dumasar kana jinis panarima metode.
    /// Kurangna aksés diwatesan ogé merlukeun adapters kedah uphold API umum sumber urang sanajan maranéhna miboga aksés ka internals na.
    ///
    /// Nu nélépon péngkolan kedah ngarepkeun sumberna bakal aya dina kaayaan naon waé anu saluyu sareng API umum na kusabab adaptor anu linggih diantawisna sareng sumberna ngagaduhan aksés anu sami.
    /// Khususna adaptor panginten tiasa nyéépkeun langkung seueur unsur tibatan anu diperyogikeun pisan.
    ///
    /// Tujuan sakabéh sarat ieu téh mun ngantep konsumen of a pamakéan pipa
    /// * naon tetep di sumberna sanggeus Iteration geus dieureunkeun
    /// * mémori nu geus jadi henteu kapake ku advancing a iterator consuming
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adaptor iterator anu ngahasilkeun kaluaran salami iterator kaayaan ngahasilkeun nilai `Result::Ok`.
///
///
/// Lamun kasalahan anu encountered, iterator eureun and error teh disimpen.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Ngolah iterator dirumuskeun sakumaha lamun eta yielded a `T` tinimbang hiji `Result<T, _>`.
/// Sagala kasalahan bakal ngeureunkeun iterator jero tur hasil sakabéh bakal kasalahan.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}