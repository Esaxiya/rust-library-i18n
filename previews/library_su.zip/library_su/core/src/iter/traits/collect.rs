/// Konversi ti hiji [`Iterator`].
///
/// Ku ngalaksanakeun `FromIterator` pikeun jenis a, anjeun nangtukeun sabaraha eta bakal dijieun tina hiji iterator.
/// Ieu umum pikeun jenis nu ngajelaskeun kumpulan sababaraha jenis.
///
/// [`FromIterator::from_iter()`] nyaeta jarang disebut eksplisit, sarta gaganti dipaké ngaliwatan métode [`Iterator::collect()`].
///
/// Tempo dokuméntasi [`Iterator::collect()`]'s pikeun conto deui.
///
/// Tingali ogé: [`IntoIterator`].
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ngagunakeun [`Iterator::collect()`] pikeun sacara implisit nganggo `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ngalaksanakeun `FromIterator` pikeun jenis anjeun:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A kempelan sample, éta ngan hiji wrapper leuwih Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hayu urang masihan eta sababaraha métode sangkan bisa nyieun hiji tur nambahkeun hal eta.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // sarta kami bakal nerapkeun FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ayeuna urang tiasa ngadamel iterator énggal ...
/// let iter = (0..5).into_iter();
///
/// // ... sareng ngadamel MyCollection kaluar na
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // kumpulkeun karya ogé!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Nyiptakeun nilai tina hiji iterator.
    ///
    /// Tingali [module-level documentation] pikeun langkung seueur.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konversi kana hiji [`Iterator`].
///
/// Ku ngalaksanakeun `IntoIterator` pikeun jenis a, anjeun nangtukeun sabaraha eta bakal dirobah jadi hiji iterator.
/// Ieu umum pikeun jenis nu ngajelaskeun kumpulan sababaraha jenis.
///
/// Hiji manfaat tina ngalaksanakeun `IntoIterator` éta jenis anjeun bakal [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Tingali ogé: [`FromIterator`].
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Ngalaksanakeun `IntoIterator` pikeun jenis anjeun:
///
/// ```
/// // A kempelan sample, éta ngan hiji wrapper leuwih Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hayu urang masihan eta sababaraha métode sangkan bisa nyieun hiji tur nambahkeun hal eta.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // sareng urang bakal nerapkeun IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ayeuna urang tiasa ngadamel koleksi anyar ...
/// let mut c = MyCollection::new();
///
/// // ... nambahkeun sababaraha barang ka eta ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... lajeng ngahurungkeun kana hiji Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Geus ilahar make `IntoIterator` salaku trait bound.Hal ieu ngamungkinkeun input tipe kempelan ka robah, jadi salami éta kénéh hiji iterator.
/// Wates tambahan tiasa ditangtoskeun ku ngawatesan dina
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Jinis unsur keur iterated leuwih.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Jenis iterator anu mana anu urang jantenkeun ieu?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Nyiptakeun iterator tina nilai.
    ///
    /// Tingali [module-level documentation] pikeun langkung seueur.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Manjangkeun kempelan kalayan eusi hiji iterator.
///
/// Iterators ngahasilkeun runtuyan nilai, jeung kumpulan ogé bisa dianggap salaku runtuyan nilai.
/// The `Extend` trait sasak gap ieu, sahingga anjeun manjangkeun kempelan ku kaasup eusi iterator éta.
/// Nalika dilegaan kempelan kalayan hiji konci geus aya, Éntri anu diropéa atawa, di hal koleksi nu diturutan sababaraha éntri jeung kenop sarua, yen entri diselapkeun.
///
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// // Anjeun tiasa manjangkeun String sareng sababaraha chars:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Ngalaksanakeun `Extend`:
///
/// ```
/// // A kempelan sample, éta ngan hiji wrapper leuwih Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Hayu urang masihan eta sababaraha métode sangkan bisa nyieun hiji tur nambahkeun hal eta.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kumargi MyCollection ngagaduhan daptar i32s, urang nerapkeun Extend for i32
/// impl Extend<i32> for MyCollection {
///
///     // Ieu sakedik saderhana sareng tandatangan jinis beton: urang tiasa nelepon ngalegaan naon waé anu tiasa dijantenkeun Iterator anu masihan urang i32s.
///     // Kusabab urang kudu i32s nempatkeun kana MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // palaksanaan The pisan lugas: loop ngaliwatan iterator, sarta add() unggal unsur kana diri urang sorangan.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // hayu urang manjangkeun kempelan urang ku tilu nomer langkung
/// c.extend(vec![1, 2, 3]);
///
/// // kami geus ditambahkeun elemen ieu onto tungtungna
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Ngalegaan koleksi kalayan eusi iterator.
    ///
    /// Salaku nya éta métode déskriptif wungkul diperlukeun pikeun trait ieu, nu docs [trait-level] ngandung leuwih rinci.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // Anjeun tiasa manjangkeun String sareng sababaraha chars:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Ngalegaan koleksi kalawan kahayang hiji unsur.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// kapasitas cadangan dina kempelan keur angka tinangtu unsur tambahan.
    ///
    /// Palaksanaan standar teu nanaon.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}