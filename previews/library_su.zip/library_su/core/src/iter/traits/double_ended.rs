use crate::ops::{ControlFlow, Try};

/// Hiji iterator bisa elemen ngahasilkeun ti duanana tungtung.
///
/// Hal anu implements `DoubleEndedIterator` boga salah kamampuhan tambahan leuwih hal anu implements [`Iterator`]: kamampuhan pikeun ogé nyandak `Item`s ti tukang, kitu ogé hareup.
///
///
/// Kadé catetan yen duanana deui karya mudik dina rentang anu sarua, sarta ulah cross: Iteration téh leuwih nalika aranjeunna papanggih di tengahna.
///
/// Dina cara anu sami sareng protokol [`Iterator`], sakali `DoubleEndedIterator` mulih [`None`] ti [`next_back()`], nyauran deui tiasa atanapi henteu pernah balik deui ka [`Some`] deui.
/// [`next()`] sarta [`next_back()`] anu ditukeurkeun keur kaperluan ieu.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Ngaluarkeun na mulih unsur ti tungtung iterator nu.
    ///
    /// Mulih `None` nalika teu aya deui unsur.
    ///
    /// Dokumén [trait-level] ngandung langkung rinci.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Unsur anu diturunkeun ku metode 'DoubleEndedIterator`'s tiasa béda sareng anu dihasilkeun ku cara [' Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Kamajuan nu iterator ti balik ku elemen `n`.
    ///
    /// `advance_back_by` mangrupikeun pérsi tibalik tina [`advance_by`].Metoda ieu eagerly bakal skip elemen `n` dimimitian ti tukang ku nelepon [`next_back`] nepi ka `n` kali dugi [`None`] ieu encountered.
    ///
    /// `advance_back_by(n)` bakal balik [`Ok(())`] lamun iterator berhasil kamajuan ku elemen `n`, atawa [`Err(k)`] lamun [`None`] ieu encountered, dimana `k` teh Jumlah elemen nu iterator nyaeta canggih ku méméh ngajalankeun kaluar tina elemen (ie
    /// panjang iterator nu).
    /// Catet yén `k` sok kirang ti `n`.
    ///
    /// Nelepon `advance_back_by(0)` henteu nyéépkeun unsur naon waé sareng sok mulih [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ngan ukur `&3` anu diloloskeun
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Mulih ti `unsur n`th ti tungtung iterator nu.
    ///
    /// Ieu dasarna versi malikkeun of [`Iterator::nth()`].
    /// Sanajan kawas operasi indexing paling, golongan cacah dimimitian ti enol, jadi `nth_back(0)` mulih nilai mimitina ti tungtung, `nth_back(1)` kadua, jeung saterusna.
    ///
    ///
    /// Catet yén sadaya elemen antara tungtung na unsur balik bakal dihakan, kaasup unsur balik.
    /// Ieu ogé ngandung harti yén nelepon `nth_back(0)` sababaraha kali dina iterator anu sami bakal balikkeun unsur anu béda.
    ///
    /// `nth_back()` bakal balik [`None`] lamun `n` nyaeta gede ti atawa sarua jeung panjang iterator kana.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Nelepon `nth_back()` sababaraha kali teu ngulang iterator nu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Balik `None` lamun aya kirang ti elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ieu versi sabalikna tina [`Iterator::try_fold()`]: waktu nu diperlukeun elemen dimimitian ti tukang iterator nu.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Kusabab éta pondok-sirkuit, elemen sésana masih aya ku éta iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Hiji metodeu iterator nu ngurangan elemen nu iterator urang ka, nilai final tunggal, mimitian ti tukang.
    ///
    /// Ieu versi sabalikna tina [`Iterator::fold()`]: waktu nu diperlukeun elemen dimimitian ti tukang iterator nu.
    ///
    /// `rfold()` nyokot dua alesan: hiji nilai awal, sarta panutupanana dua alesan: hiji 'accumulator', sarta unsur.
    /// panutupanana nu mulih ka nilai anu accumulator kudu boga keur Iteration salajengna.
    ///
    /// Nilai awal ngarupakeun nilai accumulator bakal mibanda dina panggero munggaran.
    ///
    /// Saatos nerapkeun panutupanana ieu pikeun unggal unsur iterator, `rfold()` mulihkeun akumulator.
    ///
    /// Operasi ieu kadangkala disebut 'reduce' atanapi 'inject'.
    ///
    /// Tilepan gunana iraha waé anjeun ngagaduhan kumpulan naon waé, sareng hoyong ngahasilkeun hiji nilai tina éta.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah sakabéh unsur a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Contona kieu ngawangun string a, dimimitian ku hiji nilai awal jeung neraskeun kalawan unggal unsur tina balik dugi hareup:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Neangan hiji unsur hiji iterator ti balik eta satisfies predikat hiji.
    ///
    /// `rfind()` nyokot panutupanana yen mulih `true` atanapi `false`.
    /// Ieu lumaku panutupanana ieu unggal unsur iterator nu, dimimitian dina tungtungna, sarta lamun salah sahiji aranjeunna balik `true`, teras `rfind()` mulih [`Some(element)`].
    /// Upami aranjeunna sadayana mulih `false`, éta mulih [`None`].
    ///
    /// `rfind()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas panutupanana nu mulih `true`.
    ///
    /// Kusabab `rfind()` nyokot rujukan, sarta loba iterators iterate leuwih rujukan, ngawujud ieu kaayaan jigana matak ngabingungkeun mana argumen mangrupakeun rujukan ganda.
    ///
    /// Anjeun tiasa ningali efek ieu conto di handap, kalawan `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Eureun dina `true` munggaran:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}