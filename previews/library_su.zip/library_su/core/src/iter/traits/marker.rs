/// Hiji iterator nu salawasna terus ngahasilkeun `None` nalika exhausted.
///
/// Nelepon hareup dina datar iterator nu geus balik `None` sakali dijamin mun balik [`None`] deui.
/// trait Ieu kudu dilaksanakeun ku sakabeh iterators anu kalakuanana cara kieu hal ieu ngamungkinkeun optimizing [`Iterator::fuse()`].
///
///
/// Note: Sacara umum, anjeun teu kedah nganggo `FusedIterator` dina wates umum upami anjeun kedah iterator sekering.
/// Sabalikna, anjeun kedah ngan ukur nyauran [`Iterator::fuse()`] dina iterator.
/// Mun iterator kasebut geus datar, anu tambahan [`Fuse`] wrapper bakal euweuh-op jeung euweuh pinalti kinerja.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Hiji iterator nu ngalaporkeun hiji panjangna akurat maké size_hint.
///
/// The iterator ngalaporkeun hiji hint ukuranana mana éta boh pasti (handap kabeungkeut sarua jeung hulu kabeungkeut), atawa luhur kabeungkeut nyaeta [`None`].
///
/// Luhur wates must ukur jadi [`None`] lamun panjang iterator sabenerna nyaéta leuwih badag batan [`usize::MAX`].
/// Dina kasus eta, nu nurunkeun sagala kudu [`usize::MAX`], hasilna dina [`Iterator::size_hint()`] of `(usize::MAX, None)`.
///
/// iterator kudu ngahasilkeun persis Jumlah elemen eta dilaporkeun atanapi diverge saméméh ngahontal tungtungna.
///
/// # Safety
///
/// trait Ieu kedah ukur dilaksanakeun lamun kontrak ieu upheld.
/// Pamakéna of trait ieu kudu mariksa [`Iterator::size_hint()`]’s luhur kabeungkeut.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterator anu nalika ngahasilkeun hiji barang bakal nyandak sahanteuna hiji unsur tina [`SourceIter`] anu janten dasarna.
///
/// Nelepon metoda naon nu kamajuan iterator nu, misalna
/// [`next()`] atanapi [`try_fold()`], jaminan yén pikeun tiap hambalan sahanteuna hiji nilai tina sumber kaayaan nu iterator urang geus dipindahkeun kaluar jeung hasil tina ranté iterator bisa diselapkeun dina tempatna, asumsina konstrain struktural sumberna ngawenangkeun panempatan misalna hiji.
///
/// Istilah sanésna trait ieu nunjukkeun yén hiji pipa iterator bisa dikumpulkeun di tempat.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}