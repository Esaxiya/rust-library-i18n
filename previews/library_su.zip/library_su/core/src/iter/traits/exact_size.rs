/// Hiji iterator nu weruh panjangna pasti na.
///
/// Loba [`Iterator`] s teu nyaho sabaraha kali maranéhna bakal iterate, tapi sababaraha do.
/// Mun hiji iterator weruh sabaraha kali eta tiasa iterate, nyadiakeun aksés ka informasi nu bisa jadi mangpaat.
/// Contona, upami anjeun hoyong iterate tukang, mimiti alus nyaeta uninga dimana tungtungna téh.
///
/// Nalika ngalaksanakeun hiji `ExactSizeIterator`, Anjeun ogé kudu nerapkeun [`Iterator`].
/// Lamun ngalakukeun kitu, palaksanaan [`Iterator::size_hint`]*kedah* balik ukuran pasti tina iterator nu.
///
/// Metodeu [`len`] ngabogaan palaksanaan standar, jadi Anjeun biasana teu kudu nerapkeun eta.
/// Najan kitu, anjeun bisa bisa nyadiakeun hiji palaksanaan performant leuwih ti standar éta, jadi overriding eta dina hal ieu ngajadikeun rasa.
///
///
/// Catet yén trait ieu mangrupikeun trait anu aman sareng sapertos kitu *henteu* sareng *henteu tiasa* ngajamin yén panjang anu dipulangkeun leres.
/// Ieu hartosna yén kode `unsafe`**teu kedah** ngandelkeun correctness of [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait anu teu stabil sareng henteu aman masihan jaminan tambahan ieu.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// // kisaran terhingga terang persis sabaraha kali éta bakal iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Dina [module-level docs], urang dilaksanakeun hiji [`Iterator`], `Counter`.
/// Hayu urang nerapkeun `ExactSizeIterator` pikeun salaku ogé:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Urang bisa kalayan gampang ngitung jumlah sésana of iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Sareng ayeuna urang tiasa nganggo!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Mulih ka panjangna pasti tina iterator nu.
    ///
    /// Palaksanaan mastikeun yén iterator bakal balik persis `len()` langkung kali nilai [`Some(T)`], sateuacan balik [`None`].
    ///
    /// Metoda ieu mangrupa palaksanaan standar, jadi Anjeun biasana teu kudu nerapkeun eta langsung.
    /// Nanging, upami anjeun tiasa nyayogikeun palaksanaan anu langkung épisién, anjeun tiasa ngalakukeun éta.
    /// Ningali docs [trait-level] pikeun conto.
    ///
    /// Fungsi ieu ngagaduhan jaminan kaamanan anu sami sareng fungsi [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // kisaran terhingga terang persis sabaraha kali éta bakal iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Pernyataan ieu teuing pertahanan, tapi éta cek invarian
        // dijamin ku trait.
        // Mun trait kieu nya rust-internal, urang bisa make debug_assert !;negeskeun_eq!bakal mariksa sadayana palaksanaan pangguna Rust ogé.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Mulih `true` upami iterator kosong.
    ///
    /// Cara ieu ngagaduhan implementasi standar nganggo [`ExactSizeIterator::len()`], janten anjeun henteu kedah ngalaksanakeunnana nyalira.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}