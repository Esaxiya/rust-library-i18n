// malire-beberes-filelength file ieu ampir éksklusif ngawengku harti `Iterator`.
// Urang teu bisa dibeulah éta kana sababaraha payil.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Hiji panganteur pikeun kaayaan iterators.
///
/// Ieu teh iterator utama trait.
/// Pikeun leuwih lengkep ngeunaan konsép iterators umumna, mangga ningali [module-level documentation].
/// Khususna, anjeun panginten hoyong terang kumaha [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Jinis unsur keur iterated leuwih.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kamajuan iterator jeung mulih nilai salajengna.
    ///
    /// Mulih [`None`] nalika Iteration geus réngsé.
    /// implementations iterator individu bisa milih neruskeun Iteration, sarta jadi nelepon `next()` deui bisa atawa teu mungkin ahirna ngamimitian balik [`Some(Item)`] deui di sawatara titik.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A panggero pikeun next() mulih nilai hareup ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... terus Euweuh sakali éta réngsé.
    /// assert_eq!(None, iter.next());
    ///
    /// // nelepon deui bisa atawa teu balik `None`.Di dieu, aranjeunna bakal salawasna.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Mulih ka bounds dina panjangna sésana of iterator kana.
    ///
    /// Husus, `size_hint()` mulih a tuple mana unsur kahiji nyaeta handap kabeungkeut, sarta unsur nu kadua nyaeta luhur kabeungkeut.
    ///
    /// Kaduana satengah tina tuple anu balik mangrupa [`Option`]`<`[`usize`] `>`.
    /// A [`None`] didieu hartosna yén boh euweuh dipikawanoh luhur kabeungkeut, atawa luhur kabeungkeut téh leuwih badag batan [`usize`].
    ///
    /// # Catetan palaksanaan
    ///
    /// Éta henteu ditegakeun yén palaksanaan iterator ngahasilkeun jumlah unsur anu dinyatakeun.A Buggy iterator bisa ngahasilkeun kirang ti handap kabeungkeut atawa leuwih ti luhur kabeungkeut unsur.
    ///
    /// `size_hint()` ieu utamana dimaksudkeun pikeun dipaké pikeun optimizations kayaning reserving spasi pikeun unsur iterator, tapi teu kudu dipercaya mun misalna, bounds cék ngaleungitkeun di kode unsafe.
    /// Hiji palaksanaan lepat tina `size_hint()` teu kudu ngakibatkeun pelanggaran kaamanan memori.
    ///
    /// Kitu cenah, palaksanaan kudu nyadiakeun estimasi bener, sabab lamun heunteu bakal palanggaran protokol trait urang.
    ///
    /// Palaksanaan standar mulih `(0,` [`None`]`)`nu bener pikeun iterator nanaon.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Hiji conto nu leuwih kompleks:
    ///
    /// ```
    /// // The angka malah ti enol nepi ka sapuluh.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Urang bisa iterate ti enol nepi ka sapuluh kali.
    /// // Nyaho yen eta urang lima kahayang moal bakal tiasa tanpa executing filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Hayu urang tambahkeun lima angka leuwih mibanda chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // kiwari duanana bounds anu ngaronjat ku lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Balik `None` pikeun wates luhur:
    ///
    /// ```
    /// // iterator tanpa wates teu ngagaduhan wates luhur sareng wates handap anu mungkin
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Meakeun iterator nu, cacah jumlah iterations na balik deui.
    ///
    /// Cara ieu bakal nyauran [`next`] sababaraha kali dugi ka [`None`] kapendak, mulih deui sababaraha kali ningali [`Some`].
    /// Catet yén [`next`] kedah disebat sahenteuna sakali sanajan iteratorna henteu ngagaduhan unsur naon waé.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Ngalangkungan Paripolah
    ///
    /// métode manten moal guarding ngalawan overflows, jadi cacah unsur hiji iterator kalawan leuwih ti [`usize::MAX`] elemen boh ngahasilkeun hasil salah atawa panics.
    ///
    /// Mun assertions debug nu diaktipkeun, hiji panic dijamin.
    ///
    /// # Panics
    ///
    /// Pungsi ieu bisa panic lamun iterator ngabogaan leuwih ti elemen [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Meakeun iterator nu, balik unsur panungtungan.
    ///
    /// Metoda ieu bakal evaluate iterator nepika mulih [`None`].
    /// Bari cara eta, eta ngajaga lagu tina unsur ayeuna.
    /// Saatos [`None`] dipulangkeun, `last()` teras bakal ngembalikan unsur panungtung anu ditingali.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Kamajuan nu iterator ku elemen `n`.
    ///
    /// Metoda ieu eagerly bakal skip elemen `n` ku nelepon [`next`] nepi ka `n` kali dugi [`None`] ieu encountered.
    ///
    /// `advance_by(n)` bakal balik [`Ok(())`][Ok] lamun iterator berhasil kamajuan ku elemen `n`, atawa [`Err(k)`][Err] lamun [`None`] ieu encountered, dimana `k` teh Jumlah elemen nu iterator nyaeta canggih ku méméh ngajalankeun kaluar tina elemen (ie
    /// panjang iterator nu).
    /// Catet yén `k` sok kirang ti `n`.
    ///
    /// Nelepon `advance_by(0)` teu meakeun elemen sagala na salawasna mulih [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // ngan ukur `&4` anu diloloskeun
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Balikkeun unsur `n`th tina iterator.
    ///
    /// Kawas operasi indexing paling, golongan cacah dimimitian ti enol, jadi `nth(0)` mulih nilai heula, `nth(1)` kadua, jeung saterusna.
    ///
    /// Catet yén sadaya unsur sateuacanna, ogé unsur anu dipulangkeun, bakal dikonsumsi tina iteratorna.
    /// hartosna yén yén elemen harita bakal dipiceun, sarta ogé anu nelepon `nth(0)` sababaraha kali dina iterator sarua bakal balik elemen béda.
    ///
    ///
    /// `nth()` bakal balik [`None`] lamun `n` nyaeta gede ti atawa sarua jeung panjang iterator kana.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Nelepon `nth()` sababaraha kali teu ngulang iterator nu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Balik `None` lamun aya kirang ti elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Nyiptakeun mangrupa iterator dimimitian dina titik anu sarua, tapi stepping ku jumlah dibikeun dina unggal Iteration.
    ///
    /// Catetan 1: Unsur kahiji tina iterator bakal salawasna dipulangkeun, teu paduli léngkah anu ditangtukeun.
    ///
    /// Catetan 2: Waktu di mana elemen dipaliré nu ditarik teu dibereskeun.
    /// `StepBy` behaves kawas sekuen `next(), nth(step-1), nth(step-1),…`, tapi oge haratis jeung kalakuanana kawas ruruntuyan
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cara mana anu dianggo tiasa robih pikeun sababaraha iterator ku alesan kinerja.
    /// Cara kadua baris muka iterator saméméhna jeung bisa meakeun leuwih item.
    ///
    /// `advance_n_and_return_first` teh sarua jeung:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Cara na bakal panic upami léngkah anu dipasihkeun nyaéta `0`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Nyokot dua iterators sarta nyiptakeun iterator anyar leuwih duanana dina runtuyan.
    ///
    /// `chain()` bakal balikkeun iterator énggal anu mimitina bakal ngutip nilai tina iterator munggaran teras langkung nilai tina iterator kadua.
    ///
    /// Kalayan kecap séjén, éta ngaitkeun dua iterator babarengan, dina ranté.🔗
    ///
    /// [`once`] ilahar dipaké pikeun adaptasi hiji nilai kana ranté jinis Iteration séjén.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ti argumen pikeun `chain()` migunakeun [`IntoIterator`], urang tiasa maot nanaon nu bisa dirobah jadi hiji [`Iterator`], teu ngan hiji [`Iterator`] sorangan.
    /// Salaku conto, keureut (`&[T]`) nerapkeun [`IntoIterator`], sareng janten tiasa diteruskeun ka `chain()` langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Mun anjeun damel sareng Windows API, anjeun bisa hayang pikeun ngarobah [`OsStr`] mun `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips up' dua iterator kana hiji iterator pasangan.
    ///
    /// `zip()` mulihkeun iterator énggal anu bakalan langkung ti dua iterator anu sanés, mulihkeun tuple dimana unsur anu munggaran asalna tina iterator anu munggaran, sareng unsur anu kadua asalna tina iterator anu kadua.
    ///
    ///
    /// Dina basa sejen, eta zips dua iterators babarengan, kana hiji tunggal.
    ///
    /// Mun boh iterator mulih [`None`], [`next`] ti zipped iterator bakal balik [`None`].
    /// Lamun iterator munggaran mulih [`None`], `zip` bakal pondok-circuit sarta `next` moal disebut dina iterator kadua.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ti argumen pikeun `zip()` migunakeun [`IntoIterator`], urang tiasa maot nanaon nu bisa dirobah jadi hiji [`Iterator`], teu ngan hiji [`Iterator`] sorangan.
    /// Salaku conto, keureut (`&[T]`) nerapkeun [`IntoIterator`], sareng janten tiasa diteruskeun ka `zip()` langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ieu mindeng dipaké pikeun pos hiji iterator wates ka hiji terhingga.
    /// Ieu jalan kusabab iterator anu kawates antukna bakal balikkeun [`None`], mungkas seleting.Zipping kalawan `(0..)` bisa ngungkaban loba kawas [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Nyiptakeun iterator anyar nu tempat hiji salinan `separator` antara barang meungkeut tina iterator aslina.
    ///
    /// Bisi `separator` henteu nerapkeun [`Clone`] atawa kaperluan bisa diitung unggal waktu, make [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Unsur kahiji ti `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pamisahna.
    /// assert_eq!(a.next(), Some(&1));   // Unsur salajengna tina `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pamisahna.
    /// assert_eq!(a.next(), Some(&2));   // Unsur pamungkas ti `a`.
    /// assert_eq!(a.next(), None);       // iterator nyaeta rengse.
    /// ```
    ///
    /// `intersperse` tiasa mangpaat pisan pikeun ngiringan barang iterator nganggo unsur anu umum:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Nyiptakeun iterator anyar nu tempat hiji item dihasilkeun ku `separator` antara barang meungkeut tina iterator aslina.
    ///
    /// panutupanana bakal disebut persis sakali unggal waktu hiji item ieu disimpen diantara dua item meungkeut ti iterator kaayaan;
    /// husus, panutupanana henteu disebut lamun kaayaan iterator ngahasilkeun kirang ti dua item sarta sanggeus éta item panungtungan ieu yielded.
    ///
    ///
    /// Lamun iterator urang item implements [`Clone`], nya meureun leuwih gampang ngagunakeun [`intersperse`].
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Unsur anu mimiti tina `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pamisahna.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Unsur hareup ti `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pamisahna.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Unsur pamungkas ti ti `v`.
    /// assert_eq!(it.next(), None);               // iterator nyaeta rengse.
    /// ```
    ///
    /// `intersperse_with` bisa dipaké dina kaayan SEPARATOR nu perlu diitung:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // panutupanana The mutably borrows konteks na keur ngahasilkeun hiji item.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Butuh panutupanana sarta nyiptakeun hiji iterator nu nyebut yen panutupanana on unggal unsur.
    ///
    /// `map()` ngarobih hiji iterator kana anu séjén, ku cara argumen na:
    /// hal anu implements [`FnMut`].Éta ngahasilkeun Iterator anyar anu nyebat panutupanana ieu pikeun masing-masing unsur iterator aslina.
    ///
    /// Mun anjeun alus dina pamikiran dina jenis, anjeun tiasa mikir `map()` kawas kieu:
    /// Upami Anjeun gaduh hiji iterator nu mere Anjeun unsur sababaraha tipe `A`, sarta rék hiji iterator tina sababaraha jenis séjén `B`, anjeun tiasa nganggo `map()`, ngalirkeun a panutupanana nu nyokot hiji `A` na mulih a `B`.
    ///
    ///
    /// `map()` konseptual mirip sareng loop [`for`].Najan kitu, salaku `map()` téh kedul, mangka pangalusna dipaké nalika nu nuju geus gawé bareng iterators lianna.
    /// Lamun nuju lakukeun sababaraha nurun looping pikeun éfék samping, ayeuna teh dianggap leuwih idiomatic ngagunakeun [`for`] ti `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Upami anjeun ngalakukeun sababaraha jinis efek samping, resep [`for`] ka `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // entong kieu:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // eta malah moal ngaéksekusi, sakumaha anu kasebut puguh.Rust bakal ngingetkeun maneh ngeunaan ieu.
    ///
    /// // Sabalikna, dianggo pikeun:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Nelepon panutupanana dina unggal unsur iterator.
    ///
    /// Ieu sarua jeung maké loop [`for`] on iterator, sanajan `break` na `continue` teu mungkin ti panutupanana a.
    /// Umumna langkung idiomatis nganggo loop `for`, tapi `for_each` tiasa langkung kabaca nalika ngolah barang dina tungtung ranté iterator anu langkung lami.
    ///
    /// Dina sababaraha kasus `for_each` ogé bisa jadi leuwih gancang ti loop a, sabab bakal make Iteration internal on adapters kawas `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Pikeun sapertos conto leutik, hiji `for` loop meureun cleaner, tapi `for_each` bisa jadi hade tetep hiji gaya fungsi kalawan iterators panjang:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Nyiptakeun mangrupa iterator nu migunakeun panutupanana pikeun nangtukeun lamun unsur kudu yielded.
    ///
    /// Dibikeun unsur panutupanana kudu balik `true` atanapi `false`.Iterator anu balik bakal ngahasilkeun unsur-unsur anu mana panutupanna leres deui.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kusabab panutupan anu diliwatan ka `filter()` butuh rujukan, sareng seueur iterator ngagitar rujukan, ieu ngakibatkeun kaayaan anu matak lieur, dimana jinis panutupan mangrupikeun référénsi dobel:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // peryogi dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Biasana pikeun ngagunakeun destructuring dina argumen pikeun ngajauhkeun:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // duanana&sarta *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// atawa duanana:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// tina lapisan ieu.
    ///
    /// Catet yén `iter.filter(f).next()` sarua jeung `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Nyiptakeun mangrupa iterator yen duanana mamah jeung peta.
    ///
    /// Dipulangkeun iterator ngahasilkeun mung `value`s keur nu panutupanana disadiakeun mulih `Some(value)`.
    ///
    /// `filter_map` bisa dipaké nyieun rantay [`filter`] na [`map`] singket langkung.
    /// Conto dihandap nempokeun sabaraha hiji `map().filter().map()` bisa disingget jadi hiji panggero single ka `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Di dieu teh conto anu sarua, tapi ku [`filter`] na [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Nyiptakeun mangrupa iterator nu méré count Iteration ayeuna ogé nilai salajengna.
    ///
    /// The iterator ngahasilkeun balik pasang `(i, val)`, dimana `i` nyaéta indéks kiwari Iteration na `val` ngarupakeun nilai dipulang ku iterator nu.
    ///
    ///
    /// `enumerate()` ngajaga count na salaku [`usize`].
    /// Mun rék cacah ku integer ukuran béda, anu fungsi [`zip`] nyadiakeun kagunaan sarupa.
    ///
    /// # Ngalangkungan Paripolah
    ///
    /// métode manten moal guarding ngalawan overflows, jadi enumerating leuwih ti elemen [`usize::MAX`] boh ngahasilkeun hasil salah atawa panics.
    /// Mun assertions debug nu diaktipkeun, hiji panic dijamin.
    ///
    /// # Panics
    ///
    /// Iterator anu dipulangkeun panginten panic upami indéks anu bakal dipulangkeun bakal ngabahekeun [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Nyiptakeun mangrupa iterator nu tiasa nganggo [`peek`] mun katingal di unsur saterusna iterator tanpa consuming eta.
    ///
    /// Nambihan metoda [`peek`] ka iterator.Tingali dokuméntasi na pikeun langkung seueur inpormasi.
    ///
    /// Catet yén iterator anu janten dasarna masih maju nalika [`peek`] disebat kanggo pertama kalina: Dina raraga milarian unsur salajengna, [`next`] disebat dina iterator anu janten dasarna, maka aya efek samping (ie
    ///
    /// nanaon lian ti nyandak nilai salajengna) tina metode [`next`] bakal kajantenan.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() hayu urang tingali kana future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // urang tiasa peek() sababaraha kali, iteratorna moal maju
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // saatos iterator réngsé, kitu ogé peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Nyiptakeun mangrupa iterator yén elemen [`skip`] s dumasar kana predikat hiji.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` nyokot panutupanana salaku hiji argumen.Éta bakal nyauran panutupanana ieu pikeun masing-masing unsur iterator, sareng teu malire unsur dugi ka ngahasilkeun `false`.
    ///
    /// Saatos `false` geus balik, `skip_while()`'s pakasaban mangrupa leuwih, sarta sesa elemen anu yielded.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kusabab panutupan anu diliwatan ka `skip_while()` butuh rujukan, sareng seueur iterator ngagitar rujukan, ieu ngakibatkeun kaayaan anu matak lieur, dimana jinis argumen penutupan mangrupikeun référénsi dobel:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // peryogi dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping sanggeus hiji `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // bari kieu bakal geus palsu, saprak urang geus ngagaduhan palsu a, skip_while() teu dipake sagala beuki
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Nyiptakeun mangrupa iterator nu ngahasilkeun elemen dumasar kana predikat hiji.
    ///
    /// `take_while()` nyokot panutupanana salaku hiji argumen.Bakal nelepon panutupanana ieu dina unggal unsur iterator, sarta ngahasilkeun elemen bari eta mulih `true`.
    ///
    /// Saatos `false` geus balik, `take_while()`'s pakasaban mangrupa leuwih, sarta sesa elemen anu teu dipalire.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kusabab panutupan anu diliwatan ka `take_while()` butuh rujukan, sareng seueur iterator ngagitar rujukan, ieu ngakibatkeun kaayaan anu matak lieur, dimana jinis panutupan mangrupikeun référénsi dobel:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // peryogi dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping sanggeus hiji `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Kami gaduh langkung seueur unsur anu kirang ti nol, tapi kusabab urang parantos ngagaduhan palsu, take_while() henteu dianggo deui
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kusabab `take_while()` perlu kasampak di nilai guna tingali lamun kudu kaasup atawa henteu, consuming iterators baris nempo yén éta dipiceun:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` parantos teu aya deui, sabab dikonsumsi pikeun ningali naha iterasi kedahna dieureunkeun, tapi henteu disimpen deui dina iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Nyiptakeun iterator anu duanana ngahasilkeun unsur dumasar kana prédikat sareng peta.
    ///
    /// `map_while()` nyandak panutupanana salaku argumen.
    /// Éta bakal nyauran panutupanana ieu pikeun masing-masing unsur iterator, sareng ngahasilkeun elemen nalika ngahasilkeun [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Di dieu teh conto anu sarua, tapi ku [`take_while`] na [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stopping sanggeus hiji [`None`] awal:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Kami gaduh langkung seueur elemen anu tiasa pas dina u32 (4, 5), tapi `map_while` ngabalikeun `None` kanggo `-3` (nalika `predicate` balik `None`) sareng `collect` lirén dina `None` anu munggaran karandapan.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Kusabab `map_while()` perlu kasampak di nilai guna tingali lamun kudu kaasup atawa henteu, consuming iterators baris nempo yén éta dipiceun:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `-3` geus euweuh aya, sabab ieu dikonsumsi dina urutan ningali lamun Iteration nu kudu eureun, tapi teu nempatkeun deui kana iterator nu.
    ///
    /// Catetan yen kawas [`take_while`] iterator ieu **moal** datar.
    /// Hal ieu ogé teu dieusian naon iterator ieu mulih saatos [`None`] munggaran ieu balik.
    /// Upami anjeun peryogi Iterator sekering, anggo [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Nyiptakeun mangrupa iterator yén skips unsur `n` munggaran.
    ///
    /// Sanggeus aranjeunna geus dihakan, sesa elemen anu yielded.
    /// Tinimbang overriding metoda ieu langsung, tinimbang override metoda `nth`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Nyiptakeun mangrupa iterator nu ngahasilkeun elemen `n` kahijina.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` sering dianggo nganggo iterator tanpa wates, pikeun ngajantenkeun terhingga:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Upami kirang ti `n` elemen sayogi, `take` bakalan nyalira kana ukuran iterator anu janten dasarna:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Hiji adaptor iterator sarupa [`fold`] nu nyepeng kaayaan internal tur ngahasilkeun iterator anyar.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` nyokot dua alesan: hiji nilai awal nu sikina kaayaan internal, sarta panutupanana dua alesan, nu keur mimiti hiji rujukan mutable kana kaayaan internal tur kadua unsur iterator.
    ///
    /// Panutupanana tiasa masihan kana kaayaan internal pikeun ngabagi kaayaan antara pangulangan.
    ///
    /// Dina iterasi, panutupan bakal dilarapkeun ka unggal unsur iterator sareng nilai balik tina panutupanana, [`Option`], dihasilkeun ku iterator.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // unggal Iteration, urang gé balikeun kaayaan nu ku unsur
    ///     *state = *state * x;
    ///
    ///     // teras, urang bakal ngahasilkeun negasi nagara
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Nyiptakeun iterator anu tiasa dianggo sapertos peta, tapi mendingan struktur bersarang.
    ///
    /// Adaptor [`map`] pohara kapaké, tapi ngan ukur nalika argumen panutupan ngahasilkeun nilai.
    /// Lamun ngahasilkeun iterator gantina, aya hiji lapisan tambahan tina indirection.
    /// `flat_map()` bakal miceun lapisan tambahan ieu nyalira.
    ///
    /// Anjeun tiasa mikir `flat_map(f)` salaku semantis sarua [`map`] ping, lajeng [`flatten`] ing sakumaha dina `map(f).flatten()`.
    ///
    /// Cara séjén tina pamikiran ngeunaan `flat_map()`: [`map`] 's panutupanana mulih hiji item pikeun tiap unsur, jeung `flat_map()`'s panutupanana mulih hiji iterator pikeun tiap unsur.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mulih pangirut
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Nyiptakeun mangrupa iterator yén flattens struktur nested.
    ///
    /// Ieu mangpaat nalika anjeun ngagaduhan iterator iterator atanapi iterator hal-hal anu tiasa dijantenkeun iterator sareng anjeun hoyong nyabut hiji tingkat indirection.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Pemetaan teras rata:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mulih pangirut
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Anjeun oge bisa nulis balik ieu dina watesan [`flat_map()`], nu leuwih hade dina hal ieu saprak eta conveys langkung hajat jelas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mulih pangirut
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening ukur ngaluarkeun satingkat ti nyarang dina hiji waktu:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Di dieu urang tingali yen `flatten()` henteu ngalakukeun rarata "deep".
    /// Gantina, ngan hiji tingkat nyarang geus dihapus.Nyaéta, upami anjeun `flatten()` rangkéan tilu diménsi, hasilna bakal dua diménsi sareng henteu hiji-diménsi.
    /// Pikeun meunangkeun struktur hiji-dimensi, Anjeun kudu `flatten()` deui.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Nyiptakeun iterator anu réngsé saatos [`None`] munggaran.
    ///
    /// Sanggeus hiji iterator mulih [`None`], nelepon future bisa atawa teu ngahasilkeun [`Some(T)`] deui.
    /// `fuse()` diluyukeun hiji iterator, mastikeun yén sanggeus [`None`] dirumuskeun, éta salawasna bakal balik [`None`] salawasna.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // iterator anu silih ganti antara Sababaraha sareng Teu aya
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // lamun éta malah, Some(i32), lain Euweuh
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // urang tiasa ningali urang iterator deui bade sarta mudik
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tapi, sakali kami sekering ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // eta bakal salawasna balik `None` sanggeus pertama kalina.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Teu hal kalawan unggal unsur hiji iterator, ngaliwatan nilai on.
    ///
    /// Lamun maké iterators, anjeun gé mindeng ranté sababaraha di antarana babarengan.
    /// Bari digawé dina kode misalna, anjeun bisa jadi hoyong pariksa kaluar naon lumangsung di sagala rupa penjuru di pipa nu.Jang ngalampahkeun anu, nyelapkeun panggero pikeun `inspect()`.
    ///
    /// Ieu leuwih umum pikeun `inspect()` bisa dipaké salaku alat debugging ti keur aya di kode final anjeun, tapi aplikasi bisa manggihan eta mangpaat dina situasi nu tangtu lamun kasalahan perlu log saméméh keur dipiceun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // runtuyan iterator ieu kompléks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // hayu urang tambahkeun sababaraha nelepon inspect() pikeun nalungtik naon lumangsung
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ieu bakal nyitak:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logging kasalahan saméméh discarding aranjeunna:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ieu bakal nyitak:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Borrows hiji iterator, tinimbang consuming eta.
    ///
    /// Ieu téh boga mangpaat pikeun ngawenangkeun nerapkeun adapters iterator bari tetep panahan kapamilikan ti iterator aslina.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // lamun urang nyobaan ngagunakeun iter deui, eta moal jalan.
    /// // Garis handap méré "kasalahan: pamakéan nilai dipindahkeun: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // hayu urang cobian deui
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // tibatan, urang tambahkeun dina .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ayeuna ieu henteu kunanaon:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Ngarobih iterator kana kumpulan.
    ///
    /// `collect()` tiasa nyandak naon waé anu tiasa diémut deui, sareng ngajantenkeun janten kumpulan anu aya hubunganana.
    /// Ieu salah sahiji metodeu leuwih kuat dina perpustakaan baku, dipaké dina rupa-rupa konteks.
    ///
    /// Pola paling dasar anu dianggo `collect()` nyaéta ngarobah hiji kumpulan kana kumpulan anu sanés.
    /// Anjeun butuh kempelan a, nelepon [`iter`] ka dinya, lampahkeun kebat transformasi, lajeng `collect()` dina tungtungna.
    ///
    /// `collect()` ogé bisa nyieun instansi tina jenis anu teu kumpulan has.
    /// Contona, hiji [`String`] bisa diwangun tina [`char`] s, sarta hiji iterator of [`Result<T, E>`][`Result`] item bisa dikumpulkeun kana `Result<Collection<T>, E>`.
    ///
    /// Ningali conto di handap pikeun leuwih lengkep.
    ///
    /// Kusabab `collect()` umum pisan, éta tiasa nyababkeun masalah sareng inferensi jinis.
    /// Salaku misalna, `collect()` mangrupa salah sahiji ti saeutik kali maneh bakal ningali rumpaka affectionately dipikawanoh salaku 'turbofish': `::<>`.
    /// Ieu ngabantuan algoritma inferensi ngartos husus nu kempelan nu nuju nyobian pikeun ngumpulkeun kana.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Catetan yen urang diperlukeun teh `: Vec<i32>` di sisi kénca-leungeun.Ieu kusabab urang tiasa ngempelkeun, contona, [`VecDeque<T>`] wae:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Ngagunakeun 'turbofish' tinimbang annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Kusabab `collect()` ngan ukur paduli kana naon anu anjeun kumpulkeun, anjeun masih tiasa nganggo hint tip parsial, `_`, kalayan turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ngagunakeun `collect()` nyieun hiji [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Upami Anjeun gaduh daptar [`hasilna<T, E>`][`Hasil`], anjeun tiasa nganggo `collect()` pikeun ningali naha salah sahiji gagal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // méré urang kasalahan munggaran
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // méré urang daptar waleran
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Meakeun hiji iterator, nyieun dua kumpulan ti eta.
    ///
    /// Prédikat anu dialirkeun ka `partition()` tiasa mulih `true`, atanapi `false`.
    /// `partition()` mulih wae, sakabéh unsur nu eta balik `true`, sarta sakabéh unsur nu eta balik `false`.
    ///
    ///
    /// Tingali ogé [`is_partitioned()`] sareng [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders unsur iterator kieu *di-tempat* nurutkeun kana predikat dibikeun, sapertos nu sakabeh jalma anu balik `true` miheulaan sakabeh jalma anu balik `false`.
    ///
    /// Mulih jumlah elemen `true` kapanggih.
    ///
    /// Urutan relatif barang bagi teu dijaga.
    ///
    /// Tempo ogé [`is_partitioned()`] na [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partisi dina-tempat antara evens na odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kedah kami salempang ngeunaan overflowing count?Hiji-hijina cara pikeun ngagaduhan langkung ti
        // `usize::MAX` rujukan mutable nyaéta kalayan ZSTs, nu teu mangpaat kana partisi ...

        // panutupanana fungsi "factory" ieu aya ulah genericity di `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Terusan milari `false` anu munggaran sareng gentoskeun sareng `true` terakhir.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Cék lamun unsur ieu iterator anu bagi nurutkeun kana predikat dibikeun, sapertos nu sakabeh jalma anu balik `true` miheulaan sakabeh jalma anu balik `false`.
    ///
    ///
    /// Tempo ogé [`partition()`] na [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Boh sadaya item nguji `true`, atawa klausa kahiji eureun di `false` na urang pariksa yen aya euweuh deui `true` item sanggeus éta.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Hiji metodeu iterator nu manglaku fungsi hiji salami eta mulih hasil, ngahasilkeun hiji, nilai final tunggal.
    ///
    /// `try_fold()` nyokot dua alesan: hiji nilai awal, sarta panutupanana dua alesan: hiji 'accumulator', sarta unsur.
    /// Panutupanana tiasa hasil deui, kalayan nilai anu kedah dina akumulator pikeun iterasi salajengna, atanapi éta ngahasilkeun kagagalan, ku nilai kasalahan anu disebarkeun deui ka anu nelepon langsung (short-circuiting).
    ///
    ///
    /// Nilai awal ngarupakeun nilai accumulator bakal mibanda dina panggero munggaran.Mun nerapkeun panutupanana nu hasil ngalawan unggal unsur iterator nu, `try_fold()` mulih ka accumulator final jadi sukses.
    ///
    /// Tilepan gunana iraha waé anjeun ngagaduhan kumpulan naon waé, sareng hoyong ngahasilkeun hiji nilai tina éta.
    ///
    /// # Catetan kana Implementors
    ///
    /// Sababaraha sahiji metodeu (forward) lianna mibanda implementations standar dina watesan ieu, jadi coba nerapkeun ieu kuduna lamun eta bisa ngalakukeun hal hadé batan standar `for` palaksanaan loop.
    ///
    /// Dina sababaraha hal, coba mun boga panggero ieu `try_fold()` dina bagian internal tina anu iterator ieu diwangun.
    /// Upami sababaraha telepon diperyogikeun, operator `?` panginten langkung merenah pikeun ngarangking nilai akumulator sasarengan, tapi waspada ka saha waé invarian anu kedah dijaga sateuacan éta pangunjung anu mimiti.
    /// Ieu metoda `&mut self`, jadi Iteration perlu jadi resumable sanggeus nganiaya kasalahan di dieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah dipariksa tina sakabéh unsur Asép Sunandar Sunarya dina
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Jumlah ieu overflows nalika nambahkeun 100 unsur
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Kusabab éta pondok-sirkuit, elemen sésana masih aya ku éta iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metode iterator anu nerapkeun fungsi anu lepat pikeun unggal item dina iterator, ngeureunkeun kasalahan anu munggaran sareng ngabalikeun kasalahan éta.
    ///
    ///
    /// Ieu ogé bisa dianggap salaku wujud fallible of [`for_each()`] atanapi sakumaha versi stateless of [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Eta pondok-circuited, jadi item sésana kénéh di iterator nu:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Ngawujud tina tilepan unggal unsur kana hiji accumulator ku nerapkeun hiji operasi, balik hasil ahir.
    ///
    /// `fold()` nyokot dua alesan: hiji nilai awal, sarta panutupanana dua alesan: hiji 'accumulator', sarta unsur.
    /// panutupanana nu mulih ka nilai anu accumulator kudu boga keur Iteration salajengna.
    ///
    /// Nilai awal ngarupakeun nilai accumulator bakal mibanda dina panggero munggaran.
    ///
    /// Saatos nerapkeun panutupanana ieu unggal unsur iterator nu, `fold()` mulih accumulator nu.
    ///
    /// Operasi ieu kadangkala disebut 'reduce' atanapi 'inject'.
    ///
    /// Tilepan gunana iraha waé anjeun ngagaduhan kumpulan naon waé, sareng hoyong ngahasilkeun hiji nilai tina éta.
    ///
    /// Note: `fold()`, sarta metoda nu sarupa nu Plawangan sakabéh iterator, bisa jadi teu nungtungan pikeun iterators wates, sanajan dina traits keur nu hasilna mangrupa determinable dina jangka waktu terhingga.
    ///
    /// Note: [`reduce()`] bisa dipaké ngagunakeun unsur kahiji salaku nilai awal, lamun tipe accumulator sarta tipe item nya sami.
    ///
    /// # Catetan kana Implementors
    ///
    /// Sababaraha sahiji metodeu (forward) lianna mibanda implementations standar dina watesan ieu, jadi coba nerapkeun ieu kuduna lamun eta bisa ngalakukeun hal hadé batan standar `for` palaksanaan loop.
    ///
    ///
    /// Dina sababaraha hal, coba mun boga panggero ieu `fold()` dina bagian internal tina anu iterator ieu diwangun.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah tina sakabéh unsur Asép Sunandar Sunarya
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Hayu urang ngalangkungan unggal léngkah pangulangan di dieu:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Jeung kitu, hasilna final urang, `6`.
    ///
    /// Eta urang umum pikeun jalma nu teu dipaké iterators pisan ngagunakeun a loop `for` kalawan daptar hal pikeun ngawangun nepi hasilna.Éta tiasa dijantenkeun `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pikeun loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // aranjeunna geus sami
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ngurangan elemen ka hiji tunggal, ku terus-terusan nerapkeun operasi ngurangan.
    ///
    /// Upami iterator kosong, mulih [`None`];disebutkeun, mulih hasil tina ngurangan teh.
    ///
    /// Pikeun iterators kalawan sahanteuna hiji unsur, ieu téh sarua jeung [`fold()`] kalawan unsur kahiji tina iterator salaku nilai awal, tilepan unggal unsur saterusna kana eta.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Manggihkeun nilai maksimum:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tés lamun unggal unsur iterator nu cocog predikat hiji.
    ///
    /// `all()` nyokot panutupanana yen mulih `true` atanapi `false`.Éta nerapkeun panutupanana ieu pikeun masing-masing unsur iterator, sareng upami aranjeunna sadayana mulih `true`, maka `all()` ogé.
    /// Lamun salah sahiji aranjeunna balik `false`, éta mulih `false`.
    ///
    /// `all()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas eta manggih hiji `false`, nunjukkeun yen euweuh urusan naon wae kajadian, hasilna oge bakal `false`.
    ///
    ///
    /// Hiji iterator kosong mulih `true`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stopping di `false` mimiti:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tés lamun sagala unsur iterator nu cocog predikat hiji.
    ///
    /// `any()` nyokot panutupanana yen mulih `true` atanapi `false`.Éta nerapkeun panutupanana ieu pikeun masing-masing unsur iterator, sareng upami salah sahiji di antawisna mulih `true`, maka `any()` ogé.
    /// Mun aranjeunna sadayana balik `false`, éta mulih `false`.
    ///
    /// `any()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas eta manggih hiji `true`, nunjukkeun yen euweuh urusan naon wae kajadian, hasilna oge bakal `true`.
    ///
    ///
    /// Iterator kosong mulih `false`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Eureun dina `true` munggaran:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Neangan hiji unsur hiji iterator yén satisfies predikat hiji.
    ///
    /// `find()` nyokot panutupanana yen mulih `true` atanapi `false`.
    /// Ieu lumaku panutupanana ieu unggal unsur iterator, sarta lamun salah sahiji aranjeunna balik `true`, teras `find()` mulih [`Some(element)`].
    /// Upami aranjeunna sadayana mulih `false`, éta mulih [`None`].
    ///
    /// `find()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas panutupanana nu mulih `true`.
    ///
    /// Kusabab `find()` nyokot rujukan, sarta loba iterators iterate leuwih rujukan, ngawujud ieu kaayaan jigana matak ngabingungkeun mana argumen mangrupakeun rujukan ganda.
    ///
    /// Anjeun tiasa ningali efek ieu conto di handap, kalawan `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Eureun dina `true` munggaran:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Catet yén `iter.find(f)` sami sareng `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Manglaku fungsi kana unsur iterator na mulih hasil non-ngaping munggaran.
    ///
    ///
    /// `iter.find_map(f)` sarua jeung `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Manglaku fungsi kana unsur iterator na mulih hasil leres kahiji atawa kasalahan munggaran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Neangan unsur dina iterator, balik indéks na.
    ///
    /// `position()` nyokot panutupanana yen mulih `true` atanapi `false`.
    /// Ieu lumaku panutupanana ieu unggal unsur iterator, sarta lamun salah sahijina mulih `true`, teras `position()` mulih [`Some(index)`].
    /// Mun sakabéh éta balik `false`, éta mulih [`None`].
    ///
    /// `position()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas eta manggih hiji `true`.
    ///
    /// # Ngalangkungan Paripolah
    ///
    /// Metoda na henteu ngajagaan ngalawan arus teuing, janten upami aya langkung ti [`usize::MAX`] elemen anu teu cocog, éta ngahasilkeun hasil anu salah atanapi panics.
    ///
    /// Mun assertions debug nu diaktipkeun, hiji panic dijamin.
    ///
    /// # Panics
    ///
    /// Pungsi ieu meureun panic lamun iterator ngabogaan leuwih ti elemen non-cocog `usize::MAX`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Eureun dina `true` munggaran:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indéks anu dipulang gumantung kana kaayaan iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Milarian unsur dina iterator ti katuhu, balikkeun indéks na.
    ///
    /// `rposition()` nyokot panutupanana yen mulih `true` atanapi `false`.
    /// Éta nerapkeun panutupanana ieu pikeun masing-masing unsur iterator, mimitian ti tungtungna, sareng upami salah sahijina mulih `true`, maka `rposition()` mulih [`Some(index)`].
    ///
    /// Mun sakabéh éta balik `false`, éta mulih [`None`].
    ///
    /// `rposition()` nyaeta pondok-circuiting;dina basa sejen, eta bakal eureun ngolah pas eta manggih hiji `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Eureun dina `true` munggaran:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // urang masih tiasa nganggo `iter`, sabab aya langkung seueur unsur.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Teu perlu pikeun mudal parios ka dieu, lantaran `ExactSizeIterator` ngakibatkeun yén Jumlah elemen fits kana `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Mulih unsur maksimum hiji iterator.
    ///
    /// Upami sababaraha unsur sami-sami maksimal, unsur pamungkas wangsul.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Mulih unsur minimum hiji iterator.
    ///
    /// Upami sababaraha unsur sami-sami minimum, unsur anu munggaran dipulangkeun.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Mulih unsur anu masihan nilai maksimum tina fungsi anu parantos ditangtukeun.
    ///
    ///
    /// Upami sababaraha unsur sami-sami maksimal, unsur pamungkas wangsul.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Mulih unsur anu masihan nilai maksimum perkawis fungsi ngabandingkeun anu parantos ditangtoskeun.
    ///
    ///
    /// Upami sababaraha unsur sami-sami maksimal, unsur pamungkas wangsul.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Mulih unsur nu méré nilai minimum tina fungsi husus.
    ///
    ///
    /// Upami sababaraha unsur sami-sami minimum, unsur anu munggaran dipulangkeun.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Mulih unsur nu méré nilai minimum jeung hormat kana fungsi ngabandingkeun ditangtukeun.
    ///
    ///
    /// Upami sababaraha unsur sami-sami minimum, unsur anu munggaran dipulangkeun.
    /// Mun iterator nu kosong, [`None`] geus balik.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ngabalikeun arah iterator.
    ///
    /// Biasana, iterator iterate ti kénca ka katuhu.
    /// Sanggeus ngagunakeun `rev()`, hiji iterator bakal gantina iterate ti katuhu ka kenca.
    ///
    /// Ieu tiasa dilakukeun upami iterator parantos aya tungtungna, janten `rev()` ngan ukur dianggo dina [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Ngarobah hiji iterator pasangan kana sapasang peti.
    ///
    /// `unzip()` meakeun hiji sakabéh iterator pasangan, ngahasilkeun dua kumpulan: hiji tina elemen kénca ti pasangan, sarta salah sahiji ti elemen katuhu.
    ///
    ///
    /// fungsi ieu, dina sababaraha rasa, sabalikna ti [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Nyiptakeun mangrupa iterator nu salinan sakabéh elemen na.
    ///
    /// Ieu mangpaat lamun anjeun boga hiji iterator leuwih `&T`, tapi nu peryogi hiji iterator leuwih `T`.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ditiron sarua .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Nyiptakeun mangrupa iterator mana [`clone`] s sakabéh elemen na.
    ///
    /// Ieu mangpaat lamun anjeun boga hiji iterator leuwih `&T`, tapi nu peryogi hiji iterator leuwih `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // diklon sarua .map(|&x| x), pikeun wilangan buleud
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ngulang iterator sajajalan.
    ///
    /// Gantina stopping di [`None`], iterator gaganti bakal ngamimitian deui, ti mimiti.Saatos iterating deui, eta bakal ngamimitian di awal deui.Sareng deuih.
    /// Sareng deuih.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Jumlah unsur éter.
    ///
    /// Butuh unggal unsur, nambihan duanana babarengan, sarta mulih hasilna.
    ///
    /// Hiji iterator kosong mulih nilai enol ngeunaan jenis teh.
    ///
    /// # Panics
    ///
    /// Nalika nelepon `sum()` sarta tipe integer primitif keur balik, metoda ieu bakal panic lamun overflows ngitung na assertions debug nu diaktipkeun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates leuwih sakabéh iterator, ngalikeun sakabeh elemen
    ///
    /// Iterator kosong ngasilkeun hiji nilai tina jinisna.
    ///
    /// # Panics
    ///
    /// Nalika nelepon `product()` sarta tipe integer primitif keur balik, metoda moal panic lamun overflows ngitung na assertions debug nu diaktipkeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares unsur [`Iterator`] kieu jeung pamadegan sejen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ngabandingkeun unsur [`Iterator`] ieu sareng anu sanés anu aya hubunganana sareng fungsi ngabandingkeun anu parantos ditangtoskeun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) compares unsur [`Iterator`] kieu jeung pamadegan sejen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ngabandingkeun unsur [`Iterator`] ieu sareng anu sanés anu aya hubunganana sareng fungsi ngabandingkeun anu parantos ditangtoskeun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Nangtukeun naha unsur [`Iterator`] ieu sami sareng anu sanés.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Nangtukeun upami unsur [`Iterator`] ieu téh sarua jeung pamadegan sejen kalayan hormat ka fungsi sarua ditangtukeun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Nangtukeun naha unsur [`Iterator`] ieu henteu sami sareng anu sanés.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Nangtukeun upami unsur [`Iterator`] ieu téh [lexicographically](Ord#lexicographical-comparison) kirang ti pamadegan sejen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Nangtukeun naha unsur [`Iterator`] ieu [lexicographically](Ord#lexicographical-comparison) kirang atanapi sami sareng anu sanés.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Nangtukeun naha unsur [`Iterator`] ieu [lexicographically](Ord#lexicographical-comparison) langkung ageung tibatan anu sanés.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Nangtukeun upami unsur [`Iterator`] ieu téh [lexicographically](Ord#lexicographical-comparison) gede ti atanapi sarua jeung pamadegan sejen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Cék lamun unsur iterator ieu dumasar.
    ///
    /// Hartina, tiap unsur `a` sarta unsur na di handap `b`, `a <= b` kedah tahan.Upami iterator ngahasilkeun persis enol atanapi hiji unsur, `true` dipulangkeun.
    ///
    /// Catet yén upami `Self::Item` ngan ukur `PartialOrd`, tapi sanés `Ord`, watesan di luhur nunjukkeun yén fungsi ieu mulih `false` upami aya dua barang anu teras-terasan henteu tiasa dibandingkeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Cék lamun unsur iterator ieu dumasar maké fungsi comparator nu tinangtu.
    ///
    /// Gantina make `PartialOrd::partial_cmp`, fungsi ieu migunakeun fungsi `compare` nu dibéré pikeun nangtukeun nyusun dua elemen.
    /// Sajaba ti eta, éta sarua jeung [`is_sorted`];tingali dokuméntasi na kanggo inpormasi lengkep.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Cék lamun unsur iterator ieu dumasar maké fungsi ékstraksi konci nu tinangtu.
    ///
    /// Gantina ngabandingkeun elemen nu iterator urang langsung, fungsi ieu compares kenop sahiji elemen, sakumaha ditangtukeun ku `f`.
    /// Sajaba ti eta, éta sarua jeung [`is_sorted`];tingali dokuméntasi na kanggo inpormasi lengkep.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Tingali [TrustedRandomAccess]
    // Ngaran ilahar téh ulah collisions ngaran dina resolusi metoda tingali #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}