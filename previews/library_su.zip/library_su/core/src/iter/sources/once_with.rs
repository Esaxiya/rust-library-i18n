use crate::iter::{FusedIterator, TrustedLen};

/// Nyiptakeun iterator anu teu puguh ngahasilkeun nilai persis sakali ku nyalukan panutupan anu disayogikeun.
///
/// Ieu ilaharna dipaké pikeun adaptasi hiji nilai generator tunggal kana [`chain()`] tina jinis séjénna Iteration.
/// Meureun anjeun gaduh iterator anu nyertakeun ampir sadayana, tapi anjeun peryogi kasus anu khusus.
/// Meureun anjeun gaduh fungsi nu gawéna dina iterators, tapi maneh ukur perlu ngolah hiji nilai.
///
/// Teu kawas [`once()`], fungsi ieu lazily bakal ngahasilkeun nilai on pamundut.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::iter;
///
/// // hiji mangrupikeun nomer anu paling sepi
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ngan salah sahiji, éta kabéh urang meunang
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining bareng jeung iterator sejen.
/// Hayu urang nyebutkeun yén urang rék iterate leuwih tiap file tina diréktori `.foo`, tapi ogé mangrupa file konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // urang kedah ngarobih tina iterator DirEntry-s ka iterator PathBufs, janten kami nganggo peta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ayeuna, iterator kami ngan ukur pikeun file config kami
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ranté dua iterators ngahiji jadi hiji iterator badag
/// let files = dirs.chain(config);
///
/// // ieu bakal masihan urang sakabéh payil dina .foo ogé .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Hiji iterator nu ngahasilkeun unsur tunggal tipe `A` ku nerapkeun panutupanana disadiakeun `F: FnOnce() -> A`.
///
///
/// `struct` ieu diciptakeun ku fungsi [`once_with()`].
/// Tingali dokuméntasi na pikeun langkung seueur.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}