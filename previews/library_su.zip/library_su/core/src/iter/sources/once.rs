use crate::iter::{FusedIterator, TrustedLen};

/// Nyiptakeun iterator anu ngahasilkeun elemen persis sakali.
///
/// Ieu ilaharna dipaké pikeun adaptasi hiji nilai tunggal kana [`chain()`] tina jinis séjénna Iteration.
/// Meureun anjeun gaduh iterator anu nyertakeun ampir sadayana, tapi anjeun peryogi kasus anu khusus.
/// Meureun anjeun gaduh fungsi nu gawéna dina iterators, tapi maneh ukur perlu ngolah hiji nilai.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::iter;
///
/// // hiji mangrupikeun nomer anu paling sepi
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ngan salah sahiji, éta kabéh urang meunang
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining bareng jeung iterator sejen.
/// Hayu urang nyebutkeun yén urang rék iterate leuwih tiap file tina diréktori `.foo`, tapi ogé mangrupa file konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // urang kedah ngarobih tina iterator DirEntry-s ka iterator PathBufs, janten kami nganggo peta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ayeuna, iterator kami ngan ukur pikeun file config kami
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ranté dua iterators ngahiji jadi hiji iterator badag
/// let files = dirs.chain(config);
///
/// // ieu bakal masihan urang sakabéh payil dina .foo ogé .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Hiji iterator nu ngahasilkeun unsur persis sakali.
///
/// `struct` ieu dijieun ku fungsi [`once()`].Tempo dokuméntasi na pikeun leuwih lengkep.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}