use crate::iter::{FusedIterator, TrustedLen};

/// Nyiptakeun iterator anyar nu endlessly repeats unsur tunggal.
///
/// Fungsi `repeat()` ngulang hiji nilai sakali-kali.
///
/// iterators wates kawas `repeat()` anu mindeng dipaké ku adapters kawas [`Iterator::take()`], dina urutan sangkan aranjeunna terhingga.
///
/// Upami jinis unsur iterator anu anjeun peryogikeun henteu nerapkeun `Clone`, atanapi upami anjeun henteu hoyong nyimpen unsur anu diulang dina mémori, anjeun tiasa nganggo fungsi [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::iter;
///
/// // jumlah opat 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, masih opat
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Bade dugi ka [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // conto anu terakhir éta seueur teuing opat.Hayu urang ukur boga opat fours.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... sareng ayeuna urang parantos bérés
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Hiji iterator yén repeats unsur endlessly.
///
/// `struct` ieu dijieun ku fungsi [`repeat()`].Tempo dokuméntasi na pikeun leuwih lengkep.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}