use crate::iter::{FusedIterator, TrustedLen};

/// Nyiptakeun iterator anyar anu ngulang unsur jinis `A` sajajalan ku nerapkeun panutupanana anu disayogikeun, repeater, `F: FnMut() -> A`.
///
/// Fungsi `repeat_with()` nyaéta panggero anu repeater leuwih sarta leuwih deui.
///
/// iterators wates kawas `repeat_with()` anu mindeng dipaké ku adapters kawas [`Iterator::take()`], dina urutan sangkan aranjeunna terhingga.
///
/// Mun jinis unsur iterator nu nu peryogi implements [`Clone`], sarta éta OKE pikeun nyimpen unsur sumber dina mémori, anjeun kedah gantina nganggo fungsi [`repeat()`].
///
///
/// Hiji iterator dihasilkeun `repeat_with()` sanes a [`DoubleEndedIterator`].
/// Lamun perlu `repeat_with()` balik a [`DoubleEndedIterator`], mangga buka hiji masalah GitHub dijelaskeun hal pamakéan Anjeun.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::iter;
///
/// // hayu urang nganggap urang gaduh sababaraha nilai tina hiji jenis anu teu `Clone` atanapi nu teu hayang boga dina mémori ngan acan sabab geus mahal:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // nilai hususna salamina:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Ngagunakeun mutasi sareng bade terwates:
///
/// ```rust
/// use std::iter;
///
/// // Ti zeroth kana kakuatan katilu tina dua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... sareng ayeuna urang parantos bérés
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Hiji iterator yén repeats unsur tipe `A` endlessly ku nerapkeun panutupanana disadiakeun `F: FnMut() -> A`.
///
///
/// `struct` ieu dijieun ku fungsi [`repeat_with()`].
/// Tingali dokuméntasi na pikeun langkung seueur.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}