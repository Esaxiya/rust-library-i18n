use crate::fmt;

/// Nyiptakeun iterator anyar mana tiap Iteration nyaéta panggero panutupanana `F: FnMut() -> Option<T>` nu disadiakeun.
///
/// Hal ieu ngamungkinkeun nyiptakeun iterator khusus kalayan perilaku naon waé tanpa ngagunakeun sintaksis langkung verosa pikeun nyiptakeun jinis anu khusus sareng ngalaksanakeun [`Iterator`] trait pikeun éta.
///
/// Catetan yén `FromFn` iterator henteu nyieun asumsi ngeunaan paripolah panutupanana, sarta ku kituna kolot henteu nerapkeun [`FusedIterator`], atawa override [`Iterator::size_hint()`] tina standar na `(0, None)`.
///
///
/// panutupanana nu tiasa nganggo ngarebut sarta lingkunganna lagu kaayaan sakuliah iterations.Gumantung kana kumaha iterator dipaké, ieu bisa merlukeun nangtukeun keyword [`move`] on panutupanana nu.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Hayu urang nerapkeun deui iterator counter ti [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Increment count urang.Ieu naha urang dimimitian di nol.
///     count += 1;
///
///     // Pariksa pikeun ningali naha urang parantos réngsé ngitung atanapi henteu.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Hiji iterator dimana unggal Iteration nyaéta panggero panutupanana `F: FnMut() -> Option<T>` nu disadiakeun.
///
/// `struct` ieu dijieun ku fungsi [`iter::from_fn()`].
/// Tingali dokuméntasi na pikeun langkung seueur.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}