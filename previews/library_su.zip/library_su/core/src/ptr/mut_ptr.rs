use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Mulih `true` upami panunjukna batal.
    ///
    /// Catet yén jenis anu teu diukur gaduh seueur kamungkinan petunjuk, sabab ukur panunjuk data atah anu dianggap, henteu panjangna, meja, sareng sajabana.
    /// Kusabab kitu, dua petunjuk anu batal tiasa tetep henteu ngabandingkeun sami-sami.
    ///
    /// ## Paripolah nalika evaluasi konst
    ///
    /// Nalika pungsi ieu dianggo nalika evaluasi konst, éta tiasa ngabalikeun `false` pikeun petunjuk anu tétéla janten batal dina runtime.
    /// Khususna, nalika pointer kana sababaraha mémori diimbangi saluareun batesan na sapertos anu nunjukkeun pointer anu batil, fungsina tetep bakal balikkeun `false`.
    ///
    /// Aya jalan pikeun CTFE apal kana posisi mutlak memori nu, sangkan teu bisa ngabejaan lamun pointer nyaeta hypothesis atanapi henteu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bandingkeun ngalangkungan cor ka pointer anu ipis, janten petunjuk anu gajih ngan ukur ngémutan bagian "data"-na pikeun batal.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Dihaturkeun kana panunjuk tina jinis sanés.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Ngurai titik (panginten lega) kana alamat sareng komponén metadata.
    ///
    /// Pointer tiasa engké didamel deui sareng [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Mulih `None` lamun pointer nyaeta hypothesis, atanapi mulih sejenna a rujukan dibagikeun ka nilai dibungkus dina `Some`.Upami nilaina tiasa uninitialized, [`as_uninit_ref`] kedah dianggo gantina.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Penunjuk kedah nunjuk kana conto anu dimimitian tina `T`.
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    /// (Bagéan ngeunaan diinisialisasi henteu acan diputuskeun sapinuhna, tapi dugi ka éta, hiji-hijina cara anu aman nyaéta pikeun mastikeun yén aranjeunna memang diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Vérsi anu teu dipariksa
    ///
    /// Mun anjeun yakin pointer nu pernah tiasa null sarta néangan sababaraha jenis `as_ref_unchecked` yen mulih teh `&T` tinimbang `Option<&T>`, nyaho yén anjeun bisa dereference pointer nu langsung.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAFETY: anu nelepon kedah ngajamin yén `self` valid pikeun a
        // rujukan upami éta henteu batal.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Mulihkeun `None` upami panunjukna batal, atanapi anu sanés mulihkeun rujukan anu dibagi kana nilai anu dibungkus `Some`.
    /// Béda sareng [`as_ref`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ngitung offset tina panunjuk.
    ///
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Upami salah sahiji kaayaan di handap ieu dilanggar, hasilna Undefined Paripolah:
    ///
    /// * Boh pointer anu ngamimitian sareng anu dihasilkeun kedahna bounds atanapi hiji byte ngalangkungan tungtung obyék anu sami dialokasikeun.
    /// Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// * The diitung offset,**dina bait**, moal bisa mudal hiji `isize`.
    ///
    /// * Offset anu aya dina wates moal tiasa ngandelkeun "wrapping around" ruang alamat.Nyaéta, jumlah anu teu aya watesna-presisi,**dina bait** kedah pas dina usize.
    ///
    /// Panyusun sareng perpustakaan standar umumna nyobian mastikeun alokasi henteu pernah dugi ka ukuran dimana offset mangrupikeun masalah.
    /// Misalna, `Vec` sareng `Box` mastikeun yén aranjeunna henteu kantos ngaluarkeun langkung ti `isize::MAX` bait, janten `vec.as_ptr().add(vec.len())` sok aman.
    ///
    /// Kaseueuran platform dasarna bahkan henteu tiasa ngawangun alokasi sapertos kitu.
    /// Salaku conto, henteu aya platform 64-bit anu dikenal anu kantos tiasa ngalayanan pamundut pikeun 2 <sup>63</sup> bait kusabab watesan halaman-méja atanapi meulah rohangan alamat.
    /// Nanging, sababaraha platform 32-bit sareng 16-bit tiasa hasil ngalayanan pamundut langkung ti `isize::MAX` bait ku hal-hal sapertos Physical Address Extension.
    ///
    /// Sapertos kitu, mémori anu dipikagaduh langsung ti pengatur atanapi file anu dipetakeun mémori *panginten* ageung teuing kanggo ngatur fungsi ieu.
    ///
    /// Pertimbangkeun ngagunakeun [`wrapping_offset`] tibatan upami kendala ieu hésé pikeun nyugemakeun.
    /// Hiji-hijina kaunggulan tina metode ieu nyaéta ngamungkinkeun optimisasi kompiler langkung agrésif.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `offset`.
        // Pointer anu diperyogikeun valid pikeun nyerat sabab anu nelepon kedah ngajamin yén éta nunjuk kana obyék anu dialokasikan sami sareng `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Ngitung offset tina panunjuk nganggo bungkus aritmatika.
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Operasi ieu nyalira sok aman, tapi nganggo pointer anu dihasilkeun henteu.
    ///
    /// Tetep pointer hasilna napel objek disadiakeun sarua yen `self` titik ka.
    /// Éta meureun *henteu* dianggo pikeun aksés ka obyék anu dialokasikan anu béda.Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// Kalayan kecap séjén, `let z = x.wrapping_offset((y as isize) - (x as isize))` henteu * ngajantenkeun `z` sami sareng `y` sanaos urang nganggap `T` ngagaduhan ukuran `1` sareng teu aya limpahan: `z` masih napel kana obyék `x` anu napel, sareng ngadéferénsi éta Undefined Paripolah kecuali `x` na `y` nunjuk kana obyék anu dialokasikan sami.
    ///
    /// Dibandingkeun sareng [`offset`], metoda ieu dina dasarna nyangsang sarat tetep dina obyék anu sami dialokasikan: [`offset`] nyaéta Perilaku Undefined langsung nalika nyebrang wates obyék;`wrapping_offset` ngahasilkeun pointer tapi masih ngawujud kana Undefined Paripolah lamun a pointer ieu dereferenced lamun kaluar-of-bounds sahiji obyek eta napel.
    /// [`offset`] tiasa dioptimalkeun langkung saé sahingga pikaresep dina kode sénsitip kinerja.
    ///
    /// Cék anu tunda ngan ukur nganggap nilai pointer anu didéferensikeun, sanés nilai panengah anu dianggo nalika ngitung hasil akhir.
    /// Contona, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` sok sarua sakumaha `x`.Kalayan kecap séjén, nyésakeun obyék anu dialokasikeun teras dilebetkeun deui engké diijinkeun.
    ///
    /// Upami anjeun kedah nyebrang wates obyék, tuang panunjuk kana integer sareng lakukeun aritmatika di dinya.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // Iterate nganggo pointer atah dina paningkatan dua unsur
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SAFETY: intrinsik `arith_offset` teu ngagaduhan prasyarat kanggo disebat.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Mulih `None` upami panunjukna batal, atanapi anu sanés mulihkeun rujukan unik kana nilai anu dibungkus `Some`.Upami nilaina tiasa uninitialized, [`as_uninit_mut`] kedah dianggo gantina.
    ///
    /// Pikeun anu tara dibagi tingali [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Penunjuk kedah nunjuk kana conto anu dimimitian tina `T`.
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    /// (Bagéan ngeunaan diinisialisasi henteu acan diputuskeun sapinuhna, tapi dugi ka éta, hiji-hijina cara anu aman nyaéta pikeun mastikeun yén aranjeunna memang diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Éta gé nyitak: "[4, 2, 3]".
    /// ```
    ///
    /// # Vérsi anu teu dipariksa
    ///
    /// Upami anjeun yakin pointer moal pernah null sareng milari sababaraha jenis `as_mut_unchecked` anu mulih `&mut T` tibatan `Option<&mut T>`, terang yén anjeun tiasa langsung milih pointer langsung.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Éta gé nyitak: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SAFETY: panelepon kedah ngajamin yén `self` leres kanggo
        // rujukan anu tiasa dirobih upami henteu batal.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Mulih `None` upami panunjukna batal, atanapi upami sanés mulihkeun rujukan unik kana nilai anu dibungkus `Some`.
    /// Béda sareng [`as_mut`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun anu tara dibagi tingali [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Mulih naha dua petunjuk dijamin sami.
    ///
    /// Dina runtime fungsi ieu sapertos `self == other`.
    /// Nanging, dina sababaraha kontéks (mis., Evaluasi kompilasi-waktos), henteu mungkin pikeun nangtoskeun persamaan dua pointer, janten fungsi ieu sacara spurious tiasa ngabalikeun `false` pikeun pointers anu engkéna tétéla sami.
    ///
    /// Tapi nalika éta ngasilkeun `true`, pointer dijamin sami.
    ///
    /// Fungsi ieu mangrupikeun kaca spion [`guaranteed_ne`], tapi henteu tibalik na.Aya babandingan pointer anu duanana fungsi balikkeun `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nilai balikna tiasa robih gumantung kana versi panyusun sareng kode anu teu aman panginten henteu gumantung kana hasil tina fungsi ieu pikeun kabersihan.
    /// Disarankeun ngan ukur nganggo fungsi ieu pikeun optimasi kinerja dimana nilai balik `false` palsu ku fungsi ieu henteu mangaruhan hasilna, tapi ngan ukur pagelaranana.
    /// Konsékuansi tina ngagunakeun cara ieu pikeun nyieun runtime sareng kode kompilasi-waktos kalakuan anu bénten-bénten teu acan digali.
    /// Cara ieu henteu kedah dianggo pikeun ngenalkeun bédana sapertos kitu, sareng éta ogé henteu kedah distabilkeun sateuacan urang langkung ngartos masalah ieu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Mulih naha dua petunjuk dijamin henteu sami.
    ///
    /// Dina runtime fungsi ieu sapertos `self != other`.
    /// Nanging, dina sababaraha kontéks (mis., Évaluasi kompilasi-waktos), henteu mungkin pikeun nangtoskeun henteu sami tina dua pointer, janten fungsi ieu sacara spurious tiasa ngabalikeun `false` pikeun pointer anu engkéna tétéla henteu sami.
    ///
    /// Tapi nalika éta ngasilkeun `true`, pointer dijamin henteu sami.
    ///
    /// Fungsi ieu mangrupikeun kaca spion [`guaranteed_eq`], tapi henteu tibalik na.Aya babandingan pointer anu duanana fungsi balikkeun `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nilai balikna tiasa robih gumantung kana versi panyusun sareng kode anu teu aman panginten henteu gumantung kana hasil tina fungsi ieu pikeun kabersihan.
    /// Disarankeun ngan ukur nganggo fungsi ieu pikeun optimasi kinerja dimana nilai balik `false` palsu ku fungsi ieu henteu mangaruhan hasilna, tapi ngan ukur pagelaranana.
    /// Konsékuansi tina ngagunakeun cara ieu pikeun nyieun runtime sareng kode kompilasi-waktos kalakuan anu bénten-bénten teu acan digali.
    /// Cara ieu henteu kedah dianggo pikeun ngenalkeun bédana sapertos kitu, sareng éta ogé henteu kedah distabilkeun sateuacan urang langkung ngartos masalah ieu.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Ngitung jarak antara dua pointer.Nilai balik aya dina hijian T: jarak dina bait dibagi ku `mem::size_of::<T>()`.
    ///
    /// Fungsi ieu tibalik tina [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Upami salah sahiji kaayaan di handap ieu dilanggar, hasilna Undefined Paripolah:
    ///
    /// * Boh anu ngamimitian sareng anu séjén nunjukkeun kedah aya dina wates atanapi hiji bait ngalangkungan tungtung obyék anu dialokasikan sami.
    /// Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// * Kadua petunjuk kedah *diturunkeun tina* panunjuk kana objék anu sami.
    ///   (Tingali di handap ieu contona.)
    ///
    /// * Jarak antara pointer, dina bait, kedahna sababaraha pasti tina ukuran `T`.
    ///
    /// * Jarak antara pointer,**dina bait**, moal tiasa overflow `isize`.
    ///
    /// * Jarak anu aya dina wates moal tiasa ngandelkeun "wrapping around" ruang alamat.
    ///
    /// Jinis Rust henteu pernah langkung ageung tibatan `isize::MAX` sareng Rust alokasi henteu pernah ngabungkus rohangan alamat, janten dua poin dina sababaraha nilai naon waé Rust tipe `T` bakal nyugemakeun dua kaayaan pamungkas.
    ///
    /// Perpustakaan standar ogé umumna mastikeun yén alokasi henteu pernah dugi kana ukuran anu dipikagaduh tina offset.
    /// Misalna, `Vec` sareng `Box` mastikeun yén aranjeunna henteu kantos ngaalokasikeun langkung ti `isize::MAX` bait, janten `ptr_into_vec.offset_from(vec.as_ptr())` salawasna nyugemakeun dua kaayaan pamungkas.
    ///
    /// Kaseueuran platform dasarna bahkan henteu tiasa nyusun alokasi ageung sapertos kitu.
    /// Salaku conto, henteu aya platform 64-bit anu dikenal anu kantos tiasa ngalayanan pamundut pikeun 2 <sup>63</sup> bait kusabab watesan halaman-méja atanapi meulah rohangan alamat.
    /// Nanging, sababaraha platform 32-bit sareng 16-bit tiasa hasil ngalayanan pamundut langkung ti `isize::MAX` bait ku hal-hal sapertos Physical Address Extension.
    /// Sapertos kitu, mémori anu dipikagaduh langsung ti pengatur atanapi file anu dipetakeun mémori *panginten* ageung teuing kanggo ngatur fungsi ieu.
    /// (Catet yén [`offset`] sareng [`add`] ogé ngagaduhan watesan anu sami sareng maka teu tiasa dianggo dina alokasi ageung sapertos kitu.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Fungsi panics ieu upami `T` mangrupikeun Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Teu leres* pamakean:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Janten ptr2_lain "alias" ptr2, tapi diturunkeun tina ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kusabab ptr2_other sareng ptr2 diturunkeun tina petunjuk kana objék anu béda, ngitung offset na nyaéta kalakuan anu teu ditangtoskeun, sanaos aranjeunna nunjuk kana alamat anu sami!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Kalakuan Anu Teu Ditetepkeun
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Ngitung offset tina panunjuk (genah pikeun `.offset(count as isize)`).
    ///
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Upami salah sahiji kaayaan di handap ieu dilanggar, hasilna Undefined Paripolah:
    ///
    /// * Boh pointer anu ngamimitian sareng anu dihasilkeun kedahna bounds atanapi hiji byte ngalangkungan tungtung obyék anu sami dialokasikeun.
    /// Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// * The diitung offset,**dina bait**, moal bisa mudal hiji `isize`.
    ///
    /// * Offset anu aya dina wates moal tiasa ngandelkeun "wrapping around" ruang alamat.Nyaéta, jumlah anu teu aya watesna-pasti kedah pas dina `usize`.
    ///
    /// Panyusun sareng perpustakaan standar umumna nyobian mastikeun alokasi henteu pernah dugi ka ukuran dimana offset mangrupikeun masalah.
    /// Misalna, `Vec` sareng `Box` mastikeun yén aranjeunna henteu kantos ngaluarkeun langkung ti `isize::MAX` bait, janten `vec.as_ptr().add(vec.len())` sok aman.
    ///
    /// Kaseueuran platform dasarna bahkan henteu tiasa ngawangun alokasi sapertos kitu.
    /// Salaku conto, henteu aya platform 64-bit anu dikenal anu kantos tiasa ngalayanan pamundut pikeun 2 <sup>63</sup> bait kusabab watesan halaman-méja atanapi meulah rohangan alamat.
    /// Nanging, sababaraha platform 32-bit sareng 16-bit tiasa hasil ngalayanan pamundut langkung ti `isize::MAX` bait ku hal-hal sapertos Physical Address Extension.
    ///
    /// Sapertos kitu, mémori anu dipikagaduh langsung ti pengatur atanapi file anu dipetakeun mémori *panginten* ageung teuing kanggo ngatur fungsi ieu.
    ///
    /// Pertimbangkeun ngagunakeun [`wrapping_add`] tibatan upami kendala ieu hésé pikeun nyugemakeun.
    /// Hiji-hijina kaunggulan tina metode ieu nyaéta ngamungkinkeun optimisasi kompiler langkung agrésif.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Etang offset ti pointer (genah keur `.offset ((cacah sakumaha isize).wrapping_neg())`).
    ///
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Upami salah sahiji kaayaan di handap ieu dilanggar, hasilna Undefined Paripolah:
    ///
    /// * Boh pointer anu ngamimitian sareng anu dihasilkeun kedahna bounds atanapi hiji byte ngalangkungan tungtung obyék anu sami dialokasikeun.
    /// Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// * Kompetisi offset moal tiasa ngaleuwihan `isize::MAX`**bait**.
    ///
    /// * offset mahluk dina bounds teu bisa ngandelkeun "wrapping around" rohangan alamat.Nyaéta, jumlah anu teu aya watesna-pasti kedah pas dina usize.
    ///
    /// Panyusun sareng perpustakaan standar umumna nyobian mastikeun alokasi henteu pernah dugi ka ukuran dimana offset mangrupikeun masalah.
    /// Misalna, `Vec` sareng `Box` mastikeun yén aranjeunna henteu kantos ngaluarkeun langkung ti `isize::MAX` bait, janten `vec.as_ptr().add(vec.len()).sub(vec.len())` sok aman.
    ///
    /// Kaseueuran platform dasarna bahkan henteu tiasa ngawangun alokasi sapertos kitu.
    /// Salaku conto, henteu aya platform 64-bit anu dikenal anu kantos tiasa ngalayanan pamundut pikeun 2 <sup>63</sup> bait kusabab watesan halaman-méja atanapi meulah rohangan alamat.
    /// Nanging, sababaraha platform 32-bit sareng 16-bit tiasa hasil ngalayanan pamundut langkung ti `isize::MAX` bait ku hal-hal sapertos Physical Address Extension.
    ///
    /// Sapertos kitu, mémori anu dipikagaduh langsung ti pengatur atanapi file anu dipetakeun mémori *panginten* ageung teuing kanggo ngatur fungsi ieu.
    ///
    /// Pertimbangkeun ngagunakeun [`wrapping_sub`] tibatan upami kendala ieu hésé pikeun nyugemakeun.
    /// Hiji-hijina kaunggulan tina metode ieu nyaéta ngamungkinkeun optimisasi kompiler langkung agrésif.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ngitung offset tina panunjuk nganggo bungkus aritmatika.
    /// (genah pikeun `.wrapping_offset(count as isize)`)
    ///
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Operasi ieu nyalira sok aman, tapi nganggo pointer anu dihasilkeun henteu.
    ///
    /// Tetep pointer hasilna napel objek disadiakeun sarua yen `self` titik ka.
    /// Éta meureun *henteu* dianggo pikeun aksés ka obyék anu dialokasikan anu béda.Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// Kalayan kecap séjén, `let z = x.wrapping_add((y as usize) - (x as usize))` henteu * ngajantenkeun `z` sami sareng `y` sanaos urang nganggap `T` ngagaduhan ukuran `1` sareng teu aya limpahan: `z` masih napel kana obyék `x` anu napel, sareng ngadéferénsi éta Undefined Paripolah kecuali `x` na titik `y` kana obyék disadiakeun sarua.
    ///
    /// Dibandingkeun sareng [`add`], metoda ieu dina dasarna nyangsang sarat tetep dina obyék anu sami dialokasikan: [`add`] nyaéta Perilaku Undefined langsung nalika nyebrang wates obyék;`wrapping_add` ngahasilkeun pointer tapi tetep nyababkeun Undefined Paripolah upami pointer diturunkeun nalika aya di luar wates objék anu dipasang na.
    /// [`add`] tiasa dioptimalkeun langkung saé sahingga pikaresep dina kode sénsitip kinerja.
    ///
    /// Cék anu tunda ngan ukur nganggap nilai pointer anu didéferensikeun, sanés nilai panengah anu dianggo nalika ngitung hasil akhir.
    /// Salaku conto, `x.wrapping_add(o).wrapping_sub(o)` sok sami sareng `x`.Kalayan kecap séjén, nyésakeun obyék anu dialokasikeun teras dilebetkeun deui engké diijinkeun.
    ///
    /// Upami anjeun kedah nyebrang wates obyék, tuang panunjuk kana integer sareng lakukeun aritmatika di dinya.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // Iterate nganggo pointer atah dina paningkatan dua unsur
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Loop ieu nyetak "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ngitung offset tina panunjuk nganggo bungkus aritmatika.
    /// (genah pikeun `.wrapping_offset ((kaitung isize).wrapping_neg())`)
    ///
    /// `count` aya dina hijian T;contona, `count` of 3 ngagambarkeun pointer offset `3 * size_of::<T>()` bait.
    ///
    /// # Safety
    ///
    /// Operasi ieu nyalira sok aman, tapi nganggo pointer anu dihasilkeun henteu.
    ///
    /// Tetep pointer hasilna napel objek disadiakeun sarua yen `self` titik ka.
    /// Éta meureun *henteu* dianggo pikeun aksés ka obyék anu dialokasikan anu béda.Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
    ///
    /// Kalayan kecap séjén, `let z = x.wrapping_sub((x as usize) - (y as usize))` henteu * ngajantenkeun `z` sami sareng `y` sanaos urang nganggap `T` ngagaduhan ukuran `1` sareng teu aya limpahan: `z` masih napel kana obyék `x` anu napel, sareng ngadéferénsi éta Undefined Paripolah kecuali `x` na `y` nunjuk kana obyék anu dialokasikan sami.
    ///
    /// Dibandingkeun sareng [`sub`], metoda ieu dina dasarna nyangsang sarat tetep dina obyék anu sami dialokasikan: [`sub`] nyaéta Perilaku Undefined langsung nalika nyebrang wates obyék;`wrapping_sub` ngahasilkeun pointer tapi tetep nyababkeun Undefined Paripolah upami pointer diturunkeun nalika aya di luar wates objék anu dipasang na.
    /// [`sub`] tiasa dioptimalkeun langkung saé sahingga pikaresep dina kode sénsitip kinerja.
    ///
    /// Cék anu tunda ngan ukur nganggap nilai pointer anu didéferensikeun, sanés nilai panengah anu dianggo nalika ngitung hasil akhir.
    /// Salaku conto, `x.wrapping_add(o).wrapping_sub(o)` sok sami sareng `x`.Kalayan kecap séjén, nyésakeun obyék anu dialokasikeun teras dilebetkeun deui engké diijinkeun.
    ///
    /// Upami anjeun kedah nyebrang wates obyék, tuang panunjuk kana integer sareng lakukeun aritmatika di dinya.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // Iterate nganggo pointer atah dina paningkatan dua unsur (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Loop ieu nyetak "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nyetél nilai pointer ka `ptr`.
    ///
    /// Upami `self` mangrupikeun pointer (fat) kana jinis anu teu diukur, operasi ieu ngan ukur bakal mangaruhan bagian pointer, padahal pikeun (thin) nunjuk kana ukuran anu ukuran, ieu pangaruhna sami sareng tugas anu saderhana.
    ///
    /// Penunjuk anu dihasilkeun bakal ngagaduhan hasil tina `val`, nyaéta pikeun pitunjuk gajih, operasi ieu sacara séméntal sami sareng nyiptakeun pointer gajih énggal kalayan nilai pointer data `val` tapi metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// fungsi Ieu utamina mangpaat pikeun sahingga bait saarah pointer arithmetic on pointers berpotensi gajih:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // bakal nyitak "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // Kaamanan: Upami aya panunjuk tipis, operasi ieu idéntik
        // kana tugas anu saderhana.
        // Dina hal pointer gajih, kalayan palaksanaan tata perenah pointer gajih anu ayeuna, bidang anu mimiti pikeun panunjuk sapertos kitu sok nunjukkeun data, anu ogé ditugaskeun.
        //
        unsafe { *thin = val };
        self
    }

    /// Maca nilai tina `self` tanpa mindahkeun éta.
    /// Ieu daun mémori dina `self` henteu robih.
    ///
    /// Tingali [`ptr::read`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun ``.
        unsafe { read(self) }
    }

    /// Ngalakukeun bacaan anu stabil tina nilai ti `self` tanpa mindahkeun éta.Ieu daun mémori dina `self` henteu robih.
    ///
    /// Operasi volatil dimaksudkan pikeun meta dina mémori I/O, sareng dijamin moal élided atanapi diatur deui ku panyusunna ngalangkungan operasi volatil anu sanés.
    ///
    ///
    /// Tingali [`ptr::read_volatile`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Maca nilai tina `self` tanpa mindahkeun éta.
    /// Ieu daun mémori dina `self` henteu robih.
    ///
    /// Béda sareng `read`, panunjukna tiasa henteu disaluyukeun.
    ///
    /// Tingali [`ptr::read_unaligned`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Nyalin `count * size_of<T>` bait tina `self` dugi `dest`.
    /// Sumber sareng tujuanana tiasa tumpang tindih.
    ///
    /// NOTE: ieu ngagaduhan urutan anu sami * sami sareng [`ptr::copy`].
    ///
    /// Tingali [`ptr::copy`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Nyalin `count * size_of<T>` bait tina `self` dugi `dest`.
    /// Sumber sareng tujuanana meureun *henteu* tumpang tindih.
    ///
    /// NOTE: ieu ngagaduhan urutan anu sami * sami sareng [`ptr::copy_nonoverlapping`].
    ///
    /// Tingali [`ptr::copy_nonoverlapping`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Nyalin `count * size_of<T>` bait tina `src` dugi `self`.
    /// Sumber sareng tujuanana tiasa tumpang tindih.
    ///
    /// NOTE: ieu ngagaduhan urutan *sabalikna* argumen [`ptr::copy`].
    ///
    /// Tingali [`ptr::copy`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Nyalin `count * size_of<T>` bait tina `src` dugi `self`.
    /// Sumber sareng tujuanana meureun *henteu* tumpang tindih.
    ///
    /// NOTE: ieu ngagaduhan urutan *sabalikna* argumen [`ptr::copy_nonoverlapping`].
    ///
    /// Tingali [`ptr::copy_nonoverlapping`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Ngaeksekusi destruktor (upami aya) tina nilai anu ditunjuk.
    ///
    /// Tempo [`ptr::drop_in_place`] keur masalah kaamanan sarta conto.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Nimpa lokasi mémori sareng nilai anu dibéré tanpa maca atanapi muragkeun nilaina anu lami.
    ///
    ///
    /// Tingali [`ptr::write`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `write`.
        unsafe { write(self, val) }
    }

    /// Invokes memset dina pointer dieusian, netepkeun `count * size_of::<T>()` bait memori dimimitian di `self` mun `val`.
    ///
    ///
    /// Tingali [`ptr::write_bytes`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Ngalakukeun panulisan anu volatil ngeunaan lokasi mémori kalayan nilai anu ditangtoskeun tanpa maca atanapi ngaleupaskeun nilai lami.
    ///
    /// Operasi volatil dimaksudkan pikeun meta dina mémori I/O, sareng dijamin moal élided atanapi diatur deui ku panyusunna ngalangkungan operasi volatil anu sanés.
    ///
    ///
    /// Tingali [`ptr::write_volatile`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Nimpa lokasi mémori sareng nilai anu dibéré tanpa maca atanapi muragkeun nilaina anu lami.
    ///
    ///
    /// Béda sareng `write`, panunjukna tiasa henteu disaluyukeun.
    ///
    /// Tingali [`ptr::write_unaligned`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Ngagantikeun nilai di `self` kalawan `src`, balik nilai heubeul, tanpa muterna boh.
    ///
    ///
    /// Tingali [`ptr::replace`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `replace`.
        unsafe { replace(self, src) }
    }

    /// Tukeur nilai-nilai dina dua lokasi anu tiasa dirobih tina jinis anu sami, tanpa deinitialisasi ogé.
    /// Éta bisa tumpang tindih, kawas `mem::swap` nu disebutkeun sarimbag.
    ///
    /// Tingali [`ptr::swap`] pikeun masalah kaamanan sareng conto.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `swap`.
        unsafe { swap(self, with) }
    }

    /// Ngitung offset anu kedah dilarapkeun ka pointer supados tiasa dijantenkeun `align`.
    ///
    /// Upami teu mungkin pikeun ngajajar pointer, palaksanaan na mulih `usize::MAX`.
    /// Diidinan pikeun palaksanaan *salawasna* balik `usize::MAX`.
    /// Ngan ukur kinerja algoritma anjeun tiasa gumantung kana kéngingkeun offset anu tiasa dianggo di dieu, sanés leresna.
    ///
    /// Offset dikedalkeun dina sababaraha unsur `T`, sareng sanés bait.Nilai anu dipulangkeun tiasa dianggo nganggo metode `wrapping_add`.
    ///
    /// Teu aya jaminan naon waé anu ngimbangan pointer moal overflow atanapi ngalangkungan alokasi anu ditunjuk ku pointer.
    ///
    /// Éta dugi ka anu nélépon pikeun mastikeun yén offset anu dipulangkeun leres dina sadaya istilah salain ti alignment.
    ///
    /// # Panics
    ///
    /// Fungsi panics upami `align` sanés kakuatan-tina-dua.
    ///
    /// # Examples
    ///
    /// Ngaksés `u8` caket salaku `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // samentawis pointer tiasa dijejeran ngalangkungan `offset`, éta bakal nunjuk di luar alokasi
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAFETY: `align` parantos dipariksa janten kakuatan 2 di luhur
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Mulih panjang sapotong atah.
    ///
    /// Nilai anu dipulangkeun nyaéta jumlah **elemen**, sanés jumlah bait.
    ///
    /// fungsi Ieu aman, sanajan nu nyiksikan atah teu bisa tuang ka rujukan nyiksikan sabab pointer nyaeta hypothesis atanapi unaligned.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: ieu aman sabab `*const [T]` sareng `FatPtr<T>` gaduh tata perenah anu sami.
            // Ngan `std` anu tiasa ngajamin ieu.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Balikkeun pointer atah kana panyangga irisan.
    ///
    /// Ieu sami sareng casting `self` ka `*mut T`, tapi langkung aman-tipeu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Balikkeun pointer atah kana unsur atanapi langganan, tanpa kedah dilakukeun batesan.
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates atanapi nalika `self` henteu dileungitkeun nyaéta *[tingkah laku anu teu ditangtoskeun]* sanajan panunjuk anu dihasilkeun henteu dianggo.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KESELAMATAN: panelepon mastikeun yén `self` henteu tiasa dibébaskeun sareng `index` di-wates.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Mulih `None` upami panunjukna batal, atanapi anu sanésna mulihkeun potongan anu dibagi kana nilai anu dibungkus `Some`.
    /// Béda sareng [`as_ref`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * Penunjuk kedah [valid] kanggo maos pikeun `ptr.len() * mem::size_of::<T>()` seueur bait, sareng éta kedah leres-leres dijantenkeun.Hartosna khususna:
    ///
    ///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
    ///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.
    ///
    ///     * Pointer kedah diluyukeun bahkan pikeun irisan panjang-enol.
    ///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
    ///
    ///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
    ///   Tingali dokuméntasi kaamanan [`pointer::offset`].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// Tempo ogé [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Mulih `None` upami panunjukna batal, atanapi anu sanésna ngasilkeun potongan unik kana nilai anu dibungkus `Some`.
    /// Béda sareng [`as_mut`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun anu tara dibagi tingali [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kudu mastikeun yén *naha* pointer nyaéta NULL *atanapi* sadayana ieu leres.
    ///
    /// * pointer kudu [valid] pikeun maos teras nyerat keur `ptr.len() * mem::size_of::<T>()` loba bait, sarta eta kudu Blok leres.Hartosna khususna:
    ///
    ///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
    ///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.
    ///
    ///     * Pointer kedah diluyukeun bahkan pikeun irisan panjang-enol.
    ///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
    ///
    ///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
    ///   Tingali dokuméntasi kaamanan [`pointer::offset`].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// Tingali ogé [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Sarua pikeun panunjuk
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}