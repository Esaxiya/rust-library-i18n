#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Nyayogikeun jinis metadata pointer tina sagala jinis anu ditunjuk.
///
/// # Metadata pointer
///
/// Jinis pointer atah sareng jinis rujukan dina Rust tiasa panginten didamel tina dua bagian:
/// pitunjuk data anu ngandung alamat mémori niléyna, sareng sababaraha metadata.
///
/// Pikeun jenis ukuran-statis (anu ngalaksanakeun `Sized` traits) ogé pikeun jenis `extern`, pointer disebatkeun "ipis": metadata ukuranana nol sareng jinis na `()`.
///
///
/// Nunjuk ka [dynamically-sized types][dst] disebatkeun "lega" atanapi "gendut", aranjeunna ngagaduhan metadata non-enol:
///
/// * Pikeun struktur anu lapangan terakhir nyaéta DST, metadata mangrupikeun metadata kanggo lapangan terakhir
/// * Pikeun jinis `str`, metadata nyaéta panjang dina bait sakumaha `usize`
/// * Pikeun jenis nyiksikan kawas `[T]`, metadata teh panjangna di item sakumaha `usize`
/// * Pikeun trait objék kawas `dyn SomeTrait`, metadata nyaeta [`DynMetadata<Self>`][DynMetadata] (misalna `DynMetadata<dyn SomeTrait>`)
///
/// Dina future, basa Rust tiasa ngagaduhan jinis-jinis énggal anu ngagaduhan metadata pointer anu béda.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Intina trait ieu mangrupikeun jinis pakait `Metadata` na, nyaéta `()` atanapi `usize` atanapi `DynMetadata<_>` sakumaha ditétélakeun di luhur.
/// Éta sacara otomatis dilaksanakeun pikeun unggal jenis.
/// Éta tiasa dianggap diterapkeun dina kontéks umum, bahkan tanpa wates anu saluyu.
///
/// # Usage
///
/// Nunjuk atah tiasa diuraikeun kana alamat data sareng komponén metadata kalayan padika [`to_raw_parts`] na.
///
/// Alternatipna, metadata nyalira tiasa diekstraksi sareng fungsi [`metadata`].
/// Rujukan tiasa diliwatan ka [`metadata`] sareng sacara implisit dipaksa.
///
/// A (possibly-wide) pointer bisa nempatkeun deui babarengan ti alamat sarta metadata kalawan [`from_raw_parts`] atanapi [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Jenis pikeun metadata dina petunjuk sareng rujukan pikeun `Self`.
    #[lang = "metadata_type"]
    // NOTE: Tetep trait bounds di `static_assert_expected_bounds_for_metadata`
    //
    // dina `library/core/src/ptr/metadata.rs` sinkron sareng anu aya di dieu:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Nunjuk kana jinis ngalaksanakeun alias trait ieu "ipis".
///
/// Ieu kalebet jinis `Sized` sacara statis sareng jinis `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: entong stabilkeun ieu sateuacan landihan trait stabil dina basa?
pub trait Thin = Pointee<Metadata = ()>;

/// Ékstrak komponén metadata tina panunjuk.
///
/// Nilai tipe `*mut T`, `&T`, atanapi `&mut T` tiasa diteruskeun langsung kana fungsi ieu sabab sacara implisit maksa ka `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Ngaksés nilaina tina union `PtrRepr` aman saprak * const T
    // sareng PtrComponents<T>gaduh perenah memori anu sami.
    // Ngan std tiasa ngajamin ieu.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Ngabentuk pointer atah (possibly-wide) tina alamat data sareng metadata.
///
/// Fungsi ieu aman tapi pointer anu balik henteu merta aman pikeun ngaleungitkeun.
/// Kanggo keureut, tingali dokuméntasi [`slice::from_raw_parts`] pikeun syarat kaamanan.
/// Pikeun objék trait, metadata kedahna sumping tina panunjuk kana jinis anu teu acan dicasarkeun anu sami.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Ngaksés nilaina tina union `PtrRepr` aman saprak * const T
    // sareng PtrComponents<T>gaduh perenah memori anu sami.
    // Ngan std tiasa ngajamin ieu.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Nedunan pungsi anu sami sareng [`from_raw_parts`], kajabi pointer `*mut` atah dipulangkeun, sabalikna tina panunjuk `* const` atah.
///
///
/// Tingali dokuméntasi [`from_raw_parts`] pikeun langkung jelasna.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Ngaksés nilaina tina union `PtrRepr` aman saprak * const T
    // sareng PtrComponents<T>gaduh perenah memori anu sami.
    // Ngan std tiasa ngajamin ieu.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Impl Manual kedah nyingkahan `T: Copy` kabeungkeut.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Impl Manual kedah nyingkahan `T: Clone` kabeungkeut.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata pikeun jenis obyék `Dyn = dyn SomeTrait` trait.
///
/// Éta mangrupikeun pointer kana vtable (méja panggero maya) anu ngagambarkeun sadaya inpormasi anu diperyogikeun pikeun ngamanipulasi jinis beton anu disimpen di jero obyék trait.
/// Vtable khususna ngandung:
///
/// * ukuran tipe
/// * jinis alignment
/// * pitunjuk pikeun `drop_in_place` impl tipe (tiasa janten no-op kanggo data-lami-lami)
/// * nunjuk ka sadaya padika pikeun panerapan jinis trait
///
/// Catet yén anu kahiji anu tilu khusus kusabab éta diperyogikeun pikeun ngaalokasikeun, lungsur, sareng ngarobih obyék trait naon waé.
///
/// Tiasa waé namina strukturna ieu sareng parameter jinis anu sanés obyék `dyn` trait (contona `DynMetadata<u64>`) tapi henteu kéngingkeun nilai bermakna tina strukturna.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Awalan umum sadaya vtables.Hal ieu dituturkeun ku petunjuk fungsi pikeun metode trait.
///
/// Jéntré palaksanaan swasta `DynMetadata::size_of` jsb.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Balikkeun ukuran tina jinis anu aya hubunganana sareng tabel ieu.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Mulang koréksi jinis anu aya hubunganana sareng tabel ieu.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Balikkeun ukuran sareng alignment salaku `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: kompiler ngaluarkeun vtable ieu pikeun jenis Rust beton anu
        // dipikaterang ngagaduhan tata ruang anu valid.Alesan anu sami sapertos dina `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Impls Manual diperlukeun pikeun nyingkahan wates `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}