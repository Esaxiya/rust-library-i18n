//! Sacara manual ngatur memori ngalangkungan petunjuk atah.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Seueur fungsi dina modul ieu nyandak petunjuk atah salaku argumen sareng maca tina atanapi nyerat ka aranjeunna.Keur kitu aya aman, pointers ieu kedah janten * * sah.
//! Naha pointer valid gumantung kana operasi anu dianggo pikeun (maca atanapi nyerat), sareng tingkat mémori anu diaksés (nyaéta, sabaraha bait read/written).
//! Kaseueuran fungsi nganggo `*mut T` sareng `* const T` ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur ngan ukur nganggap nilai tunggal, dina hal éta dokuméntasi ngaleungitkeun ukuranana sareng sacara implisit nganggap éta `size_of::<T>()` bait.
//!
//! Aturan anu pas pikeun validitas henteu acan ditangtoskeun.Jaminan anu disayogikeun dina titik ieu minimal pisan:
//!
//! * Penunjuk [null]*henteu pernah* sah, bahkan pikeun aksés [size zero][zst].
//! * Pikeun panunjuk janten sah, perlu, tapi henteu kedah cekap, panunjuk na janten *pikaresepeun*: kisaran mémori tina ukuran anu parantos dimimitian ti panunjuk sadayana kedah aya dina bates hiji obyék anu dialokasikan.
//!
//! Catet yén dina Rust, unggal variabel (stack-allocated) dianggap obyék anu dialokasikan misah.
//! * Bahkan pikeun operasi [size zero][zst], pointer kedah henteu nunjuk kana mémori anu ditranslokasi, nyaéta, deallocation ngajantenkeun pointers henteu valid bahkan kanggo operasi saukuran nol.
//! Nanging, nempatkeun integer *nol* non-nol pikeun panunjuk sah pikeun aksés berukuran nol, bahkan upami sababaraha mémori kajantenan aya di alamat éta sareng tiasa ditranslokasi.
//! Ieu saluyu sareng nyerat alokasi anjeun nyalira: nyebarkeun obyék anu ukuranana enol henteu sesah pisan.
//! Cara kanonis pikeun kéngingkeun pointer anu valid pikeun aksés anu ukuranana nol nyaéta [`NonNull::dangling`].
//! * Sadaya aksés anu dilakukeun ku fungsi dina modul ieu nyaéta *non-atom* dina hartos [atomic operations] anu digunakeun pikeun nyinkronkeun antara utas.
//! hartosna kieu éta kabiasaan undefined nedunan dua aksés babarengan ka lokasi anu sarua ti threads béda iwal duanana aksés ngan maca tina memori.
//! Perhatikeun yén ieu jelas-jelas kalebet [`read_volatile`] sareng [`write_volatile`]: aksés volatil henteu tiasa dianggo pikeun sinkronisasi antar-benang.
//! * Hasil tina casting rujukan ka pointer valid pikeun salami obyék anu ngadasarna hirup sareng henteu aya rujukan (ngan ukur petunjuk atah) anu dianggo pikeun aksés mémori anu sami.
//!
//! axioms ieu marengan pamakéan ati [`offset`] pikeun pointer arithmetic, anu cukup pikeun neuleu nerapkeun loba hal mangpaat dina kode unsafe.
//! Jaminan anu langkung kuat bakal disayogikeun akhirna, sabab aturan [aliasing] parantos ditangtoskeun.
//! Kanggo inpormasi lengkep, tingali [book] ogé bagian dina rujukan anu dikhususkeun pikeun [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Nunjuk atah anu sah sakumaha anu ditetepkeun di luhur henteu kedah leres-leres dijejerankeun (dimana alignment "proper" didefinisikeun ku jinis pointee, nyaéta `*const T` kedah dijejeran janten `mem::align_of::<T>()`).
//! Nanging, kaseueuran fungsi ngabutuhkeun argumenna pikeun leres-leres dijejeran, sareng sacara jelas bakal nyatakeun sarat ieu dina dokuméntasiana.
//! Pengecualian anu kasohor ieu nyaéta [`read_unaligned`] sareng [`write_unaligned`].
//!
//! Nalika fungsi peryogi perenah anu pas, éta bakal dilakukeun sanajan aksésna ngagaduhan ukuran 0, nyaéta, bahkan upami mémori henteu leres-leres keuna.Pertimbangkeun ngagunakeun [`NonNull::dangling`] dina kasus sapertos kitu.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ngaeksekusi destruktor (upami aya) tina nilai anu ditunjuk.
///
/// Ieu sacara sémantis sarimbag pikeun nyauran [`ptr::read`] sareng miceun hasilna, tapi ngagaduhan kaunggulan ieu:
///
/// * Hal ieu *diperlukeun* ngagunakeun `drop_in_place` lungsur jenis unsized kawas trait objék, sabab teu bisa maca kaluar onto tumpukan jeung turun normal.
///
/// * Éta langkung marahmay pikeun pangoptimal pikeun ngalakukeun ieu langkung ti [`ptr::read`] nalika lungsur mémori anu dialokasikan sacara manual (contona, dina implementasi `Box`/`Rc`/`Vec`), sabab panyusunna henteu kedah ngabuktoskeun yén éta sora pikeun milih salinanna.
///
///
/// * Éta tiasa dianggo pikeun teundeun data [pinned] nalika `T` sanés `repr(packed)` (data anu dipasang kedah henteu dipindahkeun sateuacan lungsur).
///
/// Nilai anu teu dijadwalkeun henteu tiasa dijalankeun dina tempatna, éta kedah disalin ka lokasi anu didaptarkeun heula nganggo [`ptr::read_unaligned`].Pikeun structs dipakétkeun, pindah ieu dipigawé sacara otomatis ku compiler anu.
/// Ieu hartosna widang structs dipak teu turun di-tempat.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `to_drop` kedah [valid] pikeun duanana maos sareng nyerat.
///
/// * `to_drop` kudu Blok leres.
///
/// * Nilai `to_drop` poin kedah sah pikeun turunna, anu tiasa hartosna éta kedah ngadukung invariants tambahan, ieu gumantung kana jinis.
///
/// Salaku tambahan, upami `T` sanés [`Copy`], ngagunakeun nilai nunjuk-ka saatos nyebat `drop_in_place` tiasa nyababkeun kalakuan anu teu ditangtoskeun.Catet yén `*to_drop = foo` diitung salaku panggunaan sabab éta bakal ngabalukarkeun nilaina turun deui.
/// [`write()`] tiasa dianggo pikeun nimpa data tanpa nyababkeun murag.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Sacara manual cabut barang panungtung tina vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Kéngingkeun pointer atah pikeun unsur panungtung dina `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Cekkeun `v` kanggo nyegah barang anu terakhir tina murag.
///     // Kami ngalakukeun anu munggaran, pikeun nyegah masalah upami `drop_in_place` di handap panics.
///     v.set_len(1);
///     // Tanpa panggero `drop_in_place`, barang panungtung moal pernah murag, sareng mémori anu dikokolakeunna bakal bocor.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Pastikeun yén barang panungtung murag.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Perhatikeun yén panyusun ngalaksanakeun salinan ieu sacara otomatis nalika ngaleupaskeun tali anu dibungkus, nyaéta anjeun biasana henteu hariwang ngeunaan masalah sapertos éta kecuali upami anjeun nyauran `drop_in_place` sacara manual.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kodeu didieu henteu janten masalah, ieu diganti ku lem serelek asli ku panyusunna.
    //

    // SAFETY: tingali komentar di luhur
    unsafe { drop_in_place(to_drop) }
}

/// Nyiptakeun pointer atah kosong.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Nyiptakeun pointer atah mutable mutable.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Impl Manual kedah nyingkahan `T: Clone` kabeungkeut.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Impl Manual kedah nyingkahan `T: Copy` kabeungkeut.
impl<T> Copy for FatPtr<T> {}

/// Ngabentuk irisan atah tina panunjuk sareng panjang.
///
/// Argumen `len` mangrupikeun jumlah unsur **, sanés jumlah bait.
///
/// Fungsi ieu aman, tapi anu saéstuna nganggo nilai balik teu aman.
/// Tingali dokuméntasi [`slice::from_raw_parts`] pikeun syarat kaamanan nyiksikan.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // jieun pointer keureut nalika dimimitian ku panunjuk kana unsur anu munggaran
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAFETY: Ngaksés nilaina tina union `Repr` aman saprak * const [T]
        //
        // sareng FatPtr gaduh perenah memori anu sami.Ngan std tiasa ngajamin ieu.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Laksanakeun pungsionalitas anu sami sareng [`slice_from_raw_parts`], kajabi irisan mutable atah dipulihkeun, sabalikna tina keureut anu teu tiasa dirobih atah.
///
///
/// Tingali dokuméntasi [`slice_from_raw_parts`] pikeun langkung jelasna.
///
/// Fungsi ieu aman, tapi anu saéstuna nganggo nilai balik teu aman.
/// Tingali dokuméntasi [`slice::from_raw_parts_mut`] pikeun syarat kaamanan nyiksikan.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // napelkeun nilai dina indéks dina potongan
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // Kasalametan: Ngaksés nilai nu ti rugbi `Repr` geus aman saprak * mut [T]
        // sareng FatPtr gaduh perenah memori anu sami
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Tukeur nilai-nilai dina dua lokasi anu tiasa dirobih tina jinis anu sami, tanpa deinitialisasi ogé.
///
/// Tapi pikeun dua pengecualian di handap ieu, fungsi ieu sacara séméntal sami sareng [`mem::swap`]:
///
///
/// * Éta dioperasikeun dina petunjuk atah tibatan rujukan.
/// Upami aya rujukan, [`mem::swap`] kedah langkung resep.
///
/// * Dua nilai anu ditunjuk tiasa tumpang tindih.
/// Upami nilai-nilai tindihna, maka daérah tumpang tindih ingetan ti `x` bakal dianggo.
/// Ieu nunjukkeun dina conto kadua di handap.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * Duanana `x` sareng `y` kedah [valid] pikeun duanana maca sareng nyerat.
///
/// * Duanana `x` sareng `y` kedah leres dijajar.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, petunjuk kedah non-NULL sareng leres dijajarkeun.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Tukeuran dua daérah anu henteu tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ieu `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ieu `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Tukeuran dua daérah tumpang tindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ieu `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ieu `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indéks `1..3` tina irisan tumpang tindih antara `x` sareng `y`.
///     // Hasil anu wajar pikeun aranjeunna janten `[2, 3]`, sahingga indéks `0..3` nyaéta `[1, 2, 3]` (cocog `y` sateuacan `swap`);atanapi pikeun aranjeunna janten `[0, 1]` sahingga indéks `1..4` nyaéta `[0, 1, 2]` (cocog sareng `x` sateuacan `swap`).
/////
///     // Palaksanaan ieu dihartikeun pikeun ngajantenkeun pilihan anu terakhir.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Pasihan diri urang pikeun sababaraha rohangan anu garet pikeun digarap.
    // Kami henteu kedah hariwang ngeunaan tetes: `MaybeUninit` henteu ngalakukeun nanaon nalika turun.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Laksanakeun SAFETY swap: anu nelepon kedah ngajamin yén `x` sareng `y` valid pikeun nyerat sareng leres dijejeran.
    // `tmp` moal tiasa tumpang tindih boh `x` atanapi `y` sabab `tmp` nembé dialokasikan dina tumpukan salaku obyék anu dialokasikeun anu misah.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` sareng `y` tiasa tindih
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Tukar `count * size_of::<T>()` bait antara dua daérah mémori dimimitian dina `x` sareng `y`.
/// Dua daérah kedahna *henteu* tumpang tindih.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * Duanana `x` sareng `y` kedah [valid] pikeun duanana maos sareng nyerat `count *
///   size_of: :<T>() `bait.
///
/// * Duanana `x` sareng `y` kedah leres dijajar.
///
/// * Wilayah mémori dimimitian dina `x` kalayan ukuran `count *
///   size_of: :<T>() `bait kedah *henteu* tumpang tindih sareng daérah ingetan anu dimimitian dina `y` kalayan ukuran anu sami.
///
/// Catetan yen sanajan ukuran éféktif disalin (`cacah * size_of: :<T>()`) nyaéta `0`, petunjuk kedah non-NULL sareng leres dijajarkeun.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: panelepon kedah ngajamin yén `x` sareng `y` nyaéta
    // valid pikeun nyerat sareng leres dijejeran.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Pikeun jinis anu langkung alit tibatan optimasi blok di handap, cukup langsung pertukaran pikeun nyingkahan codégén pesimis.
    //
    if mem::size_of::<T>() < 32 {
        // SAFETY: anu nelepon kedah ngajamin yén `x` sareng `y` leres
        // pikeun nyerat, leres leres, sareng henteu tumpang tindih.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pendekatan di dieu nyaéta ngagunakeun simd pikeun swap x&y épisién.
    // Tés ngungkabkeun yén silih tukeur 32 bait atanapi 64 bait sakaligus pang éfisiénna pikeun prosésor Intel Haswell E.
    // LLVM langkung sanggup ngaoptimalkeun upami urang masihan str #[repr(simd)] X, bahkan upami urang henteu leres-leres nganggo strukturna ieu.
    //
    //
    // FIXME repr(simd) rusak dina emscripten sareng redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop ngaliwatan x&y, nyalin `Block` sakaligus Optimizer kedah ngabuka loop pinuh pikeun kaseueuran jinis NB
    // Kami henteu tiasa nganggo loop salaku impl `range` nyaéta panggero `mem::swap` sacara rekursif
    //
    let mut i = 0;
    while i + block_size <= len {
        // Ngadamel sababaraha mémori anu henteu dieritialikeun salaku spasi ngiklan Ngadéklarasikeun `t` di dieu ngahindarkeun ngabéréskeun tumpukan nalika loop ieu henteu dianggo
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: Salaku `i < len`, sareng salaku anu nelepon kedah ngajamin yén `x` sareng `y` leres
        // pikeun `len` bait, `x + i` sareng `y + i` kedah alamat anu valid, anu minuhan kontrak kaamanan pikeun `add`.
        //
        // Ogé, anu nelepon kedah ngajamin yén `x` sareng `y` valid pikeun nyerat, saluyu sareng leres, sareng henteu tumpang tindih, anu minuhan kontrak kaamanan pikeun `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Tukeurkeun blok bait x&y, nganggo t salaku panyangga samentawis Ieu kedah dioptimalkeun janten operasi SIMD anu épisién upami aya
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tukeur bait sésana
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // Kaamanan: tingali komentar kaamanan sateuacanna.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Mindahkeun `src` kana `dst` runcing, balik deui nilai `dst`.
///
/// Sanés nilai turun.
///
/// Fungsi ieu sacara séméntal sami sareng [`mem::replace`] kecuali yén éta tiasa dianggo dina petunjuk atah tibatan rujukan.
/// Upami aya rujukan, [`mem::replace`] kedah langkung resep.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `dst` kedah [valid] pikeun duanana maos sareng nyerat.
///
/// * `dst` kudu Blok leres.
///
/// * `dst` kedah nunjuk kana nilai inisialisasi leres jinis `T`.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bakal gaduh pangaruh anu sami tanpa meryogikeun blok anu teu aman.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: panelepon kedah ngajamin yén `dst` leres janten
    // matak kana rujukan anu tiasa dirobih (valid pikeun nyerat, dijajarkeun, diinisialisasi), sareng henteu tiasa tumpang tindih `src` kumargi `dst` kedah nunjuk ka obyék anu dialokasikan anu béda.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // moal tiasa tumpang tindih
    }
    src
}

/// Maca nilai tina `src` tanpa mindahkeun éta.Ieu daun mémori dina `src` henteu robih.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `src` kedah [valid] kanggo macana.
///
/// * `src` kedah leres-leres dijajarkeun.Anggo [`read_unaligned`] upami ieu sanés masalahna.
///
/// * `src` kedah nunjuk kana nilai inisialisasi leres jinis `T`.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Sacara manual nerapkeun [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ngadamel salinan bitwise tina nilai dina `a` dina `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kaluar dina titik ieu (naha ku jelas-jelas balik deui atanapi ku nelepon fungsi anu panics) bakal ngabalukarkeun nilai dina `tmp` turun bari nilai anu sami masih dirujuk ku `a`.
///         // Ieu tiasa memicu tingkah laku anu teu ditangtoskeun upami `T` sanés `Copy`.
/////
/////
///
///         // Ngadamel salinan bitwise tina nilai dina `b` dina `a`.
///         // Ieu aman sabab rujukan anu teu tiasa dipotong henteu tiasa landihan.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sakumaha di luhur, kaluar di dieu tiasa memicu tingkah laku anu teu ditangtoskeun sabab nilai anu sami dirujuk ku `a` sareng `b`.
/////
///
///         // Mindahkeun `tmp` kana `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` parantos dipindahkeun (`write` ngagaduhan kapamilikan argumen anu kadua), janten teu aya anu murag sacara implisit di dieu.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Kapamilikan Nilai Anu Dipulangkeun
///
/// `read` nyiptakeun salinan bitwise `T`, henteu paduli naha `T` nyaéta [`Copy`].
/// Upami `T` sanés [`Copy`], nganggo nilai anu balik sareng nilai `*src` tiasa ngalanggar kaamanan mémori.
/// Catet yén napelkeun ka `*src` diitung salaku panggunaan sabab bakal nyobian lungsur nilai dina `* src`.
///
/// [`write()`] tiasa dianggo pikeun nimpa data tanpa nyababkeun murag.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ayeuna nunjuk kana mémori anu sami sareng `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Napelkeun ka `s2` nyababkeun nilai aslina turun.
///     // Cicih ti titik ieu, `s` kedah henteu kedah dianggo deui, sabab mémori dasarna parantos dibébaskeun.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Napelkeun ka `s` bakal nyababkeun nilai lami diturunkeun deui, hasilna kabiasaan teu ditangtoskeun.
/////
///     // s= String::from("bar");//Kasalahan
///
///     // `ptr::write` tiasa dianggo pikeun nimpa nilai tanpa lungsur.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: anu nelepon kedah ngajamin yén `src` valid pikeun dibaca.
    // `src` moal tiasa tumpang tindih `tmp` sabab `tmp` nembé dialokasikan dina tumpukan salaku obyék anu dialokasikeun misah.
    //
    //
    // Ogé, kusabab urang nembé nyerat nilai anu valid kana `tmp`, éta dijamin bakal diinalisasi leres.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Maca nilai tina `src` tanpa mindahkeun éta.Ieu daun mémori dina `src` henteu robih.
///
/// Beda sareng [`read`], `read_unaligned` tiasa dianggo sareng pointer anu teu dijadwalkeun.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `src` kedah [valid] kanggo macana.
///
/// * `src` kedah nunjuk kana nilai inisialisasi leres jinis `T`.
///
/// Sapertos [`read`], `read_unaligned` nyiptakeun salinan bitwise `T`, henteu paduli naha `T` nyaéta [`Copy`].
/// Upami `T` sanés [`Copy`], nganggo nilai anu sami sareng nilai di `*src` tiasa [violate memory safety][read-ownership].
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-nol.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Dina strukturna `packed`
///
/// Ayeuna teu mungkin pikeun nyiptakeun petunjuk atah kana kolom anu teu didaptarkeun tina strukturna anu dikemas.
///
/// Nyobaan nyieun pointer atah ka `unaligned` strukture bidang kalayan éksprési sapertos `&packed.unaligned as *const FieldType` nyiptakeun rujukan anu teu aya panengah sateuacan ngarobah éta kana panunjuk atah.
///
/// Éta rujukan ieu samentawis sareng langsung matak henteu penting sabab panyusunna salawasna ngarepkeun référénsi bakal leres dijejeran.
/// Hasilna, nganggo `&packed.unaligned as *const FieldType` nyababkeun langsung* tingkah laku teu ditangtoskeun * dina program anjeun.
///
/// Conto naon anu kedah dilakukeun sareng kumaha hubunganana sareng `read_unaligned` nyaéta:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Di dieu urang nyobian nyandak alamat integer 32-bit anu henteu sajajar.
///     let unaligned =
///         // Rujukan anu henteu disaluyukeun samentawis didamel di dieu anu ngakibatkeun kalakuan anu teu ditangtoskeun henteu paduli naha rujukan éta dianggo atanapi henteu.
/////
///         &packed.unaligned
///         // Matak ka pointer atah henteu ngabantuan;kasalahan anu parantos kajantenan.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ngakses lapangan anu teu dirobih langsung sareng eg `packed.unaligned` aman waé.
///
///
///
///
///
///
// FIXME: Perbarui dokumén dumasar kana hasil RFC #2582 sareng réréncangan.
/// # Examples
///
/// Baca nilai usize tina panyangga bait:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: anu nelepon kedah ngajamin yén `src` valid pikeun dibaca.
    // `src` moal tiasa tumpang tindih `tmp` sabab `tmp` nembé dialokasikan dina tumpukan salaku obyék anu dialokasikeun misah.
    //
    //
    // Ogé, kusabab urang nembé nyerat nilai anu valid kana `tmp`, éta dijamin bakal diinalisasi leres.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Nimpa lokasi mémori sareng nilai anu dibéré tanpa maca atanapi muragkeun nilaina anu lami.
///
/// `write` teu lungsur eusi `dst`.
/// Ieu aman, tapi éta tiasa ngabocorkeun alokasi atanapi sumber daya, janten kedah ati-ati supados henteu nimpa hiji obyék anu kedah lungsur.
///
///
/// Salaku tambahan, éta henteu lungsur `src`.Sacara semantis, `src` dipindahkeun kana lokasi anu ditunjuk ku `dst`.
///
/// Ieu cocog pikeun ngainisialisasi mémori anu teu dihaja, atanapi nimpa mémori anu sateuacanna parantos [`read`] ti.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `dst` kedah [valid] pikeun nyerat.
///
/// * `dst` kedah leres-leres dijajarkeun.Anggo [`write_unaligned`] upami ieu sanés masalahna.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Sacara manual nerapkeun [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ngadamel salinan bitwise tina nilai dina `a` dina `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kaluar dina titik ieu (naha ku jelas-jelas balik deui atanapi ku nelepon fungsi anu panics) bakal ngabalukarkeun nilai dina `tmp` turun bari nilai anu sami masih dirujuk ku `a`.
///         // Ieu tiasa memicu tingkah laku anu teu ditangtoskeun upami `T` sanés `Copy`.
/////
/////
///
///         // Ngadamel salinan bitwise tina nilai dina `b` dina `a`.
///         // Ieu aman sabab rujukan anu teu tiasa dipotong henteu tiasa landihan.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sakumaha di luhur, kaluar di dieu tiasa memicu tingkah laku anu teu ditangtoskeun sabab nilai anu sami dirujuk ku `a` sareng `b`.
/////
///
///         // Mindahkeun `tmp` kana `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` parantos dipindahkeun (`write` ngagaduhan kapamilikan argumen anu kadua), janten teu aya anu murag sacara implisit di dieu.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Kami nelepon intrinsik sacara langsung pikeun ngahindaran fungsi nelepon dina kode anu dihasilkeun salaku `intrinsics::copy_nonoverlapping` nyaéta fungsi bungkus.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: anu nelepon kedah ngajamin yén `dst` valid pikeun nyerat.
    // `dst` moal tiasa tumpang tindih `src` sabab anu nelepon ngagaduhan aksés anu tiasa dirobih ka `dst` sedengkeun `src` dipiboga ku fungsi ieu.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Nimpa lokasi mémori sareng nilai anu dibéré tanpa maca atanapi muragkeun nilaina anu lami.
///
/// Béda sareng [`write()`], panunjukna tiasa henteu disaluyukeun.
///
/// `write_unaligned` henteu teundeun eusi `dst`.Ieu aman, tapi éta tiasa ngabocorkeun alokasi atanapi sumber daya, janten kedah ati-ati supados henteu nimpa hiji obyék anu kedah lungsur.
///
/// Salaku tambahan, éta henteu lungsur `src`.Sacara semantis, `src` dipindahkeun kana lokasi anu ditunjuk ku `dst`.
///
/// Ieu luyu pikeun initializing memori uninitialized, atawa overwriting memori nu saméméhna geus maca kalawan [`read_unaligned`].
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `dst` kedah [valid] pikeun nyerat.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-nol.
///
/// [valid]: self#safety
///
/// ## Dina strukturna `packed`
///
/// Ayeuna teu mungkin pikeun nyiptakeun petunjuk atah kana kolom anu teu didaptarkeun tina strukturna anu dikemas.
///
/// Nyobaan nyieun pointer atah ka `unaligned` strukture bidang kalayan éksprési sapertos `&packed.unaligned as *const FieldType` nyiptakeun rujukan anu teu aya panengah sateuacan ngarobah éta kana panunjuk atah.
///
/// Éta rujukan ieu samentawis sareng langsung matak henteu penting sabab panyusunna salawasna ngarepkeun référénsi bakal leres dijejeran.
/// Hasilna, nganggo `&packed.unaligned as *const FieldType` nyababkeun langsung* tingkah laku teu ditangtoskeun * dina program anjeun.
///
/// Conto kumaha teu ngalakukeun na kumaha ieu relates to `write_unaligned` nyaeta:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Di dieu urang nyobian nyandak alamat integer 32-bit anu henteu sajajar.
///     let unaligned =
///         // Rujukan anu henteu disaluyukeun samentawis didamel di dieu anu ngakibatkeun kalakuan anu teu ditangtoskeun henteu paduli naha rujukan éta dianggo atanapi henteu.
/////
///         &mut packed.unaligned
///         // Matak ka pointer atah henteu ngabantuan;kasalahan anu parantos kajantenan.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ngakses lapangan anu teu dirobih langsung sareng eg `packed.unaligned` aman waé.
///
///
///
///
///
///
///
///
///
// FIXME: Perbarui dokumén dumasar kana hasil RFC #2582 sareng réréncangan.
/// # Examples
///
/// Tulis nilai usize kana panyangga bait:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: anu nelepon kedah ngajamin yén `dst` valid pikeun nyerat.
    // `dst` moal tiasa tumpang tindih `src` sabab anu nelepon ngagaduhan aksés anu tiasa dirobih ka `dst` sedengkeun `src` dipiboga ku fungsi ieu.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kami nelepon intrinsik nu langsung ulah nelepon fungsi dina kode dihasilkeun.
        intrinsics::forget(src);
    }
}

/// Ngalakukeun bacaan anu stabil tina nilai ti `src` tanpa mindahkeun éta.Ieu daun mémori dina `src` henteu robih.
///
/// Operasi volatil dimaksudkan pikeun meta dina mémori I/O, sareng dijamin moal élided atanapi diatur deui ku panyusunna ngalangkungan operasi volatil anu sanés.
///
/// # Notes
///
/// Rust ayeuna henteu ngagaduhan modél mémori anu diartikeun sacara ketat sareng resmi, janten semantis anu tepat tina naon hartosna "volatile" didieu tiasa robih ngalangkungan waktos.
/// Disebutkeun, semantik ampir bakal tungtungna lumayan mirip sareng [C11's definition of volatile][c11].
///
/// Penyusunna henteu kedah ngarobih urutan relatif atanapi jumlah operasi mémori volatil.
/// Nanging, operasi mémori volatil dina jinis ukuran nol (contona, upami jinis anu ukuranana nol diteruskeun ka `read_volatile`) henteu sareng henteu tiasa diémutan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `src` kedah [valid] kanggo macana.
///
/// * `src` kudu Blok leres.
///
/// * `src` kedah nunjuk kana nilai inisialisasi leres jinis `T`.
///
/// Sapertos [`read`], `read_volatile` nyiptakeun salinan bitwise `T`, henteu paduli naha `T` nyaéta [`Copy`].
/// Upami `T` sanés [`Copy`], nganggo nilai anu sami sareng nilai di `*src` tiasa [violate memory safety][read-ownership].
/// Nanging, nyimpen jinis sanés [`Copy`] dina mémori volatil ampir pasti lepat.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Sapertos di C, naha operasi volatil teu aya hubunganana sareng patarosan anu ngalibatkeun aksés sasarengan tina sababaraha benang.Aksés volatil polah persis sapertos aksés non-atom dina hal éta.
///
/// Khususna, balapan antara `read_volatile` sareng operasi nyerat ka lokasi anu sami mangrupikeun tingkah laku anu teu ditangtoskeun.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Teu panicking tetep dampak codegen leutik.
        abort();
    }
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Ngalakukeun panulisan anu volatil ngeunaan lokasi mémori kalayan nilai anu ditangtoskeun tanpa maca atanapi ngaleupaskeun nilai lami.
///
/// Operasi volatil dimaksudkan pikeun meta dina mémori I/O, sareng dijamin moal élided atanapi diatur deui ku panyusunna ngalangkungan operasi volatil anu sanés.
///
/// `write_volatile` henteu teundeun eusi `dst`.Ieu aman, tapi éta tiasa ngabocorkeun alokasi atanapi sumber daya, janten kedah ati-ati supados henteu nimpa hiji obyék anu kedah lungsur.
///
/// Salaku tambahan, éta henteu lungsur `src`.Sacara semantis, `src` dipindahkeun kana lokasi anu ditunjuk ku `dst`.
///
/// # Notes
///
/// Rust ayeuna henteu ngagaduhan modél mémori anu diartikeun sacara ketat sareng resmi, janten semantis anu tepat tina naon hartosna "volatile" didieu tiasa robih ngalangkungan waktos.
/// Disebutkeun, semantik ampir bakal tungtungna lumayan mirip sareng [C11's definition of volatile][c11].
///
/// Penyusunna henteu kedah ngarobih urutan relatif atanapi jumlah operasi mémori volatil.
/// Nanging, operasi mémori volatil dina jinis ukuran nol (contona, upami jinis anu ukuranana nol diteruskeun ka `write_volatile`) henteu sareng henteu tiasa diémutan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `dst` kedah [valid] pikeun nyerat.
///
/// * `dst` kudu Blok leres.
///
/// Catet yén sanajan `T` ngagaduhan ukuran `0`, panunjukna kedah non-NUL sareng leres dijajarkeun.
///
/// [valid]: self#safety
///
/// Sapertos di C, naha operasi volatil teu aya hubunganana sareng patarosan anu ngalibatkeun aksés sasarengan tina sababaraha benang.Aksés volatil polah persis sapertos aksés non-atom dina hal éta.
///
/// Khususna, balapan antara `write_volatile` sareng operasi naon waé (maca atanapi nyerat) dina lokasi anu sami nyaéta tingkah laku anu teu ditangtoskeun.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Teu panicking tetep dampak codegen leutik.
        abort();
    }
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Align pointer `p`.
///
/// Itung offset (tina segi unsur `stride` stride) anu kedah dilarapkeun ka pointer `p` sahingga pointer `p` tiasa dijantenkeun `a`.
///
/// Note: Palaksanaan ieu parantos disaluyukeun ku ati pikeun sanés panic.Éta UB kanggo ieu ka panic.
/// Hiji-hijina parobihan nyata anu tiasa dilakukeun di dieu nyaéta parobihan `INV_TABLE_MOD_16` sareng konstanta anu aya hubunganana.
///
/// Upami urang kantos mutuskeun pikeun nyayogikeun intrinsik sareng `a` sanés kakuatan-tina-dua, sigana bakal langkung wijaksana pikeun ngan ukur ngarobah kana palaksanaan naif tibatan nyobian adaptasi ieu pikeun nampung parobihan éta.
///
///
/// Naon waé patarosan angkat ka@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Pamakéan langsung intrinsik ieu ningkatkeun codegen sacara signifikan dina tingkat milih <=
    // 1, dimana versi metode operasi ieu henteu digariskeun.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Ngitung tibalik modular multiplicative of `x` modulo `m`.
    ///
    /// Palaksanaan ieu diluyukeun pikeun `align_offset` sareng ngagaduhan prasyarat ieu:
    ///
    /// * `m` nyaéta kakuatan-dua;
    /// * `x < m`; (upami `x ≥ m`, lulus dina `x % m`)
    ///
    /// Palaksanaan fungsi ieu henteu panic.Kantos.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Méja modél tibalik modular multiplikasi 2⁴=16.
        ///
        /// Catetan, éta méja ieu teu ngandung nilai mana tibalik teu aya (ie, pikeun `0⁻¹ mod 16`, `2⁻¹ mod 16`, jsb)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo anu dimaksud `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KESELAMATAN: `m` diperyogikeun janten kakuatan-dua, maka sanés nol.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Kami iterate "up" nganggo rumus ieu:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // dugi ka 2 ⁿⁿ ≥ m.Maka urang tiasa ngirangan kana `m` anu dipikahoyong ku nyandak hasil `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Catetan, yén kami nganggo operasi bungkus didieu ngahaja-rumus aslina nganggo contona, pangurangan `mod n`.
                // Éta ogé saé waé pikeun ngalakukeunana `mod usize::MAX` tibatan, sabab urang nyandak hasilna `mod n` di tungtungna ogé.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` mangrupikeun kakuatan-dua, maka sanés nol.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` bisi tiasa diitung langkung saderhana ngalangkungan `-p (mod a)`, tapi ngalakukeun éta ngahambat kamampuan LLVM pikeun milih pitunjuk sapertos `lea`.Sabalikna urang ngitung
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // anu ngadistribusikaeun operasi di sakitar beban-bantalan, tapi pessimizing `and` cekap pikeun LLVM tiasa ngamangpaatkeun sababaraha optimasi anu dipikaterang na.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Parantos jajar.Wéw!
        return 0;
    } else if stride == 0 {
        // Upami panunjuk henteu sajajar sareng unsur na ukuranana nol, maka teu aya jumlah unsur anu kantos ngajajar pointer na.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KESELAMATAN: a mangrupikeun kakuatan-tina-dua maka sanés nol.stride==0 kasus ditangani di luhur.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow ngagaduhan wates luhur anu paling seueur jumlah bit dina usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd sok langkung ageung atanapi sami sareng 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch ieu ngajawab pikeun persamaan kongruensi linier ieu:
        //
        // ` p + so = 0 mod a `
        //
        // `p` ieu nilai pointer, `s`, stride of `T`, `o` offset dina `T`s, sareng `a`, anu dijajarkeun alignment.
        //
        // Kalayan `g = gcd(a, s)`, sareng kaayaan di luhur negeskeun yén `p` ogé tiasa dibagi ku `g`, urang tiasa nunjukkeun `a' = a/g`, `s' = s/g`, `p' = p/g`, maka ieu janten sami sareng:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Istilah anu kahiji nyaéta "the relative alignment of `p` to `a`" (dibagi ku `g`), istilah anu kadua nyaéta "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (deui dibagi ku `g`).
        //
        // Divisi ku `g` diperyogikeun pikeun ngajantenkeun tibalik upami `a` sareng `s` henteu ko-perdana.
        //
        // Salajengna, hasil anu dihasilkeun ku leyuran ieu sanés "minimal", janten perlu nyandak hasilna `o mod lcm(s, a)`.Urang tiasa ngagentos `lcm(s, a)` ku ngan ukur `a'`.
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` ngagaduhan wates luhur henteu langkung ageung tina jumlah labuh 0-bit dina `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // Kaamanan: `a2` henteu nol.Ngalihkeun `a` ku `gcdpow` moal tiasa ngalihkeun salah sahiji bit anu ditetepkeun
        // dina `a` (anu ngagaduhan persis hiji).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` ngagaduhan wates luhur henteu langkung ageung tina jumlah labuh 0-bit dina `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` ngagaduhan wates luhur henteu langkung ageung tina jumlah labuh 0-bit dina
        // `a`.
        // Salajengna, pangirangan henteu tiasa kabanjiran, sabab `a2 = a >> gcdpow` bakal teras-terasan langkung ageung tibatan `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: `a2` mangrupikeun kakuatan-tina-dua, sakumaha kabuktosan di luhur.`s2` tegesna kirang ti `a2`
        // sabab `(s % a) >> gcdpow` nyaéta mastikeun kirang ti `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Henteu tiasa dijajarkeun pisan.
    usize::MAX
}

/// Ngabandingkeun petunjuk atah pikeun sasaruaan.
///
/// Ieu sarua jeung ngagunakeun operator `==`, tapi kirang umum:
/// argumenna kedah `*const T` petunjuk atah, sanés naon-naon anu ngalaksanakeun `PartialEq`.
///
/// Ieu tiasa dianggo pikeun ngabandingkeun rujukan `&T` (anu maksa ka `*const T` sacara implisit) ku alamatna tibatan ngabandingkeun nilaina anu ditunjuk (anu dilakukeun ku implementasi `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Irisan ogé dibandingkeun ku panjangna (pojok gajih):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits ogé dibandingkeun ku ngalaksanakeunana:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Pointer gaduh alamat anu sami.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Obyek gaduh alamat anu sami, tapi `Trait` ngagaduhan implementasi anu béda.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ngarobih rujukan kana `*const u8` ngabandingkeun dumasar alamat.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash panunjuk atah.
///
/// Ieu tiasa dianggo pikeun Hash rujukan `&T` (anu maksa ka `*const T` sacara implisit) ku alamatna tibatan nilai anu ditunjuk (anu naon anu dilakukeun ku `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Ngalaksanakeun pikeun panunjuk fungsi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Anu matak panengah salaku panggunaan diperyogikeun pikeun AVR
                // sahingga rohangan alamat pointer fungsi sumber dilestarikan dina panunjuk fungsi akhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Anu matak panengah salaku panggunaan diperyogikeun pikeun AVR
                // sahingga rohangan alamat pointer fungsi sumber dilestarikan dina panunjuk fungsi akhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Henteu aya fungsi variadis sareng 0 parameter
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Ngadamel pointer atah `const` ka tempat, henteu nganggo rujukan panengah.
///
/// Nyiptakeun rujukan nganggo `&`/`&mut` ngan ukur kénging upami panunjuk leres leres sareng nunjuk kana data anu diinisialisasi.
/// Pikeun kasus anu saratna henteu dicekel, petunjuk atah kedah dianggo tibatan.
/// Nanging, `&expr as *const _` nyiptakeun rujukan sateuacan nempatkeun kana panunjuk atah, sareng rujukan éta tunduk kana aturan anu sami sareng sadaya rujukan anu sanés.
///
/// Makro ieu tiasa nyiptakeun pointer atah *tanpa* nyiptakeun rujukan heula.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` bakal nyiptakeun référénsi anu teu disaluyukeun, sareng janten Perilaku Undefined!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Ngadamel pointer atah `mut` ka tempat, henteu nganggo rujukan panengah.
///
/// Nyiptakeun rujukan nganggo `&`/`&mut` ngan ukur kénging upami panunjuk leres leres sareng nunjuk kana data anu diinisialisasi.
/// Pikeun kasus anu saratna henteu dicekel, petunjuk atah kedah dianggo tibatan.
/// Nanging, `&mut expr as *mut _` nyiptakeun rujukan sateuacan nempatkeun kana panunjuk atah, sareng rujukan éta tunduk kana aturan anu sami sareng sadaya rujukan anu sanés.
///
/// Makro ieu tiasa nyiptakeun pointer atah *tanpa* nyiptakeun rujukan heula.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` bakal nyiptakeun référénsi anu teu disaluyukeun, sareng janten Perilaku Undefined!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` pasukan nyalin lapangan tibatan nyiptakeun rujukan.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}