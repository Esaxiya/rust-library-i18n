use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` tapi henteu nol sareng kovarian.
///
/// Ieu sering hal anu leres pikeun digunakeun nalika ngawangun struktur data nganggo petunjuk atah, tapi pamustunganana langkung bahaya dianggo kusabab sipat tambahan na.Upami anjeun henteu yakin kana naha anjeun kedah nganggo `NonNull<T>`, kantun nganggo `*mut T`!
///
/// Beda sareng `*mut T`, panunjuk kedah teras-terasan, bahkan upami panunjukna henteu pernah disérénkeun.Ieu supados enums tiasa nganggo nilai terlarang ieu salaku diskriminatif-`Option<NonNull<T>>` gaduh ukuran anu sami sareng `* mut T`.
/// Nanging panunjukna masih tiasa ngagantung upami henteu diséferénsi.
///
/// Teu kawas `*mut T`, `NonNull<T>` kapilih janten covarian leuwih `T`.Hal ieu ngamungkinkeun ngagunakeun `NonNull<T>` nalika ngawangun jinis kovarian, tapi ngenalkeun résiko kagorengan upami dianggo dina jinis anu henteu kedah leres-leres kovarian.
/// (Pilihan anu sabalikna pikeun `*mut T` sanaos sacara téknis unsoundness éta ngan bisa disababkeun ku nelepon fungsi teu aman.)
///
/// Covariance leres pikeun paling abstraksi anu aman, sapertos `Box`, `Rc`, `Arc`, `Vec`, sareng `LinkedList`.Ieu hal sabab aranjeunna nyayogikeun API umum anu nuturkeun aturan XOR mutable biasa tina Rust.
///
/// Mun tipe anjeun moal bisa aman jadi covarian, Anjeun kudu mastikeun eta ngandung sababaraha widang tambahan nyadiakeun invariance.Seringna lapangan ieu bakal janten jinis [`PhantomData`] sapertos `PhantomData<Cell<T>>` atanapi `PhantomData<&'a mut T>`.
///
/// Bewara nu `NonNull<T>` ngabogaan conto `From` pikeun `&T`.Nanging, ieu henteu ngarobih kanyataan yén mutasi ngalangkungan (pointer diturunkeun tina) rujukan anu dibagi nyaéta paripolah anu teu ditangtoskeun kecuali upami mutasi kajantenan dina [`UnsafeCell<T>`].Hal anu sami pikeun nyiptakeun rujukan anu tiasa dirobih tina rujukan anu dibagi.
///
/// Nalika nganggo conto `From` ieu tanpa `UnsafeCell<T>`, tanggung jawab anjeun pikeun mastikeun yén `as_mut` henteu pernah disebat, sareng `as_ptr` henteu kantos dianggo pikeun mutasi.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` petunjuk henteu `Send` sabab data anu aranjeunna rujukan tiasa janten alias alias.
// NB, impl ieu perlu, tapi kedah nyadiakeun seratan kasalahan hadé.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers henteu `Sync` lantaran data aranjeunna nuduhkeun bisa jadi aliased.
// NB, impl ieu perlu, tapi kedah nyadiakeun seratan kasalahan hadé.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Nyiptakeun `NonNull` anyar anu ngagantung, tapi saé pisan.
    ///
    /// Ieu gunana pikeun ngainisialisasi jinis anu puguh dialokasikan, sapertos `Vec::new`.
    ///
    /// Catet yén nilai pointer berpotensi ngagambarkeun pointer anu valid kana `T`, anu hartosna ieu henteu kedah dianggo salaku nilai "not yet initialized" sentinel.
    /// Jenis anu teu puguh alokasi kedah ngalacak inisialisasi ku cara sanésna.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KESELAMATAN: mem::align_of() mulihkeun panggunaan anu teu nol anu teras dialungkeun
        // ka * mut T.
        // Ku alatan éta, `ptr` henteu batal sareng kaayaan nelepon new_unchecked() dipikahormat.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Mulihkeun rujukan anu dibagi kana nilaina.Béda sareng [`as_ref`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Mulih hiji rujukan unik keur nilai nu.Béda sareng [`as_mut`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun anu tara dibagi tingali [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Nyiptakeun `NonNull` anyar.
    ///
    /// # Safety
    ///
    /// `ptr` kedah non-batal.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: panelepon kedah ngajamin yén `ptr` henteu nol.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ngadamel `NonNull` énggal upami `ptr` sanés batal.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Kaamanan: pointer parantos dipariksa sareng henteu nol
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Laksanakeun pungsionalitas anu sami sareng [`std::ptr::from_raw_parts`], kajabi pointer `NonNull` dipulang, sabalikna tina panunjuk `*const` atah.
    ///
    ///
    /// Tingali dokuméntasi [`std::ptr::from_raw_parts`] pikeun langkung jelasna.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAFETY: Hasil tina `ptr::from::raw_parts_mut` henteu nol kusabab `data_address` nyaéta.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ngurai titik (panginten lega) kana alamat sareng komponén metadata.
    ///
    /// Pointer tiasa engké didamel deui sareng [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Acquires anu ngadasar `*mut` pointer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Mulihkeun rujukan anu dibagi kana nilaina.Upami nilaina tiasa uninitialized, [`as_uninit_ref`] kedah dianggo gantina.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Penunjuk kedah nunjuk kana conto anu dimimitian tina `T`.
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    /// (Bagéan ngeunaan diinisialisasi henteu acan diputuskeun sapinuhna, tapi dugi ka éta, hiji-hijina cara anu aman nyaéta pikeun mastikeun yén aranjeunna memang diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        unsafe { &*self.as_ptr() }
    }

    /// Mulih rujukan unik kana nilaina.Upami nilaina tiasa uninitialized, [`as_uninit_mut`] kedah dianggo gantina.
    ///
    /// Pikeun anu tara dibagi tingali [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * Panunjuk kedah leres-leres dijajarkeun.
    ///
    /// * Éta kedah "dereferencable" dina hartos anu ditetepkeun dina [the module documentation].
    ///
    /// * Penunjuk kedah nunjuk kana conto anu dimimitian tina `T`.
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    /// (Bagéan ngeunaan diinisialisasi henteu acan diputuskeun sapinuhna, tapi dugi ka éta, hiji-hijina cara anu aman nyaéta pikeun mastikeun yén aranjeunna memang diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // syarat pikeun rujukan anu tiasa dirobih.
        unsafe { &mut *self.as_ptr() }
    }

    /// Dihaturkeun kana panunjuk tina jinis sanés.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` mangrupikeun pointer `NonNull` anu kuduna henteu batal
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Nyiptakeun non-null nyiksikan atah ti pointer ipis jeung panjang a.
    ///
    /// Argumen `len` mangrupikeun jumlah unsur **, sanés jumlah bait.
    ///
    /// Pungsi ieu aman, tapi ngabébaskeun nilai balik teu aman.
    /// Tingali dokuméntasi [`slice::from_raw_parts`] pikeun syarat kaamanan nyiksikan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // jieun pointer keureut nalika dimimitian ku panunjuk kana unsur anu munggaran
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Catet yén conto ieu sacara artifisial nunjukkeun panggunaan metoda ieu, tapi `hayu keureut= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` mangrupikeun pointer `NonNull` anu kuduna henteu batal
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Balikkeun panjang irisan atah anu teu nol.
    ///
    /// Nilai anu dipulangkeun nyaéta jumlah **elemen**, sanés jumlah bait.
    ///
    /// Fungsi ieu aman, sanaos irisan atah anu sanés henteu tiasa dikaluarkeun tina potongan sabab pointer henteu ngagaduhan alamat anu valid.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Mulih hiji non-null pointer kana panyangga anu nyiksikan urang.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAFETY: Kami terang `self` henteu null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Balikkeun pointer atah kana panyangga irisan.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ngahasilkeun rujukan anu dibagikeun kana sapotong nilai anu henteu tiasa diinisialisasi.Béda sareng [`as_ref`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun tara anu tiasa dirobih tingali [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * Penunjuk kedah [valid] kanggo maos pikeun `ptr.len() * mem::size_of::<T>()` seueur bait, sareng éta kedah leres-leres dijantenkeun.Hartosna khususna:
    ///
    ///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
    ///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.
    ///
    ///     * Pointer kedah diluyukeun bahkan pikeun irisan panjang-enol.
    ///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
    ///
    ///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
    ///   Tingali dokuméntasi kaamanan [`pointer::offset`].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu dimutasi (kecuali dina `UnsafeCell`).
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// Tingali ogé [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Mulihkeun rujukan unik kana sapotong nilai-nilai anu teu tiasa dicantumkeun.Béda sareng [`as_mut`], ieu henteu meryogikeun yén nilaina kedah diinisialisasi.
    ///
    /// Pikeun anu tara dibagi tingali [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Nalika nelepon metoda ieu, anjeun kedah mastikeun yén sadayana ieu leres.
    ///
    /// * pointer kudu [valid] pikeun maos teras nyerat keur `ptr.len() * mem::size_of::<T>()` loba bait, sarta eta kudu Blok leres.Hartosna khususna:
    ///
    ///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
    ///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.
    ///
    ///     * Pointer kedah diluyukeun bahkan pikeun irisan panjang-enol.
    ///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
    ///
    ///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
    ///
    /// * Ukuran total `ptr.len() * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
    ///   Tingali dokuméntasi kaamanan [`pointer::offset`].
    ///
    /// * Anjeun kedah ngalaksanakeun aturan aliasing Rust, kumargi hirupna `'a` anu kapengker dipilih sawenang-wenang sareng henteu merta ngagambarkeun umur data anu saleresna.
    ///   Khususna, salami waktos ieu, mémori anu ditunjuk pointer kedahna henteu tiasa diaksés (dibaca atanapi ditulis) ngalangkungan panunjuk anu sanés.
    ///
    /// Ieu lumaku sanajan hasil tina metode ieu henteu kapake!
    ///
    /// Tingali ogé [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ieu aman sabab `memory` valid pikeun maca sareng nyerat pikeun `memory.len()` seueur bait.
    /// // Catet yén nyauran `memory.as_mut()` henteu kénging di dieu sabab eusina tiasa uninitialisasi.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Balikkeun pointer atah kana unsur atanapi langganan, tanpa kedah dilakukeun batesan.
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates atanapi nalika `self` henteu dileungitkeun nyaéta *[tingkah laku anu teu ditangtoskeun]* sanajan panunjuk anu dihasilkeun henteu dianggo.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KESELAMATAN: panelepon mastikeun yén `self` henteu tiasa dibébaskeun sareng `index` di-wates.
        // Akibatna, pointer anu dihasilkeun moal tiasa NUL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // Kaamanan: Pointer anu unik henteu tiasa batal, janten kaayaan pikeun
        // new_unchecked() anu dipikahormat.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Kasalametan: A rujukan mutable teu kaci hypothesis.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAFETY: Rujukan moal tiasa batal, janten kaayaan pikeun
        // new_unchecked() anu dipikahormat.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}