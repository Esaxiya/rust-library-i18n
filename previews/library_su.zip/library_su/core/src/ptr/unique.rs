use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Pembungkus sakitar `*mut T` non-null atah anu nunjukkeun yén anu ngagaduhan bungkus ieu ngagaduhan referén.
/// Mangpaat pikeun ngawangun abstraksi sapertos `Box<T>`, `Vec<T>`, `String`, sareng `HashMap<K, V>`.
///
/// Beda sareng `*mut T`, `Unique<T>` kalakuanana "as if" éta mangrupikeun conto tina `T`.
/// Éta ngalaksanakeun `Send`/`Sync` upami `T` nyaéta `Send`/`Sync`.
/// Éta ogé ngakibatkeun jinis aliasing anu kuat ngajamin conto `T` anu tiasa diarepkeun:
/// anu ngarujuk tina tutunjuk henteu kedah dirobih tanpa jalan anu unik pikeun Milik na Unik.
///
/// Upami anjeun henteu yakin naha leres ngagunakeun `Unique` pikeun tujuan anjeun, pertimbangkeun nganggo `NonNull`, anu ngagaduhan semantik anu langkung lemah.
///
///
/// Beda sareng `*mut T`, pointer kedah teras-terasan, bahkan upami panunjukna henteu pernah disérénkeun.
/// Ieu supados enums tiasa nganggo nilai terlarang ieu salaku diskriminatif-`Option<Unique<T>>` ngagaduhan ukuran anu sami sareng `Unique<T>`.
/// Nanging panunjukna masih tiasa ngagantung upami henteu diséferénsi.
///
/// Béda sareng `*mut T`, `Unique<T>` nyaéta kovarian langkung ti `T`.
/// Ieu kedah leres-leres leres pikeun naon waé anu netepkeun syarat aliasing Unik.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: panyiri ieu teu aya akibat pikeun varian, tapi perlu
    // pikeun dropck ngartos yén urang sacara logis ngagaduhan `T`.
    //
    // Kanggo detil, tingali:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` petunjuk anu `Send` upami `T` nyaéta `Send` kusabab data anu aranjeunna rujukan teu dialihkeun.
/// Catet yén invasiant aliasing ieu henteu dikuatkeun ku sistem jenis;abstraksi anu nganggo `Unique` kedah ngalaksanakeunnana.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` petunjuk anu `Sync` upami `T` nyaéta `Sync` kusabab data anu aranjeunna rujukan teu dialihkeun.
/// Catet yén invasiant aliasing ieu henteu dikuatkeun ku sistem jenis;abstraksi anu nganggo `Unique` kedah ngalaksanakeunnana.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Nyiptakeun `Unique` anyar anu ngagantung, tapi saé pisan.
    ///
    /// Ieu gunana pikeun ngainisialisasi jinis anu puguh dialokasikan, sapertos `Vec::new`.
    ///
    /// Catet yén nilai pointer berpotensi ngagambarkeun pointer anu valid kana `T`, anu hartosna ieu henteu kedah dianggo salaku nilai "not yet initialized" sentinel.
    /// Jenis anu teu puguh alokasi kedah ngalacak inisialisasi ku cara sanésna.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // Kasalametan: mem::align_of() mulih a valid, non-null pointer.The
        // kaayaan pikeun nelepon new_unchecked() sahingga terhormat.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Nyiptakeun `Unique` anyar.
    ///
    /// # Safety
    ///
    /// `ptr` kedah non-batal.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: panelepon kedah ngajamin yén `ptr` henteu nol.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ngadamel `Unique` énggal upami `ptr` sanés batal.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Kaamanan: pointer parantos dipariksa sareng henteu nol.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Acquires anu ngadasar `*mut` pointer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferénsina eusina.
    ///
    /// Kahirupan anu dihasilkeun pasti aya dina diri jadi ieu kalakuan "as if" éta saleresna mangrupikeun conto tina T anu bakal diinjeum.
    /// Upami umur (unbound) langkung lami diperyogikeun, anggo `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // sarat pikeun rujukan.
        unsafe { &*self.as_ptr() }
    }

    /// Bisa ogé dereferénsi eusina.
    ///
    /// Kahirupan anu dihasilkeun pasti aya dina diri jadi ieu kalakuan "as if" éta saleresna mangrupikeun conto tina T anu bakal diinjeum.
    /// Upami umur (unbound) langkung lami diperyogikeun, anggo `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAFETY: panelepon kedah ngajamin yén `self` minuhan sadayana
        // syarat pikeun rujukan anu tiasa dirobih.
        unsafe { &mut *self.as_ptr() }
    }

    /// Dihaturkeun kana panunjuk tina jinis sanés.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAFETY: Unique::new_unchecked() nyiptakeun unik sareng kabutuhan anu anyar
        // pointer anu dipasihkeun janten teu nolih.
        // Kusabab urang ngalirkeun dirina salaku panunjuk, éta moal tiasa batal.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KESELAMATAN: Rujukan anu teu tiasa dipotong henteu tiasa batal
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}