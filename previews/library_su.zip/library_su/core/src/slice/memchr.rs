// Palaksanaan aslina dicandak tina rust-memchr.
// Hak cipta 2015 Andrew Gallant, bluss sareng Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Anggo truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Mulih `true` upami `x` ngandung nol bait.
///
/// Tina *Perkara Komputasional*, J. Arndt:
///
/// "Idéna nyaéta ngirangan hiji tina masing-masing bait teras milari bait dimana peminjam disebarkeun dugi ka anu paling signifikan
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Balikkeun indéks munggaran anu cocog sareng bait `x` dina `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Jalan gancang pikeun keureut leutik
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan pikeun hiji nilai bait ku maca dua kecap `usize` dina hiji waktu.
    //
    // Pamisah `text` dina tilu bagian
    // - bagian awal anu teu disaluyukeun, sateuacan kecap anu munggaran dijajarkeun alamat dina téks
    // - awak, scan ku 2 kecap dina hiji waktu
    // - bagian sésana terakhir, <2 ukuran kecap

    // milarian dugi ka wates anu cocog
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // milarian awak téks
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAFETY: predikat bari ngajamin jarak sahenteuna 2 * usize_bytes
        // antara offset sareng tungtung keureut.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // putus upami aya bait anu cocog
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Milarian bait saatos titik loop awak dieureunkeun.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Balikkeun indéks terakhir anu cocog sareng bait `x` dina `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan pikeun hiji nilai bait ku maca dua kecap `usize` dina hiji waktu.
    //
    // Dibeulah `text` di tilu bagian:
    // - buntut henteu cocog, saatos kecap terakhir dijajarkeun alamat dina téks,
    // - awak, discan ku 2 kecap dina hiji waktu,
    // - bait sésana anu mimiti, <2 ukuran kecap.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Urang nelepon ieu ngan pikeun ménta panjang awalan jeung ahiran.
        // Di tengahna urang sok ngolah dua sakaligus sakaligus.
        // KESELAMATAN: ngirimkeun `[u8]` ka `[usize]` aman kecuali béda ukuran anu diurus ku `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Milarian awak téksna, pastikeun kami henteu nyebrang min_aligned_offset.
    // offset ieu salawasna Blok, jadi ngan nguji `>` cukup tur avoids mungkin mudal.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // Kasalametan: offset dimimitian dina Ilen, suffix.len(), salami éta leuwih gede ti
        // min_aligned_offset (prefix.len()) jarak sésana téh sahanteuna 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Putus upami aya bait anu cocog.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Milarian bait sateuacan titik loop awak dieureunkeun.
    text[..offset].iter().rposition(|elt| *elt == x)
}