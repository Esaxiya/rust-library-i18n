//! Operasi kana ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Pariksa naha sadaya bait dina potongan ieu aya dina kisaran ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Pariksa yén dua keureut mangrupikeun pertandingan anu teu peka kasus ASCII.
    ///
    /// Sarua sareng `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tapi henteu aya alokasi sareng nyalin samentawis.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ngarobih keureutan ieu kana kasus luhur ASCII na sami-sami.
    ///
    /// hurup ASCII 'a' mun 'z' anu dipetakeun kana 'A' mun 'Z', tapi hurup non-ASCII anu unchanged.
    ///
    /// Pikeun ngabalikeun nilai nilai luhur anu énggal tanpa ngarobih anu parantos aya, anggo [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ngarobih keureutan ieu kana ASCII bisi handap anu sami dina tempatna.
    ///
    /// Huruf ASCII 'A' dugi 'Z' dipetakeun ka 'a' dugi 'z', tapi hurup sanés ASCII henteu robih.
    ///
    /// Pikeun ngabalikeun nilai anu handap anu handap dina modeu tanpa ngarobih anu parantos aya, anggo [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Balikkeun `true` upami aya bait dina kecap `v` nyaéta nonascii (>=128).
/// Snarfed ti `../str/mod.rs`, anu ngalakukeun hal anu sami pikeun validasi utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Tes ASCII anu dioptimalkeun anu bakal nganggo operasi usize-at-a-time tibatan operasi byte-at-a-time (nalika dimungkinkeun).
///
/// Algoritma anu kami anggo di dieu cukup saderhana.Mun `s` teuing pondok, urang ngan pariksa tiap bait sarta dipigawé kalawan eta.Upami teu kitu:
///
/// - Maca kecap munggaran kalayan beban anu teu dijadwalkeun.
/// - Blokkeun panunjuk, baca kecap-kecap salajengna dugi ka réngsé ku beban anu dijajarkeun.
/// - Baca `usize` panungtungan ti `s` kalawan beban unaligned.
///
/// Upami salah sahiji beban ieu ngahasilkeun naon anu `contains_nonascii` (above) mulih leres, maka urang terang jawabanana salah.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Upami urang henteu kéngingkeun naon-naon tina palaksanaan kecap-sakaligus, murag deui ka loop skalar.
    //
    // Kami ogé ngalakukeun ieu pikeun arsitéktur dimana `size_of::<usize>()` henteu cocog pikeun `usize`, kusabab éta kasus edge anu anéh.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Urang sok maca kecap anu mimitina teu disaluyukeun, anu hartosna `align_offset` nyaéta
    // 0, urang bakal maca nilai anu sami deui pikeun bacaan anu parantos dibéréskeun.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // Kaamanan: Kami mastikeun `len < USIZE_SIZE` di luhur.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Urang dipariksa kieu luhur, aya sababaraha hal implicitly.
    // Catet yén `offset_to_aligned` boh `align_offset` atanapi `USIZE_SIZE`, duanana jelas-jelas diparios di luhur.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr mangrupikeun (leres dijajarkeun) nganggo ptr anu urang anggo pikeun maca
    // potongan tengah keureutan.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` nyaéta indeks bait `word_ptr`, dianggo pikeun pamariksaan loop tungtung.
    let mut byte_pos = offset_to_aligned;

    // Paranoia mariksa ngeunaan keselarasan, sabab urang badé ngalakukeun sakumpulan beban anu teu disaluyukeun.
    // Dina praktékna ieu kedah teu mungkin ngalarang bug dina `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Baca kecap saterusna dugi kecap Blok panungtungan, kaasup kecap Blok panungtungan ku sorangan dipigawé di pariksa buntut engké, pikeun mastikeun buntut anu sok salah `usize` di paling mun tambahan branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity parios yén anu dibaca aya dina wates
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Sareng éta asumsi urang ngeunaan `byte_pos` tahan.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAFETY: Kami terang `word_ptr` leres dijajarkeun (kusabab
        // `align_offset`), sareng kami terang yén kami ngagaduhan cukup bait antara `word_ptr` sareng akhir
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // Kaamanan: Urang terang yén `byte_pos <= len - USIZE_SIZE`, anu hartosna éta
        // saatos `add` ieu, `word_ptr` bakal paling tiheula-hiji-tungtung.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity pariksa pikeun mastikeun aya bener ngan hiji `usize` ditinggalkeun.
    // Ieu kedah dijamin ku kaayaan gelung urang.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // Kaamanan: Ieu gumantung ka `len >= USIZE_SIZE`, anu urang parios di mimitian.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}