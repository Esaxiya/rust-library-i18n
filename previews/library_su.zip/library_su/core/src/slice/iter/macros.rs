//! Makro anu dianggo ku iterator tina irisan.

// Inlining is_empty sareng len ngajantenkeun bédana kinerja anu ageung
macro_rules! is_empty {
    // Cara urang ngodekeun panjang Iterator ZST, ieu tiasa dianggo pikeun ZST sareng non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Pikeun meunang leupas tina sababaraha bounds cék (tingali `position`), urang itung panjang dina cara rada kaduga.
// (Diuji ku `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // urang kadang dianggo dina blok anu teu aman

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ ieu nganggo `unchecked_sub` sabab urang gumantung kana bungkus pikeun ngagambarkeun panjang iterator irisan ZST panjang.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Kami terang yén `start <= end`, janten tiasa ngalakukeun langkung saé tibatan `offset_from`, anu kedah diungkulan ditandatanganan.
            // Ku netepkeun panji anu cocog di dieu urang tiasa nyarios ka LLVM ieu, anu ngabantosan éta ngaleupaskeun cék wates.
            // SAFETY: Ku jenis invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ku ogé nétélakeun LLVM yén pointers anu mencar ku hiji sababaraha pasti tina ukuran tipe, éta bisa ngaoptimalkeun `len() == 0` handap ka `start == end` tinimbang `(end - start) < size`.
            //
            // SAFETY: Ku jenis invariant, petunjuk dijejerankeun janten
            //         jarak antara aranjeunna kedah janten sababaraha ukuran pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Definisi dibagikeun tina iterator `Iter` sareng `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Malikeun unsur anu munggaran sareng mindahkeun awal iterator payun ku 1.
        // Ningkatkeun pisan kinerja dibandingkeun sareng fungsi inline.
        // Iter na kedahna kosong.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Malikeun unsur panungtung sareng mindahkeun tungtung iterator ka tukang ku 1.
        // Ningkatkeun pisan kinerja dibandingkeun sareng fungsi inline.
        // Iter na kedahna kosong.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Nyusut iterator nalika T nyaéta ZST, ku mindahkeun tungtung iterator mundur ku `n`.
        // `n` henteu kedah ngaleuwihan `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Fungsi bantosan pikeun nyiptakeun sapotong tina iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: iterator didamel tina potongan sareng pointer
                // `self.ptr` tur panjang `len!(self)`.
                // Ieu ngajamin yén sadaya prasyarat pikeun `from_raw_parts` parantos réngsé.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Fungsi pembantun pikeun mindahkeun awal iterator payun ku elemen `offset`, mulihkeun mimiti anu lami.
            //
            // Henteu aman sabab offset kedah henteu langkung ti `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAFETY: panelepon ngajamin yén `offset` henteu langkung ti `self.len()`,
                    // janten pointer énggal ieu aya di jero `self` sahingga dijamin moal batal.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Fungsi pembantun kanggo mindahkeun tungtung iterator mundur ku elemen `offset`, mulihkeun tungtung anu anyar.
            //
            // Henteu aman sabab offset kedah henteu langkung ti `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAFETY: panelepon ngajamin yén `offset` henteu langkung ti `self.len()`,
                    // anu dijamin moal ngabahekeun `isize`.
                    // Ogé, pointer anu dihasilkeun aya dina wates `slice`, anu minuhan sarat anu sanés pikeun `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // bisa dilaksanakeun ku irisan, tapi ieu nyingkahan cek bounds

                // SAFETY: Telepon `assume` aman sabab pointer mimiti sapotong
                // kedah non-nol, sareng keureut tina non-ZSTs ogé kedah ngagaduhan pointer tungtung non-nol.
                // Telepon ka `next_unchecked!` aman sabab urang parios upami iteratorna kosong heula.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iterator ieu ayeuna kosong.
                    if mem::size_of::<T>() == 0 {
                        // Urang kedah ngalakukeun ieu ku cara `ptr` moal pernah janten 0, tapi `end` tiasa (kusabab dibungkus).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAFETY: tungtung moal tiasa 0 upami T sanés ZST kusabab ptr sanés 0 sareng tungtung>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // Kaamanan: Kami aya dina wates.`post_inc_start` ngalakukeun anu leres bahkan pikeun ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            // Ogé, `assume` ngahindaran cek bounds.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // Kaamanan: kami dijamin bakal aya dina wates ku gelandang invariant:
                        // nalika `i >= n`, `self.next()` mulih `None` sareng puteran putus.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Kami nimpa palaksanaan standar, anu nganggo `try_fold`, sabab palaksanaan saderhana ieu ngahasilkeun kirang LLVM IR sareng langkung gancang pikeun nyusun.
            // Ogé, `assume` ngahindaran cek bounds.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAFETY: `i` kedah langkung handap tina `n` kumargi dimimitian dina `n`
                        // sareng ngan ukur ngirangan.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAFETY: panelepon kedah ngajamin yén `i` aya dina wates
                // keureutan anu janten dasarna, janten `i` moal tiasa ngabahekeun `isize`, sareng rujukan anu dikembalikan dijamin ngarujuk kana unsur tina irisan sahingga dijamin janten valid.
                //
                // Ogé perhatos yén anu nelepon ogé ngajamin yén kami henteu kantos disebat nganggo indéks anu sami deui, sareng yén teu aya metode anu sanés anu bakal ngaksés langganan ieu anu disebat, janten sah pikeun rujukan anu dipulangkeun tiasa dimutasi dina kasus
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // bisa dilaksanakeun ku irisan, tapi ieu nyingkahan cek bounds

                // KESELAMATAN: Telepon `assume` aman sabab pointer mimiti sapotong kedah non-batal,
                // sareng keureut tina non-ZST ogé kedah ngagaduhan pointer tungtung non-nol.
                // Telepon ka `next_back_unchecked!` aman sabab urang parios upami iteratorna kosong heula.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iterator ieu ayeuna kosong.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // Kasalametan: Urang aya di bounds.`pre_dec_end` manten hal katuhu malah keur ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}