//! Fungsi bébas pikeun nyiptakeun `&[T]` sareng `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Ngabentuk potongan tina panunjuk sareng panjang.
///
/// Argumen `len` mangrupikeun jumlah unsur **, sanés jumlah bait.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `data` kedah janten [valid] pikeun maos pikeun `len * mem::size_of::<T>()` loba bait, sarta eta kudu Blok leres.Hartosna khususna:
///
///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.Tingali [below](#incorrect-usage) pikeun conto anu salah henteu tumut kana akun ieu.
///     * `data` kedah non-nol sareng Blok bahkan pikeun keureut enol-panjang.
///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
///
/// * `data` kedah nunjuk kana `len` padeukeut nilai awal anu diinisialisasi tina tipe `T`.
///
/// * Memori anu dirujuk ku irisan anu dikintunkeun henteu kedah dirobih salami umur `'a`, kecuali dina `UnsafeCell`.
///
/// * Ukuran total `len * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
///   Tingali dokuméntasi kaamanan [`pointer::offset`].
///
/// # Caveat
///
/// Hirupna kanggo irisan anu dikembalikan disimpulkeun tina panggunaanana.
/// Pikeun nyegah panyalahgunaan anu teu disahaja, disarankeun pikeun ngabeungkeut hirupna kana sumber hirup anu mana waé anu aman dina kontéksna, sapertos ku nyayogikeun fungsi pembantu anu hirup salami nilai host pikeun potongan, atanapi ku anotasi anu jelas.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // wujudkeun sapotong pikeun hiji unsur
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Pamakéan salah
///
/// handap Fungsi `join_slices` nyaeta **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Cindekna di luhur mastikeun `fst` sareng `snd` caket, tapi éta tiasa dikandung dina _different allocated objects_, dina hal ieu nyiptakeun potongan ieu kabiasaan anu teu ditangtoskeun.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` sarta `b` mangrupakeun obyek disadiakeun béda ...
///     let a = 42;
///     let b = 27;
///     // ... nu bisa Tapi jadi diteundeun kaluar contiguously dina mémori: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Laksanakeun pungsionalitas anu sami sareng [`from_raw_parts`], kajabi sapotong anu tiasa dirobih dikembalikan.
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `data` kedah [valid] pikeun duanana maca sareng nyerat pikeun `len * mem::size_of::<T>()` seueur bait, sareng éta kedah leres-leres dijajarkeun.Hartosna khususna:
///
///     * Sakabeh rentang memori potongan ieu kedah dikandung dina hiji obyék anu dialokasikeun!
///       Irisan henteu pernah tiasa dibentang di sababaraha obyék anu dialokasikan.
///     * `data` kedah non-nol sareng Blok bahkan pikeun keureut enol-panjang.
///     Hiji alesan pikeun ieu nyaéta optimasi perenah enum tiasa ngandelkeun rujukan (kalebet potongan iraha panjangna) anu dijajarkeun sareng teu nolih ngabédakeunana tina data sanés.
///
///     Anjeun tiasa kéngingkeun pointer anu tiasa dianggo salaku `data` pikeun potongan enol panjang nganggo [`NonNull::dangling()`].
///
/// * `data` kedah nunjuk kana `len` padeukeut nilai awal anu diinisialisasi tina tipe `T`.
///
/// * Memori anu dirujuk ku irisan anu dikintunkeun henteu kedah diaksés ngalangkungan petunjuk naon waé (sanés diturunkeun tina nilai balik) salami umur `'a`.
///   Boh aksés maca sareng nyerat dilarang.
///
/// * Ukuran total `len * mem::size_of::<T>()` tina irisan kedah henteu langkung ageung dibandingkeun `isize::MAX`.
///   Tingali dokuméntasi kaamanan [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Ngarobih rujukan kana T kana sapotong panjang 1 (tanpa nyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Ngarobih rujukan kana T kana sapotong panjang 1 (tanpa nyalin).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}