// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Muterkeun rentang `[mid-left, mid+right)` sapertos anu unsur dina `mid` janten unsur anu munggaran.Sarua, muterkeun rentang unsur `left` ka kénca atanapi elemen `right` ka katuhu.
///
/// # Safety
///
/// Kisaran anu parantos ditangtoskeun kedah valid pikeun maca sareng nyerat.
///
/// # Algorithm
///
/// Algoritma 1 dianggo kanggo nilai alit `left + right` atanapi kanggo `T` ageung.
/// Unsur-unsur dipindahkeun kana posisi akhirna hiji-hiji mimitian jam `mid - left` sareng maju ku `right` léngkah modulo `left + right`, sapertos anu diperyogikeun ngan ukur samentawis.
/// Antukna, urang dugi deui dina `mid - left`.
/// Nanging, upami `gcd(left + right, right)` sanés 1, léngkah-léngkah di luhur ngalangkungan elemen.
/// Salaku conto:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Untungna, jumlah unsur anu diloloskeun antara unsur-unsur finalis sami-sami, janten urang tiasa ngimbangan posisi awal sareng ngalakukeun langkung seueur babak (jumlah total babak nyaéta `gcd(left + right, right)` value).
///
/// Hasil ahirna nyaéta sadaya unsur direngsekeun sakali sareng sakali.
///
/// Algoritma 2 digunakeun lamun `left + right` téh badag tapi `min(left, right)` cukup leutik pikeun nyocogkeun onto hiji panyangga tumpukan.
/// Unsur `min(left, right)` disalin kana panyangga, `memmove` dilarapkeun ka anu sanésna, sareng anu dina panyangga dipindahkeun deui kana liang dina sisi anu sabalikna dimana éta asalna.
///
/// Algoritma anu tiasa di-vectorize langkung luhur di luhur sakali `left + right` janten cekap ageung.
/// Algoritma 1 bisa vectorized ku chunking Calung loba rounds sakaligus, tapi aya teuing sababaraha rounds rata-rata dugi `left + right` téh loba pisan, sarta hal awon tina hiji babak tunggal sok aya.
/// Sabalikna, algoritma 3 nganggo swap berulang unsur `min(left, right)` dugi masalah rotasi anu langkung alit deui.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// lamun `left < right` swapping nu kajadian ti kénca gantina.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritma di handap tiasa gagal upami kasus-kasus ieu henteu diparios
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritma 1 Mikrobenchmark nunjukkeun yén kinerja rata-rata pikeun pergeseran acak langkung saé sapanjang jalan dugi ka `left + right == 32`, tapi pagelaran kasus anu paling parah pegatna bahkan sakitar 16.
            // 24 kapilih salaku jalan tengah.
            // Upami ukuran `T` langkung ageung tibatan 4 'usize`s, algoritma ieu ogé langkung saé dina algoritma anu sanés.
            //
            //
            let x = unsafe { mid.sub(left) };
            // mimiti babak kahiji
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` tiasa dipanggihan sateuacan tangan ku ngitung `gcd(left + right, right)`, tapi langkung gancang pikeun ngalakukeun hiji loop anu ngitung gcd salaku efek samping, teras ngalakukeun sesa potongan.
            //
            //
            let mut gcd = right;
            // tolok ukur ngungkabkeun yén langkung gancang pikeun silih tukeur samentawis jalan tibatan maca hiji samentawis sakali, salin ka tukang, teras nyerat anu samentawis dina tungtung pisan.
            // Ieu tiasa disababkeun ku kanyataan yén ngaganti atanapi ngaganti samentawis ngan ukur nganggo hiji alamat mémori dina loop tibatan kedah ngatur dua.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // tinimbang nambahan `i` teras parios naha éta di luar wates, urang parios naha `i` bakal lebet luar wates dina paningkatan salajengna.
                // Ieu nyegah bungkus pointers atanapi `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // tungtung babak kahiji
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // saratna ieu kedah aya didieu upami `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // rengse dina chunk kalawan leuwih rounds
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` sanés jinisna ukuran nol, janten teu kunanaon pikeun ngabagi ku ukuran na.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritma 2 `[T; 0]` di dieu pikeun mastikeun yén ieu cocog pikeun T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritma 3 Aya hiji cara séjén swapping anu ngalibatkeun nyungsi mana anu swap panungtungan tina algoritma ieu bakal janten, sareng swapping ngagunakeun éta chunk panungtungan tinimbang swapping sakumpulan padeukeut kawas algoritma ieu lakukeun, tapi cara ieu téh masih gancang.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritma 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}