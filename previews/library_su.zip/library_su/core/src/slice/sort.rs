//! Nyortir keureutan
//!
//! Modul ieu ngandung algoritma asihan dumasar kana corak Orson Peters 'anu ngéléhkeun pola, diterbitkeun dina: <https://github.com/orlp/pdqsort>
//!
//!
//! Asihan henteu stabil kompatibel sareng libcore kusabab éta henteu nyayogikeun mémori, henteu sapertos palaksanaan asihan stabil kami.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nalika turun, salinan tina `src` kana `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // Kasalametan: Ieu kelas nulungan.
        //          Mangga tingali panggunaanna pikeun leresna.
        //          Nyaéta, salah kedah pastikeun yén `src` sareng `dst` henteu tumpang tindih sakumaha anu dibutuhkeun ku `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ngalihkeun unsur kahiji ka katuhu dugi ka pendakan sareng unsur anu langkung ageung atanapi sami.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Operasi anu henteu aman di handap ngalibatkeun pengindeksan tanpa cek anu kabeungkeut (`get_unchecked` sareng `get_unchecked_mut`)
    // sareng nyalin mémori (`ptr::copy_nonoverlapping`).
    //
    // a.Ngindeks:
    //  1. Kami parios ukuran tina larik kana>=2.
    //  2. Sagala indexing yen urang bakal ngalakukeun sok antara {0 <= index < len} di paling.
    //
    // b.memori Niron
    //  1. Kami ngumpulkeun pointers kana rujukan nu dijamin janten sah.
    //  2. Aranjeunna henteu tiasa tumpang tindih sabab kami kéngingkeun petunjuk kana bédana indéks tina wilah.
    //     Nyaéta, `i` sareng `i-1`.
    //  3. Upami keureut leres dijejeran, unsur-unsur leres leres.
    //     Éta tanggung jawab anu nélépon pikeun mastikeun keureut leres-leres dijajarkeun.
    //
    // Tingali koméntar di handap pikeun langkung detil.
    unsafe {
        // Upami dua unsur anu mimitina kaluar-tina-urutan ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Maca unsur kahiji kana variabel anu dialokasikeun.
            // Upami operasi ngabandingkeun panics ieu, `hole` bakal turun sareng sacara otomatis nyerat unsur deui kana keureutan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mindahkeun `i`-th unsur hiji tempat ka kénca, sahingga mindahkeun liang kana katuhu.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bakal turun teras nyalin `tmp` kana liang sésana dina `v`.
        }
    }
}

/// Mindahkeun unsur panungtung ka kénca dugi ka pendakan sareng unsur anu langkung alit atanapi sami.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAFETY: Operasi anu henteu aman di handap ngalibatkeun pengindeksan tanpa cek anu kabeungkeut (`get_unchecked` sareng `get_unchecked_mut`)
    // sareng nyalin mémori (`ptr::copy_nonoverlapping`).
    //
    // a.Ngindeks:
    //  1. Kami parios ukuran tina larik kana>=2.
    //  2. Sadaya indéks anu bakal kami laksanakeun nyaéta antara `0 <= index < len-1` paling henteu.
    //
    // b.memori Niron
    //  1. Kami ngumpulkeun pointers kana rujukan nu dijamin janten sah.
    //  2. Aranjeunna henteu tiasa tumpang tindih sabab kami kéngingkeun petunjuk kana bédana indéks tina wilah.
    //     Nyaéta, `i` sareng `i+1`.
    //  3. Upami keureut leres dijejeran, unsur-unsur leres leres.
    //     Éta tanggung jawab anu nélépon pikeun mastikeun keureut leres-leres dijajarkeun.
    //
    // Tingali koméntar di handap pikeun langkung detil.
    unsafe {
        // Upami dua unsur terakhir teu di-order ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Maca unsur panungtung kana variabel anu dialokasikeun.
            // Upami operasi ngabandingkeun panics ieu, `hole` bakal turun sareng sacara otomatis nyerat unsur deui kana keureutan.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mindahkeun `i`-th unsur hiji tempat ka katuhu, sahingga shifting liang ka kénca.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bakal turun teras nyalin `tmp` kana liang sésana dina `v`.
        }
    }
}

/// Sawaréh nyortir sapotong ku mindahkeun sababaraha unsur kaluar-urutan di dieu.
///
/// Mulih `true` upami keureutan diurut dina tungtung.Fungsi ieu nyaéta *O*(*n*) kasus anu paling parah.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Jumlah maksimum pasangan kaluar-of-order anu padeukeut anu bakal ngalih.
    const MAX_STEPS: usize = 5;
    // Upami irisan langkung pondok tina ieu, tong mindahkeun unsur naon waé.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // Kaamanan: Kami parantos jelas-jelas ngalakukeun pamariksaan anu pasti sareng `i < len`.
        // Sadaya pengindeksan urang salajengna ngan ukur dina kisaran `0 <= index < len`
        unsafe {
            // Milarian pasangan unsur-unsur kaluar-tina-urutan anu caket.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Naha urang parantos bérés?
        if i == len {
            return true;
        }

        // Entong ngalih elemen dina susunan pondok, éta ngagaduhan biaya kinerja.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tukeuran pasangan unsur anu dipendakan.Ieu nempatkeun aranjeunna dina urutan anu leres.
        v.swap(i - 1, i);

        // Mindahkeun unsur anu langkung alit ka kénca.
        shift_tail(&mut v[..i], is_less);
        // Mindahkeun elemen anu langkung ageung ka katuhu.
        shift_head(&mut v[i..], is_less);
    }

    // Teu ngatur nyortir nu nyiksikan di angka kawates hambalan.
    false
}

/// Nyortir sapotong nganggo sisipan sisipan, nyaéta *O*(*n*^ 2) bisi awon.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Nyortir `v` nganggo heapsort, anu ngajamin *O*(*n*\*log(* n*)) kasus awon.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tumpukan binér ieu ngahargaan `parent >= child` anu invarian.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Barudak tina `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Milih anak anu langkung ageung.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Eureun upami invarian tahan di `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Tukeur `node` sareng murangkalih anu langkung ageung, ngalih saléngkah, sareng teraskeun ayak.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Ngawangun numpuk dina jangka waktu linier.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Unsur unsur maksimal tina tumpukan.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partisi `v` kana unsur anu langkung alit tibatan `pivot`, dituturkeun ku elemen anu langkung ageung tibatan atanapi sami sareng `pivot`.
///
///
/// Mulih jumlah unsur langkung alit tibatan `pivot`.
///
/// Partisi dilakukeun blok-demi-blok pikeun ngaminimalkeun biaya operasi cabang.
/// Ideu ieu dipidangkeun dina makalah [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Jumlah elemen dina blok has.
    const BLOCK: usize = 128;

    // Algoritma partisi ngulang léngkah ieu dugi ka réngsé:
    //
    // 1. Lacak blok ti beulah kénca pikeun ngaidéntifikasi elemen anu langkung ageung tibatan atanapi sami sareng pangsi.
    // 2. Lacak blok ti beulah katuhu pikeun ngaidéntifikasi elemen anu langkung alit tibatan pangsi.
    // 3. Bursa unsur dicirikeun antara kénca jeung samping katuhu.
    //
    // Simkuring tetep variabel handap pikeun blok elemen:
    //
    // 1. `block` - Jumlah elemen dina blok.
    // 2. `start` - Mimitian pointer kana Asép Sunandar Sunarya `offsets`.
    // 3. `end` - Mungkas pointer kana Asép Sunandar Sunarya `offsets`.
    // 4. `offset, Indéks unsur kaluar-urutan dina blok.

    // Blok ayeuna di sisi kénca (ti `l` dugi ka `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blok ayeuna di sisi katuhu (tina `r.sub(block_r)` to `r`).
    // Kasalametan: The dokuméntasi pikeun .add() husus disebatkeun yen `vec.as_ptr().add(vec.len())` sok safe`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Nalika urang kéngingkeun VLAs, cobian ngadamel hiji Asép Sunandar Sunarya panjang `min(v.len(), 2 * BLOCK) `langkung
    // ti dua susunan ukuran-ukuran panjang `BLOCK`.VLAs bisa jadi leuwih cache-efisien.

    // Mulih jumlah unsur antara pointers `l` (inclusive) na `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kami beres ku ngabagi blok-demi-blok nalika `l` sareng `r` caket pisan.
        // Teras we ngalakukeun sababaraha padamelan tambalan supados tiasa ngabagi unsur-unsur sésana di antawisna.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Jumlah unsur sésana (tetep henteu dibandingkeun sareng pangsi).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Saluyukeun ukuran blok sahingga blok kénca sareng katuhu henteu tumpang tindih, tapi kedah sampurna pikeun nutupan jurang sésana.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Lacak elemen `block_l` ti sisi kénca.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // Kasalametan: The operasi unsafety handap ngalibetkeun pamakéan tina `offset`.
                //         Nurutkeun kondisi diperlukeun ku fungsi nu kami nyugemakeun aranjeunna kusabab:
                //         1. `offsets_l` nyaeta tumpukan-disadiakeun, sahingga dianggap misah obyék disadiakeun.
                //         2. Fungsi `is_less` mulihkeun `bool`.
                //            Casting `bool` moal pernah ngabahekeun `isize`.
                //         3. Kami parantos ngajamin yén `block_l` bakal `<= BLOCK`.
                //            Tambih Deui, `end_l` mimitina disetél ka pointer mimiti `offsets_` anu dinyatakeun dina tumpukan.
                //            Ku kituna, urang terang yen sanajan dina hal awon (sadayana invocations of `is_less` mulih palsu) urang ngan bakal di paling 1 bait lulus tungtungna.
                //        Operasi anu teu aman anu sanés di dieu nyaéta dereferencing `elem`.
                //        Nanging, `elem` mimitina mangrupikeun pointer pikeun keureutan anu sok valid.
                unsafe {
                    // Babandingan tanpa cabang.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Lacak elemen `block_r` ti beulah katuhu.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // Kasalametan: The operasi unsafety handap ngalibetkeun pamakéan tina `offset`.
                //         Nurutkeun kondisi diperlukeun ku fungsi nu kami nyugemakeun aranjeunna kusabab:
                //         1. `offsets_r` nyaeta tumpukan-disadiakeun, sahingga dianggap misah obyék disadiakeun.
                //         2. Fungsi `is_less` mulihkeun `bool`.
                //            Casting `bool` moal pernah ngabahekeun `isize`.
                //         3. Kami geus dijamin nu `block_r` bakal `<= BLOCK`.
                //            Tambih Deui, `end_r` mimitina disetél ka pointer mimiti `offsets_` anu dinyatakeun dina tumpukan.
                //            Maka, urang terang yén sanajan dina kasus anu paling parah (sadaya panyundaan `is_less` mulih leres) urang ngan ukur paling henteu 1 byte bakal lulus.
                //        Operasi anu teu aman anu sanés di dieu nyaéta dereferencing `elem`.
                //        Sanajan kitu, `elem` éta mimitina `1 *sizeof(T)` kaliwat tungtung jeung kami decrement eta ku `1* sizeof(T)` saméméh ngakses eta.
                //        Tambih Deui, `block_r` negeskeun kirang ti `BLOCK` sareng `elem` ku sabab éta paling bakal nunjukkeun awal keureutan.
                unsafe {
                    // Babandingan tanpa cabang.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Jumlah elemen kaluar-urutan pikeun tukeur antara kénca sareng katuhu.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Gantina swapping hiji pasangan wanoh, ieu leuwih efisien jeung ngalakukeun permutation siklik.
            // Ieu henteu sami pisan sareng pertukaran, tapi ngahasilkeun hasil anu sami nganggo operasi memori anu kirang.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Kabéh kaluar-of-urutan elemen dina blok ditinggalkeun anu dipindahkeun.Pindahkeun ka blok salajengna.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Kabéh kaluar-of-urutan elemen dina blok katuhu anu dipindahkeun.Pindahkeun ka blok sateuacanna.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Kabéh nu tetep kiwari nyaeta dina paling hiji blok (boh kénca atawa katuhu) jeung kaluar-of-urutan elemen anu kudu jadi dipindahkeun.
    // Unsur sésana sapertos kitu tiasa dialihkeun dugi ka akhir dina blokna.
    //

    if start_l < end_l {
        // Blok kénca tetep.
        // Mindahkeun elemen sésa-sésa na kaluar ti katuhu ka katuhu.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blok katuhu tetep.
        // Mindahkeun unsur sésa-sésa na kénca ka kénca paling kénca.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nanaon lain jeung ngalakukeun, urang geus rengse.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` kana elemen leutik batan `v[pivot]`, dituturkeun ku elemen gede ti atanapi sarua keur `v[pivot]`.
///
///
/// Mulihkeun tuple tina:
///
/// 1. Jumlah elemen langkung alit tibatan `v[pivot]`.
/// 2. Leres upami `v` ieu geus bagi.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Tempatkeun pangsi dina awal keureutan.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Baca pangsi kana variabel tumpukan-alokasi pikeun épisiénsi.
        // Mun operasi ngabandingkeun handap panics, pangsi nu bakal otomatis ditulis deui kana nyiksikan teh.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Milarian pasangan unsur kaluar-tina-urutan anu munggaran.
        let mut l = 0;
        let mut r = v.len();

        // SAFETY: The unsafety handap ngalibatkeun indexing hiji Asép Sunandar Sunarya.
        // Pikeun anu munggaran: Kami parantos ngalaksanakeun wates mariksa di dieu ku `l < r`.
        // Pikeun anu kadua: Mimitina urang ngagaduhan `l == 0` sareng `r == v.len()` sareng kami parios yén `l < r` dina unggal operasi pengindeksan.
        //                     Ti dieu urang terang yén `r` kedah sahenteuna `r == l` anu kabuktian sah ti anu munggaran.
        unsafe {
            // Teangan nu leuwih gede unsur kahiji ti atanapi sarua jeung pangsi nu.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Manggihan unsur panungtungan leutik nu pangsi nu.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` mana kaluar tina wengkuan teras nyerat dina pangsi (anu ngarupakeun variabel tumpukan-disadiakeun) deui kana nyiksikan dimana eta asalna éta.
        // Léngkah ieu penting pikeun mastikeun kasalametan!
        //
    };

    // Tempatkeun pangsi antara dua partisi.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitions `v` kana elemen sarua keur `v[pivot]` dituturkeun ku elemen gede ti `v[pivot]`.
///
/// Mulih jumlah unsur anu sami sareng pangsi.
/// Diasumsikeun yén `v` henteu ngandung unsur anu langkung alit tibatan pangsi.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tempatkeun pangsi dina awal keureutan.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Baca pangsi kana variabel tumpukan-alokasi pikeun épisiénsi.
    // Mun operasi ngabandingkeun handap panics, pangsi nu bakal otomatis ditulis deui kana nyiksikan teh.
    // Kasalametan: pointer di dieu valid sabab ieu dicandak ti rujukan pikeun nyiksikan a.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ayeuna partisi keureutan.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAFETY: The unsafety handap ngalibatkeun indexing hiji Asép Sunandar Sunarya.
        // Pikeun anu munggaran: Kami parantos ngalaksanakeun wates mariksa di dieu ku `l < r`.
        // Pikeun anu kadua: Mimitina urang ngagaduhan `l == 0` sareng `r == v.len()` sareng kami parios yén `l < r` dina unggal operasi pengindeksan.
        //                     Ti dieu urang terang yén `r` kedah sahenteuna `r == l` anu kabuktian sah ti anu munggaran.
        unsafe {
            // Teangan nu leuwih gede unsur kahiji ti pangsi nu.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Milarian unsur panungtung sami sareng pangsi.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Naha urang parantos bérés?
            if l >= r {
                break;
            }

            // Swap pasangan kapanggih tina kaluar-of-urutan elemen.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Kami mendakan unsur `l` sami sareng pangsi.Tambahkeun 1 kana akun pangsi éta sorangan.
    l + 1

    // `_pivot_guard` mana kaluar tina wengkuan teras nyerat dina pangsi (anu ngarupakeun variabel tumpukan-disadiakeun) deui kana nyiksikan dimana eta asalna éta.
    // Léngkah ieu penting pikeun mastikeun kasalametan!
}

/// Nyebarkeun sababaraha unsur sakitar usaha pikeun megatkeun pola anu tiasa nyababkeun partisi henteu saimbang dina quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom number generator tina kertas "Xorshift RNGs" karya George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Candak angka acak Modulo angka ieu.
        // Jumlahna pas kana `usize` kusabab `len` henteu langkung ageung tibatan `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Sababaraha calon pangsi bakal di caket dieu di indéks ieu.Hayu urang acak aranjeunna.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ngahasilkeun angka acak modulo `len`.
            // Nanging, pikeun nyingkahan operasi anu mahal, urang mimiti nyandak modulo kakuatan dua, teras turun ku `len` dugi ka pas kana kisaran `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` dijamin kirang ti `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Pilih hiji pangsi di `v` na mulih indéks jeung `true` lamun nyiksikan ieu dipikaresep geus disusun.
///
/// Unsur dina `v` panginten tiasa disusun deui dina prosés.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Panjang minimum pikeun milih metodeu median-of-medians.
    // keureut pondok ngagunakeun padika basajan median-of-tilu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Jumlah maksimum swap anu tiasa dilakukeun dina fungsi ieu.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tilu indéks deukeut nu urang bade milih pangsi a.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Ngitung jumlah total swap anu urang badé laksanakeun nalika milah indéks.
    let mut swaps = 0;

    if len >= 8 {
        // Tukeur indeks supados `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Tukeur indeks supados `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Manggih median tina `v[a - 1], v[a], v[a + 1]` jeung toko indéks kana `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Manggihan medians di neighborhoods of `a`, `b`, sarta `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Milari médiana diantara `a`, `b`, sareng `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Jumlah maksimum swaps ieu dipigawé.
        // Kasempetan anu keureut turun atanapi seueurna turun, janten ngabalikkeun sigana tiasa ngabantosan langkung gancang.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorts `v` recursively.
///
/// Upami nyiksikan kagungan miheulaan dina Asép Sunandar Sunarya aslina, éta dieusian sakumaha `pred`.
///
/// `limit` nyaéta jumlah partisi anu henteu saé anu diidinan sateuacan ngalih ka `heapsort`.
/// Mun enol, fungsi ieu bakal geuwat pindah ka heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Irisan dugi ka panjang ieu tiasa diurut nganggo sisipan sisipan.
    const MAX_INSERTION: usize = 20;

    // Leres upami partisi terakhir saimbang saimbang.
    let mut was_balanced = true;
    // Leres upami partisi pamungkas henteu ngacak unsur-unsur (sapotong parantos dipilahkeun).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Irisan pondok pisan tiasa diurut nganggo sisipan sisipan.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Upami seueur teuing pilihan pangsi anu goréng parantos dilakukeun, kantun mundur kana heapsort pikeun ngajamin `O(n * log(n))`-kasus anu paling parah.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Upami partisi anu terakhir henteu saimbang, cobian corak pola dina keureutan ku ngacak sababaraha elemen di sakitar.
        // Mudah-mudahan urang bakal milih pangsi anu langkung saé ayeuna.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pilih pangsi sareng cobian tebak naha irisanna parantos diurutkeun.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Mun nu ngabagi panungtungan ieu decently saimbang sarta teu ngacak elemen, sarta lamun Pilihan pangsi prédiksi nyiksikan ieu dipikaresep geus disusun ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Coba idéntifikasi sababaraha elemen kaluar-tina-urutan sareng mindahkeun éta pikeun ngabenerkeun posisi.
            // Upami keureut tungtungna diurutkeun lengkep, urang parantos réngsé.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Upami pangsi anu dipilih sami sareng anu sateuacanna, maka éta unsur pangleutikna dina potongan.
        // Partisi keureutan kana unsur anu sami sareng unsur anu langkung ageung tibatan pangsi.
        // Kasus ieu biasana pencét nalika keureut ngandung seueur unsur duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nuluykeun asihan elemen gede ti pangsi nu.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Pisahkeun keureutan.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Beulah keureut kana `left`, `pivot`, sareng `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Recurse kana sisi anu langkung pondok pikeun ngaleutikan total jumlah panggero rekursif sareng nyéépkeun ruang tumpukan anu kirang.
        // Teras teras teraskeun sareng sisi anu langkung lami (ieu mirip sareng recursion buntut).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Nyortir `v` nganggo pola-ngéléhkeun quicksort, nyaéta *O*(*n*\*log(* n*)) kasus awon.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Asihan henteu ngagaduhan paripolah anu bermakna pikeun jinis ukuran nol.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ngawatesan jumlah partisi henteu saimbang kana `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kanggo irisan dugi ka panjangna ieu sigana langkung gancang pikeun ngan saukur nyortirkeunana.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Milih pangsi
        let (pivot, _) = choose_pivot(v, is_less);

        // Upami pangsi anu dipilih sami sareng anu sateuacanna, maka éta unsur pangleutikna dina potongan.
        // Partisi keureutan kana unsur anu sami sareng unsur anu langkung ageung tibatan pangsi.
        // Kasus ieu biasana pencét nalika keureut ngandung seueur unsur duplikat.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Upami kami parantos lulus indéks kami, maka kami saé.
                if mid > index {
                    return;
                }

                // Upami teu kitu, teraskeun asihan unsur-unsur anu langkung ageung tibatan pangsi.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Beulah keureut kana `left`, `pivot`, sareng `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Upami pertengahan==indéks, maka urang parantos, kumargi partition() ngajamin yén sadaya unsur saatos pertengahan langkung ageung tibatan atanapi sami sareng pertengahan.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Asihan henteu ngagaduhan paripolah anu bermakna pikeun jinis ukuran nol.Teu nanaon.
    } else if index == v.len() - 1 {
        // Milarian elemen maks sareng tempatkeun dina posisi terakhir tina larik.
        // Kami bébas nganggo `unwrap()` di dieu sabab kami terang v kedahna kosong.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Milarian unsur min sareng tempatkeun dina posisi mimiti Asép Sunandar Sunarya.
        // Kami bébas nganggo `unwrap()` di dieu sabab kami terang v kedahna kosong.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}