// ignore-tidy-filelength

//! Manajemén keureut sareng manipulasi.
//!
//! Kanggo langkung jelasna tingali [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Murni rust palaksanaan memchr, dicokot tina rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Fungsi ieu ngan ukur umum kusabab teu aya jalan anu sanés pikeun unit test heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Mulih jumlah unsur dina keureutan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // KESELAMATAN: sora const sabab urang ngalirkeun lapangan panjang salaku usize (anu kedahna)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAFETY: ieu aman sabab `&[T]` sareng `FatPtr<T>` gaduh tata perenah anu sami.
            // Ngan `std` anu tiasa ngajamin ieu.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ngaganti kalayan `crate::ptr::metadata(self)` nalika éta nyaéta const-stabil.
            // Dina tulisan ieu, ieu nyababkeun kasalahan "Const-stable functions can only call other const-stable functions".
            //

            // SAFETY: Ngaksés nilaina tina union `PtrRepr` aman saprak * const T
            // sareng PtrComponents<T>gaduh perenah memori anu sami.
            // Ngan std tiasa ngajamin ieu.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Mulih `true` upami keureut panjangna 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Balikkeun unsur mimiti keureutan, atanapi `None` upami kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Balikkeun petunjuk anu tiasa dirobih kana unsur mimiti tina keureut, atanapi `None` upami kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Mulih anu mimiti sareng sésana tina unsur keureut, atanapi `None` upami kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Mulih anu mimiti sareng sésana tina unsur keureut, atanapi `None` upami kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Balikkeun unsur panungtung sareng sésana tina potongan, atanapi `None` upami éta kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Balikkeun unsur panungtung sareng sésana tina potongan, atanapi `None` upami éta kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Mulih unsur pamungkas nyiksikan, atanapi `None` lamun éta kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Balikkeun petunjuk anu tiasa dirobih kana barang anu terakhir dina keureutan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Mulihkeun rujukan kana unsur atanapi langganan gumantung kana jinis indéksna.
    ///
    /// - Upami dipasihan posisi, mulihkeun rujukan kana unsur dina posisi éta atanapi `None` upami kaluar tina wates.
    ///
    /// - Upami dipasihan jajaran, balikkeun langganan anu saluyu sareng kisaran éta, atanapi `None` upami kaluar tina wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Mulihkeun rujukan anu tiasa dirobih kana unsur atanapi langganan gumantung kana jinis indéks (tingali [`get`]) atanapi `None` upami indéksna diluar wates.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Mulih hiji rujukan ka unsur atawa subslice, tanpa ngalakonan bounds mariksa.
    ///
    /// Pikeun alternatif anu aman tingali [`get`].
    ///
    /// # Safety
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates nyaéta *[kabiasaan teu ditangtoskeun]* sanajan rujukan anu dihasilkeun henteu dianggo.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // KESELAMATAN: anu nelepon kedah ngajaga kalolobaan sarat kaamanan pikeun `get_unchecked`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Mulihkeun rujukan anu tiasa dirobih kana unsur atanapi langganan, tanpa kedah dilakukeun batesan.
    ///
    /// Pikeun alternatif anu aman tingali [`get_mut`].
    ///
    /// # Safety
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates nyaéta *[kabiasaan teu ditangtoskeun]* sanajan rujukan anu dihasilkeun henteu dianggo.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: anu nelepon kedah ngajaga syarat kaamanan pikeun `get_unchecked_mut`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Balikkeun pointer atah kana panyangga irisan.
    ///
    /// panelepon kudu mastikeun yén nyiksikan teh outlives pointer fungsi ieu mulih, atawa nu sejenna deui bakal mungkas nepi ngarah ka sampah.
    ///
    /// panelepon oge kudu mastikeun yén mémori nu pointer (non-transitively) titik mun geus pernah ditulis keur (iwal di jero hiji `UnsafeCell`) ngagunakeun pointer ieu atawa pointer diturunkeun tina eta.
    /// Upami anjeun kedah mutasi eusi keureutan, anggo [`as_mut_ptr`].
    ///
    /// Ngarobih wadah anu dirujuk ku irisan ieu tiasa nyababkeun panyangga na dialokasikan deui, anu ogé bakal ngajantenkeun petunjuk naon anu henteu leres.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Balikkeun pointer anu teu tiasa dirobih kana panyangga irisan.
    ///
    /// panelepon kudu mastikeun yén nyiksikan teh outlives pointer fungsi ieu mulih, atawa nu sejenna deui bakal mungkas nepi ngarah ka sampah.
    ///
    /// Ngarobih wadah anu dirujuk ku irisan ieu tiasa nyababkeun panyangga na dialokasikan deui, anu ogé bakal ngajantenkeun petunjuk naon anu henteu leres.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Balikkeun dua pojok atah dugi ka keureut.
    ///
    /// Kisaran anu dibalikkeun satengah kabuka, anu hartosna titik pointer tungtung *hiji mangsa ka pengker* unsur terakhir tina potongan.
    /// Ku cara ieu, sapotong kosong diwakilan ku dua pointer anu sami, sareng bédana antara dua pointer nunjukkeun ukuran potongan.
    ///
    /// Tingali [`as_ptr`] pikeun peringatan ngeunaan panggunaan petunjuk ieu.Pointer tungtung ngabutuhkeun ati-ati tambahan, sabab henteu nunjukkeun unsur anu valid dina keureutan.
    ///
    /// Fungsi ieu gunana pikeun berinteraksi sareng interfaces asing anu nganggo dua petunjuk pikeun ngarujuk kana sababaraha unsur dina mémori, sapertos anu biasa di C++ .
    ///
    ///
    /// Éta ogé tiasa manpaat pikeun mariksa naha panunjuk kana hiji unsur nuduhkeun unsur tina potongan ieu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SAFETY: `add` didieu aman, sabab:
        //
        //   - Kadua petunjuk mangrupikeun bagian tina obyék anu sami, sabab nunjukkeun langsung ka tukang obyék ogé kaitung.
        //
        //   - Ukuran irisan henteu pernah langkung ageung tibatan isize::MAX bait, sakumaha nyatet di dieu:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Teu aya bungkus anu kalebet, sabab irisan henteu dibungkus dina tungtung rohangan alamat.
        //
        // Tempo dokuméntasi tina pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Mulihkeun dua petunjuk anu teu tiasa dirobih henteu leres dugi ka keureut.
    ///
    /// Kisaran anu dibalikkeun satengah kabuka, anu hartosna titik pointer tungtung *hiji mangsa ka pengker* unsur terakhir tina potongan.
    /// Ku cara ieu, sapotong kosong diwakilan ku dua pointer anu sami, sareng bédana antara dua pointer nunjukkeun ukuran potongan.
    ///
    /// Tempo [`as_mut_ptr`] pikeun warnings on maké pointers ieu.
    /// Pointer tungtung ngabutuhkeun ati-ati tambahan, sabab henteu nunjukkeun unsur anu valid dina keureutan.
    ///
    /// Fungsi ieu gunana pikeun berinteraksi sareng interfaces asing anu nganggo dua petunjuk pikeun ngarujuk kana sababaraha unsur dina mémori, sapertos anu biasa di C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // Kasalametan: Tempo as_ptr_range() luhur keur naha `add` dieu téh aman.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Tukeuran dua unsur dina keureutan.
    ///
    /// # Arguments
    ///
    /// * a, Indéks unsur munggaran
    /// * b, Indéks unsur kadua
    ///
    /// # Panics
    ///
    /// Panics upami `a` atanapi `b` kaluar tina wates.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Henteu tiasa nyandak dua pinjaman anu tiasa dirobih tina hiji vector, janten sanés nganggo petunjuk atah.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` sareng `pb` parantos didamel tina rujukan anu tiasa dirobih aman sareng refer
        // kana unsur-unsur dina keureutan sahingga dijamin valid sareng sajajar.
        // Catetan yen ngakses unsur balik `a` na `b` geus dipariksa sarta bakal panic nalika kaluar tina bounds.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ngabalikeun urutan unsur dina keureutan, dina tempatna.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Pikeun jinis anu alit pisan, sadaya individu maos dina jalur normal ngalakukeun goréng.
        // Urang tiasa langkung saé, dibéré épisién load/store anu teu disaluyukeun deui, ku ngamuat sapotong anu langkung ageung sareng ngabalikkeun daptar.
        //

        // Idéalna LLVM bakal ngalakukeun ieu pikeun urang, sabab éta langkung terang tibatan urang naha maca anu teu disaluyuan épisién (kusabab éta parobihan antara versi ARM anu beda, contona) sareng ukuran potongan anu pangsaéna.
        // Hanjakalna, ngeunaan LLVM 4.0 (2017-05) éta ngan ukur muka gulung, janten urang kedah ngalakukeun ieu nyalira.
        // (Hipotesis: tibalik matak nyusahkeun sabab sisina tiasa dijajarkeun béda-bakal, nalika panjangna ganjil-janten teu aya cara pikeun ngaluarkeun pra-sareng postludes nganggo SIMD anu lengkep dina tengahna.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Anggo llvm.bswap intrinsik pikeun ngabalikeun u8s dina usize
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // Kaamanan: Aya sababaraha hal anu kedah diperiksa di dieu:
                //
                // - Catet yén `chunk` mangrupikeun 4 atanapi 8 kusabab cek CFg di luhur.Janten `chunk - 1` positip.
                // - Indéks sareng indéks `i` henteu saé sabab jaminan cek loop
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indéks sareng indéks `ln - i - chunk = ln - (i + chunk)` henteu kunanaon:
                //   - `i + chunk > 0` leres sepele.
                //   - Cék loop ngajamin:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, sahingga pangirangan henteu turun.
                // - Telepon `read_unaligned` sareng `write_unaligned` henteu kunanaon:
                //   - `pa` nunjuk kana indéks `i` dimana `i < ln / 2 - (chunk - 1)` (tempo di luhur) sareng `pb` nunjuk kana indéks `ln - i - chunk`, janten duanana sahenteuna `chunk` seueur bait jauh ti tungtung `self`.
                //
                //   - Sagala mémori inisialisasi valid `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Anggo muterkeun-demi-16 pikeun ngabalikkeun u16 dina u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // KESELAMATAN: u32 anu teu aya tandingan tiasa dibaca ti `i` upami `i + 1 < ln`
                // (sareng jelas `i < ln`), kusabab masing-masing elemen aya 2 bait sareng urang nuju maca 4.
                //
                // `i + chunk - 1 < ln / 2` # bari kaayaan
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Kusabab éta kirang tina panjang dibagi kana 2, maka éta kedah dina wates.
                //
                // Ieu ogé ngandung harti yén kaayaan `0 < i + chunk <= ln` sok dihormat, mastikeun pointer `pb` tiasa dianggo kalayan aman.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SAFETY: `i` langkung handap tina satengah panjang potongan dugi ka
            // ngakses `i` sareng `ln - i - 1` aman (`i` mimitian jam 0 sareng moal langkung ti `ln / 2 - 1`).
            // pointers anu dihasilkeun `pa` na `pb` aya kituna valid tur Blok, sarta bisa maca tina na ditulis keur.
            //
            //
            unsafe {
                // Tukeuran teu aman pikeun nyingkahan bounds cek di swap aman.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Balikkeun iterator dina keureutan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Mulang iterator anu ngamungkinkeun ngarobih unggal nilaina.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Balikkeun iterator dina sadaya windows anu caket tina `size`.
    /// windows tindih.
    /// Upami keureutna langkung pondok tibatan `size`, iterator moal ngahasilkeun nilai.
    ///
    /// # Panics
    ///
    /// Panics upami `size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Mun nyiksikan teh nyaeta pondok ti `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// Potongan éta keureut sareng henteu tumpang tindih.Upami `chunk_size` henteu ngabagi panjang keureutan, maka potongan terakhir moal gaduh panjang `chunk_size`.
    ///
    /// Tingali [`chunks_exact`] pikeun varian iterator ieu anu mulih potongan sakaligus persis unsur `chunk_size`, sareng [`rchunks`] kanggo iterator anu sami tapi dimimitian dina tungtung irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// The sakumpulan anu keureut mutable, sarta ulah tumpang tindihna.Upami `chunk_size` henteu ngabagi panjang keureutan, maka potongan terakhir moal gaduh panjang `chunk_size`.
    ///
    /// Tingali [`chunks_exact_mut`] pikeun varian iterator ieu anu mulih potongan sakaligus persis unsur `chunk_size`, sareng [`rchunks_mut`] kanggo iterator anu sami tapi dimimitian dina tungtung irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// Potongan éta keureut sareng henteu tumpang tindih.
    /// Upami `chunk_size` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `chunk_size-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `remainder` tina iterator.
    ///
    ///
    /// Kusabab masing-masing potongan gaduh elemen `chunk_size` persis, panyusun sering tiasa ngaoptimalkeun kode anu dihasilkeun langkung saé tibatan dina kasus [`chunks`].
    ///
    /// Tingali [`chunks`] pikeun varian iterator ieu anu ogé ngabalikeun sésana salaku potongan anu langkung alit, sareng [`rchunks_exact`] kanggo iterator anu sami tapi dimimitian dina tungtung irisan.
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// Potongan ieu irisan mutable, sareng henteu tumpang tindih.
    /// Upami `chunk_size` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `chunk_size-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `into_remainder` tina iterator.
    ///
    ///
    /// Kusabab masing-masing potongan gaduh elemen `chunk_size` persis, panyusun sering tiasa ngaoptimalkeun kode anu dihasilkeun langkung saé tibatan dina kasus [`chunks_mut`].
    ///
    /// Tingali [`chunks_mut`] pikeun varian iterator ieu anu ogé ngabalikeun sésana salaku potongan anu langkung alit, sareng [`rchunks_exact_mut`] kanggo iterator anu sami tapi dimimitian dina tungtung irisan.
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Splits nyiksikan teh kana nyiksikan tina `arrays N`-unsur, asumsina yén aya aya sésana.
    ///
    ///
    /// # Safety
    ///
    /// Ieu ngan ukur tiasa disebat iraha
    /// - Irisan beulah persis kana sakumpulan `N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SAFETY: potongan 1-unsur henteu kantos gaduh sésana
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // KESELAMATAN: Panjang irisan (6) mangrupikeun kalikeun 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ieu bakal teu leres:
    /// // antepkeun potongan: &[[_;5]]= slice.as_chunks_unchecked()//Panjang wilah sanés sababaraha kali tina 5 ngantep sakedik:&[[_;0]] sakumpulan= slice.as_chunks_unchecked()//Zero-panjang anu pernah diwenangkeun
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KESELAMATAN: Prasyarat kami nyaéta naon anu diperyogikeun pikeun nyauran ieu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Kami tuang sapotong elemen `new_len * N` kana
        // sapotong `new_len` seueur elemen `N` sakumpulan.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Beulahkeun keureut kana sapotong susunan `N`-element, dimimitian dina awal keureutan, sareng sésa sésa kalayan panjangna kirang kirang ti `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // Kaamanan: Kami parantos panik pikeun nol, sareng mastikeun ku pangwangunan
        // yén panjangna subslice mangrupikeun sababaraha tina N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Splits nu nyiksikan kana nyiksikan tina `arrays N`-unsur, dimimitian dina ahir nyiksikan teh, sarta nyiksikan sésana kalayan panjangna mastikeun kirang ti `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // Kaamanan: Kami parantos panik pikeun nol, sareng mastikeun ku pangwangunan
        // yén panjangna subslice mangrupikeun sababaraha tina N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Balikkeun iterator langkung tina unsur `N` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// Sakumpulan mangrupikeun referensi susunan sareng henteu tumpang tindih.
    /// Upami `N` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `N-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `remainder` tina iterator.
    ///
    ///
    /// Metoda ieu teh const generik sarua [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Splits nyiksikan teh kana nyiksikan tina `arrays N`-unsur, asumsina yén aya aya sésana.
    ///
    ///
    /// # Safety
    ///
    /// Ieu ngan ukur tiasa disebat iraha
    /// - Irisan beulah persis kana sakumpulan `N`-element (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SAFETY: potongan 1-unsur henteu kantos gaduh sésana
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // KESELAMATAN: Panjang irisan (6) mangrupikeun kalikeun 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ieu bakal teu leres:
    /// // antepkeun potongan: &[[_;5]]= slice.as_chunks_unchecked_mut()//Panjang wilah sanés sababaraha kali tina 5 ngantep sakedik:&[[_;0]]= slice.as_chunks_unchecked_mut()//Gugus panjang-panjang teu kénging
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // KESELAMATAN: Prasyarat kami nyaéta naon anu diperyogikeun pikeun nyauran ieu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SAFETY: Kami tuang sapotong elemen `new_len * N` kana
        // sapotong `new_len` seueur elemen `N` sakumpulan.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Beulahkeun keureut kana sapotong susunan `N`-element, dimimitian dina awal keureutan, sareng sésa sésa kalayan panjangna kirang kirang ti `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // Kaamanan: Kami parantos panik pikeun nol, sareng mastikeun ku pangwangunan
        // yén panjangna subslice mangrupikeun sababaraha tina N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Splits nu nyiksikan kana nyiksikan tina `arrays N`-unsur, dimimitian dina ahir nyiksikan teh, sarta nyiksikan sésana kalayan panjangna mastikeun kirang ti `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // Kaamanan: Kami parantos panik pikeun nol, sareng mastikeun ku pangwangunan
        // yén panjangna subslice mangrupikeun sababaraha tina N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Balikkeun iterator langkung tina unsur `N` tina keureutan dina hiji waktos, dimimitian dina awal keureut.
    ///
    /// Potongan mangrupikeun rujukan anu tiasa dirobih sareng henteu tumpang tindih.
    /// Upami `N` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `N-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `into_remainder` tina iterator.
    ///
    ///
    /// Metoda ieu mangrupikeun sarimbag umum generik [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics lamun `N` nyaeta 0. dipariksa ieu bakal paling meureun perlu dirobah ka kasalahan waktu compile saméméh metoda ieu bakal stabilized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Balikkeun iterator ngalangkungan windows tina elemen `N` sapotong, dimimitian dina mimiti keureut.
    ///
    ///
    /// Ieu mangrupikeun sarimbag umum generik [`windows`].
    ///
    /// Upami `N` langkung ageung tibatan ukuran keureut, éta moal mulang deui windows.
    ///
    /// # Panics
    ///
    /// Panics upami `N` nyaéta 0.
    /// Cék ieu sigana bakal dirobih janten kasalahan waktos nyusun sateuacan metode ieu stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureut dina hiji waktos, dimimitian dina akhir keureut.
    ///
    /// Potongan éta keureut sareng henteu tumpang tindih.Upami `chunk_size` henteu ngabagi panjang keureutan, maka potongan terakhir moal gaduh panjang `chunk_size`.
    ///
    /// Tempo [`rchunks_exact`] pikeun variasi tina iterator ieu nu mulih sakumpulan salawasna persis elemen `chunk_size`, sarta [`chunks`] keur iterator sarua tapi dimimitian dina awal nyiksikan teh.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureut dina hiji waktos, dimimitian dina akhir keureut.
    ///
    /// The sakumpulan anu keureut mutable, sarta ulah tumpang tindihna.Upami `chunk_size` henteu ngabagi panjang keureutan, maka potongan terakhir moal gaduh panjang `chunk_size`.
    ///
    /// Tingali [`rchunks_exact_mut`] pikeun varian iterator ieu anu mulih potongan sakaligus persis unsur `chunk_size`, sareng [`chunks_mut`] kanggo iterator anu sami tapi dimimitian dina mimiti irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureut dina hiji waktos, dimimitian dina akhir keureut.
    ///
    /// Potongan éta keureut sareng henteu tumpang tindih.
    /// Upami `chunk_size` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `chunk_size-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `remainder` tina iterator.
    ///
    /// Kusabab masing-masing potongan gaduh elemen `chunk_size` persis, panyusun sering tiasa ngaoptimalkeun kode anu dihasilkeun langkung saé tibatan dina kasus [`chunks`].
    ///
    /// Tingali [`rchunks`] pikeun varian iterator ieu anu ogé ngabalikeun sésana salaku potongan anu langkung alit, sareng [`chunks_exact`] kanggo iterator anu sami tapi dimimitian dina mimiti irisan.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Balikkeun iterator langkung tina unsur `chunk_size` tina keureut dina hiji waktos, dimimitian dina akhir keureut.
    ///
    /// Potongan ieu irisan mutable, sareng henteu tumpang tindih.
    /// Upami `chunk_size` henteu ngabagi panjang irisan, maka anu pangahirna dugi ka `chunk_size-1` elemen bakal dileungitkeun sareng tiasa dicandak tina fungsi `into_remainder` tina iterator.
    ///
    /// Kusabab masing-masing potongan gaduh elemen `chunk_size` persis, panyusun sering tiasa ngaoptimalkeun kode anu dihasilkeun langkung saé tibatan dina kasus [`chunks_mut`].
    ///
    /// Tingali [`rchunks_mut`] pikeun varian iterator ieu anu ogé ngabalikeun sésana salaku potongan leutik, sareng [`chunks_exact_mut`] kanggo iterator anu sami tapi dimimitian dina mimiti keureut.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `chunk_size` nyaéta 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Balikkeun iterator dina irisan anu ngahasilkeun unsur-unsur anu henteu tumpang tindih nganggo prédikat pikeun misahkeunana.
    ///
    /// Prédikat disebut kana dua unsur nuturkeun dirina, éta hartosna predikat disebut dina `slice[0]` sareng `slice[1]` teras kana `slice[1]` sareng `slice[2]` sareng sajabana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cara ieu tiasa dianggo pikeun nimba langganan anu diurutkeun:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Balikkeun iterator dina irisan anu ngahasilkeun unsur-unsur mutable anu teu tumpang tindih nganggo predikat pikeun misahkeunana.
    ///
    /// Prédikat disebut kana dua unsur nuturkeun dirina, éta hartosna predikat disebut dina `slice[0]` sareng `slice[1]` teras kana `slice[1]` sareng `slice[2]` sareng sajabana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Cara ieu tiasa dianggo pikeun nimba langganan anu diurutkeun:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Bagikeun hiji keureut janten dua dina hiji indéks.
    ///
    /// Anu mimiti bakal ngandung sadaya indéks tina `[0, mid)` (henteu kaasup kana indéks `mid` sorangan) sareng anu kadua bakal ngandung sadaya indéks tina `[mid, len)` (henteu kaasup indéks `len` sorangan).
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` sareng `[mid; len]` aya dina `self`, anu
        // minuhan sarat `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Bagikeun hiji keureut anu tiasa dirobih janten dua dina hiji indéks.
    ///
    /// Anu mimiti bakal ngandung sadaya indéks tina `[0, mid)` (henteu kaasup kana indéks `mid` sorangan) sareng anu kadua bakal ngandung sadaya indéks tina `[mid, len)` (henteu kaasup indéks `len` sorangan).
    ///
    ///
    /// # Panics
    ///
    /// Panics upami `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SAFETY: `[ptr; mid]` sareng `[mid; len]` aya dina `self`, anu
        // minuhan sarat `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Bagikeun hiji keureut janten dua dina hiji indéks, tanpa ngalakukeun bounds mariksa.
    ///
    /// Anu mimiti bakal ngandung sadaya indéks tina `[0, mid)` (henteu kaasup kana indéks `mid` sorangan) sareng anu kadua bakal ngandung sadaya indéks tina `[mid, len)` (henteu kaasup indéks `len` sorangan).
    ///
    ///
    /// Pikeun alternatif anu aman tingali [`split_at`].
    ///
    /// # Safety
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates nyaéta *[kabiasaan teu ditangtoskeun]* sanajan rujukan anu dihasilkeun henteu dianggo.Anu nelepon kedah mastikeun yén `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // Kaamanan: Anu nelepon kedah parios `0 <= mid <= self.len()` éta
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Bagikeun hiji keureut anu tiasa dirobih janten dua dina hiji indéks, tanpa ngalakukeun batesan mariksa.
    ///
    /// Anu mimiti bakal ngandung sadaya indéks tina `[0, mid)` (henteu kaasup kana indéks `mid` sorangan) sareng anu kadua bakal ngandung sadaya indéks tina `[mid, len)` (henteu kaasup indéks `len` sorangan).
    ///
    ///
    /// Pikeun alternatif anu aman tingali [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Nelepon metodeu ieu ku indéks luar-wates nyaéta *[kabiasaan teu ditangtoskeun]* sanajan rujukan anu dihasilkeun henteu dianggo.Anu nelepon kedah mastikeun yén `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // Kaamanan: Anu nelepon kedah parios `0 <= mid <= self.len()` éta.
        //
        // `[ptr; mid]` sareng `[mid; len]` henteu tumpang tindih, janten mulihkeun referensi anu tiasa dirobih henteu kunanaon.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred`.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Upami unsur anu munggaran dicocogkeun, irisan kosong mangrupikeun barang anu pangpayunna dipulangkeun ku iterator.
    /// Nya kitu, upami unsur panungtung dina irisan cocog, irisan kosong mangrupikeun barang panungtung anu dikembalikan ku iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Upami dua unsur anu cocog caket langsung, potongan kosong bakal aya diantara aranjeunna:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu tiasa dirobih dipisahkeun ku elemen anu cocog sareng `pred`.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred`.
    /// unsur loyog dikandung dina tungtung subslice saméméhna salaku terminator a.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Upami unsur pamungkas tina keureut cocog, unsur éta bakal dianggap terminator tina keureutan sateuacana.
    ///
    /// Irisan éta mangrupikeun barang terakhir anu dipulangkeun ku pangulangan.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu tiasa dirobih dipisahkeun ku elemen anu cocog sareng `pred`.
    /// Unsur anu cocog aya dina subslice sateuacana salaku terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred`, dimimitian dina tungtung keureut sareng damel ka tukang.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sapertos sareng `split()`, upami unsur anu kahiji atanapi anu terakhir cocog, potongan anu kosong bakal janten barang anu pangpayunna (atanapi terakhir) anu dikembalikan ku iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu tiasa dirobih dipisahkeun ku unsur-unsur anu cocog sareng `pred`, dimimitian dina tungtung keureut sareng dianggo mundur.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred`, diwatesan pikeun mulang dina seueur barang `n`.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// Unsur terakhir anu dipulangkeun, upami aya, bakal ngandung sésa potongan.
    ///
    /// # Examples
    ///
    /// Nyitak nyiksikan pamisah sakali ku nomer bisa dibeulah deui ku 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred`, diwatesan pikeun mulang dina seueur barang `n`.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// Unsur terakhir anu dipulangkeun, upami aya, bakal ngandung sésa potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred` kawates pikeun mulang paling barang `n`.
    /// Ieu dimimitian dina tungtung keureut sareng tiasa dianggo mundur.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// Unsur terakhir anu dipulangkeun, upami aya, bakal ngandung sésa potongan.
    ///
    /// # Examples
    ///
    /// Nyitak sapotong beulah sakali, mimitian ti tungtungna, ku nomer anu teu tiasa dibagi ku 3 (nyaéta, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Mulang iterator ngalangkungan langganan anu dipisahkeun ku elemen anu cocog sareng `pred` kawates pikeun mulang paling barang `n`.
    /// Ieu dimimitian dina tungtung keureut sareng tiasa dianggo mundur.
    /// Unsur anu cocog henteu aya dina palanggan.
    ///
    /// Unsur terakhir anu dipulangkeun, upami aya, bakal ngandung sésa potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Mulih `true` lamun nyiksikan ngandung unsur jeung nilai dibikeun.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Upami anjeun henteu ngagaduhan `&T`, tapi ngan `&U` sapertos `T: Borrow<U>` (misal
    /// `String: nginjeum<str>`), anjeun tiasa nganggo `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // nyiksikan tina `String`
    /// assert!(v.iter().any(|e| e == "hello")); // milarian nganggo `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Mulih `true` upami `needle` mangrupikeun awalan tina potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Sok balikeun `true` upami `needle` mangrupikeun irisan kosong:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Mulih `true` lamun `needle` mangrupakeun ahiran of nyiksikan teh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Sok balikeun `true` upami `needle` mangrupikeun irisan kosong:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Mulang deui subslice kalayan awalan dihapus.
    ///
    /// Upami keureutan dimimitian ku `prefix`, balikkeun langganan saatos awalan, dibungkus `Some`.
    /// Upami `prefix` kosong, kantun balikkeun keureutan aslina.
    ///
    /// Upami keureut henteu dimimitian ku `prefix`, mulih `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fungsi ieu kedah nyerat deui upami sareng iraha SlicePattern janten langkung canggih.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Balikkeun langganan sareng ahiran dihapus.
    ///
    /// Mun nu nyiksikan tungtung kalawan `suffix`, mulih ka subslice saméméh akhiran, dibungkus dina `Some`.
    /// Upami `suffix` kosong, kantun balikkeun keureutan aslina.
    ///
    /// Upami keureutna henteu ditungtungan ku `suffix`, mulih `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Fungsi ieu kedah nyerat deui upami sareng iraha SlicePattern janten langkung canggih.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binér milarian irisan diurutkeun ieu pikeun unsur anu ditangtoskeun.
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.
    /// Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    ///
    /// Tingali ogé [`binary_search_by`], [`binary_search_by_key`], sareng [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Milarian runtuyan opat unsur.
    /// Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Upami anjeun hoyong ngalebetkeun barang kana vector anu diurut, bari ngajaga urutan:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// maluruh binér ieu dumasar nyiksikan sareng fungsi comparator.
    ///
    /// Fungsi komparator kedah nerapkeun urutan anu saluyu sareng urutan sortir tina keureutan anu aya, mulihkeun kode urutan anu nunjukkeun naha argumen na nyaéta `Less`, `Equal` atanapi `Greater` target anu dipikahoyong.
    ///
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    /// Tempo ogé [`binary_search`], [`binary_search_by_key`], sarta [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Milarian runtuyan opat unsur.Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // KESELAMATAN: sauran tiasa diamankeun ku anu ngondang kieu:
            // - `mid >= 0`
            // - `mid < size`: `mid` diwatesan ku `[left; right)` kabeungkeut.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Alesan naha urang nganggo aliran kontrol if/else tibatan pertandingan kusabab pertandingan ngabandingkeun ulang operasi, anu sénsitip perf.
            //
            // Ieu x86 asm pikeun u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binér milarian keureutan diurut ieu sareng fungsi ékstraksi konci.
    ///
    /// Nganggap yén irisan diurutkeun dumasar koncina, contona sareng [`sort_by_key`] nganggo fungsi ékstraksi konci anu sami.
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.
    /// Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    ///
    /// Tingali ogé [`binary_search`], [`binary_search_by`], sareng [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Néangan séri opat unsur dina sapotong pasang diurut ku unsur kadua na.
    /// Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links diidinan sakumaha `slice::sort_by_key` aya dina crate `alloc`, sareng sapertos kitu teu acan aya nalika ngawangun `core`.
    //
    // tautan ka hilir crate: #74481.Kusabab primitip ngan ukur didokumentasikeun dina libstd (#73423), ieu henteu pernah nyababkeun tautan rusak dina praktékna.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Nyortir potongan, tapi henteu tiasa ngalaksanakeun urutan unsur anu sami.
    ///
    /// Urut ieu henteu stabil (nyaéta, tiasa nyusun ulang unsur anu sami), dina tempatna (nyaéta, henteu masihan), sareng *O*(*n*\*log(* n*)) kasus awon.
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna dumasar kana [pattern-defeating quicksort][pdqsort] ku Orson Peters, anu ngahijikeun kasus rata-rata gancang tina quicksort acak sareng kasus paling parah tina heapsort, nalika ngahontal waktos linier dina keureut kalayan pola anu tangtu.
    /// Éta ngagunakeun sababaraha acak pikeun nyingkahan kasus degenerate, tapi ku seed tetep pikeun salawasna nyayogikeun perilaku deterministik.
    ///
    /// Ieu ilaharna gancang ti stabil asihan, iwal dina kasus husus sababaraha, misalna, nalika nyiksik nu diwangun ku sababaraha urutan diruntuykeun disambungkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Nyortir sapotong ku fungsi komparator, tapi tiasa henteu ngajaga urutan unsur anu sami.
    ///
    /// Urut ieu henteu stabil (nyaéta, tiasa nyusun ulang unsur anu sami), dina tempatna (nyaéta, henteu masihan), sareng *O*(*n*\*log(* n*)) kasus awon.
    ///
    /// Fungsi komparator kedah ngartikeun total susunan unsur-unsur dina potongan.Upami mesen henteu total, urutan unsur henteu ditangtoskeun.Pesenan mangrupikeun urutan total upami éta (pikeun sadaya `a`, `b` sareng `c`):
    ///
    /// * total sareng antisymmetric: persis salah sahiji `a < b`, `a == b` atanapi `a > b` leres, sareng
    /// * transitif, `a < b` sareng `b < c` ngakibatkeun `a < c`.Sarua kedah tahan pikeun `==` sareng `>`.
    ///
    /// Salaku conto, nalika [`f64`] henteu nerapkeun [`Ord`] kusabab `NaN != NaN`, urang tiasa nganggo `partial_cmp` salaku fungsi sortir urang nalika urang terang keureutna henteu ngandung `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna dumasar kana [pattern-defeating quicksort][pdqsort] ku Orson Peters, anu ngahijikeun kasus rata-rata gancang tina quicksort acak sareng kasus paling parah tina heapsort, nalika ngahontal waktos linier dina keureut kalayan pola anu tangtu.
    /// Éta ngagunakeun sababaraha acak pikeun nyingkahan kasus degenerate, tapi ku seed tetep pikeun salawasna nyayogikeun perilaku deterministik.
    ///
    /// Ieu ilaharna gancang ti stabil asihan, iwal dina kasus husus sababaraha, misalna, nalika nyiksik nu diwangun ku sababaraha urutan diruntuykeun disambungkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // asihan tibalik
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Nyortir sapotong ku fungsi ékstraksi konci, tapi tiasa henteu ngajaga urutan unsur anu sami.
    ///
    /// Urut ieu henteu stabil (nyaéta, tiasa nyusun ulang unsur anu sami), dina tempatna (nyaéta, henteu dialokasikeun), sareng *O*(m\* * n *\* log(*n*)) kasus awon, dimana fungsi konci na *O*(*m*).
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna dumasar kana [pattern-defeating quicksort][pdqsort] ku Orson Peters, anu ngahijikeun kasus rata-rata gancang tina quicksort acak sareng kasus paling parah tina heapsort, nalika ngahontal waktos linier dina keureut kalayan pola anu tangtu.
    /// Éta ngagunakeun sababaraha acak pikeun nyingkahan kasus degenerate, tapi ku seed tetep pikeun salawasna nyayogikeun perilaku deterministik.
    ///
    /// Kusabab strategi nelepon konci na, [`sort_unstable_by_key`](#method.sort_unstable_by_key) sigana bakal langkung laun tibatan [`sort_by_cached_key`](#method.sort_by_cached_key) dina kasus dimana fungsi konci na mahal.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Rumah Gadang nyiksikan teh sapertos yén unsur dina `index` nyaeta dina posisi diruntuykeun ahir na.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Rumah Gadang di nyiksikan jeung comparator hiji fungsi misalna yén unsur dina `index` nyaeta dina posisi diruntuykeun ahir na.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Susun deui keureutan ku fungsi ékstraksi konci sapertos unsur dina `index` aya dina posisi anu terakhir diurutkeun.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Rumah Gadang nyiksikan teh sapertos yén unsur dina `index` nyaeta dina posisi diruntuykeun ahir na.
    ///
    /// Panyusunan ulang ieu ngagaduhan sipat tambahan anu nilai naon dina posisi `i < index` bakal kirang tina atanapi sami sareng nilai naon dina posisi `j > index`.
    /// Salaku tambahan, ngarobih deui ieu teu stabil (ie
    /// sababaraha unsur anu sami tiasa waé dina posisi `index`), dina tempatna (nyaéta
    /// henteu nyayogikeun), sareng *O*(*n*) kasus awon.
    /// Fungsi ieu ogé/katelah "kth element" di perpustakaan séjén.
    /// Éta mulihkeun triplet tina nilai-nilai ieu: sadaya elemen kirang ti hiji dina indéks anu ditangtoskeun, nilai dina indéks anu dipasihkeun, sareng sadaya unsur langkung ageung tibatan anu dina indéks anu ditangtoskeun.
    ///
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritme ayeuna dumasarkeun kana bagean gancang tina algoritma quicksort anu sami anu dianggo pikeun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, hartosna éta salawasna panics dina keureut kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Milarian médiana
    /// v.select_nth_unstable(2);
    ///
    /// // Kami ngan ukur dijamin irisan bakal janten salah sahiji di handap ieu, dumasar kana cara kami milah ngeunaan indéks anu parantos ditangtoskeun.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rumah Gadang di nyiksikan jeung comparator hiji fungsi misalna yén unsur dina `index` nyaeta dina posisi diruntuykeun ahir na.
    ///
    /// Panyusun ulang ieu ngagaduhan sipat tambahan anu nilai naon dina posisi `i < index` bakal kirang tina atanapi sami sareng nilai naon dina posisi `j > index` nganggo fungsi komparator.
    /// Sajaba ti, reordering ieu stabil (ie sagala Jumlah elemen sarua bisa mungkas nepi di posisi `index`), di-tempat (ie teu allocate), sarta *O*(*n*) awon-hal.
    /// Fungsi ieu ogé katelah "kth element" di perpustakaan séjén.
    /// Éta mulihkeun triplet tina nilai-nilai ieu: sadaya unsur kirang ti hiji dina indéks anu ditangtoskeun, nilai dina indéks anu dipasihkeun, sareng sadaya unsur langkung ageung dibanding hiji dina indéks anu ditangtoskeun, nganggo fungsi komparator anu disayogikeun
    ///
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritme ayeuna dumasarkeun kana bagean gancang tina algoritma quicksort anu sami anu dianggo pikeun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, hartosna éta salawasna panics dina keureut kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Milari médiana saolah-olah nyiksikan diurutkeun dina urutan turun.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Kami ngan ukur dijamin irisan bakal janten salah sahiji di handap ieu, dumasar kana cara kami milah ngeunaan indéks anu parantos ditangtoskeun.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Susun deui keureutan ku fungsi ékstraksi konci sapertos unsur dina `index` aya dina posisi anu terakhir diurutkeun.
    ///
    /// reordering ieu harta tambahan yen nilai wae dina posisi `i < index` bakal kurang atawa sarua jeung nilai wae dina hiji posisi `j > index` ngagunakeun fungsi ékstraksi konci.
    /// Sajaba ti, reordering ieu stabil (ie sagala Jumlah elemen sarua bisa mungkas nepi di posisi `index`), di-tempat (ie teu allocate), sarta *O*(*n*) awon-hal.
    /// Fungsi ieu ogé katelah "kth element" di perpustakaan séjén.
    /// Éta mulihkeun triplet tina nilai-nilai ieu: sadaya unsur kirang ti hiji dina indéks anu ditangtoskeun, nilai dina indéks anu dipasihkeun, sareng sadaya unsur langkung ageung dibanding hiji dina indéks anu dipasihkeun, nganggo fungsi ékstraksi konci anu disayogikeun
    ///
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritme ayeuna dumasarkeun kana bagean gancang tina algoritma quicksort anu sami anu dianggo pikeun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nalika `index >= len()`, hartosna éta salawasna panics dina keureut kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Balikkeun médiana saolah-olah susunanana diurutkeun numutkeun nilai mutlak.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Kami ngan ukur dijamin irisan bakal janten salah sahiji di handap ieu, dumasar kana cara kami milah ngeunaan indéks anu parantos ditangtoskeun.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Mindahkeun sadaya unsur anu teras-terasan dina tungtung keureut numutkeun palaksanaan [`PartialEq`] trait.
    ///
    ///
    /// Mulang dua keureut.Anu mimiti henteu ngandung unsur-unsur anu teras-terasan teras-terasan.
    /// Kadua ngandung sadaya duplikat dina urutan anu teu ditangtoskeun.
    ///
    /// Upami keureut diurutkeun, keureutan anu pangénggalna teu aya anu duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Mindahkeun sadayana tapi anu mimiti tina unsur-unsur anu padeukeut kana tungtung potongan anu nyugemakeun hubungan anu sami.
    ///
    /// Mulang dua keureut.Anu mimiti henteu ngandung unsur-unsur anu teras-terasan teras-terasan.
    /// Kadua ngandung sadaya duplikat dina urutan anu teu ditangtoskeun.
    ///
    /// Fungsi `same_bucket` diliwatan rujukan pikeun dua unsur tina potongan sareng kedah nangtoskeun naha unsur-unsur ngabandingkeun sami.
    /// Unsur anu diliwatan dina urutan sabalikna tina urutan maranéhanana di nyiksikan teh, jadi mun `same_bucket(a, b)` mulih `true`, `a` ieu dipindahkeun di ahir nyiksikan teh.
    ///
    ///
    /// Upami keureut diurutkeun, keureutan anu pangénggalna teu aya anu duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Sanaos kami ngagaduhan rujukan anu tiasa dirobih ka `self`, urang moal tiasa ngarobih *sawenang-wenang*.Telepon `same_bucket` tiasa panic, janten urang kedah mastikeun yén keureut dina kaayaan anu sah sepanjang waktos.
        //
        // Cara anu kami nanganan nyaéta ngagunakeun swap;urang ngémutan sadaya unsur, ngagentos nalika urang jalan supados tungtungna mah unsur-unsur anu urang pikahoyong aya di payun, sareng anu urang hoyong ditolak aya di tukang.
        // Urang teras tiasa ngabagi keureutan.
        // Operasi ieu masih `O(n)`.
        //
        // Conto: Urang mimitian dina kaayaan kieu, dimana `r` ngagambarkeun "salajengna
        // baca "sareng `w` ngagambarkeun" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ngabandingkeun self[r] ngalawan diri [w-1], ieu teu duplikat a, sangkan swap self[r] na self[w] (euweuh pangaruh sakumaha r==w) lajeng increment duanana r na w, ninggalkeun urang jeung:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ngabandingkeun self[r] ngalawan dirina [w-1], nilai ieu mangrupikeun duplikat, janten kami nambahan `r` tapi ngantepkeun sadayana anu sanés robih:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ngabandingkeun self[r] ngalawan diri [w-1], ieu teu duplikat a, jadi swap self[r] na self[w] na sateuacanna r na w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Sanés duplikat, balikan deui:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikat, advance r. End tina keureutan.Beulah di w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SAFETY: kaayaan `while` ngajamin `next_read` sareng `next_write`
        // kirang ti `len`, sahingga aya di jero `self`.
        // `prev_ptr_write` nunjuk kana hiji unsur sateuacan `ptr_write`, tapi `next_write` dimimitian dina 1, janten `prev_ptr_write` henteu pernah kirang ti 0 sareng aya dina jero wilah.
        // Ieu minuhan sarat pikeun dereferénsi `ptr_read`, `prev_ptr_write` sareng `ptr_write`, sareng pikeun nganggo `ptr.add(next_read)`, `ptr.add(next_write - 1)` sareng `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ogé ditambahan paling sakali sakali pikeun loop anu paling artina henteu aya unsur anu diloloskeun nalika panginten diperyogikeun.
        //
        // `ptr_read` sareng `prev_ptr_write` henteu pernah nunjuk unsur anu sami.Ieu diperyogikeun pikeun `&mut *ptr_read`, `&mut* prev_ptr_write` janten aman.
        // Kateranganana ngan saukur `next_read >= next_write` sok leres, sahingga `next_read > next_write - 1` ogé.
        //
        //
        //
        //
        //
        unsafe {
            // Hindarkeun cek bounds ku ngagunakeun petunjuk atah.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ngalir kabeh tapi kahiji unsur padeukeut nepi ka ahir nyiksikan anu ngabéréskeun kana konci sarua.
    ///
    ///
    /// Mulang dua keureut.Anu mimiti henteu ngandung unsur-unsur anu teras-terasan teras-terasan.
    /// Kadua ngandung sadaya duplikat dina urutan anu teu ditangtoskeun.
    ///
    /// Upami keureut diurutkeun, keureutan anu pangénggalna teu aya anu duplikat.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Muterkeun keureutan dina tempatna sapertos unsur `mid` munggaran tina keureut ngalih ka tungtungna sedengkeun unsur `self.len() - mid` pamungkas ngalih ka payun.
    /// Saatos nyauran `rotate_left`, unsur anu saacanna dina indéks `mid` bakal janten unsur munggaran dina keureutan.
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami `mid` langkung ageung tibatan panjang keureutan.Catet yén `mid == self.len()` ngalakukeun _not_ panic sareng mangrupakeun rotasi no-op.
    ///
    /// # Complexity
    ///
    /// Nyandak linier (dina waktos `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Puteran subslice a:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // Kaamanan: Kisaran `[p.add(mid) - mid, p.add(mid) + k)` henteu pati penting
        // valid pikeun maca sareng nyerat, sakumaha anu diperyogikeun ku `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Muterkeun keureutan dina tempatna sapertos unsur `self.len() - k` munggaran tina keureut ngalih ka tungtungna sedengkeun unsur `k` pamungkas ngalih ka payun.
    /// Saatos nelepon `rotate_right`, unsur saméméhna dina indéks `self.len() - k` baris jadi unsur kahiji di nyiksikan teh.
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami `k` langkung ageung tibatan panjang keureutan.Catetan yen `k == self.len()` teu _not_ panic sarta mangrupakeun rotasi no-op.
    ///
    /// # Complexity
    ///
    /// Nyandak linier (dina waktos `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Puterkeun subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // Kaamanan: Kisaran `[p.add(mid) - mid, p.add(mid) + k)` henteu pati penting
        // valid pikeun maca sareng nyerat, sakumaha anu diperyogikeun ku `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ngeusi `self` kalawan unsur dumasar Kloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Ngeusi `self` mibanda elemen dipulang ku nelepon panutupanana a sababaraha kali.
    ///
    /// Metoda ieu migunakeun panutupanana pikeun nyieun nilai anyar.Upami anjeun langkung resep [`Clone`] nilai tinangtu, anggo [`fill`].
    /// Upami anjeun hoyong nganggo [`Default`] trait pikeun ngahasilkeun nilai, anjeun tiasa ngalirkeun [`Default::default`] salaku alesan.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Nyalin elemen tina `src` kana `self`.
    ///
    /// Panjang `src` kedah sami sareng `self`.
    ///
    /// Mun `T` implements `Copy`, bisa jadi leuwih performant ngagunakeun [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami dua keureut gaduh panjang anu bénten.
    ///
    /// # Examples
    ///
    /// Kloning dua unsur tina sapotong kana unsur anu sanés:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kusabab keureutna kedah panjangna sami, urang keureut sumberna tina opat unsur janten dua.
    /// // Éta bakal panic upami urang henteu ngalakukeun ieu.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust negeskeun yén ngan ukur aya hiji rujukan anu tiasa dirobih kalayan henteu aya rujukan anu teu tiasa dirobih kana salembar data dina wengkuan anu tangtu.
    /// Kusabab ieu, nyobian nganggo `clone_from_slice` dina hiji potong bakal ngahasilkeun kagagalan kompilasi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ka pagawean sabudeureun ieu, urang tiasa nganggo [`split_at_mut`] mun nyieun dua béda sub-keureut tina nyiksikan a:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Nyalin sadaya unsur ti `src` kana `self`, nganggo mémo.
    ///
    /// Panjang `src` kedah sami sareng `self`.
    ///
    /// Upami `T` henteu nerapkeun `Copy`, anggo [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami dua keureut gaduh panjang anu bénten.
    ///
    /// # Examples
    ///
    /// Nyalin dua elemen tina sapotong kana unsur anu sanés:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Kusabab keureutna kedah panjangna sami, urang keureut sumberna tina opat unsur janten dua.
    /// // Éta bakal panic upami urang henteu ngalakukeun ieu.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust negeskeun yén ngan ukur aya hiji rujukan anu tiasa dirobih kalayan henteu aya rujukan anu teu tiasa dirobih kana salembar data dina wengkuan anu tangtu.
    /// Kusabab ieu, nyobian nganggo `copy_from_slice` dina hiji potong bakal ngahasilkeun kagagalan kompilasi:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ka pagawean sabudeureun ieu, urang tiasa nganggo [`split_at_mut`] mun nyieun dua béda sub-keureut tina nyiksikan a:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Jalur kode panic ieu nempatkeun kana fungsi tiis kana moal bloat situs panggero.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // Kasalametan: `self` nyaeta valid keur elemen `self.len()` ku harti, jeung `src` éta
        // dipariksa ngagaduhan panjang anu sami.
        // Irisan henteu tiasa tumpang tindih sabab rujukan anu tiasa dirobih sacara éksklusif.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Nyalin elemen tina hiji bagian tina irisan ka bagian sanésna, nganggo mémove.
    ///
    /// `src` nyaéta kisaran dina `self` kanggo nyonto.
    /// `dest` nyaéta indéks dimimitian ti rentang dina `self` mun nyalin jeung nu bakal boga panjang anu sarua sakumaha `src`.
    /// Dua rentang éta tiasa tindih.
    /// Ujung dua rentang kedahna kirang ti atanapi sami sareng `self.len()`.
    ///
    /// # Panics
    ///
    /// Pungsi ieu bakal panic upami rentang mana waé ngaleuwihan tungtung keureut, atanapi upami tungtung `src` sateuacan ngamimitian.
    ///
    ///
    /// # Examples
    ///
    /// Nyalin opat bait dina sapotong:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SAFETY: kaayaan pikeun `ptr::copy` sadayana parantos diparios di luhur,
        // sakumaha anu kasebut pikeun `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Tukeur sadaya unsur dina `self` sareng anu di `other`.
    ///
    /// Panjang `other` kedah sami sareng `self`.
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami dua keureut gaduh panjang anu bénten.
    ///
    /// # Example
    ///
    /// Tukeur dua elemen dina wilah:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ngalaksanakeun yén ngan ukur aya hiji rujukan anu tiasa dirobih kana salembar data dina wengkuan anu tangtu.
    ///
    /// Kusabab ieu, ngusahakeun ngagunakeun `swap_with_slice` dina nyiksikan tunggal bakal hasil dina gagalna compile:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Pikeun ngagarap ieu, urang tiasa nganggo [`split_at_mut`] pikeun nyiptakeun dua keureut anu tiasa dirobih tina potongan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // Kasalametan: `self` nyaeta valid keur elemen `self.len()` ku harti, jeung `src` éta
        // dipariksa ngagaduhan panjang anu sami.
        // Irisan henteu tiasa tumpang tindih sabab rujukan anu tiasa dirobih sacara éksklusif.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Fungsi pikeun ngitung panjang tengah sareng labuh nyiksikan pikeun `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Naon anu urang badé lakukeun ngeunaan `rest` nyaéta terang naon sababaraha `U`s anu tiasa urang lebetkeun dina angka panghandapna`T`s.
        //
        // Jeung sabaraha `T`s kami kudu keur unggal "multiple" misalna.
        //
        // Pertimbangkeun contona T=u8 U=u16.Maka urang tiasa nempatkeun 1 U dina 2 Ts.Basajan.
        // Ayeuna, anggap contona hiji pasualan dimana size_of: :<T>=16, size_of::<U>=24.</u>
        // Urang tiasa nempatkeun 2 Kami dina tempat unggal 3 Ts dina keureut `rest`.
        // Rada langkung rumit.
        //
        // Formula pikeun ngitung ieu nyaéta:
        //
        // Urang= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Dilegakeun sareng disederhanakeun:
        //
        // Urang=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Kabeneran saprak kabeh ieu konstan-dievaluasi ... kinerja dieu perkara moal!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Algoritma iterative Stein urang Simkuring masih kedah ngadamel `const fn` ieu (sarta dibalikkeun kana algoritma recursive lamun urang ngalakukeun) sabab gumantung llvm mun consteval kabeh ieu ... ogé, eta ngajadikeun kuring uncomfortable.
            //
            //

            // Kasalametan: `a` na `b` anu dipariksa janten nilai non-nol.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // miceun kabeh faktor 2 tina b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // Kasalametan: `b` geus dipariksa janten non-nol.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Angkatan sareng pangaweruh ieu, urang tiasa mendakan sabaraha `U`s bisa cocog!
        let us_len = self.len() / ts * us;
        // Sareng sabaraha `T`s anu bakal di irisan labuh!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Mindahkeun keureutan kana keureutan jinis anu sanés, ngajantenkeun penjajaran jinisna dijaga.
    ///
    /// Metoda ieu ngabagi keureutan kana tilu keureut anu beda: awalan, leres ngahususkeun irisan tengah tina jinis anyar, sareng irisan ahiran.
    /// Metoda na tiasa ngajantenkeun potongan tengah paling panjang pikeun jinis sareng input input, tapi ngan ukur kinerja algoritma anjeun kedah gumantung kana éta, sanés leresna.
    ///
    /// Diidinan pikeun sadaya data input dikembalikan salaku awalan atanapi seselan ahiran.
    ///
    /// Metoda ieu teu aya tujuan nalika unsur input `T` atanapi kaluaran elemen `U` ukuranana nol sareng bakal ngasilkeun potongan aslina tanpa ngabagi nanaon.
    ///
    /// # Safety
    ///
    /// Metoda ieu dina dasarna mangrupikeun `transmute` anu aya kaitannana sareng unsur-unsur dina potongan tengah anu dikembalikan, janten sadayana peringatan anu biasana aya hubunganana sareng `transmute::<T, U>` ogé diterapkeun di dieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Catet yén kaseueuran fungsi ieu bakal dievaluasi sacara konstan,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // nanganan ZST khusus, nyaéta-entong dicekel pisan.
            return (self, &[], &[]);
        }

        // Mimiti, panggihan dina titik naon urang beulah antara irisan kahiji sareng 2.
        // Gampang nganggo ptr.align_offset.
        let ptr = self.as_ptr();
        // Kaamanan: Tingali metode `align_to_mut` pikeun koméntar kaamanan anu lengkep.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: ayeuna `rest` pasti dijejeran, janten `from_raw_parts` di handap henteu kunanaon,
            // kumargi anu nelepon ngajamin yén urang tiasa ngirimkeun `T` ka `U` aman.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Mindahkeun keureutan kana keureutan jinis anu sanés, ngajantenkeun penjajaran jinisna dijaga.
    ///
    /// Metoda ieu ngabagi keureutan kana tilu keureut anu beda: awalan, leres ngahususkeun irisan tengah tina jinis anyar, sareng irisan ahiran.
    /// Metoda na tiasa ngajantenkeun potongan tengah paling panjang pikeun jinis sareng input input, tapi ngan ukur kinerja algoritma anjeun kedah gumantung kana éta, sanés leresna.
    ///
    /// Diidinan pikeun sadaya data input dikembalikan salaku awalan atanapi seselan ahiran.
    ///
    /// Metoda ieu teu aya tujuan nalika unsur input `T` atanapi kaluaran elemen `U` ukuranana nol sareng bakal ngasilkeun potongan aslina tanpa ngabagi nanaon.
    ///
    /// # Safety
    ///
    /// Metoda ieu dina dasarna mangrupikeun `transmute` anu aya kaitannana sareng unsur-unsur dina potongan tengah anu dikembalikan, janten sadayana peringatan anu biasana aya hubunganana sareng `transmute::<T, U>` ogé diterapkeun di dieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Catet yén kaseueuran fungsi ieu bakal dievaluasi sacara konstan,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // nanganan ZST khusus, nyaéta-entong dicekel pisan.
            return (self, &mut [], &mut []);
        }

        // Mimiti, panggihan dina titik naon urang beulah antara irisan kahiji sareng 2.
        // Gampang nganggo ptr.align_offset.
        let ptr = self.as_ptr();
        // KESELAMATAN: Di dieu kami mastikeun kami bakal nganggo petunjuk anu cocog pikeun U pikeun
        // sesa metode.Hal ieu dilakukeun ku ngalirkeun pointer ka&[T] kalayan alignment anu sasaran pikeun U.
        // `crate::ptr::align_offset` disebut ku pointer neuleu Blok jeung valid `ptr` (datang ti rujukan pikeun `self`) jeung ku ukuranana nu mangrupakeun kakuatan dua (saprak datang ti alignement pikeun U), satisfying konstrain kaamanan na.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Kami henteu tiasa nganggo `rest` deui saatos ieu, éta bakal ngabatalkeun alias `mut_ptr` na!Kasalametan: tingali komentar pikeun `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Pariksa naha unsur keureutan ieu diurutkeun.
    ///
    /// Nyaéta, pikeun unggal unsur `a` sareng unsur na `b` di handap ieu, `a <= b` kedah tahan.Upami keureut ngahasilkeun persis enol atanapi hiji unsur, `true` bakal dikembalikan.
    ///
    /// Catet yén upami `Self::Item` ngan ukur `PartialOrd`, tapi sanés `Ord`, watesan di luhur nunjukkeun yén fungsi ieu mulih `false` upami aya dua barang anu teras-terasan henteu tiasa dibandingkeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Pariksa naha elemen tina keureutan ieu diurutkeun nganggo fungsi komparator anu dipasihkeun.
    ///
    /// Gantina make `PartialOrd::partial_cmp`, fungsi ieu migunakeun fungsi `compare` nu dibéré pikeun nangtukeun nyusun dua elemen.
    /// Sajaba ti eta, éta sarua jeung [`is_sorted`];tingali dokuméntasi na kanggo inpormasi lengkep.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Cék lamun unsur nyiksikan ieu dumasar maké fungsi ékstraksi konci nu tinangtu.
    ///
    /// Daripada ngabandingkeun unsur keureutan sacara langsung, fungsi ieu ngabandingkeun konci unsur-unsur, sakumaha ditangtukeun ku `f`.
    /// Sajaba ti eta, éta sarua jeung [`is_sorted`];tingali dokuméntasi na kanggo inpormasi lengkep.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Balikkeun indéks titik partisi numutkeun prédikat anu dipasihkeun (indéks unsur munggaran tina partisi kadua).
    ///
    /// nyiksikan teh dianggap bisa bagi nurutkeun kana predikat dibikeun.
    /// Ieu ngandung harti yén sadaya unsur anu predikat balik leres aya dina mimiti keureutan sareng sadaya unsur anu predikat mulih palsu aya tungtungna.
    ///
    /// Salaku conto, [7, 15, 3, 5, 4, 12, 6] mangrupikeun partisi dina predikat x% 2!=0 (sadaya nomer ganjil aya dina ngamimitian, bahkan dina tungtung).
    ///
    /// Upami keureut ieu henteu dipilahkeun, hasilna anu dikembalikan henteu ditangtoskeun sareng henteu aya artina, sabab metode ieu ngalakukeun semacam milarian binér.
    ///
    /// Tingali ogé [`binary_search`], [`binary_search_by`], sareng [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // Kaamanan: Nalika `left < right`, `left <= mid < right`.
            // Ku alatan éta `left` salawasna ningkat sareng `right` sok turun, sareng salah sahiji diantarana dipilih.Dina dua kasus `left <= right` geus wareg.Maka upami `left < right` dina undakan, `left <= right` sugema dina léngkah salajengna.
            //
            // Kituna salami `left != right`, `0 <= left < right <= len` wareg sareng upami kasus ieu `0 <= mid < len` wareg teuing.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Urang kedah jelas-jelas nyiksikan aranjeunna kana panjang anu sami
        // pikeun ngagampangkeun pangoptimal pikeun milih pamariksaan bounds.
        // Tapi kumargi éta henteu tiasa diandelkeun kami ogé ngagaduhan spésialisasi anu jelas pikeun T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Nyiptakeun sapotong kosong.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Nyiptakeun nyiksikan kosong anu teu tiasa dirobih.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Pola dina irisan, ayeuna, ngan ukur dianggo ku `strip_prefix` sareng `strip_suffix`.
/// Dina titik future, urang ngaharepkeun ngageneralisasi `core::str::Pattern` (anu dina waktos nyerat diwatesan dugi ka `str`) kana irisan, teras trait ieu bakal diganti atanapi dileungitkeun.
///
pub trait SlicePattern {
    /// Jinis elemen tina irisan anu cocog sareng.
    type Item;

    /// Ayeuna, konsumén `SlicePattern` peryogi nyiksikan.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}