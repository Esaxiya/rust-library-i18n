#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ngandung definisi strukturna pikeun perenah kompiler jinis bawaan.
//!
//! Éta tiasa dianggo salaku udagan transmutes dina kode anu teu aman pikeun ngamanipulasi perwakilan atah langsung.
//!
//!
//! Definisi aranjeunna kedahna cocog sareng ABI anu ditetepkeun dina `rustc_middle::ty::layout`.
//!

/// Répréséntasi tina obyék trait sapertos `&dyn SomeTrait`.
///
/// Struktur ieu ngagaduhan tata ruang anu sami sareng jinis sapertos `&dyn SomeTrait` sareng `Box<dyn AnotherTrait>`.
///
/// `TraitObject` dijamin cocog sareng tata letak, tapi sanés jinis obyék trait (contona, lapanganna henteu langsung diaksés dina `&dyn SomeTrait`) ogé henteu ngendalikeun perenah éta (ngarobah definisi moal ngarobih tata ruang `&dyn SomeTrait`).
///
/// Éta ngan ukur dirancang pikeun dianggo ku kode anu teu aman anu kedah ngamanipulasi detail tingkat handap.
///
/// Teu aya cara pikeun ngarujuk ka sadaya obyék trait sacara umum, janten hiji-hijina cara pikeun nyiptakeun nilai tina jinis ieu nyaéta fungsi sapertos [`std::mem::transmute`][transmute].
/// Nya kitu, hiji-hijina cara pikeun nyiptakeun obyék trait leres tina nilai `TraitObject` nyaéta kalayan `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintésis hiji obyék trait kalayan jinis anu teu cocog-salah sahiji tempat anu teu cocog sareng jinis nilai anu nunjukkeun data pointer-kamungkinan pisan ngakibatkeun kabiasaan anu teu ditangtoskeun.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // conto trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // hayu kompiler ngadamel obyék trait
/// let object: &dyn Foo = &value;
///
/// // tingali kana perwakilan atah
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // pointer data nyaéta alamat `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // nyusunna hiji objek anyar, ngarah ka `i32` béda, keur awas mun nganggo vtable `i32` ti `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // éta kedah dianggo saolah-olah urang parantos ngawangun objek trait kaluar tina `other_value` langsung
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}