/// Kode khusus dina destruktor.
///
/// Nalika nilai henteu peryogi deui, Rust bakal ngajalankeun "destructor" dina nilai éta.
/// Cara anu paling umum yén nilai henteu peryogi deui nyaéta nalika éta kaluar tina wengkuan.Penghancur masih tiasa dijalankeun dina kaayaan anu sanés, tapi urang bakal fokus kana wengkuan pikeun conto di dieu.
/// Pikeun diajar ngeunaan sababaraha kasus sanésna, punten tingali bagian [the reference] ngeunaan destruktor.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Destruktor ieu diwangun ku dua komponén:
/// - Sauran `Drop::drop` kanggo nilai éta, upami `Drop` trait khusus ieu dilaksanakeun pikeun jinisna.
/// - "drop glue" anu dihasilkeun sacara otomatis anu sacara rekursif nyaéta panggero anu ngarusak sadaya bidang tina nilai ieu.
///
/// Salaku Rust sacara otomatis nyauran destruktorer sadaya bidang anu aya, anjeun henteu kedah nerapkeun `Drop` dina kaseueuran kasus.
/// Tapi aya sababaraha kasus dimana éta mangpaat, contona pikeun jinis anu sacara langsung ngatur sumberdaya.
/// Sumber anu tiasa janten mémori, éta tiasa janten deskriptor file, éta tiasa janten stop kontak jaringan.
/// Sakali nilai jenis éta henteu badé dianggo deui, éta kedah "clean up" sumberdaya ku ngabébaskeun mémori atanapi nutup file atanapi stop kontak.
/// Ieu padamelan tukang ngarusak, maka padamelan `Drop::drop`.
///
/// ## Examples
///
/// Pikeun ningali palaku anu ngaruksak, hayu urang tingali dina program ieu:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust mimitina bakal nyauran `Drop::drop` pikeun `_x` teras pikeun `_x.one` sareng `_x.two`, hartosna yén ngajalankeun ieu bakal nyetak
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Komo upami urang miceun palaksanaan `Drop` pikeun `HasTwoDrop`, anu ngarusak lapangan na masih disebut.
/// Ieu bakal ngahasilkeun
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Anjeun teu tiasa nyauran `Drop::drop` nyalira
///
/// Kusabab `Drop::drop` dianggo pikeun meresihan nilai, panginten bahaya upami nganggo nilai ieu saatos metode na disebat.
/// Kusabab `Drop::drop` henteu ngagaduhan kapamilikan input na, Rust nyegah panyalahgunaan ku teu ngamungkinkeun anjeun nyauran `Drop::drop` langsung.
///
/// Kalayan kecap séjén, upami anjeun nyobian sacara éksplisit nelepon `Drop::drop` dina conto di luhur, anjeun bakal ngagaduhan kasalahan panyusun.
///
/// Upami anjeun hoyong sacara éksplisit nelepon penghancur nilai, [`mem::drop`] tiasa dianggo tibatan.
///
/// [`mem::drop`]: drop
///
/// ## Pesenan lungsur
///
/// Anu ti dua `HasDrop` kami anu murag heula?Pikeun struktur, éta urutan anu sami anu dinyatakeunana: mimitina `one`, teras `two`.
/// Upami anjeun hoyong nyobian ieu nyalira, anjeun tiasa ngarobih `HasDrop` di luhur pikeun ngandung sababaraha data, sapertos bilangan bulat, teras dianggo dina `println!` di jero `Drop`.
/// Kalakuan ieu dijamin ku bahasa.
///
/// Beda sareng strukturna, variabel lokal turun dina urutan anu sabalikna:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ieu bakal nyetak
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Mangga tingali [the reference] pikeun aturan lengkep.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` sareng `Drop` ekslusif
///
/// Anjeun teu tiasa ngalaksanakeun [`Copy`] sareng `Drop` dina tipeu anu sami.Jenis anu `Copy` tersirat diduplikasi ku panyusunna, janten hésé pisan pikeun ngaduga iraha, sareng sabaraha sering destruktor bakal dieksekusi.
///
/// Sapertos kitu, jenis ieu teu tiasa gaduh destruktor.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ngaeksekusi destruktor pikeun jenis ieu.
    ///
    /// Cara ieu disebut sacara implisit nalika nilaina kaluar tina ruang lingkup, sareng teu tiasa disebat sacara eksplisit (ieu mangrupikeun kasalahan kompiler [E0040]).
    /// Nanging, fungsi [`mem::drop`] dina prelude tiasa dianggo pikeun nyauran palaksanaan `Drop` argumen.
    ///
    /// Nalika metoda ieu parantos disebat, `self` henteu acan tiasa disélokasi.
    /// Éta ngan ukur kajadian saatos metode na parantos réngsé.
    /// Upami ieu sanés masalahna, `self` bakal janten rujukan ngagantung.
    ///
    /// # Panics
    ///
    /// Nunjukkeun yén [`panic!`] bakal nyauran `drop` nalika éta dikaluarkeun, naon waé [`panic!`] dina palaksanaan `drop` sigana bakal dibolaykeun.
    ///
    /// Catet yén sanajan panics ieu, nilaina dianggap turun;
    /// anjeun teu kedah nyababkeun `drop` ditelepon deui.
    /// Ieu biasana sacara otomatis diatur ku panyusunna, tapi nalika nganggo kode anu teu aman, kadang tiasa ngahaja, utamina nalika nganggo [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}