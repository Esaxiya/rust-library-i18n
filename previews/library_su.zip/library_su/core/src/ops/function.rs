/// Versi operator telepon anu nyandak panarima anu teu tiasa dirobih.
///
/// Instansi `Fn` tiasa disebat sababaraha kali tanpa kaayaan mutasi.
///
/// *trait (`Fn`) ieu henteu matak lieur sareng [function pointers] (`fn`).*
///
/// `Fn` dilaksanakeun sacara otomatis ku panutupan anu ngan ukur nyandak rujukan anu teu tiasa dirobih pikeun variabel anu ditangkep atanapi henteu néwak nanaon pisan, ogé (safe) [function pointers] (kalayan sababaraha peringatan, tingali dokuméntasi na pikeun langkung jelasna).
///
/// Salaku tambahan, pikeun jenis `F` anu nerapkeun `Fn`, `&F` ogé nerapkeun `Fn`.
///
/// Kusabab duanana [`FnMut`] sareng [`FnOnce`] mangrupakeun supertraits of `Fn`, naon conto `Fn` tiasa dianggo salaku parameter anu diarepkeun [`FnMut`] atanapi [`FnOnce`].
///
/// Anggo `Fn` salaku kaiket nalika anjeun badé nampi parameter tina jinis sapertos fungsina sareng kedah nyauranana sababaraha kali sareng tanpa kaayaan mutasi (contona, nalika nyauran éta babarengan).
/// Upami anjeun henteu kedah sarat ketat sapertos kitu, anggo [`FnMut`] atanapi [`FnOnce`] sakumaha wates.
///
/// Tingali [chapter on closures in *The Rust Programming Language*][book] pikeun sababaraha langkung seueur inpormasi ngeunaan topik ieu.
///
/// Ogé catetan teh rumpaka husus pikeun `Fn` traits (misalna
/// `Fn(usize, bool) -> ngagunnakeun`).Anu resep kana detil téknis ieu tiasa ningali kana [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nelepon panutupanana
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Maké parameter `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sahingga regex tiasa ngandelkeun `&str: !FnMut` éta
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Laksanakeun operasi telepon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versi tina operator panggero anu diperlukeun panarima mutable.
///
/// Instansi `FnMut` tiasa disebat sababaraha kali sareng tiasa mutasi kaayaan.
///
/// `FnMut` dilaksanakeun sacara otomatis ku panutupan anu nyandak rujukan anu tiasa dirobih kana variabel anu ditangkep, ogé sadaya jinis anu ngalaksanakeun [`Fn`], misal, (safe) [function pointers] (kumargi `FnMut` mangrupikeun supertrait of [`Fn`]).
/// Salaku tambahan, pikeun jenis `F` anu nerapkeun `FnMut`, `&mut F` ogé nerapkeun `FnMut`.
///
/// Kusabab [`FnOnce`] mangrupikeun supertrait of `FnMut`, conto naon waé `FnMut` tiasa dianggo dimana [`FnOnce`] diarepkeun, sareng kumargi [`Fn`] mangrupikeun subtrait `FnMut`, naon waé conto [`Fn`] tiasa dianggo dimana `FnMut` diarepkeun.
///
/// Anggo `FnMut` salaku kaiket nalika anjeun badé nampi parameter tina jinis sapertos fungsi sareng kedah nyauranana sababaraha kali, bari ngantepkeun éta mutasi kaayaan.
/// Upami anjeun henteu hoyong parameter pikeun mutasi kaayaan, anggo [`Fn`] salaku kaiket;upami anjeun henteu kedah nyauran deui sababaraha kali, anggo [`FnOnce`].
///
/// Tingali [chapter on closures in *The Rust Programming Language*][book] pikeun sababaraha langkung seueur inpormasi ngeunaan topik ieu.
///
/// Ogé catetan teh rumpaka husus pikeun `Fn` traits (misalna
/// `Fn(usize, bool) -> ngagunnakeun`).Anu resep kana detil téknis ieu tiasa ningali kana [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Nelepon panutupanana anu tiasa dicandak
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Ngagunakeun parameter `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sahingga regex tiasa ngandelkeun `&str: !FnMut` éta
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Laksanakeun operasi telepon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versi operator telepon anu nyandak panarima nilai.
///
/// Instansi `FnOnce` tiasa ditelepon, tapi panginten henteu tiasa disebat sababaraha kali.Kusabab ieu, upami hiji-hijina anu dipikanyaho ngeunaan hiji tipeu nyaéta nerapkeun `FnOnce`, éta ngan ukur tiasa disebat sakali.
///
/// `FnOnce` dilaksanakeun sacara otomatis ku panutupan anu tiasa nganggo variabel anu ditangkep, ogé sadaya jinis anu ngalaksanakeun [`FnMut`], misal, (safe) [function pointers] (kumargi `FnOnce` mangrupikeun supertrait of [`FnMut`]).
///
///
/// Kusabab duanana [`Fn`] sareng [`FnMut`] mangrupikeun subtraits `FnOnce`, naon waé conto [`Fn`] atanapi [`FnMut`] tiasa dianggo dimana diperkirakeun `FnOnce`.
///
/// Anggo `FnOnce` salaku kaiket nalika anjeun badé nampi parameter tina jinis sapertos fungsi sareng ngan kedah nganuhunkeun sakali.
/// Upami anjeun kedah nyauran parameterna sababaraha kali, anggo [`FnMut`] salaku kaiket;upami anjeun ogé peryogi éta henteu mutasi kaayaan, anggo [`Fn`].
///
/// Tingali [chapter on closures in *The Rust Programming Language*][book] pikeun sababaraha langkung seueur inpormasi ngeunaan topik ieu.
///
/// Ogé catetan teh rumpaka husus pikeun `Fn` traits (misalna
/// `Fn(usize, bool) -> ngagunnakeun`).Anu resep kana detil téknis ieu tiasa ningali kana [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ngagunakeun parameter `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` meakeun variabel na anu direbut, janten teu tiasa dijalankeun langkung ti sakali.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Nyobian nyungkeun `func()` deui bakal buang kasalahan `use of moved value` pikeun `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` moal tiasa disaur deui dina waktos ieu
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sahingga regex tiasa ngandelkeun `&str: !FnMut` éta
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Jenis anu balik saatos operator telepon parantos dianggo.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Laksanakeun operasi telepon.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}