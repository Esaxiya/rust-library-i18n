/// Dipaké pikeun operasi dereferénsi anu teu tiasa dirobih, sapertos `*v`.
///
/// Salian digunakeun pikeun operasi dereferénsi anu eksplisit sareng operator (unary) `*` dina kontéks anu teu tiasa dirobih, `Deref` ogé dianggo sacara implisit ku panyusun dina sababaraha kaayaan.
/// Mékanisme ieu disebat ['`Deref` coercion'][more].
/// Dina kontéks anu tiasa dirobih, [`DerefMut`] dianggo.
///
/// Ngalaksanakeun `Deref` pikeun petunjuk pinter ngajantenkeun aksés kana data anu aya di tukangeunana janten merenah, sabab éta ngalaksanakeun `Deref`.
/// Di sisi anu sanésna, aturan ngeunaan `Deref` sareng [`DerefMut`] didesain khusus pikeun nampung panunjuk pinter.
/// Kusabab ieu,**`Deref` kedahna dilaksanakeun pikeun petunjuk anu hadé** pikeun nyegah kabingungan.
///
/// Alesan anu sami,**trait ieu kedah pernah gagal**.Gagalna nalika dérferérénsi tiasa ngabingungkeun pisan nalika `Deref` disaur sacara implisit.
///
/// # Langkung lengkep ihwal `Deref` paksaan
///
/// Upami `T` ngalaksanakeun `Deref<Target = U>`, sareng `x` mangrupikeun nilai tina tipe `T`, maka:
///
/// * Dina kontéks anu teu tiasa robih, `*x` (dimana `T` sanés rujukan atanapi pointer atah) sami sareng `* Deref::deref(&x)`.
/// * Nilai tipe `&T` dipaksa nepi ka nilai tipe `&U`
/// * `T` implisit implisit sadayana metoda (immutable) tina tipe `U`.
///
/// Kanggo langkung seueur detil, buka [the chapter in *The Rust Programming Language*][book] ogé bagian rujukan dina [the dereference operator][ref-deref-op], [method resolution] sareng [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktur kalayan médan tunggal anu tiasa diaksés ku ngadéferénsi strukturna.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Jenis anu dihasilkeun saatos dérferénsi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferensi nilai.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Dipaké pikeun operasi dereferénsi anu tiasa dirobih, sapertos dina `*v = 1;`.
///
/// Salian digunakeun pikeun operasi dereferénsi anu eksplisit sareng operator (unary) `*` dina kontéks anu tiasa dirobih, `DerefMut` ogé dianggo sacara implisit ku panyusun dina sababaraha kaayaan.
/// Mékanisme ieu disebat ['`Deref` coercion'][more].
/// Dina kontéks anu teu robih, [`Deref`] dianggo.
///
/// Ngalaksanakeun `DerefMut` pikeun petunjuk anu pinter ngajantenkeun mutasi data anu aya di tukangeunana janten merenah, sabab éta ngalaksanakeun `DerefMut`.
/// Di sisi anu sanésna, aturan ngeunaan [`Deref`] sareng `DerefMut` didesain khusus pikeun nampung panunjuk pinter.
/// Kusabab ieu,**`DerefMut` kedahna ngan ukur diterapkeun pikeun petunjuk pinter** pikeun nyingkahan kekeliruan.
///
/// Alesan anu sami,**trait ieu kedah pernah gagal**.Gagalna nalika dérferérénsi tiasa ngabingungkeun pisan nalika `DerefMut` disaur sacara implisit.
///
/// # Langkung lengkep ihwal `Deref` paksaan
///
/// Upami `T` ngalaksanakeun `DerefMut<Target = U>`, sareng `x` mangrupikeun nilai tina tipe `T`, maka:
///
/// * Dina kontéks anu tiasa dirobih, `*x` (dimana `T` sanés rujukan atanapi panunjuk atah) sami sareng `* DerefMut::deref_mut(&mut x)`.
/// * Nilai tipe `&mut T` dipaksa nepi ka nilai tipe `&mut U`
/// * `T` implisit implisit sadayana metoda (mutable) tina tipe `U`.
///
/// Kanggo langkung seueur detil, buka [the chapter in *The Rust Programming Language*][book] ogé bagian rujukan dina [the dereference operator][ref-deref-op], [method resolution] sareng [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktur kalayan médan tunggal anu tiasa dirobih ku ngadéferénsi strukturna.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Bisa ogé dereferénsi nilaina.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Nunjukkeun yén strukturna tiasa dianggo salaku panarima metoda, tanpa fitur `arbitrary_self_types`.
///
/// Ieu dilaksanakeun ku jinis pointer stdlib sapertos `Box<T>`, `Rc<T>`, `&T`, sareng `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}