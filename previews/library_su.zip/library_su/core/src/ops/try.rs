/// trait pikeun ngarobih kabiasaan operator `?`.
///
/// Jinis anu nerapkeun `Try` mangrupikeun cara anu kanonis pikeun ningali éta tina dikotomi success/failure.
/// trait Hal ieu ngamungkinkeun duanana extracting jalma sukses atanapi gagalna nilai tina hiji conto aya na nyieun hiji conto anyar ti sukses atanapi nilai gagalna.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Jenis nilai ieu nalika ditingali suksés.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Jenis nilai ieu nalika ditingali gagal.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Ngalarapkeun operator "?".Balikna `Ok(t)` hartosna yén palaksanaan kedah diteraskeun normal, sareng hasil `?` nyaéta nilai `t`.
    /// Balikna `Err(e)` hartosna yén palaksanaan kedah branch ka jero kalebet `catch`, atanapi balik tina fungsina.
    ///
    /// Upami hasil `Err(e)` dipulang, nilai `e` bakal "wrapped" dina jinis balik tina wengkuan anu ngalingkup (anu kedahna nerapkeun `Try`).
    ///
    /// Khususna, nilai `X::from_error(From::from(e))` dipulangkeun, dimana `X` mangrupikeun jinis balikna fungsi ngalingkupkeun.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bungkus nilai kasalahan pikeun ngawangun hasil komposit.
    /// Salaku conto, `Result::Err(x)` sareng `Result::from_error(x)` sami.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Bungkus nilai OK pikeun ngawangun hasil komposit.
    /// Salaku conto, `Result::Ok(x)` sareng `Result::from_ok(x)` sami.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}