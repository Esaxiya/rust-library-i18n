use crate::marker::Unpin;
use crate::pin::Pin;

/// Hasil tina hanca generator.
///
/// Enum ieu dipulangkeun tina metoda `Generator::resume` sareng nunjukkeun kamungkinan nilai balik generator.
/// Ayeuna ieu pakait sareng titik gantung (`Yielded`) atanapi titik penghentian (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generator ditunda kalayan nilai.
    ///
    /// Kaayaan ieu nunjukkeun yén generator parantos ditunda, sareng biasana pakait sareng pernyataan `yield`.
    /// Nilai anu disayogikeun dina varian ieu pakait sareng éksprési anu dialirkeun ka `yield` sareng ngamungkinkeun generator ngahasilkeun nilai unggal-unggal ngahasilkeun.
    ///
    ///
    Yielded(Y),

    /// Generator réngsé ku nilai balik.
    ///
    /// Kaayaan ieu nunjukkeun yén generator parantos réngsé ngajalankeun sareng nilai anu disayogikeun.
    /// Sakali generator parantos mulih `Complete` dianggap kasalahan programmer pikeun nyauran `resume` deui.
    ///
    Complete(R),
}

/// trait dilaksanakeun ku jinis generator builtin.
///
/// Generator, ogé biasa disebut coroutines, ayeuna mangrupikeun ciri basa ékspérimén dina Rust.
/// Ditambahkeun dina [RFC 2033] generator ayeuna dimaksudkeun pikeun utamina nyayogikeun blok wangunan pikeun sintaksis async/await tapi sigana bakal manjangan ogé nyayogikeun definisi ergonomis pikeun iterator sareng primitip sanésna.
///
///
/// Sintaksis sareng semantik pikeun generator teu stabil sareng peryogi RFC salajengna pikeun stabilisasi.Dina waktos ieu, sanaos, sintaksisna sapertos panutupan:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Langkung dokuméntasi generator tiasa dipendakan dina buku henteu stabil.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Jinis nilai ngahasilkeun generator ieu.
    ///
    /// Jenis anu pakait ieu pakait sareng éksprési `yield` sareng nilai-nilai anu diidinan dipulangkeun unggal ngahasilkeun generator.
    ///
    /// Misalna hiji iterator-as-a-generator sigana bakal ngagaduhan jinis ieu salaku `T`, jenis anu ditetepkeun deui.
    ///
    type Yield;

    /// Jinis nilai generator ieu mulih.
    ///
    /// Ieu pakait sareng jinis anu dipulangkeun tina generator naha kalayan pernyataan `return` atanapi sacara implisit salaku ungkapan terakhir tina generator sacara literal.
    /// Salaku conto futures bakal nganggo ieu salaku `Result<T, E>` sabab ngagambarkeun future anu réngsé.
    ///
    ///
    type Return;

    /// Neruskeun dijalankeunnana generator ieu.
    ///
    /// Fungsi ieu bakal neraskeun palaksanaan generator atanapi ngamimitian palaksanaan upami éta henteu acan.
    /// Telepon ieu bakal balik deui ka titik gantung terakhir generator, neraskeun deui éksékusi ti `yield` pangénggalna.
    /// Generator bakal neraskeun ngaéksekusi dugi ngahasilkeun atanapi balik, dina titik ieu fungsi ieu bakal balik.
    ///
    /// # Nilai balik
    ///
    /// Enum `GeneratorState` balik tina fungsi ieu nunjukkeun kaayaan generator dimana balik.
    /// Upami varian `Yielded` dipulangkeun maka generator parantos ngahontal titik gantung sareng nilai parantos dikaluarkeun.
    /// Generator dina kaayaan ieu sayogi kanggo diteruskeun dina titik engké.
    ///
    /// Upami `Complete` dipulangkeun maka generator parantos réngsé kalayan nilai anu disayogikeun.Teu valid pikeun generator dihanca deui.
    ///
    /// # Panics
    ///
    /// Fungsi ieu tiasa panic upami disebat saatos varian `Complete` parantos dipulangkeun sateuacanna.
    /// Sedengkeun literals generator dina basa dijamin panic nalika dilanjutkeun saatos `Complete`, ieu henteu dijamin pikeun sadaya palaksanaan `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}