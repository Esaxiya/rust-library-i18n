use crate::marker::Unsize;

/// Trait anu nunjukkeun yén ieu mangrupikeun pointer atanapi bungkus kanggo hiji, dimana unsizing tiasa dilakukeun dina pointee.
///
/// Tingali [DST coercion RFC][dst-coerce] sareng [the nomicon entry on coercion][nomicon-coerce] pikeun langkung jelasna.
///
/// Pikeun jinis pointer builtin, pointers ka `T` bakal maksa kana pointers ka `U` upami `T: Unsize<U>` ku jalan ngarobah tina pointer ipis janten pointer gajih.
///
/// Pikeun jinis khusus, paksaan di dieu dianggo ku maksa `Foo<T>` dugi ka `Foo<U>` disayogikeun impl `CoerceUnsized<Foo<U>> for Foo<T>` aya.
/// Implik sapertos kitu ngan ukur tiasa diserat upami `Foo<T>` ngagaduhan ngan ukur hiji lapangan non-phantomdata anu ngalibatkeun `T`.
/// Upami jinis bidangna nyaéta `Bar<T>`, palaksanaan `CoerceUnsized<Bar<U>> for Bar<T>` kedah aya.
/// Paksaan bakal dianggo ku cara maksa lapangan `Bar<T>` kana `Bar<U>` sareng ngeusian sésana bidang ti `Foo<T>` kanggo nyiptakeun `Foo<U>`.
/// Ieu sacara efektif bakal ngebor ka lapangan pointer sareng nekenkeun éta.
///
/// Sacara umum, pikeun petunjuk pinter anjeun bakal nerapkeun `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, sareng `?Sized` opsional kabeungkeut dina `T` nyalira.
/// Pikeun jinis bungkus anu langsung nyisipkeun `T` sapertos `Cell<T>` sareng `RefCell<T>`, anjeun tiasa langsung ngalaksanakeun `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ieu bakal ngantep paksaan jinis sapertos `Cell<Box<T>>` jalan.
///
/// [`Unsize`][unsize] digunakeun pikeun nandaan jinis-jinis anu tiasa dipaksakeun ka DST upami aya di tukang pointer.Éta dilaksanakeun sacara otomatis ku panyusun.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ieu dianggo pikeun kaamanan obyék, pikeun mariksa yén jinis panarima metode tiasa dikirim.
///
/// Conto palaksanaan trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}