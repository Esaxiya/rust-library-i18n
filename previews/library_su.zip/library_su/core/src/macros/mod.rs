#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Ngembang janten `$crate::panic::panic_2015` atanapi `$crate::panic::panic_2021` gumantung kana édisi anu nelepon.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Negeskeun yén dua ungkapan téh sarua jeung silih (maké [`PartialEq`]).
///
/// Dina panic, makro ieu bakal nyitak nilai tina ungkapan kalawan Répréséntasi debug maranéhanana.
///
///
/// Kawas [`assert!`], makro ieu ngabogaan formulir kadua, dimana a custom pesen panic bisa disadiakeun.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // The reborrows handap téh ngahaja.
                    // Tanpa aranjeunna, slot tumpukan pikeun nginjeum ieu initialized malah méméh nilai nu dibandingkeun, anjog ka handap slow noticeable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // The reborrows handap téh ngahaja.
                    // Tanpa aranjeunna, slot tumpukan pikeun nginjeum ieu initialized malah méméh nilai nu dibandingkeun, anjog ka handap slow noticeable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Negeskeun yén dua ungkapan henteu sarua jeung silih (maké [`PartialEq`]).
///
/// Dina panic, makro ieu bakal nyitak nilai tina ungkapan kalawan Répréséntasi debug maranéhanana.
///
///
/// Kawas [`assert!`], makro ieu ngabogaan formulir kadua, dimana a custom pesen panic bisa disadiakeun.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // The reborrows handap téh ngahaja.
                    // Tanpa aranjeunna, slot tumpukan pikeun nginjeum ieu initialized malah méméh nilai nu dibandingkeun, anjog ka handap slow noticeable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // The reborrows handap téh ngahaja.
                    // Tanpa aranjeunna, slot tumpukan pikeun nginjeum ieu initialized malah méméh nilai nu dibandingkeun, anjog ka handap slow noticeable.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Negeskeun yén ekspresi boolean nyaeta `true` di runtime.
///
/// Ieu bakal nu dipake dina makro [`panic!`] lamun babasan disadiakeun moal bisa ngaevaluasi keur `true` di runtime.
///
/// Kawas [`assert!`], makro ieu ogé boga versi kadua, dimana a custom pesen panic bisa disadiakeun.
///
/// # Uses
///
/// Teu kawas [`assert!`], pernyataan `debug_assert!` téh ukur sangkan di non dioptimalkeun ngawangun sacara standar.
/// Hiji ngawangun dioptimalkeun moal ngaéksekusi pernyataan `debug_assert!` iwal `-C debug-assertions` disalurkeun kana compiler anu.
/// Hal ieu ngajadikeun `debug_assert!` mangpaat pikeun cék anu teuing mahal pikeun hadir dina siaran ngawangun tapi bisa jadi mantuan mangsa pangwangunan.
/// Hasil tina ngembangna `debug_assert!` sok tipe dipariksa.
///
/// Cindekna anu teu dipariksa ngamungkinkeun program dina kaayaan anu teu konsisten pikeun tetep dijalankeun, anu mungkin akibatna teu disangka-sangka tapi henteu ngenalkeun henteu aman salami ieu ngan ukur lumangsung dina kode anu aman.
///
/// Biaya kinerja déklarasi, nanging, henteu kaukur sacara umum.
/// Ngaganti [`assert!`] kalawan `debug_assert!` ieu sahingga ukur wanti sanggeus Profil teleb, sareng langkung importantly, ngan dina kode aman!
///
/// # Examples
///
/// ```
/// // pesen panic pikeun assertions ieu ngarupakeun nilai stringified sahiji ekspresi dibikeun.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // fungsi basajan pisan
/// debug_assert!(some_expensive_computation());
///
/// // ngeceskeun kalawan pesen custom
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Negeskeun yén dua ungkapan anu sarua unggal lianna.
///
/// Dina panic, makro ieu bakal nyitak nilai tina ungkapan kalawan Répréséntasi debug maranéhanana.
///
/// Teu kawas [`assert_eq!`], pernyataan `debug_assert_eq!` téh ukur sangkan di non dioptimalkeun ngawangun sacara standar.
/// Hiji ngawangun dioptimalkeun moal ngaéksekusi pernyataan `debug_assert_eq!` iwal `-C debug-assertions` disalurkeun kana compiler anu.
/// Hal ieu ngajadikeun `debug_assert_eq!` mangpaat pikeun cék anu teuing mahal pikeun hadir dina siaran ngawangun tapi bisa jadi mantuan mangsa pangwangunan.
///
/// Hasil tina ngembangna `debug_assert_eq!` sok tipe dipariksa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Negeskeun yén dua ungkapan henteu sarua unggal lianna.
///
/// Dina panic, makro ieu bakal nyitak nilai tina ungkapan kalawan Répréséntasi debug maranéhanana.
///
/// Teu kawas [`assert_ne!`], pernyataan `debug_assert_ne!` téh ukur sangkan di non dioptimalkeun ngawangun sacara standar.
/// Hiji ngawangun dioptimalkeun moal ngaéksekusi pernyataan `debug_assert_ne!` iwal `-C debug-assertions` disalurkeun kana compiler anu.
/// Hal ieu ngajadikeun `debug_assert_ne!` mangpaat pikeun cék anu teuing mahal pikeun hadir dina siaran ngawangun tapi bisa jadi mantuan mangsa pangwangunan.
///
/// Hasil tina ngembangna `debug_assert_ne!` sok ngetik dipariksa.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Mulih naha ekspresi dibikeun cocog salah sahiji pola dibikeun.
///
/// Sapertos dina éksprési `match`, pola na tiasa sacara opsional dituturkeun ku `if` sareng éksprési penjaga anu ngagaduhan aksés kana nami anu kaiket ku pola.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps hasilna atawa ngarambat kasalahan na.
///
/// Operator `?` ditambihan ngagentos `try!` sareng kedah dianggo gantina.
/// Saterusna, `try` mangrupakeun kecap wengkuan di Rust 2018, jadi lamun kudu make eta, anjeun bakal kedah nganggo [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` loyog jeung [`Result`] dibikeun.Bisi tina varian `Ok`, ekspresi nu boga nilai tina nilai dibungkus.
///
/// Bisi tina varian `Err`, éta retrieves kasalahan batin.`try!` teras ngalakukeun konvérsi nganggo `From`.
/// Ieu nyadiakeun artos otomatis antara kasalahan husus tur leuwih leuwih umum.
/// Kasalahan anu dihasilkeun teras langsung dipulangkeun.
///
/// Kusabab mulang awal, `try!` ngan bisa dipaké dina fungsi nu balik [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metodeu anu pikaresep pikeun gancang balik Kasalahan
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // The saméméhna metoda Kasalahan balik gancang
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ieu sami sareng:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Nyerat data anu diformat kana panyangga.
///
/// Makro ieu nampi 'writer', string format, sareng daptar argumen.
/// Argumen bakal diformat numutkeun senar format anu parantos ditangtoskeun sareng hasilna bakal diturunkeun ka panulis.
/// panulis meureun sagala nilai ku metoda `write_fmt`;umumna ieu asalna tina hiji palaksanaan boh [`fmt::Write`] atawa [`io::Write`] trait.
/// Makro mulih naon nu `write_fmt` metoda mulih;ilaharna mangrupa [`fmt::Result`], atawa hiji [`io::Result`].
///
/// Tingali [`std::fmt`] pikeun langkung seueur inpormasi ngeunaan sintaksis string format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A modul tiasa diimpor duanana `std::fmt::Write` na `std::io::Write` jeung panggero `write!` on objék ngalaksanakeun boh, sakumaha objék teu ilaharna nerapkeun duanana.
///
/// Sanajan kitu, éta modul kudu ngimpor traits mumpuni jadi ngaran maranéhna ulah konflik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // ngagunakeun fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // migunakeun io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: macro Ieu bisa dipaké dina setups `no_std` ogé.
/// Dina setelan `no_std` anjeun jawab sacara rinci palaksanaan komponén.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tulis data anu diformat kana panyangga, sareng larik anyar ditambihan.
///
/// Dina sagala platform, newline mangrupa karakter garis Feed (`\n`/`U+000A`) nyalira (teu tambahan kenop Balik (`\r`/`U+000D`).
///
/// Kanggo inpormasi lengkep, tingali [`write!`].Kanggo inpormasi ngeunaan sintaksis string format, tingali [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A modul tiasa diimpor duanana `std::fmt::Write` na `std::io::Write` jeung panggero `write!` on objék ngalaksanakeun boh, sakumaha objék teu ilaharna nerapkeun duanana.
/// Sanajan kitu, éta modul kudu ngimpor traits mumpuni jadi ngaran maranéhna ulah konflik:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // ngagunakeun fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // migunakeun io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Nunjukkeun kode anu teu kahontal.
///
/// Ieu gunana iraha waé ogé panyusun henteu tiasa nangtoskeun yén sababaraha kode henteu kahontal.Salaku conto:
///
/// * Cocogkeun panangan sareng kaayaan penjaga.
/// * Puteran anu dinamis nungtungan.
/// * Iterators anu dinamis nungtungan.
///
/// Mun tekad yen kode nyaeta unreachable ngabuktikeun lepat, program geura terminates ku [`panic!`].
///
/// The tara unsafe tina makro ieu fungsi [`unreachable_unchecked`], anu bakal ngakibatkeun kabiasaan undefined lamun kode kasebut ngahontal.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// bakal kieu salawasna [`panic!`].
///
/// # Examples
///
/// Cocogkeun panangan:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // compile kasalahan upami commented kaluar
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // salah sahiji implementations poorest of x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Nunjukkeun kode anu teu tiasa dianggo ku panicking sareng pesen "not implemented".
///
/// Hal ieu ngamungkinkeun kode anjeun pikeun jenis-cek, nu mangpaat lamun anjeun prototyping atanapi ngalaksanakeun hiji trait nu butuh sababaraha métode nu teu Anjeun ngalakukeun rencana tina ngagunakeun sakabéh.
///
/// Beda antara `unimplemented!` sareng [`todo!`] nyaéta nalika `todo!` ngalaksanakeun maksud ngalaksanakeun fungsina engké na pesen na "not yet implemented", `unimplemented!` henteu ngagaduhan klaim sapertos kitu.
/// Pesen na nyaéta "not implemented".
/// Ogé sababaraha IDE bakal nyirian `todo!` S.
///
/// # Panics
///
/// bakal kieu salawasna [`panic!`] sabab `unimplemented!` téh ngan hiji shorthand pikeun `panic!` ku, pesen husus dibereskeun.
///
/// Kawas `panic!`, makro ieu ngabogaan formulir kadua pikeun mintonkeun nilai adat.
///
/// # Examples
///
/// Kocapkeun kami ngagaduhan trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Simkuring hoyong nerapkeun `Foo` pikeun 'MyStruct', tapi pikeun sababaraha alesan eta ukur ngajadikeun rasa pikeun nerapkeun fungsi `bar()`.
/// `baz()` sarta `qux()` masih bakal perlu dihartikeun dina palaksanaan kami tina `Foo`, tapi urang tiasa nganggo `unimplemented!` dina definisi maranéhna pikeun ngawenangkeun kode urang pikeun compile.
///
/// Simkuring masih hayang boga urang program eureun ngajalankeun lamun metodeu unimplemented anu ngahontal.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ayeuna damel moal aya rasa ka `baz` a `MyStruct`, sangkan boga logika dieu pisan.
/////
///         // Ieu bakal nembongkeun "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Simkuring gaduh sababaraha logika di dieu, urang bisa nambahkeun pesen ka unimplemented!pikeun nembongkeun omission urang.
///         // Ieu bakal nembongkeun: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Nunjukkeun kode tacan beres.
///
/// Ieu tiasa manpaat upami anjeun prototyping sareng ngan ukur hoyong gaduh kode typecheck anjeun.
///
/// Beda antara [`unimplemented!`] na `todo!` éta bari `todo!` conveys hiji hajat tina ngalaksanakeun pungsi nu engké na suratna téh "not yet implemented", `unimplemented!` ngajadikeun aya klaim misalna.
/// Pesen na nyaéta "not implemented".
/// Ogé sababaraha IDE bakal nyirian `todo!` S.
///
/// # Panics
///
/// bakal kieu salawasna [`panic!`].
///
/// # Examples
///
/// Di dieu téh conto sabagian kode di-kamajuan.Kami ngagaduhan trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Simkuring hoyong nerapkeun `Foo` on salah sahiji jenis urang, tapi urang ogé rék gawé dina ngan `bar()` munggaran.Supados kode urang pikeun compile, urang kedah ngalaksanakeun `baz()`, sangkan bisa make `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // palaksanaan mana dieu
///     }
///
///     fn baz(&self) {
///         // hayu urang teu salempang ngeunaan ngalaksanakeun baz() keur ayeuna
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // urang bahkan henteu nganggo baz(), janten ieu henteu kunanaon.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisi makro internal.
///
/// Kaseueuran sipat makro (stabilitas, pisibilitas, sareng sajabana) dicandak tina kode sumber di dieu, kecuali fungsi ékspansi ngarobah input makro kana kaluaran, fungsi-fungsi éta disayogikeun ku panyusun.
///
///
pub(crate) mod builtin {

    /// Sabab kompilasi gagal dipilampah kasalahan dibikeun nalika encountered.
    ///
    /// macro Ieu sakuduna dipaké lamun crate ngagunakeun strategi kompilasi kondisional nyadiakeun seratan kasalahan hadé pikeun kaayaan erroneous.
    ///
    /// Ieu wujud kompiler-tingkat [`panic!`] tapi emits kasalahan salila *kompilasi* tinimbang di *runtime*.
    ///
    /// # Examples
    ///
    /// Dua conto sapertos sapertos makro sareng lingkungan `#[cfg]`.
    ///
    /// Emit kasalahan kompiler hadé lamun makro hiji disalurkeun nilai sah.
    /// Tanpa branch ahir, compiler anu masih bakal emit kasalahan, tapi suratna kasalahan urang moal bakal nyebut dua nilai sah.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Éror kompilator upami salah sahiji sajumlah fitur henteu sayogi.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Constructs parameter pikeun macros string-pormat lianna.
    ///
    /// macro Ieu fungsi ku cara nyokot string pormat literal ngandung `{}` pikeun tiap argumen tambahan kaliwat.
    /// `format_args!` prepares parameter tambihan pikeun mastikeun output bisa diinterpretasi salaku senar sarta canonicalizes dalil kana jenis tunggal.
    /// Sagala nilai nu implements nu [`Display`] trait bisa diliwatan mun `format_args!`, sakumaha tiasa wae palaksanaan [`Debug`] lulus ka `{:?}` dina senar pormat.
    ///
    ///
    /// Makro ieu ngahasilkeun nilai tipe [`fmt::Arguments`].nilai Ieu bisa diliwatan ka macros dina [`std::fmt`] keur ngalakukeun redirection mangpaat.
    /// Kabéh macros pormat séjén ([`format!`], [`write!`], [`println!`], jsb) anu proxied ngaliwatan hiji ieu.
    /// `format_args!`, henteu sapertos makro turunanana, ngahindarkeun alokasi tumpukan.
    ///
    /// Anjeun tiasa nganggo nilai [`fmt::Arguments`] yén `format_args!` mulih dina `Debug` na `Display` konteks salaku ditempo di handap ieu.
    /// Conto ogé nempokeun yén `Debug` sarta format `Display` kana hal anu sarua: nu string format interpolated di `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Kanggo inpo nu leuwih lengkep, tingal dokuméntasi dina [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sarua sareng `format_args`, tapi nambihan garis anyar dina tungtungna.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Mariksa variabel lingkungan dina waktos nyusun.
    ///
    /// macro ieu bakal dilegakeun ka nilai variabel lingkungan ngaranna dina waktos compile, ngahasilkeun hiji ekspresi tipe `&'static str`.
    ///
    ///
    /// Lamun variabel lingkunganana henteu diartikeun, teras hiji kasalahan kompilasi bakal dipancarkeun.
    /// Pikeun henteu ngaluarkeun kasalahan kompilasi, nganggo makro [`option_env!`] tibatan.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Anjeun tiasa ngaropea pesen kasalahan ku ngalirkeun senar salaku parameter anu kadua:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Lamun variabel lingkungan `documentation` henteu diartikeun, Anjeun bakal meunang kasalahan handap:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opsional mariksa variabel lingkungan dina waktos nyusun.
    ///
    /// Lamun variabel lingkungan ngaranna hadir dina waktos compile, ieu bakal dilegakeun ka hiji ekspresi tipe `Option<&'static str>` anu nilai téh `Some` sahiji nilai variabel lingkunganana.
    /// Upami variabel lingkungan henteu aya, maka ieu bakal dilegakeun ka `None`.
    /// Tempo [`Option<T>`][Option] pikeun émbaran nu langkung lengkep ihwal tipe ieu.
    ///
    /// A kasalahan waktu compile geus pernah dipancarkeun nalika maké makro kieu paduli naha variabel lingkungan anu hadir atawa teu.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates identifiers kana hiji identifier.
    ///
    /// macro Ieu nyokot angka salah sahiji identifiers koma-dipisahkeun, sareng concatenates kabeh kana salah, ngahasilkeun hiji éksprési nu mangrupakeun identifier anyar.
    /// Catetan kasehatan anu ngajadikeun eta sapertos nu makro teu bisa newak variabel lokal.
    /// Ogé, salaku aturan umum, macros téh ukur diwenangkeun dina item, pernyataan atawa posisi éksprési.
    /// Anu hartosna bari anjeun bisa make makro ieu ngarujuk kana variabel aya, fungsi atawa modul jsb, anjeun moal bisa nangtukeun nu anyar kalawan eta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idente! (énggal, pikaresepeun, nami) { }//henteu tiasa dianggo ku cara kieu!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates literals kana nyiksikan statik senar.
    ///
    /// macro Ieu nyokot angka salah sahiji literals koma-dipisahkeun, ngahasilkeun hiji ekspresi tipe `&'static str` nu ngawakilan sadaya literals disambungkeun ditinggalkeun-to-katuhu.
    ///
    ///
    /// Integer sarta titik floating literals anu stringified guna jadi disambungkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expands kana angka garis dina nu ieu invoked.
    ///
    /// Kalawan [`column!`] na [`file!`], macros ieu nyadiakeun informasi debugging keur pamekar ngeunaan lokasi dina sumberna.
    ///
    /// babasan dimekarkeun boga tipe `u32` na nyaeta 1 basis, jadi garis kahiji dina tiap file ngaevaluasi keur 1, nu kadua ka 2, jsb
    /// Ieu saluyu sareng pesen kasalahan ku panyusun umum atanapi éditor populér.
    /// Garis anu dikembalikan *henteu merta* garis tina pangintunan `line!` éta nyalira, tapi ngan ukur pangintunan makro pangpayunna dugi ka pangintunan makro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Ngalegaan kana nomer kolom dina waktos éta dianggo.
    ///
    /// Kalawan [`line!`] na [`file!`], macros ieu nyadiakeun informasi debugging keur pamekar ngeunaan lokasi dina sumberna.
    ///
    /// Éksprési anu dimekaran ngagaduhan jinis `u32` sareng dumasar-1, janten kolom anu munggaran dina unggal garis meunteun kana 1, anu kadua dugi ka 2, jst.
    /// Ieu saluyu sareng pesen kasalahan ku panyusun umum atanapi éditor populér.
    /// kolom balik téh *teu merta* garis tina namah `column!` sorangan, tapi rada di namah makro mimiti anjog nepi ka namah tina makro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Dilegakeun kana nami file anu dianggo.
    ///
    /// Kalawan [`line!`] na [`column!`], macros ieu nyadiakeun informasi debugging keur pamekar ngeunaan lokasi dina sumberna.
    ///
    /// Éksprési anu dimekaran ngagaduhan jinis `&'static str`, sareng file anu dikembalikan sanés pangintunan makro `file!` éta nyalira, tapi pangandaran makro anu pangpayunna dugi ka pangintunan makro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies alesan na.
    ///
    /// macro ieu bakal ngahasilkeun hiji ekspresi tipe `&'static str` nu di stringification tina sagala tokens diliwatan mun makro nu.
    /// Henteu aya larangan pikeun sintaksis tina pangrojong makro éta nyalira.
    ///
    /// Catet yén hasil dimekarkeun tina input tokens bisa ngarobah dina future.Anjeun kedah ati-ati upami anjeun ngandelkeun kaluaranana.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ngawengku hiji UTF-8 disandikeun file salaku senar a.
    ///
    /// file ieu lokasina relatif ka file ayeuna (kitu ka sabaraha modul nu kapanggih).
    /// Jalur anu disayogikeun diinterpretasi ku cara anu khusus pikeun platform dina waktos nyusun.
    /// Janten, salaku conto, invocation kalayan jalur Windows anu ngandung backslashes `\` moal nyusun leres dina Unix.
    ///
    ///
    /// Makro ieu bakal ngahasilkeun éksprési jinis `&'static str` anu mangrupikeun eusi file.
    ///
    /// # Examples
    ///
    /// Nganggap aya dua file dina diréktori sarua jeung eusi handap:
    ///
    /// Berkas 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Berkas 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' sarta ngajalankeun binér anu dihasilkeun baris nyitak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ngawengku hiji file salaku rujukan ka Asép Sunandar Sunarya bait.
    ///
    /// file ieu lokasina relatif ka file ayeuna (kitu ka sabaraha modul nu kapanggih).
    /// Jalur anu disayogikeun diinterpretasi ku cara anu khusus pikeun platform dina waktos nyusun.
    /// Janten, salaku conto, invocation kalayan jalur Windows anu ngandung backslashes `\` moal nyusun leres dina Unix.
    ///
    ///
    /// macro ieu bakal ngahasilkeun hiji ekspresi tipe `&'static [u8; N]` nu eusi file.
    ///
    /// # Examples
    ///
    /// Nganggap aya dua file dina diréktori sarua jeung eusi handap:
    ///
    /// Berkas 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Berkas 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' sarta ngajalankeun binér anu dihasilkeun baris nyitak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Expands ka string anu ngawakilan jalur modul ayeuna.
    ///
    /// Jalur modul ayeuna bisa dianggap salaku hirarki modul ngarah deui nepi ka crate root.
    /// Komponén mimiti jalur anu balik nyaéta nami crate anu ayeuna nuju disusun.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ngaevaluasi kombinasi boolean of umbul konfigurasi di compile-waktu.
    ///
    /// Sajaba atribut `#[cfg]`, makro ieu disadiakeun pikeun ngidinan evaluasi ekspresi boolean of umbul konfigurasi.
    /// Ieu remen ngawujud kana kode kirang duplicated.
    ///
    /// The rumpaka dibikeun ka makro ieu téh rumpaka sarua salaku atribut [`cfg`].
    ///
    /// `cfg!`, teu sapertos `#[cfg]`, henteu ngahapus kode naon waé sareng ngan ukur ngaévaluasi leres atanapi salah.
    /// Contona, kabéh blok dina ekspresi kedah if/else janten valid lamun `cfg!` dipaké pikeun kondisi, henteu paduli naon `cfg!` ieu evaluating.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses file salaku hiji ekspresi atawa hiji item nurutkeun kontéks éta.
    ///
    /// file ieu lokasina relatif ka file ayeuna (kitu ka sabaraha modul nu kapanggih).jalur disadiakeun keur diinterpretasi dina cara platform-spésifik dina waktos compile.
    /// Janten, salaku conto, invocation kalayan jalur Windows anu ngandung backslashes `\` moal nyusun leres dina Unix.
    ///
    /// Ngagunakeun makro ieu mindeng pamanggih goréng, kusabab lamun file ieu parsed salaku hiji éksprési, mangka bade ditempatkeun dina kode sabudeureun unhygienically.
    /// Ieu tiasa ngahasilkeun variabel atanapi fungsi anu bénten ti anu diarepkeun file upami aya variabel atanapi fungsi anu ngagaduhan nami anu sami dina file ayeuna.
    ///
    ///
    /// # Examples
    ///
    /// Nganggap aya dua file dina diréktori sarua jeung eusi handap:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Berkas 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' sarta ngajalankeun binér anu dihasilkeun baris nyitak "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Negeskeun yén ekspresi boolean nyaeta `true` di runtime.
    ///
    /// Ieu bakal nu dipake dina makro [`panic!`] lamun babasan disadiakeun moal bisa ngaevaluasi keur `true` di runtime.
    ///
    /// # Uses
    ///
    /// Assertions sok dipariksa di duanana debug jeung sékrési ngawangun, sarta teu bisa ditumpurkeun.
    /// Tempo [`debug_assert!`] pikeun assertions nu teu diaktipkeun di release ngawangun sacara standar.
    ///
    /// Kode unsafe bisa ngandelkeun `assert!` ngalaksanakeun invariants ngajalankeun-waktu éta, lamun dilanggar bisa ngakibatkeun unsafety.
    ///
    /// Kasus panggunaan sanés `assert!` kalebet uji coba sareng ngalaksanakeun invariants jangka waktos anu aman dina kode anu aman (anu ngalanggarna henteu tiasa ngahasilkeun henteu aman).
    ///
    ///
    /// # Messages custom
    ///
    /// Makro ieu ngagaduhan bentuk anu kadua, dimana pesen panic khusus tiasa disayogikeun atanapi henteu nganggo alesan pikeun pormat.
    /// Tempo [`std::fmt`] pikeun rumpaka keur formulir ieu.
    /// Ungkapan anu dijantenkeun salaku argumen format ngan ukur bakal dievaluasi upami nyatakeun gagal.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // pesen panic pikeun assertions ieu ngarupakeun nilai stringified sahiji ekspresi dibikeun.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // fungsi basajan pisan
    ///
    /// assert!(some_computation());
    ///
    /// // ngeceskeun kalawan pesen custom
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline assembly.
    ///
    /// Baca [unstable book] pikeun panggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-gaya inline assembly.
    ///
    /// Baca [unstable book] pikeun panggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Rakitan inline tingkat modul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints diliwatan tokens kana kaluaran baku.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ngaktipkeun atanapi nganonaktifkeun nyukcruk fungsi anu dianggo pikeun debugging macros anu sanés.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atribut makro dipaké pikeun nerapkeun macros diturunkeun.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Atribut makro dilarapkeun ka fungsi pikeun ngahurungkeun deui kana uji Unit.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut dilarapkeun kana fungsi pikeun ngajantenkeun janten tés tolok ukur.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Hiji jéntré palaksanaan `#[test]` na `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribut makro dilarapkeun ka statik pikeun ngadaptar eta salaku allocator global.
    ///
    /// Tempo ogé [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ngajaga item ayeuna teh dilarapkeun ka lamun jalur diliwatan nyaéta diaksés, sarta ngaluarkeun eta disebutkeun.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Ngalegaan sadaya atribut `#[cfg]` sareng `#[cfg_attr]` dina sempalan kode anu dilarapkeunana.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Detil palaksanaan teu stabil tina panyusun `rustc`, entong anggo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Detil palaksanaan teu stabil tina panyusun `rustc`, entong anggo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}