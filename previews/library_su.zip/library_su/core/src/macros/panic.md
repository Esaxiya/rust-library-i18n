Panics benang ayeuna.

Hal ieu ngamungkinkeun program pikeun langsung numpurkeun sareng masihan tanggapan ka anu nelepon program.
`panic!` kedah dianggo nalika program ngahontal kaayaan anu teu tiasa dipulihkeun.

Makro ieu mangrupikeun cara anu sampurna pikeun negeskeun kaayaan dina conto kode sareng dina tés.
`panic!` eta dihijikeun raket jeung metoda `unwrap` duanana [`Option`][ounwrap] na [`Result`][runwrap] enums.
Duanana implementations nelepon `panic!` basa aranjeunna keur disetel ka [`None`] atanapi [`Err`] varian.

Nalika nganggo `panic!()` anjeun tiasa nangtoskeun muatan senar, éta diwangun nganggo sintaksis [`format!`].
payload nyaeta dipaké nalika injecting nu panic kana thread Rust nelepon, ngabalukarkeun thread kana panic sagemblengna.

Paripolah standar nu `std` hook, nyaéta
kode anu ngalir langsung saatos panic dipanggil, nyaéta nyetak muatan pesen ka `stderr` sasarengan inpormasi file/line/column tina panggero `panic!()`.

Anjeun tiasa override nu panic hook maké [`std::panic::set_hook()`].
Jero hook a panic tiasa diakses salaku `&dyn Any + Send`, nu ngandung boh mangrupa `&str` atanapi `String` pikeun invocations `panic!()` biasa.
Pikeun panic ku nilai tina tipe séjén sejen, [`panic_any`] bisa dipaké.

[`Result`] enum sering janten solusi anu langkung saé pikeun pulih tina kasalahan tibatan nganggo makro `panic!`.
macro Ieu sakuduna dipaké pikeun nyingkahan lajengkeun maké nilai lepat, kayaning ti sumber éksternal.
inpo wincik tentang penanganan kasalahan anu kapanggih di [book].

Tempo oge [`compile_error!`] macro, pikeun raising kasalahan salila kompilasi.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Palaksanaan ayeuna

Mun thread utama panics éta bakal nungtungan sadayana threads anjeun sarta mungkas program anjeun kalawan kode `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





