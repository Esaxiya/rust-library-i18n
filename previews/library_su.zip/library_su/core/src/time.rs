#![stable(feature = "duration_core", since = "1.25.0")]

//! quantification temporal.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // duanana deklarasi sami
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// Jenis `Duration` pikeun ngagambarkeun jangka waktu, biasana dianggo pikeun sistem sistem waktos.
///
/// Unggal `Duration` diwangun ku sababaraha sakabéhna hasil detik sarta bagian fractional digambarkeun dina nanoseconds.
/// Upami sistem anu ngadukung henteu ngadukung presisi tingkat nanosecond, API ngariung timeout sistem biasana bakal buleudan jumlah nanodetik.
///
/// [`Duration`] s nerapkeun seueur traits umum, kalebet [`Add`], [`Sub`], sareng [`ops`] traits anu sanés.Ieu implements [`Default`] ku balik a enol-panjangna `Duration`.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # Pormat nilai `Duration`
///
/// `Duration` ngahaja teu ngagaduhan `Display` impl, sabab aya sababaraha rupa cara pikeun pormat rentang waktos kanggo kabaca manusa.
/// `Duration` nyadiakeun impl `Debug` nu nempokeun teh precision pinuh ku nilai.
///
/// The `Debug` kaluaran ngagunakeun non-ASCII "µs" ahiran keur microseconds.
/// Upami kaluaran program anjeun nembongan dina kontéks anu henteu tiasa ngandelkeun kasaluyuan Unicode lengkep, anjeun panginten hoyong pormat objék `Duration` nyalira atanapi nganggo crate pikeun ngalakukeunana.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // Salawasna 0 <=nanos <NANOS_PER_SEC
}

impl Duration {
    /// Durasi sadetik.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// Durasi salah millisecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// Durasi salah microsecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// Durasi salah nanosecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// Durasi nol waktos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// Durasi maksimum.
    ///
    /// Kira-kira sarua jeung lilana 584,942,417,355 taun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// Nyiptakeun `Duration` énggal tina jumlah anu parantos ditangtukeun sacara gembleng detik sareng nanosetik.
    ///
    /// Upami jumlah nanoseconds langkung ageung tibatan 1 milyar (jumlah nanodetik dina sadetik), maka éta bakal kalangkung kana detik-detik anu disayogikeun.
    ///
    ///
    /// # Panics
    ///
    /// Konstruktor ieu bakal panic upami mawa tina nanoseconds overflows counter detik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// Nyiptakeun `Duration` énggal tina jumlah anu parantos ditangtukeun sacara gembleng detik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// Nyiptakeun `Duration` anyar tina jumlah milliseconds anu ditangtoskeun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// Nyiptakeun `Duration` énggal tina jumlah mikrosékon anu ditangtukeun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// Nyiptakeun `Duration` anyar tina jumlah dieusian of nanoseconds.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// Balik leres upami `Duration` ieu teu aya waktos.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// Mulih jumlah _whole_ detik anu dikandung ku `Duration` ieu.
    ///
    /// Nilai balik teu kaasup (nanosecond) bagian fractional tina durasi nu tiasa didapet maké [`subsec_nanos`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// Pikeun nangtoskeun jumlah total detik anu diwakilan ku `Duration`, anggo `as_secs` dina kombinasi sareng [`subsec_nanos`]:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// Mulih ka bagian fractional of `Duration` ieu, dina sadayana milliseconds.
    ///
    /// Metoda ieu **henteu** mulih panjang lilana nalika diwakilan ku milidetik.
    /// Jumlah nu balik salawasna ngagambarkeun nyangkokkeun fractional tina kadua (ie, nya kurang leuwih hiji sarébu).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// Balikkeun bagéan pecahan tina `Duration` ieu, dina sakitar mikrosetik.
    ///
    /// Metoda ieu teu **moal** balik panjang durasi lamun digambarkeun ku microseconds.
    /// Angka anu dikintunkeun teras-terasan ngagambarkeun bagian pecahan sadetik (nyaéta, kirang ti sajuta).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// Balikkeun bagéan pecahan tina `Duration` ieu, dina nanodetik.
    ///
    /// Cara ieu henteu **henteu** mulihkeun panjang durasi nalika diwakilan ku nanosetik.
    /// Jumlah nu balik salawasna ngagambarkeun nyangkokkeun fractional tina kadua (ie, éta kirang ti samilyar).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// Mulih total jumlah sakabeh milliseconds ngandung ku `Duration` ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// Mulih total jumlah sakabeh microseconds ngandung ku `Duration` ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// Mulih total jumlah nanoseconds ngandung ku `Duration` ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// Dipariksa `Duration` tambahan.
    /// Perhitungan `self + other`, balik [`None`] lamun mudal lumangsung.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Ditambahkeun `Duration` jenuh.
    /// Perhitungan `self + other`, balik [`Duration::MAX`] lamun mudal lumangsung.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// Dipariksa pangirangan `Duration`.
    /// Perhitungan `self - other`, balik [`None`] lamun hasilna bakal jadi négatip atanapi lamun mudal lumangsung.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Pangirangan `Duration` jenuh.
    /// Ngitung `self - other`, balikkeun [`Duration::ZERO`] upami hasilna bakal négatip atanapi upami limpahan kajantenan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// Dipariksa `Duration` multiplication.
    /// Perhitungan `self * other`, balik [`None`] lamun mudal lumangsung.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // nanoseconds balikeun jadi u64, sabab teu bisa mudal jalan éta.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// Judul `Duration` perkalian.
    /// Ngitung `self * other`, balikkeun [`Duration::MAX`] upami limpahan kajantenan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// Dipariksa `Duration` divisi.
    /// Perhitungan `self / other`, balik [`None`] lamun `other == 0`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// Mulih jumlah detik ngandung ku `Duration` ieu salaku `f64`.
    /// Nilai balik teu kaasup (nanosecond) bagian fractional of durasi nu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// Mulih jumlah detik anu dikandung ku `Duration` ieu salaku `f32`.
    /// Nilai balik teu kaasup (nanosecond) bagian fractional of durasi nu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// Nyiptakeun `Duration` énggal tina sababaraha detik anu ditangtoskeun anu diwakilan salaku `f64`.
    ///
    /// # Panics
    /// constructor Ieu bakal panic lamun `secs` henteu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Nyiptakeun `Duration` anyar tina jumlah dieusian tina detik digambarkeun salaku `f32`.
    ///
    /// # Panics
    /// constructor Ieu bakal panic lamun `secs` henteu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// Multiplies `Duration` ku `f64`.
    /// # Panics
    /// Metoda ieu bakal panic lamun hasilna teu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// Kalikeun `Duration` ku `f32`.
    /// # Panics
    /// Metoda ieu bakal panic lamun hasilna teu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // dicatet yén kusabab kasalahan kasalahan ngabuleudkeun rada béda ti 8.478 sareng 847800.0
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// Bagikeun `Duration` ku `f64`.
    /// # Panics
    /// Metoda ieu bakal panic lamun hasilna teu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // Catet yén truncation dipaké, henteu buleud
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// Ditilik `Duration` ku `f32`.
    /// # Panics
    /// Metoda ieu bakal panic lamun hasilna teu terhingga, négatip atanapi overflows `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // catetan nu alatan rounding kasalahan hasilna rada beda ti 0.859_872_611
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // Catet yén truncation dipaké, henteu buleud
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// Ditilik `Duration` ku `Duration` sarta balik `f64`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// Bagikeun `Duration` ku `Duration` sareng balikkeun `f32`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// Format jumlah titik ngambang di notasi decimal.
        ///
        /// Nomerna dipasihkeun salaku `integer_part` sareng bagian pecahan.
        /// Nilai tina bagian fractional nyaeta `fractional_part / divisor`.
        /// Jadi `integer_part` =3, `fractional_part` =12 jeung `divisor` =100 ngagambarkeun jumlah `3.012`.
        /// nol labuh anu disingkahkeun.
        ///
        /// `divisor` teu kedah diluhur 100_000_000.
        /// Éta ogé kedah kakuatan 10, anu sanésna henteu asup akal.
        /// `fractional_part` boga janten kirang ti `10 * divisor`!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // Encode bagian fraksi kana panyangga samentawis.
            // Buffer ngan kedah nahan 9 elemen, sabab `fractional_part` kedah langkung alit tibatan 10 ^ 9.
            //
            // Buffer na tos dieusian ku '0' digit pikeun mempermudah kode di handap.
            let mut buf = [b'0'; 9];

            // Digit salajengna ditulis dina posisi ieu
            let mut pos = 0;

            // Kami tetep nyerat angka kana panyangga nalika masih aya angka henteu nol sareng kami henteu acan nyerat cukup digit.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // Tulis angka anyar kana panyangga
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // Upami katepatan <9 ditangtoskeun, panginten aya sababaraha sésana sanés digit anu sanés nyerat kana panyangga.
            // Bisi nu urang kudu nedunan rounding mun cocog semantik tina percetakan normal angka floating titik.
            // Najan kitu, urang ukur perlu ngalakukeun pagawean lamun rounding up.
            // Ieu kajadian lamun angka mimiti leuwih sésana nyaéta>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // Bulatkeun nomer anu aya dina panyangga.
                // Kami ngalangkungan buffer ka tukang sareng ngalacak bawa.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // Lamun angka di panyangga anu teu '9', urang ngan kudu increment dinya tur bisa ngeureunkeun lajeng (saprak urang teu boga mawa hiji deui).
                    // Upami teu kitu, urang nangtukeun ka '0' (overflow) tur nuluykeun.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // Upami urang masih gaduh set bit bawa, éta ngandung hartos yén urang netepkeun sadaya panyangga kana '0's sareng kedah naékkeun bagian bilangan bulat.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // Nangtukeun tungtung panyangga anu: lamun precision diatur, urang ngan make saloba digit ti panyangga (capped nepi ka 9).
            // Lamun teu diatur, urang ukur migunakeun sakabéh digit nepi ka panungtungan non-enol hiji.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // Upami urang henteu ngaluarkeun angka pecahan tunggal sareng presisi na henteu diatur kana nilai anu teu nol, kami moal nyitak titik decimal.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // KESELAMATAN: Kami ngan ukur nyerat angka ASCII kana panyangga sareng éta
                // diinisialisasi sareng '0's, janten ngandung UTF8 anu valid.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // Upami pangguna nyungkeun katepatan> 9, urang pad '0's di tungtungna.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // Nyetak tanda '+' ngarah upami dipénta
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}