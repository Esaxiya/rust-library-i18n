use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Antarbeungeut pikeun kaayaan iterator asinkron.
///
/// Ieu aliran utama trait.
/// Kanggo langkung seueur ngeunaan konsép aliran umumna, mangga tingali [module-level documentation].
/// Khususna, anjeun panginten hoyong terang kumaha [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Jinis barang anu dihasilkeun ku aliran.
    type Item;

    /// Coba pikeun narik nilai salajengna tina aliran ieu, ngadaptarkeun tugas ayeuna kanggo hudang upami nilaina teu acan aya, sareng ngawangsulkeun `None` upami aliranna béak.
    ///
    /// # Nilai balik
    ///
    /// Aya sababaraha kamungkinan nilai balikna, masing-masing nunjukkeun kaayaan aliran anu béda:
    ///
    /// - `Poll::Pending` hartosna yén nilai salajengna aliran ieu teu acan siap.Palaksanaan bakal mastikeun yén tugas ayeuna bakal dibéjakeun nalika nilai salajengna tiasa siap.
    ///
    /// - `Poll::Ready(Some(val))` hartosna yén aliran parantos hasil ngahasilkeun nilai, `val`, sareng tiasa ngahasilkeun nilai salajengna dina telepon `poll_next` salajengna.
    ///
    /// - `Poll::Ready(None)` ngandung hartos yén aliran na parantos diakhiri, sareng `poll_next` henteu kedah disebat deui.
    ///
    /// # Panics
    ///
    /// Sakali aliran parantos réngsé (balikkeun `Ready(None)` from `poll_next`), nyauran metode `poll_next` na deui panginten panic, meungpeuk salamina, atanapi nyababkeun masalah anu sanés; `Stream` trait henteu nempatkeun sarat pikeun épék panggero sapertos kitu.
    ///
    /// Nanging, salaku padika `poll_next` henteu ditandaan `unsafe`, aturan biasa Rust diterapkeun: telepon kedah pernah nyababkeun tingkah laku anu teu ditangtoskeun (korupsi mémori, panggunaan fungsi `unsafe` anu salah, atanapi anu sapertosna), henteu paduli kaayaan aliranna.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Balikkeun wates dina panjangna sésa aliran.
    ///
    /// Husus, `size_hint()` mulih a tuple mana unsur kahiji nyaeta handap kabeungkeut, sarta unsur nu kadua nyaeta luhur kabeungkeut.
    ///
    /// Kaduana satengah tina tuple anu balik mangrupa [`Option`]`<`[`usize`] `>`.
    /// A [`None`] didieu hartosna yén boh euweuh dipikawanoh luhur kabeungkeut, atawa luhur kabeungkeut téh leuwih badag batan [`usize`].
    ///
    /// # Catetan palaksanaan
    ///
    /// Éta henteu ditegakeun yén palaksanaan aliran ngahasilkeun jumlah unsur anu dinyatakeun.A stream Buggy bisa ngahasilkeun kirang ti handap kabeungkeut atawa leuwih ti luhur kabeungkeut unsur.
    ///
    /// `size_hint()` ieu utamana dimaksudkeun pikeun dipaké pikeun optimizations kayaning reserving spasi pikeun unsur aliran, tapi teu kudu dipercaya mun misalna, bounds cék ngaleungitkeun di kode unsafe.
    /// Hiji palaksanaan lepat tina `size_hint()` teu kudu ngakibatkeun pelanggaran kaamanan memori.
    ///
    /// Kitu cenah, palaksanaan kudu nyadiakeun estimasi bener, sabab lamun heunteu bakal palanggaran protokol trait urang.
    ///
    /// Palaksanaan standar mulihkeun `(0,` [`Teu aya`]`)`anu leres pikeun aliran naon.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}