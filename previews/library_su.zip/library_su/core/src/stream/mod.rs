//! Iterasi anu teu sinkron.
//!
//! Mun futures aya nilai Asynchronous, teras aliran anu iterators Asynchronous.
//! Upami anjeun parantos mendakan diri anjeun sareng kumpulan anu teu sinkron, sareng diperyogikeun pikeun ngalakukeun operasi dina unsur-unsur koleksi éta, anjeun bakal gancang lumpat kana 'streams'.
//! Aliran téh beurat dipaké dina idiomatic kode Rust Asynchronous, ku kituna urang patut jadi akrab jeung éta.
//!
//! Sateuacan ngajelaskeun langkung seueur, hayu urang ngobrol ngeunaan kumaha modul ieu terstruktur:
//!
//! # Organization
//!
//! modul ieu sakitu legana diayakeun ku tipe:
//!
//! * [Traits] mangrupikeun bagian inti: traits ieu ngahartikeun jenis aliran naon sareng naon anu tiasa dilakukeun ku aranjeunna.Métode traits ieu pantes nempatkeun sababaraha waktos diajar tambahan.
//! * Fungsi nyayogikeun sababaraha cara anu ngabantosan pikeun nyieun sababaraha aliran dasar.
//! * Structs anu mindeng jenis balikna rupa padika dina traits ieu modul urang.Anjeun biasana gé hayang nempo metodeu nu nyiptakeun `struct`, tinimbang `struct` sorangan.
//! Kanggo langkung jéntré ngeunaan kunaon, tingali '[Ngalaksanakeun Aliran](#implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Éta pisan!Hayu urang ngali kana aliran.
//!
//! # Stream
//!
//! Jantung sareng jiwa modul ieu nyaéta [`Stream`] trait.Inti [`Stream`] siga kieu:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Beda sareng `Iterator`, `Stream` ngajantenkeun bedana antara metode [`poll_next`] anu dianggo nalika nerapkeun `Stream`, sareng metode (to-be-implemented) `next` anu dianggo nalika meakeun aliran.
//!
//! Pamakéna `Stream` ngan ukur kedah ngémutan `next`, anu nalika disebat, mulih future anu ngahasilkeun `Option<Stream::Item>`.
//!
//! The future dipulang ku `next` bakal ngahasilkeun `Some(Item)` salami aya elemen, sarta sakaligus aranjeunna geus kabeh geus béak, bakal ngahasilkeun `None` mun nunjukkeun yén Iteration geus réngsé.
//! Mun urang nuju ngantosan di hal Asynchronous pikeun ngabéréskeun, anu future bakal antosan dugi stream teh nyaeta siap ngahasilkeun deui.
//!
//! Aliran individu tiasa milih pikeun neraskeun Iteration, sareng nelepon deui `next` deui atanapi henteu tungtungna ngahasilkeun `Some(Item)` deui dina sababaraha waktos.
//!
//! Definisi lengkep [`Stream`] kalebet sababaraha cara anu sanés ogé, tapi éta mangrupikeun metode standar, diwangun di luhur [`poll_next`], sahingga anjeun kéngingkeun gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ngalaksanakeun Stream
//!
//! Nyiptakeun aliran sorangan ngalibatkeun dua léngkah: nyiptakeun `struct` pikeun nahan kaayaan aliran, sareng teras ngalaksanakeun [`Stream`] pikeun `struct` éta.
//!
//! Hayu urang ngadamel aliran anu namina `Counter` anu diitung tina `1` dugi ka `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Kahiji, struct nu:
//!
//! /// Aliran anu kaitung tina hiji dugi ka lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami hoyong itungan urang mimitian ti hiji, janten hayu urang tambahkeun padika new() pikeun ngabantosan.
//! // Ieu henteu diperyogikeun ketat, tapi langkung merenah.
//! // Catet yén urang ngamimitian `count` dina nol, urang bakal ningali kunaon dina `poll_next()`'s palaksanaan di handap.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Teras, urang nerapkeun `Stream` pikeun `Counter` kami:
//!
//! impl Stream for Counter {
//!     // kami bakal cacah jeung usize
//!     type Item = usize;
//!
//!     // poll_next() nya éta métode déskriptif wungkul diperlukeun
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Increment count urang.Ieu naha urang dimimitian di nol.
//!         self.count += 1;
//!
//!         // Pariksa pikeun ningali naha urang parantos réngsé ngitung atanapi henteu.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Aliran téh *kedul*.Ieu hartosna yén ngan nyieun aliran a henteu _do_ sacara gembleng loba.Nanaon sih kajadian dugi ka nelepon `next`.
//! Ieu kadang mangrupa sumber ngabingungkeun nalika nyieun aliran a solely keur efek samping na.
//! Panyusun bakal ngingetkeun urang ngeunaan kabiasaan sapertos kieu:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;