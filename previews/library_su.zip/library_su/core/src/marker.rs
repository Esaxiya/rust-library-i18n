//! Primitif traits sareng jinis ngalambangkeun sipat dasar tina jinisna.
//!
//! jenis Rust bisa digolongkeun dina sagala rupa cara mangpaat numutkeun sipat intrinsik maranéhanana.
//! klasifikasi ieu digambarkeun salaku traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Jenis nu bisa dibikeun sakuliah wates thread.
///
/// trait ieu otomatis dilaksanakeun nalika kompiler nangtukeun éta luyu.
///
/// Conto jinis non-`Send` nyaéta rujukan-ngitung pointer [`rc::Rc`][`Rc`].
/// Mun dua threads nyobian clone [`Rc`] s eta titik kana nilai rujukan-diitung sarua, maranéhna bisa coba mun update count rujukan dina waktos anu sareng, nu [undefined behavior][ub] sabab [`Rc`] teu make operasi atom.
///
/// Misan na [`sync::Arc`][arc] memang nganggo operasi atom (ngahasilkeun sababaraha overhead) sahingga `Send`.
///
/// Tempo [the Nomicon](../../nomicon/send-and-sync.html) pikeun leuwih rinci.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Jenis kalayan ukuran konstan dipikanyaho dina waktos nyusun.
///
/// Kabéh parameter tipe boga hiji implisit kabeungkeut of `Sized`.Sintaksis `?Sized` khusus tiasa dianggo pikeun ngaleungitkeun wates ieu upami henteu pantes.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // str FooUse(Foo<[i32]>);//error: Ukuran henteu dilaksanakeun pikeun [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Hiji pengecualian mangrupikeun jinis `Self` implisit tina trait.
/// A trait teu boga hiji `Sized` implisit kabeungkeut jadi ieu téh sauyunan jeung [trait obyék] s mana, ku harti, anu trait perlu gawé kalawan sagala implementors mungkin, sahingga bisa jadi ukuran nanaon.
///
///
/// Sanajan Rust bakal ngantep anjeun ngabeungkeut `Sized` ka trait, anjeun moal bisa migunakeun eta pikeun ngabentuk hiji objek trait engké:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // hayu y: &dyn Bar= &Impl;//kasalahan: nu trait `Bar` bisa dilakukeun kana hiji obyék
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // pikeun Default, contona, anu merlukeun `[T]: !Default` jadi evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Jenis anu tiasa "unsized" ka tipe dinamis-ukuran.
///
/// Contona, dina ukuran Asép Sunandar Sunarya tipe `[i8; 2]` implements `Unsize<[i8]>` na `Unsize<dyn fmt::Debug>`.
///
/// Kabéh implementations of `Unsize` anu disadiakeun sacara otomatis ku compiler anu.
///
/// `Unsize` dilaksanakeun pikeun:
///
/// - `[T; N]` nyaéta `Unsize<[T]>`
/// - `T` nyaeta `Unsize<dyn Trait>` nalika `T: Trait`
/// - `Foo<..., T, ...>` nyaeta `Unsize<Foo<..., U, ...>>` lamun:
///   - `T: Unsize<U>`
///   - Anu mangrupakeun struct a
///   - Ngan widang panungtungan of `Foo` ngabogaan tipe ngalibetkeun `T`
///   - `T` teu bagian tina jinis naon widang
///   - `Bar<T>: Unsize<Bar<U>>`, lamun widang panungtungan of `Foo` boga tipe `Bar<T>`
///
/// `Unsize` dipaké babarengan jeung [`ops::CoerceUnsized`] pikeun ngidinan peti "user-defined" kayaning [`Rc`] mun ngandung jenis dinamis-ukuran.
/// Ningali [DST coercion RFC][RFC982] na [the nomicon entry on coercion][nomicon-coerce] pikeun leuwih rinci.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Dibutuhkeun trait pikeun konstanta anu dianggo dina pertandingan pola.
///
/// Sagala jenis anu asalna `PartialEq` otomatis implements trait ieu,*paduli* naha jenis-parameter na nerapkeun `Eq`.
///
/// Mun hiji item `const` ngandung sababaraha jenis anu teu nerapkeun trait ieu, lajeng nu tipe boh (1.) henteu nerapkeun `PartialEq` (nu hartina tetep dina moal nyadiakeun éta métode ngabandingkeun nu generasi kode nganggap disadiakeun), atawa (2.) eta implements *sorangan* versi `PartialEq` (anu urang nganggap teu akur jeung perbandingan struktural-sarua).
///
///
/// Dina boh tina dua skenario di luhur, urang nampik pamakéan of konstan misalna di hiji patandingan pola.
///
/// Tempo oge [structural match RFC][RFC1445], sarta [issue 63438] nu ngamotivasi Migrasi tina rarancang dumasar-atribut jeung trait ieu.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Dibutuhkeun trait pikeun konstanta anu dianggo dina pertandingan pola.
///
/// Sagala jenis anu asalna `Eq` otomatis implements trait ieu,*paduli* naha tipe parameter na nerapkeun `Eq`.
///
/// Ieu Hack digawekeun di sabudeureun watesan di sistem tipe urang.
///
/// # Background
///
/// Kami badé meryogikeun jinis-jinis konst anu dianggo dina pola cocog sareng atribut `#[derive(PartialEq, Eq)]`.
///
/// Di dunya anu langkung idéal, urang tiasa mariksa sarat éta ku ngan ukur mariksa yén jinis anu ditangtoskeun ngalaksanakeun `StructuralPartialEq` trait *sareng*`Eq` trait.
/// Najan kitu, anjeun tiasa gaduh ADTs yen *do*`derive(PartialEq, Eq)`, sarta janten hal anu urang hayang compiler anu nampa, jeung acan tipe konstanta urang gagal pikeun nerapkeun `Eq`.
///
/// Nyaéta, kasus sapertos kieu:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Masalah dina kode di luhur nyaéta `Wrap<fn(&())>` henteu nerapkeun `PartialEq`, atanapi `Eq`, kusabab `kanggo <'a> fn(&'a _)` does not implement those traits.)
///
/// Kituna, urang moal bisa ngandelkeun dipariksa naif pikeun `StructuralPartialEq` tur mere `Eq`.
///
/// Salaku Hack ka tempat gawe di sabudeureun ieu kami nganggo dua traits misah nyuntik ku unggal dua asalna (`#[derive(PartialEq)]` na `#[derive(Eq)]`) tur dipariksa yen duanana aya hadir salaku bagian tina mariksa struktural-cocok.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Jenis anu nilai bisa duplicated saukur ku nyalin bit.
///
/// Sacara standar, variabel bindings gaduh 'mindahkeun semantik.'Istilah sanésna:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` parantos ngalih kana `y`, janten teu tiasa dianggo
///
/// // println ("{: ?}", x)!;//kasalahan: pamakéan nilai pindah
/// ```
///
/// Sanajan kitu, lamun a tipe implements `Copy`, éta gantina boga 'nyalin semantik':
///
/// ```
/// // Urang tiasa nurunkeun palaksanaan `Copy`.
/// // `Clone` oge diperlukeun, sakumaha téh mangrupa supertrait of `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` mangrupakeun salinan `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Éta penting pikeun dicatet yén dina dua conto ieu, hijina bédana téh naha anjeun diwenangkeun aksés `x` sanggeus ngerjakeun teh.
/// Dina tiung, duanana salinan na move bisa ngahasilkeun bit keur disalin dina mémori, najan ieu kadang dioptimalkeun jauh.
///
/// ## Kumaha carana abdi tiasa nerapkeun `Copy`?
///
/// Aya dua cara pikeun nerapkeun `Copy` on tipe anjeun.pangbasajanna nyaéta ngagunakeun `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Anjeun oge bisa nerapkeun `Copy` na `Clone` sacara manual:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Aya bédana leutik antara dua: strategi `derive` ogé bakal nempatkeun hiji `Copy` kabeungkeut kana parameter tipe, nu teu salawasna nu dipikahoyong.
///
/// ## Naon beda antara `Copy` na `Clone`?
///
/// Salinan lumangsung implicitly, contona minangka bagian ti hiji ngerjakeun `y = x`.Paripolah `Copy` teu overloadable;éta salawasna saeutik saarah salinan basajan.
///
/// Kloning mangrupikeun tindakan anu jelas, `x.clone()`.Palaksanaan [`Clone`] bisa nyadiakeun sagala kabiasaan tipe-spésifik perlu jadi gaduh panulisan nilai aman.
/// Contona, palaksanaan [`Clone`] pikeun [`String`] perlu nyalin-mun nunjuk string panyangga di numpuk.
/// A salinan bitwise basajan tina nilai [`String`] saukur bakal nyalin pointer nu, anjog ka bébas ganda handap jalur.
/// Kusabab kitu, [`String`] nyaéta [`Clone`] tapi sanés `Copy`.
///
/// [`Clone`] mangrupakeun supertrait of `Copy`, jadi sagalana nu `Copy` ogé kudu nerapkeun [`Clone`].
/// Mun tipe hiji `Copy` lajeng palaksanaan [`Clone`] na ukur perlu balik `*self` (ningali conto di luhur).
///
/// ## Nalika tipe abdi tiasa `Copy`?
///
/// Jinis tiasa nerapkeun `Copy` upami sadaya komponénna ngalaksanakeun `Copy`.Contona, struct ieu tiasa `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct tiasa `Copy`, sarta [`i32`] nyaeta `Copy`, kituna `Point` téh ngabogaan hak pikeun jadi `Copy`.
/// Sacara jelas, mertimbangkeun
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// The struct `PointList` teu tiasa nerapkeun `Copy`, sabab [`Vec<T>`] teu `Copy`.Mun urang nyobian nurunkeun palaksanaan `Copy`, urang gé meunang kasalahan:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Rujukan dibagi (`&T`) ogé `Copy`, janten hiji jinis tiasa `Copy`, bahkan nalika éta ngagaduhan rujukan anu dibagi tina jinis `T` anu *sanés*`Copy`.
/// Mertimbangkeun struct handap, anu bisa nerapkeun `Copy`, sabab ukur nahan hiji *dibagikeun rujukan* mun urang tipe non-`Copy` `PointList` ti luhur:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Iraha *teu tiasa* jinis kuring janten `Copy`?
///
/// Sababaraha jinis henteu tiasa disalin kalayan aman.Contona, nyalin `&mut T` bakal nyieun hiji rujukan mutable aliased.
/// Nyalin [`String`] bakal nyalin tanggung jawab pikeun ngatur panyangga [`String`] ', ngarah kana dua kali gratis.
///
/// Generalizing kasus dimungkinkeun, sagala jenis ngalaksanakeun [`Drop`] teu kaci `Copy`, sabab urang menata sababaraha sumberdaya sagigireun [`size_of::<T>`] sorangan bait.
///
/// Upami anjeun nyobian ngalaksanakeun `Copy` dina str atanapi enum anu ngandung data non-`Copy`, anjeun bakal ngagaduhan error [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Lamun *kedah* tipe abdi janten `Copy`?
///
/// Sacara umum, upami tipe _can_ anjeun ngalaksanakeun `Copy`, éta kedahna.
/// Terus di pikiran, sanajan, anu ngalaksanakeun `Copy` mangrupa bagian tina API umum tina tipe anjeun.
/// Mun tipe nu bisa jadi non-`Copy` dina future, éta bisa jadi prudent ka ngaleungitkeun palaksanaan `Copy` kiwari, ulah aya parobahan API megatkeun.
///
/// ## Palaksana tambahan
///
/// Sajaba [implementors listed below][impls], jenis handap ogé nerapkeun `Copy`:
///
/// * jenis fungsi item (ie, jenis béda diartikeun pikeun tiap fungsi)
/// * Fungsi pointer (sapertos, `fn() -> i32`)
/// * jenis Asép Sunandar Sunarya, pikeun sakabéh ukuran, upami tipe item ogé implements `Copy` (misalna `[i32; 123456]`)
/// * jenis tuple, upami tiap komponén ogé implements `Copy` (misalna `()`, `(i32, bool)`)
/// * jenis panutupanana, upami aranjeunna candak euweuh nilai tina lingkungan atanapi lamun sakabeh nilai direbut sapertos nerapkeun `Copy` sorangan.
///   Catetan yen variabel direbut ku rujukan dibagikeun salawasna nerapkeun `Copy` (sanajan referent nu henteu), bari variabel direbut ku rujukan mutable pernah nerapkeun `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Hal ieu ngamungkinkeun nyalin jinis anu teu nerapkeun `Copy` kusabab bounds hirupna unsatisfied (nyalin `A<'_>` lamun ukur `A<'static>: Copy` na `A<'_>: Clone`).
// Simkuring gaduh atribut ieu didieu keur ayeuna wungkul lantaran aya rada sababaraha specializations aya dina `Copy` nu geus aya di perpustakaan baku, sarta aya henteu jalan ka aman boga kabiasaan kieu ayeuna.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// macro diturunkeun generating hiji impl tina trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Jenis nu éta aman rujukan dibagikeun antara threads.
///
/// trait ieu otomatis dilaksanakeun nalika kompiler nangtukeun éta luyu.
///
/// Definisi hade nyaeta: a tipe `T` nyaeta [`Sync`] lamun jeung ukur lamun `&T` nyaeta [`Send`].
/// Kalayan kecap séjén, lamun euweuh kamungkinan [undefined behavior][ub] (kaasup ras data) nalika ngalirkeun rujukan `&T` antara threads.
///
/// Sakumaha anu diarepkeun, jenis primitif sapertos [`u8`] sareng [`f64`] sadayana [`Sync`], sareng kitu ogé jinis agrégat saderhana anu ngandungna, sapertos tuples, strukturna sareng enum.
/// conto anu leuwih tina jenis [`Sync`] dasar kaasup jenis "immutable" kawas `&T`, sarta maranéhanana kalayan basajan diwariskeun mutability, kayaning [`Box<T>`][box], [`Vec<T>`][vec] na paling jenis koleksi lianna.
///
/// (Parameter generik kudu jadi [`Sync`] keur wadahna maranéhna pikeun jadi [`Sync`].)
///
/// A konsekuensi rada heran tina harti teh nya eta `&mut T` nyaeta `Sync` (lamun `T` nyaeta `Sync`) sanajan sigana kawas nu bisa nyadiakeun mutasi unsynchronized.
/// trik teh nya eta hiji rujukan mutable tukangeun hiji rujukan dibagikeun (hal ieu `& &mut T`) janten baca-hijina, lamun éta hiji `& &T`.
/// Maka teu aya résiko lomba data.
///
/// Jenis anu teu `Sync` jalma nu mibanda "interior mutability" dina formulir non-thread-tengtrem, kayaning [`Cell`][cell] na [`RefCell`][refcell].
/// jenis ieu ngidinan pikeun mutasi eusi maranéhna malah ngaliwatan hiji immutable, rujukan dibagikeun.
/// Misalna, metode `set` on [`Cell<T>`][cell] nyandak `&self`, janten ngan ukur butuh [`&Cell<T>`][cell] rujukan.
/// Cara na henteu ngalakukeun sinkronisasi, sahingga [`Cell`][cell] moal tiasa `Sync`.
///
/// conto sejen tina hiji jenis non-`Sync` teh pointer rujukan-cacah [`Rc`][rc].
/// Dibikeun referensi [`&Rc<T>`][rc] naon waé, anjeun tiasa ngébréhkeun [`Rc<T>`][rc] énggal, ngarobih jumlah rujukan dina cara anu teu atom.
///
/// Pikeun kasus lamun teu salah kedah thread-aman mutability interior, Rust nyadiakeun [atomic data types], kitu ogé Ngonci eksplisit via [`sync::Mutex`][mutex] na [`sync::RwLock`][rwlock].
/// jenis ieu mastikeun yén sagala mutasi bisa ngabalukarkeun ras data, ku kituna jenis anu `Sync`.
/// Kitu ogé, [`sync::Arc`][arc] nyadiakeun analog thread-aman tina [`Rc`][rc].
///
/// Sagala jenis kalawan mutability interior ogé kedah nganggo wrapper [`cell::UnsafeCell`][unsafecell] sabudeureun value(s) nu bisa mutated ngaliwatan hiji rujukan dibagikeun.
/// Gagal ngalakukeun ieu [undefined behavior][ub].
/// Contona, [`transmute`][transmute]-ing ti `&T` mun `&mut T` téh sah.
///
/// Tingali [the Nomicon][nomicon-send-and-sync] pikeun langkung seueur rinci ngeunaan `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sakali rojongan pikeun nambahkeun catetan di `rustc_on_unimplemented` lemahna di béta, jeung eta geus ngalegaan nepi ka parios naha panutupanana hiji mana dina ranté sarat, manjangkeun salaku (#48534) sapertos:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nol-ukuran tipe dipaké pikeun nandaan hal anu "act like" maranéhna sorangan a `T`.
///
/// Nambahkeun widang `PhantomData<T>` kana tipe Anjeun ngabejaan ka compiler anu tipe anjeun tindakan minangka najan nyimpen ajén tipe `T`, sanajan eta henteu bener.
/// Inpo ieu dipake nalika komputasi sipat kaamanan nu tangtu.
///
/// Pikeun katerangan leuwih lengkep di-jerona cara ngagunakeun `PhantomData<T>`, mangga tingali [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Hiji catetan ghastly 👻👻👻
///
/// Padahal maranéhna duanana mibanda ngaran pikasieuneun, `PhantomData` na 'jenis phantom' nu patali, tapi henteu sarua.A parameter tipe phantom téh cukup ku hiji parameter tipe nu geus pernah dipaké.
/// Dina Rust, ieu mindeng ngabalukarkeun compiler anu ngangluh, sarta solusi anu nambahkeun pamakéan "dummy" ku cara `PhantomData`.
///
/// # Examples
///
/// ## Paraméter hirupna henteu kapake
///
/// Bisa oge paling hal umum pamakéan pikeun `PhantomData` mangrupakeun struct nu boga hiji parameter hirupna henteu kapake, ilaharna saperti bagian tina sababaraha kode unsafe.
/// Salaku conto, ieu mangrupikeun X XXXXXXXXXXXXXXXXXXXXXX XXXXXXXXXXXXX2S XXX XXXX XXXX XXXX XXXX XXXX XXXX XXX X XXX XXXXXXXXX XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX berguruan, didukung ku pabrikan.
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// niat teh nya eta data kaayaan téh ngan valid pikeun hirupna `'a`, jadi `Slice` sakuduna mah outlive `'a`.
/// Nanging, maksud ieu henteu dikedalkeun dina kode, sabab teu aya kagunaan hirupna `'a` sahingga teu jelas data anu dilarapkeunana.
/// Urang bisa ngabenerkeun ku sangkan compiler anu meta *sakumaha lamun* nu struct `Slice` ngandung rujukan hiji `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ieu ogé dina gilirannana meryogikeun anotasi `T: 'a`, nunjukkeun yén naon waé rujukan dina `T` anu valid salami `'a` hirupna.
///
/// Nalika nginisialisasi `Slice` anjeun kantun nyayogikeun nilai `PhantomData` pikeun lapangan `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parameter tipeu anu henteu dianggo
///
/// Kadang-kadang kajadian anjeun gaduh parameter jenis anu henteu dianggo anu nunjukkeun jinis data naon anu "tied", padahal data éta henteu saéstuna aya dina strukturna sorangan.
/// Di handap ieu conto dimana ieu timbul ku [FFI].
/// The kagunaan panganteur asing handles sahiji jenis `*mut ()` ka tingal nilai Rust sahiji tipena béda.
/// Urang lagu jenis Rust maké parameter tipe phantom dina struct `ExternalResource` nu wraps cecekelan a.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Kapamilikan sareng cék serelek
///
/// Nambahkeun hiji widang tipe `PhantomData<T>` nunjukkeun yén jenis anjeun owns data tina tipe `T`.Ieu dina gilirannana ngakibatkeun yén nalika jenis anjeun turun, éta tiasa lungsur hiji atanapi langkung conto tina jinis `T`.
/// Ieu bearing on analisis [drop check] nu Rust kompiler urang.
///
/// Upami struktur anjeun sanés nyatana *gaduh* data jinis `T`, langkung saé nganggo jinis rujukan, sapertos `PhantomData<&'a T>` (ideally) atanapi `PhantomData<*const T>` (upami henteu aya umur anu diterapkeun), supados henteu nunjukkeun kapamilikan.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompiler-internal trait dipaké pikeun nandaan tipe discriminants enum.
///
/// trait ieu sacara otomatis dilaksanakeun pikeun unggal jenis sareng henteu nambihan jaminan kana [`mem::Discriminant`].
/// Éta kabiasaan undefined ** ** mun transmute antara `DiscriminantKind::Discriminant` na `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Jinis discriminant, anu kedah nyugemakeun nu trait bounds diperlukeun ku `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internal trait dipaké pikeun nangtoskeun naha jinisna ngandung `UnsafeCell` naon waé anu aya dina internalna, tapi henteu ngalangkungan indirection.
///
/// Ieu mangaruhan, contona, naha a `static` tina jenis anu ditempatkeun di baca-hijina memori statik atawa memori statik ditulisan.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Jenis nu bisa aman dipindahkeun sanggeus pinned.
///
/// Rust sorangan boga Pamanggih ngeunaan jenis immovable, sarta ngemutan belah (misalna ngaliwatan ngerjakeun atanapi [`mem::replace`]) pikeun salawasna jadi aman.
///
/// Jinis [`Pin`][Pin] dipaké tibatan pikeun nyegah belah ngaliwatan sistem tipe.Pointers `P<T>` dibungkus dina [`Pin<P<T>>`][Pin] wrapper teu bisa dipindahkeun kaluar tina.
/// Tempo dokuméntasi [`pin` module] pikeun émbaran nu langkung lengkep ihwal pinning.
///
/// Ngalaksanakeun éta `Unpin` trait pikeun `T` lifts nu larangan ngeunaan pinning off tipe, nu lajeng ngamungkinkeun pindah `T` kaluar tina [`Pin<P<T>>`][Pin] kalayan fungsi kayaning [`mem::replace`].
///
///
/// `Unpin` teu aya balukarna pisan pikeun data anu teu dicitak.
/// Dina sababaraha hal, [`mem::replace`] happily ngalir data `!Unpin` (gawéna pikeun sagala `&mut T`, teu ngan lamun `T: Unpin`).
/// Najan kitu, anjeun teu bisa maké [`mem::replace`] on data dibungkus jero hiji [`Pin<P<T>>`][Pin] sabab moal bisa meunang ka `&mut T` nu peryogi éta, sarta *yen* téh naon ngajadikeun sistem pakasaban ieu.
///
/// Janten ieu, salaku conto, ngan tiasa dilakukeun dina jinis anu ngalaksanakeun `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Urang peryogi rujukan anu tiasa dirobih pikeun nelepon `mem::replace`.
/// // Urang tiasa kéngingkeun rujukan sapertos kitu ku (implicitly) invoking `Pin::deref_mut`, tapi éta ngan ukur tiasa dilakukeun kusabab `String` ngalaksanakeun `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait ieu otomatis dilaksanakeun pikeun ampir unggal jenis.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// A tipe kamajuan nu teu nerapkeun `Unpin`.
///
/// Mun tipe a ngandung hiji `PhantomPinned`, éta moal nerapkeun `Unpin` sacara standar.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementations of `Copy` pikeun jenis primitif.
///
/// Palaksanaan anu teu tiasa dijelaskeun dina Rust dilaksanakeun di `traits::SelectionContext::copy_clone_conditions()` dina `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// rujukan dibagikeun bisa disalin, tapi rujukan mutable *teu bisa*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}