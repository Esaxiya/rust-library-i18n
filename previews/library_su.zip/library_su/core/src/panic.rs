//! Dukungan Panic dina perpustakaan standar.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Struktur nyayogikeun inpormasi ngeunaan panic.
///
/// `PanicInfo` struktur dialirkeun ka panic hook diatur ku fungsi [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Balikkeun muatan anu aya hubunganana sareng panic.
    ///
    /// Ieu biasana bakal, tapi henteu salawasna, janten `&'static str` atanapi [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Upami makro `panic!` ti `core` crate (sanés ti `std`) dianggo ku senar pormat sareng sababaraha alesan tambahan, mulihkeun yén pesen siap dianggo contona sareng [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Balikkeun inpormasi ngeunaan lokasi anu asalna ti panic, upami sayogi.
    ///
    /// Metoda ieu ayeuna bakal balik deui [`Some`], tapi ieu tiasa robih dina versi future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Upami ieu dirobih janten sakapeung mulang Euweuh,
        // nguruskeun hal éta dina std::panicking::default_hook sareng std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: urang moal tiasa nganggo downcast_ref: :<String>() Ieuh
        // kumargi String henteu sayogi dina piaraan!
        // Payload mangrupikeun String nalika `std::panic!` disebat ku sababaraha alesan, tapi dina hal éta pesen ogé sayogi.
        //

        self.location.fmt(formatter)
    }
}

/// Struktur anu ngandung inpormasi ngeunaan lokasi panic.
///
/// Struktur ieu diciptakeun ku [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Babandingan pikeun sasaruaan sareng mesen dilakukeun dina file, line, teras prioritas kolom.
/// File dibandingkeun salaku senar, sanés `Path`, anu tiasa diduga.
/// Tingali dokuméntasi [`Lokasi: : file`] pikeun langkung seueur diskusi.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Balikkeun sumber sumber anu nelepon tina fungsi ieu.
    /// Upami panelepon fungsi éta nyatakeun maka lokasi telepon na bakal dikembalikan, teras salajengna tumpukan kana panggero anu munggaran dina badan fungsi anu henteu dilacak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Mulihkeun [`Location`] anu disebatna.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Mulihkeun [`Location`] tina jero definisi fungsi ieu.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ngajalankeun fungsi anu teu sami anu sami dina lokasi anu sanés masihan urang hasilna sami
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ngajalankeun fungsi dilacak di lokasi anu béda ngahasilkeun nilai anu béda
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Balikkeun nami file sumber anu asalna panic.
    ///
    /// # `&str`, moal `&Path`
    ///
    /// Ngaran anu balik ngarujuk kana jalur sumber dina sistem nyusun, tapi henteu valid pikeun ngagambarkeun ieu langsung salaku `&Path`.
    /// Kodeu anu disusun tiasa dijalankeun dina sistem anu sanés kalayan palaksanaan `Path` anu béda tibatan sistem anu nyayogikeun kontén na perpustakaan ieu ayeuna henteu ngagaduhan jinis "host path" anu sanés.
    ///
    /// Paripolah anu paling héran lumangsung nalika file "the same" tiasa dihubungi ngalangkungan sababaraha jalur dina sistem modul (biasana nganggo atribut `#[path = "..."]` atanapi anu sami), anu tiasa nyababkeun kode anu sami sareng kode anu sami sareng nilai anu béda tina fungsi ieu.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Nilai ieu henteu cocog pikeun ngalirkeun ka `Path::new` atanapi konstruktor anu sami nalika platform host sareng target platform sanés.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Balikkeun nomer garis ti mana panic asalna.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Mulih kolom ti mana éta panic asalna.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait internal anu dianggo ku libstd pikeun ngalirkeun data tina libstd ka `panic_unwind` sareng runtime panic anu sanés.
/// Sanés dihaja janten stabil deui waé, tong dianggo.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Candak kapamilikan pinuh eusi.
    /// Jenis balikna saleresna `Box<dyn Any + Send>`, tapi kami henteu tiasa nganggo `Box` dina libcore.
    ///
    /// Saatos metoda ieu disebat, ngan ukur sababaraha nilai standar dummy anu tersisa dina `self`.
    /// Nelepon metode ieu dua kali, atanapi nyauran `get` saatos nelepon metoda ieu, mangrupikeun kalepatan.
    ///
    /// Argumenna diinjeum sabab panic runtime (`__rust_start_panic`) ngan ukur ngagaduhan `dyn BoxMeUp` anu diinjeum.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Ukur nginjeum eusina.
    fn get(&mut self) -> &(dyn Any + Send);
}