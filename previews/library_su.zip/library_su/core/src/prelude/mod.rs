//! The libcore prelude
//!
//! Modul ieu dimaksudkeun pikeun pangguna libcore anu henteu numbu ka libstd ogé.
//! Modul ieu diimpor sacara standar nalika `#![no_std]` dianggo dina cara anu sami sareng perpustakaan standar's prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Versi 2015 tina inti prelude.
///
/// Tingali [module-level documentation](self) pikeun langkung seueur.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versi 2018 tina prelude inti.
///
/// Tingali [module-level documentation](self) pikeun langkung seueur.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versi 2021 tina inti prelude.
///
/// Tingali [module-level documentation](self) pikeun langkung seueur.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Tambihkeun deui barang.
}