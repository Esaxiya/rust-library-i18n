//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Titik kode valid pangluhurna `char` tiasa gaduh.
    ///
    /// `char` mangrupikeun [Unicode Scalar Value], anu hartosna éta mangrupikeun [Code Point], tapi ngan ukur anu aya dina kisaran anu tangtu.
    /// `MAX` mangrupikeun titik kode anu paling luhur anu sah [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () dianggo dina Unicode pikeun ngagambarkeun kasalahan dina panyandian.
    ///
    /// Éta tiasa lumangsung, salaku conto, nalika masihan bait UTF-8 anu teu kabentuk janten [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Versi tina [Unicode](http://www.unicode.org/) yén bagian Unicode sahiji metodeu `char` na `str` anu dumasar kana.
    ///
    /// Versi anyar Unicode dileupaskeun sacara rutin sareng teras sadaya metode dina perpustakaan standar gumantung kana Unicode diperbarui.
    /// Ku sabab kitu paripolah sababaraha padika `char` sareng `str` sareng nilai konstanta ieu ngarobah kana waktu.
    /// Ieu *henteu* dianggap parobihan parobihan.
    ///
    /// Skéma panomeran vérsi dipedar dina [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Nyiptakeun iterator ngalangkungan UTF-16 kode kode anu dienkode dina `iter`, ngirangan pengganti anu teu berpasangan salaku `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Dekoder lossy tiasa didapet ku ngagentos hasil `Err` ku karakter gaganti:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Ngarobih `u32` janten `char`.
    ///
    /// Catet yén sadaya `char`s sah [`u32`] s, sareng tiasa dialungkeun ka hiji sareng
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Nanging, tibalikna henteu leres: henteu sadayana sah [`u32`] s valid`char`s.
    /// `from_u32()` bakal balik `None` upami input sanés nilai valid pikeun `char`.
    ///
    /// Kanggo vérsi anu teu aman tina fungsi ieu anu teu maliré kana cék ieu, tingali [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Balik `None` nalika input sanés `char` anu valid:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Ngarobah hiji `u32` ka `char`, ignoring validitas.
    ///
    /// Catet yén sadaya `char`s sah [`u32`] s, sareng tiasa dialungkeun ka hiji sareng
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Nanging, tibalikna henteu leres: henteu sadayana sah [`u32`] s valid`char`s.
    /// `from_u32_unchecked()` bakal malire ieu, sareng ambing matak ka `char`, panginten nyiptakeun anu salah.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman, sabab tiasa ngawangun nilai `char` anu henteu leres.
    ///
    /// Kanggo vérsi anu aman tina fungsi ieu, tingali fungsi [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // KESELAMATAN: kontrak kaamanan kudu dijaga ku anu nelepon.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Ngarobah hiji angka dina radix dibikeun ka `char`.
    ///
    /// 'radix' di dieu kadang disebut ogé 'base'.
    /// Radix dua nunjukkeun nomer binér, radix sapuluh, decimal, sareng radix genep belas, héksadesimal, pikeun masihan sababaraha nilai umum.
    ///
    /// Radices wenang didukung.
    ///
    /// `from_digit()` bakal balik `None` lamun input sanes a angka dina radix dibikeun.
    ///
    /// # Panics
    ///
    /// Panics upami dipasihan radix langkung ageung tibatan 36.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Desimal 11 mangrupikeun angka tunggal dina dasar 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Balikkeun `None` nalika input sanés angka:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ngalirkeun a radix badag, ngabalukarkeun panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Pariksa naha `char` mangrupikeun angka dina radix anu dipasihkeun.
    ///
    /// 'radix' di dieu kadang disebut ogé 'base'.
    /// Radix dua nunjukkeun nomer binér, radix sapuluh, decimal, sareng radix genep belas, héksadesimal, pikeun masihan sababaraha nilai umum.
    ///
    /// Radices wenang didukung.
    ///
    /// Dibandingkeun sareng [`is_numeric()`], fungsi ieu ngan ukur mikawanoh karakter `0-9`, `a-z` sareng `A-Z`.
    ///
    /// 'Digit' dihartikeun ngan ukur karakter ieu:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Pikeun pamahaman anu langkung lengkep ngeunaan 'digit', tingali [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics upami dipasihan radix langkung ageung tibatan 36.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ngalirkeun a radix badag, ngabalukarkeun panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Ngarobah hiji `char` ka angka dina radix dibikeun.
    ///
    /// 'radix' di dieu kadang disebut ogé 'base'.
    /// Radix dua nunjukkeun nomer binér, radix sapuluh, decimal, sareng radix genep belas, héksadesimal, pikeun masihan sababaraha nilai umum.
    ///
    /// Radices wenang didukung.
    ///
    /// 'Digit' dihartikeun ngan ukur karakter ieu:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Mulih `None` lamun `char` henteu tingal angka hiji di radix dibikeun.
    ///
    /// # Panics
    ///
    /// Panics upami dipasihan radix langkung ageung tibatan 36.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ngalirkeun hasil anu henteu digit tina kagagalan:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ngalirkeun a radix badag, ngabalukarkeun panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kode dipisahkeun di dieu pikeun ningkatkeun kagancangan palaksanaan kasus dimana `radix` angger sareng 10 atanapi langkung alit
        //
        let val = if likely(radix <= 10) {
            // Upami sanés angka, nomer anu langkung ageung tibatan radix bakalan didamel.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Balikkeun iterator anu ngahasilkeun hexadecimal Unicode ngewa karakter salaku `char`s.
    ///
    /// Ieu bakal kabur karakter jeung sintaksis Rust tina `\u{NNNNNN}` formulir mana `NNNNNN` nyaéta pawakilan hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // atanapi-ing 1 mastikeun yén pikeun c==0 kode ngitung yén hiji digit kedah dicitak sareng (anu sami) nyingkahan arus balik (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indéks angka héks paling signifikan
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Pérsi ngalegaan `escape_debug` anu sacara opsional ngamungkinkeun kabur tina codepoints Extended Grapheme.
    /// Ieu ngamungkinkeun kami pormat karakter sapertos nonspacing mark langkung saé nalika aranjeunna nuju ngamimitian senar.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Mulih hiji iterator nu ngahasilkeun kodeu ngewa literal tina karakter hiji sakumaha `char`s.
    ///
    /// Ieu bakal luput tina karakter anu sami sareng implementasi `Debug` `str` atanapi `char`.
    ///
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Mulih hiji iterator nu ngahasilkeun kodeu ngewa literal tina karakter hiji sakumaha `char`s.
    ///
    /// standar nu dipilih ku bias arah ngahasilkeun literals anu légal dina rupa-rupa basa, kaasup C++ 11 na basa C-kulawarga sarupa.
    /// Aturan anu pasti nyaéta:
    ///
    /// * Tab kabur sakumaha `\t`.
    /// * enter ieu lolos jadi `\r`.
    /// * feed garis anu lolos jadi `\n`.
    /// * Kutipan tunggal kabur sakumaha `\'`.
    /// * cutatan ganda anu lolos jadi `\"`.
    /// * Backslash kabur sakumaha `\\`.
    /// * Sagala karakter dina 'diprint ASCII' rentang `0x20` .. `0x7e` inklusif teu lolos.
    /// * Sadaya karakter sanésna dibéré kabur heksadesimal Unicode;tingali [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Mulih jumlah bait `char` ieu bakal butuh lamun disandikeun di UTF-8.
    ///
    /// Éta jumlah bait sok antara 1 sareng 4, kalebet.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Jinis `&str` ngajamin yén eusina UTF-8, sahingga urang tiasa ngabandingkeun panjang anu diperyogikeun upami tiap titik kode diwakilan salaku `char` vs dina `&str` sorangan:
    ///
    ///
    /// ```
    /// // sakumaha chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // duanana bisa digambarkeun salaku tilu bait
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // salaku &str, dua ieu disandikeun dina UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // urang tiasa ningali yén aranjeunna nyandak genep bait total ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... sapertos &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Mulih jumlah unit kode 16-bit `char` ieu bakal butuh lamun disandikeun di UTF-16.
    ///
    ///
    /// Tingali dokuméntasi pikeun [`len_utf8()`] pikeun langkung seueur penjelasan ngeunaan konsép ieu.
    /// Fungsi ieu mangrupikeun eunteung, tapi pikeun UTF-16 tibatan UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Nangkodkeun karakter ieu salaku UTF-8 kana bait panyangga anu disayogikeun, sareng teras mulihkeun subslice buffer anu ngandung karakter anu disandikeun.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami panyangga henteu cekap ageung.
    /// A panyangga panjangna opat cukup ageung pikeun dikodekeun `char` naon waé.
    ///
    /// # Examples
    ///
    /// Dina dua conto ieu, 'ß' nyandak dua bait pikeun dikodekeun.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A panyangga éta teuing leutik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` sanés pengganti, janten ieu UTF-8 valid.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ngodekuen karakter ieu salaku UTF-16 kana `u16` panyangga anu disadiakeun, terus mulih ka subslice tina panyangga anu ngandung karakter dikodekeun.
    ///
    ///
    /// # Panics
    ///
    /// Panics upami panyangga henteu cekap ageung.
    /// A panyangga panjang 2 cukup ageung pikeun dikodekeun `char` naon waé.
    ///
    /// # Examples
    ///
    /// Dina dua conto ieu, '𝕊' nyandak dua `u16`s pikeun dikodekeun.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A panyangga éta teuing leutik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Mulih `true` upami `char` ieu ngagaduhan sipat `Alphabetic`.
    ///
    /// `Alphabetic` dijelaskeun dina Bab 4 (Character Properties) tina [Unicode Standard] sareng ditetepkeun dina [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // cinta téh loba hal, tapi teu alphabetic
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Mulih `true` lamun `char` ieu boga sipat `Lowercase`.
    ///
    /// `Lowercase` dijelaskeun dina Bab 4 (Character Properties) tina [Unicode Standard] sareng ditetepkeun dina [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Rupa-rupa skrip sareng tanda baca Cina teu gaduh kasus, sareng kitu:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Mulih `true` upami `char` ieu ngagaduhan sipat `Uppercase`.
    ///
    /// `Uppercase` dijelaskeun dina Bab 4 (Character Properties) tina [Unicode Standard] sareng ditetepkeun dina [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Rupa-rupa skrip sareng tanda baca Cina teu gaduh kasus, sareng kitu:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Mulih `true` upami `char` ieu ngagaduhan sipat `White_Space`.
    ///
    /// `White_Space` dieusian dina [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // rohangan anu teu pegat-pegat
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Mulih `true` lamun `char` ieu satisfies boh [`is_alphabetic()`] atanapi [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Mulih `true` upami `char` ieu ngagaduhan kategori umum pikeun kode kontrol.
    ///
    /// Konci Control (kode titik jeung kategori umum tina `Cc`) anu digambarkeun dina Bab 4 (Aksara Pasipatan) tina [Unicode Standard] sarta dieusian dina [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Mulih `true` lamun `char` ieu boga sipat `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` digambarkeun dina [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] sarta dieusian dina [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Mulih `true` lamun `char` ieu boga salah sahiji kategori umum pikeun nomer.
    ///
    /// Kategori umum pikeun nomer (`Nd` pikeun digit decimal, `Nl` pikeun karakter numerik sapertos huruf, sareng `No` pikeun karakter numerik sanés) anu ditangtoskeun dina [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Mulih hiji iterator nu ngahasilkeun pemetaan aksara leutik tina `char` ieu salaku salah sahiji atawa leuwih
    /// `char`s.
    ///
    /// Upami `char` ieu henteu ngagaduhan pemetaan aksara leutik, iterator ngahasilkeun `char` anu sami.
    ///
    /// Upami `char` ieu ngagaduhan pemetaan aksara alit hiji-ka-hiji anu dipasihkeun ku [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ngahasilkeun `char` éta.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Upami `char` ieu meryogikeun pertimbangan khusus (misal sababaraha `char`s) iterator ngahasilkeun`char` (s) anu dipasihkeun ku [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasi ieu ngalakukeun pemetaan tanpa syarat tanpa tukang ngaput.Nyaéta, konvérsi henteu gumantung tina kontéks sareng basa.
    ///
    /// Dina [Unicode Standard], Bab 4 (Character Properties) ngabahas pemetaan kasus sacara umum sareng Bab 3 (Conformance) ngabahas algoritma standar pikeun konversi hal.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Kadangkala hasilna mangrupa leuwih ti hiji karakter:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karakter anu henteu gaduh hurup ageung boh hurup leutik kana dirina.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Balikkeun iterator anu ngahasilkeun pemetaan aksara gedé `char` ieu salaku hiji atanapi langkung
    /// `char`s.
    ///
    /// Mun `char` ieu teu boga pemetaan uppercase, iterator nu ngahasilkeun `char` sarua.
    ///
    /// Upami `char` ieu ngagaduhan pemetaan hiji-ka-hiji hurup gedé anu dipasihkeun ku [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ngahasilkeun `char` éta.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Upami `char` ieu meryogikeun pertimbangan khusus (misal sababaraha `char`s) iterator ngahasilkeun`char` (s) anu dipasihkeun ku [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasi ieu ngalakukeun pemetaan tanpa syarat tanpa tukang ngaput.Nyaéta, konvérsi henteu gumantung tina kontéks sareng basa.
    ///
    /// Dina [Unicode Standard], Bab 4 (Character Properties) ngabahas pemetaan kasus sacara umum sareng Bab 3 (Conformance) ngabahas algoritma standar pikeun konversi hal.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Kadangkala hasilna mangrupa leuwih ti hiji karakter:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karakter anu henteu gaduh hurup ageung boh hurup leutik kana dirina.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Catetan dina lokal
    ///
    /// Dina Turki, teh sarua 'i' dina basa Latin boga lima bentuk gaganti dua:
    ///
    /// * 'Dotless': Kuring/ı, sakapeung ditulis ï
    /// * 'Dotted': İ/abdi
    ///
    /// Catet yén aksara leutik dina dotted 'i' téh sarua jeung Latin.kituna:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Nilai `upper_i` didieu gumantung kana basa téks: upami urang dina `en-US`, éta kedah `"I"`, tapi upami urang dina `tr_TR`, éta kedah `"İ"`.
    /// `to_uppercase()` henteu nganggap hal ieu, sareng kitu:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// nahan basa.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Pariksa naha niléyna aya dina kisaran ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Ngajadi salinan nilaina dina kasus luhur ASCII na.
    ///
    /// hurup ASCII 'a' mun 'z' anu dipetakeun kana 'A' mun 'Z', tapi hurup non-ASCII anu unchanged.
    ///
    /// Pikeun huruf besar nilai di tempatna, anggo [`make_ascii_uppercase()`].
    ///
    /// Pikeun hurup aksara ASCII salian ti karakter sanés ASCII, anggo [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ngajadi salinan nilaina dina ASCII bisi handapna sami.
    ///
    /// Huruf ASCII 'A' dugi 'Z' dipetakeun ka 'a' dugi 'z', tapi hurup sanés ASCII henteu robih.
    ///
    /// Pikeun ngaleutikan nilai dina tempatna, anggo [`make_ascii_lowercase()`].
    ///
    /// Pikeun ngaleutikan karakter ASCII salian ti karakter sanés ASCII, anggo [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Mariksa yén dua nilai mangrupikeun pertandingan anu teu peka kasus ASCII.
    ///
    /// Sarua jeung `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Ngarobih jinis ieu kana kasus luhur ASCII na sami-sami.
    ///
    /// hurup ASCII 'a' mun 'z' anu dipetakeun kana 'A' mun 'Z', tapi hurup non-ASCII anu unchanged.
    ///
    /// Pikeun balik a nilai uppercased anyar tanpa modifying hiji aya, nganggo [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ngarobih jinis ieu kana titik handap na ASCII anu sami.
    ///
    /// Huruf ASCII 'A' dugi 'Z' dipetakeun ka 'a' dugi 'z', tapi hurup sanés ASCII henteu robih.
    ///
    /// Pikeun balik a nilai lowercased anyar tanpa modifying hiji aya, nganggo [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Pariksa naha niléyna nyaéta karakter abjad ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', atawa
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Pariksa naha nilaina mangrupikeun karakter gedé ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Pariksa naha niléyna karakter leutik ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Cék lamun nilai nu mangrupa karakter ASCII alpanumérik:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', atawa
    /// - U + 0061 'a' ..=U + 007A 'z', atawa
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Pariksa naha niléyna nyaéta angka decimal ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Pariksa naha niléyna mangrupikeun angka héksadesimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', atanapi
    /// - U + 0041 'A' ..=U + 0046 'F', atanapi
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Pariksa naha niléyna nyaéta karakter tanda baca ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, atanapi
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, atanapi
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, atanapi
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Pariksa naha niléyna mangrupikeun karakter grapik ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Pariksa naha niléyna mangrupikeun karakter buleud ASCII:
    /// U + 0020 SPACE, U + 0009 TAB HORIZONTAL, U + 000A LINE FED, U + 000C FORM FEED, atanapi U + 000D CarriAGE Return.
    ///
    /// Rust nganggo WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Aya sababaraha definisi sanés anu seueur dianggo.
    /// Misalna, [the POSIX locale][pct] kalebet U + 000B TAB VERTIKA ogé sadaya karakter di luhur, tapi - tina spésipikasi anu sami pisan- [aturan standar pikeun "field splitting" dina Bourne shell][bfs] ngemutan *ngan* RUANG, TAB HORIZONTAL, sareng LINE FEED salaku rohangan bodas.
    ///
    ///
    /// Upami anjeun nyerat program anu bakal ngolah format file anu aya, parios naon definisi format éta pikeun spasi bodas sateuacan nganggo pungsi ieu.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Cék lamun nilai nu mangrupa karakter kontrol ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, atanapi U + 007F Hapus.
    /// Catet yén kaseueuran karakter buleud ASCII mangrupikeun karakter kontrol, tapi SPACE henteu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Nangkodkeun nilai u32 atah salaku UTF-8 kana bait panyangga anu disayogikeun, teras mulihkeun subslice buffer anu ngandung karakter anu disandikeun.
///
///
/// Teu kawas `char::encode_utf8`, metoda ieu ogé handles codepoints dina rentang surrogate.
/// (Nyiptakeun `char` dina kisaran pengganti nyaéta UB.) Hasilna sah [generalized UTF-8] tapi henteu valid UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics upami panyangga henteu cekap ageung.
/// A panyangga panjangna opat cukup ageung pikeun dikodekeun `char` naon waé.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Nangkodkeun nilai u32 atah salaku UTF-16 kana panyangga `u16` anu disayogikeun, teras mulihkeun subslice buffer anu ngandung karakter anu disandikeun.
///
///
/// Beda sareng `char::encode_utf16`, metoda ieu ogé nanganan codepoints dina kisaran pengganti.
/// (Nyieun `char` dina rentang surrogate nyaeta UB.)
///
/// # Panics
///
/// Panics upami panyangga henteu cekap ageung.
/// A panyangga panjang 2 cukup ageung pikeun dikodekeun `char` naon waé.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // Kaamanan: unggal panangan mariksa naha aya cekap tulisan pikeun ditulis
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ragrag
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Pesawat suplemén janten pengganti.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}