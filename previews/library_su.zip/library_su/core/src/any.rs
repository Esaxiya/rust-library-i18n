//! Modul ieu ngalaksanakeun `Any` trait, anu ngamungkinkeun ngetikkeun dinamis naon waé jinis `'static` ngalangkungan réfléksi runtime.
//!
//! `Any` sorangan bisa dipaké pikeun meunangkeun `TypeId`, sarta boga leuwih fitur lamun dipaké salaku obyek trait.
//! Salaku `&dyn Any` (objék trait anu diinjeum), éta ngagaduhan metode `is` sareng `downcast_ref`, pikeun nguji upami nilai anu dikandung mangrupikeun jinis anu ditangtoskeun, sareng kéngingkeun rujukan kana nilai jero salaku hiji jinis.
//! Salaku `&mut dyn Any`, aya ogé metode `downcast_mut`, pikeun kéngingkeun rujukan anu tiasa dirobih kana nilai jero.
//! `Box<dyn Any>` nambihan metode `downcast`, anu nyobian dikonversi janten `Box<T>`.
//! Tempo dokuméntasi [`Box`] keur leuwih jelasna.
//!
//! Catet yén `&dyn Any` kawates pikeun nguji naha nilai mangrupikeun jinis beton anu parantos ditangtoskeun, sareng henteu tiasa dianggo pikeun nguji naha jinis ngalaksanakeun trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Panunjuk pinter sareng `dyn Any`
//!
//! Hiji sapotong kabiasaan tetep dina pikiran nalika maké `Any` salaku obyek trait, utamana kalayan jenis kawas `Box<dyn Any>` atanapi `Arc<dyn Any>`, éta saukur nelepon `.type_id()` on nilai bakal ngahasilkeun `TypeId` tina *wadahna*, teu kaayaan trait obyék.
//!
//! Ieu bisa dihindari ku jalan ngarobah éta pointer pinter kana `&dyn Any` gantina, anu baris balik obyék `TypeId`.
//! Salaku conto:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Anjeun langkung resep kana ieu:
//! let actual_id = (&*boxed).type_id();
//! // ... ti ieu:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Mertimbangkeun kaayaan dimana urang rék kaluar hiji nilai diliwatan mun hiji fungsi.
//! Kami terang nilai anu nuju kami kerjakeun dina ngalaksanakeun Debug, tapi kami henteu terang jinisna beton.Simkuring hoyong masihan perlakuan husus ka jenis nu tangtu: dina hal ieu percetakan kaluar panjang string peunteun saméméh nilai maranéhanana.
//! Simkuring teu terang jinis beton tina nilai urang wanoh compile, sangkan kudu make cerminan runtime gantina.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fungsi logger pikeun naon waé jinis anu ngalaksanakeun Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Coba pikeun ngarobah nilai urang ka `String`.
//!     // Upami suksés, urang hoyong ngaluarkeun panjang String` ogé nilaina.
//!     // Upami henteu, éta mangrupikeun jinis anu sanés: citak waé henteu nganggo hiasan.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Fungsi ieu hoyong kaluar parameter na kaluar sateuacan ngalaksanakeunnana.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ngalakukeun sababaraha padamelan anu sanés
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Naon trait
///////////////////////////////////////////////////////////////////////////////

/// trait pikeun niru ketak dinamis.
///
/// Kaseueuran jinis nerapkeun `Any`.Nanging, jinis naon waé anu ngandung rujukan anu sanés ``statik` henteu.
/// Ningali [module-level documentation][mod] pikeun leuwih rinci.
///
/// [mod]: crate::any
// trait ieu henteu aman, sanaos kami ngandelkeun khusus tina fungsi `type_id` na impl nyalira dina kode anu henteu aman (mis. `downcast`).Biasana, éta bakal janten masalah, tapi kusabab ngan impl `Any` nyaéta palaksanaan simbut, teu aya kode sanés anu tiasa nerapkeun `Any`.
//
// Kami leres-leres tiasa ngajantenkeun trait ieu henteu aman-éta moal ngakibatkeun rusak, sabab kami ngatur sadaya panerapan-tapi kami milih henteu sabab éta duanana henteu leres-leres diperyogikeun sareng tiasa ngalieurkeun pangguna ngeunaan bédana traits anu teu aman sareng metode anu henteu aman (nyaéta, `type_id` bakal aman ditelepon, tapi kami sigana hoyong nunjukkeun sapertos dina dokuméntasi).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Meunang `TypeId` of `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Métode penyuluhan pikeun objék Sakur trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Mastikeun yén hasil tina misalna, ngagabung thread a bisa dicitak jeung ku kituna dipaké kalawan `unwrap`.
// May antukna moal diperyogikeun deui upami pangiriman tiasa dianggo kalayan upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Mulih `true` upami jinis boxed sami sareng `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Meunang `TypeId` sahiji jenis fungsi ieu instantiated kalawan.
        let t = TypeId::of::<T>();

        // Meunang `TypeId` tina jinis dina trait objék (`self`).
        let concrete = self.type_id();

        // Bandingkeun duanana`TypeId`s dina sasaruaan.
        t == concrete
    }

    /// Mulih sababaraha rujukan kana nilai boxed lamun éta tina tipe `T`, atawa `None` lamun teu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KESELAMATAN: ngan ukur parios naha urang nunjuk kana jinis anu leres, sareng urang tiasa ngandelkeun
            // anu mariksa kaamanan memori sabab kami parantos ngalaksanakeun Naon waé pikeun sadaya jinis;henteu aya impls anu sanés tiasa aya sabab bakal paséa sareng impl kami.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Mulih sababaraha rujukan mutable kana nilai boxed lamun éta tina tipe `T`, atawa `None` lamun teu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KESELAMATAN: ngan ukur parios naha urang nunjuk kana jinis anu leres, sareng urang tiasa ngandelkeun
            // anu mariksa kaamanan memori sabab kami parantos ngalaksanakeun Naon waé pikeun sadaya jinis;henteu aya impls anu sanés tiasa aya sabab bakal paséa sareng impl kami.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Teruskeun kana metode anu ditetepkeun dina jinis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID sareng metode na
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` ngagambarkeun idéntifikasi unik sacara global pikeun hiji jinis.
///
/// Unggal `TypeId` mangrupikeun obyék opak anu henteu ngijinkeun pamariksaan anu aya di jero tapi ngamungkinkeun operasi dasar sapertos kloning, ngabandingkeun, nyetak, sareng nunjukkeun.
///
///
/// A `TypeId` ayeuna ngan sadia pikeun jenis nu ascribe mun `'static` tapi watesan ieu bisa dihapus dina future.
///
/// Sedengkeun `TypeId` ngalaksanakeun `Hash`, `PartialOrd`, sareng `Ord`, perhatoskeun yén hashes sareng mesen bakal bénten-bénten antara Kaluaran Rust.
/// Ati-ati pikeun ngandelkeun aranjeunna dina kode anjeun!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ngembalikan `TypeId` tina jinis fungsi umum ieu parantos diasongkeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Mulih nami hiji tipe salaku nyiksikan senar.
///
/// # Note
///
/// Ieu dimaksudkeun keur pamakéan diagnostik.
/// Eusi jeung format tina string balik pasti teu dieusian, lian ti mahluk pedaran pangalusna-usaha ti tipe éta.
/// Salaku conto, diantara senar anu `type_name::<Option<String>>()` tiasa wangsul nyaéta `"Option<String>"` sareng `"std::option::Option<std::string::String>"`.
///
///
/// string dipulangkeun kudu teu dianggap hiji identifier unik tina jenis anu jadi sababaraha jenis mungkin peta ka ngaran tipe sarua.
/// Nya kitu, teu aya jaminan yén sadaya bagian tina hiji jinis bakal muncul dina senar anu dikembalikan: contona, spésipter hirupna ayeuna teu dieusian.
/// Salaku tambahan, kaluaranana tiasa robih antara vérsi panyusunna.
///
/// Palaksanaan ayeuna ngagunakeun infrastruktur anu sarua saperti diagnostics kompiler na debuginfo, tapi ieu moal dijamin.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Mulih ngaran tipe tina nunjuk-mun nilai salaku nyiksikan senar.
/// Ieu sami sareng `type_name::<T>()`, tapi tiasa dianggo dimana jinis variabelna henteu gampang sayogi.
///
/// # Note
///
/// Ieu dimaksudkeun pikeun panggunaan diagnostik.Eusi jeung format tina string nu pasti teu dieusian, lian ti mahluk pedaran pangalusna-usaha ti tipe éta.
/// Salaku conto, `type_name_of_val::<Option<String>>(None)` tiasa mulih `"Option<String>"` atanapi `"std::option::Option<std::string::String>"`, tapi sanés `"foobar"`.
///
/// Salaku tambahan, kaluaranana tiasa robih antara vérsi panyusunna.
///
/// Fungsi ieu henteu ngabéréskeun objék trait, hartosna yén `type_name_of_val(&7u32 as &dyn Debug)` tiasa mulih `"dyn Debug"`, tapi sanés `"u32"`.
///
/// Nami jenis henteu kedah dianggap pangenal unik tina hiji jenis;
/// sababaraha jenis bisa babagi ngaran tipe sami.
///
/// Palaksanaan ayeuna ngagunakeun infrastruktur anu sarua saperti diagnostics kompiler na debuginfo, tapi ieu moal dijamin.
///
/// # Examples
///
/// Nyitak wilangan bawaan sareng float standar.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}