//! Fungsi dasar pikeun kaayaan mémori.
//!
//! modul ieu ngandung fungsi pikeun querying ukuran na alignment sahiji jenis, initializing jeung manipulasi memori.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Butuh kapamilikan jeung "forgets" ngeunaan nilai nu **tanpa ngajalankeun destructor na**.
///
/// Sagala sumber daya anu dikokolakeun ku nilai, sapertos mémori tumpukan atanapi gagang file, bakal lami-lami dina kaayaan anu teu kahontal.Sanajan kitu, teu ngajamin yén pointers ingetan ieu bakal tetep sah.
///
/// * Mun rék bocor memori, tingali [`Box::leak`].
/// * Mun rék ménta pointer baku pikeun memori, tempo [`Box::into_raw`].
/// * Upami anjeun hoyong miceun nilai anu leres, ngajalankeun penghancur na, tingali [`mem::drop`].
///
/// # Safety
///
/// `forget` henteu ditandaan salaku `unsafe`, sabab jaminan kaamanan Rust henteu kalebet jaminan yén destruktor bakal teras ngajalankeun.
/// Contona, program anu bisa nyieun hiji siklus rujukan maké [`Rc`][rc], atawa nelepon [`process::exit`][exit] mun kaluar tanpa ngajalankeun destructors.
/// Ku kituna, sahingga `mem::forget` tina kode aman teu fundamentally ngarobah jaminan kaamanan Rust urang.
///
/// Kitu cenah, sumber daya bocor sapertos mémori atanapi objék I/O biasana teu pikaresepeun.
/// kedah asalna nepi dina sababaraha kasus pamakéan husus pikeun FFI atawa kode unsafe, tapi malah lajeng, [`ManuallyDrop`] ieu ilaharna pikaresep.
///
/// Kusabab forgetting nilai a nu diwenangkeun, sagala kode `unsafe` anjeun nulis kudu ngidinan pikeun kamungkinan ieu.Anjeun teu bisa balik nilai a jeung nyangka yen panelepon merta bakal ngajalankeun destructor nilai urang.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Pamakéan aman canonical of `mem::forget` nyaeta mun ngagilekkeun destructor hiji nilai urang dilaksanakeun ku `Drop` trait.Salaku conto, ieu bakal ngabocorkeun `File`, nyaéta
/// meunang balik rohangan dicokot ku variabel tapi pernah nutup di sumberdaya Sistim kaayaan:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ieu kapaké nalika kapamilikan sumber dasar anu sateuacanna ditransferkeun ka kode di luar Rust, contona ku ngirimkeun deskriptor file atah kana kode C.
///
/// # Hubungan jeung `ManuallyDrop`
///
/// Bari `mem::forget` ogé bisa dipaké pikeun mindahkeun *memori* kapamilikan, lakukeun sangkan aya kasalahan-rawan.
/// [`ManuallyDrop`] kedah dianggo gantina.Pertimbangkeun, contona, kode ieu:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Ngawangun hiji `String` maké eusi `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // bocor `v` sabab mémori na ayeuna dikelola ku `s`
/// mem::forget(v);  // ERROR, v nyaéta sah teu kudu diliwatan mun fungsi hiji
/// assert_eq!(s, "Az");
/// // `s` sacara implisit murag sareng ingetan na tiasa ngalih.
/// ```
///
/// Aya dua masalah jeung conto di luhur:
///
/// * Upami langkung seueur kode anu ditambihkeun antara pangwangunan `String` sareng pangintunan `mem::forget()`, hiji panic di jerona bakal nyababkeun bebas ganda kusabab mémori anu sami ditangani ku `v` sareng `s`.
/// * Saatos nelepon `v.as_mut_ptr()` na ngalirkeun nu kapamilikan ti data kana `s`, nilai `v` téh sah.
/// Sanajan nilai a ieu ngan dipindahkeun ka `mem::forget` (anu moal mariksa deui), sababaraha jenis gaduh syarat ketat dina nilai maranéhanana yén sangkan aranjeunna sah lamun dangling atawa milik euweuh.
/// Ngagunakeun nilai anu teu valid ku cara naon waé, kaasup ngalirkeunana kana atanapi ngahanca éta tina fungsi, mangrupikeun kabiasaan anu teu ditangtoskeun sareng tiasa ngarusak asumsi anu dilakukeun ku panyusun.
///
/// Ngalihkeun ka `ManuallyDrop` nyingkahan kadua masalah:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sateuacan urang ngaleupas `v` kana bagian atah na, pastikeun teu perlu turun!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ayeuna ngaleupas `v`.Operasi ieu bisa panic, jadi aya teu bisa jadi bocor a.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Tungtungna, ngawangun `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` sacara implisit murag sareng ingetan na tiasa ngalih.
/// ```
///
/// `ManuallyDrop` mantap nyegah dua kali bébas kusabab urang nganonaktifkeun 'v`'s destructor sateuacan ngalakukeun anu sanés.
/// `mem::forget()` henteu ngijinkeun ieu sabab nyéépkeun argumenna, maksa urang nganuhunkeun waé saatos sasari naon waé anu urang peryogikeun ti `v`.
/// Komo upami panic dikenalkeun antara pangwangunan `ManuallyDrop` sareng ngawangun senar (anu henteu tiasa kajantenan dina kode sapertos anu dituduhkeun), éta bakal ngahasilkeun bocor sareng henteu bebas ganda.
/// Kalayan kecap séjén, `ManuallyDrop` lepat dina sisi bocor tibatan kasalahan dina sisi (dobel-) lungsur.
///
/// Ogé, `ManuallyDrop` nyegah urang tina kedah "touch" `v` saatos mindahkeun kapamilikan ka `s`-léngkah ahir berinteraksi sareng `v` pikeun miceun éta tanpa ngajalankeun destruktor na sacara lengkep dihindari.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Sapertos [`forget`], tapi ogé nampi nilai henteu diukur.
///
/// Fungsi ieu ngan ukur dimaksudkeun pikeun dihapus nalika fitur `unsized_locals` janten stabil.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mulih ukuran tina hiji jinis dina bait.
///
/// Langkung khusus, ieu anu diimbangi ku bait antara unsur-unsur anu berturut-turut dina susunan sareng jinis barang kalebet padding alignment.
///
/// Janten, pikeun jenis `T` sareng `n` panjangna, `[T; n]` ngagaduhan ukuran `n * size_of::<T>()`.
///
/// Sacara umum, ukuran hiji jenis henteu stabil pikeun kompilasi, tapi jinis khusus sapertos primitip.
///
/// Tabel ieu masihan ukuran pikeun primitip.
///
/// Ketik |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Salajengna, `usize` sareng `isize` gaduh ukuran anu sami.
///
/// Jenis `*const T`, `&T`, `Box<T>`, `Option<&T>`, sareng `Option<Box<T>>` sadayana ngagaduhan ukuran anu sami.
/// Upami `T` ukuranana, sadaya jinisna gaduh ukuran anu sami sareng `usize`.
///
/// Mutability pointer henteu ngarobah ukuran na.Sapertos kitu, `&T` sareng `&mut T` gaduh ukuran anu sami.
/// Kitu ogé pikeun `*const T` sareng `* mut T`.
///
/// # Ukuran barang `#[repr(C)]`
///
/// Répréséntasi `C` pikeun barang ngagaduhan perenah anu ditetepkeun.
/// Kalayan perenah ieu, ukuran barang ogé stabil salami sadaya bidang ngagaduhan ukuran anu stabil.
///
/// ## Ukuran Struktur
///
/// Pikeun `structs`, ukuran ditangtukeun ku algoritma ieu.
///
/// Pikeun unggal lapangan dina strukturna dipesen ku urutan deklarasi:
///
/// 1. Tambahkeun ukuran lapangan.
/// 2. Buleudkeun ukuran ayeuna kana sababaraha caket lapangan [alignment] lapangan salajengna.
///
/// Tungtungna, buleudkeun ukuranana kana sababaraha anu pang caket na [alignment].
/// Alignment tina strukturna biasana alignment pangageungna pikeun sadaya bidangna;ieu tiasa dirobih ku panggunaan `repr(align(N))`.
///
/// Beda sareng `C`, ukuran ukuran nol henteu dibuleudkeun dugi ka hiji bait ukuranana.
///
/// ## Ukuran Enum
///
/// Enum anu henteu ngagaduhan data salain anu diskriminatif gaduh ukuran anu sami sareng enum C dina platform anu aranjeunna disusun.
///
/// ## Ukuran Serikat
///
/// Ukuran union nyaéta ukuran bidangna anu panggedéna.
///
/// Beda sareng `C`, serikat ukuran teu nol dibuleudkeun dugi ka hiji bait ukuranana.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Sababaraha primitif
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Sababaraha susunan
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer ukuranana sarua
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Ngagunakeun `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ukuran widang kahiji nyaeta 1, jadi nambahan 1 keur ukuran.Ukuranana nyaéta 1.
/// // Jajaran kolom kadua nyaéta 2, janten nambihan 1 kanggo ukuran pikeun padding.Ukuranana 2.
/// // Ukuran widang kadua 2, jadi nambahan 2 mun ukuran nu.Ukuranana 4.
/// // Jajaran kolom katilu nyaéta 1, janten nambihan 0 kana ukuran pikeun padding.Ukuranana 4.
/// // Ukuran widang katilu nyaeta 1, jadi nambahan 1 keur ukuran.Ukuranana 5.
/// // Tungtungna, anu alignment of struct nyaeta 2 (kusabab dina alignment panggedena antarana widang nyaeta 2), sahingga nambahkeun 1 keur ukuran pikeun padding.
/// // Ukuranana 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tatangkalan Tuple nuturkeun aturan anu sami.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Catet yén ngarobih lapangan tiasa nurunkeun ukuranana.
/// // Urang tiasa miceun duanana bait padding ku nempatkeun `third` sateuacan `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ukuran Uni nyaeta ukuran tina widang panggedena.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Mulih ukuran nilai nunjuk-ka bait.
///
/// Ieu biasana sami sareng `size_of::<T>()`.
/// Nanging, nalika `T` * henteu ngagaduhan ukuran anu dipikaterang sacara statik, contona, sapotong [`[T]`][slice] atanapi [trait object], maka `size_of_val` tiasa dianggo pikeun kéngingkeun ukuran anu dinamis-dipikanyaho.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` mangrupikeun rujukan, janten mangrupikeun pointer atah anu valid
    unsafe { intrinsics::size_of_val(val) }
}

/// Mulih ukuran nilai nunjuk-ka bait.
///
/// Ieu biasana sami sareng `size_of::<T>()`.Nanging, nalika `T`*teu ngagaduhan* ukuran anu dipikaterang sacara statik, contona, sapotong [`[T]`][slice] atanapi [trait object], maka `size_of_val_raw` tiasa dianggo pikeun kéngingkeun ukuran anu dinamis-dipikanyaho.
///
/// # Safety
///
/// Fungsi ieu ngan ukur aman pikeun ditelepon upami kaayaan sapertos kieu dicekel:
///
/// - Mun `T` nyaeta `Sized`, fungsi ieu salawasna aman nelepon.
/// - Upami buntut henteu ukuran tina `T` nyaéta:
///     - a [slice], maka panjang buntut keureut kedah integer anu diinisialisasi, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan berukuran statis) kedah pas dina `isize`.
///     - a [trait object], maka bagian anu tiasa ditunjuk tina pointer kedah nunjuk kana vtable valid anu kaala ku paksaan anu teu panceg, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan berukuran statis) kedah pas dina `isize`.
///
///     - hiji (unstable) [extern type], maka fungsi ieu teras-terasan ditelepon, tapi muga-muga panic atanapi sanésna balikkeun nilai anu lepat, sabab tata letak jinis éksternal henteu dipikaterang.
///     Ieu paripolah anu sami sareng [`size_of_val`] dina rujukan kana jinis anu nganggo buntut jinis éksternal.
///     - Upami teu kitu, sacara konservatif teu kénging nelepon fungsi ieu.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: anu nelepon kedah nyayogikeun pointer atah anu sah
    unsafe { intrinsics::size_of_val(val) }
}

/// Mulihkeun [ABI]-pilih alignment minimum pikeun hiji jenis.
///
/// Unggal rujukan kana nilai jinis `T` kedah janten sababaraha tina nomer ieu.
///
/// Ieu mangrupikeun jajaran anu dianggo pikeun bidang strukturna.Éta tiasa langkung alit tibatan alignment anu pikaresep.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mulihkeun [ABI]-panyelarasan minimum anu diperyogikeun tina jinis nilai anu `val` nunjuk.
///
/// Unggal rujukan kana nilai jinis `T` kedah janten sababaraha tina nomer ieu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val mangrupikeun acuan, janten mangrupikeun pointer atah anu sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mulihkeun [ABI]-pilih alignment minimum pikeun hiji jenis.
///
/// Unggal rujukan kana nilai jinis `T` kedah janten sababaraha tina nomer ieu.
///
/// Ieu mangrupikeun jajaran anu dianggo pikeun bidang strukturna.Éta tiasa langkung alit tibatan alignment anu pikaresep.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mulihkeun [ABI]-panyelarasan minimum anu diperyogikeun tina jinis nilai anu `val` nunjuk.
///
/// Unggal rujukan kana nilai jinis `T` kedah janten sababaraha tina nomer ieu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val mangrupikeun acuan, janten mangrupikeun pointer atah anu sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mulihkeun [ABI]-panyelarasan minimum anu diperyogikeun tina jinis nilai anu `val` nunjuk.
///
/// Unggal rujukan kana nilai jinis `T` kedah janten sababaraha tina nomer ieu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Fungsi ieu ngan ukur aman pikeun ditelepon upami kaayaan sapertos kieu dicekel:
///
/// - Mun `T` nyaeta `Sized`, fungsi ieu salawasna aman nelepon.
/// - Upami buntut henteu ukuran tina `T` nyaéta:
///     - a [slice], maka panjang buntut keureut kedah integer anu diinisialisasi, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan berukuran statis) kedah pas dina `isize`.
///     - a [trait object], maka bagian anu tiasa ditunjuk tina pointer kedah nunjuk kana vtable valid anu kaala ku paksaan anu teu panceg, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan berukuran statis) kedah pas dina `isize`.
///
///     - hiji (unstable) [extern type], maka fungsi ieu teras-terasan ditelepon, tapi muga-muga panic atanapi sanésna balikkeun nilai anu lepat, sabab tata letak jinis éksternal henteu dipikaterang.
///     Ieu paripolah anu sami sareng [`align_of_val`] dina rujukan kana jinis anu nganggo buntut jinis éksternal.
///     - Upami teu kitu, sacara konservatif teu kénging nelepon fungsi ieu.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: anu nelepon kedah nyayogikeun pointer atah anu sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mulih `true` upami lungsur nilai jinis `T` perkawis.
///
/// Ieu murni petunjuk optimasi, sareng tiasa dilaksanakeun sacara konservatif:
/// éta tiasa ngabalikeun `true` pikeun jinis-jinis anu henteu leres-leres kedah lungsur.
/// Sapertos kitu sok balik `true` bakal janten palaksanaan anu leres pikeun fungsi ieu.Nanging upami fungsi ieu leres-leres mulihkeun `false`, maka anjeun bakal pasti lungsur `T` moal aya pangaruhna.
///
/// Palaksanaan tingkat handap hal sapertos kumpulan, anu kedah lungsur data na sacara manual, kedah nganggo fungsi ieu pikeun nyingkahan teu kedah nyobian lungsur sadayana konténna nalika ancur.
///
/// Ieu panginten henteu ngahasilkeun bédana dina ngawangun sékrési (dimana gelung anu teu aya efek sampingna gampang dideteksi sareng dileungitkeun), tapi sering janten kameunangan ageung pikeun ngawangun debug.
///
/// Catet yén [`drop_in_place`] parantos ngalaksanakeun cék ieu, janten upami beban padamelan anjeun tiasa dikirangan janten sakedik sauran [`drop_in_place`], nganggo ieu henteu perlu.
/// Hususna dicatet yén anjeun tiasa [`drop_in_place`] sapotong, sareng éta bakal ngalakukeun hiji cek kabutuhan_tunggal pikeun sadaya nilai.
///
/// Jinis sapertos Vec kumargi kitu ngan `drop_in_place(&mut self[..])` tanpa nganggo `needs_drop` sacara jelas.
/// Jinis sapertos [`HashMap`], di sisi anu sanésna, kedah turun nilai hiji-hiji sareng kedah nganggo API ieu.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ieu conto kumaha koleksi tiasa nganggo `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // leupaskeun data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Mulih nilai jinis `T` anu diwakilan ku pola nol-sadaya-enol.
///
/// Ieu ngandung harti yén, contona, bait padding dina `(u8, u16)` henteu merta enol.
///
/// Teu aya jaminan yén pola bait sadaya-enol nunjukkeun nilai anu valid pikeun sababaraha jenis `T`.
/// Salaku conto, pola byte sadaya-nol sanes nilai anu valid pikeun jinis rujukan (`&T`, `&mut T`) sareng petunjuk fungsi.
/// Ngagunakeun `zeroed` pikeun jenis sapertos kitu nyababkeun [undefined behavior][ub] langsung sabab [the Rust compiler assumes][inv] anu aya sok aya nilai anu valid dina variabel anu dianggapna ngainisialisasi.
///
///
/// Ieu pangaruhna sami sareng [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Mangpaat pikeun FFI sakapeung, tapi sacara umum kedah dihindari.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Pamakean leres tina fungsi ieu: ngainisialisasi bilangan bulat sareng nol.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Teu leres* panggunaan fungsi ieu: nginisialisasi rujukan kalayan nol.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Kalakuan teu ditangtoskeun!
/// let _y: fn() = unsafe { mem::zeroed() }; // Sareng deuih!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: anu nelepon kedah ngajamin yén nilai sadaya-nol valid pikeun `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Cek memori-inisialisasi normal Bypass Rust ku pura-pura ngahasilkeun nilai tipe `T`, bari teu ngalakukeun nanaon pisan.
///
/// **Pungsi ieu teu nganggo.** Anggo [`MaybeUninit<T>`] tibatan.
///
/// Alesan panyusutan nyaéta fungsi dasarna henteu tiasa dianggo leres: éta ngagaduhan pangaruh anu sami sareng [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Sakumaha [`assume_init` documentation][assume_init] ngajelaskeun, [the Rust compiler assumes][inv] yén nilai leres-leres dimimitian.
/// Salaku konsekuensi, nelepon mis
/// `mem::uninitialized::<bool>()` ngabalukarkeun kabiasaan teu ditangtoskeun langsung pikeun ngabalikeun `bool` anu henteu pasti `true` atanapi `false`.
/// Goréng, mémori anu leres-leres henteu diminialisasi sapertos naon anu bakal dipulangkeun deui di dieu khusus kusabab panyusunna terang yén éta henteu ngagaduhan nilai anu tetep.
/// Hal ieu ngajantenkeun paripolah anu teu ditangtoskeun ngagaduhan data anu teu dihaja dina variabel sanaos variabel éta ngagaduhan jenis integer.
/// (Perhatoskeun yén aturan ngeunaan wilangan bulat anu henteu acan diméntialisasi henteu acan réngsé, tapi dugi ka éta, disarankan pikeun nyingkahanana.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: anu nelepon kedah ngajamin yén nilai unitialisasi valid pikeun `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Tukeur nilai-nilai dina dua lokasi anu teu tiasa dirobih, tanpa deinitialisasi salah sahiji.
///
/// * Upami anjeun hoyong gentos nganggo nilai standar atanapi dummy, tingali [`take`].
/// * Upami anjeun hoyong gentos ku nilai anu diliwatan, balikkeun nilai anu lami, tingali [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KESELAMATAN: pitunjuk atah parantos diciptakeun tina rujukan mutable aman anu nyugemakeun sadayana
    // konstrain dina `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ngaganti `dest` ku nilai standar `T`, balik nilai `dest` sateuacanna.
///
/// * Upami anjeun hoyong ngagentos nilai dua variabel, tingali [`swap`].
/// * Upami anjeun hoyong ngagentos ku nilai lolos tibatan nilai standar, tingali [`replace`].
///
/// # Examples
///
/// Conto saderhana:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ngamungkinkeun nyandak kapamilikan bidang strom ku ngagentoskeun ku nilai "empty".
/// Tanpa `take` anjeun tiasa ngajalankeun masalah sapertos kieu:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Catet yén `T` henteu kedah nerapkeun [`Clone`], janten bahkan henteu tiasa dikloning sareng ngareset `self.buf`.
/// Tapi `take` tiasa dianggo pikeun ngasingkeun nilai aslina `self.buf` ti `self`, sahingga tiasa dipulangkeun:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Mindahkeun `src` kana `dest` anu dirujuk, balikkeun nilai `dest` sateuacanna.
///
/// Sanés nilai turun.
///
/// * Upami anjeun hoyong ngagentos nilai dua variabel, tingali [`swap`].
/// * Upami anjeun hoyong ngagentos ku nilai standar, tingali [`take`].
///
/// # Examples
///
/// Conto saderhana:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ngamungkinkeun konsumsi bidang strukturna ku ngagentoskeun ku nilai sanés.
/// Tanpa `replace` anjeun tiasa ngajalankeun masalah sapertos kieu:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Catet yén `T` henteu kedah nerapkeun [`Clone`], janten urang bahkan henteu tiasa mengklon `self.buf[i]` pikeun ngahindaran gerakan.
/// Tapi `replace` tiasa dianggo pikeun ngaleungitkeun nilai aslina dina indéks éta ti `self`, ngamungkinkeun pikeun dipulangkeun:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: Urang maca tina `dest` tapi langsung nyerat `src` ka dinya saatosna,
    // sapertos anu nilai lami henteu diduplikasi.
    // Henteu aya anu murag sareng sia didieu tiasa panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispose tina nilai.
///
/// Ieu ngalakukeun éta ku nelepon palaksanaan argumen ngeunaan [`Drop`][drop].
///
/// Ieu sacara efektif henteu ngalakukeun nanaon pikeun jinis anu nerapkeun `Copy`, misal
/// integers.
/// Nilai sapertos disalin sareng _then_ ngalih kana fungsina, janten nilaina tetep saatos nelepon fungsi ieu.
///
///
/// Fungsi ieu sanés sihir;éta sacara harfiah dihartikeun salaku
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Kusabab `_x` dipindahkeun kana fungsina, éta sacara otomatis turun sateuacan fungsina balik.
///
/// [drop]: Drop
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // eksplisit leupaskeun vector
/// ```
///
/// Kusabab [`RefCell`] ngalaksanakeun aturan injeuman nalika runtime, `drop` tiasa ngaleupaskeun [`RefCell`] nginjeum:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ngaleupaskeun pinjaman anu tiasa dirobih dina slot ieu
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer sareng jinis sanés anu ngalaksanakeun [`Copy`] henteu kapangaruhan ku `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // salinan tina `x` geus dipindahkeun tur turun
/// drop(y); // salinan tina `y` geus dipindahkeun tur turun
///
/// println!("x: {}, y: {}", x, y.0); // masih aya
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Napsirkeun `src` ngagaduhan jinis `&U`, teras maca `src` tanpa mindahkeun nilai anu dikandung.
///
/// Pungsi ieu sacara teu aman bakal nganggap pointer `src` valid pikeun [`size_of::<U>`][size_of] bytes ku ngirimkeun `&T` ka `&U` teras maca `&U` (kecuali yén ieu dilakukeun dina cara anu leres sanaos `&U` ngajantenkeun syarat alignment anu langkung ketat tibatan `&T`).
/// Éta ogé bakal aman nyieun salinan tina nilai anu dikandung tibatan pindah kaluar `src`.
///
/// Éta sanés kasalahan kompilasi-waktos upami `T` sareng `U` ngagaduhan ukuran anu bénten-bénten, tapi disarankeun pisan pikeun ngan ukur nyuhungkeun fungsi ieu dimana `T` sareng `U` ngagaduhan ukuran anu sami.Fungsi ieu micu [undefined behavior][ub] upami `U` langkung ageung tibatan `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Nyalin data ti 'foo_array' jeung ngubaran eta salaku 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ngaropéa data disalin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Eusi 'foo_array' kudu geus robah
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Upami U ngagaduhan sarat anu langkung luhur, src panginten tiasa henteu cocog.
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` mangrupikeun rujukan anu dijamin janten sah pikeun dibaca.
        // Nu nelepon kedah ngajamin yén transmutasi saleresna aman.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` mangrupikeun rujukan anu dijamin janten sah pikeun dibaca.
        // Kami nembé parios yén `src as *const U` leres leres.
        // Nu nelepon kedah ngajamin yén transmutasi saleresna aman.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Jinis opak ngalambangkeun diskriminasi enum.
///
/// Tingali fungsi [`discriminant`] dina modul ieu pikeun langkung seueur inpormasi.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Implementasi trait ieu teu tiasa diturunkeun sabab kami henteu hoyong aya wates di T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Mulih nilai anu unik pikeun ngaidentipikasi varian enum dina `v`.
///
/// Upami `T` sanés enum, nelepon fungsi ieu moal ngahasilkeun paripolah anu teu ditangtoskeun, tapi nilai balikna henteu ditangtoskeun.
///
///
/// # Stability
///
/// Anu ngabédakeun varian enum tiasa robih upami definisi enum robih.
/// A diskriminan tina sababaraha varian moal robih antara kompilasi sareng panyusun anu sami.
///
/// # Examples
///
/// Ieu tiasa dianggo pikeun ngabandingkeun enum anu ngangkut data, bari teu ngémutan data anu saleresna:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Mulih jumlah varian dina enum tipe `T`.
///
/// Upami `T` sanés enum, nelepon fungsi ieu moal ngahasilkeun paripolah anu teu ditangtoskeun, tapi nilai balikna henteu ditangtoskeun.
/// Sarua, upami `T` mangrupikeun enum kalayan langkung seueur varian tibatan `usize::MAX` nilai balikna henteu ditangtoskeun.
/// Varian anu henteu didumukan bakal diitung.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}