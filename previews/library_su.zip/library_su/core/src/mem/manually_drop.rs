use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper mun ngahambat kompiler ti otomatis nelepon `destructor T` urang.
/// wrapper Ieu 0-ongkos.
///
/// `ManuallyDrop<T>` nyaeta tunduk kana optimizations perenah sarua salaku `T`.
/// Salaku konsekuensi hiji, éta boga *euweuh pangaruh* dina asumsi yen kompiler ngajadikeun ngeunaan eusina.
/// Contona, initializing a `ManuallyDrop<&mut T>` kalawan [`mem::zeroed`] nyaeta kabiasaan undefined.
/// Lamun perlu nanganan data uninitialized, make [`MaybeUninit<T>`] gantina.
///
/// Catet yén ngaksés nilai dina `ManuallyDrop<T>` aman.
/// hartosna kieu yén hiji `ManuallyDrop<T>` anu eusi geus turun teu kudu kakeunaan ngaliwatan API aman umum.
/// Correspondingly, `ManuallyDrop::drop` nyaeta unsafe.
///
/// # `ManuallyDrop` sareng lungsur urutan.
///
/// Rust boga well-diartikeun [drop order] tina nilai.
/// Pikeun mastikeun yén sawah atanapi warga lokal dijagragkeun dina urutan anu khusus, susun deui deklarasi sapertos urutan serelek implisit anu leres.
///
/// Kasebut nyaéta dimungkinkeun pikeun ngagunakeun `ManuallyDrop` ngadalikeun Urutan serelek, tapi ieu merlukeun kode unsafe na téh hésé do neuleu ku ayana unwinding.
///
///
/// Salaku conto, upami anjeun hoyong mastikeun yén bidang khusus ragrag saatos anu sanésna, jantenkeun lapangan terakhir tina strukturna:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bakal turun sanggeus `children`.
///     // Rust jaminan yén sawah anu turun di urutan of deklarasi.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Bungkus nilai pikeun turun sacara manual.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Anjeun masih bisa aman beroperasi dina nilai nu
    /// assert_eq!(*x, "Hello");
    /// // Tapi `Drop` moal ngajalankeun dieu
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ekstrak nilai tina wadah `ManuallyDrop`.
    ///
    /// Hal ieu ngamungkinkeun nilai ka jadi turun deui.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ieu pakait jeung `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Nyandak nilai tina `ManuallyDrop<T>` wadahna kaluar.
    ///
    /// Metoda ieu utamana dimaksudkeun pikeun pindah kaluar nilai dina serelek.
    /// Gantina make [`ManuallyDrop::drop`] mun sacara manual leupaskeun nilai, Anjeun tiasa make metoda ieu nyandak nilai jeung ngagunakeun eta kumaha dipikahoyong.
    ///
    /// Sabisana, éta leuwih hade migunakeun [`into_inner`][`ManuallyDrop::into_inner`] gantina, anu nyegah duplicating eusi tina `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi ieu sacara semantik ngalirkeun nilai anu dikandung tanpa nyegah panggunaan salajengna, ngantepkeun kaayaan wadah ieu henteu robih.
    /// Éta téh tanggung jawab anjeun pikeun mastikeun yén `ManuallyDrop` ieu henteu dipaké deui.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Kasalametan: urang keur maca ti rujukan, anu dijamin
        // janten valid pikeun berbunyi.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Sacara manual pakait nilai ngandung.Ieu persis sami sareng nelepon [`ptr::drop_in_place`] sareng panunjuk kana nilai anu dikandung.
    /// Salaku misalna, iwal dina nilai ngandung mangrupakeun struct dipakétkeun, destructor bakal disebut di-tempat tanpa gerak nilai, sahingga bisa dipaké pikeun aman leupaskeun data [pinned].
    ///
    /// Upami Anjeun gaduh kapamilikan nilai, Anjeun tiasa make [`ManuallyDrop::into_inner`] gantina.
    ///
    /// # Safety
    ///
    /// Pungsi ieu ngalir ti destructor sahiji nilai ngandung.
    /// Lian ti parobihan anu dirusak ku sorangan, mémori tetep henteu robih, sareng sajauh panyusunna masih gaduh pola-bit anu sah pikeun jinis `T`.
    ///
    ///
    /// Sanajan kitu, nilai "zombie" ieu teu matak kakeunaan kode aman, tur fungsi ieu teu matak disebut leuwih ti sakali.
    /// Ngagunakeun nilai a sanggeus ayeuna teh geus turun, atawa leupaskeun nilai a sababaraha kali, bisa ngabalukarkeun Paripolah Undefined (gumantung naon `drop` manten).
    /// Ieu ilaharna dicegah ku sistem tipe, tapi pamaké tina `ManuallyDrop` kedah uphold pamadegan jaminan tanpa bantuan ti compiler anu.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Kasalametan: kami anu muterna nilai nunjuk kana ku rujukan mutable
        // nu dijamin janten valid keur nyerat.
        // Ieu nepi ka panelepon ka pastikeun yén `slot` henteu turun deui.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}