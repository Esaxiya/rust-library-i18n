use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// A tipe wrapper keur nyusunna instansi uninitialized of `T`.
///
/// # Initialization invarian
///
/// compiler anu, sacara umum, nu nganggap yen variabel a ieu leres initialized nurutkeun sarat tina jenis variabel urang.Contona, variabel sahiji jenis rujukan kudu Blok sarta non-hypothesis.
/// Ieu mangrupa invarian nu kedah *salawasna* jadi upheld, sanajan dina kode unsafe.
/// Salaku konsekuensi a, enol-initializing variabel sahiji jenis rujukan ngabalukarkeun sakedapan [undefined behavior][ub], euweuh urusan naha rujukan nu kantos meunang dipaké pikeun memori aksés:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // kabiasaan undefined!️
/// // Teh sarua kode jeung `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // kabiasaan undefined!️
/// ```
///
/// Ieu dieksploitasi ku kompiler pikeun sagala rupa optimizations, kayaning eliding cék amprok-waktos jeung optimizing perenah `enum`.
///
/// Nya kitu, mémori anu henteu dieritialisasi sadayana tiasa aya kontén, sedengkeun `bool` kedah `true` atanapi `false`.Maka, nyiptakeun `bool` anu henteu dicaturkeun mangrupikeun paripolah anu henteu ditangtoskeun:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // kabiasaan undefined!️
/// // Kodeu anu sami sareng `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // kabiasaan undefined!️
/// ```
///
/// Leuwih ti éta, ingetan uninitialized téh husus dina nu teu boga nilai dibereskeun ("fixed" hartina "it won't change without being written to").Maca sarua uninitialized bait sababaraha kali tiasa masihan hasil béda.
/// Hal ieu ngajadikeun eta undefined kabiasaan mun gaduh data uninitialized dina variabel malah lamun variabel anu boga hiji tipe integer, nu disebutkeun bisa nahan pola bit *naon* dibereskeun:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // kabiasaan undefined!️
/// // Teh sarua kode jeung `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // kabiasaan undefined!️
/// ```
/// (Perhatoskeun yén aturan ngeunaan wilangan bulat anu henteu acan diméntialisasi henteu acan réngsé, tapi dugi ka éta, disarankan pikeun nyingkahanana.)
///
/// Lian ti éta, émut yén kaseueuran jinis gaduh invariants tambahan saluareun ngan saukur dianggap inisialisasi dina tingkat jenis.
/// Contona, hiji `1`-initialized [`Vec<T>`] dianggap initialized (sahandapeun palaksanaan ayeuna; ieu teu mangrupakeun jaminan stabil) sabab hijina sarat compiler anu weruh ngeunaan éta yén pointer data kudu jadi non-hypothesis.
/// Nyieun sarupaning `Vec<T>` henteu ngabalukarkeun *saharita* kabiasaan undefined, tapi bakal ngakibatkeun kabiasaan undefined kalawan paling operasi aman (kaasup muterna eta).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` fungsina pikeun ngaktipkeun kode anu teu aman pikeun ngungkulan data anu teu diinisialisasi.
/// Ieu sinyal ka kompiler nunjukkeun yén data didieu bisa *moal* jadi initialized:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Jieun hiji rujukan eksplisit uninitialized.
/// // compiler anu weruh yén data jero hiji `MaybeUninit<T>` bisa jadi teu sah, sarta ku kituna ieu teu UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Atur deui ka nilai sah.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Nimba data initialized-kieu *ieu ngan diwenangkeun sanggeus* leres initializing `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// compiler anu lajeng weruh kana teu nyieun sagala asumsi lepat atanapi optimizations on kode ieu.
///
/// Anjeun tiasa mikirkeun `MaybeUninit<T>` salaku anu siga `Option<T>` tapi tanpa aya pelacak waktu-ngajalankeun sareng tanpa cek kaamanan.
///
/// ## out-pointers
///
/// Anjeun tiasa make `MaybeUninit<T>` pikeun nerapkeun "out-pointers": tinimbang balik data tina fungsi hiji, lulus hiji pointer kana sababaraha memori (uninitialized) nempatkeun hasilna kana.
/// Ieu tiasa mangpaat nalika hal anu penting pikeun panelepon ka kontrol kumaha mémori hasilna disimpen dina meunang disadiakeun, sarta rék nyingkahan belah perlu.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` henteu leupaskeun eusi lami, anu penting.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ayeuna urang nyaho `v` ieu initialized!Ieu ogé ngajadikeun yakin nu vector bakal leres turun.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing hiji Asép Sunandar Sunarya unsur-demi-unsur
///
/// `MaybeUninit<T>` bisa dipaké pikeun initialize hiji Asép Sunandar Sunarya badag unsur-demi-unsur:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Jieun hiji Asép Sunandar Sunarya uninitialized of `MaybeUninit`.
///     // The `assume_init` geus aman kusabab jinis urang meunangkeun geus initialized dieu mangrupakeun kebat `MaybeUninit`s, nu teu merlukeun initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Muterna a `MaybeUninit` teu nanaon.
///     // Kituna maké ngerjakeun pointer atah tinimbang `ptr::write` henteu ngabalukarkeun nilai uninitialized heubeul bisa turun.
/////
///     // Ogé lamun aya panic salila loop ieu, urang boga bocor memori, tapi euweuh masalah kaamanan memori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Sadayana diinisialisasi.
///     // Transmute nu Asép Sunandar Sunarya ka tipe initialized.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Anjeun oge bisa digawekeun ku arrays sawaréh initialized, nu bisa kapanggih dina datastructures-tingkat low.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Jieun hiji Asép Sunandar Sunarya uninitialized of `MaybeUninit`.
/// // The `assume_init` geus aman kusabab jinis urang meunangkeun geus initialized dieu mangrupakeun kebat `MaybeUninit`s, nu teu merlukeun initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Cacah jumlah elemen kami geus ditugaskeun.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pikeun unggal item dina Asép Sunandar Sunarya dina, neundeun lamun urang disadiakeun eta.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing a struct widang-demi-widang
///
/// Anjeun tiasa make `MaybeUninit<T>`, jeung macro [`std::ptr::addr_of_mut`], mun initialize widang structs ku widang:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing widang `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing widang `list` Lamun aya hiji panic didieu, mangka `String` dina leaks widang `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Sadaya bidangna diinisialisasi, janten urang nyauran `assume_init` kanggo kéngingkeun Foo anu diinisialisasi.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` dijamin gaduh ukuran anu sami, alignment, sareng ABI sakumaha `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Sanajan inget yen tipe a *ngandung* a `MaybeUninit<T>` teu merta tata perenah sarua;Rust henteu di garansi umum yén widang a `Foo<T>` boga urutan sarua salaku `Foo<U>` sanajan `T` na `U` boga ukuran na alignment sarua.
///
/// Saterusna sabab sagala nilai bit anu valid pikeun `MaybeUninit<T>` compiler anu teu bisa nerapkeun non-zero/niche-filling optimizations, berpotensi hasilna dina ukuran badag:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Mun `T` nyaeta FFI-tengtrem, lajeng jadi mangrupakeun `MaybeUninit<T>`.
///
/// Bari `MaybeUninit` nyaeta `#[repr(transparent)]` (nunjukkeun eta jaminan ukuran sarua, alignment, sarta abi salaku `T`), ieu manten *moal* ngaganti salah sahiji caveats saméméhna.
/// `Option<T>` sareng `Option<MaybeUninit<T>>` masih tiasa gaduh ukuran anu bénten-bénten, sareng jinis anu ngandung bidang jinis `T` tiasa ditata (sareng ukuran) benten tibatan upami bidangna `MaybeUninit<T>`.
/// `MaybeUninit` mangrupikeun jinis serikat, sareng `#[repr(transparent)]` dina serikat kerja henteu stabil (tingali [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Kana waktosna, jaminan anu pasti tina `#[repr(transparent)]` dina serikat kerja tiasa mekar, sareng `MaybeUninit` tiasa atanapi henteu tetep `#[repr(transparent)]`.
/// Kitu cenah, `MaybeUninit<T>` bakal *salawasna* garansi yén éta boga ukuran nu sami, alignment, sarta abi salaku `T`;éta ngan éta jalan `MaybeUninit` implements yén garansi mungkin mekar.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang item sangkan bisa mungkus jenis séjén di éta.Ieu dipake keur Generators.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Teu nelepon `T::clone()`, urang moal bisa nyaho lamun urang keur cukup initialized keur éta.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Nyiptakeun `MaybeUninit<T>` anyar initialized jeung nilai dibikeun.
    /// Aman pikeun nelepon [`assume_init`] dina nilai balik fungsi ieu.
    ///
    /// Catet yén muterna `MaybeUninit<T>` moal pernah nelepon kode serelek `T`'s.
    /// Éta téh tanggung jawab anjeun pikeun mastikeun `T` bakal turun lamun eta meunang initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Nyiptakeun `MaybeUninit<T>` anyar dina kaayaan uninitialized.
    ///
    /// Catet yén muterna `MaybeUninit<T>` moal pernah nelepon kode serelek `T`'s.
    /// Éta téh tanggung jawab anjeun pikeun mastikeun `T` bakal turun lamun eta meunang initialized.
    ///
    /// Ningali [type-level documentation][MaybeUninit] pikeun sababaraha conto.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Jieun Asép Sunandar Sunarya anyar `MaybeUninit<T>` item, dina kaayaan uninitialized.
    ///
    /// Note: dina versi future Rust metoda ieu tiasa janten teu perlu nalika susunan sintaksis literal ngamungkinkeun [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Conto di handap ieu teras tiasa nganggo `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Mulih nyiksikan (jigana leutik) data nu ieu sabenerna maca
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KESELAMATAN: `[MaybeUninit<_>; LEN]` anu teu dihaja sah.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Nyiptakeun `MaybeUninit<T>` anyar dina kaayaan uninitialized, kalawan mémori keur ngeusi bait `0`.Eta gumantung kana `T` naha nu geus ngajadikeun pikeun initialization ditangtoskeun.
    ///
    /// Contona, `MaybeUninit<usize>::zeroed()` ieu initialized tapi `MaybeUninit<&'static i32>::zeroed()` henteu sabab rujukan teu kedah janten hypothesis.
    ///
    /// Catet yén muterna `MaybeUninit<T>` moal pernah nelepon kode serelek `T`'s.
    /// Éta téh tanggung jawab anjeun pikeun mastikeun `T` bakal turun lamun eta meunang initialized.
    ///
    /// # Example
    ///
    /// Pamakean leres tina fungsi ieu: ngainisialisasi strukturna sareng nol, dimana sadaya bidang strukturna tiasa nahan pola-bit 0 salaku nilai anu valid.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Salah pamakéan* tina fungsi ieu: nelepon `x.zeroed().assume_init()` nalika `0` teu saeutik-pola valid keur tipe éta:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Jero pasangan a, urang nyieun hiji `NotZero` nu teu boga discriminant sah.
    /// // Ieu kabiasaan undefined.️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` nunjuk kana mémori anu dialokasikan.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Susunan nilai `MaybeUninit<T>`.
    /// Ieu nimpa sagala nilai saméméhna tanpa muterna eta, jadi bisa Kade ulah make ieu dua kali iwal mun hoyong skip ngajalankeun destructor nu.
    ///
    /// Pikeun genah Anjeun, ieu ogé mulih hiji rujukan mutable kana eusi (ayeuna aman initialized) tina `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // Kasalametan: Urang ngan initialized nilai ieu.
        unsafe { self.assume_init_mut() }
    }

    /// Meunangkeun panunjuk kana nilai anu dikandung.
    /// Maca tina pointer ieu atanapi ngarobahna kana rujukan hiji kabiasaan undefined iwal nu `MaybeUninit<T>` ieu initialized.
    /// Nulis ingetan yen pointer ieu (non-transitively) titik mun geus kabiasaan undefined (iwal di jero hiji `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Jieun rujukan kana `MaybeUninit<T>`.Ieu oke sabab kami initialized eta.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Teu leres* pamakean metode ieu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Kami parantos nyiptakeun référénsi ka vector anu teu kaémisialisasi!Ieu kabiasaan undefined.️
    /// ```
    ///
    /// (Aya bewara yen aturan di sabudeureun rujukan pikeun data uninitialized teu diadopsi acan, tapi dugi aranjeunna, éta sasaena ulah aranjeunna.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` sarta `ManuallyDrop` téh duanana `repr(transparent)` sangkan bisa matak pointer nu.
        self as *const _ as *const T
    }

    /// Meunang pointer mutable kana nilai ngandung.
    /// Maca tina pointer ieu atanapi ngarobahna kana rujukan hiji kabiasaan undefined iwal nu `MaybeUninit<T>` ieu initialized.
    ///
    /// # Examples
    ///
    /// pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ngadamel rujukan kana `MaybeUninit<Vec<u32>>`.
    /// // Ieu oke sabab kami initialized eta.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Teu leres* pamakean metode ieu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Kami parantos nyiptakeun référénsi ka vector anu teu kaémisialisasi!Ieu kabiasaan undefined.️
    /// ```
    ///
    /// (Aya bewara yen aturan di sabudeureun rujukan pikeun data uninitialized teu diadopsi acan, tapi dugi aranjeunna, éta sasaena ulah aranjeunna.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` sarta `ManuallyDrop` téh duanana `repr(transparent)` sangkan bisa matak pointer nu.
        self as *mut _ as *mut T
    }

    /// Extracts nilai tina wadahna `MaybeUninit<T>`.Ieu cara hébat pikeun mastikeun yén data bakal meunang turun, sabab `T` anu dihasilkeun téh tunduk kana dawam serelek penanganan.
    ///
    /// # Safety
    ///
    /// Ieu nepi ka panelepon mun garansi yén `MaybeUninit<T>` bener aya dina hiji kaayaan initialized.Nelepon ieu lamun eusi henteu acan pinuh initialized sabab kabiasaan undefined saharita.
    /// [type-level documentation][inv] ngandung langkung seueur inpormasi ngeunaan invariant inisialisasi ieu.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Lian ti éta, émut yén kaseueuran jinis gaduh invariants tambahan saluareun ngan saukur dianggap inisialisasi dina tingkat jenis.
    /// Contona, hiji `1`-initialized [`Vec<T>`] dianggap initialized (sahandapeun palaksanaan ayeuna; ieu teu mangrupakeun jaminan stabil) sabab hijina sarat compiler anu weruh ngeunaan éta yén pointer data kudu jadi non-hypothesis.
    ///
    /// Nyieun sarupaning `Vec<T>` henteu ngabalukarkeun *saharita* kabiasaan undefined, tapi bakal ngakibatkeun kabiasaan undefined kalawan paling operasi aman (kaasup muterna eta).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Teu leres* pamakean metode ieu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` kungsi teu acan initialized acan, jadi garis tukang ieu disababkeun kabiasaan undefined.️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // Kasalametan: nu garansi panelepon must yén `self` ieu initialized.
        // Ieu ogé hartina `self` kedah janten varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Berbunyi nilai tina wadahna `MaybeUninit<T>`.`T` anu dihasilkeun téh tunduk kana dawam serelek penanganan.
    ///
    /// Sabisana, éta leuwih hade migunakeun [`assume_init`] gantina, anu nyegah duplicating eusi tina `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Ieu nepi ka panelepon mun garansi yén `MaybeUninit<T>` bener aya dina hiji kaayaan initialized.Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun kalakuan anu teu ditangtoskeun.
    /// [type-level documentation][inv] ngandung langkung seueur inpormasi ngeunaan invariant inisialisasi ieu.
    ///
    /// Leuwih ti éta, daun ieu salinan tina tukangeun data sarua dina `MaybeUninit<T>`.
    /// Nalika ngagunakeun sababaraha salinan data (ku nelepon `assume_init_read` sababaraha kali, atanapi mimitina nelepon `assume_init_read` teras [`assume_init`]), éta tanggung jawab anjeun pikeun mastikeun yén data éta memang tiasa diduplikasi.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` nyaéta `Copy`, janten urang tiasa maca sababaraha kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplikasi nilai `None` henteu kunanaon, janten urang tiasa maca sababaraha kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Teu leres* pamakean metode ieu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Urang ayeuna dijieun dua salinan tina vector sarua, anjog ka ⚠️ ganda bébas basa aranjeunna duanana meunang turun!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // Kasalametan: nu garansi panelepon must yén `self` ieu initialized.
        // Maca tina `self.as_ptr()` geus aman saprak `self` kudu initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Pakait nilai anu dikandung dina tempat.
    ///
    /// Upami anjeun ngagaduhan kapamilikan `MaybeUninit`, anjeun tiasa nganggo [`assume_init`] tibatan.
    ///
    /// # Safety
    ///
    /// Ieu nepi ka panelepon mun garansi yén `MaybeUninit<T>` bener aya dina hiji kaayaan initialized.Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun kalakuan anu teu ditangtoskeun.
    ///
    /// Di luhureun eta, sadaya invariants tambahan tina tipe `T` kudu puas, sakumaha palaksanaan `Drop` of `T` (atawa anggotana) bisa ngandelkeun ieu.
    /// Contona, hiji `1`-initialized [`Vec<T>`] dianggap initialized (sahandapeun palaksanaan ayeuna; ieu teu mangrupakeun jaminan stabil) sabab hijina sarat compiler anu weruh ngeunaan éta yén pointer data kudu jadi non-hypothesis.
    ///
    /// Nurunkeun `Vec<T>` sapertos kitu bakal nyababkeun kalakuan anu teu ditangtoskeun.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // Kasalametan: nu garansi panelepon must yén `self` ieu initialized na
        // satisfies sadayana invariants of `T`.
        // Muterna nilai dina tempat anu aman lamun éta hal.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Meunangkeun rujukan babarengan kana nilai anu dikandung.
    ///
    /// Ieu tiasa mangpaat lamun urang hayang asup ka `MaybeUninit` nu geus initialized tapi teu boga kapamilikan ti `MaybeUninit` (ngahulag pamakéan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku anu teu ditangtoskeun: terserah anu nelepon pikeun ngajamin yén `MaybeUninit<T>` leres-leres aya dina kaayaan inisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ### pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialisasi `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Kiwari éta `MaybeUninit<_>` kami geus dipikawanoh bisa initialized, éta oke nyieun rujukan dibagikeun ka dinya:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` parantos diinisialisasi.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### * * Salah guna tina metoda ieu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Kami parantos nyiptakeun référénsi ka vector anu teu kaémisialisasi!Ieu kabiasaan undefined.️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialisasi `MaybeUninit` nganggo `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Rujukan pikeun `Cell<bool>` anu henteu dicaturkeun: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // Kasalametan: nu garansi panelepon must yén `self` ieu initialized.
        // Ieu ogé hartina `self` kedah janten varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Meunangkeun rujukan (unique) anu tiasa dirobih kana nilai anu aya.
    ///
    /// Ieu tiasa mangpaat lamun urang hayang asup ka `MaybeUninit` nu geus initialized tapi teu boga kapamilikan ti `MaybeUninit` (ngahulag pamakéan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku anu teu ditangtoskeun: terserah anu nelepon pikeun ngajamin yén `MaybeUninit<T>` leres-leres aya dina kaayaan inisialisasi.
    /// Contona, `.assume_init_mut()` teu bisa dipaké pikeun initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### pamakéan bener tina metoda ieu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialisasikeun *sadayana* bait tina buffer input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialize `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ayeuna urang terang yén `buf` parantos diinisialisasi, janten kami tiasa `.assume_init()`.
    /// // Sanajan kitu, maké `.assume_init()` bisa memicu a `memcpy` tina 2048 bait.
    /// // Pikeun ngeceskeun panyangga kami geus initialized tanpa nyalin eta, urang ningkatkeun `&mut MaybeUninit<[u8; 2048]>` ka `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Kasalametan: `buf` geus initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ayeuna urang tiasa nganggo `buf` salaku nyiksikan normal:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### * * Salah guna tina metoda ieu:
    ///
    /// Anjeun teu tiasa maké `.assume_init_mut()` mun initialize nilai a:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kami geus dijieun rujukan (mutable) ka `bool` uninitialized!
    ///     // Ieu kabiasaan undefined.️
    /// }
    /// ```
    ///
    /// Contona, Anjeun tiasa teu [`Read`] kana hiji panyangga uninitialized:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) rujukan dina ingetan uninitialized!
    ///                             // Ieu kalakuan teu ditangtoskeun.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Anjeun atawa bisa migunakeun aksés sawah langsung ulah widang-demi-widang bertahap initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) rujukan dina ingetan uninitialized!
    ///                  // Ieu kalakuan teu ditangtoskeun.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) rujukan dina ingetan uninitialized!
    ///                  // Ieu kalakuan teu ditangtoskeun.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ayeuna urang ngandelkeun di luhur keur lepat, misalna, urang boga rujukan pikeun data uninitialized (misalna, dina `libcore/fmt/float.rs`).
    // Urang kudu nyieun kaputusan final ngeunaan aturan saméméh stabilisasi.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // Kasalametan: nu garansi panelepon must yén `self` ieu initialized.
        // Ieu ogé hartina `self` kedah janten varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extracts nilai tina hiji Asép Sunandar Sunarya ti peti `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Éta dugi ka anu nelepon pikeun ngajamin yén sadaya elemen tina susunan dina kaayaan inisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Kaamanan: Ayeuna aman nalika kami ngaasinisikeun sadaya unsur
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Nu nelepon ngajamin yén sadaya elemen tina larik diinisialisasi
        // * `MaybeUninit<T>` sareng T dijamin ngagaduhan perenah anu sami
        // * MaybeUnint teu lungsur, jadi aya euweuh ganda-frees Jeung sahingga artos geus aman
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Anggap sadaya elemen diinisialisasi, kéngingkeun sapotong kana éta unsur.
    ///
    /// # Safety
    ///
    /// Ieu nepi ka panelepon ka ngajamin yén elemen `MaybeUninit<T>` bener aya dina kaayaan initialized.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun kalakuan anu teu ditangtoskeun.
    ///
    /// Tempo [`assume_init_ref`] pikeun leuwih rinci tur conto.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: tuang keureutan ka `*const [T]` aman kumargi anu nelepon ngajamin éta
        // `slice` nyaeta initialized, and`MaybeUninit` dijamin mun gaduh tata perenah sarua salaku `T`.
        // The pointer diala téh sah saprak dinya nujul kana memori milik `slice` nu rujukan hiji sahingga dijamin janten valid pikeun berbunyi.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Anggap sakabeh elemen anu initialized, meunang nyiksikan mutable ka aranjeunna.
    ///
    /// # Safety
    ///
    /// Ieu nepi ka panelepon ka ngajamin yén elemen `MaybeUninit<T>` bener aya dina kaayaan initialized.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun kalakuan anu teu ditangtoskeun.
    ///
    /// Tempo [`assume_init_mut`] pikeun leuwih rinci tur conto.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Kasalametan: sarupa catetan kaamanan pikeun `slice_get_ref`, tapi urang boga
        // rujukan mutable anu ogé dijamin janten valid keur nyerat.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Meunang pointer kana unsur mimiti Asép Sunandar Sunarya dina.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Meunangkeun petunjuk anu tiasa dirobih kana unsur mimiti Asép Sunandar Sunarya.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Salinan unsur tina `src` mun `this`, balik a rujukan mutable kana eusi kiwari initalized of `this`.
    ///
    /// Mun `T` henteu nerapkeun `Copy`, make [`write_slice_cloned`]
    ///
    /// Ieu sarupa [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami dua keureut gaduh panjang anu bénten.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: urang nembé nyalin sadaya unsur len kana kapasitas luang
    /// // unsur src.len() mimiti vec anu valid ayeuna.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] sareng&[MaybeUninit<T>] gaduh tata perenah anu sami
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // Kasalametan: elemen Sah kakarék geus disalin kana `this` kitu mangka initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klon unsur ti `src` dugi ka `this`, mulihkeun référénsi anu tiasa dirobih kana eusi `this` anu ayeuna diinitalisasi.
    /// Sagala elemen geus initalized moal turun.
    ///
    /// Mun `T` implements `Copy`, pamakéan [`write_slice`]
    ///
    /// Ieu sarupa [`slice::clone_from_slice`] tapi henteu lungsur elemen aya.
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami dua keureut gaduh panjang anu bénten, atanapi upami palaksanaan `Clone` panics.
    ///
    /// Upami aya panic, elemen anu parantos diklon bakal turun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Kasalametan: kami geus ngan diklon sakabéh unsur Ilen kana kapasitas cadang
    /// // unsur src.len() mimiti vec anu valid ayeuna.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // kawas copy_from_slice ieu teu nelepon clone_from_slice dina nyiksikan ieu kusabab `MaybeUninit<T: Clone>` henteu nerapkeun Klon.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KESELAMATAN: keureutan atah ieu ngan ukur ngandung objék inisialisasi
                // éta naha, mangka diwenangkeun leupaskeun eta.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Urang kedah jelas-jelas nyiksikan aranjeunna kana panjang anu sami
        // pikeun bounds mariksa janten elided, sareng optimizer bakal ngahasilkeun memcpy pikeun kasus anu saderhana (contona T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // hansip anu diperlukeun b/c panic tiasa lumangsung salami clone a
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // Kasalametan: elemen Sah kakarék geus ditulis kana `this` kitu mangka initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}