//! Dukungan Panic pikeun libcore
//!
//! Perpustakaan inti henteu tiasa ngahartikeun panik, tapi éta *nyatakeun* panik.
//! Ieu ngandung harti yén fungsi dina jeroeun libcore diijinkeun ka panic, tapi pikeun janten gunana crate hulu kedah ngartikeun panik pikeun dipaké pikeun pornografi.
//! Antarbeungeut ayeuna pikeun panik nyaéta:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definisi ieu ngamungkinkeun panik kalayan pesen umum naon waé, tapi henteu kénging gagal ku nilai `Box<Any>`.
//! (`PanicInfo` ngan ukur ngandung `&(dyn Any + Send)`, anu ku kami dieusian nilai dummy dina `PanicInfo: : internal_constructor`.) Alesan pikeun ieu nyaéta yén pornografi henteu kéngingkeun alokasi.
//!
//!
//! Modul ieu ngandung sababaraha fungsi panik anu sanés, tapi ieu ngan ukur barang anu diperyogikeun pikeun panyusunna.Sadayana panics dialihkeun ngaliwatan fungsi anu hiji ieu.
//! Simbol anu nyata dinyatakeun ngalangkungan atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Palaksanaan dasar makro `panic!` libcore nalika teu nganggo pormat.
#[cold]
// henteu kantos ngajantenkeun kacuali panic_im Mediate_abort pikeun nyingkahan kembung kode dina situs panggero sabisa-bisa
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // diperyogikeun ku codegen pikeun panic dina overflow sareng terminator `Assert` MIR anu sanés
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Anggo Arguments::new_v1 tibatan format_args! ("{}", Expr) pikeun berpotensi ngirangan ukuran overhead.
    // Format_args na!makro nganggo str's Display trait pikeun nulis expr, anu nyauran Formatter::pad, anu kedah nampung string truncation sareng padding (sanaos henteu dianggo di dieu).
    //
    // Ngagunakeun Arguments::new_v1 tiasa ngijinkeun kompiler pikeun ngaluarkeun Formatter::pad tina binér kaluaran, ngahémat dugi ka sababaraha kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // diperyogikeun pikeun panics anu dievaluasi kon
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // diperyogikeun ku codegen pikeun panic dina aksés OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Palaksanaan dasar makro `panic!` libcore nalika pormat dianggo.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // CATETAN Fungsi ieu henteu pernah ngalangkungan wates FFI;éta nyaéta panggero Rust-to-Rust anu bakal direngsekeun kana fungsi `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` didefinisikeun dina kode Rust anu aman sahingga aman kanggo nelepon.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fungsi internal pikeun `assert_eq!` sareng `assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}