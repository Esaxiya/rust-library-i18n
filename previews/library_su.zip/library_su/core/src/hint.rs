#![stable(feature = "core_hint", since = "1.27.0")]

//! Pitunjuk pikeun panyusun anu mangaruhan kumaha kode kedah dipancarkan atanapi dioptimalkeun.
//! Pitunjuk tiasa nyusun waktos atanapi runtime.

use crate::intrinsics;

/// Ngabéjaan anu nyusun yén titik ieu dina kode henteu kahontal, sahingga pangoptimalan salajengna.
///
/// # Safety
///
/// Ngahontal fungsi ieu lengkep *kabiasaan teu ditangtoskeun*(UB).Dina sababaraha hal, compiler anu nganggap yen sakabeh UB pernah kudu lumangsung, sarta ku kituna bakal ngaleungitkeun sagala dahan nu jangkauan ka panggero pikeun `unreachable_unchecked()`.
///
/// Sapertos sadaya conto UB, upami asumsi ieu tétéla lepat, nyaéta, panggero `unreachable_unchecked()` saleresna tiasa kahontal di antara sadaya kamungkinan aliran pangendali, panyusunna bakal nerapkeun strategi optimalisasi anu salah, sareng bahkan kadang-kadang ngarusak kode anu sigana teu aya hubunganana, ngabalukarkeun mun-debug masalah.
///
///
/// Paké fungsi ieu ngan lamun anjeun bisa ngabuktikeun yén kode nu moal nelepon eta.
/// Upami teu kitu, nganggap ngagunakeun makro [`unreachable!`], nu teu ngijinan optimizations tapi bakal panic lamun dibales.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` sok positip (henteu nol), ku sabab kitu `checked_div` moal balik deui `None`.
/////
///     // Maka, anu sanésna branch henteu kahontal.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: kontrak kaamanan pikeun `intrinsics::unreachable` kedah
    // dijaga ku anu nelepon.
    unsafe { intrinsics::unreachable() }
}

/// Ngaluarkeun instruksi mesin pikeun sinyal prosésor yén éta ngajalankeun dina spin-loop sibuk-tunggu ("spin lock").
///
/// Kana nampi sinyal spin-loop prosesor tiasa ngaoptimalkeun tingkah polahna ku, contona, hemat daya atanapi pindah hyper-threads.
///
/// Fungsi ieu béda sareng [`thread::yield_now`] anu langsung ngahasilkeun panyatur sistem, sedengkeun `spin_loop` henteu berinteraksi sareng sistem operasi.
///
/// Kasus panggunaan umum pikeun `spin_loop` nyaéta ngalaksanakeun puteran optimis anu kabates dina loop CAS dina primitip sinkronisasi.
/// Pikeun ngahindarkeun masalah sapertos pembalikan prioritas, disarankeun pisan yén puteran puteran diakhiri saatos jumlah iterasi anu terbatas sareng syscall blok anu cocog dilakukeun.
///
///
/// **Catetan**: Dina platform anu henteu ngadukung nampi petunjuk puteran-puteran fungsi ieu henteu ngalakukeun nanaon pisan.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Nilai atom anu dibagi anu dianggo ku utas pikeun koordinat
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Dina thread tukang urang tungtungna bakal netepkeun nilaina
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Ngalakukeun sababaraha pagawean, teras jieun nilai nu hirup
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Balik kana utas kami ayeuna, kami ngantosan nilaina tiasa disetél
/// while !live.load(Ordering::Acquire) {
///     // The spin loop mangrupakeun hint kana CPU anu urang nuju ngantosan, tapi sigana teu pisan lila
/////
///     hint::spin_loop();
/// }
///
/// // Nilai ayeuna diatur
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAFETY: `cfg` attr mastikeun yén urang ngan ukur ngajalankeun ieu dina target x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // Kasalametan: attr nu `cfg` ensures yén urang ngan ngaéksekusi ieu dina target x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // Kasalametan: attr nu `cfg` ensures yén urang ngan ngaéksekusi ieu dina target aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: `cfg` atr mastikeun yén urang ngan ukur ngajalankeun ieu dina target panangan
            // kalayan rojongan pikeun fitur v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Hiji fungsi idéntitas nu *__ petunjuk __* mun compiler anu jadi maximally pesimis ngeunaan naon bisa ngalakukeun `black_box`.
///
/// Béda sareng [`std::convert::identity`], panyusun Rust didorong nganggap yén `black_box` tiasa nganggo `dummy` ku cara anu sah anu dimungkinkeun yén kode Rust diidinan tanpa ngenalkeun kabiasaan anu teu ditangtoskeun dina kode nélépon.
///
/// Pasipatan ieu ngajantenkeun `black_box` kapaké pikeun kode panulisan anu dihoyongkeun sababaraha optimasi, sapertos tolok ukur.
///
/// Catet Nanging, yén `black_box` ngan ukur (sareng ngan ukur tiasa) disayogikeun dina dasar "best-effort".Jauh mana éta tiasa ngahalangan pangoptimalan tiasa bénten-bénten gumantung kana platform sareng kode-gen backend anu dianggo.
/// Program henteu tiasa ngandelkeun `black_box` pikeun *leresna* ku cara naon waé.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Urang kudu "use" argumen sababaraha cara LLVM tiasa teu introspect, sarta dina target nu ngarojong eta urang ilaharna bisa ngungkit inline assembly ngalakonan ieu.
    // interpretasi LLVM ngeunaan inline assembly éta éta, ogé, hiji kotak hideung.
    // Ieu sanés palaksanaan anu paling ageung kumargi éta sigana nganoptimikeun langkung seueur tibatan anu dipikahoyong, tapi éta lumayan cukup.
    //
    //

    #[cfg(not(miri))] // Ieu mah sakadar hint hiji, ku kituna rupa mun skip di Miri.
    // KESELAMATAN: gempungan inline mangrupikeun no-op.
    unsafe {
        // FIXME: teu bisa make `asm!` sabab henteu ngarojong MIPS jeung arsitéktur lianna.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}