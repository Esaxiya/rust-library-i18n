//! Traits pikeun konvérsi antara jinisna.
//!
//! The traits dina modul ieu nyadiakeun cara pikeun ngarobah ti hiji jenis kana jenis séjén.
//! Unggal trait ngagaduhan tujuan béda:
//!
//! - Ngalaksanakeun [`AsRef`] trait pikeun konversi rujukan-rujukan anu murah
//! - Ngalaksanakeun [`AsMut`] trait pikeun konvérsi mutable-to-mutable anu murah
//! - Ngalaksanakeun [`From`] trait pikeun consuming conversions nilai-to-nilai
//! - Ngalaksanakeun [`Into`] trait pikeun ngonsumsi konvérsi nilai-ka-nilai kana jinis-jinis diluar crate ayeuna
//! - [`TryFrom`] sareng [`TryInto`] traits kalakuanana sapertos [`From`] sareng [`Into`], tapi kedah dilaksanakeun nalika konvérsina tiasa gagal.
//!
//! traits dina modul ieu sering dianggo salaku trait bounds kanggo fungsi generik sapertos alesan anu ngadukung sababaraha jinis didukung.Tingali dokuméntasi unggal trait contona.
//!
//! Salaku panulis perpustakaan, anjeun kedah langkung milih nerapkeun [`From<T>`][`From`] atanapi [`TryFrom<T>`][`TryFrom`] tinimbang [`Into<U>`][`Into`] atanapi [`TryInto<U>`][`TryInto`], sabab [`From`] sareng [`TryFrom`] nyayogikeun kalenturan anu langkung ageung sareng nawiskeun palaksanaan [`Into`] atanapi [`TryInto`] gratis, berkat palaksanaan simbut dina perpustakaan standar.
//! Nalika nargétkeun vérsi sateuacan Rust 1.41, panginten kedah nerapkeun [`Into`] atanapi [`TryInto`] langsung nalika ngarobah kana jinis diluar crate ayeuna.
//!
//! # Palaksanaan Generik
//!
//! - [`AsRef`] sareng [`AsMut`] auto-dereferensi upami jinis jero mangrupikeun rujukan
//! - [`Ti`]`<U>pikeun T` ngakibatkeun [`Kana Kana]]`</u><T><U>pikeun U`</u>
//! - [`TryFrom`]`<U>pikeun T` nyirikeun [`TryInto`]`</u><T><U>pikeun U`</u>
//! - [`From`] sareng [`Into`] réaktif, anu hartosna yén sadaya jinis tiasa `into` nyalira sareng `from` nyalira
//!
//! Tingali unggal trait pikeun conto panggunaan.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fungsi idéntitas.
///
/// Dua hal anu penting pikeun catetan ngeunaan fungsi ieu:
///
/// - Teu salawasna sarua jeung nu panutupanana kawas `|x| x`, saprak panutupanana nu bisa maksa `x` kana tipe béda.
///
/// - Éta mindahkeun input `x` diliwatan kana fungsina.
///
/// Bari eta bisa sigana aneh mun boga fungsi anu ngan mulih deui input, aya sababaraha kagunaan metot.
///
///
/// # Examples
///
/// Ngagunakeun `identity` mun becus tina sekuen sejen, menarik, fungsi:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Hayu urang pretend anu nambahkeun hiji mangrupa fungsi metot.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Ngagunakeun `identity` salaku kasus dasar "do nothing" dina kaayaan:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ngalakukeun hal anu langkung menarik ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Ngagunakeun `identity` pikeun ngajaga `Some` varian tina hiji iterator `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Dipaké pikeun ngalakukeun konvérsi rujukan-ka-rujukan anu murah.
///
/// trait ieu sami sareng [`AsMut`] anu dianggo pikeun ngarobih antara rujukan anu tiasa dirobih.
/// Upami anjeun kedah ngalakukeun konversi anu langkung saé langkung saé nerapkeun [`From`] kalayan tipe `&T` atanapi nyerat fungsi khusus.
///
/// `AsRef` boga signature sarua salaku [`Borrow`] tapi [`Borrow`] mah béda di sababaraha aspék:
///
/// - Beda sareng `AsRef`, [`Borrow`] ngagaduhan simbut pikeun `T` naon waé, sareng tiasa dianggo pikeun nampi rujukan atanapi nilai.
/// - [`Borrow`] ogé merlukeun [`Hash`], [`Eq`] na [`Ord`] keur nilai injeuman anu sarua jeung pamadegan nu nilai dipiboga.
/// Kusabab kitu, upami anjeun hoyong nginjeum ngan hiji bidang tina strat anjeun tiasa ngalaksanakeun `AsRef`, tapi sanés [`Borrow`].
///
/// **Note: trait teu kedah gagal **.Mun artos tiasa gagal, make metoda dedicated nu mulih hiji [`Option<T>`] atawa [`Result<T, E>`].
///
/// # Palaksanaan Generik
///
/// - `AsRef` otomatis-dereferences lamun tipe jero nyaéta rujukan atawa rujukan mutable (misalna: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ku ngagunakeun trait bounds bisa nampa alesan tina tipena béda salami maranéhna bisa dirobah kana tipe husus `T`.
///
/// Salaku conto: Ku nyiptakeun fungsi umum anu nyandak `AsRef<str>` kami nganyatakeun yén urang hoyong nampi sadaya rujukan anu tiasa dirobih janten [`&str`] salaku argumen.
/// Kusabab duanana [`String`] na [`&str`] nerapkeun `AsRef<str>` bisa nampa duanana sakumaha argumen input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ngalaksanakeun artos.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Dipaké pikeun ngalakukeun konvérsi révisi anu mutable-to-mutable anu murah.
///
/// trait Ieu sarupa [`AsRef`] tapi dipaké pikeun ngarobah antara rujukan mutable.
/// Upami anjeun kedah ngalakukeun konversi anu langkung saé langkung saé nerapkeun [`From`] kalayan tipe `&mut T` atanapi nyerat fungsi khusus.
///
/// **Note: trait teu kedah gagal **.Mun artos tiasa gagal, make metoda dedicated nu mulih hiji [`Option<T>`] atawa [`Result<T, E>`].
///
/// # Palaksanaan Generik
///
/// - `AsMut` dereferénsi otomatis upami jinis batin mangrupikeun rujukan anu tiasa dirobih (misal: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ngagunakeun `AsMut` sakumaha trait bound pikeun fungsi generik bisa nampa kabeh rujukan mutable nu bisa dirobah jadi ngetik `&mut T`.
/// Kusabab [`Box<T>`] ngalaksanakeun `AsMut<T>` urang tiasa nyerat fungsi `add_one` anu nyandak sadaya alesan anu tiasa dirobih janten `&mut u64`.
/// Kusabab [`Box<T>`] ngalaksanakeun `AsMut<T>`, `add_one` nampi alesan tina tipe `&mut Box<u64>` ogé:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ngalaksanakeun artos.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konvérsi nilai-ka-nilai anu nyéépkeun nilai input.Sabalikna [`From`].
///
/// Hiji kedah nyingkahan nerapkeun [`Into`] sareng nerapkeun [`From`] tibatan.
/// Ngalaksanakeun [`From`] sacara otomatis nyayogikeun salah sahiji panerapan [`Into`] berkat palaksanaan simbut di perpustakaan standar.
///
/// Resep maké [`Into`] leuwih [`From`] nalika nangtukeun trait bounds dina fungsi generik pikeun mastikeun yén jenis anu ngan nerapkeun [`Into`] bisa dipaké ogé.
///
/// **Note: trait teu kedah gagal **.Upami konversi tiasa gagal, anggo [`TryInto`].
///
/// # Palaksanaan Generik
///
/// - [`Ti`]`<T>pikeun U` ngakibatkeun `Into<U> for T`
/// - [`Into`] refleksif, anu hartosna `Into<T> for T` dilaksanakeun
///
/// # Ngalaksanakeun [`Into`] pikeun conversions kana jenis éksternal dina versi heubeul Rust
///
/// Saacanna Rust 1.41, upami tipe tujuan éta teu bagian tina crate ayeuna lajeng Anjeun bisa henteu ngalaksanakeun [`From`] langsung.
/// Salaku conto, candak kode ieu:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ieu bakal gagal nyusun dina versi basa anu langkung lami kusabab aturan yatim piatu Rust urang biasana rada ketat.
/// Pikeun bypass ieu, anjeun tiasa nerapkeun [`Into`] langsung:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Penting pikeun ngarti yén [`Into`] henteu nyayogikeun palaksanaan [`From`] (sakumaha [`From`] henteu sareng [`Into`]).
/// Kituna, anjeun kedah salawasna nyobian ngalaksanakeun [`From`] teras ragrag deui ka [`Into`] upami [`From`] henteu tiasa dilaksanakeun.
///
/// # Examples
///
/// [`String`] ngalaksanakeun [`Kana Kana`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Dina urutan pikeun nganyatakeun yen urang hoyong fungsi generik nyandak sakabeh alesan nu bisa dirobah ka tipe dieusian `T`, urang bisa ngagunakeun trait bound of [`Into`]`<T>`.
///
/// Contona: Fungsi `is_hello` nyokot kabeh alesan nu bisa dirobah kana [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ngalaksanakeun artos.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Dipaké pikeun ngalakukeun konversi nilai-ka-nilai bari meakeun nilai input.Éta mangrupikeun wangsalan [`Into`].
///
/// Hiji kedah salawasna resep nerapkeun `From` langkung [`Into`] sabab nerapkeun `From` sacara otomatis nyayogikeun salah sahiji implementasi [`Into`] berkat palaksanaan simbut di perpustakaan standar.
///
///
/// Ukur nerapkeun [`Into`] nalika nargétkeun vérsi sateuacan Rust 1.41 teras ngarobih kana jinis diluar crate ayeuna.
/// `From` éta teu bisa ngalakukeun jenis ieu tina conversions dina versi samemehna sabab aturan orphaning Rust urang.
/// Tingali [`Into`] pikeun langkung jelasna.
///
/// Resep ngagunakeun [`Into`] tibatan nganggo `From` nalika ngahususkeun trait bounds dina fungsi generik.
/// Ku cara ieu, jenis anu langsung nerapkeun [`Into`] bisa dipaké salaku alesan ogé.
///
/// `From` ogé mangpaat pisan nalika ngalakukeun pananganan kasalahan.Lamun diwangun hiji fungsi nu sanggup gagal, anu tipe balik umumna bakal sahiji formulir `Result<T, E>`.
/// kasalahan `From` trait simplifies nanganan ku sahingga fungsi pikeun balik jinis kasalahan tunggal nu encapsulate sababaraha jenis kasalahan.Tingali bagian "Examples" sareng [the book][book] pikeun langkung jelasna.
///
/// **Note: trait teu kedah gagal **.Upami konversi tiasa gagal, anggo [`TryFrom`].
///
/// # Palaksanaan Generik
///
/// - `From<T> for U` nyirikeun [`Kana Kana`]`<U>kanggo T`</u>
/// - `From` refleksif, anu hartosna `From<T> for T` dilaksanakeun
///
/// # Examples
///
/// [`String`] ngalaksanakeun `From<&str>`:
///
/// Hiji konversi eksplisit ti `&str` ka string dipigawé saperti kieu:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Nalika ngalakukeun kasalahan nanganan éta sering gunana pikeun nerapkeun `From` pikeun jinis kasalahan anjeun nyalira.
/// Ku ngarobih jinis kasalahan anu janten dasar pikeun jinis kasalahan khusus urang sorangan anu ngarangkep jinis kasalahan anu aya, urang tiasa balikkeun hiji jinis kasalahan tanpa kaleungitan inpormasi dina sabab anu janten sababna.
/// Operator '?' sacara otomatis ngarobah jinis kasalahan anu didasarkeun kana jinis kasalahan khusus urang ku nelepon `Into<CliError>::into` anu sacara otomatis disayogikeun nalika ngalaksanakeun `From`.
/// Kompilator teras nyeratkeun palaksanaan `Into` anu mana anu kedah dianggo.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ngalaksanakeun artos.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Konversi anu diusahakeun anu nyéépkeun `self`, anu panginten henteu mahal.
///
/// pangarang Perpustakaan kedah biasana teu langsung nerapkeun trait ieu, tapi kedah resep ngalaksanakeun éta [`TryFrom`] trait, anu nawarkeun kalenturan gede jeung nyadiakeun hiji palaksanaan `TryInto` sarimbag haratis, nuhun ka palaksanaan simbut dina perpustakaan baku.
/// Kanggo inpormasi lengkep ngeunaan ieu, tingali dokuméntasi pikeun [`Into`].
///
/// # Ngalaksanakeun `TryInto`
///
/// Ieu ngalaman larangan sareng alesan anu sami sareng nerapkeun [`Into`], tingali di dieu pikeun detilna.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Jenisna balik upami aya kasalahan konvérsi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ngalaksanakeun artos.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Konversi jenis saderhana sareng aman anu tiasa gagal dina cara anu dikawasa dina sababaraha kaayaan.Éta mangrupikeun wangsalan [`TryInto`].
///
/// Ieu mangpaat lamun anjeun ngalakonan konversi tipe nu bisa trivially sukses tapi ogé bisa butuh penanganan husus.
/// Salaku conto, teu aya jalan pikeun ngarobih [`i64`] kana [`i32`] nganggo [`From`] trait, sabab [`i64`] tiasa ngandung nilai anu [`i32`] moal tiasa ngagambarkeun sareng janten konversi bakal kaleungitan data.
///
/// Ieu tiasa diurus ku cara motong [`i64`] ka [`i32`] (intina masihan modulo [`i32::MAX`] nilai [`i64`]) atanapi ku ngan saukur balikkeun [`i32::MAX`], atanapi ku cara anu sanés.
/// [`From`] trait ditujukeun pikeun konversi anu sampurna, janten `TryFrom` trait ngawartosan programmer nalika konversi jinis tiasa janten goréng sareng ngantepkeun aranjeunna mutuskeun kumaha nangananana.
///
/// # Palaksanaan Generik
///
/// - `TryFrom<T> for U` nyirikeun [`Coba Kana Kana`]`<U>kanggo T`</u>
/// - [`try_from`] refleksif, anu hartosna `TryFrom<T> for T` dilaksanakeun sareng henteu tiasa gagal-jinis `Error` anu pakait pikeun nelepon `T::try_from()` dina nilai tipe `T` nyaéta [`Infallible`].
/// Nalika éta jenis [`!`] ieu stabilized [`Infallible`] na [`!`] bakal sarua.
///
/// `TryFrom<T>` tiasa dilaksanakeun sapertos kieu:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Sakumaha nu ditétélakeun, [`i32`] implements `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Jempe truncates `big_number`, peryogi ngadeteksi sareng nanganan truncasi saatos kanyataan.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Mulih kasalahan sabab `big_number` teuing badag pikeun nyocogkeun dina `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Mulih `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Jenisna balik upami aya kasalahan konvérsi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ngalaksanakeun artos.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS UMUM
////////////////////////////////////////////////////////////////////////////////

// Salaku lifts leuwih&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Salaku angkat langkung &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ngaganti impls luhur pikeun&/&mut kalawan handap hiji leuwih umum:
// // Salaku angkat ngalangkungan Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Ukuran> AsRef <U>pikeun D {FN as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut angkat langkung &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ngaganti impl di luhur pikeun &mut ku anu langkung umum di handap ieu:
// // AsMut lifts leuwih DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Ukuran> AsMut <U>pikeun D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Tina ngakibatkeun Kana
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Tina (sahingga Kana Kana) répléksif
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **stabilitas catetan:** impl ieu teu acan aya, tapi kami "reserving space" pikeun nambahkeun éta dina future.
/// Tempo [rust-lang/rust#64715][#64715] pikeun detil.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ngalakukeun ngalereskeun prinsip.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// CobaFrom ngakibatkeun TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// conversions Infallible anu semantically sarua jeung conversions fallible kalawan jenis kasalahan didumukan.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// NGONJUKKEUN IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// JENIS SALAH TEU SALAH
////////////////////////////////////////////////////////////////////////////////

/// Jenis kasalahan pikeun kasalahan anu pernah tiasa kajantenan.
///
/// Kusabab enum ieu boga variasi, ajén tipe ieu pernah bisa sabenerna aya.
/// Ieu tiasa mangpaat pikeun API umum nu ngagunakeun [`Result`] na parameterize tipe kasalahan, pikeun nunjukkeun yén hasilna sok [`Ok`].
///
/// Contona, dina [`TryFrom`] trait (konversi yen mulih a [`Result`]) mibanda palaksanaan simbut keur sakabeh tipe dimana a palaksanaan [`Into`] sabalikna aya.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # kasaluyuan Future
///
/// Enum ieu ngagaduhan peran anu sami sareng [the `!`“never”type][never], anu henteu stabil dina vérsi Rust ieu.
/// Nalika `!` stabil, urang rencanana ngajantenkeun `Infallible` mangrupikeun jinis alias ka dinya:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Sareng akhirna ngaleungitkeun `Infallible`.
///
/// Najan kitu aya hiji pasualan numana rumpaka `!` bisa dipaké saméméh `!` ieu stabilized salaku tipe full-fledged: dina posisi fungsi urang tipe mulang.
/// Husus, nya éta jurus lianna pikeun dua jenis fungsi pointer béda:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kalayan `Infallible` janten enum, kode ieu valid.
/// Nanging nalika `Infallible` janten landian pikeun never type, dua `impl`s bakal mimiti tumpang tindih sareng sabab éta bakal diidinan ku aturan koherensi trait bahasa.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}