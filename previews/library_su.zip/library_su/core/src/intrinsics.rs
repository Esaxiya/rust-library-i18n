//! intrinsics compiler.
//!
//! Definisi anu pakait aya dina `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! The implementations const pakait anu di `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # intrinsics Const
//!
//! Note: sagala parobahan ka constness of intrinsics kudu dibahas jeung tim basa.
//! Ieu kalebet parobihan dina stabilitas konsténsi.
//!
//! Dina raraga ngajantenkeun intrinsik tiasa dianggo dina waktos kompilasi, kedah nyalin palaksanaan tina <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ka `compiler/rustc_mir/src/interpret/intrinsics.rs` sareng nambihan `#[rustc_const_unstable(feature = "foo", issue = "01234")]` kana intrinsik.
//!
//!
//! Mun hiji intrinsik anu sakuduna dituju bisa dipaké ti `const fn` ku atribut `rustc_const_stable`, atribut teh intrinsik urang kudu janten `rustc_const_stable`, teuing.
//! Parobihan sapertos kitu henteu kedah dilakukeun tanpa konsultasi T-lang, sabab éta fitur bak kana basa anu teu tiasa ditiru dina kode pangguna tanpa dukungan kompiler.
//!
//! # Volatiles
//!
//! Intrinsik volatil nyayogikeun operasi anu dimaksadkeun pikeun meta dina mémori I/O, anu dijamin henteu tiasa diatur deui ku panyusun dina intrinsik volatil anu sanés.Tempo dokuméntasi LLVM on [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! The intrinsics atom nyadiakeun operasi atom umum dina kecap mesin, jeung sababaraha kamungkinan cara susunan memori.Aranjeunna nurut ka semantik sarua salaku C++ 11.Tempo dokuméntasi LLVM on [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A refresher rusuh on nyusun memori:
//!
//! * Acquire, halangan pikeun kéngingkeun konci.Saterusna maos na nyerat lumangsung sanggeus pawates.
//! * Ngaleupaskeun, panghalang pikeun ngaleupaskeun konci a.Harita maos na nyerat lumangsung méméh pawates.
//! * Operasi sacara konsisten, sekuen anu konsistén dijamin bakal kajadian dina urutan.Ieu teh mode standar pikeun gawé bareng jenis atom na sarua jeung Java urang `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// impor ieu digunakeun pikeun ngajarkeun Tumbu intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kaamanan: tingali `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, intrinsik ieu nyandak petunjuk atah sabab éta mutasi memori alias, anu henteu valid pikeun `&` atanapi `&mut`.
    //

    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::SeqCst`] salaku parameter `success` sareng `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::Acquire`] salaku parameter `success` sareng `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::Release`] salaku `success` sareng [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::AcqRel`] salaku `success` sareng [`Ordering::Acquire`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange` ku jalan ngalirkeun [`Ordering::Relaxed`] sakumaha duanana parameter `success` na `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::SeqCst`] salaku `success` sareng [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `success` na [`Ordering::Acquire`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `success` na [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange` ku ngalirkeun [`Ordering::AcqRel`] salaku `success` sareng [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::SeqCst`] salaku parameter `success` sareng `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::Acquire`] salaku parameter `success` sareng `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange_weak` ku jalan ngalirkeun [`Ordering::Release`] salaku `success` na [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange_weak` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `success` na [`Ordering::Acquire`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::Relaxed`] salaku parameter `success` sareng `failure`.
    ///
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::SeqCst`] salaku `success` sareng [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::SeqCst`] salaku `success` sareng [`Ordering::Acquire`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `compare_exchange_weak` ku ngalirkeun [`Ordering::Acquire`] salaku `success` sareng [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Nyimpen hiji nilai upami nilai ayeuna sami sareng nilai `old`.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `compare_exchange_weak` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `success` na [`Ordering::Relaxed`] salaku parameter `failure`.
    /// Salaku conto, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Beban nilai ayeuna tina panunjuk.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `load` ku ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Beban nilai ayeuna tina panunjuk.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `load` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Beban nilai ayeuna tina panunjuk.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `load` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Nyimpen nilai dina lokasi mémori anu ditangtoskeun.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `store` ku ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Nyimpen nilai dina lokasi mémori anu ditangtoskeun.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `store` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Nyimpen nilai dina lokasi mémori anu ditangtoskeun.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `store` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Nyimpen ajén di lokasi mémori dieusian, balik nilai heubeul.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `swap` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen ajén di lokasi mémori dieusian, balik nilai heubeul.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `swap` ku ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen ajén di lokasi mémori dieusian, balik nilai heubeul.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `swap` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen ajén di lokasi mémori dieusian, balik nilai heubeul.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `swap` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nyimpen ajén di lokasi mémori dieusian, balik nilai heubeul.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `swap` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_add` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_add` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_add` ku ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_add` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_add` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kurangan tina nilai ayeuna, mulih deui nilai anu sateuacanna.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_sub` ku ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangan tina nilai ayeuna, mulih deui nilai anu sateuacanna.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_sub` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangan tina nilai ayeuna, mulih deui nilai anu sateuacanna.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_sub` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangan tina nilai ayeuna, mulih deui nilai anu sateuacanna.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_sub` ku ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangan tina nilai ayeuna, mulih deui nilai anu sateuacanna.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_sub` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise sareng ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_and` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sareng ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_and` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sareng ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_and` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sareng ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_and` ku ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise sareng ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_and` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina tipe [`AtomicBool`] via metoda `fetch_nand` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina tipe [`AtomicBool`] via metoda `fetch_nand` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina tipe [`AtomicBool`] via metoda `fetch_nand` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina tipe [`AtomicBool`] via metoda `fetch_nand` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`AtomicBool`] ngalangkungan metode `fetch_nand` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise atanapi ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_or` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atanapi ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_or` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atanapi ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_or` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atanapi ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_or` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise atanapi ku nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_or` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor sareng nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_xor` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor sareng nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis [`atomic`] ngalangkungan metode `fetch_xor` ku ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor sareng nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_xor` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor sareng nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_xor` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor sareng nilai ayeuna, balikkeun nilai sateuacana.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina jenis [`atomic`] via metoda `fetch_xor` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_max` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina [`atomic`] jinis integer anu ditandatanganan ngalangkungan metode `fetch_max` ku ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_max` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_max` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum jeung nilai ayeuna.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_max` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_min` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_min` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina [`atomic`] jinis integer anu ditandatanganan ngalangkungan metode `fetch_min` ku ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina [`atomic`] jinis integer anu ditandatanganan ngalangkungan metode `fetch_min` ku ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] ditandatanganan integer jenis liwat metoda `fetch_min` ku jalan ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_min` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis integer [`atomic`] anu teu ditandatanganan ngalangkungan metode `fetch_min` ku ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_min` ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_min` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis integer [`atomic`] anu teu ditandatanganan ngalangkungan metode `fetch_min` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_max` ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_max` ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis integer [`atomic`] anu teu ditandatanganan ngalangkungan metode `fetch_max` ku ngalirkeun [`Ordering::Release`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic`] jenis integer unsigned via metoda `fetch_max` ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimal kalayan nilai ayeuna nganggo perbandingan anu teu ditandatanganan.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina jinis integer [`atomic`] anu teu ditandatanganan ngalangkungan metode `fetch_max` ku ngalirkeun [`Ordering::Relaxed`] salaku `order`.
    /// Salaku conto, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` intrinsik mangrupikeun petunjuk ka generator kode pikeun ngalebetkeun paréntah prefetch upami didukung;disebutkeun, eta mangrupakeun no-op.
    /// Prefetches teu aya pangaruhna kana paripolah program tapi tiasa ngarobih ciri kinerja na.
    ///
    /// The `locality` argumen kedah janten integer konstanta sarta mangrupakeun locality specifier temporal mimitian ti (0), teu locality, mun (3), pisan Keep lokal di cache.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsik mangrupikeun petunjuk ka generator kode pikeun ngalebetkeun paréntah prefetch upami didukung;disebutkeun, eta mangrupakeun no-op.
    /// Prefetches teu aya pangaruhna kana paripolah program tapi tiasa ngarobih ciri kinerja na.
    ///
    /// The `locality` argumen kedah janten integer konstanta sarta mangrupakeun locality specifier temporal mimitian ti (0), teu locality, mun (3), pisan Keep lokal di cache.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsik mangrupikeun petunjuk ka generator kode pikeun ngalebetkeun paréntah prefetch upami didukung;disebutkeun, eta mangrupakeun no-op.
    /// Prefetches teu aya pangaruhna kana paripolah program tapi tiasa ngarobih ciri kinerja na.
    ///
    /// The `locality` argumen kedah janten integer konstanta sarta mangrupakeun locality specifier temporal mimitian ti (0), teu locality, mun (3), pisan Keep lokal di cache.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` intrinsik mangrupikeun petunjuk ka generator kode pikeun ngalebetkeun paréntah prefetch upami didukung;disebutkeun, eta mangrupakeun no-op.
    /// Prefetches teu aya pangaruhna kana paripolah program tapi tiasa ngarobih ciri kinerja na.
    ///
    /// The `locality` argumen kedah janten integer konstanta sarta mangrupakeun locality specifier temporal mimitian ti (0), teu locality, mun (3), pisan Keep lokal di cache.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Pager atom.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::fence`] ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Pager atom.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::fence`] ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Pager atom.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina [`atomic::fence`] ku ngalirkeun [`Ordering::Release`] salaku `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Pager atom.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::fence`] ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Penghalang mémori ngan ukur kompiler.
    ///
    /// aksés mémori bakal pernah jadi reordered sakuliah panghalang ku compiler, tapi euweuh parentah bakal dipancarkeun keur eta.
    /// Ieu luyu pikeun operasi dina thread nu sami nu bisa jadi preempted, kayaning nalika interacting jeung pawang sinyal.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::compiler_fence`] ku jalan ngalirkeun [`Ordering::SeqCst`] salaku `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Penghalang mémori ngan ukur kompiler.
    ///
    /// aksés mémori bakal pernah jadi reordered sakuliah panghalang ku compiler, tapi euweuh parentah bakal dipancarkeun keur eta.
    /// Ieu luyu pikeun operasi dina thread nu sami nu bisa jadi preempted, kayaning nalika interacting jeung pawang sinyal.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::compiler_fence`] ku jalan ngalirkeun [`Ordering::Acquire`] salaku `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Penghalang mémori ngan ukur kompiler.
    ///
    /// aksés mémori bakal pernah jadi reordered sakuliah panghalang ku compiler, tapi euweuh parentah bakal dipancarkeun keur eta.
    /// Ieu luyu pikeun operasi dina thread nu sami nu bisa jadi preempted, kayaning nalika interacting jeung pawang sinyal.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::compiler_fence`] ku jalan ngalirkeun [`Ordering::Release`] salaku `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Penghalang mémori ngan ukur kompiler.
    ///
    /// aksés mémori bakal pernah jadi reordered sakuliah panghalang ku compiler, tapi euweuh parentah bakal dipancarkeun keur eta.
    /// Ieu luyu pikeun operasi dina thread nu sami nu bisa jadi preempted, kayaning nalika interacting jeung pawang sinyal.
    ///
    /// Vérsi The stabilized of intrinsik ieu sadia dina [`atomic::compiler_fence`] ku jalan ngalirkeun [`Ordering::AcqRel`] salaku `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Sihir intrinsik anu nampi hartos na tina atribut anu napel dina fungsina.
    ///
    /// Contona, dataflow kagunaan ieu nyuntik assertions statik ambéh `rustc_peek(potentially_uninitialized)` bakal sabenerna ganda-cek nu dataflow teu memang itung anu eta anu uninitialized dina titik nu di aliran kontrol.
    ///
    ///
    /// Intrinsik ieu henteu kedah dianggo di luar panyusun.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts nu dijalankeunnana prosés.
    ///
    /// Hiji deui ramah-pamaké sarta stabil Vérsi operasi ieu [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Ngawartosan pangoptimal yén titik ieu dina kode henteu kahontal, sahingga pangoptimalan salajengna.
    ///
    /// NB, ieu bénten pisan sareng makro `unreachable!()`: Beda sareng makro, anu panics nalika dieksekusi, éta *kabiasaan anu teu ditangtoskeun* pikeun ngahontal kode anu dicirian ku fungsi ieu.
    ///
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Nyaritakeun pangoptimal yén kaayaan salawasna leres.
    /// Upami kondisina palsu, kalakuanana henteu ditangtoskeun.
    ///
    /// Teu aya kode anu dihasilkeun pikeun intrinsik ieu, tapi pangoptimal bakal nyobian ngalestarikeunana (sareng kondisina) diantawis pass, anu tiasa ngaganggu optimasi kode sakurilingna sareng ngirangan kinerja.
    /// Éta henteu kedah dianggo upami invarian tiasa dipanggihan ku pangoptimal nyalira, atanapi upami éta henteu ngaktipkeun optimasi anu signifikan.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Petunjuk ka compiler anu kaayaan branch kamungkinan janten leres.
    /// Mulih ka nilai diliwatan mun eta.
    ///
    /// Sagala kagunaan sanés ku pernyataan `if` sigana moal aya pangaruh.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Petunjuk ka compiler anu kaayaan branch kamungkinan janten palsu.
    /// Mulih ka nilai diliwatan mun eta.
    ///
    /// Sagala kagunaan sanés ku pernyataan `if` sigana moal aya pangaruh.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executes a bubu breakpoint, keur inspeksi ku debugger a.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn breakpoint();

    /// Ukuran jinis dina bait.
    ///
    /// Leuwih husus, ieu teh offset dina bait antara barang saterusna tina tipe sarua, kaasup alignment padding.
    ///
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimum alignment sahiji jenis a.
    ///
    /// Vérsi The stabilized of intrinsik ieu [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Alignment pikaresep tina hiji jenis.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ukuran sahiji nilai referenced dina bait.
    ///
    /// Vérsi The stabilized of intrinsik ieu [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Alignment anu diperyogikeun tina nilai anu dirujuk.
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Meunang potongan senar statik anu ngandung nami hiji jinis.
    ///
    /// Vérsi The stabilized of intrinsik ieu [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Meunang hiji identifier nu global unik kana tipe ditangtukeun.
    /// fungsi ieu bakal balik ka nilai anu sarua keur tipe a paduli whichever crate mangka invoked di.
    ///
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A hansip keur fungsi unsafe nu teu bisa kantos jadi dieksekusi lamun `T` nyaeta didumukan:
    /// Ieu sacara statis bakal boh panic, atanapi henteu ngalakukeun nanaon.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Pangawal pikeun fungsi anu teu aman anu henteu tiasa dilaksanakeun upami `T` henteu kéngingkeun enol-inisialisasi: Ieu sacara statis ogé panic, atanapi henteu ngalakukeun nanaon.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn assert_zero_valid<T>();

    /// A hansip keur fungsi unsafe nu teu bisa kantos jadi dieksekusi lamun `T` boga pola bit sah: Ieu statically bakal boh panic, atawa becus.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn assert_uninit_valid<T>();

    /// Meunangkeun rujukan kana `Location` statis nunjukkeun dimana éta disebatna.
    ///
    /// Pertimbangkeun nganggo [`core::panic::Location::caller`](crate::panic::Location::caller) tibatan.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Mindahkeun nilai kaluar tina ruang lingkup tanpa nganggo lem serelek.
    ///
    /// Ieu ngan ukur pikeun [`mem::forget_unsized`];`forget` normal nganggo `ManuallyDrop` tibatan.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Nafsirkeun potongan tina hiji nilai tina jenis anu sanés.
    ///
    /// Duanana jenis kudu boga ukuran nu sami.
    /// Ngayakeun asal, atawa hasilna, bisa jadi hiji [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` nyaeta semantically sarua jeung move bitwise tina hiji jenis kana sejen.Ieu salinan ti bit ti nilai sumber kana nilai tujuan, teras poho aslina.
    /// Ieu sarua jeung C urang `memcpy` handapeun tiung, kawas `transmute_copy`.
    ///
    /// Kusabab `transmute` ngarupakeun operasi ku-nilai, alignment tina *transmuted nilai sorangan* teu perhatian a.
    /// Salaku kalayan sagala fungsi sejen, compiler anu geus ensures duanana `T` na `U` anu Blok leres.
    /// Najan kitu, nalika transmuting nilai yen *titik nguap*(kayaning pointers, rujukan, buleud ...), panelepon ngabogaan pikeun mastikeun alignment ditangtoskeun tina nilai nunjuk-ka.
    ///
    /// `transmute` nyaéta **luar biasa** teu aman.Aya sababaraha vast cara ngabalukarkeun [undefined behavior][ub] kalayan fungsi ieu.`transmute` kedah janten pilihan terakhir.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ngagaduhan dokuméntasi tambihan.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Aya sababaraha hal anu `transmute` leres-leres kapaké pikeun.
    ///
    /// Ngaktipkeun pointer a kana pointer fungsi.Ieu *moal* dibabawa kana mesin mana pointers fungsi jeung data pointers gaduh ukuran béda.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Dilegaan hirupna hiji, atanapi pondok hiji hirupna invarian.Ieu maju, Rust pisan teu aman!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ulah asa: loba kagunaan tina `transmute` bisa dihontal ngaliwatan cara nu lian.
    /// Ieu mangrupikeun aplikasi umum `transmute` anu tiasa diganti ku konstruksi anu langkung aman.
    ///
    /// Ngaktipkeun bytes(`&[u8]`) atah keur `u32`, `f64`, jsb .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // pamakéan `u32::from_ne_bytes` gantina
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // atanapi nganggo `u32::from_le_bytes` atanapi `u32::from_be_bytes` mun nangtukeun endianness nu
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ngaktipkeun pointer a kana `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Paké hiji matak `as` gantina
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ngarobih `*mut T` kana `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Anggo tarima deui
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ngarobih `&mut T` kana `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ayeuna, sasarengan `as` sareng reborrowing, perhatoskeun ranté `as` `as` henteu transitif
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Ngarobih `&str` kana `&[u8]`:
    ///
    /// ```
    /// // ieu sanés cara anu saé pikeun ngalakukeun ieu.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Anjeun bisa make `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Atanapi, kantun nganggo senar bait, upami anjeun gaduh kendali string sacara literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ngarobih `Vec<&T>` kana `Vec<Option<&T>>`.
    ///
    /// Pikeun transmute tipe jero eusi wadah, Anjeun kedah pastikeun pikeun henteu ngalanggar salah sahiji invariants wadahna urang.
    /// Pikeun `Vec`, ieu hartosna yen duanana ukuran *na alignment* sahiji jenis jero kudu cocog.
    /// Wadah anu sanés panginten gumantung kana ukuran jinisna, alignment, atanapi bahkan `TypeId`, dina hal ieu transmutasi moal mungkin pisan tanpa ngalanggar invariants kontainer.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone nu vector salaku urang maké deui aranjeunna engké
    /// let v_clone = v_orig.clone();
    ///
    /// // Ngagunakeun transmute: ieu gumantung kana tata data anu henteu ditangtoskeun tina `Vec`, anu mangrupakeun ide anu goréng sareng tiasa nyababkeun Perilaku Anu Teu Ditetepkeun.
    /////
    /// // Nanging, éta henteu aya salinan.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ieu cara anu disarankeun, aman.
    /// // Ieu teu nyalin sakabéh vector, sanajan, kana Asép Sunandar Sunarya anyar.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ieu cara no-copy, cara henteu aman tina "transmuting" a `Vec`, tanpa ngandelkeun perenah data.
    /// // Gantina sacara harfiah nelepon `transmute` kami ngalakukeun matak pointer, tapi tina segi ngarobah kana tipe jero aslina (`&i32`) kana anyar salah (`Option<&i32>`), ieu boga sagala caveats sarua.
    /////
    /// // Di sagigireun informasi nu disadiakeun di luhur, ogé konsultasi dokuméntasi [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Perbarui ieu nalika vector_into_raw_parts stabilisasi.
    ///     // Pastikeun vector aslina henteu lungsur.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Ngalaksanakeun `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Aya sababaraha cara pikeun ngalakukeun ieu, sarta aya sababaraha masalah sareng cara (transmute) handap.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // kahiji: transmute henteu ngetik aman;kabéh cék éta yen T na
    ///         // U nyaéta sahiji ukuran anu sarua.
    ///         // Kadua, di dieu, anjeun gaduh dua rujukan anu tiasa dirobih nunjuk kana mémori anu sami.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ieu bakal leupas tina masalah tipe kaamanan;`&mut *` baris* wungkul *masihan anjeun hiji `&mut T` ti hiji `&mut T` atanapi `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // kumaha oge, Anjeun masih gaduh dua rujukan mutable ngarah ka mémori sarua.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ieu kumaha perpustakaan standar ngalakukeunana.
    /// // Ieu cara anu pangsaéna, upami anjeun kedah ngalakukeun sapertos kieu
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ieu ayeuna gaduh tilu rujukan anu tiasa dirobih nunjuk dina mémori anu sami.`slice`, anu rvalue ret.0, sarta rvalue ret.1.
    ///         // `slice` geus pernah dipaké sanggeus `let ptr = ...`, sarta jadi salah sahiji bisa ngubaran salaku "dead", sarta ku kituna, Anjeun ukur boga dua keureut mutable nyata.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Bari kieu ngajadikeun const stabil intrinsik, urang gaduh sababaraha kode custom di FN const
    // cék anu nyegah panggunaan na dina `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Mulih `true` lamun tipe sabenerna dirumuskeun sakumaha `T` merlukeun serelek lem;mulih `false` lamun tipe sabenerna nu disadiakeun pikeun `T` implements `Copy`.
    ///
    ///
    /// Mun tipe sabenerna ngayakeun merlukeun serelek lem atawa implements `Copy`, mangka nilai balikna fungsi ieu unspecified.
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ngitung offset tina panunjuk.
    ///
    /// Ieu dilaksanakeun salaku intrinsik pikeun nyingkahan ngarobah kana sareng integer, kumargi konversi bakal miceun inpormasi aliasing.
    ///
    /// # Safety
    ///
    /// Boh pointer anu ngamimitian sareng anu dihasilkeun kedahna aya dina bounds atanapi hiji byte ngalangkungan tungtung hiji obyék anu dialokasikan.
    /// Upami salah sahiji pointer aya diluar wates atanapi limpahan aritmatika lumangsung maka panggunaan salajengna nilai balik bakal ngahasilkeun perilaku anu teu ditangtoskeun.
    ///
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Etang offset ti pointer, berpotensi wrapping.
    ///
    /// Ieu dilaksanakeun salaku intrinsik ulah ngarobah ka sareng ti hiji integer, saprak artos nyegah optimizations tangtu.
    ///
    /// # Safety
    ///
    /// Saperti intrinsik `offset`, intrinsik ieu teu ngawatesan pointer anu dihasilkeun nepi ka titik kana atanapi salah bait kaliwat tungtung hiji obyék disadiakeun, sarta eta wraps dua urang arithmetic pelengkap.
    /// nilai anu dihasilkeun teu merta valid pikeun dipaké pikeun memori sabenerna aksés.
    ///
    /// Vérsi The stabilized of intrinsik ieu [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Sarua jeung intrinsik `llvm.memcpy.p0i8.0i8.*` anu pas, kalayan ukuran `count`*`size_of::<T>()` sareng alignment
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile disetel ka `true`, ku kituna moal dioptimalkeun kaluar iwal ukuranana sarua jeung nol.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sarimbag ka kaca nu luyu `llvm.memmove.p0i8.0i8.*` intrinsik, ku ukuran tina `count* size_of::<T>()` na hiji alignment tina
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile disetel ka `true`, ku kituna moal dioptimalkeun kaluar iwal ukuranana sarua jeung nol.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sarua jeung intrinsik `llvm.memset.p0i8.*` anu pas, kalayan ukuran `count* size_of::<T>()` sareng alignment `min_align_of::<T>()`.
    ///
    ///
    /// Parameter volatile disetel ka `true`, ku kituna moal dioptimalkeun kaluar iwal ukuranana sarua jeung nol.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Ngalakukeun beban volatil tina pointer `src`.
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Ngalakukeun toko anu henteu stabil dina panunjuk `dst`.
    ///
    /// Versi stabil tina intrinsik ieu nyaéta [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Ngalaksanakeun beban volatile ti pointer `src` pointer The henteu diperlukeun bisa Blok.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Ngalakukeun toko anu henteu stabil dina panunjuk `dst`.
    /// Penunjuk henteu diperyogikeun pikeun dijajarkeun.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Balikkeun akar kuadrat `f32`
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Mulih akar kuadrat hiji `f64`
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Raises hiji `f32` ka kakuatan integer.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ngangkat `f64` kana kakuatan integer.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Balikkeun résin tina `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Mulih sinus tina hiji `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Mulih ka kosinus tina hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Mulih ka kosinus tina hiji `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ngangkat `f32` kana kakuatan `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Raises hiji `f64` ka kakuatan `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Mulih ka eksponensial tina hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Balikkeun éksponénsial `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Mulih 2 diangkat kana kakuatan `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Mulih 2 diangkat kana kakuatan `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Balikkeun logaritma alami `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Balikkeun logaritma alami `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Mulih dasar 10 logaritma hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Mulih dasar 10 logaritma hiji `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Mulih dasar 2 logaritma hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Balikkeun dasar 2 logaritma `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Mulih `a * b + c` kanggo nilai `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Mulih `a * b + c` kanggo nilai `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Mulih nilai mutlak hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Balikkeun nilai mutlak `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Mulih minimum dua nilai `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Mulih minimum dua nilai `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Mulih maksimal dua nilai `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Mulih maksimal dua nilai `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Salinan tanda ti `y` mun `x` keur nilai `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Nyalin tanda tina `y` ka `x` pikeun nilai `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Mulih bilangan bulat panggedéna kirang ti atanapi sami sareng `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Mulih bilangan bulat panggedéna kirang ti atanapi sami sareng `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Balikkeun bilangan bulat pangleutikna anu langkung ageung tibatan atanapi sami sareng `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Mulih ka gede integer pangleutikna ti atanapi sarua ka `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Mulih ka bagian integer tina hiji `f32`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Balikkeun bagian bilangan bulat `f64`.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Balikkeun bilangan bulat pangdeukeutna ka `f32`.
    /// Bisa ngangkat pengecualian titik terapung lamun arguménna sanés bilangan bulat.
    pub fn rintf32(x: f32) -> f32;
    /// Mulih ka integer pangcaketna ka `f64`.
    /// Bisa ngangkat pengecualian titik terapung lamun arguménna sanés bilangan bulat.
    pub fn rintf64(x: f64) -> f64;

    /// Balikkeun bilangan bulat pangdeukeutna ka `f32`.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Mulih ka integer pangcaketna ka `f64`.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Mulih ka integer pangcaketna ka `f32`.Bunderan satengah jalan kasus jauh tina nol.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Balikkeun bilangan bulat pangdeukeutna ka `f64`.kasus Rounds satengah jalan jauh ti nol.
    ///
    /// Vérsi The stabilized of intrinsik ieu
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ngapung nambihan anu ngamungkinkeun ngaoptimalkeun dumasar kana aturan aljabar.
    /// Bisa nganggap inputs anu terhingga.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Pangurangan ngambang anu ngamungkinkeun optimisasi dumasarkeun kana aturan aljabar.
    /// Bisa nganggap inputs anu terhingga.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ngambang multiplication anu ngamungkinkeun optimizations dumasar aljabar aturan.
    /// Bisa nganggap inputs anu terhingga.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Pembagian apungan anu ngamungkinkeun optimisasi dumasarkeun kana aturan aljabar.
    /// Bisa nganggap inputs anu terhingga.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sésa ngambang anu ngamungkinkeun optimasi dumasar kana aturan aljabar.
    /// Bisa nganggap inputs anu terhingga.
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Ngarobih nganggo LLVM's fptoui/fptosi, anu tiasa mulih undef pikeun nilai-nilai anu teu aya dina kisaran
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilized sakumaha [`f32::to_int_unchecked`] na [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Mulih jumlah bit diatur dina tipe integer `T`
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `count_ones`.
    /// Salaku conto,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Mulih jumlah bit unset ngarah (zeroes) dina tipe integer `T`.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `leading_zeros`.
    /// Salaku conto,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` kalayan nilai `0` bakal balikkeun rubak bit `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Sapertos `ctlz`, tapi ekstra-teu aman sabab mulih `undef` nalika dipasihan `x` kalayan nilai `0`.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Mulih jumlah bit unset labuh (zeroes) dina tipe integer `T`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina integer primitives ngalangkungan metode `trailing_zeros`.
    /// Salaku conto,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` kalayan nilai `0` bakal balikkeun rubak sakedik `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Sapertos `cttz`, tapi ekstra-teu aman sabab mulih `undef` nalika dipasihan `x` kalayan nilai `0`.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Reverses nu bait dina tipe integer `T`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina integer primitives ngalangkungan metode `swap_bytes`.
    /// Salaku conto,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Balikkeun bit dina tipe bilangan bulat `T`.
    ///
    /// Versi stabil tina intrinsik ieu sayogi dina integer primitives ngalangkungan metode `reverse_bits`.
    /// Salaku conto,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Ngalaksanakeun ditambahan bilangan bulat.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `overflowing_add`.
    /// Salaku conto,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ngalaksanakeun dipariksa integer pangurangan
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `overflowing_sub`.
    /// Salaku conto,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ngalaksanakeun dikali integer
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `overflowing_mul`.
    /// Salaku conto,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ngalakukeun hiji division pasti, hasilna kabiasaan undefined mana `x % y != 0` atanapi `y == 0` atanapi `x == T::MIN && y == -1`
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Ngalakukeun hiji division unchecked, hasilna kabiasaan undefined mana `y == 0` atanapi `x == T::MIN && y == -1`
    ///
    ///
    /// Bungkus aman pikeun intrinsik ieu sayogi dina integer primitip ngalangkungan metode `checked_div`.
    /// Salaku conto,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Mulih sésana tina hiji division unchecked, hasilna kabiasaan undefined nalika `y == 0` atanapi `x == T::MIN && y == -1`
    ///
    ///
    /// wrappers aman pikeun intrinsik ieu sadia dina Primitif integer via metoda `checked_rem`.
    /// Salaku conto,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Ngalaksanakeun shift kénca anu teu dipariksa, hasilna kabiasaan teu ditangtoskeun nalika `y < 0` atanapi `y >= N`, dimana N nyaéta lébar T dina bit.
    ///
    ///
    /// wrappers aman pikeun intrinsik ieu sadia dina Primitif integer via metoda `checked_shl`.
    /// Salaku conto,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Ngalaksanakeun pergeseran katuhu anu teu dipariksa, ngahasilkeun paripolah anu teu ditangtoskeun nalika `y < 0` atanapi `y >= N`, dimana N nyaéta lébar T dina bit.
    ///
    ///
    /// Bungkus aman pikeun intrinsik ieu sayogi dina integer primitip ngalangkungan metode `checked_shr`.
    /// Salaku conto,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Mulih hasil tambihan anu teu dipariksa, ngahasilkeun paripolah anu teu ditangtoskeun nalika `x + y > T::MAX` atanapi `x + y < T::MIN`.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Mulih hasil tina hiji pangurangan unchecked, hasilna kabiasaan undefined nalika `x - y > T::MAX` atanapi `x - y < T::MIN`.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Mulih hasil tina hiji multiplication unchecked, hasilna kabiasaan undefined nalika `x *y > T::MAX` atanapi `x* y < T::MIN`.
    ///
    ///
    /// Intrinsik ieu henteu ngagaduhan tara anu mantep.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Laksanakeun muterkeun kénca.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `rotate_left`.
    /// Salaku conto,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Laksanakeun muterkeun katuhu.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `rotate_right`.
    /// Salaku conto,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Mulih (a + b) Emod 2 <sup>N,</sup> mana N nyaéta rubak T dina bit.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `wrapping_add`.
    /// Salaku conto,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Mulih (a, b) mod 2 <sup>N</sup>, dimana N nyaéta lébar T dina bit.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `wrapping_sub`.
    /// Salaku conto,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Mulih (a * b) Emod 2 <sup>N,</sup> mana N nyaéta rubak T dina bit.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `wrapping_mul`.
    /// Salaku conto,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ngitung `a + b`, jenuh dina wates angka.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `saturating_add`.
    /// Salaku conto,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ngitung `a - b`, jenuh dina wates angka.
    ///
    /// versi nu stabilized of intrinsik ieu sadia dina Primitif integer via metoda `saturating_sub`.
    /// Salaku conto,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Mulih nilai discriminant keur variasi dina 'v';
    /// upami `T` teu gaduh diskriminatif, mulih `0`.
    ///
    /// Vérsi The stabilized of intrinsik ieu [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Mulih jumlah varian tina tipe `T` tuang ka `usize`;
    /// lamun `T` boga varian, mulih `0`.Varian anu henteu didumukan bakal diitung.
    ///
    /// Vérsi ka-jadi-stabilized of intrinsik ieu [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// nyusunna "try catch" Rust urang nu invokes fungsi pointer `try_fn` jeung pointer data `data`.
    ///
    /// Argumen katilu nyaéta fungsi disebutna lamun a panic lumangsung.
    /// Pungsi ieu nyokot pointer data sarta pointer ka obyék iwal target-spésifik yén ieu bray.
    ///
    /// Kanggo inpo nu leuwih lengkep tingali sumberna kompiler urang ogé palaksanaan nyekel std urang.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emits hiji toko `!nontemporal` nurutkeun LLVM (tingali docs maranéhanana).
    /// Meureun moal jadi stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Tingali dokuméntasi `<*const T>::offset_from` pikeun detil.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Tingali dokuméntasi `<*const T>::guaranteed_eq` pikeun detil.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Tingali dokuméntasi `<*const T>::guaranteed_ne` pikeun detil.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alokasi dina waktos nyusun.Teu matak disebut di runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Sababaraha fungsi nu tangtu di dieu sabab ngahaja meunang dijieun sadia dina modul ieu dina stabil.
// Tempo <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ogé asup kana katégori ieu, tapi éta henteu tiasa dibungkus kusabab cek `T` sareng `U` ngagaduhan ukuran anu sami.)
//

/// Pariksa naha `ptr` leres dijejerankeun pikeun `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Nyalin `count *size_of::<T>()` bait tina `src` dugi `dst`.Sumber jeung tujuanana must* moal * tumpang tindihna.
///
/// Pikeun wewengkon mémori nu bisa tumpang tindih, make [`copy`] gantina.
///
/// `copy_nonoverlapping` nyaeta semantically sarua jeung C urang [`memcpy`], tapi jeung urutan argumen swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `src` kedah janten [valid] pikeun maos tina `count * size_of::<T>()` bait.
///
/// * `dst` kedah [valid] kanggo nyerat bait `count * size_of::<T>()`.
///
/// * Duanana `src` sareng `dst` kedah leres dijajar.
///
/// * Wilayah mémori dimimitian dina `src` kalayan ukuran `count *
///   size_of: :<T>() `bait kedah *henteu* tumpang tindih sareng daérah ingetan anu dimimitian dina `dst` kalayan ukuran anu sami.
///
/// Kawas [`read`], `copy_nonoverlapping` nyiptakeun salinan bitwise of `T`, paduli naha `T` nyaeta [`Copy`].
/// Upami `T` sanés [`Copy`], nganggo *duanana* nilai-nilai di daérah anu dimimitian dina `*src` sareng daérah anu dimimitian dina `* dst` tiasa [violate memory safety][read-ownership].
///
///
/// Catetan yen sanajan ukuran éféktif disalin (`cacah * size_of: :<T>()`) nyaéta `0`, petunjuk kedah non-NULL sareng leres dijajarkeun.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Sacara manual nerapkeun [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Ngalir sakabéh unsur `src` kana `dst`, ninggalkeun `src` kosong.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Pastikeun yén `dst` ngagaduhan kapasitas anu cekap pikeun nahan sadaya `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Telepon pikeun ngimbangan sok aman sabab `Vec` moal pernah ngaluarkeun langkung ti `isize::MAX` bait.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` tanpa muterna eusina.
///         // Urang ngalakukeun ieu heula, masalah ulah bisi hal salajengna handap panics.
///         src.set_len(0);
///
///         // Dua daérah moal tiasa tumpang tindih sabab référénsi anu tiasa dirobih sanés alias, sareng dua béda vectors henteu tiasa gaduh mémori anu sami.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Ngabéjaan `dst` nu ayeuna nyepeng eusi `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Laksanakeun cék ieu ngan ukur dina waktos ngaji
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Teu panicking tetep dampak codegen leutik.
        abort();
    }*/

    // SAFETY: kontrak kaamanan pikeun `copy_nonoverlapping` kedahna
    // dijaga ku anu nelepon.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Nyalin `count * size_of::<T>()` bait tina `src` dugi `dst`.Sumber jeung tujuanana bisa tumpang tindih.
///
/// Upami sumber sareng tujuan na moal * pernah tumpang tindih, [`copy_nonoverlapping`] tiasa dianggo tibatan.
///
/// `copy` sacara sémantik sami sareng C's [`memmove`], tapi ku urutan arguménna ditukeurkeun.
/// Nyalin lumangsung saolah-olah bait anu disalin ti `src` ka Asép Sunandar Sunarya samentara teras disalin ti Asép Sunandar Sunarya ka `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `src` kedah janten [valid] pikeun maos tina `count * size_of::<T>()` bait.
///
/// * `dst` kedah [valid] kanggo nyerat bait `count * size_of::<T>()`.
///
/// * Duanana `src` sareng `dst` kedah leres dijajar.
///
/// Sapertos [`read`], `copy` nyiptakeun salinan bitwise `T`, henteu paduli naha `T` nyaéta [`Copy`].
/// Upami `T` sanés [`Copy`], nganggo duanana nilai di daérah anu dimimitian dina `*src` sareng daérah anu dimimitian dina `* dst` tiasa [violate memory safety][read-ownership].
///
///
/// Catetan yen sanajan ukuran éféktif disalin (`cacah * size_of: :<T>()`) nyaéta `0`, petunjuk kedah non-NULL sareng leres dijajarkeun.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Epektip nyieun hiji Rust vector ti hiji panyangga unsafe:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` kedah leres-leres dijantenkeun pikeun jinisna sareng henteu nol.
/// /// * `ptr` kedah janten valid pikeun maos tina `elts` elemen contiguous sahiji jenis `T`.
/// /// * Unsur-unsur éta henteu kedah dianggo saatos nelepon fungsi ieu kecuali `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // Kasalametan: kami prasarat ensures sumberna ieu Blok sarta sah,
///     // sareng `Vec::with_capacity` mastikeun yén urang ngagaduhan rohangan anu tiasa dianggo pikeun nyerat aranjeunna.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KESELAMATAN: Kami nyiptakeunana kalayan sakedik kapasitas ieu,
///     // jeung `copy` saméméhna geus initialized elemen ieu.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Laksanakeun cék ieu ngan ukur dina waktos ngaji
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Teu panicking tetep dampak codegen leutik.
        abort();
    }*/

    // Kasalametan: kontrak kaamanan pikeun `copy` kudu upheld ku panelepon.
    unsafe { copy(src, dst, count) }
}

/// Susunan `count * size_of::<T>()` bait memori dimimitian di `dst` mun `val`.
///
/// `write_bytes` nyaéta sarupa C urang [`memset`] tapi susunan `count * size_of::<T>()` bait ka `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Kabiasaan ieu undefined lamun salah sahiji kaayaan handap dilanggar:
///
/// * `dst` kedah [valid] kanggo nyerat bait `count * size_of::<T>()`.
///
/// * `dst` kudu Blok leres.
///
/// Sajaba ti, panelepon kudu mastikeun yén nulis `count * size_of::<T>()` bait ka wilayah tinangtu hasil memori dina nilai valid of `T`.
/// Maké wewengkon memori diketik salaku `T` nu ngandung hiji nilai sah ngeunaan `T` nyaeta kabiasaan undefined.
///
/// Catet yén sanajan ukuranana disalin kalayan efektif (`count * size_of: :<T>()`) Nyaéta `0`, pointer kudu non-hypothesis sarta Blok leres.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Nyiptakeun nilai anu henteu valid:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Leaks nilai dilaksanakeun samemehna ku overwriting nu `Box<T>` ku pointer hypothesis.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Dina tahap ieu, ngagunakeun atawa muterna hasil `v` dina kabiasaan undefined.
/// // drop(v); // ERROR
///
/// // Malah bocor `v` "uses" dinya, sarta ku kituna aya kabiasaan undefined.
/// // mem::forget(v); // ERROR
///
/// // Nyatana, `v` henteu valid numutkeun invariants perenah jinis dasar, janten *naon waé* operasi anu némpél nyaéta kalakuan anu teu ditangtoskeun.
/////
/// // hayu v2 =v;//ERROR
///
/// unsafe {
///     // Hayu urang gantina nempatkeun dina nilai anu valid
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ayeuna kotakna henteu kunanaon
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // Kasalametan: kontrak kaamanan pikeun `write_bytes` kudu upheld ku panelepon.
    unsafe { write_bytes(dst, val, count) }
}