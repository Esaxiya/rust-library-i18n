//! Fungsionalitas pikeun nyusun jeung perbandingan.
//!
//! Modul ieu ngandung sababaraha alat pikeun mesen sareng ngabandingkeun nilaina.Ringkesanana:
//!
//! * [`Eq`] sareng [`PartialEq`] mangrupikeun traits anu ngamungkinkeun anjeun pikeun ngartikeun persamaan total sareng parsial antara nilai, masing-masing.
//! Ngalaksanakeun éta langkung seueur teuing operator `==` sareng `!=`.
//! * [`Ord`] sareng [`PartialOrd`] mangrupikeun traits anu ngamungkinkeun anjeun netepkeun susunan total sareng parsial antara nilai, masing-masing.
//!
//! Ngalaksanakeun éta overload operator `<`, `<=`, `>`, sareng `>=`.
//! * [`Ordering`] mangrupikeun enum anu dibalikeun ku fungsi utama [`Ord`] sareng [`PartialOrd`], sareng ngajelaskeun hiji urutan.
//! * [`Reverse`] mangrupakeun struct nu ngidinan Anjeun pikeun gampang ngabalikeun hiji nyusun.
//! * [`max`] sareng [`min`] mangrupikeun fungsi anu ngawangun [`Ord`] sareng ngamungkinkeun anjeun mendakan maksimal atanapi minimum dua nilai.
//!
//! Kanggo langkung seueur detil, tingali dokuméntasi masing-masing kanggo unggal barang dina daptar.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait pikeun babandinganana sami sareng [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait Hal ieu ngamungkinkeun for sarua parsial, pikeun jenis nu teu boga sarua hubungan pinuh.
/// Contona, dina nomer floating titik `NaN != NaN`, jadi jenis floating titik nerapkeun `PartialEq` tapi teu [`trait@Eq`].
///
/// Formal, sarua kudu (pikeun sakabéh `a`, `b`, `c` sahiji jenis `A`, `B`, `C`):
///
/// - **symmetric**: lamun `A: PartialEq<B>` na `B: PartialEq<A>`, teras **`hiji==b` ngakibatkeun`b==a`**;jeung
///
/// - **Transitif**: upami `A: PartialEq<B>` sareng `B: PartialEq<C>` sareng `A:
///   Parsial<C>`, Teras **` hiji b`==na `b == c` ngakibatkeun`hiji==c`**.
///
/// Catet yén `B: PartialEq<A>` (symmetric) sareng `A: PartialEq<C>` (transitive) impls henteu dipaksakeun aya, tapi syarat ieu diterapkeun iraha waé ayana.
///
/// ## Derivable
///
/// trait ieu tiasa dianggo nganggo `#[derive]`.Nalika `turunan`d dina strukture, dua instansi sami upami sadaya bidang sami, sareng henteu sami upami bidangna henteu sami.Nalika `turunan`d dina enums, unggal varian sami sareng dirina sareng henteu sami sareng varian anu sanés.
///
/// ## Kumaha kuring tiasa nerapkeun `PartialEq`?
///
/// `PartialEq` ngan ukur peryogi metode [`eq`] pikeun dilaksanakeun;[`ne`] dihartikeun dina hal éta sacara standar.Sagala palaksanaan manual [`ne`]*kedah* hormat aturan yén [`eq`] mangrupikeun tibalik ketat [`ne`];nyaéta, `!(a == b)` upami sareng ngan upami `a != b`.
///
/// Implementations of `PartialEq`, [`PartialOrd`], sarta [`Ord`]*must* satuju saling.Ieu gampang keur ngahaja nyieun eta satuju ku deriving sababaraha traits na sacara manual ngalaksanakeun batur.
///
/// Conto palaksanaan pikeun domain di mana dua buku dianggap buku anu sami upami ISBN na cocog, sanajan formatna bénten:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kumaha carana kuring ngabandingkeun dua jinis anu sanés?
///
/// Jenis anu anjeun tiasa ngabandingkeun dikawasa ku parameter jinis `PartialEq`.
/// Salaku conto, hayu urang ngarobih kode urang sateuacanna sakedik:
///
/// ```
/// // Nurunkeun panerapan<BookFormat>==<BookFormat>babandinganana
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Laksanakeun<Book>==<BookFormat>babandinganana
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Laksanakeun<BookFormat>==<Book>babandinganana
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Ku cara ngarobah `impl PartialEq for Book` mun `impl PartialEq<BookFormat> for Book` kami ngidinan `BookFormat`s bisa dibandingkeun kalawan`Book`s.
///
/// Babandingan sapertos anu di luhur, anu teu merhatoskeun sababaraha bidang strukturna, tiasa bahaya.Éta tiasa sacara gampil ngakibatkeun pelanggaran anu teu dihaja pikeun sarat pikeun hubungan kasetaraan parsial.
/// Salaku conto, upami urang nyimpen palaksanaan `PartialEq<Book>` di luhur pikeun `BookFormat` sareng nambihan palaksanaan `PartialEq<Book>` pikeun `Book` (naha ngalangkungan `#[derive]` atanapi ngalangkungan palaksanaan manual tina conto munggaran) maka hasilna bakal ngalanggar transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Cara ieu tés pikeun nilai `self` sareng `other` sami, sareng dianggo ku `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Metoda ieu tés pikeun `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Nurunkeun makro ngahasilkeun impl tina trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait pikeun babandinganana sami sareng [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Ieu hartosna, salian ti `a == b` sareng `a != b` janten tibalik anu ketat, persamaanna kedah (pikeun sadaya `a`, `b` sareng `c`):
///
/// - reflexive: `a == a`;
/// - simétri: `a == b` ngakibatkeun `b == a`;jeung
/// - transitif: `a == b` sareng `b == c` ngakibatkeun `a == c`.
///
/// Sipat ieu teu tiasa dipariksa ku panyusun, sahingga `Eq` ngakibatkeun [`PartialEq`], sareng teu ngagaduhan metode tambahan.
///
/// ## Derivable
///
/// trait ieu tiasa dianggo nganggo `#[derive]`.
/// Nalika `turunan`d, kusabab `Eq` teu ngagaduhan metode tambahan, éta ngan ukur nganpikeun kompiler yén ieu mangrupikeun hubungan kasetaraan tibatan hubungan parsial persamaan.
///
/// Catet yén strategi `derive` meryogikeun sadaya bidang nyaéta `Eq`, anu henteu sering dipikahoyong.
///
/// ## Kumaha carana abdi tiasa nerapkeun `Eq`?
///
/// Lamun anjeun teu bisa maké strategi `derive`, tangtukeun nu Anjeun tipe implements `Eq`, nu boga padika:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // Metoda ieu dipake solely ku#[deriving] pikeun ngeceskeun yen unggal komponén hiji tipe implements#[deriving] téa, hartosna infrastruktur deriving ayeuna lakukeun Cindekna ieu tanpa ngagunakeun padika dina trait ieu ampir teu mungkin.
    //
    //
    // Ieu kedah pernah dilaksanakeun ku tangan.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Nurunkeun makro ngahasilkeun impl tina trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: strukturna ieu dianggo ngan ukur ku#[nurunkeun] ka
// negeskeun yén unggal komponén tina hiji jinis ngalaksanakeun Persamaan.
//
// struct Ieu kedah pernah muncul dina kode pamaké.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` mangrupikeun hasil tina perbandingan antara dua nilai.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Hiji nyusun dimana a nilai dibandingkeun nyaeta kirang ti nu sejen.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Pesenan numana nilai dibandingkeun sami sareng anu sanés.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Pesenan numana nilai dibandingkeun langkung ageung tibatan anu sanés.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Mulih `true` lamun nyusun mangrupa variasi `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Mulih `true` upami mesen sanés varian `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Mulih `true` upami mesen mangrupikeun varian `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Mulih `true` upami mesen mangrupikeun varian `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Mulih `true` upami mesenna boh `Less` atanapi `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Mulih `true` lamun nyusun éta téh boh `Greater` atanapi `Equal` varian.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Reverses nu `Ordering`.
    ///
    /// * `Less` janten `Greater`.
    /// * `Greater` janten `Less`.
    /// * `Equal` janten `Equal`.
    ///
    /// # Examples
    ///
    /// Paripolah dasar:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Cara ieu tiasa dianggo pikeun ngabalikeun perbandingan:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // milah susunan tina panggedéna dugi ka pangleutikna.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Ranté dua urutan.
    ///
    /// Mulih `self` nalika sanés `Equal`.Upami teu kitu mulih `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Ranté mesen ku fungsi anu dibéré.
    ///
    /// Mulih `self` nalika sanés `Equal`.
    /// Upami henteu nyauran `f` sareng mulih hasilna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Struktur pembantu pikeun mesen mundur.
///
/// Struktur ieu mangrupikeun pembantun anu dianggo kalayan fungsi sapertos [`Vec::sort_by_key`] sareng tiasa dianggo pikeun ngabalikkeun urutan bagian konci.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait pikeun jinis anu ngawangun [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Pesenan mangrupikeun urutan total upami éta (pikeun sadaya `a`, `b` sareng `c`):
///
/// - total na asimétri: persis salah sahiji `a < b`, `a == b` atanapi `a > b` bener;jeung
/// - transitif, `a < b` sareng `b < c` ngakibatkeun `a < c`.Sarua kedah tahan pikeun `==` sareng `>`.
///
/// ## Derivable
///
/// trait ieu tiasa dianggo nganggo `#[derive]`.
/// Nalika `derive`d on structs, éta baris ngahasilkeun nyusun [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) dumasar kana luhureun-to-handap deklarasi urutan sahiji anggota dina struct urang.
///
/// Nalika `turunan`d dina enums, varian dipesen ku urutan diskriminasi luhur-ka-handapna.
///
/// ## Babandingan léksikografi
///
/// Babandingan léksikografi mangrupikeun operasi sareng sipat-sipat ieu:
///  - Dua sekuen dibandingkeun unsur ku unsur.
///  - Unsur anu teu cocog mimitina ngahartikeun sekuen mana anu lexicographically kirang atanapi langkung ageung tibatan anu sanés.
///  - Lamun hiji runtuyan nyaéta awalan ti nu sejen, sekuen pondok nyaéta lexicographically kurang lianna.
///  - Upami dua sekuen gaduh unsur-unsur anu sami sareng sami panjang, maka sekuenna sacara leksikografis sami.
///  - Urutan kosong sacara leksikografis kirang langkung tina sekuen anu kosong.
///  - Dua sekuen kosong sacara leksikografis sami.
///
/// ## Kumaha kuring tiasa nerapkeun `Ord`?
///
/// `Ord` ngabutuhkeun jinisna ogé [`PartialOrd`] sareng [`Eq`] (anu meryogikeun [`PartialEq`]).
///
/// Maka anjeun kedah nangtoskeun palaksanaan pikeun [`cmp`].Anjeun tiasa mendakan gunana [`cmp`] dina bidang anjeun.
///
/// Palaksanaan [`PartialEq`], [`PartialOrd`], sareng `Ord`*kedah* satuju sareng anu sanésna.
/// Hartina, `a.cmp(b) == Ordering::Equal` lamun jeung ukur lamun `a == b` na `Some(a.cmp(b)) == a.partial_cmp(b)` pikeun sakabéh `a` na `b`.
/// Gampang ngahaja ngajantenkeun aranjeunna henteu satuju ku nurunkeun sababaraha traits sareng sacara manual nerapkeun batur.
///
/// Di dieu hiji conto dimana rék nyortir urang ku jangkungna ukur, disregarding `id` na `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Metoda ieu ngabalikeun [`Ordering`] antara `self` sareng `other`.
    ///
    /// Ku konvénsi, `self.cmp(&other)` balikkeun pesenan anu cocog sareng ungkapan `self <operator> other` upami leres.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Ngabandingkeun sareng mulih maksimal dua nilai.
    ///
    /// Balikkeun argumén anu kadua upami ngabandingkeun éta netepkeun sami.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Ngabandingkeun sareng ngabalikeun sahenteuna dua nilai.
    ///
    /// Mulih argumen mimitina lamun ngabandingkeun nangtukeun aranjeunna janten sarua.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Ngawatesan nilai kana interval anu tangtu.
    ///
    /// Mulih `max` upami `self` langkung ageung tibatan `max`, sareng `min` upami `self` kirang ti `min`.
    /// Upami teu kitu ieu mulih `self`.
    ///
    /// # Panics
    ///
    /// Panics lamun `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// macro diturunkeun generating hiji impl tina trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait keur nilai nu bisa dibandingkeun pikeun diurutkeun-urutan.
///
/// ngabandingkeun nu kudu puas, pikeun sakabéh `a`, `b` na `c`:
///
/// - asymmetry: lamun `a < b` lajeng `!(a > b)`, kitu ogé `a > b` implying `!(a < b)`;jeung
/// - transitivity: `a < b` na `b < c` ngakibatkeun `a < c`.Sarua kedah tahan pikeun `==` sareng `>`.
///
/// Catet yén sarat ieu hartosna yén trait nyalira kedah dilaksanakeun sacara simétris sareng transitif: upami `T: PartialOrd<U>` sareng `U: PartialOrd<V>` maka `U: PartialOrd<T>` sareng `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait Ieu bisa dipaké kalawan `#[derive]`.Nalika `derive`d on structs, éta baris ngahasilkeun nyusun lexicographic dumasar kana luhureun-to-handap deklarasi urutan sahiji anggota dina struct urang.
/// Nalika `turunan`d dina enums, varian dipesen ku urutan diskriminasi luhur-ka-handapna.
///
/// ## Kumaha kuring tiasa nerapkeun `PartialOrd`?
///
/// `PartialOrd` ngan ukur peryogi palaksanaan metode [`partial_cmp`], anu sanésna dihasilkeun tina standar panerapan.
///
/// Nanging tetep dimungkinkeun pikeun nerapkeun anu sanés nyalira pikeun jinis anu teu ngagaduhan urutan total.
/// Contona, keur angka floating titik, `NaN < 0 == false` na `NaN >= 0 == false` (cf.
/// IEEE 754-2008 bagian 5.11).
///
/// `PartialOrd` peryogi jinis anjeun janten [`PartialEq`].
///
/// Palaksanaan [`PartialEq`], `PartialOrd`, sareng [`Ord`]*kedah* satuju sareng anu sanésna.
/// Gampang ngahaja ngajantenkeun aranjeunna henteu satuju ku nurunkeun sababaraha traits sareng sacara manual nerapkeun batur.
///
/// Mun tipe anjeun [`Ord`], anjeun tiasa nerapkeun [`partial_cmp`] ku ngagunakeun [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Anjeun tiasa ogé nguntungkeun pikeun nganggo [`partial_cmp`] dina widang tipeu anjeun.
/// Di handap ieu conto tina jenis `Person` anu boga floating-titik médan `height` nu mangrupakeun hiji-hijina lapang pikeun dipaké pikeun asihan:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Metoda ieu mulih hiji nyusun antara nilai `self` na `other` lamun salah aya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Nalika ngabandingkeun mustahil:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Cara ieu tés kirang tina (pikeun `self` sareng `other`) sareng dianggo ku operator `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Metoda tés ieu kurang atawa sarua jeung (pikeun `self` na `other`) jeung anu dipaké ku operator `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Metoda ieu tés gede ti (pikeun `self` na `other`) jeung anu dipaké ku operator `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Metoda ieu tés gede ti atanapi sarua jeung (pikeun `self` na `other`) jeung anu dipaké ku operator `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// macro diturunkeun generating hiji impl tina trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Ngabandingkeun sareng ngabalikeun sahenteuna dua nilai.
///
/// Mulih argumen mimitina lamun ngabandingkeun nangtukeun aranjeunna janten sarua.
///
/// Internal migunakeun hiji landian pikeun [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Mulih minimum dua nilai perkawis fungsi ngabandingkeun anu parantos ditangtoskeun.
///
/// Mulih argumen mimitina lamun ngabandingkeun nangtukeun aranjeunna janten sarua.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Mulih unsur nu méré nilai minimum tina fungsi husus.
///
/// Mulih argumen mimitina lamun ngabandingkeun nangtukeun aranjeunna janten sarua.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Ngabandingkeun sareng mulih maksimal dua nilai.
///
/// Balikkeun argumén anu kadua upami ngabandingkeun éta netepkeun sami.
///
/// Internal nganggo landian pikeun [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Mulih maksimal dua nilai perkawis fungsi babandingan anu ditetepkeun.
///
/// Balikkeun argumén anu kadua upami ngabandingkeun éta netepkeun sami.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Mulih unsur anu masihan nilai maksimum tina fungsi anu parantos ditangtukeun.
///
/// Balikkeun argumén anu kadua upami ngabandingkeun éta netepkeun sami.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Palaksanaan PartialEq, Eq, PartialOrd sareng Ord pikeun jinis primitif
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Urutan didieu penting pikeun ngahasilkeun perakitan anu langkung optimal.
                    // Tempo <https://github.com/rust-lang/rust/issues/63758> pikeun info leuwih lengkep.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Matak kana i8 sareng ngarobih bédana kana Pesenan ngahasilkeun perakitan anu langkung optimal.
            //
            // Tingali <https://github.com/rust-lang/rust/issues/66780> kanggo langkung seueur inpo.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool sakumaha i8 mulih 0 atanapi 1, janten bédana na tiasa sanés nanaon
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &panunjuk

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}