//! Tali Pola API.
//!
//! Pola API nyayogikeun mékanisme generik pikeun ngagunakeun sababaraha jinis pola nalika milarian senar.
//!
//! Pikeun leuwih rinci, ningali traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], sarta [`DoubleEndedSearcher`].
//!
//! Sanajan API ieu stabil, mangka kakeunaan via API stabil dina tipe [`str`].
//!
//! # Examples
//!
//! [`Pattern`] nyaéta [implemented][pattern-impls] dina API stabil pikeun [`&str`][`str`], [`char`], keureut [`char`], sareng fungsi sareng panutupan ngalaksanakeun `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // pola char
//! assert_eq!(s.find('n'), Some(2));
//! // keureutan pola chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // pola panutupan
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Pola senar.
///
/// `Pattern<'a>` nyatakeun yén tipeu anu ngalaksanakeun tiasa dianggo salaku pola senar pikeun milarian [`&'a str`][str].
///
/// Salaku conto, duanana `'a'` sareng `"aa"` mangrupikeun pola anu cocog sareng indéks `1` dina senar `"baaaab"`.
///
/// The trait sorangan tindakan salaku pembina pikeun hiji jenis [`Searcher`] pakait, anu teu karya sabenerna nyungsi kajadian anu lumangsungna di pola dina senar a.
///
///
/// Gumantung kana jinis pola na, paripolah cara sapertos [`str::find`] sareng [`str::contains`] tiasa robih.
/// tabél di handap ngajelaskeun sababaraha paripolah jalma.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Pamasaran anu pakait pikeun pola ieu
    type Searcher: Searcher<'a>;

    /// Nyusunna anu milarian anu pakait ti `self` sareng `haystack` pikeun milarian.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Pariksa naha pola cocog mana waé di tumpukan jarami
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Pariksa naha pola cocog di payuneun tumpukan jukut
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Cék naha pola nu cocog di tukang tumpukan jukut nu
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Ngaluarkeun pola ti hareup tumpukan jukut, upami eta cocog.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SAFETY: `Searcher` dipikaterang mulang indéks anu sah.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Ngaluarkeun pola ti tukang tumpukan jukut, upami eta cocog.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SAFETY: `Searcher` dipikaterang mulang indéks anu sah.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Hasil nelepon [`Searcher::next()`] atanapi [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Expresses yén hiji patandingan tina pola nu geus kapanggih di `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Nyarios yén `haystack[a..b]` parantos ditolak salaku kamungkinan patandingan tina pola.
    ///
    /// Catet yén meureun aya langkung ti hiji `Reject` antara dua `Match`es, teu aya syarat pikeun aranjeunna digabungkeun janten hiji.
    ///
    ///
    Reject(usize, usize),
    /// Nyatakeun yén unggal bait tumpukan jarami parantos didatangan, mungkas iterasi.
    ///
    Done,
}

/// A milarian pola senar.
///
/// trait ieu nyayogikeun metode pikeun milarian pertandingan anu teu tumpang tindih tina pola mimitian ti hareup (left) tina senar.
///
/// Éta bakal dilaksanakeun ku jinis `Searcher` pakait tina [`Pattern`] trait.
///
/// The trait ieu ditandaan unsafe sabab indéks dipulang ku metodeu [`next()`][Searcher::next] diwajibkeun bohong dina wates utf8 valid dina tumpukan jukut nu.
/// Ieu ngamungkinkeun konsumén trait ieu pikeun nyiksikan tumpukan jarami tanpa pamariksaan runtime tambahan.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter pikeun tali anu tiasa dipilarian
    ///
    /// Bakal salawasna balikkeun [`&str`][str] anu sami.
    fn haystack(&self) -> &'a str;

    /// Laksanakeun léngkah milarian salajengna mimitian ti payun.
    ///
    /// - Mulih [`Match(a, b)`][SearchStep::Match] upami `haystack[a..b]` cocog sareng pola.
    /// - Mulih [`Reject(a, b)`][SearchStep::Reject] upami `haystack[a..b]` henteu tiasa cocog sareng pola, bahkan sawaréh.
    /// - Mulih [`Done`][SearchStep::Done] lamun unggal bait tina tumpukan jukut nu geus dilongok.
    ///
    /// Aliran nilai [`Match`][SearchStep::Match] sareng [`Reject`][SearchStep::Reject] dugi ka [`Done`][SearchStep::Done] bakal ngandung rentang indéks anu padeukeut, henteu tumpang tindih, nutupan sakumna tumpukan jerami, sareng nempatkeun wates utf8.
    ///
    ///
    /// Hasil [`Match`][SearchStep::Match] kedah ngandung pola anu cocog, tapi hasilna [`Reject`][SearchStep::Reject] tiasa dibagi kana sawenang-wenang fragmen anu padeukeut.Duanana Bulan mungkin gaduh enol panjangna.
    ///
    /// Salaku conto, pola `"aaa"` sareng tumpukan jarami `"cbaaaaab"` panginten ngahasilkeun aliranna
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Milarian hasil [`Match`][SearchStep::Match] salajengna.Tingali [`next()`][Searcher::next].
    ///
    /// Teu kawas [`next()`][Searcher::next], taya jaminan yén Bulan balik ti [`next_reject`][Searcher::next_reject] ieu sareng bakal tumpang tindih.
    /// Ieu bakal balikkeun `(start_match, end_match)`, dimana start_match mangrupikeun indéks dimana pertandingan dimimitian, sareng end_match mangrupikeun indéks saatos akhir pertandingan.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Milarian hasil [`Reject`][SearchStep::Reject] salajengna.Tempo [`next()`][Searcher::next] na [`next_match()`][Searcher::next_match].
    ///
    /// Beda sareng [`next()`][Searcher::next], teu aya jaminan yén rentang-rentang anu balik tina ieu sareng [`next_match`][Searcher::next_match] bakal tumpang tindih.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// A pencari balik pikeun pola senar.
///
/// trait ieu nyayogikeun metode pikeun milarian pertandingan anu teu tumpang tindih tina pola mimitian ti tukang (right) tina senar.
///
/// Éta bakal dilaksanakeun ku jinis [`Searcher`] pakait tina [`Pattern`] trait upami pola na nyokong milari deui.
///
///
/// Rentang indéks anu dibalikeun ku trait ieu henteu diperyogikeun pikeun cocog pisan sareng anu dipilarian payun sacara tibalik.
///
/// Kusabab kitu trait ieu ditandaan teu aman, tingali aranjeunna indungna trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Laksanakeun léngkah milarian salajengna mimitian ti tukang.
    ///
    /// - Mulih [`Match(a, b)`][SearchStep::Match] upami `haystack[a..b]` cocog sareng pola.
    /// - Mulih [`Reject(a, b)`][SearchStep::Reject] upami `haystack[a..b]` henteu tiasa cocog sareng pola, bahkan sawaréh.
    /// - Balikkeun [`Done`][SearchStep::Done] upami unggal bait tumpukan jarami parantos didatangan
    ///
    /// Aliran nilai [`Match`][SearchStep::Match] sareng [`Reject`][SearchStep::Reject] dugi ka [`Done`][SearchStep::Done] bakal ngandung rentang indéks anu padeukeut, henteu tumpang tindih, nutupan sakumna tumpukan jerami, sareng nempatkeun wates utf8.
    ///
    ///
    /// Hasil [`Match`][SearchStep::Match] kedah ngandung pola anu cocog, tapi hasilna [`Reject`][SearchStep::Reject] tiasa dibagi kana sawenang-wenang fragmen anu padeukeut.Duanana Bulan mungkin gaduh enol panjangna.
    ///
    /// Salaku conto, pola `"aaa"` sareng jarami `"cbaaaaab"` panginten ngahasilkeun aliran `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Milarian hasil [`Match`][SearchStep::Match] salajengna.
    /// Tingali [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Manggih hasil [`Reject`][SearchStep::Reject] salajengna.
    /// Tingali [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Pananda trait pikeun nganyatakeun yén [`ReverseSearcher`] tiasa dianggo pikeun panerapan [`DoubleEndedIterator`].
///
/// Keur kitu, di impl of [`Searcher`] na [`ReverseSearcher`] kudu nuturkeun kaayaan ieu:
///
/// - Kabéh hasil `next()` kudu jadi sarua jeung hasil `next_back()` dina urutan sabalikna.
/// - `next()` sareng `next_back()` kedah berperilaku salaku dua tungtung sauntuyan nilai, nyaéta aranjeunna henteu tiasa "walk past each other".
///
/// # Examples
///
/// `char::Searcher` mangrupikeun `DoubleEndedSearcher` sabab milarian [`char`] ngan ukur peryogi ningali hiji-hiji, anu kalakuanana sami tina dua tungtung.
///
/// `(&str)::Searcher` sanés `DoubleEndedSearcher` sabab pola `"aa"` dina tumpukan hayam `"aaa"` cocog sareng `"[aa]a"` atanapi `"a[aa]"`, gumantung ti sisi mana anu dipilarian.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Ngalaksanakeun pikeun char
/////////////////////////////////////////////////////////////////////////////

/// Jenis anu pakait pikeun `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant safety: `finger`/`finger_back` kedah janten indéks byte utf8 `haystack` invariant ieu tiasa dipecah *dina* next_match sareng next_match_back, nanging aranjeunna kedah kaluar nganggo ramo dina wates titik kode anu valid.
    //
    //
    /// `finger` nyaéta indéks bait ayeuna tina pilarian hareup.
    /// Ngabayangkeun nu eta aya méméh bait dina indéks na, nyaéta
    /// `haystack[finger]` teh bait mimiti nyiksikan teh urang kudu mariksa mangsa néangan maju
    ///
    finger: usize,
    /// `finger_back` nyaéta indéks bait ayeuna tina milarian tibalik.
    /// Ngabayangkeun nu eta aya sanggeus bait dina indéks na, nyaéta
    /// haystack [finger_back, 1] mangrupikeun bait terakhir tina keureutan anu urang kedah diperhatoskeun nalika dipilarian payun (sahingga bait anu munggaran anu kedah diparios nalika nelepon next_back()).
    ///
    finger_back: usize,
    /// karakter nu keur searched pikeun
    needle: char,

    // invariant kaamanan: `utf8_size` kedah kirang ti 5
    /// Jumlah bait `needle` nyokot up nalika disandikeun di utf8.
    utf8_size: usize,
    /// Salin utf8 énkode `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // Kaamanan: 1-4 ngajamin kasalametan `get_unchecked`
        // 1. `self.finger` sareng `self.finger_back` dijaga dina wates unicode (ieu henteu sah)
        // 2. `self.finger >= 0` saprak éta dimimitian dina 0 na ngan nambahan
        // 3. `self.finger < self.finger_back` sabab upami henteu éta char `iter` bakal balikkeun `SearchStep::Done`
        // 4.
        // `self.finger` datang méméh tungtung tumpukan jarami sabab `self.finger_back` dimimitian di tungtung sareng ngan ukur turun
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // tambahkeun byte offset karakter ayeuna tanpa enkode ulang salaku utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // kéngingkeun tumpukan jarami saatos karakter terakhir dipendakan
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // bait panungtungan tina utf8 jarum anu dikodekeun SAFETY: kami ngagaduhan invarian anu `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Ramo énggal mangrupikeun indéks tina bait anu kami mendakan, tambah hiji, kumargi kami mémo pikeun bait terakhir karakter éta.
                //
                // Catet yén ieu henteu salawasna masihan kami ramo dina wates UTF8.
                // Upami urang henteu * mendakan karakter urang, urang panginten parantos diindéks kana bait anu henteu terakhir tina karakter 3-byte atanapi 4-byte.
                // Kami henteu ngan saukur tiasa ngalangkungan bait awal anu valid salajengna kusabab karakter sapertos ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` bakal masihan urang teras-terasan milarian byte kadua nalika milarian anu katilu.
                //
                //
                // Nanging, ieu leres-leres henteu kunanaon.
                // Nalika kami ngagaduhan invariant yén self.finger aya dina wates UTF8, invarian ieu henteu diandelkeun dina metode ieu (éta diandelkeun dina CharSearcher::next()).
                //
                // Kami ngan ukur kaluar tina metoda ieu nalika dugi ka tungtung senar, atanapi upami kami mendakan hal.Lamun urang manggihan hal nu `finger` bakal diatur ka wates UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // teu kapendak nanaon, kaluar
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // hayu next_reject nganggo palaksanaan standar ti Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // Kasalametan: ningali comment pikeun next() luhur
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // kurangan byte offset tina karakter ayeuna tanpa énkode ulang salaku utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // meunangkeun tumpukan jukut nepi ka tapi teu kaasup karakter panungtungan searched
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // bait panungtungan tina utf8 jarum anu dikodekeun SAFETY: kami ngagaduhan invarian anu `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // urang milarian sapotong anu diimbangi ku self.finger, nambihan self.finger kanggo ngarangkep indéks aslina
                //
                let index = self.finger + index;
                // memrchr bakal balik indéks tina bait keukeuh we neangan.
                // Dina kasus karakter ASCII, ieu memang kami miharep ramo anyar kami janten ("after" char anu dipendakan dina paradigma pengulangan mundur).
                //
                // Pikeun chars multibyte kami kedah ngalangkungan jumlah byte langkung anu dipiboga ti ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // mindahkeun ramo kana saméméh karakter nu kapanggih (ie, dina indéks mimiti na)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Kami henteu tiasa nganggo finger_back=index, size + 1 di dieu.
                // Upami urang mendakan char terakhir karakter anu bénten ukuran (atanapi bait tengah karakter anu sanés) urang kedah nabrak jari_balik ka `index`.
                // Hal ieu sami-sami ngajantenkeun `finger_back` gaduh poténsial pikeun teu aya deui dina wates, tapi ieu henteu kunanaon kusabab urang ngan ukur kaluar tina fungsi ieu dina wates atanapi nalika tumpukan jerami parantos dipilarian lengkep.
                //
                //
                // Beda sareng next_match ieu henteu ngagaduhan masalah bait anu diulang dina utf-8 kumargi urang milari bait terakhir, sareng kami ngan ukur tiasa mendakan byte terakhir nalika milarian tibalik.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // teu kapendak nanaon, kaluar
                return None;
            }
        }
    }

    // hayu next_reject_back nganggo palaksanaan standar ti Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Milarian chars anu sami sareng [`char`] tinangtu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl pikeun wrapper MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Bandingkeun tebih tina internal iterator bait nyiksikan pikeun manggihan panjang char ayeuna
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Bandingkeun tebih tina internal iterator bait nyiksikan pikeun manggihan panjang char ayeuna
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl keur&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Ngarobih/Cabut kusabab ambiguitas dina hartos.

/// Jenis anu pakait pikeun `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Milarian chars anu sami sareng salah sahiji [`char`] s di irisan.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pikeun F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Jenis anu pakait pikeun `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Milarian [`char`] s anu cocog sareng prédikat anu dipasihkeun.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Ngalaksanakeun pikeun&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegasi ka `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl pikeun &str
/////////////////////////////////////////////////////////////////////////////

/// Milarian substring anu henteu dikaluarkeun.
///
/// Bakal nanganan pola `""` nalika balikkeun pertandingan kosong dina unggal wates karakter.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Pariksa naha pola cocog di payuneun tumpukan jukut.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Ngaluarkeun pola ti hareup tumpukan jukut, upami eta cocog.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SAFETY: awalan nembé diverifikasi aya.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Pariksa naha pola cocog di tukangeun jarami.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Ngaluarkeun pola ti tukang tumpukan jukut, upami eta cocog.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SAFETY: ahiran nembé diverifikasi aya.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Panyiar substring Dua Cara
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Pakait tipe pikeun `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // jarum kosong nolak unggal char sareng cocog sareng unggal senar kosong di antara aranjeunna
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ngahasilkeun *valid mana* indéks nu pamisah dina wates char salami hancana cocog bener jeung nu tumpukan jukut jeung jarum anu valid UTF-8 *Rejects* tina algoritma nu bisa digolongkeun kana indéks naon, tapi kami baris leumpang aranjeunna sacara manual ka wates karakter salajengna, supaya aranjeunna utf-8 aman.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // lalumpatan ka wates char salajengna
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // nyerat kasus `true` sareng `false` pikeun ngadorong panyusun pikeun ngahususkeun dua kasus nyalira.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // lalumpatan ka wates char salajengna
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // nyerat `true` sareng `false`, sapertos `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Kaayaan internal tina algoritma milarian substring dua arah.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indéks faktorisasi kritis
    crit_pos: usize,
    /// indéks faktorisasi kritis pikeun jarum dibalikkeun
    crit_pos_back: usize,
    period: usize,
    /// `byteset` mangrupa extension (teu bagian tina dua jalan terasna);
    /// éta mangrupikeun X-"fingerprint" 64-bit dimana unggal set `j` pakait sareng (bait&63)==j anu aya dina jarum.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indéks kana jarum sateuacanna urang parantos cocog
    memory: usize,
    /// indéks kana jarum satutasna urang parantos cocog
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Katerangan khusus anu tiasa dibaca ngeunaan naon anu lumangsung di dieu tiasa dipendakan dina buku Crochemore sareng Rytter "Text Algorithms", ch 13.
        // Husus ningali kode pikeun "Algorithm CP" dina h.
        // 323.
        //
        // Anu lumangsung nyaéta kami ngagaduhan sababaraha faktorisasi kritis (u, v) tina jarum, sareng kami hoyong nangtoskeun naha anjeun mangrupikeun ahiran tina&v [.. jaman].
        // Upami éta, urang nganggo "Algorithm CP1".
        // Upami urang ngagunakeun "Algorithm CP2", nu ieu dioptimalkeun pikeun nalika periode jarum nya badag.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kasus jaman pondok-jaman éta nyaéta ngitung hiji faktorisasi kritis misah pikeun jarum dibalikkeun x=u 'v' dimana | v '|<period(x).
            //
            // Ieu dipercepat ku jaman anu parantos dipikaterang.
            // Catet yén kasus sapertos x= "acba" tiasa didaptarkeun persis payun (crit_pos=1, period=3) bari dicandak faktual perkiraan waktos tibalik (crit_pos=2, period=2).
            // Kami nganggo faktorisasi tibalik anu ditangtoskeun tapi tetep dina waktos anu pasti.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // kasus jangka panjang-urang ngagaduhan perkiraan kana periode anu saleresna, sareng henteu nganggo ngapalkeun.
            //
            //
            // Kira-kira période ku max(|u|, |v|) + 1 anu langkung handap.
            // The faktorisasi kritis mangrupakeun efisien ngagunakeun pikeun duanana pilarian gancang sareng sabalikna.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Nilai dummy pikeun nandakeun yén waktuna panjang
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Salah sahiji ideu utama Dua-Jalan nyaéta urang ngukur jarum kana dua beulahan, (u, v), sareng mimitian nyobian milarian v dina tumpukan jarami ku cara nyeken kénca ka katuhu.
    // Upami pertandingan v cocog, urang cobian cocog sareng anjeun ku nyeken katuhu ka kénca.
    // Sabaraha jauh urang bisa luncat lamun urang sapatemon mismatch hiji sakabéh dumasar kana kanyataan yén (u, v) mangrupakeun faktorisasi kritis pikeun jarum.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` ngagunakeun `self.position` salaku kursor na
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Pariksa yén urang gaduh rohangan pikeun milarian dina posisi + jarum_last moal tiasa kabanjiran upami urang nganggap irisan diwatesan ku kisaran isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Gancang bolos ku porsi ageung teu aya hubunganana sareng substring urang
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Tingali naha bagian katuhu jarum cocog
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Lamun ningali bagian kénca ti patandingan jarum
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Kami parantos mendakan pertandingan!
            let match_pos = self.position;

            // Note: tambahkeun self.period tibatan needle.len() kanggo pertandingan anu tumpang tindih
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // disetel ka needle.len(), self.period pikeun patandingan tumpang tindih
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Nuturkeun ideu dina `next()`.
    //
    // Definisi na simétris, sareng period(x) = period(reverse(x)) sareng local_period(u, v) = local_period(reverse(v), reverse(u)), janten upami (u, v) mangrupikeun faktorisasi kritis, maka (reverse(v), reverse(u)).
    //
    //
    // Pikeun hal sabalikna kami geus diitung hiji kritis faktorisasi x=u 'v' (sawah `crit_pos_back`).Urang peryogi | u |<period(x) pikeun hal ka hareup sahingga | v '|<period(x) pikeun ngabalikkeun.
    //
    // Pikeun milarian dibalikkeun ngaliwatan tumpukan jukut, urang milarian maju ngaliwatan tumpukan jarami dibalikkeun sareng jarum dibalikkeun, cocog sareng u 'teras v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ngagunakeun `self.end` salaku kursor na-sahingga `next()` sareng `next_back()` bebas.
        //
        let old_end = self.end;
        'search: loop {
            // Pariksa yén urang gaduh rohangan kanggo milarian dina tungtungna, needle.len() bakal ngabungkus nalika teu aya deui kamar, tapi kusabab wates panjang potongan éta moal tiasa bungkus deui dugi ka panjang jarami.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Gancang bolos ku porsi ageung teu aya hubunganana sareng substring urang
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Lamun ningali bagian kénca ti patandingan jarum
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Tingali naha bagian katuhu jarum cocog
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Kami parantos mendakan pertandingan!
            let match_pos = self.end - needle.len();
            // Note: sub self.period tibatan needle.len() ngagaduhan patandingan tumpang tindih
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ngitung ahiran maksimal `arr`.
    //
    // Ahiran maksimal mangrupikeun kamungkinan faktorisasi (u, v) `arr`.
    //
    // Mulih (`i`, `p`) dimana `i` nyaéta indéks dimimitian tina v sarta `p` nyaeta periode v.
    //
    // `order_greater` nangtoskeun naha urutan leksikal `<` atanapi `>`.
    // Duanana pesenan kedah diitung-anu mesen ku `i` pangageungna masihan faktorisasi kritis.
    //
    //
    // Pikeun kasus jaman lila, periode hasilna teu pasti (teuing pondok).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Pakait jeung abdi di kertas
        let mut right = 1; // Cocog sareng j dina kertas
        let mut offset = 0; // Cocog sareng k dina kertas, tapi dimimitian dina 0
        // pikeun cocog sareng indéks basis 0.
        let mut period = 1; // Pakait jeung p dina kertas

        while let Some(&a) = arr.get(right + offset) {
            // `left` bakal asup nalika `right` nyaéta.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Akhiran anu langkung alit, jaman mangrupikeun awalan dugi ka ayeuna.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Maju ngalangkungan pengulangan jaman ayeuna.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Akhiran langkung ageung, mimitian ti lokasi ayeuna.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Ngitung ahiran maksimal tibalik `arr`.
    //
    // Ahiran maksimal mangrupikeun kamungkinan faktorisasi kritis (u ', v') `arr`.
    //
    // Mulih `i` dimana `i` mangrupikeun indéks awal v ', ti tukang;
    // balik deui langsung nalika waktos `known_period` kahontal.
    //
    // `order_greater` nangtoskeun naha urutan leksikal `<` atanapi `>`.
    // Duanana pesenan kedah diitung-anu mesen ku `i` pangageungna masihan faktorisasi kritis.
    //
    //
    // Pikeun kasus jaman lila, periode hasilna teu pasti (teuing pondok).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Pakait jeung abdi di kertas
        let mut right = 1; // Cocog sareng j dina kertas
        let mut offset = 0; // Cocog sareng k dina kertas, tapi dimimitian dina 0
        // pikeun cocog sareng indéks basis 0.
        let mut period = 1; // Pakait jeung p dina kertas
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Akhiran anu langkung alit, jaman mangrupikeun awalan dugi ka ayeuna.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Maju ngalangkungan pengulangan jaman ayeuna.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Akhiran langkung ageung, mimitian ti lokasi ayeuna.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ngamungkinkeun algoritma pikeun boh skip non-patandingan gancang-gancang, atawa karya dina modeu mana eta emits Rejects rélatif gancang.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Skip to cocog interval gancang-gancang
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Nolak rutin
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}