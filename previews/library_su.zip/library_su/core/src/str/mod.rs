//! String manipulasi.
//!
//! Kanggo langkung seueur detil, tingali modul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. kaluar tina wates
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ngamimitian <=tungtung
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. wates karakter
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // milari watekna
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` kedahna kirang ti len sareng wates char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Balikkeun panjang `self`.
    ///
    /// Panjang ieu aya dina bait, sanés [`char`] atanapi graphemes.
    /// Kalayan kecap séjén, panginten sanés anu dianggap manusa panjang tina senar.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // f f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Mulih `true` lamun `self` boga panjang enol bait.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Cék nu `index`-th bait teh bait kahiji dina UTF-8 kode titik sekuen atawa tungtung string anu.
    ///
    ///
    /// Mimiti sareng akhir senar (nalika `index== self.len()`) dianggap wates.
    ///
    /// Mulih `false` lamun `index` nyaeta gede ti `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // mimiti `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // bait kadua `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // bait katilu `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 sareng len sok ok.
        // Tes pikeun 0 sacara eksplisit sahingga tiasa ngaoptimalkeun cek anu gampang sareng ngalangkungan data string bacaan pikeun kasus éta.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ieu sakti sakti sareng: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Ngarobih irisan senar kana keureutan bait.
    /// Pikeun ngarobah éta bait nyiksikan deui kana nyiksikan string, nganggo fungsi [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // KESELAMATAN: disada sabab urang ngirimkeun dua jinis kalayan tata letak anu sami
        unsafe { mem::transmute(self) }
    }

    /// Ngarobah a string nyiksikan mutable ka nyiksikan bait mutable.
    ///
    /// # Safety
    ///
    /// Anu nelepon kedah mastikeun yén eusi keureut sah UTF-8 sateuacan injeuman réngsé sareng `str` anu janten dasarna dianggo.
    ///
    ///
    /// Pamakéan `str` anu eusina henteu sah UTF-8 mangrupikeun tingkah laku anu teu ditangtoskeun.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAFETY: anu matak ti `&str` dugi ka `&[u8]` aman ti `str`
        // ngagaduhan perenah anu sami sareng `&[u8]` (ngan ukur libstd anu tiasa ngajamin ieu).
        // Dereferénsi pointer aman sabab éta asalna tina rujukan anu tiasa dirobih anu dijamin valid pikeun nyerat.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Ngarobih sapotong senar kana pointer atah.
    ///
    /// Salaku string keureut nu nyiksikan bait, anu titik pointer atah ka [`u8`].
    /// Pointer ieu bakal nunjuk ka bait mimiti irisan senar.
    ///
    /// Anu nelepon kedah mastikeun yén panunjuk anu dipulangkeun henteu pernah nyerat.
    /// Upami anjeun kedah mutasi eusi irisan senar, anggo [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Ngarobah a string nyiksikan mutable ka pointer atah.
    ///
    /// Salaku string keureut nu nyiksikan bait, anu titik pointer atah ka [`u8`].
    /// Pointer ieu bakal nunjuk ka bait mimiti irisan senar.
    ///
    /// Éta tanggung jawab anjeun pikeun mastikeun yén potongan keureut ngan ukur dirobah ku cara tetep UTF-8 valid.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Mulang deui langganan `str`.
    ///
    /// Ieu mangrupikeun alternatif anu henteu panik pikeun ngaindéks `str`.
    /// Mulih [`None`] iraha operasi indéks anu sami sareng panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indéks henteu dina wates urutan UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // kaluar tina wates
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Balikkeun subslice anu tiasa dirobih `str`.
    ///
    /// Ieu mangrupikeun alternatif anu henteu panik pikeun ngaindéks `str`.
    /// Mulih [`None`] iraha operasi indéks anu sami sareng panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // panjangna bener
    /// assert!(v.get_mut(0..5).is_some());
    /// // kaluar tina wates
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Mulang deui subslice anu henteu dipariksa `str`.
    ///
    /// Ieu mangrupikeun alternatif anu teu dipariksa pikeun ngaindéks `str`.
    ///
    /// # Safety
    ///
    /// Nu nélépon pungsi ieu tanggung jawab yén prékondisi ieu wareg:
    ///
    /// * Indéks awal kedah henteu ngaleuwihan indéks tungtung;
    /// * Indéks kedah aya dina wates wilah asli;
    /// * Indexes kudu nutupan UTF-8 runtuyan wates.
    ///
    /// Gagal éta, nyiksikan string nu balik bakal nuduhkeun ingetan sah atawa ngalanggar invariants komunkasi ku tipe `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `get_unchecked`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Mulang deui hiji subslice `str` anu teu tiasa diparios.
    ///
    /// Ieu mangrupikeun alternatif anu teu dipariksa pikeun ngaindéks `str`.
    ///
    /// # Safety
    ///
    /// Nu nélépon pungsi ieu tanggung jawab yén prékondisi ieu wareg:
    ///
    /// * Indéks awal kedah henteu ngaleuwihan indéks tungtung;
    /// * Indéks kedah aya dina wates wilah asli;
    /// * Indexes kudu nutupan UTF-8 runtuyan wates.
    ///
    /// Gagal éta, nyiksikan string nu balik bakal nuduhkeun ingetan sah atawa ngalanggar invariants komunkasi ku tipe `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // Kasalametan: nu panelepon kedah uphold kontrak kaamanan pikeun `get_unchecked_mut`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Nyiptakeun sapotong senar tina keureut senar sanés, ngaliwat cek kaamanan.
    ///
    /// Ieu umumna henteu disarankeun, anggo ku ati-ati!Pikeun alternatif anu aman tingali [`str`] sareng [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Irisan anyar ieu angkat ti `begin` dugi ka `end`, kalebet `begin` tapi teu kaasup `end`.
    ///
    /// Pikeun kéngingkeun irisan senar anu tiasa dirobih, tingali metode [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Nu nélépon pungsi ieu tanggung jawab yén tilu prasyarat parantos wareg:
    ///
    /// * `begin` henteu kedah ngaleuwihan `end`.
    /// * `begin` sareng `end` kedah posisi byte dina irisan senar.
    /// * `begin` sareng `end` kedah ngagolér dina wates urutan UTF-8.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `get_unchecked`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Nyiptakeun sapotong senar tina keureut senar sanés, ngaliwat cek kaamanan.
    /// Ieu umumna henteu disarankeun, anggo ku ati-ati!Pikeun alternatif aman tingali [`str`] na [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Irisan anyar ieu angkat ti `begin` dugi ka `end`, kalebet `begin` tapi teu kaasup `end`.
    ///
    /// Pikeun kéngingkeun sapotong senar anu teu tiasa dirobih, tingali metode [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Nu nélépon pungsi ieu tanggung jawab yén tilu prasyarat parantos wareg:
    ///
    /// * `begin` henteu kedah ngaleuwihan `end`.
    /// * `begin` sareng `end` kedah posisi byte dina irisan senar.
    /// * `begin` sareng `end` kedah ngagolér dina wates urutan UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // Kasalametan: nu panelepon kedah uphold kontrak kaamanan pikeun `get_unchecked_mut`;
        // keureutna tiasa dibereskeun kusabab `self` mangrupikeun rujukan anu aman.
        // Pointer anu balik aman sabab impls of `SliceIndex` kedah ngajamin yén éta.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Bagikeun hiji irisan senar janten dua dina hiji indéks.
    ///
    /// Argumen, `mid`, kedah janten byte offset ti mimiti senar.
    /// Éta ogé kedah dina wates titik kode UTF-8.
    ///
    /// Dua keureut balik indit ti ngawitan tina string nyiksikan mun `mid`, sarta ti `mid` ka tungtung nyiksikan senar.
    ///
    /// Pikeun kéngingkeun keureut senar anu tiasa dirobih, tingali metode [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics lamun `mid` henteu dina wates titik kode UTF-8, atawa lamun geus kaliwat ahir titik kode panungtungan sahiji nyiksikan senar.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // cék is_char_boundary yén indéks nu aya dina [0, .len()]
        if self.is_char_boundary(mid) {
            // SAFETY: nembé parios yén `mid` aya dina wates char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ditilik hiji senar nyiksikan mutable kana dua di hiji indéks.
    ///
    /// Argumen, `mid`, kedah janten byte offset ti mimiti senar.
    /// Éta ogé kedah dina wates titik kode UTF-8.
    ///
    /// Dua keureut balik indit ti ngawitan tina string nyiksikan mun `mid`, sarta ti `mid` ka tungtung nyiksikan senar.
    ///
    /// Pikeun kéngingkeun keureut senar anu teu tiasa dirobih, tingali metode [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics lamun `mid` henteu dina wates titik kode UTF-8, atawa lamun geus kaliwat ahir titik kode panungtungan sahiji nyiksikan senar.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // cék is_char_boundary yén indéks nu aya dina [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAFETY: nembé parios yén `mid` aya dina wates char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Balikkeun iterator dina bagian [`char`] tina keureut senar.
    ///
    /// Salaku keureut senar diwangun ku UTF-8 anu valid, urang tiasa ngiringan nganggo irisan senar ku [`char`].
    /// Metoda ieu mulihkeun sapertos Iterator.
    ///
    /// Penting pikeun diémutan yén [`char`] ngagambarkeun Unicode Scalar Value, sareng panginten henteu cocog sareng ideu anjeun ngeunaan naon anu 'character'.
    ///
    /// Iterasi gugusi grapheme panginten anu anjeun pikahoyong.
    /// Fungsi ieu sanés disayogikeun ku perpustakaan standar Rust, cek crates.io waé.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Émut, [`char`] panginten henteu cocog sareng intuisi anjeun ngeunaan karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // moal 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Balikkeun iterator dina bagian [`char`] tina potongan irisan, sareng posisina.
    ///
    /// Salaku keureut senar diwangun ku UTF-8 anu valid, urang tiasa ngiringan nganggo irisan senar ku [`char`].
    /// Cara ieu ngabalikeun iterator pikeun duanana [`char`] ieu, ogé posisi baitna.
    ///
    /// iterator nu ngahasilkeun tuples.Posisi kahiji, [`char`] kadua.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Émut, [`char`] panginten henteu cocog sareng intuisi anjeun ngeunaan karakter:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // henteu (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // perhatoskeun 3 di dieu, tokoh pamungkas nyandak dua bait
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iterator ngalangkungan bait tina irisan senar.
    ///
    /// Salaku keureut senar diwangun ku sekuen bait, urang tiasa nerobos ngaliwatan irisan senar ku bait.
    /// Metoda ieu mulihkeun sapertos Iterator.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Dibeulah sapotong senar ku ruang bodas.
    ///
    /// iterator nu balik bakal balik keureut string anu sub-keureut tina nyiksikan string aslina, dipisahkeun ku sagala jumlah whitespace.
    ///
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    /// Upami anjeun ngan ukur hoyong pisah dina ruang bodas ASCII, nganggo [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Sagala jinis rohangan bodas dianggap:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Dibeulah sapotong senar ku ruang bodas ASCII.
    ///
    /// Iterator anu dipulangkeun bakal ngirangkeun irisan senar anu sub-irisan tina irisan senar aslina, dipisahkeun ku jumlah buleud ASCII.
    ///
    ///
    /// Pikeun dipisahkeun ku Unicode `Whitespace` waé, anggo [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Sagala jinis ASCII whitespace dianggap:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iterator ngalangkungan garis senar, sakumaha irisan senar.
    ///
    /// Garis dipungkas ku XlineX anyar atanapi balik angkot sareng feed line (`\r\n`).
    ///
    /// Garis akhir pamungkas nyaéta opsional.
    /// Senar anu ditungtungan ku tungtung garis akhir bakal balikkeun garis anu sami sareng senar anu sanés sami sareng teu aya garis akhir anu akhir.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Garis akhir akhir henteu diperyogikeun:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Hiji iterator ngaliwatan garis tina string a.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Mulang iterator `u16` ngalangkungan senar anu disandikeun salaku UTF-16.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Mulih `true` upami pola anu dipasihkeun cocog sareng sub-slice tina potongan string ieu.
    ///
    /// Mulih `false` upami henteu.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Mulih `true` upami pola anu dipasihkeun cocog sareng awalan tina potongan string ieu.
    ///
    /// Mulih `false` upami henteu.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Mulih `true` upami pola anu dipasihkeun cocog sareng ahiran tina potongan string ieu.
    ///
    /// Mulih `false` upami henteu.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Balikkeun indeks byte karakter mimiti potongan string ieu anu cocog sareng pola.
    ///
    /// Mulih [`None`] upami pola na henteu cocog.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// pola leuwih kompleks maké titik-gratis gaya na closures:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Henteu mendakan pola na:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Balikkeun indéks bait pikeun karakter mimiti pertandingan paling katuhu tina pola dina irisan senar ieu.
    ///
    /// Mulih [`None`] upami pola na henteu cocog.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Pola anu langkung rumit kalayan panutupan:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Henteu mendakan pola na:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iterator ngalangkungan substrings tina irisan senar ieu, dipisahkeun ku karakter anu cocog sareng pola.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik bakal janten [`DoubleEndedIterator`] upami pola na ngamungkinkeun milarian tibalik sareng pamilarian forward/reverse ngahasilkeun unsur anu sami.
    /// Ieu leres kanggo, contona, [`char`], tapi henteu pikeun `&str`.
    ///
    /// Upami pola na ngamungkinkeun milarian tibalik tapi hasilna na tiasa bénten tina pamilarian payun, metode [`rsplit`] tiasa dianggo.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Upami pola na nyaéta sapotong chars, beulah unggal kajadian tina salah sahiji karakter na:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Upami senar ngandung sababaraha pamisah anu caket, anjeun bakal nganggo senar kosong dina kaluaranana:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Pisahkeun anu caket dipisahkeun ku senar kosong.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Pamisah dina mimiti atanapi tungtung senar dikurung ku senar kosong.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Nalika senar kosong dianggo salaku pamisah, éta misahkeun unggal karakter dina senar, dibarengan sareng awal sareng akhir senar.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// SEPARATOR anu caket tiasa nyababkeun tingkah polah anu héran nalika bule dianggo salaku pamisah.Kode ieu leres:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Éta _not_ masihan anjeun:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Paké [`split_whitespace`] pikeun kabiasaan ieu.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iterator ngalangkungan substrings tina irisan senar ieu, dipisahkeun ku karakter anu cocog sareng pola.
    /// Béda tina iterator anu dihasilkeun `split` dina `split_inclusive` daun anu cocog sareng salaku terminator tina substring.
    ///
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Mun unsur panungtungan of string anu loyog Unsur anu bakal dianggap terminator tina substring harita.
    /// Substring éta bakal janten barang terakhir anu dipulangkeun ku iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Hiji iterator leuwih substrings of nyiksikan string anu dibikeun, dipisahkeun ku karakter loyog ku pola sarta yielded dina urutan sabalikna.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Dipulangkeun iterator merlukeun pola nu ngarojong hiji pilarian sabalikna, sarta eta bakal [`DoubleEndedIterator`] lamun hiji pilarian forward/reverse ngahasilkeun elemen sarua.
    ///
    ///
    /// Pikeun iterating ti payun, metoda [`split`] tiasa dianggo.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Hiji iterator leuwih substrings of nyiksikan string anu dibikeun, dipisahkeun ku karakter loyog ku pola hiji.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Sarua sareng [`split`], kajaba substring labuh diloloskeun upami kosong.
    ///
    /// [`split`]: str::split
    ///
    /// Cara ieu tiasa dianggo pikeun data string anu _terminated_, tinimbang _separated_ ku pola.
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik bakal janten [`DoubleEndedIterator`] upami pola na ngamungkinkeun milarian tibalik sareng pamilarian forward/reverse ngahasilkeun unsur anu sami.
    /// Ieu leres kanggo, contona, [`char`], tapi henteu pikeun `&str`.
    ///
    /// Upami pola na ngamungkinkeun milarian tibalik tapi hasilna na tiasa bénten tina pamilarian payun, metode [`rsplit_terminator`] tiasa dianggo.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Hiji iterator leuwih substrings of `self`, dipisahkeun ku karakter loyog ku pola sarta yielded dina urutan sabalikna.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Sarua sareng [`split`], kajaba substring labuh diloloskeun upami kosong.
    ///
    /// [`split`]: str::split
    ///
    /// Cara ieu tiasa dianggo pikeun data string anu _terminated_, tinimbang _separated_ ku pola.
    ///
    /// # kabiasaan Iterator
    ///
    /// Dipulangkeun iterator merlukeun pola nu ngarojong hiji pilarian sabalikna, sarta eta bakal ganda réngsé lamun hiji pilarian forward/reverse ngahasilkeun elemen sarua.
    ///
    ///
    /// Pikeun iterating ti payun, metoda [`split_terminator`] tiasa dianggo.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iterator ngalangkungan substrings tina irisan senar anu dipasihkeun, dipisahkeun ku pola, diwatesan pikeun mulang paling seueur barang `n`.
    ///
    /// Upami `n` substrings dipulangkeun, substring terakhir (substring `n`th) bakal ngandung sésa senar.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik moal dua kali réngsé, sabab éta henteu épisién pikeun ngadukung.
    ///
    /// Upami pola na ngamungkinkeun milarian tibalik, metode [`rsplitn`] tiasa dianggo.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterator ngalangkungan substrings tina irisan senar ieu, dipisahkeun ku pola, mimitian ti tungtung senar, diwatesan pikeun mulang paling seueur barang `n`.
    ///
    ///
    /// Upami `n` substrings dipulangkeun, substring terakhir (substring `n`th) bakal ngandung sésa senar.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik moal dua kali réngsé, sabab éta henteu épisién pikeun ngadukung.
    ///
    /// Pikeun pisah ti payun, metode [`splitn`] tiasa dianggo.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Splits string dina lumangsungna mimitina tina delimiter dieusian na mulih awalan saméméh delimiter sarta ahiran sanggeus delimiter.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Beulah string dina kajadian terakhir tina delimiter anu ditangtoskeun sareng mulih awalan sateuacan pembatas sareng ahiran saatos pembatas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iterator dina pertandingan anu cocog sareng pola dina irisan senar anu ditangtoskeun.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik bakal janten [`DoubleEndedIterator`] upami pola na ngamungkinkeun milarian tibalik sareng pamilarian forward/reverse ngahasilkeun unsur anu sami.
    /// Ieu leres kanggo, contona, [`char`], tapi henteu pikeun `&str`.
    ///
    /// Upami pola na ngamungkinkeun milarian tibalik tapi hasilna na tiasa bénten tina pamilarian payun, metode [`rmatches`] tiasa dianggo.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iterator tina patandingan anu teu cocog tina pola dina irisan senar ieu, ngahasilkeun dina urutan anu tibalik.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Dipulangkeun iterator merlukeun pola nu ngarojong hiji pilarian sabalikna, sarta eta bakal [`DoubleEndedIterator`] lamun hiji pilarian forward/reverse ngahasilkeun elemen sarua.
    ///
    ///
    /// Pikeun iterating ti payun, metoda [`matches`] tiasa dianggo.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterator tina patandingan anu teu cocog tina pola dina irisan senar ieu ogé indéks anu dimimitian pertandingan.
    ///
    /// Pikeun pertandingan `pat` dina `self` anu tumpang tindih, ngan ukur indéks anu cocog sareng pertandingan kahiji anu dikembalikan.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Iterator anu balik bakal janten [`DoubleEndedIterator`] upami pola na ngamungkinkeun milarian tibalik sareng pamilarian forward/reverse ngahasilkeun unsur anu sami.
    /// Ieu leres kanggo, contona, [`char`], tapi henteu pikeun `&str`.
    ///
    /// Upami pola na ngamungkinkeun milarian tibalik tapi hasilna na tiasa bénten tina pamilarian payun, metode [`rmatch_indices`] tiasa dianggo.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ngan ukur `aba` munggaran
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterator dina pertandingan anu cocog tina pola dina `self`, ngahasilkeun urutan tibalik sareng indéks pertandingan.
    ///
    /// Pikeun pertandingan `pat` dina `self` anu tumpang tindih, ngan ukur indéks anu cocog sareng pertandingan terakhir anu dikembalikan.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # kabiasaan Iterator
    ///
    /// Dipulangkeun iterator merlukeun pola nu ngarojong hiji pilarian sabalikna, sarta eta bakal [`DoubleEndedIterator`] lamun hiji pilarian forward/reverse ngahasilkeun elemen sarua.
    ///
    ///
    /// Pikeun iterating ti hareup, metoda [`match_indices`] bisa dipaké.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ngan ukur `aba` terakhir
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Mulangkeun sapotong senar kalayan spasi bodas ngarah sareng labuh dihapus.
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Mulangkeun sapotong senar kalayan spasi bodas ngarah dihapus.
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// `start` dina konteks ieu hartina posisi mimiti nu bait string;pikeun basa kénca-ka-katuhu sapertos Inggris atanapi Rusia, ieu bakal kénca, sareng kanggo basa-ka-kénca sapertos Arab atanapi Ibrani, ieu bakal janten sisi katuhu.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Mulih a string nyiksikan jeung labuh whitespace dihapus.
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// `end` dina konteks ieu hartina posisi panungtungan anu bait string;pikeun basa kénca-ka-katuhu sapertos Inggris atanapi Rusia, ieu bakal janten sisi katuhu, sareng pikeun basa-ka-kénca sapertos Arab atanapi Ibrani, ieu bakal janten sisi kénca.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Mulangkeun sapotong senar kalayan spasi bodas ngarah dihapus.
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// 'Left' dina kontéks ieu hartosna posisi mimiti senar bait éta;pikeun basa sapertos Arab atanapi Ibrani anu 'katuhu ka kénca' tibatan 'kénca ka katuhu', ieu bakal janten sisi _right_, sanés kénca.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Mulih a string nyiksikan jeung labuh whitespace dihapus.
    ///
    /// 'Whitespace' dihartikeun numutkeun istilah tina Unicode Derried Core Property `White_Space`.
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// 'Right' dina kontéks ieu hartosna posisi terakhir senar bait éta;pikeun basa sapertos Arab atanapi Ibrani anu 'katuhu ka kenca' tibatan 'kénca ka katuhu', ieu bakal janten sisi _left_, sanés leres.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Mulang sapotong string sareng sadaya awalan sareng ahiran anu cocog sareng pola anu teras-terasan dihapus.
    ///
    /// [pattern] tiasa janten [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakter cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Émut pertandingan anu mimiti dipikanyaho, lereskeun ieu di handap upami
            // pertandingan terakhir mah béda
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dipikaterang mulang indéks anu sah.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Mulih nyiksikan string kalayan sagala émbohan nu cocog hiji pola sababaraha kali dihapus.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// `start` dina konteks ieu hartina posisi mimiti nu bait string;pikeun basa kénca-ka-katuhu sapertos Inggris atanapi Rusia, ieu bakal kénca, sareng kanggo basa-ka-kénca sapertos Arab atanapi Ibrani, ieu bakal janten sisi katuhu.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAFETY: `Searcher` dipikaterang mulang indéks anu sah.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Mulang sapotong string kalayan awalan dihapus.
    ///
    /// Upami senar dimimitian ku pola `prefix`, mulih substring saatos awalan, dibungkus `Some`.
    /// Beda sareng `trim_start_matches`, cara ieu ngaluarkeun awalan persis sakali.
    ///
    /// Upami senarna henteu dimimitian ku `prefix`, mulih `None`.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Mulang sapotong senar kalayan ahiran dicabut.
    ///
    /// Upami senar dipungkas ku pola `suffix`, mulihkeun substring sateuacan ahiran, dibungkus `Some`.
    /// Beda sareng `trim_end_matches`, metoda ieu ngaluarkeun ahiran anu persis sakali.
    ///
    /// Upami senar na henteu ditungtungan ku `suffix`, mulih `None`.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Mulang sapotong string sareng sadaya ahiran anu cocog sareng pola anu teras-terasan dihapus.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// `end` dina konteks ieu hartina posisi panungtungan anu bait string;pikeun basa kénca-ka-katuhu sapertos Inggris atanapi Rusia, ieu bakal janten sisi katuhu, sareng pikeun basa-ka-kénca sapertos Arab atanapi Ibrani, ieu bakal janten sisi kénca.
    ///
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAFETY: `Searcher` dipikaterang mulang indéks anu sah.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Mulih nyiksikan string kalayan sagala émbohan nu cocog hiji pola sababaraha kali dihapus.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// 'Left' dina kontéks ieu hartosna posisi mimiti senar bait éta;pikeun basa sapertos Arab atanapi Ibrani anu 'katuhu ka kénca' tibatan 'kénca ka katuhu', ieu bakal janten sisi _right_, sanés kénca.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Mulang sapotong string sareng sadaya ahiran anu cocog sareng pola anu teras-terasan dihapus.
    ///
    /// [pattern] tiasa janten `&str`, [`char`], sapotong [`char`] s, atanapi fungsi atanapi panutupan anu nangtoskeun naha karakterna cocog.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Arah téks
    ///
    /// Senar mangrupikeun sekuen bait.
    /// 'Right' dina kontéks ieu hartosna posisi terakhir senar bait éta;pikeun basa sapertos Arab atanapi Ibrani anu 'katuhu ka kenca' tibatan 'kénca ka katuhu', ieu bakal janten sisi _left_, sanés leres.
    ///
    ///
    /// # Examples
    ///
    /// Pola saderhana:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Hiji pola anu leuwih kompléks, maké panutupanana a:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses senar ieu kana jinis anu sanés.
    ///
    /// Kusabab `parse` umum pisan, éta tiasa nyababkeun masalah sareng inferensi jinis.
    /// Sapertos kitu, `parse` mangrupikeun sababaraha waktos anjeun bakal ningali sintaksis anu dipikaterang salaku 'turbofish': `::<>`.
    ///
    /// Ieu ngabantuan algoritma inferensi ngartos husus nu ngetik nu nuju nyobian parse kana.
    ///
    /// `parse` tiasa parse kana sagala jinis anu nerapkeun [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Bakal balikkeun [`Err`] upami henteu mungkin pikeun ngurai potongan string ieu kana jinis anu dipikahoyong.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Dasar panggunaan
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Ngagunakeun 'turbofish' tinimbang annotating `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Gagal parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Pariksa naha sadaya karakter dina senar ieu aya dina kisaran ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Bisa ngubaran tiap bait sakumaha karakter dieu: kabéh karakter multibyte mimitian ku bait anu teu di rentang ASCII, sangkan bakal eureun aya geus.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Cék nu dua senar anu hiji hal-merhatikeun cocok ASCII.
    ///
    /// Sarua sareng `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, tapi henteu aya alokasi sareng nyalin samentawis.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ngarobah string ieu ASCII hal luhur sarimbag taun-tempat.
    ///
    /// hurup ASCII 'a' mun 'z' anu dipetakeun kana 'A' mun 'Z', tapi hurup non-ASCII anu unchanged.
    ///
    /// Pikeun balik a nilai uppercased anyar tanpa modifying hiji aya, nganggo [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // Kasalametan: aman sabab kami transmute dua jenis jeung tata perenah sarua.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ngarobah string ieu ASCII hal handap sarua taun-tempat.
    ///
    /// Huruf ASCII 'A' dugi 'Z' dipetakeun ka 'a' dugi 'z', tapi hurup sanés ASCII henteu robih.
    ///
    /// Pikeun balik a nilai lowercased anyar tanpa modifying hiji aya, nganggo [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // Kasalametan: aman sabab kami transmute dua jenis jeung tata perenah sarua.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Balikkeun iterator anu kabur unggal char dina `self` sareng [`char::escape_debug`].
    ///
    ///
    /// Note: ngan ukur codepoints grapheme anu ngalegaan anu ngamimitian senarna bakal kabur.
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Balikkeun iterator anu kabur unggal char dina `self` sareng [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Balikkeun iterator anu kabur unggal char dina `self` sareng [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Salaku iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Ngagunakeun `println!` langsung:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Duanana nyaéta sarua jeung:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Ngagunakeun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Nyiptakeun str kosong
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Nyiptakeun str mutable kosong
    #[inline]
    fn default() -> Self {
        // Kasalametan: The string kosong téh sah UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Jinis fn anu tiasa ditingalkeun
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // KESELAMATAN: henteu aman
        unsafe { from_utf8_unchecked(bytes) }
    };
}