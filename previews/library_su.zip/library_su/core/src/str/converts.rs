//! Cara nyieun `str` tina bait keureut.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Ngarobih sapotong bait kana irisan senar.
///
/// Irisan senar ([`&str`]) didamel tina bait ([`u8`]), sareng sapotong bait ([`&[u8]`][byteslice]) didamel tina bait, janten fungsi ieu ngarobah antara keduanya.
/// Henteu sadayana keureutan bait mangrupikeun keureut senar anu sah, nanging: [`&str`] ngabutuhkeun UTF-8 anu valid.
/// `from_utf8()` cek pikeun mastikeun yén bait valid UTF-8, teras ngalakukeun konvérsi éta.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Upami anjeun yakin yén keureutan bait valid UTF-8, sareng anjeun teu hoyong ngahasilkeun overhead cek validitas, aya pérsi anu teu aman tina fungsi ieu, [`from_utf8_unchecked`], anu ngagaduhan paripolah anu sami tapi ngalangkungan cek éta.
///
///
/// Upami anjeun peryogi `String` tinimbang `&str`, anggap [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Kusabab anjeun tiasa nyusun-nyayogikeun `[u8; N]`, sareng anjeun tiasa nyandak [`&[u8]`][byteslice], fungsi ieu mangrupikeun salah sahiji cara pikeun ngagaduhan senar tumpukan.Aya conto ieu dina conto conto di handap.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Balikkeun `Err` upami keureut sanés UTF-8 kalayan katerangan naha potongan anu disayogikeun sanés UTF-8.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::str;
///
/// // sababaraha bait, dina vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kami terang bait ieu valid, janten ngan nganggo `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bait salah:
///
/// ```
/// use std::str;
///
/// // sababaraha bait anu henteu valid, dina vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Tingali dokumén pikeun [`Utf8Error`] pikeun langkung seueur rinci ngeunaan jinis kasalahan anu tiasa dipulangkeun.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // sababaraha bait, dina susunan susunan-alokasi
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Kami terang bait ieu valid, janten ngan nganggo `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Ngan lumpat validasi.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Ngarobih irisan bait anu tiasa dirobih kana irisan senar anu tiasa dirobih.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" salaku vector anu tiasa dirobih
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Sakumaha urang terang bait ieu sah, urang tiasa nganggo `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bait salah:
///
/// ```
/// use std::str;
///
/// // Sababaraha bait anu henteu valid dina vector anu tiasa dirobih
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Tingali dokumén pikeun [`Utf8Error`] pikeun langkung seueur rinci ngeunaan jinis kasalahan anu tiasa dipulangkeun.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: Ngan lumpat validasi.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Ngarobih sapotong bait kana irisan senar tanpa mariksa senar na ngandung UTF-8 anu valid.
///
/// Tingali vérsi anu aman, [`from_utf8`], kanggo langkung seueur inpormasi.
///
/// # Safety
///
/// Fungsi ieu henteu aman sabab henteu mariksa yén bait anu diliwatan ka UTF-8 anu valid.
/// Upami konstrain ieu dilanggar, hasilna kalakuan teu ditangtoskeun, sabab sésana Rust nganggap yén [`&str`] s valid UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::str;
///
/// // sababaraha bait, dina vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: panelepon kedah ngajamin yén bait `v` valid UTF-8.
    // Ogé ngandelkeun `&str` sareng `&[u8]` gaduh perenah anu sami.
    unsafe { mem::transmute(v) }
}

/// Ngarobih sapotong bait kana irisan senar tanpa mariksa yén senarna ngandung UTF-8 anu valid;Vérsi mutable.
///
///
/// Tempo versi immutable, [`from_utf8_unchecked()`] kanggo inpormasi lengkep.
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAFETY: panelepon kedah ngajamin yén bait `v`
    // valid UTF-8, sahingga anu matak ka `*mut str` aman.
    // Ogé, anu pointer dereference geus aman sabab nu pointer asalna ti rujukan nu dijamin janten valid keur nyerat.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}