//! Nangtukeun `IntoIter` milik iterator pikeun susunan.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Iterator [array] ku nilai.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ieu Asép Sunandar Sunarya anu urang teras-terasan.
    ///
    /// Unsur anu nganggo indéks `i` dimana `alive.start <= i < alive.end` teu acan ngahasilkeun sareng éntri éntri anu valid.
    /// Elemen anu nganggo indéks `i < alive.start` atanapi `i >= alive.end` parantos parantos dipasihkeun sareng teu kedah diaksés deui!Unsur-unsur paéh éta bahkan tiasa dina kaayaan anu henteu leres pisan!
    ///
    ///
    /// Janten anu ngundangna nyaéta:
    /// - `data[alive]` hirup (nyaéta ngandung unsur anu valid)
    /// - `data[..alive.start]` sarta `data[alive.end..]` nu maot (misalna unsur anu geus maca teu kudu keuna deui!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Unsur-unsur dina `data` anu henteu acan dihasilkeun.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Nyiptakeun iterator anyar dina `array` anu ditangtoskeun.
    ///
    /// *Catetan*: metoda ieu panginten teu nganggo deui dina future, saatos [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Jinis `value` nyaéta `i32` di dieu, tibatan `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // KESELAMATAN: Transmisi di dieu saleresna aman.Dokumén `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` dijamin mun boga ukuran na alignment sarua
        // > sakumaha `T`.
        //
        // Dokumén bahkan nunjukkeun transmute tina Asép Sunandar Sunarya `MaybeUninit<T>` ka Asép Sunandar Sunarya `T`.
        //
        //
        // Kalayan éta, inisialisasi ieu nyugemakeun para pangajak.

        // FIXME(LukasKalbertodt): saleresna nganggo `mem::transmute` di dieu, sakali éta tiasa dianggo sareng umumna konstip:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Dugi lajeng, urang tiasa nganggo `mem::transmute_copy` mun nyieun salinan bitwise salaku tipe béda, teras hilap `array` meh teu turun.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Balikkeun irisan anu teu tiasa dirobih tina sadaya unsur anu henteu acan ngahasilkeun.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // Kaamanan: Kami terang yén sadaya unsur dina `alive` leres diinisialisasi.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Mulih nyiksikan mutable sadaya elemen anu teu acan yielded acan.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // Kaamanan: Kami terang yén sadaya unsur dina `alive` leres diinisialisasi.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Kéngingkeun indéks salajengna ti payun.
        //
        // Ngaronjatna `alive.start` ku 1 mertahankeun éta invarian ngeunaan `alive`.
        // Sanajan kitu, alatan robah ieu, keur waktu anu singget, anu zone hirup teu `data[alive]` deui, tapi `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Maca unsur tina susunan.
            // Kasalametan: `idx` mangrupa indéks kana urut wilayah "alive" tina
            // rarangkén.Maca unsur ieu hartosna `data[idx]` dianggap maot ayeuna (nyaéta henteu keuna).
            // Kusabab `idx` mangrupikeun awal zona anu hirup, zona hirup ayeuna `data[alive]` deui, mulangkeun sadaya invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Kéngingkeun indéks salajengna ti tukang.
        //
        // Nurunna `alive.end` ku 1 mertahankeun éta invarian ngeunaan `alive`.
        // Sanajan kitu, alatan robah ieu, keur waktu anu singget, anu zone hirup teu `data[alive]` deui, tapi `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Maca unsur tina susunan.
            // Kasalametan: `idx` mangrupa indéks kana urut wilayah "alive" tina
            // rarangkén.Maca unsur ieu hartosna `data[idx]` dianggap maot ayeuna (nyaéta henteu keuna).
            // Salaku `idx` éta tungtung hirup-zone, zona hirup téh kiwari `data[alive]` deui, malikkeun sadayana invariants.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // Kasalametan: Ieu aman: `as_mut_slice` mulih persis sub-nyiksikan
        // ngeunaan unsur-unsur anu henteu acan dipindahkeun sareng anu bakal tetep turun.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Moal pernah banjir kusabab panyawat `hirup.ngawitan <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator mémang ngalaporkeun panjangna anu leres.
// Jumlah unsur "alive" (anu bakal tetep dihasilkeun) nyaéta panjang kisaran `alive`.
// Kisaran ieu panjangna decremented boh `next` atanapi `next_back`.
// Ieu sok decremented ku 1 dina metode jalma, tapi ngan lamun `Some(_)` geus balik.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Catetan, urang henteu kedah cocog sareng kisaran hirup anu sami, janten urang ngan saukur tiasa diklasifikasikeun kana offset 0 henteu paduli dimana `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonkeun sadaya unsur anu hirup.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tulis clone a kana Asép Sunandar Sunarya anyar, lajeng ngamutahirkeun rentang hirup na.
            // Upami diklon panics, urang leres lungsur barang anu sateuacanna.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ukur nyetak unsur-unsur anu henteu acan dihasilkeun: urang moal tiasa ngaksés deui unsur anu dihasilkeun.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}