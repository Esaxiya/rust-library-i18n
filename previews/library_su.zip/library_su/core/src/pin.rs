//! Jenis anu nyepetkeun data ka lokasi na dina mémori.
//!
//! Kadang-kadang gunana pikeun ngagaduhan objék anu dijamin moal ngalih, dina hartos panempatanna dina mémori henteu robih, sahingga tiasa diandelkeun.
//! Hiji conto prima tina skenario anu sapertos bakal jadi gedong structs timer referential, sakumaha pindah hiji obyék kalayan pointers mun sorangan bakal invalidate aranjeunna, anu bisa ngakibatkeun kabiasaan undefined.
//!
//! Dina tingkat anu luhur, [`Pin<P>`] mastikeun yén anu ditunjuk pikeun naon waé jenis pointer `P` ngagaduhan lokasi anu stabil dina mémori, hartosna éta henteu tiasa dipindahkeun ka tempat sanésna sareng mémori na henteu tiasa disahkeun dugi ka lungsur.Kami nyarios yén pointee nyaéta "pinned".Hal-hal janten langkung halus nalika ngabahas jinis-jinis anu ngagabungkeun sareng data anu teu dicitak;[see below](#projections-and-structural-pinning) pikeun langkung jelasna.
//!
//! Sacara standar, sadaya jinis dina Rust tiasa dipindahkeun.
//! Rust ngamungkinkeun ngalirkeun sadaya jinis ku nilai, sareng jenis pinter-pointer umum sapertos [`Box<T>`] sareng `&mut T` ngamungkinkeun ngagentos sareng mindahkeun nilai anu dikandungna: anjeun tiasa ngalih kaluar [`Box<T>`], atanapi anjeun tiasa nganggo [`mem::swap`].
//! [`Pin<P>`] bungkus jinis pointer `P`, janten [`Pin`]`<`[`Box`]`<T>>`fungsina sapertos biasa
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`]`<T>>`turun, kitu ogé eusina, sareng ingetan na meunang
//!
//! paséa.Nya kitu, [`Pin`]`<&mut T>` mirip pisan sareng `&mut T`.Nanging, [`Pin<P>`] henteu ngantep klien leres-leres kéngingkeun [`Box<T>`] atanapi `&mut T` kana data anu dipasang, anu nunjukkeun yén anjeun moal tiasa nganggo operasi sapertos [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` peryogi `&mut T`, tapi kami henteu tiasa kéngingkeunana.
//!     // Kami macét, kami moal tiasa ngagentoskeun kontén rujukan ieu.
//!     // Urang tiasa nganggo `Pin::get_unchecked_mut`, tapi éta henteu aman pikeun alesan:
//!     // kami henteu kénging nganggo éta pikeun mindahkeun hal-hal kaluar tina `Pin`.
//! }
//! ```
//!
//! Éta patut diémutan deui yén [`Pin<P>`] henteu *henteu* ngarobih kanyataan yén panyusun Rust nganggap sadaya jinis tiasa dipindahkeun.[`mem::swap`] tetep nganuhunkeun pikeun `T` naon waé.Sabalikna, [`Pin<P>`] nyegah *nilai* anu tangtu (ditunjuk ku petunjuk anu dibungkus [`Pin<P>`]) tina dipindahkeun ku cara teu mungkin pikeun nelepon metode anu meryogikeun `&mut T` (sapertos [`mem::swap`]).
//!
//! [`Pin<P>`] tiasa dianggo pikeun mungkus jinis pointer `P`, sareng sapertos éta berinteraksi sareng [`Deref`] sareng [`DerefMut`].A [`Pin<P>`] mana `P: Deref` kudu dianggap salaku "`P`-style pointer" ka `P::Target` pinned-kitu, a [`Pin`]`<`[`Box`] `<T>>`mangrupikeun pointer milik `T` anu disemat, sareng [`Pin`] `<` [`Rc`]`<T>>`mangrupikeun pointer anu diitung janten rujukan `T`.
//! Kanggo leresna, [`Pin<P>`] ngandelkeun kana implementasi [`Deref`] sareng [`DerefMut`] supados henteu ngalih kaluar parameter `self` na, sareng ngan ukur kantos ngabalikkeun pointer kana data anu dicubit nalika disebat dina pointer anu dipasang.
//!
//! # `Unpin`
//!
//! Seueur jinisna biasana tiasa dialihkeun sacara bébas, bahkan nalika dicubit, sabab éta henteu gumantung kana alamat anu stabil.Ieu kalebet sadaya jinis dasar (sapertos [`bool`], [`i32`], sareng rujukan) ogé jinis anu ngan ukur tina jenis ieu.Jenis anu henteu paduli ngeunaan pinning nerapkeun [`Unpin`] auto-trait, anu ngabatalkeun pangaruh [`Pin<P>`].
//! Pikeun `T: Unpin`, [`Pin`]`<`[`Box`]`<T>>`sareng fungsi [`Box<T>`] idéntik, sapertos ogé [`Pin`] `<&mut T>` sareng `&mut T`.
//!
//! Catet yén pinning sareng [`Unpin`] ngan ukur mangaruhan X-`P::Target` X anu runcing, sanés tipe pointer `P` nyalira anu dibungkus [`Pin<P>`].Salaku conto, naha [`Box<T>`] atanapi [`Unpin`] henteu mangaruhan kana paripolah [`Pin`]`<`[`Box`]`<T>>`(di dieu, `T` mangrupikeun jinis anu ditunjuk).
//!
//! # Conto: struktip referensial diri
//!
//! Sateuacan urang langkung rinci pikeun ngajelaskeun jaminan sareng pilihan anu aya hubunganana sareng `Pin<T>`, urang bahas sababaraha conto ngeunaan kumaha éta tiasa dianggo.
//! Ngarasa Luncat ka [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ieu mangrupikeun struktip referensial diri kusabab lapangan slice nunjuk kana bidang data.
//! // Simkuring teu tiasa ngawartosan compiler anu ngeunaan éta ku rujukan normal, salaku pola ieu teu bisa digambarkeun ku aturan injeuman biasa.
//! //
//! // Sabalikna urang nganggo pointer atah, sanaos anu dipikaterang henteu batal, sabab urang terang éta nunjuk kana senarna.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Pikeun mastikeun data henteu ngalih nalika fungsina balik, urang lebetkeun kana tumpukan dimana éta bakal tetep salami obyék, sareng hiji-hijina cara pikeun ngaksésna nyaéta ku cara nunjuk kana éta.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // urang ngan ukur nyiptakeun pointer saatos data aya dina tempat sanésna éta bakal parantos ngalih sateuacan urang ngamimitian
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // kami terang yén ieu aman kusabab ngarobih lapangan henteu mindahkeun sacara gembleng
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Pointer kedah nunjuk ka lokasi anu leres, salami strukturna henteu acan ngalih.
//! //
//! // Samentawis éta, kami bébas mindahkeun pointer.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kusabab jinis kami henteu nerapkeun Unpin, ieu bakal gagal nyusun:
//! // hayu mut new_unmaced= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Conto: daptar intrusive do-link
//!
//! Dina daptar anu dikaitkeun dobel anu nyusup, koleksi henteu leres-leres ngaalokasikeun mémori pikeun unsur éta nyalira.
//! Alokasi dikawasa ku klien, sareng elemen tiasa hirup dina pigura tumpukan anu hirupna langkung pondok tibatan koléksi.
//!
//! Pikeun ngadamel padamelan ieu, unggal elemen ngagaduhan petunjuk anu sateuacanna sareng panerusna dina daptar.Elemen ngan bisa ditambahkeun basa aranjeunna keur pinned, lantaran pindah ka elemen sabudeureun bakal invalidate nu pointers.Sumawona, panerapan [`Drop`] tina unsur daptar anu kakait bakal nambalan point of miheulaan sareng panerusna pikeun ngaluarkeun dirina tina daptar.
//!
//! Krusial, urang kedah tiasa ngandelkeun [`drop`] disauran.Upami hiji unsur tiasa disélokasi atanapi henteu leres dibatalkeun tanpa nyauran [`drop`], petunjuk kana unsur-unsur tatangga na janten teu valid, anu bakal ngarusak struktur data.
//!
//! Maka, pinning ogé ngagaduhan jaminan anu aya hubunganana sareng [`drop`].
//!
//! # `Drop` guarantee
//!
//! Tujuan nyepetkeun nyaéta pikeun tiasa ngandelkeun panempatan sababaraha data dina mémori.
//! Pikeun nyieun padamelan ieu, henteu ngan ukur mindahkeun data diwatesan;deallocating, repurposing, atanapi anu sanés ngabatalkeun mémori anu dianggo pikeun nyimpen data diwatesan ogé.
//! Sacara konkrit, pikeun data anu disematkeun anjeun kedah ngajaga invariant yén *mémori na moal dibatalkeun atanapi dirobih deui ti saprak éta dipasang nalika dugi ka [`drop`] disebat*.Ngan sakali [`drop`] balik atanapi panics, mémori tiasa dianggo deui.
//!
//! Memori tiasa "invalidated" ku deallocation, tapi ogé ku ngaganti hiji [`Some(v)`] ku [`None`], atawa nelepon [`Vec::set_len`] mun "kill" sababaraha elemen kaluar tina hiji vector.Éta tiasa repurposed ku ngagunakeun [`ptr::write`] pikeun nimpa éta tanpa nelepon destructor heula.Henteu aya anu kéngingkeun data anu disematkan tanpa nelepon [`drop`].
//!
//! Ieu persis jenis garansi yén daptar numbu intrusive ti bagian saencanna perlu fungsi neuleu.
//!
//! Bewara nu garansi ieu manten *moal* hartosna memori nu teu bocor!Masih leres-leres henteu kunanaon upami nelepon [`drop`] dina elemen anu dipasang (contona, anjeun masih tiasa nyauran [`mem::forget`] dina [`Pin`]`<`[Box`]``<T>> `).Dina conto daptar anu dikaitkeun dua kali, elemen éta bakal tetep dina daptar.Nanging anjeun moal ngaleupaskeun atanapi nganggo deui panyimpenan *tanpa nyauran [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Upami jinis anjeun nganggo pinning (sapertos dua conto di luhur), anjeun kedah ati-ati nalika nerapkeun [`Drop`].Fungsi [`drop`] nyandak `&mut self`, tapi ieu disebat *sanaos jinis anjeun sateuacanna dipencét*!Saolah-olah panyusunna sacara otomatis disebat [`Pin::get_unchecked_mut`].
//!
//! Ieu henteu pernah tiasa nimbulkeun masalah dina kode anu aman kusabab ngalaksanakeun jinis anu ngandelkeun kana pinning peryogi kode anu teu aman, tapi kudu sadar yén mutuskeun pikeun ngagunakeun pining dina jinis anjeun (contona ku ngalaksanakeun sababaraha operasi dina [`Pin`]`<&Self>`atanapi [`Pin`] `<&mut Self>`) ngagaduhan akibat pikeun palaksanaan [`Drop`] anjeun ogé: upami unsur jinis anjeun tiasa disepelkeun, anjeun kedah ngubaran [`Drop`] salaku implisit anu nyandak [`Pin`]`<&mut Diri>`.
//!
//!
//! Salaku conto, anjeun tiasa nerapkeun `Drop` sapertos kieu:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` henteu kunanaon sabab kami terang nilai ieu henteu pernah dianggo deui saatos turun.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kodeu serelek saleresna angkat ka dieu.
//!         }
//!     }
//! }
//! ```
//!
//! Fungsi `inner_drop` ngagaduhan jinis anu kedah [`drop`] *, janten ieu pastikeun anjeun henteu ngahaja nganggo `self`/`this` ku cara anu bentrok sareng pinning.
//!
//! Sumawona, upami jinis anjeun `#[repr(packed)]`, panyusunna bakal sacara otomatis mindahkeun lapangan supados tiasa lungsur.Éta malah tiasa ngalaksanakeun éta pikeun lapangan anu kajantenan cekap dijajarkeun.Salaku konsekuensina, anjeun moal tiasa nganggo pinning ku jinis `#[repr(packed)]`.
//!
//! # Proyeksi sareng Pin Struktural
//!
//! Nalika damel sareng struktur anu dipasang, patarosan bakal muncul kumaha carana tiasa aksés kana bidang strukturna dina metoda anu ngan ukur [`Pin`]`<&mut Struct>`.
//! Pendekatan anu biasa nyaéta nyerat metode penolong (anu disebat *proyeksi*) anu ngajantenkeun [`Pin`]`<&mut Struct>` janten rujukan ka lapangan, tapi jenis naon anu ngagaduhan referensi éta?Naha éta [`Pin`]`<&mut Field>`atanapi `&mut Field`?
//! Patarosan anu sami timbul sareng bidang `enum`, sareng ogé nalika ngémutan container/wrapper jinis sapertos [`Vec<T>`], [`Box<T>`], atanapi [`RefCell<T>`].
//! (Patarosan ieu dilarapkeun pikeun rujukan anu tiasa ditumpes sareng dibagikeun, urang ngan ukur nganggo kasus anu langkung umum tina rujukan anu tiasa dirobih di dieu pikeun ilustrasi.)
//!
//! Tétéla éta leres-leres dugi ka panulis struktur data pikeun mutuskeun naha proyéksi anu dipasang pikeun lapangan tinangtu ngajantenkeun [`Pin`]`<&Mut Struct>`kana [`Pin`] `<&mut Field>` atanapi `&mut Field`.Aya sababaraha kendala, sareng anu paling penting pikeun *konsistensi*:
//! unggal lapangan tiasa *boh* diproyeksikeun kana rujukan pin,*atanapi* dipiceun pinning salaku bagian tina proyéksi.
//! Upami duanana dilakukeun pikeun lapangan anu sami, éta sigana bakal teu leres!
//!
//! Salaku panulis struktur data anjeun bakal mutuskeun unggal bidang naha nyepetkeun "propagates" ka lapangan ieu atanapi henteu.
//! Pinning anu nyebarkeun disebut ogé "structural", sabab éta nuturkeun struktur jinisna.
//! Dina bagian handap ieu, kami ngajelaskeun pertimbangan anu kedah dilakukeun pikeun salah sahiji pilihan.
//!
//! ## Pinning *sanés* struktural pikeun `field`
//!
//! Éta sigana katingali counter-intuitif yén bidang strukturna dilebetkeun moal dicubit, tapi éta sanés pilihan anu paling gampang: upami [`Pin`]`<&mut Field>`henteu pernah diciptakeun, moal aya anu lepat!Janten, upami anjeun mutuskeun yén sababaraha bidang henteu ngagaduhan pin struktural, anu anjeun kedah pastikeun nyaéta anjeun henteu pernah nyiptakeun rujukan pin kana bidang éta.
//!
//! Widang tanpa pin struktural tiasa gaduh metode proyéksi anu ngajantenkeun [`Pin`]`<&mut Struct>` janten `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Ieu henteu kunanaon kusabab `field` henteu kantos dianggap pinned.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Anjeun tiasa ogé `impl Unpin for Struct`*sanaos* jinis `field` sanés [`Unpin`].Naon anu dipikirkeun ku jinis sapertos ngeunaan pinning teu aya hubunganana nalika teu aya [`Pin`]`<&mut Field>` anu kantos didamel.
//!
//! ## Pinning *nyaeta* struktural pikeun `field`
//!
//! Pilihan sanésna nyaéta mutuskeun pinning nyaéta "structural" pikeun `field`, hartosna yén upami strukturna dicubit maka lapanganna ogé.
//!
//! Ieu ngamungkinkeun nyerat proyéksi anu nyiptakeun [`Pin`]`<&mut Field>`, sahingga nyaksian yén lapangan dipasangkeun:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Ieu henteu kunanaon kusabab `field` dipasang nalika `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Nanging, pinting struktural hadir sareng sababaraha sarat tambahan:
//!
//! 1. Strukturna kedahna ngan ukur [`Unpin`] upami sadaya bidang struktural [`Unpin`].Ieu standar, tapi [`Unpin`] mangrupikeun trait anu aman, janten salaku panulis strukturna tanggung jawab anjeun *sanés* pikeun nambihan sapertos `impl<T> Unpin for Struct<T>`.
//! (Perhatoskeun yén nambihan operasi proyéksi peryogi kode anu teu aman, janten kanyataan yén [`Unpin`] mangrupikeun trait aman henteu ngalanggar prinsip anu anjeun ngan ukur kedah hariwang ngeunaan hal ieu upami anjeun nganggo `teu aman`.)
//! 2. Nu ngarusak strukturna teu kudu mindahkeun bidang struktural tina arguméntasina.Ieu mangrupikeun titik anu leres anu diangkat dina [previous section][drop-impl]: `drop` nyandak `&mut self`, tapi strukturna (sareng maka ladang na) panginten parantos disemetkeun sateuacanna.
//!     Anjeun kedah ngajamin yén anjeun henteu mindahkeun lapangan dina panerapan [`Drop`] anjeun.
//!     Khususna, sakumaha anu dijelaskeun sateuacanna, ieu ngandung hartos yén strukturna anjeun kedah *henteu* janten `#[repr(packed)]`.
//!     Tingali bagian éta pikeun kumaha nyerat [`drop`] ku cara panyusun tiasa ngabantosan anjeun teu ngahaja megatkeun pin.
//! 3. Anjeun kedah pastikeun yén anjeun ngadukung [`Drop` guarantee][drop-guarantee]:
//!     saatos strukturna anjeun dipasangkeun, mémori anu ngandung konténna moal ditimpa atanapi ditranslokasi tanpa disebat penghancur eusi na.
//!     Ieu tiasa nyusahkeun, sakumaha disaksian ku [`VecDeque<T>`]: penghancur [`VecDeque<T>`] tiasa gagal nyauran [`drop`] dina sadaya elemen upami salah sahiji penghancur panics.Ieu ngalanggar garansi [`Drop`], sabab éta tiasa nyababkeun unsur-unsur dirobihkeun tanpa disebat destruktor na.([`VecDeque<T>`] teu aya proyéksi pin, janten ieu henteu nyababkeun kagorengan.)
//! 4. Anjeun teu kedah nawiskeun operasi sanés anu tiasa ngakibatkeun data dipindahkeun tina bidang struktural nalika jinis anjeun dipasangkeun.Salaku conto, upami strukturna ngandung [`Option<T>`] sareng aya operasi 'take`-like sareng tipe `fn(Pin<&mut Struct<T>>) -> Option<T>`, operasi éta tiasa dianggo pikeun mindahkeun `T` tina `Struct<T>` anu dipasang-anu hartosna pinning henteu tiasa struktural pikeun lapangan anu ngagaduhan ieu data.
//!
//!     Pikeun conto anu langkung rumit pikeun mindahkeun data tina jinis anu dipasang, bayangkeun upami [`RefCell<T>`] ngagaduhan metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Maka urang tiasa ngalakukeun ieu:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Ieu musibah, éta hartosna urang mimiti tiasa nyumputkeun eusi [`RefCell<T>`] (nganggo `RefCell::get_pin_mut`) teras mindahkeun kontén éta nganggo rujukan anu tiasa dimungkinkeun anu urang anggo engké.
//!
//! ## Examples
//!
//! Pikeun jinis sapertos [`Vec<T>`], duanana kamungkinan (pin struktural atanapi henteu) masuk akal.
//! A [`Vec<T>`] kalayan pin struktural tiasa ngagaduhan metode `get_pin`/`get_pin_mut` pikeun kéngingkeun rujukan kana unsur-unsur.Nanging, éta henteu tiasa *ngantep* nyauran [`pop`][Vec::pop] dina [`Vec<T>`] anu disemat kusabab éta bakal mindahkeun eusi (sacara struktural dipasang) eusi!Atanapi teu tiasa ngantepkeun [`push`][Vec::push], anu panginten tiasa dialokasi teras ogé mindahkeun konténna.
//!
//! [`Vec<T>`] tanpa pin struktural tiasa `impl<T> Unpin for Vec<T>`, kusabab eusina henteu pernah disematkan sareng [`Vec<T>`] nyalira saé pisan upami dipindahkeun ogé.
//! Dina waktos éta pinning ngan teu aya pangaruh kana vector pisan.
//!
//! Di perpustakaan standar, jinis pointer umumna henteu ngagaduhan pinning struktural, sahingga aranjeunna henteu nawiskeun ramalan panyamaran.Ieu naha `Box<T>: Unpin` tahan pikeun sadaya `T`.
//! Ngajadikeun rasa ngalakonan ieu pikeun jenis pointer, lantaran pindah ka `Box<T>` teu sabenerna mindahkeun `T`: nu [`Box<T>`] tiasa kalawan bébas movable (aka `Unpin`) sanajan `T` henteu.Nyatana, bahkan [`Pin`]`<`[`Box`]`<T>>`sareng [`Pin`] `<&mut T>` sok [`Unpin`] nyalira, ku alesan anu sami: eusina (`T`) dicubit, tapi petunjukna nyalira tiasa dipindahkeun tanpa mindahkeun data anu disemat.
//! Pikeun [`Box<T>`] sareng [`Pin`]`<`[`Box`]`<T>>`, naha konténna dipasut sadayana henteu leres tina naon panunjukna ditempelkeun, hartosna pinning henteu * struktural.
//!
//! Nalika ngalaksanakeun kombinator [`Future`], anjeun biasana peryogi pinn struktural pikeun futures anu bersarang, sabab anjeun kedah kéngingkeun referensi pinned pikeun nelepon [`poll`].
//! Tapi upami kombinator anjeun ngandung data sanés anu henteu kedah dicantélkeun, anjeun tiasa ngajantenkeun bidangna henteu struktural sahingga sacara bébas ngaksésna ku référénsi anu tiasa dirobih sanajan anjeun ngan ukur ngagaduhan [`Pin`]`<&mut Self>`(sapertos sakumaha dina implementasi [`poll`] anjeun nyalira).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Panunjuk anu dipasang.
///
/// Ieu mangrupikeun bungkus sakuriling pointer anu ngajantenkeun pointer "pin" nilaina di tempatna, nyegah nilai anu dirujuk ku pointer éta tina henteu tiasa dipindahkeun kecuali upami ngalaksanakeun [`Unpin`].
///
///
/// *Tingali dokuméntasi [`pin` module] pikeun penjelasan ngeunaan pinning.*
///
/// [`pin` module]: self
///
// Note: anu `Clone` diturunkeun di handap nyababkeun unsoundness sabab éta mungkin pikeun nerapkeun
// `Clone` pikeun rujukan anu tiasa dirobih.
// Tingali <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> pikeun langkung jelasna.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Pelaksanaan ieu henteu diturunkeun pikeun nyingkahan masalah kasihatan.
// `&self.pointer` henteu kedah diaksés kana palaksanaan trait anu teu dipercaya.
//
// Tingali <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> pikeun langkung jelasna.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Ngawangun `Pin<P>` énggal sakitar pointer kana sababaraha data jinis anu ngalaksanakeun [`Unpin`].
    ///
    /// Beda sareng `Pin::new_unchecked`, metoda ieu aman sabab pointer `P` dereferénsi kana jinis [`Unpin`], anu ngabatalkeun jaminan pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: nilai anu ditunjuk nyaéta `Unpin`, sareng kitu teu ngagaduhan syarat
        // sakitar pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps `Pin<P>` ieu balikkeun pointer anu janten dasarna.
    ///
    /// Ieu ngabutuhkeun yén data anu aya dina `Pin` ieu nyaéta [`Unpin`] sahingga urang tiasa malire invariants panyematan nalika muka konci éta.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Ngawangun `Pin<P>` énggal sakitar rujukan kana sababaraha data tina jinis anu tiasa atanapi henteu nerapkeun `Unpin`.
    ///
    /// Upami `pointer` ngahapus kana jinis `Unpin`, `Pin::new` kedah dianggo waé.
    ///
    /// # Safety
    ///
    /// constructor Ieu unsafe lantaran kami teu bisa garansi yén data nunjuk kana ku `pointer` ieu pinned, hartina data éta moal dipindahkeun atawa neundeun na batal nepika meunang turun.
    /// Upami `Pin<P>` anu didamelna henteu ngajamin yén data `P` nunjuk ka ditempelkeun, éta mangrupikeun palanggaran kontrak API sareng tiasa ngakibatkeun tingkah laku anu teu jelas dina operasi (safe) engké.
    ///
    /// Ku ngagunakeun cara ieu, anjeun ngadamel promise ngeunaan implementasi `P::Deref` sareng `P::DerefMut`, upami éta aya.
    /// Paling importantly, aranjeunna teu kudu kaluar ti alesan `self` maranéhna: `Pin::as_mut` na `Pin::as_ref` bakal nelepon `DerefMut::deref_mut` na `Deref::deref`*dina pointer pinned* na nyangka metodeu ieu pikeun uphold nu invariants pinning.
    /// Sumawona, ku nelepon metoda ieu anjeun promise yén rujukan `P` dereferensi moal dipindahkeun deui;khususna, henteu kedah dimungkinkeun pikeun kéngingkeun `&mut P::Target` teras ngalih tina rujukan éta (ngagunakeun, contona [`mem::swap`]).
    ///
    ///
    /// Salaku conto, nyauran `Pin::new_unchecked` dina `&'a mut T` henteu aman sabab nalika anjeun tiasa nyepelkeun salami `'a` hirupna, anjeun teu ngagaduhan kendali naha éta tetep dijepit sakali `'a` réngsé:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ieu kedah hartosna pointee `a` moal tiasa ngalih deui.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Alamat `a` dirobih janten slot tumpukan `b`, janten `a` ngalih sanaos kami sateuacanna nyepetkeun!Kami geus dilanggar kontrak API pinning.
    /////
    /// }
    /// ```
    ///
    /// A nilai, sakali pinned, kedah tetep pinned salamina (kecuali jenis na ngalaksanakeun `Unpin`).
    ///
    /// Nya kitu, nyauran `Pin::new_unchecked` dina `Rc<T>` henteu aman sabab tiasa aya alias kana data anu sami anu henteu tunduk kana larangan nyepitan:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Ieu kedah hartosna anu ditunjuk moal tiasa ngalih deui.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ayeuna, upami `x` mangrupikeun hiji-hijina rujukan, urang gaduh rujukan anu tiasa dirobih kana data anu urang dipasang di luhur, anu tiasa kami anggo pikeun mindahkeun éta sakumaha anu urang tingali dina conto samemehna.
    ///     // Kami parantos ngalanggar kontrak API pinning.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Meunangkeun rujukan anu dibéré pin tina pitunjuk ieu.
    ///
    /// Ieu cara umum pikeun ngalih ti `&Pin<Pointer<T>>` dugi ka `Pin<&T>`.
    /// Éta aman sabab, salaku bagian tina kontrak `Pin::new_unchecked`, pointee henteu tiasa ngalih saatos `Pin<Pointer<T>>` didamel.
    ///
    /// "Malicious" implementasi `Pointer::Deref` ogé dikaluarkeun ku kontrak `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // KESELAMATAN: tingali dokuméntasi ngeunaan fungsi ieu
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps `Pin<P>` ieu balikkeun pointer anu janten dasarna.
    ///
    /// # Safety
    ///
    /// Pungsi ieu henteu aman.Anjeun kudu ngajamin yén anjeun bakal neruskeun ngubaran pointer `P` sakumaha pinned sanggeus anjeun nyauran fungsi ieu, supados invariants dina tipe `Pin` bisa upheld.
    /// Mun kodeu maké `P` anu dihasilkeun teu neruskeun miara invariants pinning anu mangrupa palanggaran kontrak API tur bisa ngakibatkeun kabiasaan undefined di engké operasi (safe).
    ///
    ///
    /// Upami data anu ngadasarkeun nyaéta [`Unpin`], [`Pin::into_inner`] kedah dianggo waé.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Meunangkeun rujukan anu tiasa dipaténkeun tina petunjuk ieu.
    ///
    /// Ieu cara umum pikeun ngalih ti `&mut Pin<Pointer<T>>` dugi ka `Pin<&mut T>`.
    /// Éta aman sabab, salaku bagian tina kontrak `Pin::new_unchecked`, pointee henteu tiasa ngalih saatos `Pin<Pointer<T>>` didamel.
    ///
    /// "Malicious" implementasi `Pointer::DerefMut` ogé dikaluarkeun ku kontrak `Pin::new_unchecked`.
    ///
    /// Metoda ieu gunana nalika ngalakukeun sababaraha panggero kana fungsi anu nyéépkeun jinis pin.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // ngalakukeun naon
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` meakeun `self`, janten reborrow `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // KESELAMATAN: tingali dokuméntasi ngeunaan fungsi ieu
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Napelkeun nilai énggal dina mémori anu aya di sebalik rujukan anu dipasang.
    ///
    /// Ieu nimpa data anu dipasang, tapi henteu kunanaon: penghancur na tiasa dijalankeun sateuacan ditimpa, janten teu aya jaminan pinning anu dilanggar.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Nyusunna pin énggal ku cara pemetaan nilai interior.
    ///
    /// Contona, lamun hayang meunangkeun hiji `Pin` hiji widang hal, Anjeun bisa make ieu meunang aksés ka widang nu dina hiji garis kode.
    /// Nanging, aya sababaraha gotchas sareng "pinning projections" ieu;
    /// tingali dokuméntasi [`pin` module] pikeun detil langkung lengkep ngeunaan topik éta.
    ///
    /// # Safety
    ///
    /// Pungsi ieu henteu aman.
    /// Anjeun kedah ngajamin yén data anu anjeun balikeun moal ngalih salami nilai argumen henteu ngalih (contona, sabab éta mangrupikeun salah sahiji bidang tina nilai éta), sareng ogé yén anjeun henteu ngalih tina argumen anu anjeun tampi fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAFETY: kontrak kaamanan pikeun `new_unchecked` kedahna
        // dijaga ku anu nelepon.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Meunangkeun rujukan anu dibagi tina pin.
    ///
    /// Ieu aman sabab teu mungkin kaluar ti hiji rujukan dibagikeun.
    /// Éta sigana siga aya masalah di dieu kalayan mutability interior: kanyataanna, éta *mungkin* mindahkeun `T` tina `&RefCell<T>`.
    /// Nanging, ieu sanés masalah salami teu aya ogé `Pin<&T>` anu nunjuk kana data anu sami, sareng `RefCell<T>` henteu ngantep anjeun ngadamel rujukan anu disematkan kana eusina.
    ///
    /// Tingali diskusi ngeunaan ["pinning projections"] pikeun langkung jelasna.
    ///
    /// Note: `Pin` ogé nerapkeun `Deref` kana udagan, anu tiasa dianggo pikeun ngaksés nilai jero.
    /// Nanging, `Deref` ngan ukur nyayogikeun rujukan anu hirup salami nginjeum `Pin`, sanés hirupna `Pin` nyalira.
    /// Metoda ieu ngamungkinkeun ngarobah `Pin` kana rujukan anu hirupna sami sareng `Pin` asli.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ngarobih `Pin<&mut T>` ieu kana `Pin<&T>` kalayan hirup anu sami.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Kengingkeun rujukan anu tiasa dirobih kana data anu aya dina `Pin` ieu.
    ///
    /// Ieu ngabutuhkeun yén data anu aya dina `Pin` ieu nyaéta `Unpin`.
    ///
    /// Note: `Pin` ogé nerapkeun `DerefMut` kana data, anu tiasa dianggo pikeun ngaksés nilai jero.
    /// Nanging, `DerefMut` ngan ukur nyayogikeun rujukan anu hirup salami nginjeum `Pin`, sanés hirupna `Pin` nyalira.
    ///
    /// Metoda ieu ngamungkinkeun ngarobah `Pin` kana rujukan anu hirupna sami sareng `Pin` asli.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Kengingkeun rujukan anu tiasa dirobih kana data anu aya dina `Pin` ieu.
    ///
    /// # Safety
    ///
    /// Pungsi ieu henteu aman.
    /// Anjeun kedah ngajamin yén anjeun moal ngaluarkeun data tina rujukan anu tiasa ditampi nalika anjeun nampi fungsi ieu, supados invariants dina jinis `Pin` tiasa dijaga.
    ///
    ///
    /// Upami data anu ngadasarkeun nyaéta `Unpin`, `Pin::get_mut` kedah dianggo waé.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ngawangun pin anyar ku cara pemetaan nilai interior.
    ///
    /// Contona, lamun hayang meunangkeun hiji `Pin` hiji widang hal, Anjeun bisa make ieu meunang aksés ka widang nu dina hiji garis kode.
    /// Nanging, aya sababaraha gotchas sareng "pinning projections" ieu;
    /// tingali dokuméntasi [`pin` module] pikeun detil langkung lengkep ngeunaan topik éta.
    ///
    /// # Safety
    ///
    /// Pungsi ieu henteu aman.
    /// Anjeun kedah ngajamin yén data anu anjeun balikeun moal ngalih salami nilai argumen henteu ngalih (contona, sabab éta mangrupikeun salah sahiji bidang tina nilai éta), sareng ogé yén anjeun henteu ngalih tina argumen anu anjeun tampi fungsi interior.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // KESELAMATAN: panelepon tanggung jawab henteu mindahkeun éta
        // nilai kaluar tina rujukan ieu.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAFETY: salaku nilai `this` dijamin moal gaduh
        // parantos dipindahkeun, telepon ka `new_unchecked` ieu aman.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Kéngingkeun rujukan anu disematkan tina rujukan statik.
    ///
    /// Ieu aman, sabab `T` diinjeum pikeun hirupna `'static`, anu henteu pernah réngsé.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // Kaamanan: 'Pinjaman statis ngajamin data moal janten
        // moved/invalidated nepika meunang turun (nu pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Kéngingkeun référénsi anu tiasa dipaténkeun tina rujukan anu tiasa dirobih statik.
    ///
    /// Ieu aman, sabab `T` diinjeum pikeun hirupna `'static`, anu henteu pernah réngsé.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // Kaamanan: 'Pinjaman statis ngajamin data moal janten
        // moved/invalidated nepika meunang turun (nu pernah).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: hartosna kieu nu mana wae impl of `CoerceUnsized` anu ngamungkinkeun coercing tina
// jenis anu impls `Deref<Target=impl !Unpin>` kana jinis anu impls `Deref<Target=Unpin>` henteu leres.
// Naon waé implikasi sapertos kitu sigana bakal teu leres kusabab alesan anu sanés, janten, ngan urang kedah ati-ati supados henteu ngantep impls sapertos badarat di std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}