use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// A allocator mémori nu bisa didaptarkeun salaku standar perpustakaan baku urang ngaliwatan atribut `#[global_allocator]`.
///
/// Sababaraha metodeu ngabutuhkeun blok mémori janten *ayeuna dialokasikeun* ngalangkungan alokasi.hartosna kieu yén:
///
/// * alamat awal pikeun blok mémori éta sateuacanna dipulangkeun ku telepon sateuacana kana metode alokasi sapertos `alloc`, sareng
///
/// * blok mémori teu teras-teras diteruskeun, dimana blok-blok ditranslokasi ku cara dialirkeun kana metode deallocation sapertos `dealloc` atanapi ku dialirkeun kana metodeu realokasi anu ngabalikeun pointer anu henteu nol.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// The `GlobalAlloc` trait mangrupa trait `unsafe` pikeun Jumlah alesan, sarta implementors kudu mastikeun yén maranéhna taat ka kontrak ieu:
///
/// * Éta tingkah laku anu teu ditangtoskeun upami para panyalur global ngahiang.Watesan ieu tiasa diangkat dina future, tapi ayeuna panic tina salah sahiji fungsi ieu tiasa ngakibatkeun teu aman ingetan.
///
/// * `Layout` pamundut sareng itungan sacara umum kedah leres.Nelepon tina trait ieu diwenangkeun ngandelkeun kontrak dihartikeun dina unggal metoda, sarta implementors kudu mastikeun kontrak sapertos tetep leres.
///
/// * Anjeun panginten henteu ngandelkeun alokasi anu leres-leres kajadian, sanaos aya alokasi tumpukan anu jelas dina sumberna.
/// Optimizer tiasa ngadeteksi alokasi anu henteu dianggo anu tiasa ngaleungitkeun sapinuhna atanapi ngalih kana tumpukan sahingga henteu kantos nyungkeun alokasi.
/// Optimizer tiasa salajengna nganggap yén alokasi henteu tiasa disalahkeun, janten kode anu pernah gagal kusabab gagal alokasi ayeuna dumadakan tiasa dianggo sabab pangoptimal damel sapertos peryogi alokasi.
/// Langkung konkrit, conto kode di handap ieu henteu leres, henteu paduli naha pembagi custom anjeun ngamungkinkeun ngitung sabaraha alokasi anu kajantenan.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Catet yén optimisasi anu kasebut di luhur sanés hiji-hijina optimasi anu tiasa diterapkeun.Anjeun bisa umumna mah ngandelkeun jatah numpuk lumangsung lamun maranéhna bisa dihapus tanpa ngarobah kabiasaan program.
///   Naha alokasi kajantenan atanapi henteu sanés mangrupikeun bagian tina paripolah program, bahkan upami éta tiasa kauninga ngalangkungan alokasi anu ngalacak alokasi ku nyetak atanapi upami teu ngagaduhan efek samping.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alokasi mémori sakumaha anu dijelaskeun ku `layout` anu ditangtoskeun.
    ///
    /// Mulih a pointer ingetan karek-disadiakeun, atawa null keur nandaan gagalna alokasi.
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman sabab kalakuan anu teu ditangtoskeun tiasa ngahasilkeun upami anu nelepon teu mastikeun yén `layout` gaduh ukuran non-enol.
    ///
    /// (Penyuluh subtraits bisa nyadiakeun bounds beuki spésifik dina kabiasaan, misalna, ngajamin alamat sentinel atawa pointer null dina respon ka pamundut alokasi enol-ukuran.)
    ///
    /// Blok mémori anu dialokasikan tiasa atanapi henteu dikasinisikeun.
    ///
    /// # Errors
    ///
    /// Balikkeun pointer null nunjukkeun yén mémori parantos béak atanapi `layout` henteu cocog sareng ukuran atanapi alokasi alignment ieu.
    ///
    /// Implementations didorong ka balik null dina kacapean memori tinimbang aborting, tapi ieu teu sarat ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Deallocate blok memori dina `ptr` pointer anu ditangtoskeun ku `layout` anu ditangtoskeun.
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman sabab kalakuan anu teu ditangtoskeun tiasa ngahasilkeun upami anu nelepon teu mastikeun sadayana ieu:
    ///
    ///
    /// * `ptr` kedah denote hiji blok mémori keur disadiakeun via allocator ieu,
    ///
    /// * `layout` kedah janten tata perenah anu sami anu dianggo pikeun alokasi blok memori éta.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Behaves sapertos `alloc`, tapi ogé mastikeun yén eusina disetel ka nol sateuacan dipulangkeun.
    ///
    /// # Safety
    ///
    /// Pungsi ieu henteu aman pikeun alesan anu sami anu `alloc`.
    /// Nanging blok mémori anu dialokasikan dijamin bakal dikinisialisasi.
    ///
    /// # Errors
    ///
    /// Balik a hypothesis pointer nunjukkeun yén boh memori nyaéta exhausted atanapi `layout` teu papanggih ukuranana atanapi alignment konstrain allocator urang, ngan sakumaha dina `alloc`.
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // Kasalametan: kontrak kaamanan pikeun `alloc` kudu upheld ku panelepon.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KESELAMATAN: nalika alokasi hasil, daérah ti `ptr`
            // ukuran `size` dijamin valid pikeun nyerat.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Nyusut atanapi numuwuhkeun blok mémori kana `new_size` anu ditangtoskeun.
    /// Blok ieu dijelaskeun ku `ptr` pointer sareng `layout` anu ditangtoskeun.
    ///
    /// Lamun mulih ieu non-null pointer, teras kapamilikan ti blok memori referenced ku `ptr` geus dibikeun ka allocator ieu.
    /// Memori tiasa atanapi henteu tiasa ditranslokasi, sareng kedah dianggap teu tiasa dianggo (kacuali tangtosna éta ditransferkeun deui ka anu nelepon deui liwat nilai balik tina metode ieu).
    /// Blok mémori anyar dialokasikan sareng `layout`, tapi ku `size` diénggalan ka `new_size`.
    /// perenah anyar ieu kudu dipake lamun deallocating blok memori anyar kalawan `dealloc`.
    /// Kisaran `0..min(layout.size(), new_size) `tina blok mémori énggal dijamin ngagaduhan nilai anu sami sareng blok aslina.
    ///
    /// Upami metoda ieu mundur, maka kapamilikan blok mémori henteu acan ditransferkeun ka alokasi ieu, sareng eusi blok mémori henteu robih.
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman sabab kalakuan anu teu ditangtoskeun tiasa ngahasilkeun upami anu nelepon teu mastikeun sadayana ieu:
    ///
    /// * `ptr` kedah ayeuna dialokasikan ngalangkungan alokasi ieu,
    ///
    /// * `layout` kedah janten perenah anu sami anu dianggo pikeun ngaalokasikeun blok mémori éta,
    ///
    /// * `new_size` kudu leuwih gede ti nol.
    ///
    /// * `new_size`, nalika dibuleudkeun kana sababaraha `layout.align()` anu pang caketna, henteu kedah dilimpah teuing (nyaéta, nilai bunderan kedah kirang tina `usize::MAX`).
    ///
    /// (Penyuluh subtraits bisa nyadiakeun bounds beuki spésifik dina kabiasaan, misalna, ngajamin alamat sentinel atawa pointer null dina respon ka pamundut alokasi enol-ukuran.)
    ///
    /// # Errors
    ///
    /// Mulih hypothesis lamun tata perenah anyar teu papanggih ukuran na alignment konstrain of allocator, atanapi lamun reallocation disebutkeun gagal.
    ///
    /// Implementations didorong ka balik null dina kacapean memori tinimbang panicking atanapi aborting, tapi ieu teu sarat ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién wishing mun ngitung abort di respon ka kasalahan reallocation didorong nyauran fungsi [`handle_alloc_error`], tinimbang langsung invoking `panic!` atawa sarupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: panelepon kedah mastikeun yén `new_size` henteu kabanjiran.
        // `layout.align()` asalna tina `Layout` sahingga dijamin valid.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAFETY: panelepon kedah mastikeun yén `new_layout` langkung ageung tibatan enol.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // Kasalametan: blok saméméhna disadiakeun moal bisa tumpang tindih blok karek disadiakeun.
            // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}