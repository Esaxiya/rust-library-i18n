//! API alokasi mémori

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kasalahan `AllocError` nunjukkeun kagagalan alokasi anu tiasa disababkeun ku kasieun sumberdaya atanapi anu lepat nalika ngagabungkeun alesan input anu disayogikeun sareng alokasi ieu.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (urang peryogi ieu pikeun impl hilir trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementasi `Allocator` tiasa ngaalokasikeun, numuwuhkeun, ngaleutikan, sareng ngatasi blok data sawenang-wenang anu dijelaskeun ngalangkungan [`Layout`][].
///
/// `Allocator` dirancang pikeun dilaksanakeun dina ZSTs, rujukan, atawa pointers pinter kusabab sanggeus hiji allocator kawas `MyAlloc([u8; N])` teu bisa dipindahkeun, tanpa ngamutahirkeun nu pointers kana memori disadiakeun.
///
/// Beda sareng [`GlobalAlloc`][], alokasi saukuran ageung diijinkeun dina `Allocator`.
/// Upami alokator anu ngadukung henteu ngadukung ieu (sapertos jemalloc) atanapi balikeun pointer null (sapertos `libc::malloc`), ieu kedah dicekel ku palaksanaan na.
///
/// ### Memori ayeuna dialokasikan
///
/// Sababaraha metodeu ngabutuhkeun blok mémori janten *ayeuna dialokasikeun* ngalangkungan alokasi.hartosna kieu yén:
///
/// * alamat awal blok memori éta sateuacanna dipulangkeun ku [`allocate`], [`grow`], atanapi [`shrink`], sareng
///
/// * blok mémori teu teras-teras diteruskeun, dimana blokna langsung ditranslokasi ku diliwatan ka [`deallocate`] atanapi dirobih ku diliwatan ka [`grow`] atanapi [`shrink`] anu mulih `Ok`.
///
/// Mun `grow` atanapi `shrink` geus balik `Err`, anu pointer diliwatan tetep sah.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memori pas
///
/// Sababaraha metodeu ngabutuhkeun perenah *pas* blok mémori.
/// Naon hartosna pikeun perenah ka "fit" blok memori hartosna (atanapi sami, pikeun blok mémori ka "fit" perenah) nyaéta kaayaan di handap ieu anu kedah dicekel:
///
/// * Blok kedah dialokasikan sareng alignment anu sami sareng [`layout.align()`], sareng
///
/// * [`layout.size()`] anu disayogikeun kedah ragrag dina kisaran `min ..= max`, dimana:
///   - `min` nyaeta ukuran tina tata perenah nu panganyarna dipaké pikeun allocate blok, sarta
///   - `max` nyaéta ukuran aktual pangénggalna anu dipulangkeun ti [`allocate`], [`grow`], atanapi [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blok mémori anu dipulangkeun deui tina anu masihan kedah nunjuk kana mémori anu valid sareng nahan kaaslianana dugi ka conto sareng sadaya klon na murag,
///
/// * kloning atanapi mindahkeun alokasi teu kedah ngabatalkeun blok mémori anu dipulangkeun ti alokasi ieu.Alokasi anu diklon kudu kalakuanana saperti alokasi anu sami, sareng
///
/// * sagala pointer ka blok memori nu [*currently allocated*] bisa jadi diliwatan mun sagala metoda sejenna allocator nu.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Usaha pikeun nyayogikeun blok mémori.
    ///
    /// Dina kasuksésan, mulih [`NonNull<[u8]>`][NonNull] pasamoan ukuran sareng jaminan alignment `layout`.
    ///
    /// Blok anu dipulangkeun tiasa gaduh ukuran anu langkung ageung tibatan anu ditangtoskeun ku `layout.size()`, sareng tiasa atanapi henteu ngagaduhan inisialisasi.
    ///
    /// # Errors
    ///
    /// Balik `Err` nunjukkeun yén boh memori nyaéta exhausted atanapi `layout` teu papanggih ukuranana atanapi alignment konstrain allocator urang.
    ///
    /// Palaksanaan disarankeun pikeun ngabalikeun `Err` kana kacapean mémori tibatan panik atanapi ngagugurkeun, tapi ieu sanés sarat anu ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Behaves kawas `allocate`, tapi ogé ensures yén memori balik nyaeta nol-initialized.
    ///
    /// # Errors
    ///
    /// Balik `Err` nunjukkeun yén boh memori nyaéta exhausted atanapi `layout` teu papanggih ukuranana atanapi alignment konstrain allocator urang.
    ///
    /// Palaksanaan disarankeun pikeun ngabalikeun `Err` kana kacapean mémori tibatan panik atanapi ngagugurkeun, tapi ieu sanés sarat anu ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // Kasalametan: `alloc` mulih blok memori valid
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallocates mémori anu dirujuk ku `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` kedah nandaan blok memori [*currently allocated*] ngalangkungan alokasi ieu, sareng
    /// * `layout` kedah [*fit*] blok memori éta.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Usaha pikeun manjangan blok mémori.
    ///
    /// Mulih a [`NonNull<[u8]>`][NonNull] anyar ngandung hiji pointer sarta ukuran sabenerna mémori disadiakeun.Pointer cocog pikeun nyepeng data anu dijelaskeun ku `new_layout`.
    /// Pikeun ngalengkepan ieu, anu ngadeudeul tiasa manjangkeun alokasi anu dirujuk ku `ptr` pikeun nyocogkeun kana tata perenah anu énggal.
    ///
    /// Upami ieu ngembalikan `Ok`, maka kapamilikan blok mémori anu dirujuk ku `ptr` parantos ditransfer ka alokasi ieu.
    /// memori meureun atanapi henteu mungkin geus dibébaskeun, sarta kudu dianggap unusable iwal eta kasebut dibikeun deui ka panelepon deui via nilai balik tina metoda ieu.
    ///
    /// Lamun metoda ieu mulih `Err`, kapamilikan lajeng sahiji blok memori teu acan dibikeun ka allocator ieu, sarta eusi blok mémori anu unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` kedah nandaan blok memori [*currently allocated*] ngalangkungan alokasi ieu.
    /// * `old_layout` kedah [*fit*] blok memori (Argumen `new_layout` kedahna henteu cocog.).
    /// * `new_layout.size()` kudu leuwih gede ti atawa sarua jeung `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mulih `Err` lamun tata perenah anyar teu papanggih ukuran na alignment konstrain nu allocator ngeunaan allocator, atanapi lamun tumuwuh disebutkeun gagal.
    ///
    /// Palaksanaan disarankeun pikeun ngabalikeun `Err` kana kacapean mémori tibatan panik atanapi ngagugurkeun, tapi ieu sanés sarat anu ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Kasalametan: sabab `new_layout.size()` kudu leuwih gede ti atawa sarua jeung
        // `old_layout.size()`, boh alokasi mémori lami sareng énggal valid pikeun maca sareng nyerat `old_layout.size()` bait.
        // Ogé, kusabab alokasi anu lami teu acan diuruskeun, éta moal tiasa tumpang tindih `new_ptr`.
        // Ku kituna, panggero pikeun `copy_nonoverlapping` aman.
        // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Behaves sapertos `grow`, tapi ogé mastikeun yén kontén énggalna disetél ka nol sateuacan dikembalikan.
    ///
    /// Blok mémori bakal ngandung eusi sapertos kieu saatos suksés nelepon
    /// `grow_zeroed`:
    ///   * Bait `0..old_layout.size()` dilestarikan tina alokasi aslina.
    ///   * Bait `old_layout.size()..old_size` bakal dilestarikan atanapi nol, gumantung kana palaksanaan alokasi.
    ///   `old_size` ngarujuk kana ukuran blok mémori sateuacan nelepon `grow_zeroed`, anu tiasa langkung ageung tibatan ukuran anu tadina dipénta nalika dialokasikeun.
    ///   * Bait `old_size..new_size` ditoler.`new_size` nujul kana ukuran tina blok memori balik ku panggero `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` kedah nandaan blok memori [*currently allocated*] ngalangkungan alokasi ieu.
    /// * `old_layout` kedah [*fit*] blok memori (Argumen `new_layout` kedahna henteu cocog.).
    /// * `new_layout.size()` kudu leuwih gede ti atawa sarua jeung `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mulih `Err` lamun tata perenah anyar teu papanggih ukuran na alignment konstrain nu allocator ngeunaan allocator, atanapi lamun tumuwuh disebutkeun gagal.
    ///
    /// Palaksanaan disarankeun pikeun ngabalikeun `Err` kana kacapean mémori tibatan panik atanapi ngagugurkeun, tapi ieu sanés sarat anu ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // Kasalametan: sabab `new_layout.size()` kudu leuwih gede ti atawa sarua jeung
        // `old_layout.size()`, boh alokasi mémori lami sareng énggal valid pikeun maca sareng nyerat `old_layout.size()` bait.
        // Ogé, kusabab alokasi anu lami teu acan diuruskeun, éta moal tiasa tumpang tindih `new_ptr`.
        // Ku kituna, panggero pikeun `copy_nonoverlapping` aman.
        // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Usaha pikeun ngaleutikan blok mémori.
    ///
    /// Mulih a [`NonNull<[u8]>`][NonNull] anyar ngandung hiji pointer sarta ukuran sabenerna mémori disadiakeun.Pointer cocog pikeun nyepeng data anu dijelaskeun ku `new_layout`.
    /// Pikeun ngalengkepan ieu, anu masihan tiasa ngaleutikan alokasi anu dirujuk ku `ptr` pikeun nyocogkeun kana tata perenah anu énggal.
    ///
    /// Upami ieu ngembalikan `Ok`, maka kapamilikan blok mémori anu dirujuk ku `ptr` parantos ditransfer ka alokasi ieu.
    /// memori meureun atanapi henteu mungkin geus dibébaskeun, sarta kudu dianggap unusable iwal eta kasebut dibikeun deui ka panelepon deui via nilai balik tina metoda ieu.
    ///
    /// Lamun metoda ieu mulih `Err`, kapamilikan lajeng sahiji blok memori teu acan dibikeun ka allocator ieu, sarta eusi blok mémori anu unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` kedah nandaan blok memori [*currently allocated*] ngalangkungan alokasi ieu.
    /// * `old_layout` kedah [*fit*] blok memori (Argumen `new_layout` kedahna henteu cocog.).
    /// * `new_layout.size()` kudu jadi leuwih leutik batan atawa sarua jeung `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mulih `Err` upami tata perenah énggal henteu minuhan ukuran sareng alokasi alignment tina alokasi, atanapi upami nyusut upami gagal.
    ///
    /// Palaksanaan disarankeun pikeun ngabalikeun `Err` kana kacapean mémori tibatan panik atanapi ngagugurkeun, tapi ieu sanés sarat anu ketat.
    /// (Khususna: éta *sah* pikeun nerapkeun trait ieu di luhur perpustakaan alokasi asli anu nyababkeun kaleungitan ingetan.)
    ///
    /// Klién anu badé ngagugurkeun komputasi salaku réspon kana alokasi kasalahan didorong pikeun nelepon fungsi [`handle_alloc_error`], sanés langsung nyungkeun `panic!` atanapi anu sami.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KESELAMATAN: sabab `new_layout.size()` kedah langkung handap atanapi sami
        // `old_layout.size()`, boh alokasi mémori lami sareng énggal valid pikeun maca sareng nyerat `new_layout.size()` bait.
        // Ogé, kusabab alokasi anu lami teu acan diuruskeun, éta moal tiasa tumpang tindih `new_ptr`.
        // Ku kituna, panggero pikeun `copy_nonoverlapping` aman.
        // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Nyiptakeun adaptor "by reference" pikeun conto `Allocator` ieu.
    ///
    /// Adaptor balik ogé ngalaksanakeun `Allocator` sareng ngan saukur bakal nginjeum ieu.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KESELAMATAN: kontrak kaamanan kudu dijaga ku anu nelepon
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak kaamanan kudu dijaga ku anu nelepon
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak kaamanan kudu dijaga ku anu nelepon
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak kaamanan kudu dijaga ku anu nelepon
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}