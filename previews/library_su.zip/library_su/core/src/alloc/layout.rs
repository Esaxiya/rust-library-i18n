use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Nalika fungsi ieu dianggo dina hiji tempat sareng palaksanaanna tiasa ditetepkeun, usaha-usaha sateuacanna dilakukeun rustc langkung laun:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tata ruang blok memori.
///
/// Conto `Layout` ngajelaskeun tata peringatan anu khusus.
/// Anjeun ngawangun `Layout` salaku input pikeun masihan ka alokasi.
///
/// Sadaya tata ruang ngagaduhan ukuran anu pakait sareng kakuatan-of-dua alignment.
///
/// (Catet yén tata ruang *henteu* diperyogikeun pikeun ngagaduhan ukuran henteu nol, sanaos `GlobalAlloc` meryogikeun sadaya pamundut mémori ukuranana henteu nol.
/// Anu narelepon kedah mastikeun yén kaayaan sapertos kieu parantos dicumponan, nganggo panyadia khusus kalayan syarat anu langkung leupas, atanapi nganggo panganteur `Allocator` anu langkung lemes.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ukuran blok memori anu dipénta, diukur ku bait.
    size_: usize,

    // alignment sahiji blok dipénta memori, nu diukur dina bait.
    // kami mastikeun yén ieu teras-terasan kakuatan-dua, sabab API sapertos `posix_memalign` meryogikeunana sareng mangrupakeun kendala anu wajar pikeun maksa kana konstruktor Tata Letak.
    //
    //
    // (Sanajan, urang ulah analogously merlukeun `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Nyusunna `Layout` tina `size` sareng `align` tinangtu, atanapi mulih `LayoutError` upami salah sahiji kaayaan di handap ieu henteu kacumponan:
    ///
    /// * `align` kedah henteu nol,
    ///
    /// * `align` kedah janten kakuatan dua,
    ///
    /// * `size`, nalika dibuleudkeun kana sababaraha `align` anu pang caketna, henteu kedah overflow (nyaéta nilai buleud kedah kirang ti atanapi sami sareng `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kakuatan-of-dua ngakibatkeun align!=0.)

        // Ukuran anu dibulatkeun nyaéta:
        //   size_rounds_up=(size + align, 1)&! (align, 1);
        //
        // Urang terang ti luhur anu ngajajar!=0.
        // Mun nambahkeun (align, 1) henteu mudal, teras rounding up bakal rupa.
        //
        // Sabalikna,&-masking kalawan! (Align, 1) bakal subtract kaluar ukur-urutan low-bit.
        // Maka upami limpahan kajantenan ku jumlahna,&-mask moal tiasa dikirangan cekap pikeun méréskeun limpahanana.
        //
        //
        // Luhur ngakibatkeun yen ngecék jumlahna mudal nyaeta duanana perlu jeung kacukupan.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAFETY: kaayaan pikeun `from_size_align_unchecked` parantos
        // diparios di luhur.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Nyiptakeun perenah, bypassing sadayana cek.
    ///
    /// # Safety
    ///
    /// fungsi Ieu unsafe sakumaha teu pariksa nu preconditions ti [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAFETY: panelepon kedah mastikeun yén `align` langkung ageung tibatan enol.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ukuran minimum dina bait pikeun blok memori perenah ieu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Alignment byte minimum pikeun blok mémori tina perenah ieu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Constructs a `Layout` cocog pikeun ngayakeun nilai tina tipe `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // KESELAMATAN: jajaran dijamin ku Rust janten kakuatan dua sareng
        // ukuran + align combo dijamin pas dina rohangan alamat kami.
        // Hasilna anggo konstruktor anu teu dipariksa di dieu pikeun nyingkahan kode sisipan anu panics upami henteu dioptimalkeun cukup saé.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ngahasilkeun tata ruang ngajelaskeun rékaman anu tiasa dianggo pikeun nyayogikeun struktur patukang tonggong pikeun `T` (anu tiasa janten trait atanapi jinis sanés sapertos sapisan).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KESELAMATAN: tingali alesan dina `new` kunaon ieu ngagunakeun varian anu teu aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ngahasilkeun tata ruang ngajelaskeun rékaman anu tiasa dianggo pikeun nyayogikeun struktur patukang tonggong pikeun `T` (anu tiasa janten trait atanapi jinis sanés sapertos sapisan).
    ///
    /// # Safety
    ///
    /// Fungsi ieu ngan ukur aman pikeun ditelepon upami kaayaan sapertos kieu dicekel:
    ///
    /// - Mun `T` nyaeta `Sized`, fungsi ieu salawasna aman nelepon.
    /// - Upami buntut henteu ukuran tina `T` nyaéta:
    ///     - a [slice], maka panjang buntut keureut kedah integer intialisasi, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan berukuran statis) kedah pas dina `isize`.
    ///     - a [trait object], maka bagian anu tiasa ditunjuk tina pointer kedah nunjuk ka vtable anu valid pikeun tipe `T` anu diala ku coersion anu teu ngarobih, sareng ukuran *sakabéh nilai*(panjang buntut dinamis + awalan ukuran statis) kedah pas dina `isize`.
    ///
    ///     - hiji (unstable) [extern type], maka fungsi ieu teras-terasan ditelepon, tapi muga-muga panic atanapi sanésna balikkeun nilai anu lepat, sabab tata letak jinis éksternal henteu dipikaterang.
    ///     Ieu paripolah anu sami sareng [`Layout::for_value`] dina rujukan kana buntut jinis éksternal.
    ///     - Upami teu kitu, sacara konservatif teu kénging nelepon fungsi ieu.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KESELAMATAN: urang ngalirkeun prasarat fungsi ieu pikeun anu nelepon
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KESELAMATAN: tingali alesan dina `new` kunaon ieu ngagunakeun varian anu teu aman
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Nyiptakeun `NonNull` anu ngagantung, tapi saé pisan pikeun Tata Letak ieu.
    ///
    /// Catet yén nilai pointer berpotensi ngagambarkeun pointer anu valid, anu hartosna ieu henteu kedah dianggo salaku nilai "not yet initialized" sentinel.
    /// Jenis anu teu puguh alokasi kedah ngalacak inisialisasi ku cara sanésna.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // KESELAMATAN: align dijamin janten non-nol
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Nyiptakeun tata ruang anu ngajelaskeun rékaman anu tiasa nahan nilai tina tata letak anu sami sareng `self`, tapi éta ogé dijajarkeun kana alignment `align` (diukur dina bait).
    ///
    ///
    /// Upami `self` parantos parantos cocog sareng anu cocog, maka mulih deui `self`.
    ///
    /// Catet yén metoda ieu henteu nambihan padding naon waé pikeun ukuran umum, henteu paduli naha perenah anu dipulangkeun ngagaduhan alignment anu béda.
    /// Kalayan kecap séjén, upami `K` ngagaduhan ukuran 16, `K.align_to(32)` bakal *masih* gaduh ukuran 16.
    ///
    /// Mulang kasalahan upami kombinasi `self.size()` sareng `align` tinangtu ngalanggar kaayaan anu didaptarkeun dina [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Balik jumlah padding urang kedah lebetkeun saatos `self` pikeun mastikeun yén alamat ieu bakal nyugemakeun `align` (diukur dina bait).
    ///
    /// contona, upami `self.size()` 9, maka `self.padding_needed_for(4)` mulih 3, kusabab éta jumlah minimum bait padding anu diperyogikeun kanggo kéngingkeun alamat anu 4-sajajar (asumsina yén blok mémori anu saluyu dimimitian dina alamat anu dijejeran 4).
    ///
    ///
    /// Nilai balik fungsi ieu teu aya artina upami `align` sanés kakuatan-dua.
    ///
    /// Catet yén gunana nilai balik ngabutuhkeun `align` kirang ti atanapi sami sareng alignment alamat awal pikeun blok memori anu dialokasikan sacara gembleng.Salah sahiji cara pikeun nyugemakeun konstrain ieu nyaéta mastikeun `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Nilai anu dibuleudkeun nyaéta:
        //   len_rounds_up=(len + align, 1)&! (align, 1);
        // terus urang balikkeun bédana padding: `len_rounded_up - len`.
        //
        // Kami nganggo aritmatika modular sapanjang:
        //
        // 1. align dijamin janten> 0, janten align, 1 sok valid.
        //
        // 2.
        // `len + align - 1` tiasa kabanjiran ku paling seueur `align - 1`, janten&-mask kalayan `!(align - 1)` bakal mastikeun yén dina kasus overflow, `len_rounded_up` bakal sorangan janten 0.
        //
        //    Kituna teh padding balik, nalika ditambahkeun kana `len`, ngahasilkeun 0, nu trivially satisfies nu alignment `align`.
        //
        // (Tangtosna, usaha pikeun nyebarkeun blok mémori anu ukuran sareng padding overflow ku cara di luhur kedah nyababkeun alokator ngahasilkeun kasalahan.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Nyiptakeun perenah ku rounding ukuran perenah ieu nepi ka sababaraha of alignment tata perenah urang.
    ///
    ///
    /// Ieu sarua jeung nambahkeun hasil tina `padding_needed_for` kana ukuranana tata perenah urang ayeuna.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ieu moal tiasa ngabahekeun.Dicutat tina invariant of Layout:
        // > `size`, lamun rounded nepi ka sababaraha pangcaketna ti `align`,
        // > kedah henteu overflow (nyaéta, nilai buleud kedah kirang ti
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Nyiptakeun perenah anu ngajelaskeun rékor pikeun `n` instansi `self`, kalayan jumlah padding anu pas antara masing-masing pikeun mastikeun yén unggal conto anu dipasihkeun ukuran sareng alignment na.
    /// Dina kasuksésan, balikkeun `(k, offs)` dimana `k` mangrupikeun perenah susunan sareng `offs` nyaéta jarak antara mimiti unggal unsur dina larik.
    ///
    /// Dina limpahan aritmatika, mulih `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ieu moal tiasa ngabahekeun.Dicutat tina invariant of Layout:
        // > `size`, lamun rounded nepi ka sababaraha pangcaketna ti `align`,
        // > kedah henteu overflow (nyaéta, nilai buleud kedah kirang ti
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align parantos dipikaterang valid sareng alokasi_size parantos aya
        // padded geus.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Nyiptakeun perenah anu ngajelaskeun rékor pikeun `self` dituturkeun ku `next`, kalebet padding anu diperyogikeun pikeun mastikeun yén `next` bakal leres dijejeran, tapi *henteu aya padding labuh*.
    ///
    /// Dina raraga cocog sareng perenah C perwakilan `repr(C)`, anjeun kedah nyauran `pad_to_align` saatos ngalegaan perenah sareng sadaya bidang.
    /// (Teu aya jalan pikeun cocog sareng standar Rust perwakilan perwakilan `repr(Rust)`, as it is unspecified.)
    ///
    /// Catet yén alignment tina perenah anu dihasilkeun bakal maksimal pikeun `self` sareng `next`, dina urutan pikeun mastikeun alignment kadua bagian.
    ///
    /// Mulih `Ok((k, offset))`, dimana `k` mangrupikeun tata letak tina catetan konvénatasi sareng `offset` mangrupikeun lokasi anu relatif, dina bait, ti mimiti `next` anu dilebetkeun dina catetan anu disatukan (asumsina yén rékaman éta sorangan dimimitian dina offset 0).
    ///
    ///
    /// Dina limpahan aritmatika, mulih `LayoutError`.
    ///
    /// # Examples
    ///
    /// Pikeun ngitung tata letak struktur `#[repr(C)]` sareng offset lapangan tina tata ruang na:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Émut kana finalisasi sareng `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // tés yén éta jalan
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Nyiptakeun perenah anu ngajelaskeun rékor pikeun `n` instansi `self`, kalayan henteu aya padding antara unggal conto.
    ///
    /// Catet yén, henteu sapertos `repeat`, `repeat_packed` henteu ngajamin yén conto anu diulang tina `self` bakal leres dijejeran, sanajan conto `self` anu leres dijejerankeun.
    /// Kalayan kecap sanésna, upami tata perenah anu dipulang ku `repeat_packed` dianggo pikeun nyayogikeun hiji susunan, éta henteu dijamin yén sadaya unsur dina susunan bakal leres-leres dijejeran.
    ///
    /// Dina limpahan aritmatika, mulih `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Nyiptakeun perenah anu ngajelaskeun rékor pikeun `self` dituturkeun ku `next` kalayan henteu padding tambihan antara duaan.
    /// Kusabab henteu dilebetkeun padding, alignment of `next` henteu relevan, sareng henteu dilebetkeun *pisan* kana tata perenah anu dihasilkeun.
    ///
    ///
    /// Dina limpahan aritmatika, mulih `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Nyiptakeun perenah anu ngajelaskeun rékor pikeun `[T; n]`.
    ///
    /// Dina limpahan aritmatika, mulih `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parameter anu dipasihkeun ka `Layout::from_size_align` atanapi sababaraha konstruktor `Layout` anu sanés henteu nyugemakeun konstrain na anu didokumentasikeun.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (urang peryogi ieu pikeun impl hilir trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}