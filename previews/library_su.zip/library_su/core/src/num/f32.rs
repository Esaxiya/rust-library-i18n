//! Konstanta khusus pikeun jenis titik ngambang presisi tunggal `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Nomer anu signifikan sacara matématis disayogikeun dina sub-modul `consts`.
//!
//! Pikeun konstanta anu ditetepkeun langsung dina modul ieu (benten sareng anu ditetepkeun dina sub-modul `consts`), kode anyar kedahna nganggo konstantaitan anu pakait anu ditetepkeun langsung kana jinis `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix atanapi dasar tina representasi internal `f32`.
/// Anggo [`f32::RADIX`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // cara anu dituju
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Jumlah angka penting dina dasar 2.
/// Anggo [`f32::MANTISSA_DIGITS`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // cara anu dituju
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Jumlah perkiraan angka penting dina dasar 10.
/// Anggo [`f32::DIGITS`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // cara anu dituju
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] nilai pikeun `f32`.
/// Anggo [`f32::EPSILON`] wae.
///
/// Ieu anu ngabédakeun antara `1.0` sareng nomer anu langkung ageung diwakilan.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // cara anu dituju
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Nilai `f32` terhingga pangleutikna.
/// Anggo [`f32::MIN`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // cara anu dituju
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Nilai `f32` normal positip pangleutikna.
/// Anggo [`f32::MIN_POSITIVE`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // cara anu dituju
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Nilai `f32` terhingga pangageungna.
/// Anggo [`f32::MAX`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // cara anu dituju
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Hiji anu langkung ageung tibatan kamungkinan kakuatan minimum 2 éksponén.
/// Anggo [`f32::MIN_EXP`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // cara anu dituju
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Kamungkinan maksimum 2 éksponén.
/// Anggo [`f32::MAX_EXP`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // cara anu dituju
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Daya normal minimum anu tiasa tina 10 éksponén.
/// Anggo [`f32::MIN_10_EXP`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // cara anu dituju
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Kakuatan maksimal 10 éksponénter.
/// Anggo [`f32::MAX_10_EXP`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // cara anu dituju
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Sanés Nomer (NaN).
/// Anggo [`f32::NAN`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // cara anu dituju
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Teu aya watesna (∞).
/// Anggo [`f32::INFINITY`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // cara anu dituju
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Teu aya watesna négatip (−∞).
/// Anggo [`f32::NEG_INFINITY`] wae.
///
/// # Examples
///
/// ```rust
/// // jalan béak
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // cara anu dituju
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Konstanta matématika dasar.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ngaganti sareng konstanta matématika tina cmath.

    /// Ximaks X Archimedes '
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Bunderan lengkep konstan (τ)
    ///
    /// Sarua jeung 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Nomer Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radix atanapi dasar tina representasi internal `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Jumlah angka penting dina dasar 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Jumlah perkiraan angka penting dina dasar 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] nilai pikeun `f32`.
    ///
    /// Ieu anu ngabédakeun antara `1.0` sareng nomer anu langkung ageung diwakilan.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Nilai `f32` terhingga pangleutikna.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Nilai `f32` normal positip pangleutikna.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Nilai `f32` terhingga pangageungna.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Hiji anu langkung ageung tibatan kamungkinan kakuatan minimum 2 éksponén.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Kamungkinan maksimum 2 éksponén.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Daya normal minimum anu tiasa tina 10 éksponén.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Kakuatan maksimal 10 éksponénter.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Sanés Nomer (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Teu aya watesna (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Teu aya watesna négatip (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Mulih `true` upami nilai ieu `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` teu aya di masarakat di buruan umum kusabab masalah ngeunaan portabilitas, janten palaksanaan ieu kanggo panggunaan swasta sacara internal.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Mulih `true` upami nilai ieu positif tanpa wates atanapi tanpa wates négatip, sareng `false` sanés.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Mulih `true` upami nomer ieu sanés teu terbatas teu `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Teu kedah ngadamel NaN nyalira: upami diri NaN, babandinganna henteu leres, persis sakumaha anu dipikahoyong.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Mulih `true` upami nomer na [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Nilai antara `0` sareng `min` nyaéta Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Mulih `true` upami jumlahna sanés nol, tanpa wates, [subnormal], atanapi `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Nilai antara `0` sareng `min` nyaéta Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Mulih katégori titik kumalayang tina nomer.
    /// Upami ngan ukur hiji harta anu bade diuji, umumna langkung gancang nganggo predikat khususna.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Mulih `true` upami `self` ngagaduhan tanda positip, kalebet `+0.0`, `NaN`s kalayan tanda positip bit sareng takterhingga positif.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Mulih `true` upami `self` ngagaduhan tanda négatip, kalebet `-0.0`, `NaN`s kalayan tanda bit négatip sareng tak terbatas négatip.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 nyarios: isSignMinus(x) leres upami sareng ngan upami x ngagaduhan tanda négatip.
        // isSignMinus dilarapkeun ka nol sareng NaN ogé.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Nyandak (inverse) bulak-balik angka, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Ngarobih radian kana derajat.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Anggo konstanta pikeun presisi anu langkung saé.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Ngarobih derajat kana radian.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Mulih maksimal dua nomer.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Upami salah sahiji argumenna nyaéta NaN, maka argumen anu sanés dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Balikkeun minimum dua nomer.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Upami salah sahiji argumenna nyaéta NaN, maka argumen anu sanés dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Babak ka arah nol sareng ngarobah kana jinis bilangan bulat primitif, asumsina yén nilaina terbatas sareng pas dina jenis éta.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Nilaina kedah:
    ///
    /// * Sanés `NaN`
    /// * Teu janten wates
    /// * Janten representable dina tipe balik `Int`, saatos nyingkirkeun bagian pecahan na
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmisiasi atah kana `u32`.
    ///
    /// Ieu ayeuna sami sareng `transmute::<f32, u32>(self)` dina sadaya platform.
    ///
    /// Tingali `from_bits` pikeun sawala ngeunaan ngeunaan portabilitas operasi ieu (ampir teu aya masalah).
    ///
    /// Catet yén fungsi ieu béda ti casting `as`, anu nyobian ngajaga nilai *numerik*, sareng sanés nilai bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() henteu casting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: `u32` mangrupikeun datatype lami anu polos sahingga urang tiasa teras ngirimkeunana
        unsafe { mem::transmute(self) }
    }

    /// Transmisiasi atah tina `u32`.
    ///
    /// Ieu ayeuna sami sareng `transmute::<u32, f32>(v)` dina sadaya platform.
    /// Tétéla ieu luar biasa dibabawa, kusabab dua alesan:
    ///
    /// * Floats and Ints gaduh endianness anu sami dina sadaya platform anu didukung.
    /// * IEEE-754 pas pisan netepkeun tata perenah bit.
    ///
    /// Nanging aya hiji peringatan: sateuacan versi 2008 tina IEEE-754, kumaha napsirkeun bit signalling NaN henteu leres-leres ditetepkeun.
    /// Kaseueuran platform (khususna x86 sareng ARM) milih interpretasi anu pamustunganana distandarkeun di 2008, tapi sabagian henteu (khususna MIPS).
    /// Hasilna, sadaya NaNs anu nunjukkeun kana MIPS nyaéta NaN anu sepi dina x86, sareng sabalikna.
    ///
    /// Daripada nyobian pikeun ngalestarikeun cross-platform signaling-ness, palaksanaan ieu langkung resep ngalaksanakeun bit anu tepat.
    /// Ieu ngandung harti yén sagala muatan anu disandikeun dina NaNs bakal dilestarikan sanajan hasil tina metode ieu dikirimkeun kana jaringan tina mesin x86 dugi ka MIPS.
    ///
    ///
    /// Upami hasil tina metode ieu ngan ukur dimanipulasi ku arsitéktur anu sami anu ngahasilkeunana, maka moal aya prihatin portabilitas.
    ///
    /// Upami input sanés NaN, maka teu aya patalina sareng portabilitas.
    ///
    /// Upami anjeun henteu paduli ngeunaan signallingness (sigana pisan), maka teu aya perhatian portabilitas.
    ///
    /// Catet yén fungsi ieu béda ti casting `as`, anu nyobian ngajaga nilai *numerik*, sareng sanés nilai bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SAFETY: `u32` mangrupikeun datatype lami anu polos sahingga urang tiasa teras transmut ti dinya
        // Tétéla masalah kaamanan sareng sNaN parantos kaleuleuwihi!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Balikkeun peringatan mémori nomer titik ngambang ieu salaku susunan bait dina orte (network) big-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Balikkeun peringatan mémori nomer titik ngambang ieu salaku susunan bait dina urutan bait sakedik-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Balikkeun peringatan mémori nomer titik ngambang ieu salaku susunan bait dina urutan bait asli.
    ///
    /// Nalika endianness asli target platform digunakeun, kode portabel kedah nganggo [`to_be_bytes`] atanapi [`to_le_bytes`], sakumaha pantes, tibatan.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Balikkeun peringatan mémori nomer titik ngambang ieu salaku susunan bait dina urutan bait asli.
    ///
    ///
    /// [`to_ne_bytes`] kedah langkung resep tibatan ieu sabisana.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SAFETY: `f32` mangrupikeun datatype lami anu polos sahingga urang tiasa teras ngirimkeunana
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Ngadamel nilai titik kumambang tina perwakilanna salaku susunan bait dina endian ageung.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Ngadamel nilai titik kumambang tina perwakilanna salaku susunan bait dina sakedik endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Ngadamel nilai titik ngambang tina perwakilanna salaku susunan bait dina endian asli.
    ///
    /// Nalika endianness asli target platform digunakeun, kode portabel sigana hoyong nganggo [`from_be_bytes`] atanapi [`from_le_bytes`], sakumaha pantesna.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Mulang tarekat antara diri sareng nilai-nilai sanés.
    /// Beda sareng perbandingan parsial standar antara nomer titik ngambang, perbandingan ieu teras-terasan ngahasilkeun mesen saluyu sareng total predikat Orde sakumaha ditetepkeun dina standar titik ngambang IEEE 754 (2008 révisi).
    /// Nilai-nilai dipesen dina urutan ieu:
    /// - sepi négatip nan
    /// - Sinyal négatip NaN
    /// - Teu aya watesna négatip
    /// - Angka négatip
    /// - Angka subnormal négatip
    /// - Enol négatip
    /// - Positip nol
    /// - Angka subnormal positip
    /// - Angka positip
    /// - Teu aya watesna positip
    /// - Signal positip NaN
    /// - Pisan sepi NaN
    ///
    /// Catet yén fungsi ieu henteu saluyu sareng [`PartialOrd`] sareng [`PartialEq`] implementasi `f32`.Khususna, aranjeunna nganggap négatip négatip sareng positip sami, sedengkeun `total_cmp` henteu.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Dina hal négatip, flip sadayana bit kecuali tanda pikeun ngahontal perenah anu sami salaku bilangan bungkus dua urang
        //
        // Naha ieu jalan?Float IEEE 754 diwangun ku tilu lapangan:
        // Asup sakedik, éksponénsial sareng mantissa.Susunan kolom exponent sareng mantissa sacara gembleng ngagaduhan sipat anu urutan bitwise na sami sareng gedena numerik dimana gedena dihartikeun.
        // Gedéna henteu biasana didefinisikeun kana nilai NaN, tapi IEEE 754 totalOrder ngahartikeun nilai NaN ogé pikeun nuturkeun urutan bitwise.Ieu ngakibatkeun urutan anu dipedar dina koméntar koméntar.
        // Nanging, representasi gedena sami pikeun nomer négatip sareng positip-ngan ukur tanda anu bénten.
        // Pikeun gampang ngabandingkeun floats salaku integers anu ditandatanganan, urang kedah flip exponent sareng mantissa bit upami nomer négatip.
        // Kami sacara efektif ngarobih nomer janten "two's complement" form.
        //
        // Pikeun ngalakukeun flip, kami nyusun topeng sareng XOR ngalawan éta.
        // Kami henteu ngitung "all-ones except for the sign bit" topéng tina nilai anu ditandatanganan négatip: tanda pergeseran katuhu-ngalegaan bilangan bulat, janten kami "fill" topéng nganggo bit tanda, teras ngarobah kana unsigned pikeun nyorong langkung enol.
        //
        // Dina nilai positip, topéng sadayana nol, janten éta henteu-sanés.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Batesan nilai kana interval anu tangtu kecuali éta NaN.
    ///
    /// Mulih `max` upami `self` langkung ageung tibatan `max`, sareng `min` upami `self` kirang ti `min`.
    /// Upami teu kitu ieu mulih `self`.
    ///
    /// Catet yén fungsi ieu mulih NaN upami nilai awalna NaN ogé.
    ///
    /// # Panics
    ///
    /// Panics upami `min > max`, `min` nyaéta NaN, atanapi `max` nyaéta NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}