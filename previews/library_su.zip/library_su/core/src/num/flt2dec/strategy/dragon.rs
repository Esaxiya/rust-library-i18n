//! Ampir langsung (tapi rada dioptimalkeun) tarjamahan Rust Gambar 3 tina "Nyetak Angka Angka-Titik Gancang sareng Akurat" [^ 1].
//!
//!
//! [^1]: Burger, RG sareng Dybvig, RK 1996. Nyitak angka-angka ngambang
//!   gancang sareng akurat.SIGPLAN Henteu.31, 5 (Mei 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// arrays precalculated of `Digit`s for 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// ngan ukur tiasa dianggo nalika `x < 16 * scale`;`scaleN` kedah `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Palaksanaan modeu pondok pikeun Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // angka `v` kana pormat katelah:
    // - sarua jeung `mant * 2^exp`;
    // - dipiheulaan ku `(mant - 2 *minus)* 2^exp` dina jinis aslina;jeung
    // - dituturkeun ku `(mant + 2 *plus)* 2^exp` dina jinis aslina.
    //
    // jelas, `minus` sareng `plus` moal tiasa nol.(pikeun infinities, urang nganggo nilai luar jangkauan.) ogé kami nganggap sahenteuna aya hiji digit dihasilkeun, nyaéta `mant` moal tiasa nol teuing.
    //
    // ieu ogé ngandung hartos yén angka naon antara `low = (mant - minus)*2^exp` sareng `high = (mant + plus)* 2^exp` bakal map kana nomer titik ngambang ieu, kalayan batesan kalebet nalika mantissa aslina bahkan (nyaéta `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` nyaéta `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // perkirakeun `k_0` tina input aslina anu nyugemakeun `10^(k_0-1) < high <= 10^(k_0+1)`.
    // `k` anu kabeungkeut ngabeungkeut `10^(k-1) < high <= 10^k` anu ngaraos diitung engké.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ngarobah `{mant, plus, minus} * 2^exp` kana bentuk pecahan sahingga:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // ngabagi `mant` ku `10^k`.ayeuna `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // ngalereskeun nalika `mant + plus > scale` (atanapi `>=`).
    // urang henteu leres-leres ngarobih `scale`, kumargi urang tiasa ngalangkungan perkalian awal tibatan.
    // kiwari `scale < mant + plus <= scale * 10` sarta kami siap ngahasilkeun digit.
    //
    // dicatet yén `d[0]`*tiasa* janten nol, nalika `scale - plus < mant < scale`.
    // dina hal ieu kaayaan ngabuleudkeun (`up` dihandap) bakal langsung dipicu.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // sami sareng skala `scale` ku 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` pikeun generasi digit.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, dimana `d[0..n-1]` mangrupikeun angka anu dihasilkeun dugi ka ayeuna:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (sahingga `mant / scale < 10`) dimana `d[i..j]` mangrupikeun pondok pikeun `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // ngahasilkeun hiji angka: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ieu mangrupikeun pedaran saderhana tina algoritma Naga anu dirobih.
        // seueur derivasi panengah sareng argumén kompléks dikaluarkeun pikeun merenah.
        //
        // mimitian ku invariants anu dirobih, sabab kami parantos ngapdet `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // anggap yén `d[0..n-1]` mangrupikeun gambaran anu paling pondok antara `low` sareng `high`, nyaéta `d[0..n-1]` nyugemakeun duanana ieu tapi `d[0..n-2]` henteu:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: angka buleud ka `v`);jeung
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (digit terakhir leres).
        //
        // kaayaan kadua saderhana janten `2 * mant <= scale`.
        // ngarengsekeun invariants dina hal `mant`, `low` sareng `high` ngahasilkeun versi saderhana tina kaayaan munggaran: `-plus < mant < minus`.
        // ti saprak `-plus < 0 <= mant`, urang ngagaduhan gambaran anu pang pondokna nalika `mant < minus` sareng `2 * mant <= scale`.
        // (urut janten `mant <= minus` nalika mantissa aslina merata.)
        //
        // nalika anu kadua henteu tahan (`2 * mant> skala`), urang kedah ningkatkeun angka anu terakhir.
        // ieu cekap pikeun malikkeun kaayaan éta: urang parantos terang yén generasi digit ngajamin `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // dina hal ieu, kaayaan anu mimiti janten `-plus < mant - scale < minus`.
        // ti saprak `mant < scale` saatos generasi, urang gaduh `scale < mant + plus`.
        // (Deui, ieu janten `scale <= mant + plus` nalika mantissa aslina nyaeta malah.)
        //
        // pondokna:
        // - lirén sareng buleud `down` (jaga angka sapertos) nalika `mant < minus` (atanapi `<=`).
        // - liren sareng buleud `up` (ningkatkeun digit terakhir) nalika `scale < mant + plus` (atanapi `<=`).
        // - tetep ngahasilkeun disebutkeun.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // urang gaduh perwakilan anu paling pondok, teraskeun kana pambulatan

        // mulangkeun para invariants.
        // ieu ngajantenkeun algoritma anu salawasna diakhiri: `minus` sareng `plus` sok ningkat, tapi `mant` dipotong modulo `scale` sareng `scale` parantos dibereskeun.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ngabuleudkeun kajadian nalika i) ngan ukur kaayaan buleudan-up anu dipicu, atanapi ii) duanana kaayaan dipicu sareng dasi putus langkung resep dibuleudkeun.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // upami ngabuleudkeun ngarobih panjangna, éksponén ogé kedah robih.
        // sigana kaayaan ieu sesah pisan pikeun nyugemakeun (sigana teu mungkin), tapi urang ngan ukur aman sareng konsisten di dieu.
        //
        // KESELAMATAN: kami ngainisialkeun mémori éta di luhur.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // KESELAMATAN: kami ngainisialkeun mémori éta di luhur.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Palaksanaan mode anu pasti sareng tetep pikeun Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // perkirakeun `k_0` tina input aslina anu nyugemakeun `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // ngabagi `mant` ku `10^k`.ayeuna `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ngalereskeun nalika `mant + plus >= scale`, dimana `plus / scale = 10^-buf.len() / 2`.
    // supados tetep bignum ukuran-ukuran, urang saleresna nganggo `mant + floor(plus) >= scale`.
    // urang henteu leres-leres ngarobih `scale`, kumargi urang tiasa ngalangkungan perkalian awal tibatan.
    // deui jeung algoritma shortest, `d[0]` tiasa enol tapi bakal pamustunganana rounded up.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // sami sareng skala `scale` ku 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // upami urang damel sareng watesan angka terakhir, urang kedah nyingkat panyangga sateuacan ngajadikeun anu saleresna pikeun ngahindaran dua kali.
    //
    // perhatikeun yén urang kedah ngagedékeun panyangga deui nalika lumangsungna lumangsung!
    let mut len = if k < limit {
        // waduh, urang bahkan henteu tiasa ngahasilkeun *hiji* angka.
        // ieu tiasa nalika, saur, urang ngagaduhan anu sapertos 9.5 sareng ayeuna dibuleudkeun janten 10.
        // urang balikkeun panyangga kosong, dikecualkeun ku kasus buleud engké anu lumangsung nalika `k == limit` sareng kedah ngahasilkeun persis hiji digit.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` pikeun generasi digit.
        // (ieu tiasa mahal, janten ulah ngitung éta nalika panyangga kosong.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // digit ieu sadayana nol, urang lirén di dieu ulah *henteu* coba lakukeun babak!rada, eusian digit sésana.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // KESELAMATAN: kami ngainisialkeun mémori éta di luhur.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ngabuleudkeun upami urang lirén di tengah digit upami digit ieu persis persis 5000 ..., parios digit sateuacanna sareng cobaan bulatkeun ka rata (nyaéta, hindarkeun ngurilingan nalika digit sateuacanna rata).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAFETY: `buf[len-1]` diinisialisasi.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // upami ngabuleudkeun ngarobih panjangna, éksponén ogé kedah robih.
        // tapi urang dipénta sajumlah pasti digit, janten ulah ngarobih panyangga ...
        // KESELAMATAN: kami ngainisialkeun mémori éta di luhur.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... kacuali kami dipénta presisi anu tetep.
            // urang ogé kedah parios éta, upami panyangga aslina kosong, digit tambihan ngan ukur tiasa ditambihan nalika `k == limit` (kasus edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // KESELAMATAN: kami ngainisialkeun mémori éta di luhur.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}