/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// samentawis ieu sacara dokuméntasi sacara éksténsif, ieu sacara prinsip swasta anu ngan ukur dilakukeun umum pikeun tés.
// entong nyilakakeun kami.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Algoritma generasi Digit.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Ukuran minimum panyangga diperyogikeun pikeun modeu pang pondokna.
///
/// Éta mangrupikeun sanés non-sepele pikeun diturunkeun, tapi ieu mangrupikeun tambah jumlah maksimal digit decimal anu signifikan tina pormat algoritma kalayan hasil anu paling pondok.
///
/// Formula anu pasti nyaéta `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Nalika `d` ngandung digit decimal, ningkatkeun digit terakhir sareng nyebarkeun bawa.
/// Balikkeun angka salajengna nalika nyababkeun panjangna robih.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] sadayana kasalapan
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 buleud nepi ka 1000..000 kalayan éksponén anu ningkat
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // hiji panyangga kosong buleud (rada anéh tapi wajar)
            Some(b'1')
        }
    }
}

/// Bagian anu diformat.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Nomer angka nol.
    Zero(usize),
    /// Jumlah literal dugi ka 5 angka.
    Num(u16),
    /// Salin verbalm tina bait anu dipasihkeun.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Mulihkeun panjang bait tepat bagian anu dipasihkeun.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Nyerat bagian kana panyangga anu disayogikeun.
    /// Mulih jumlah bait tinulis, atanapi `None` upami panyangga henteu cekap.
    /// (Éta masih tiasa ngantunkeun bait anu ditulis sabagian dina panyangga; ulah ngandelkeun éta.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Hasil anu diformat ngandung hiji atanapi langkung bagian.
/// Ieu tiasa nyerat kana bait panyangga atanapi dirobih kana senar anu dialokasikan.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Irisan bait ngalambangkeun tanda, boh `""`, `"-"` atanapi `"+"`.
    pub sign: &'static str,
    /// Bagian anu diformat badé ditunjuk saatos tanda sareng padalisan enol opsional.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Mulihkeun panjang byte pasti tina hasil pormat gabungan.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Nyerat sadaya bagian anu diformat kana panyangga anu disayogikeun.
    /// Mulih jumlah bait tinulis, atanapi `None` upami panyangga henteu cekap.
    /// (Éta masih tiasa ngantunkeun bait anu ditulis sabagian dina panyangga; ulah ngandelkeun éta.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Format anu dibéré nomer decimal `0.<...buf...> * 10^exp` kana bentuk decimal kalayan sahenteuna jumlah digit pecahan.
///
/// Hasilna disimpen kana susunan bagian anu disayogikeun sareng sapotong bagian tulisan dikembalikan.
///
/// `frac_digits` tiasa kirang tina jumlah digit pecahan saleresna dina `buf`;
/// éta bakal teu dipalire sareng digit lengkep bakal dicitak.Éta ngan ukur dianggo pikeun nyetak tambahan nol saatos digentoskeun kana digit.
/// Maka `frac_digits` of 0 hartosna yén éta ngan ukur bakal nyetak digit anu dipasihkeun sareng anu sanés.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // upami aya pangwatesan dina posisi angka pamungkas, `buf` dianggap kénca-padded sareng nol virtual.
    // jumlah nol virtual, `nzeroes`, sami sareng `max(0, exp + frac_digits - buf.len())`, sahingga posisi digit terakhir `exp - buf.len() - nzeroes` henteu langkung ti `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |nol |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` diitung sacara individual pikeun masing-masing kasus pikeun nyegah ngabahekeun.
    //

    if exp <= 0 {
        // titik desimal sateuacan digitus digit: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // titik desimal aya dina angka anu dihasilkeun: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // KESELAMATAN: urang nembé ngainisialisasi unsur `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // KESELAMATAN: urang nembé ngainisialisasi unsur `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // titik desimal saatos disalin angka: [1234][____0000] atanapi [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // KESELAMATAN: urang nembé ngainisialisasi unsur `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // KESELAMATAN: urang nembé ngainisialisasi unsur `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Ngformat angka decimal `0.<...buf...> * 10^exp` kana bentuk éksponénsial kalayan sahenteuna jumlah digit anu dipasihkeun.
///
/// Nalika `upper` nyaéta `true`, éksponénna bakal dieusian ku `E`;sanésna éta `e`.
/// Hasilna disimpen kana susunan bagian anu disayogikeun sareng sapotong bagian tulisan dikembalikan.
///
/// `min_digits` tiasa kirang tina jumlah digit signifikan dina `buf`;
/// éta bakal teu dipalire sareng digit lengkep bakal dicitak.Éta ngan ukur dianggo pikeun nyetak tambahan nol saatos digentoskeun kana digit.
/// Janten, `min_digits == 0` hartosna éta ngan bakal nyitak angka anu dipasihkeun sareng anu sanés.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // ulah underflow nalika exp nyaéta i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // KESELAMATAN: urang nembé ngainisialisasi unsur `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Pilihan pormat tanda.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Nyitak `-` ngan ukur pikeun nilai négatip sanés.
    Minus, // -inf -1 0 0 1 inf nan
    /// Nyitak `-` ngan ukur pikeun nilai négatip (kalebet enol négatip).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Nyitak `-` pikeun nilai négatip sanés-nol, atanapi `+` sanésna.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Nyitak `-` pikeun naon waé nilai négatip (kalebet enol négatip), atanapi `+` sanésna.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Mulang senar bait statik anu saluyu sareng tanda anu bakal diformat.
/// Éta tiasa `""`, `"+"` atanapi `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Nyusun nomer titik ngambang anu ditangtoskeun kana bentuk desimal kalayan sahenteuna masihan jumlah digit pecahan.
/// Hasilna disimpen kana susunan bagian anu disayogikeun bari ngamangpaatkeun buffer byte salaku goresan.
/// `upper` ayeuna henteu dianggo tapi tinggaleun pikeun kaputusan future pikeun ngarobih kasus nilai anu teu aya watesna, nyaéta `inf` sareng `nan`.
///
/// Bagéan kahiji anu bakal diterjemahkeun sok `Part::Sign` (anu tiasa janten senar kosong upami henteu aya tandana anu dipasang).
///
/// `format_shortest` kedah janten fungsi generasi-digit anu mendakan.
/// Sakuduna ngabalikeun bagian tina panyangga anu diinisialisasi.
/// Anjeun panginten hoyong `strategy::grisu::format_shortest` kanggo ieu.
///
/// `frac_digits` tiasa kirang tina jumlah digit pecahan saleresna dina `v`;
/// éta bakal teu dipalire sareng digit lengkep bakal dicitak.Éta ngan ukur dianggo pikeun nyetak tambahan nol saatos digentoskeun kana digit.
/// Maka `frac_digits` of 0 hartosna yén éta ngan ukur bakal nyetak digit anu dipasihkeun sareng anu sanés.
///
/// Buffer bait kedah sahenteuna `MAX_SIG_DIGITS` bait panjang.
/// Kudu aya sahanteuna 4 bagian anu sayogi, kusabab kasus anu paling parah sapertos `[+][0.][0000][2][0000]` sareng `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Nyusun nomer titik ngambang anu ditangtoskeun kana bentuk desimal atanapi bentuk éksponénsial, gumantung kana éksponén anu hasilna.
/// Hasilna disimpen kana susunan bagian anu disayogikeun bari ngamangpaatkeun buffer byte salaku goresan.
/// `upper` digunakeun pikeun nangtoskeun hal nilai non-terhingga (`inf` sareng `nan`) atanapi kasus awalan éksponén (`e` atanapi `E`).
/// Bagéan kahiji anu bakal diterjemahkeun sok `Part::Sign` (anu tiasa janten senar kosong upami henteu aya tandana anu dipasang).
///
/// `format_shortest` kedah janten fungsi generasi-digit anu mendakan.
/// Sakuduna ngabalikeun bagian tina panyangga anu diinisialisasi.
/// Anjeun panginten hoyong `strategy::grisu::format_shortest` kanggo ieu.
///
/// `dec_bounds` mangrupikeun `(lo, hi)` tuple sapertos angka na diformat salaku decimal ngan nalika `10^lo <= V < 10^hi`.
/// Catet yén ieu mangrupikeun *jelas*`V` sanés `v` anu sanés!Janten eksponén anu dicitak dina bentuk éksponénsial moal tiasa aya dina kisaran ieu, nyingkahan kekeliruan.
///
///
/// Buffer bait kedah sahenteuna `MAX_SIG_DIGITS` bait panjang.
/// Kudu aya sahenteuna 6 bagian anu sayogi, kusabab kasus anu paling parah sapertos `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Mulihkeun perkiraan anu rada kasar (wates luhur) pikeun ukuran panyangga maksimum anu diitung tina éksponén anu didékode.
///
/// Wates anu pasti nyaéta:
///
/// - nalika `exp < 0`, panjang maksimum `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - nalika `exp >= 0`, panjang maksimum `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` kirang ti `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, anu dina gilirannana kirang ti `20 + (1 + exp* log_10 x)`.
/// Kami nganggo kanyataan yén `log_10 2 < 5/16` sareng `log_10 5 < 12/16`, anu cekap pikeun tujuan urang.
///
/// Naha urang peryogi ieu?Fungsi `format_exact` bakal ngeusian sadaya panyangga kacuali diwatesan ku watesan digit anu terakhir, tapi kamungkinan jumlah digit anu dipénta ageung pisan (saur, 30,000 digit).
///
/// Seuseueurna seuseueurna panyangga bakal dieusian ku nol, janten kami henteu hoyong nyebarkeun sadayana panyangga sateuacanna.
/// Akibatna, pikeun alesan naon waé,
/// 826 bait buffer kedahna cekap pikeun `f64`.Bandingkeun ieu sareng nomer saleresna pikeun kasus anu paling parah: 770 bait (nalika `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Format anu dibéré nomer titik ngambang kana bentuk éksponénsial kalayan jumlah digit anu dipasihan persis.
/// Hasilna disimpen kana susunan bagian anu disayogikeun bari ngamangpaatkeun buffer byte salaku goresan.
/// `upper` digunakeun pikeun nangtoskeun kasus awalan éksponén (`e` atanapi `E`).
/// Bagéan kahiji anu bakal diterjemahkeun sok `Part::Sign` (anu tiasa janten senar kosong upami henteu aya tandana anu dipasang).
///
/// `format_exact` kedah janten fungsi generasi-digit anu mendakan.
/// Sakuduna ngabalikeun bagian tina panyangga anu diinisialisasi.
/// Anjeun panginten hoyong `strategy::grisu::format_exact` kanggo ieu.
///
/// Buffer bait sahenteuna kedah `ndigits` bait panjang kecuali `ndigits` ageung saurna ngan ukur nomer digit anu bakal kantos diserat.
/// (Tipping point pikeun `f64` sakitar 800, janten 1000 bait kedahna cekap.) Kudu aya sahenteuna 6 bagian anu sayogi, kusabab kasus anu paling parah sapertos `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Format anu dibéré nomer titik ngambang kana bentuk decimal kalayan jumlah digit frékuénsi anu ditangtoskeun.
/// Hasilna disimpen kana susunan bagian anu disayogikeun bari ngamangpaatkeun buffer byte salaku goresan.
/// `upper` ayeuna henteu dianggo tapi tinggaleun pikeun kaputusan future pikeun ngarobih kasus nilai anu teu aya watesna, nyaéta `inf` sareng `nan`.
/// Bagéan kahiji anu bakal diterjemahkeun sok `Part::Sign` (anu tiasa janten senar kosong upami henteu aya tandana anu dipasang).
///
/// `format_exact` kedah janten fungsi generasi-digit anu mendakan.
/// Sakuduna ngabalikeun bagian tina panyangga anu diinisialisasi.
/// Anjeun panginten hoyong `strategy::grisu::format_exact` kanggo ieu.
///
/// Buffer bait kedahna cekap pikeun kaluaran kecuali `frac_digits` anu ageung anu ngan ukur jumlah digit anu bakal kantos diserat.
/// (Tipping point pikeun `f64` sakitar 800, sareng 1000 bait kedahna cekap.) Kudu aya sahanteuna 4 bagian anu sayogi, kusabab kasus anu paling parah sapertos `[+][0.][0000][2][0000]` sareng `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // éta *mungkin*`frac_digits` téh gedé pisan.
            // `format_exact` bakal mungkas rendering angka langkung awal dina kasus ieu, sabab kami ketat dibatesan ku `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // pangwatesan éta henteu tiasa dicumponan, janten ieu kedahna sapertos nol teu paduli `exp` éta.
                // ieu henteu kalebet kasus yén watesan parantos patepung ngan ukur saatos babak final;éta kasus biasa sareng `exp = limit + 1`.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // KESELAMATAN: urang nembé ngainisialisasi unsur `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // KESELAMATAN: urang nembé ngainisialisasi unsur `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}