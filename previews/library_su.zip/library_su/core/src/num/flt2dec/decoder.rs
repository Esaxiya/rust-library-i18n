//! Ngadekode nilai titik ngambang kana bagian-bagian individu sareng rentang kasalahan.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dicatikeun nilai tak terbatas anu teu ditandatanganan, sapertos:
///
/// - Nilai aslina sami sareng `mant * 2^exp`.
///
/// - Jumlah naon waé ti `(mant - minus)*2^exp` dugi ka `(mant + plus)* 2^exp` bakal buleud kana nilai aslina.
/// Kisaran na kaasup ngan nalika `inclusive` nyaéta `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa skala.
    pub mant: u64,
    /// Kisaran kasalahan anu langkung handap.
    pub minus: u64,
    /// Rentang kasalahan luhur.
    pub plus: u64,
    /// Éksponén anu dibagikeun dina basa 2.
    pub exp: i16,
    /// Leres nalika rentang kasalahan kaasup.
    ///
    /// Dina IEEE 754, ieu leres nalika mantissa aslina sami.
    pub inclusive: bool,
}

/// Dicatikeun nilai unsigned.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, naha positip atanapi négatip.
    Infinite,
    /// Enol, boh positip atanapi négatip.
    Zero,
    /// Angka bérés kalayan medan anu dékode deui.
    Finite(Decoded),
}

/// Jinis titik kumalayang anu tiasa `dékode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Nilai normalisasi minimum minimum.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Ngahasilkeun tanda (leres nalika négatip) sareng nilai `FullDecoded` tina jumlah titik ngambang.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // tatangga: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode salawasna ngajaga éksponén, janten mantissa skala pikeun subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // tatangga: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // dimana maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // tatangga: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}