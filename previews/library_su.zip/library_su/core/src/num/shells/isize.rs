//! Konstanta pikeun jenis wilangan bulat anu ditandatanganan.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Kodeu anyar kedah nganggo konstanta pakait langsung dina jenis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }