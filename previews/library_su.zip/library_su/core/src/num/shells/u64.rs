//! Konstanta pikeun jinis wilangan bulat anu henteu ditandatanganan 64-bit.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Kodeu anyar kedah nganggo konstanta pakait langsung dina jenis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }