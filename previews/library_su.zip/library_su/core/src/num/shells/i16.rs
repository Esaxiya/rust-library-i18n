//! Konstanta pikeun jinis bilangan bulat anu ditandatanganan 16-bit.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Kodeu anyar kedah nganggo konstanta pakait langsung dina jenis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }