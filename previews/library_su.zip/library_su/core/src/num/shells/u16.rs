//! Konstanta pikeun jinis wilangan bulat 16-bit unsigned.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Kodeu anyar kedah nganggo konstanta pakait langsung dina jenis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }