//! Jenis kasalahan pikeun konvérsi kana jinis integral.

use crate::convert::Infallible;
use crate::fmt;

/// Jinis kasalahan balik nalika konversi jenis integral anu dicentang gagal.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Cocog tinimbang maksa pikeun mastikeun yén kode sapertos `From<Infallible> for TryFromIntError` di luhur bakal tetep jalan nalika `Infallible` janten landian pikeun `!`.
        //
        //
        match never {}
    }
}

/// Éror anu tiasa dipulangkeun nalika ngétang bilangan bulat.
///
/// Éror ieu dianggo salaku jinis error kanggo fungsi `from_str_radix()` dina jinis bilangan bulat primitif, sapertos [`i8::from_str_radix`].
///
/// # Nyababkeun poténsial
///
/// Diantara panyabab anu sanés, `ParseIntError` tiasa dialungkeun kusabab ngarah atanapi nyusudkeun rohangan bodas dina senar sapertos, nalika diala tina input standar.
///
/// Ngagunakeun metode [`str::trim()`] mastikeun yén teu aya spasi bodas sateuacana parsing.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum pikeun nyimpen sababaraha jinis kasalahan anu tiasa nyababkeun ngabatesan bilangan bulat gagal.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Nilai dikurai kosong.
    ///
    /// Diantara sabab-sabab séjén, varian ieu bakal diwangun nalika nguraikeun senar kosong.
    Empty,
    /// Ngandung digit anu teu valid dina kontéks na.
    ///
    /// Diantara sabab-sabab séjén, varian ieu bakal diwangun nalika nguraikeun senar anu ngandung char sanés ASCII.
    ///
    /// Varian ieu ogé diwangun nalika `+` atanapi `-` salah tempat dina tali anu nyalira atanapi di tengah nomer.
    ///
    ///
    InvalidDigit,
    /// Integer ageung teuing pikeun disimpen dina tipe integer target.
    PosOverflow,
    /// Integer leutik teuing pikeun disimpen dina tipe integer target.
    NegOverflow,
    /// Nilai éta Zero
    ///
    /// Varian ieu bakal dikaluarkeun nalika senar parsing ngagaduhan nilai nol, anu haram pikeun jenis non-enol.
    ///
    Zero,
}

impl ParseIntError {
    /// Kaluaran anu ngajentrekeun nyababkeun bilangan bulat gagal.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}