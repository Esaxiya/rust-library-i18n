//! Bit fiddling dina IEEE 754 ngambang positip.Nomer négatip henteu sareng henteu kedah diurus.
//! Angka titik ngambang normal gaduh representasi kanonis sakumaha (frac, exp) sapertos nilainya 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) dimana N mangrupikeun jumlah bit.
//!
//! Subnormal rada beda sareng anéh, tapi prinsip anu sami diterapkeun.
//!
//! Nanging, di dieu, kami ngagambarkeun aranjeunna salaku (sig, k) kalayan f positip, sapertos ajénna f *
//! 2 <sup>e</sup> .Di sagigireun ngajantenkeun "hidden bit" eksplisit, ieu ngarobah éksponén ku pergeseran mantissa.
//!
//! Pasang ku cara anu sanés, biasana floats ditulis salaku (1) tapi didieu aranjeunna ditulis salaku (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kami nyauran (1) salaku **representasi pecahan** sareng (2) salaku **representasi integral**.
//!
//! Seueur fungsi dina modul ieu ngan ukur nanganan angka normal.Rutinitas dec2flt sacara konservatif nyandak jalur lambat sacara universal-leres (Algoritma M) pikeun jumlah anu alit pisan sareng seueur pisan.
//! Algoritma éta peryogi ngan ukur next_float() anu nanganan subnormal sareng nol.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Anu ngabantosan trait pikeun nyingkahan duplikat dasarna sadaya kode konvérsi pikeun `f32` sareng `f64`.
///
/// Tingali koméntar modul modul induk pikeun kunaon ieu diperyogikeun.
///
/// Kedah **henteu kantos** dilaksanakeun pikeun jinis sanés atanapi dianggo di luar modul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Jenis anu dianggo ku `to_bits` sareng `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Ngalaksanakeun transmutasi atah kana bilangan bulat.
    fn to_bits(self) -> Self::Bits;

    /// Ngalaksanakeun transmutasi atah tina bilangan bulat.
    fn from_bits(v: Self::Bits) -> Self;

    /// Mulih katégori anu nomer ieu asup.
    fn classify(self) -> FpCategory;

    /// Balikkeun mantissa, éksponénan sareng lebet salaku bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dékode ngambang.
    fn unpack(self) -> Unpacked;

    /// Casts tina bilangan bulat leutik anu tiasa diwakilan persis.
    /// Panic upami bilangan bulat henteu tiasa diwakilan, kode anu sanés dina modul ieu pastikeun moal ngantep éta kajantenan.
    fn from_int(x: u64) -> Self;

    /// Meunang nilai 10 <sup>e</sup> tina tabel anu tos diitung.
    /// Panics pikeun `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Naon namina nyarios.
    /// Langkung gampang pikeun kode heuras tibatan ngagugulung intrinsik sareng ngarep-ngarep LLVM teras-terasan ngalipet na.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Kabeungkeut konservatif dina angka decimal input anu teu tiasa ngahasilkeun overflow atanapi nol atanapi
    /// subnormal.Meureun éksponén desimal tina nilai normal maksimum, ku kitu namina.
    const MAX_NORMAL_DIGITS: usize;

    /// Nalika digit decimal anu paling penting ngagaduhan nilai tempat langkung ageung ti ieu, jumlahna pasti dibuleudkeun dugi ka teu aya watesna.
    ///
    const INF_CUTOFF: i64;

    /// Nalika digit decimal paling penting ngagaduhan nilai tempat kirang ti ieu, jumlahna pasti dibuleudkeun ka nol.
    ///
    const ZERO_CUTOFF: i64;

    /// Jumlah bit dina éksponén.
    const EXP_BITS: u8;

    /// Jumlah bit dina significanceand,*kalebet* bit anu disumputkeun.
    const SIG_BITS: u8;

    /// Jumlah bit dina significanceand,*teu kaasup* bit anu disumputkeun.
    const EXPLICIT_SIG_BITS: u8;

    /// Éksponén légal maksimum dina ngagambarkeun fraksional.
    const MAX_EXP: i16;

    /// Eksponén légal minimum dina répréséntasi fraksional, teu kaasup subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` pikeun ngagambarkeun integral, nyaéta, kalayan pergeseran dilarapkeun.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` dikodekeun (nyaéta, kalayan bias ngimbangan)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pikeun ngagambarkeun integral, nyaéta, kalayan pergeseran dilarapkeun.
    const MIN_EXP_INT: i16;

    /// Teges normalisasi maksimum dina representasi anu teu integral.
    const MAX_SIG: u64;

    /// Minimumnormalisasi anu penting dina répréséntasi integral.
    const MIN_SIG: u64;
}

// Seuseueurna jalan pikeun #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Balikkeun mantissa, éksponénan sareng lebet salaku bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias Exponent + mantissa shift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe henteu pasti naha `as` buleud leres dina sadaya platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Balikkeun mantissa, éksponénan sareng lebet salaku bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias Exponent + mantissa shift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe henteu pasti naha `as` buleud leres dina sadaya platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Ngarobih `Fp` kana jinis mesin anu paling caket.
/// Teu nanganan hasil anu teu normal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f nyaéta 64 bit, janten xe gaduh pergeseran mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Buleudkeun 64-bit tegesand ka T::SIG_BITS bit kalayan satengah-ka-sakitar.
/// Henteu nanganan éksploitasi éksponénsial.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Saluyukeun shift mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Tibalik `RawFloat::unpack()` pikeun nomer dinormalisasi.
/// Panics upami teges atanapi exponent henteu valid pikeun nomer anu dinormalisasi.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Dipiceun sakedik disumputkeun
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Saluyukeun exponén pikeun bias exponent sareng shift mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Tinggalkeun tanda bit dina 0 ("+"), nomer kami sadayana positip
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ngawangun anu teu normal.Mantissa tina 0 diidinan sareng ngawangun nol.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Éksponén anu dienkode nyaéta 0, bit tanda nyaéta 0, janten urang ngan kedah ngainterpretasi deui bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Perkiraan bignum ku Fp.Babak dina 0.5 ULP kalayan satengah ka-rata.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Kami neukteuk sadayana bit sateuacan indéks `start`, nyaéta, sacara épéktip sacara leres belah ku jumlah `start`, janten ieu ogé exponén anu urang peryogikeun.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Babak (half-to-even) gumantung kana bit-truncated.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Milarian nomer titik terapung anu langkung ageung langkung alit tibatan argumen.
/// Henteu nanganan subnormal, nol, atanapi underflow éksponénsial.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Milarian nomer titik terapung pangleutikna anu langkung ageung tibatan argumen.
// Operasi ieu jenuh, nyaéta next_float(inf) ==inf.
// Beda sareng kaseueuran kode dina modul ieu, fungsi ieu henteu nganggo nol, subnormal, sareng infinities.
// Sanajan kitu, kawas sagala kode sejenna di dieu, teu nungkulan nan na angka négatif.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ieu sigana saé leres janten leres, tapi éta hasil.
        // 0.0 dikodekeun salaku kecap sadaya-nol.Subnormal aya 0x000m ... m dimana m janten mantissa.
        // Khususna, anu paling leutik anu paling leutik nyaéta 0x0 ... 01 sareng anu pangageungna nyaéta 0x000F ... F.
        // Jumlah normal pangleutikna nyaéta 0x0010 ... 0, janten kasus sudut ieu ogé jalan.
        // Upami paningkatan ngabahekeun mantissa, bit mawa nambahan éksponén anu dipikahoyong, sareng bit mantissa janten enol.
        // Kusabab konvénsi bit anu disumputkeun, ieu ogé anu urang hoyongkeun!
        // Tungtungna, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}