//! Fungsi Utilitas pikeun bignum anu henteu raos teuing janten metode.

// FIXME Ngaran modul ieu rada hanjakal, kumargi modul anu sanés ogé ngimpor `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Nguji naha motong sadaya bit kirang penting tibatan `ones_place` ngenalkeun kasalahan relatif kirang, sami, atanapi langkung ageung tibatan 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Upami sadaya sésa bit nyaéta nol, éta= 0.5 ULP, sanésna> 0.5 Upami teu aya deui bit (half_bit==0), ieu di handap ogé leres mulih Sarua.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Ngarobih senar ASCII anu ngandung ukur angka decimal kana `u64`.
///
/// Henteu ngalakukeun pamariksaan pikeun karakter overflow atanapi salah, janten upami anu nelepon teu ati-ati, hasilna bogus sareng tiasa panic (sanaos henteu `unsafe`).
/// Salaku tambahan, senar kosong diperlakukeun salaku nol.
/// Fungsi ieu aya sabab
///
/// 1. ngagunakeun `FromStr` on `&[u8]` merlukeun `from_utf8_unchecked`, anu anu goréng, sarta
/// 2. nyusun hasil tina `integral.parse()` sareng `fractional.parse()` langkung rumit tibatan sadaya fungsi ieu.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Ngarobih string digit ASCII kana bignum.
///
/// Sapertos `from_str_unchecked`, fungsi ieu gumantung kana parser pikeun nalungtik non-angka.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Ngabuka bignum kana bilangan bulat 64.Panics upami jumlahna ageung teuing.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ékstrak sauntuyan bit.

/// Indéks 0 nyaéta anu paling henteu penting sareng kisaranna satengah kabuka sapertos biasana.
/// Panics upami dipenta nimba langkung bit ti pas kana jinis balik.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}