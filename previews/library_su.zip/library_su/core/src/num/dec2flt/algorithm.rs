//! Rupa-rupa algoritma tina kertas.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Jumlah bit anu penting di Fp
const P: u32 = 64;

// Urang ngan saukur nyimpen pendekatan pangsaéna pikeun *sadayana* éksponén, janten variabel "h" sareng kaayaan anu pakait tiasa disingkirkeun.
// Ieu dagang kinerja pikeun sababaraha kilobytes rohangan.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Dina kaseueuran arsitéktur, operasi titik ngambang ngagaduhan ukuran anu eksplisit, janten presisi tina perhitungan ditangtukeun dumasar kana unggal operasi.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Dina x86, x87 FPU digunakeun pikeun operasi apungan upami ekstensi SSE/SSE2 henteu sayogi.
// x87 FPU ngoperasikeun sareng 80 bit presisi sacara standar, anu hartosna operasi bakal buleud dugi ka 80 bit anu ngabalukarkeun dua kali lumangsung nalika nilai-nilai akhirna diwakilan salaku
//
// 32/64 nilai bit ngambang.Pikeun ngungkulan ieu, kecap kontrol FPU tiasa diatur sahingga itungan dilakukeun dina presisi anu dipikahoyong.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktur anu digunakeun pikeun ngajaga nilai aslina tina kecap kontrol FPU, sahingga tiasa disimpen deui nalika strukturna murag.
    ///
    ///
    /// x87 FPU mangrupikeun daptar 16-bit anu bidangna sapertos kieu:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokuméntasi pikeun sadaya lapangan sayogi dina Buku Panduan Pamekar Perangkat Lunak IA-32 (Jilid 1).
    ///
    /// Hijina bidang anu aya hubunganana pikeun kode ieu nyaéta PC, Precision Control.
    /// Widang ieu nangtoskeun katepatan tina operasi anu dilakukeun ku FPU.
    /// Éta tiasa disetél ka:
    ///  - 0b00, presisi tunggal, 32-bit
    ///  - 0b10, presisi dobel nyaéta, 64-bit
    ///  - 0b11, presisi ngalegaan ganda nyaéta, 80-bit (kaayaan standar) Nilai 0b01 ditangtayungan sareng henteu kedah dianggo.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAFETY: paréntah `fldcw` parantos diaudit pikeun tiasa dianggo leres
        // sagala `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Kami nganggo sintaksis ATT pikeun ngadukung LLVM 8 sareng LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Susunan bidang presisi FPU ka `T` sareng mulihkeun `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Ngitung nilai pikeun kolom Control Precision anu cocog pikeun `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // standar, 80 bit
        };

        // Kéngingkeun nilai aslina tina kecap kontrol pikeun mulangkeunana engké, nalika struktur `FPUControlWord` turun SAFETY: paréntah `fnstcw` parantos diaudit pikeun tiasa dianggo leres kalayan `u16` naon waé
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Kami nganggo sintaksis ATT pikeun ngadukung LLVM 8 sareng LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Atur kecap pangendali kana katepatan anu dipikahoyong.
        // Ieu dihontal ku masking jauh tina presisi lami (bit 8 sareng 9, 0x300) sareng ngagentoskeun sareng bendera presisi anu diitung di luhur.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Jalur gancang Bellerophon ngagunakeun bilangan bulat sareng ukuran mesin.
///
/// Ieu diekstraksi kana fungsi anu misah sahingga tiasa diusahakeun sateuacan ngawangun bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Kami ngabandingkeun nilai anu pas kana MAX_SIG caket tungtungna, ieu ngan ukur gancang, panolakan murah (sareng ogé ngabébaskeun sésana kode tina hariwang ngeunaan aliran masuk).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Jalur gancang sacara krusial gumantung kana aritmatika anu dibuleudkeun kana jumlah bit anu leres tanpa dibuleudkeun panengah.
    // Dina x86 (tanpa SSE atanapi SSE2) ieu ngabutuhkeun presisi tumpukan x87 FPU dirobah supados langsung buleud ka 64/32 bit.
    // Fungsi `set_precision` jaga netepkeun presisi kana arsitéktur anu meryogikeun netepkeunana ku ngarobah kaayaan global (sapertos kecap kontrol x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Kasus e <0 henteu tiasa dilipet kana branch anu sanés.
    // Kakuatan négatip ngahasilkeun bagian frékuénsi ulang dina binér, anu dibuleudkeun, anu nyababkeun kasalahan anu nyata (sareng aya kalana rada signifikan!) Dina hasil akhir.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritma Bellerophon mangrupikeun kode sepele anu dibenerkeun ku analisis numerik anu teu pati penting.
///
/// Babak "f" kana apungan sareng 64 bit tegesand sareng kalikeun ku perkiraan `10^e` pangsaéna (dina format titik ngambang anu sami).Ieu sering cekap kéngingkeun hasil anu leres.
/// Nanging, nalika hasilna caket satengahna antara dua float (ordinary) anu caket, kasalahan bunderan sanyawa tina ngalikeun dua perkiraan hartosna hasilna tiasa pareum ku sababaraha bit.
/// Nalika ieu kajantenan, Algoritma iteratif Sunda ngalereskeun hal-hal.
///
/// "close to halfway" anu digulung ku tangan dijantenkeun tepat ku analisis numerik dina kertas.
/// Dina kecap Clinger:
///
/// > Slop, dinyatakeun dina unit anu paling henteu penting, mangrupikeun kaiket pikeun kasalahan
/// > akumulasi nalika ngitung titik ngambang perkiraan ka f * 10 ^ e.(Slop nyaéta
/// > sanés kabeungkeut pikeun kasalahan anu leres, tapi ngawatesan bédana antara perkiraan z sareng
/// > perkiraan anu pangsaéna anu nganggo p bit tina significanceand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Kasus abs(e) <log5(2^N) aya dina fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Naha lamping cukup ageung pikeun ngabédakeun nalika ngabuleudkeun kana n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Algoritma iteratif anu ningkatkeun perkiraan titik ngambang `f * 10^e`.
///
/// Masing-masing iterasi kéngingkeun hiji unit di tempat terakhir caket, anu tangtosna peryogi lami pisan konvergen upami `z0` bahkan pareum.
/// Kabeneran, nalika dianggo salaku fallback pikeun Bellerophon, perkiraan dimimitian dipareuman ku paling hiji ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Milarian bilangan bulat positip `x`, `y` sapertos `x / y` persis `(f *10^e) / (m* 2^k)`.
        // Ieu henteu ngan ukur ngahindarkeun kaayaan tanda-tanda `e` sareng `k`, urang ogé ngaleungitkeun kakuatan dua umum pikeun `10^e` sareng `2^k` supados angka langkung alit.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Ieu ditulis rada kagok sabab bignum kami henteu ngadukung angka négatip, janten kami nganggo inpormasi nilai inohong + tanda mutlak.
        // Gandakan ku m_digits moal tiasa kabanjiran.
        // Upami `x` atanapi `y` cukup ageung anu urang kedah hariwang ngeunaan overflow, maka éta ogé cukup ageung yén `make_ratio` parantos ngirangan fraksi ku faktor 2 ^ 64 atanapi langkung.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Teu kedah x deui, simpen clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Masih peryogi y, ngadamel salinan.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dibikeun `x = f` sareng `y = m` dimana `f` ngagambarkeun digit desimal input sapertos biasana sareng `m` mangrupikeun pinunjul tina titik ngambang, damel rasio `x / y` sami sareng `(f *10^e) / (m* 2^k)`, panginten dikirangan ku kakuatan dua duanana sami-sami.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, kecuali urang ngirangan fraksi ku sababaraha kakuatan dua.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Ieu henteu tiasa kabanjiran sabab meryogikeun `e` positip sareng `k` négatip, anu ngan ukur tiasa kajantenan pikeun nilai anu caket pisan kana 1, anu hartosna `e` sareng `k` bakal relatif leutik.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ieu moal tiasa teuing ngabahekeun, tingali di luhur.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), deui dikurangan ku kakuatan umum dua.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Sacara konsép, Algoritma M mangrupikeun cara paling saderhana pikeun ngarobih desimal janten ngambang.
///
/// Kami ngabentuk rasio anu sami sareng `f * 10^e`, teras ngalungkeun kakuatan dua dugi ka masihan float tegesand anu valid.
/// Éksponén binér `k` mangrupikeun sababaraha kali urang ngalikeun numerator atanapi pangbagi ku dua, nyaéta, sepanjang waktos `f *10^e` sami sareng `(u / v)* 2^k`.
/// Nalika kami parantos terang anu penting, urang ngan ukur kedah buleud ku mariksa sésa pembagian, anu dilakukeun dina fungsi pembantunya di handap ieu.
///
///
/// Algoritma ieu super lambat, bahkan kalayan optimalisasi anu dijelaskeun dina `quick_start()`.
/// Nanging, éta anu paling saderhana tina algoritma pikeun adaptasi pikeun overflow, underflow, sareng hasil anu teu normal.
/// Palaksanaan ieu ngambil alih nalika Bellerophon sareng Algorithm Sunda kalindih.
/// Ngadeteksi underflow sareng overflow gampang: Rasio masih sanés mangrupikeun rentang-rentang, tapi éksponén minimum/maximum parantos kahontal.
/// Dina kasus kabanjiran, urang ngan saukur balik ka takterhingga.
///
/// Nanganan underflow sareng subnormal langkung rumit.
/// Hiji masalah ageung nya éta, ku ékspon minimum, babandinganana masih ageung teuing pikeun a.
/// Tingali underflow() pikeun detil.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME kamungkinan optimalisasi: generalisasi big_to_fp sahingga urang tiasa ngalakukeun anu sami sareng fp_to_float(big_to_fp(u)) di dieu, ngan ukur teu aya dua kali.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Urang kedah lirén dina éksponén minimum, upami urang ngantosan dugi ka `k < T::MIN_EXP_INT`, maka urang bakal pareum ku faktor dua.
            // Hanjakalna ieu hartosna urang kedah khusus-bisi angka normal kalayan éksponén minimum.
            // FIXME mendakan formulasi langkung elegan, tapi ngajalankeun tes `tiny-pow10` pikeun mastikeun yén éta leres leres!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Ngalangkungan seuseueuran Algoritma M ku mariksa panjangna sakedik.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Panjang bit mangrupikeun perkiraan tina dasar dua logaritma, sareng log(u / v) = log(u), log(v).
    // Perkiraan dipareuman ku paling seueur 1, tapi teras-terangan diperkirakeun, janten kasalahan dina log(u) sareng log(v) mangrupikeun tanda anu sami sareng ngabatalkeun (upami duanana ageung).
    // Maka kasalahan pikeun log(u / v) paling ogé hiji ogé.
    // Babandingan target mangrupikeun u/v aya dina rentang-rentang.Maka kaayaan terminasi urang nyaéta log2(u / v) janten bit anu penting, plus/minus hiji.
    // FIXME Ningali bit anu kadua tiasa ningkatkeun perkiraan sareng nyingkahan sababaraha babagian deui.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow atanapi subnormal.Pasangkeun kana fungsi utama.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ngabahekeun.Pasangkeun kana fungsi utama.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Rasio sanés mangrupikeun rentang anu saé sareng éksponén minimum, janten urang kedah ngatasi kaleuleuwihan bit sareng nyaluyukeun éksponén anu saluyu.
    // Nilai aslina ayeuna siga kieu:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(diwakilan ku rem)
    //
    // Ku alatan éta, nalika bit anu dibuleudkeun nyaéta!= 0.5 ULP, aranjeunna mutuskeun putaran nyalira.
    // Nalika aranjeunna sami sareng sésana henteu nol, nilaina masih kedah dibuleudkeun.
    // Ngan lamun bit anu dibuleudkeun nyaéta 1/2 sareng sésana nyaéta nol, urang ngagaduhan kaayaan satengah-ka-bahkan.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Biasa buleud-ka-rata, obfuscated ku kedah buleud dumasar kana sésa-sésa divisi.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}