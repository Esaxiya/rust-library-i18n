//! Palaksanaan nomer (bignum) wenang-presisi khusus.
//!
//! Ieu dirancang pikeun nyingkahan alokasi tumpukan ku mémori tumpukan.
//! Jenis bignum anu paling sering dianggo, `Big32x40`, dibatesan ku 32 × 40=1.280 bit sareng bakal nyandak paling seueur 160 bait memori tumpukan.
//! Ieu langkung ti cukup pikeun babak-tripping sadaya kamungkinan nilai `f64` terhingga.
//!
//! Sacara prinsip kasebut nyaéta dimungkinkeun pikeun gaduh sababaraha jinis bignum pikeun input anu béda, tapi kami henteu ngalakukeun éta pikeun nyegah kode kembung.
//!
//! Unggal bignum masih dilacak pikeun panggunaan anu saéstuna, janten biasana henteu janten masalah.
//!

// Modul ieu ngan ukur pikeun dec2flt sareng flt2dec, sareng ngan ukur umum kusabab coretests.
// Éta henteu dimaksad kanggo stabil.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Operasi aritmatika diperyogikeun ku bignums.
pub trait FullOps: Sized {
    /// Mulih `(carry', v')` sapertos `carry' * 2^W + v' = self + other + carry`, dimana `W` mangrupikeun jumlah bit dina `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Mulih `(carry', v')` sapertos `carry'*2^W + v' = self* other + carry`, dimana `W` mangrupikeun jumlah bit dina `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Mulih `(carry', v')` sapertos `carry'*2^W + v' = self* other + other2 + carry`, dimana `W` mangrupikeun jumlah bit dina `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Mulih `(quo, rem)` sapertos `borrow *2^W + self = quo* other + rem` sareng `0 <= rem < other`, dimana `W` mangrupikeun jumlah bit dina `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Ieu moal tiasa kabanjiran;kaluaranna antara `0` sareng `2 * 2^nbits - 1`.
                    // FIXME: bakal LLVM ngaoptimalkeun ieu kana ADC atanapi anu sami?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ieu moal tiasa kabanjiran;
                    // kaluaranna antara `0` sareng `2^nbits * (2^nbits - 1)`.
                    // FIXME: bakal LLVM ngaoptimalkeun ieu kana ADC atanapi anu sami?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ieu moal tiasa kabanjiran;
                    // kaluaranna antara `0` sareng `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Ieu moal tiasa kabanjiran;kaluaranna antara `0` sareng `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Tingali RFC #521 pikeun ngaktipkeun ieu.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Daptar kakuatan 5 tiasa digambarkeun dina angka.Khususna, nilai {u8, u16, u32} panggedéna éta kakuatan tina lima, ditambah éksponén anu cocog.
/// Dipaké dina `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Alokasi tumpukan-alokasi-presisi (dugi ka wates anu tangtu) bilangan bulat.
        ///
        /// Ieu dirojong ku Asép Sunandar Sunarya-ukuran dibereskeun tina jenis ("digit").
        /// Sedengkeun susunanana henteu ageung (biasana saratus bait), nyalin éta kalayan gagabah tiasa nyababkeun hit kinerja.
        ///
        /// Janten ieu ngahaja sanés `Copy`.
        ///
        /// Sadaya operasi sayogi pikeun bignums panic dina kasus overflows.
        /// Nu nélépon tanggung jawab ngagunakeun jinis bignum anu cekap ageung.
        pub struct $name {
            /// Hiji ditambah offset kana "digit" maksimum anu dianggo.
            /// Ieu henteu ngirangan, janten waspada kana urutan komputasi.
            /// `base[size..]` kuduna nol.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` ngagambarkeun `a + b *2^W + c* 2^(2W) + ...` dimana `W` mangrupikeun jumlah bit dina jinis digit.
            base: [$ty; $n],
        }

        impl $name {
            /// Ngadamel bignum tina hiji digit.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Ngajantenkeun bignum tina nilai `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Balikkeun digit internal salaku slice `[a, b, c, ...]` sapertos nilai numerik nyaéta `a + b *2^W + c* 2^(2W) + ...` dimana `W` mangrupikeun jumlah bit dina jinis digit.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Mulang deui `i`-th dimana bit 0 mangrupikeun anu paling henteu penting.
            /// Kalayan kecap séjén, bit sareng beurat `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Mulih `true` upami bignum enol.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Mulih jumlah bit anu diperyogikeun pikeun ngagambarkeun nilai ieu.
            /// Catet yén nol dianggap peryogi 0 bit.
            pub fn bit_length(&self) -> usize {
                // Langkung tina digit anu paling penting nyaéta nol.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Teu aya angka anu henteu nol, nyaéta jumlahna aya nol.
                    return 0;
                }
                // Ieu tiasa dioptimalkeun ku leading_zeros() sareng bit shift, tapi éta panginten henteu raoseun.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Nambihan `other` nyalira sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Subtracts `other` ti dirina sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Gandakan dirina ku `other` saukuran digit sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Gandakan dirina ku `2^bits` sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // shift ku `digits * digitbits` bit
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // shift ku `bits` bit
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digit] nol, teu kedah dialihkeun
                }

                self.size = sz;
                self
            }

            /// Gandakan dirina ku `5^e` sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Aya n nol labél persis dina 2 ^ n, sareng hiji-hijina ukuran digit anu aya hubunganana sareng dua kakuatan, janten ieu cocog sareng indéks pikeun tabel.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Kalikeun ku kakuatan digit tunggal panggedéna salami mungkin ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... teras bérés sésana.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Gandakan dirina ku nomer anu dijelaskeun ku `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (dimana `W` mangrupikeun jumlah bit dina jinis digit) sareng mulihkeun rujukan anu tiasa dirobih nyalira.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // rutin internal.jalan paling hadé nalika aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Ngabagi dirina ku `other` saukuran digit sareng mulihkeun référénsi anu tiasa dirobih sorangan *sareng* sésana.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Bagikeun diri ku bignum anu sanés, nimpa `q` kalayan kuotansi sareng `r` sareng sésana.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Bodoh lalaunan base-2 divisi panjang dicandak tina
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME nganggo ($ty) basa anu langkung ageung pikeun babagian panjang.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Atur bit `i` tina q ka 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Jenis digit pikeun `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// anu ieu dianggo pikeun uji hungkul.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}