use crate::iter::FromIterator;

/// Ngabubarkeun sadaya unit barang tina hiji iterator kana hiji.
///
/// Ieu leuwih mangpaat lamun digabungkeun jeung abstractions-tingkat luhur, kawas ngumpulkeun ka `Result<(), E>` mana anjeun ngan ngeunaan miara kasalahan:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}