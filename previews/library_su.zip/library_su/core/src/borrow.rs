//! Modul pikeun ngagarap data anu diinjeum.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait pikeun data nginjeum.
///
/// Dina Rust, umum pikeun nyayogikeun répréséntasi anu béda pikeun hiji jinis pikeun kasus panggunaan anu béda.
/// Contona, lokasi gudang sarta manajemén pikeun nilai a bisa husus dipilih salaku luyu pikeun pamakéan tinangtu via jenis pointer kayaning [`Box<T>`] atanapi [`Rc<T>`].
/// Saluareun pambungkus umum ieu anu tiasa dianggo nganggo jinis naon waé, sababaraha jinis nyayogikeun opsional opsional anu nyayogikeun fungsionalitas anu berpotensi mahal.
/// Conto pikeun jenis sapertos kitu nyaéta [`String`] anu nambihan kamampuan pikeun manjangkeun senar kana [`str`] dasar.
/// Ieu kedah ngajaga inpormasi tambihan teu perlu pikeun senar anu gampang, teu tiasa dirobih.
///
/// Jenis ieu nyayogikeun aksés kana data anu ngalangkungan ngalangkungan rujukan kana jinis data éta.Éta téh bisa disebutkeun 'injeuman saperti' tipe éta.
/// Salaku conto, [`Box<T>`] tiasa diinjeum salaku `T` sedengkeun [`String`] tiasa diinjeum salaku `str`.
///
/// Jenis nyatakeun yén aranjeunna tiasa diinjeum salaku sababaraha jinis `T` ku ngalaksanakeun `Borrow<T>`, nyayogikeun rujukan kana `T` dina metoda [`borrow`] trait's.Jinis bebas nginjeum sababaraha jinis anu béda.
/// Lamun wishes mun mutably nginjeum sakumaha jenis-sahingga data kaayaan bisa dirobah, eta Sajaba bisa nerapkeun [`BorrowMut<T>`].
///
/// Salajengna, nalika nyayogikeun palaksanaan pikeun traits tambahan, perlu diperhatoskeun naha aranjeunna kedah kalakuanana idéntik sareng jinis anu aya dina dasarna salaku akibat tina kalakuan salaku representasi tina jinis anu aya dina dasarna.
/// Kodeu umum biasana nganggo `Borrow<T>` nalika éta ngandelkeun paripolah anu sami tina panerapan trait tambahan ieu.
/// traits ieu sigana bakal muncul salaku trait bounds tambahan.
///
/// Dina `Eq` husus, `Ord` na `Hash` kudu jadi sarua keur nilai injeuman sarta dipiboga: `x.borrow() == y.borrow()` kedah masihan hasil sarua salaku `x == y`.
///
/// Upami kode umum kedah dianggo pikeun sadaya jenis anu tiasa masihan rujukan kana jinis `T` anu aya hubunganana, sering langkung saé nganggo [`AsRef<T>`] sabab langkung seueur jinis tiasa aman ngalaksanakeunana.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Salaku kumpulan data, [`HashMap<K, V>`] ngagaduhan konci sareng nilai.Lamun data tombol urang sabenerna geus dibungkus dina tipe menata tina sababaraha jenis, sakuduna, kumaha oge, tetep tiasa néang nilai maké rujukan pikeun data tombol urang.
/// Misalna, upami konci na senar, maka sigana bakal disimpen sareng peta Hash salaku [`String`], sedengkeun kedah tiasa milarian nganggo [`&str`][`str`].
/// Ku kituna, `insert` kedah beroperasi dina `String` sedengkeun `get` kedah tiasa ngagunakeun `&str`.
///
/// Rada disederhanakeun, bagian-bagian anu aya hubunganana sareng `HashMap<K, V>` sapertos kieu:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // sawah dikaluarkeun
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Sakabéh peta Hash nyaéta umum tibatan jenis konci `K`.Kusabab konci ieu disimpen nganggo peta Hash, jenis ieu kedah ngagaduhan data konci na.
/// Nalika ngalebetkeun pasangan konci-nilai, peta dibéré `K` sapertos kitu sareng kedah milarian ember hash anu leres sareng parios naha konci na parantos aya dumasar kana `K` éta.kituna merlukeun `K: Hash + Eq`.
///
/// Nalika milari nilai dina peta, nanging, kedah nyayogikeun rujukan kana `K` salaku konci pikeun milarian peryogi teras-terasan nyiptakeun nilai anu dipimilik.
/// Pikeun konci senar, ieu hartosna nilai `String` kedah didamel namung pikeun milarian kasus anu ngan ukur `str` sayogi.
///
/// Sabalikna, metoda `get` generik tibatan jinis data konci anu janten dasarna, disebat `Q` dina tandatangan metode di luhur.Éta nyatakeun yén `K` nginjeum salaku `Q` ku meryogikeun `K: Borrow<Q>` éta.
/// Ku tambahan meryogikeun `Q: Hash + Eq`, éta nandakeun sarat yén `K` sareng `Q` ngagaduhan implementasi `Hash` sareng `Eq` traits anu ngahasilkeun hasil anu sami.
///
/// Palaksanaan `get` ngandelkeun khusus kana implementasi idéntik `Hash` ku nangtoskeun ember Hash's key ku nelepon `Hash::hash` dina nilai `Q` sanaos éta nyelapkeun konci dumasar kana nilai Hash anu diitung tina nilai `K`.
///
///
/// Salaku akibatna, peta Hash tiasa rusak upami `K` ngabungkus nilai `Q` ngahasilkeun Hash anu sanés tibatan `Q`.Misalna, bayangkeun anjeun gaduh tipeu anu ngabungkus senar tapi ngabandingkeun hurup ASCII henteu ngawaskeun kasus na:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kusabab dua nilai anu sami kedah ngahasilkeun nilai hash anu sami, palaksanaan `Hash` kedah henteu malire bisi ASCII, ogé:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Naha `CaseInsensitiveString` tiasa nerapkeun `Borrow<str>`?Éta pastina tiasa nyayogikeun rujukan kana irisan senar ngalangkungan senar anu dikandungna.
/// Tapi kusabab palaksanaan `Hash` na béda, éta kalakuanana bénten sareng `str` sahingga henteu kedah, nyatana, nerapkeun `Borrow<str>`.
/// Upami éta hoyong ngijinkeun batur aksés kana `str` anu janten dasarna, éta tiasa ngalaksanakeun éta ngalangkungan `AsRef<str>` anu henteu ngagaduhan sarat tambahan.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutably injeuman tina nilai milik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait pikeun data anu tiasa diinput.
///
/// Salaku pendamping [`Borrow<T>`] ieu trait ngamungkinkeun jinis nginjeum salaku tipe anu mendasari ku nyayogikeun rujukan anu tiasa dirobih.
/// Tingali [`Borrow<T>`] pikeun langkung seueur inpormasi ngeunaan nginjeum salaku jinis sanés.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Bisa diminjam tina nilai anu dipimilik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}