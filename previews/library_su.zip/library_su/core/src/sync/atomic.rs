//! jenis atom
//!
//! jenis atom nyadiakeun komunikasi dibagikeun-memori primitif antara threads, sarta mangrupakeun blok wangunan jenis babarengan lianna.
//!
//! Modul ieu ngahartikeun versi atom tina sababaraha jinis jinis primitif, kalebet [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], jst.
//! Jinis atom nampilkeun operasi anu, nalika dianggo leres, nyingkronkeun pembaruan antara benang.
//!
//! Unggal metoda nyandak [`Ordering`] anu ngagambarkeun kakuatan panghalang memori pikeun operasi éta.cara susunan ieu sarua jeung [C++20 atomic orderings][1].Kanggo inpo nu leuwih lengkep ningali [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Variabel atom aman dibagi antara utas (aranjeunna nerapkeun [`Sync`]) tapi aranjeunna henteu nyayogikeun mékanisme kanggo ngabagi sareng nuturkeun [threading model](../../../std/thread/index.html#the-threading-model) of Rust.
//!
//! Cara anu paling umum pikeun ngabagi variabel atom nyaéta nempatkeun kana [`Arc`][arc] (pointer bersama anu kaitung atom-rujukan-diitung).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! jenis atom bisa diteundeun dina variabel statis, initialized ngagunakeun initializers konstan kawas [`AtomicBool::new`].Statis atom sering dianggo pikeun awal global anu teu puguh.
//!
//! # Portability
//!
//! Sadaya jinis atom dina modul ieu dijamin [lock-free] upami aranjeunna sayogi.Ieu hartina memang maranehna teu internal acquire mutex global.jenis JEUNG KOPERASI atom teu dijamin janten nungguan-gratis.
//! Ieu hartosna yén operasi kawas `fetch_or` bisa dilaksanakeun ku loop ngabandingkeun-na-swap.
//!
//! Operasi atom bisa dilaksanakeun dina instruksi lapisan kalawan atomics gedé-ukuran.Misalna sababaraha platform nganggo petunjuk atom 4-bait pikeun nerapkeun `AtomicI8`.
//! Catet yén emulasi ieu kedahna teu aya pangaruh kana leresna kode, éta ngan ukur hal anu kedah diperhatoskeun.
//!
//! Jenis atom dina modul ieu bisa jadi teu sadia di sakabéh platform.Jenis atom dieu téh sadayana lega sadia, kumaha oge, jeung umumna bisa relied kana aya.Sababaraha éntitas kasohor nyaéta:
//!
//! * PowerPC sarta MIPS platform kalawan 32-bit pointers teu boga `AtomicU64` atanapi `AtomicI64` jenis.
//! * ARM platform sapertos `armv5te` anu sanés kanggo Linux ngan ukur nyayogikeun operasi `load` sareng `store`, sareng henteu ngadukung operasi Bandingkeun sareng Swap (CAS), sapertos `swap`, `fetch_add`, jst.
//! Sajaba dina Linux, operasi CAS ieu dilaksanakeun liwat [operating system support], nu bisa datangna ku pinalti kinerja.
//! * ARM target kalawan `thumbv6m` ukur nyadiakeun operasi `load` na `store`, sarta teu ngarojong Bandingkeun jeung swap operasi (CAS), kayaning `swap`, `fetch_add`, jsb
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Catetan yen future platform bisa ditambahkeun anu ogé teu boga rojongan pikeun sababaraha operasi atom.Kodeu portabel maksimal hoyong ati-ati ngeunaan jinis atom anu mana anu dianggo.
//! `AtomicUsize` sareng `AtomicIsize` umumna paling portabel, tapi sanaos éta henteu sayogi dimana-mana.
//! Pikeun rujukan, perpustakaan `std` merlukeun atomics pointer-ukuran, najan `core` henteu.
//!
//! Ayeuna maneh bakal butuh ngagunakeun `#[cfg(target_arch)]` utamana pikeun conditionally compile di kode jeung atomics.Aya `#[cfg(target_has_atomic)]` henteu stabil ogé anu tiasa distabilkeun dina future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A spinlock basajan:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Ngadagoan thread sejen rék dipegatkeun konci
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Tetep count global thread live:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Jinis boolean anu tiasa aman dibagi antara utas.
///
/// Jenis ieu ngagaduhan gambaran anu sami dina mémori salaku [`bool`].
///
/// **Catetan**: tipe Ieu ngan sadia dina platform anu ngarojong beban atom sarta toko of `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Nyiptakeun mangrupa `AtomicBool` initialized mun `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Kirim sacara implisit dilaksanakeun pikeun AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Jinis pointer atah anu tiasa aman di bagi antara benang.
///
/// Jenis ieu ngagaduhan gambaran anu sami dina mémori salaku `*mut T`.
///
/// **Catetan**: tipe Ieu ngan sadia dina platform anu ngarojong beban atom sarta toko of pointers.
/// Ukuran na gumantung kana ukuranana udagan pointer urang.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Nyiptakeun `AtomicPtr<T>` nol.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Pesenan mémori atom
///
/// cara susunan memori nangtukeun jalan operasi atom nyingkronkeun memori.
/// Dina [`Ordering::Relaxed`] panglemahna, ngan mémori langsung keuna ku operasi anu disingkronkeun.
/// Di sisi anu sanésna, sapasang toko-beban operasi [`Ordering::SeqCst`] nyingkronkeun mémori sanésna bari ogé ngajaga sababaraha urutan operasi sapertos di sadaya utas.
///
///
/// Urutan mémori Rust nyaéta [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Kanggo inpormasi lengkep tingali [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Henteu aya kendat mesen, ngan ukur operasi atom.
    ///
    /// Pakait jeung [`memory_order_relaxed`] di C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Nalika gandeng sareng toko, sadaya operasi sateuacana dipesen sateuacan beban tina nilai ieu ku urutan [`Acquire`] (atanapi langkung kuat).
    ///
    /// Khususna, sadaya nyerat anu sateuacanna janten katingali ku sadaya utas anu ngalakukeun beban [`Acquire`] (atanapi langkung kuat) tina nilai ieu.
    ///
    /// Bewara nu maké nyusun ieu mangrupa operasi anu ngagabungkeun beban sarta toko ngawujud kana operasi beban [`Relaxed`]!
    ///
    /// Pesenan ieu ngan ukur berlaku pikeun operasi anu tiasa ngalakukeun toko.
    ///
    /// Pakait jeung [`memory_order_release`] di C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Nalika gandeng ku beban, lamun nilai dimuat ieu ditulis ku operasi toko jeung [`Release`] (atawa kuat) nyusun, teras sadayana operasi saterusna jadi maréntahkeun sanggeus toko éta.
    /// Dina sababaraha hal, sagala beban saterusna bakal ningali data nu ditulis saméméh toko.
    ///
    /// Perhatikeun yén ngagunakeun pesenan ieu kanggo operasi anu ngagabungkeun seueur sareng toko nyababkeun operasi toko [`Relaxed`]!
    ///
    /// Pesenan ieu ngan ukur berlaku pikeun operasi anu tiasa ngajalankeun beban.
    ///
    /// Cocog sareng [`memory_order_acquire`] dina C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Boga pangaruh duanana [`Acquire`] sareng [`Release`] babarengan:
    /// Pikeun beban ngagunakeun [`Acquire`] mesen.Pikeun toko éta nganggo urutan [`Release`].
    ///
    /// Perhatikeun yén dina kasus `compare_and_swap`, mungkin operasi tungtungna henteu ngalakukeun toko naon waé ku sabab éta ngan ukur [`Acquire`] mesen.
    ///
    /// Nanging, `AcqRel` moal ngalakukeun aksés [`Relaxed`].
    ///
    /// Pesenan ieu ngan ukur diterapkeun pikeun operasi anu ngagabungkeun boh beban boh toko.
    ///
    /// Pakait jeung [`memory_order_acq_rel`] di C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Kawas [`Acquire`]/[`Release`]/[`AcqRel`](pikeun beban, toko, sarta beban-kalayan-toko operasi, mungguh) jeung garansi tambahan yen sakabeh threads tingali sagala operasi sequentially konsisten dina urutan anu sarua .
    ///
    ///
    /// Pakait jeung [`memory_order_seq_cst`] di C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Hiji [`AtomicBool`] initialized mun `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Nyiptakeun `AtomicBool` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Mulihkeun rujukan anu tiasa dirobih kana [`bool`] anu janten dasarna.
    ///
    /// Ieu aman sabab rujukan anu dimutkeun ngajamin yén henteu aya utas anu sanés ngakses data atom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // Kasalametan: rujukan mutable jaminan kapamilikan unik.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Meunang aksés atom ka `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAFETY: rujukan anu tiasa dirobih ngajamin kapamilikan unik, sareng
        // alignment duanana `bool` na `Self` nyaeta 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Ngonsumsi atom sareng ngasilkeun nilai anu dikandung.
    ///
    /// Ieu aman sabab ngalirkeun `self` ku nilai ngajamin yén teu aya utas anu sanés ngakses data atom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Beban hiji nilai tina bool.
    ///
    /// `load` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
    /// nilai mungkin aya [`SeqCst`], [`Acquire`] na [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics lamun `order` nyaeta [`Release`] atanapi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // Kaamanan: lomba data naon waé dicegah ku intrinsik atom sareng atah
        // pointer diliwatan lumaku sabab kami nampi éta tina rujukan.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Nyimpen nilai kana bool.
    ///
    /// `store` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
    /// Nilai anu mungkin nyaéta [`SeqCst`], [`Release`] sareng [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics lamun `order` nyaeta [`Acquire`] atanapi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // Kaamanan: lomba data naon waé dicegah ku intrinsik atom sareng atah
        // pointer diliwatan lumaku sabab kami nampi éta tina rujukan.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Nyimpen nilai kana bool, balikkeun nilai sateuacana.
    ///
    /// `swap` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Nyimpen nilai kana [`bool`] upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Nilai balik sok nilai saméméhna.Upami éta sami sareng `current`, maka nilaina diperbarui.
    ///
    /// `compare_and_swap` ogé nyokot hiji argumen [`Ordering`] nu ngajelaskeun nyusun memori operasi ieu.
    /// Perhatoskeun yén bahkan nalika nganggo [`AcqRel`], operasi panginten gagal sareng janten ngan ukur ngalakukeun beban `Acquire`, tapi henteu ngagaduhan semantik `Release`.
    /// Ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`] upami éta kajantenan, sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Migrasi ka `compare_exchange` na `compare_exchange_weak`
    ///
    /// `compare_and_swap` sarua jeung `compare_exchange` jeung pemetaan di handap pikeun cara susunan memori:
    ///
    /// Asli |Suksés |Gagal
    /// -------- | ------- | -------
    /// santai |santai |Bersantai Acquire |acquire |Acquire Release |Ngaleupaskeun |Santai AcqRel |AcqRel |Acquire SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` diidinan gagal sacara spurious sanajan ngabandingkeunna hasil, anu ngamungkinkeun panyusun ngahasilkeun kode perakitan anu langkung saé nalika ngabandingkeun sareng swap dianggo dina gelung.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Nyimpen nilai kana [`bool`] upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
    /// Dina kasuksésan nilai ieu dijamin sami sareng `current`.
    ///
    /// `compare_exchange` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
    /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
    /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
    ///
    /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Nyimpen nilai kana [`bool`] upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Beda sareng [`AtomicBool::compare_exchange`], fungsi ieu diidinan gagal sacara spurious sanaos ngabandingkeunna hasil, anu tiasa ngahasilkeun kode anu langkung éfisién dina sababaraha platform.
    ///
    /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
    ///
    /// `compare_exchange_weak` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
    /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
    /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
    /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logis "and" kalayan nilai boolean.
    ///
    /// Ngalakukeun operasi "and" logis kana nilai ayeuna sareng argumen `val`, sareng netepkeun nilai énggal kana hasilna.
    ///
    /// Balikkeun nilai sateuacanna.
    ///
    /// `fetch_and` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logis "nand" kalayan nilai boolean.
    ///
    /// Ngalakukeun operasi "nand" logis kana nilai ayeuna sareng argumen `val`, sareng netepkeun nilai énggal kana hasilna.
    ///
    /// Balikkeun nilai sateuacanna.
    ///
    /// `fetch_nand` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Simkuring teu tiasa nganggo atomic_nand dieu sabab bisa hasil dina bool kalawan nilai sah.
        // Ieu kajadian kusabab operasi atom dilakukeun ku bilangan bulat 8-bit internal, anu bakal netepkeun 7 bit luhur.
        //
        // Janten urang ngan ukur nganggo fetch_xor atanapi swap waé.
        if val {
            // ! (x&leres)== !x Urang kedah ngabalikkeun bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==leres Urang kedah nyetél bool janten leres.
            //
            self.swap(true, order)
        }
    }

    /// "or" logis sareng nilai boolean.
    ///
    /// Ngalakukeun operasi "or" logis kana nilai ayeuna sareng argumen `val`, sareng netepkeun nilai énggal kana hasilna.
    ///
    /// Balikkeun nilai sateuacanna.
    ///
    /// `fetch_or` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" logis sareng nilai boolean.
    ///
    /// Ngalakukeun operasi "xor" logis kana nilai ayeuna sareng argumen `val`, sareng netepkeun nilai énggal kana hasilna.
    ///
    /// Balikkeun nilai sateuacanna.
    ///
    /// `fetch_xor` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Balikkeun petunjuk anu tiasa dirobih kana [`bool`] anu janten dasarna.
    ///
    /// Ngalakukeun bacaan non-atom sareng nyerat dina bilangan bulat anu dihasilkeun tiasa janten lomba data.
    /// Metoda ieu lolobana kapaké pikeun FFI, dimana tanda tangan fungsi bisa make `*mut bool` tinimbang `&AtomicBool`.
    ///
    /// Balikkeun pointer `*mut` tina rujukan anu dibagi kana atom ieu aman sabab jinis atom tiasa dianggo kalayan mutasi interior.
    /// Sadaya modifikasi tina atom ngarobih nilaina ngalangkungan rujukan anu dibagi, sareng tiasa ngalaksanakeunana salami éta nganggo operasi atom.
    /// Sagala panggunaan pointer atah anu dikembalikan peryogi blok `unsafe` sareng masih kedah ngajaga watesan anu sami: operasi pikeun éta pasti atom.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches nilai, sarta lumaku fungsi pikeun eta anu mulih hiji nilai anyar pilihan.Mulih a `Result` of `Ok(previous_value)` lamun fungsi nu balik `Some(_)`, lain `Err(previous_value)`.
    ///
    /// Note: Ieu tiasa nyauran fungsi sababaraha kali upami nilaina parantos dirobih tina utas anu sanésna, salami fungsina mulih `Some(_)`, tapi fungsina ngan ukur diterapkeun sakali kana nilai anu disimpen.
    ///
    ///
    /// `fetch_update` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// Anu kahiji ngajelaskeun susunan anu diperyogikeun nalika operasi tungtungna hasil sedengkeun anu kadua ngajelaskeun urutan anu diperyogikeun pikeun beban.
    /// Ieu pakait sareng kasuksésan sareng kagagalan susunan [`AtomicBool::compare_exchange`] masing-masing.
    ///
    /// Ngagunakeun [`Acquire`] salaku susunan kasuksésan ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] beban suksés akhir.
    /// Pesenan beban (failed) ngan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng langkung lemah tibatan susunan anu suksés.
    ///
    /// **Note:** Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Nyiptakeun `AtomicPtr` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Mulih hiji rujukan mutable ka pointer kaayaan.
    ///
    /// Ieu aman sabab rujukan anu dimutkeun ngajamin yén henteu aya utas anu sanés ngakses data atom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Kéngingkeun aksés atom kana tutunjuk.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - rujukan anu tiasa dirobih ngajamin kapamilikan unik.
        //  - alignment of `*mut T` sareng `Self` sami dina sadaya platform anu dirojong ku rust, sakumaha anu diverifikasi di luhur.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Ngonsumsi atom sareng ngasilkeun nilai anu dikandung.
    ///
    /// Ieu aman sabab ngalirkeun `self` ku nilai ngajamin yén teu aya utas anu sanés ngakses data atom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Beban nilai tina panunjuk.
    ///
    /// `load` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
    /// nilai mungkin aya [`SeqCst`], [`Acquire`] na [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics lamun `order` nyaeta [`Release`] atanapi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Nyimpen nilai kana panunjuk.
    ///
    /// `store` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
    /// Nilai anu mungkin nyaéta [`SeqCst`], [`Release`] sareng [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics lamun `order` nyaeta [`Acquire`] atanapi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Nyimpen nilai kana panunjuk, balikkeun nilai anu saacanna.
    ///
    /// `swap` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
    /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    ///
    /// **Note:** Metoda ieu ngan sadia dina platform anu ngarojong operasi atom dina pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Simpen nilai kana pointer upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Nilai balik sok nilai saméméhna.Upami éta sami sareng `current`, maka nilaina diperbarui.
    ///
    /// `compare_and_swap` ogé nyokot hiji argumen [`Ordering`] nu ngajelaskeun nyusun memori operasi ieu.
    /// Perhatoskeun yén bahkan nalika nganggo [`AcqRel`], operasi panginten gagal sareng janten ngan ukur ngalakukeun beban `Acquire`, tapi henteu ngagaduhan semantik `Release`.
    /// Ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`] upami éta kajantenan, sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
    ///
    /// **Note:** Metoda ieu ngan sadia dina platform anu ngarojong operasi atom dina pointers.
    ///
    /// # Migrasi ka `compare_exchange` na `compare_exchange_weak`
    ///
    /// `compare_and_swap` sarua jeung `compare_exchange` jeung pemetaan di handap pikeun cara susunan memori:
    ///
    /// Asli |Suksés |Gagal
    /// -------- | ------- | -------
    /// santai |santai |Bersantai Acquire |acquire |Acquire Release |Ngaleupaskeun |Santai AcqRel |AcqRel |Acquire SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` diidinan gagal sacara spurious sanajan ngabandingkeunna hasil, anu ngamungkinkeun panyusun ngahasilkeun kode perakitan anu langkung saé nalika ngabandingkeun sareng swap dianggo dina gelung.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Simpen nilai kana pointer upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
    /// Dina kasuksésan nilai ieu dijamin sami sareng `current`.
    ///
    /// `compare_exchange` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
    /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
    /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
    ///
    /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
    ///
    /// **Note:** Metoda ieu ngan sadia dina platform anu ngarojong operasi atom dina pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // Kasalametan: ras data anu dicegah ku intrinsics atom.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Simpen nilai kana pointer upami nilai ayeuna sami sareng nilai `current`.
    ///
    /// Beda sareng [`AtomicPtr::compare_exchange`], fungsi ieu diidinan gagal sacara spurious sanaos ngabandingkeunna hasil, anu tiasa ngahasilkeun kode anu langkung éfisién dina sababaraha platform.
    ///
    /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
    ///
    /// `compare_exchange_weak` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
    /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
    /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
    /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
    ///
    /// **Note:** Metoda ieu ngan sadia dina platform anu ngarojong operasi atom dina pointers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // Kaamanan: intrinsik ieu teu aman sabab éta beroperasi dina pointer atah
        // tapi urang nyaho pasti yén pointer nyaeta valid (urang ngan ngagaduhan tina hiji `UnsafeCell` yén urang kudu ku rujukan) jeung operasi atom sorangan ngamungkinkeun urang pikeun aman mutate eusi `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches nilai, sarta lumaku fungsi pikeun eta anu mulih hiji nilai anyar pilihan.Mulih a `Result` of `Ok(previous_value)` lamun fungsi nu balik `Some(_)`, lain `Err(previous_value)`.
    ///
    /// Note: Ieu tiasa nyauran fungsi sababaraha kali upami nilaina parantos dirobih tina utas anu sanésna, salami fungsina mulih `Some(_)`, tapi fungsina ngan ukur diterapkeun sakali kana nilai anu disimpen.
    ///
    ///
    /// `fetch_update` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
    /// Anu kahiji ngajelaskeun susunan anu diperyogikeun nalika operasi tungtungna hasil sedengkeun anu kadua ngajelaskeun urutan anu diperyogikeun pikeun beban.
    /// Ieu pakait sareng kasuksésan sareng kagagalan susunan [`AtomicPtr::compare_exchange`] masing-masing.
    ///
    /// Ngagunakeun [`Acquire`] salaku susunan kasuksésan ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] beban suksés akhir.
    /// Pesenan beban (failed) ngan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng langkung lemah tibatan susunan anu suksés.
    ///
    /// **Note:** Metoda ieu ngan sadia dina platform anu ngarojong operasi atom dina pointers.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Ngarobih `bool` kana `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Makro ieu tungtungna dipaké dina sababaraha arsitéktur.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Hiji tipe integer nu bisa aman dibagikeun antara threads.
        ///
        /// Jenis ieu ngagaduhan gambaran anu sami dina-memori sareng jinis bilangan bulat anu aya, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Pikeun leuwih lengkep ngeunaan béda antara jenis atom sarta jenis non-atom ogé informasi ngeunaan portability tina tipe ieu, mangga tingali di [module-level documentation].
        ///
        ///
        /// **Note:** Jenis ieu ngan ukur aya dina platform anu ngadukung beban atom sareng toko [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Hiji integer atom initialized mun `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Kirim sacara implisit dilaksanakeun.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Nyiptakeun bilangan bulat atom anyar.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Mulih hiji rujukan mutable ka integer kaayaan.
            ///
            /// Ieu aman sabab rujukan anu dimutkeun ngajamin yén henteu aya utas anu sanés ngakses data atom.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// hayu mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// negeskeun_eq! (sababaraha_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - rujukan anu tiasa dirobih ngajamin kapamilikan unik.
                //  - alignment of `$int_type` sareng `Self` sami, sakumaha anu dijanjikeun ku $cfg_align sareng diverifikasi di luhur.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Ngonsumsi atom sareng ngasilkeun nilai anu dikandung.
            ///
            /// Ieu aman sabab ngalirkeun `self` ku nilai ngajamin yén teu aya utas anu sanés ngakses data atom.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Beban nilai tina bilangan bulat atom.
            ///
            /// `load` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
            /// nilai mungkin aya [`SeqCst`], [`Acquire`] na [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics lamun `order` nyaeta [`Release`] atanapi [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Nyimpen nilai kana integer atom.
            ///
            /// `store` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.
            ///  Nilai anu mungkin nyaéta [`SeqCst`], [`Release`] sareng [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics lamun `order` nyaeta [`Acquire`] atanapi [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Nyimpen hiji nilai kana bilangan bulat atom, ngabalikeun nilai anu saacanna.
            ///
            /// `swap` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Nyimpen nilai kana bilangan bulat atom upami nilai ayeuna sami sareng nilai `current`.
            ///
            /// Nilai balik sok nilai saméméhna.Upami éta sami sareng `current`, maka nilaina diperbarui.
            ///
            /// `compare_and_swap` ogé nyokot hiji argumen [`Ordering`] nu ngajelaskeun nyusun memori operasi ieu.
            /// Perhatoskeun yén bahkan nalika nganggo [`AcqRel`], operasi panginten gagal sareng janten ngan ukur ngalakukeun beban `Acquire`, tapi henteu ngagaduhan semantik `Release`.
            ///
            /// Ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`] upami éta kajantenan, sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrasi ka `compare_exchange` na `compare_exchange_weak`
            ///
            /// `compare_and_swap` sarua jeung `compare_exchange` jeung pemetaan di handap pikeun cara susunan memori:
            ///
            /// Asli |Suksés |Gagal
            /// -------- | ------- | -------
            /// santai |santai |Bersantai Acquire |acquire |Acquire Release |Ngaleupaskeun |Santai AcqRel |AcqRel |Acquire SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` diidinan gagal sacara spurious sanajan ngabandingkeunna hasil, anu ngamungkinkeun panyusun ngahasilkeun kode perakitan anu langkung saé nalika ngabandingkeun sareng swap dianggo dina gelung.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Nyimpen nilai kana bilangan bulat atom upami nilai ayeuna sami sareng nilai `current`.
            ///
            /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
            /// Dina kasuksésan nilai ieu dijamin sami sareng `current`.
            ///
            /// `compare_exchange` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
            /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
            /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
            /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
            ///
            /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Nyimpen nilai kana bilangan bulat atom upami nilai ayeuna sami sareng nilai `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// fungsi ieu diwenangkeun spuriously gagal sanajan ngabandingkeun nu succeeds, anu bisa ngahasilkeun kode leuwih efisien dina sababaraha platform.
            /// Nilai balik mangrupikeun hasil nunjukkeun naha nilai énggal ditulis sareng ngandung nilai sateuacana.
            ///
            /// `compare_exchange_weak` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
            /// `success` ngajelaskeun susunan anu diperyogikeun pikeun operasi maca-ngarobih-nyerat anu lumangsung upami perbandingan sareng `current` hasil.
            /// `failure` ngajelaskeun susunan anu diperyogikeun pikeun operasi beban anu lumangsung nalika ngabandingkeunna gagal.
            /// Nganggo [`Acquire`] salaku kasuksésan mesen ngajadikeun toko bagian tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] anu suksés.
            ///
            /// Pesenan kagagalan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng atanapi langkung lemah tibatan mesen kasuksesan.
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// hayu mut lami= val.load(Ordering::Relaxed);
            /// loop {hayu anyar=heubeul * 2;
            ///     cocog val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Nambahkeun kana nilai ayeuna, balikkeun nilai sateuacana.
            ///
            /// Operasi ieu wraps sabudeureun on mudal.
            ///
            /// `fetch_add` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Subtracts tina nilai ayeuna, balikkeun nilai saméméhna.
            ///
            /// Operasi ieu wraps sabudeureun on mudal.
            ///
            /// `fetch_sub` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" kalayan nilai ayeuna.
            ///
            /// Ngalaksanakeun operasi "and" bitwise dina nilai ayeuna sareng argumen `val`, sareng nyetél nilai énggal kana hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_and` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" kalayan nilai ayeuna.
            ///
            /// Ngalakukeun hiji bitwise "nand" operasi dina nilai ayeuna jeung argumen `val`, sarta susunan nilai anyar pikeun hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_nand` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" jeung nilai ayeuna.
            ///
            /// Ngalaksanakeun operasi "or" bitwise dina nilai ayeuna sareng argumen `val`, sareng nyetél nilai énggal kana hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_or` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" kalayan nilai ayeuna.
            ///
            /// Ngalakukeun hiji bitwise "xor" operasi dina nilai ayeuna jeung argumen `val`, sarta susunan nilai anyar pikeun hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_xor` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches nilai, sarta lumaku fungsi pikeun eta anu mulih hiji nilai anyar pilihan.Mulih a `Result` of `Ok(previous_value)` lamun fungsi nu balik `Some(_)`, lain `Err(previous_value)`.
            ///
            /// Note: Ieu tiasa nyauran fungsi sababaraha kali upami nilaina parantos dirobih tina utas anu sanésna, salami fungsina mulih `Some(_)`, tapi fungsina ngan ukur diterapkeun sakali kana nilai anu disimpen.
            ///
            ///
            /// `fetch_update` nyandak dua argumen [`Ordering`] pikeun ngajelaskeun susunan mémori tina operasi ieu.
            /// Anu mimiti ngajelaskeun susunan anu diperyogikeun nalika operasi tungtungna hasil sedengkeun anu kadua ngajelaskeun susunan anu diperyogikeun pikeun beban.pakait ieu kana kasuksésan sarta kagagalan cara susunan tina
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Ngagunakeun [`Acquire`] salaku susunan kasuksésan ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun [`Relaxed`] beban suksés akhir.
            /// Pesenan beban (failed) ngan ukur tiasa [`SeqCst`], [`Acquire`] atanapi [`Relaxed`] sareng kedah sami sareng langkung lemah tibatan susunan anu suksés.
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (nyusun: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(7));
            /// assert_eq (x.fetch_update (nyusun: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimum jeung nilai ayeuna.
            ///
            /// Manggih nu maksimum nilai ayeuna jeung argumen `val`, sarta susunan nilai anyar pikeun hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_max` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ngantep palang=42;
            /// hayu max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// negeskeun! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum jeung nilai ayeuna.
            ///
            /// Milarian minimum nilai ayeuna sareng argumen `val`, sareng netepkeun nilai énggal kana hasilna.
            ///
            /// Balikkeun nilai sateuacanna.
            ///
            /// `fetch_min` nyandak argumen [`Ordering`] anu ngajelaskeun urutan memori operasi ieu.Kabéh modus nyusun nu mungkin.
            /// Catet yén ngagunakeun [`Acquire`] ngajantenkeun bagian toko tina operasi ieu [`Relaxed`], sareng nganggo [`Release`] ngajantenkeun bagian beban [`Relaxed`].
            ///
            ///
            /// **Catetan**: Metoda ieu ngan ukur aya dina platform anu ngadukung operasi atom dina
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ngantep palang=12;
            /// hayu min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// negeskeun_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // Kasalametan: ras data anu dicegah ku intrinsics atom.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Mulih a pointer mutable ka integer kaayaan.
            ///
            /// Ngalakukeun bacaan non-atom sareng nyerat dina bilangan bulat anu dihasilkeun tiasa janten lomba data.
            /// Metoda ieu kalolobaan kapaké pikeun FFI, dimana tanda tangan fungsi tiasa dianggo
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Balikkeun pointer `*mut` tina rujukan anu dibagi kana atom ieu aman sabab jinis atom tiasa dianggo kalayan mutasi interior.
            /// Sadaya modifikasi tina atom ngarobih nilaina ngalangkungan rujukan anu dibagi, sareng tiasa ngalaksanakeunana salami éta nganggo operasi atom.
            /// Sagala panggunaan pointer atah anu dikembalikan peryogi blok `unsafe` sareng masih kedah ngajaga watesan anu sami: operasi pikeun éta pasti atom.
            ///
            ///
            /// # Examples
            ///
            /// `` `Malire (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // Kaamanan: Aman salami `my_atomic_op` mangrupikeun atom.
            /// teu aman {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // Kasalametan: panelepon kudu uphold kontrak kaamanan pikeun `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Mulih ka nilai saméméhna (kawas __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Balikkeun nilai sateuacana (siga __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// mulihkeun nilai max (perbandingan anu ditandatanganan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Kasalametan: panelepon kudu uphold kontrak kaamanan pikeun `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// mulih ka nilai min (ditandatanganan ngabandingkeun)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: anu nelepon kedah ngadukung kontrak kaamanan pikeun `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// mulihkeun nilai max (perbandingan teu ditandatanganan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Kasalametan: panelepon kudu uphold kontrak kaamanan pikeun `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// mulihkeun nilai mnt (perbandingan teu ditandatanganan)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Kasalametan: panelepon kudu uphold kontrak kaamanan pikeun `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Pager atom.
///
/// Gumantung kana urutan anu parantos ditangtoskeun, pager nyegah kompiler sareng CPU tina ngarobih sababaraha jinis operasi memori di sakurilingna.
/// Éta nyiptakeun sinkronisasi-sareng hubungan antara éta sareng operasi atom atanapi pager dina benang sanés.
///
/// Pager 'A' anu ngagaduhan (sahenteuna) [`Release`] mesen semantik, disingkronkeun sareng pager 'B' kalayan (sahenteuna) [`Acquire`] semantik, upami sareng ngan upami aya operasi X sareng Y, kaduana dianggo dina sababaraha objék atom 'M' sapertos A diruntuy sateuacanna X, Y disingkronkeun sateuacan B sareng Y niténan parobihan kana M.
/// Ieu nyayogikeun kajantenan sateuacan-antara A sareng B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operasi atom ku [`Release`] atanapi [`Acquire`] semantik ogé tiasa nyingkronkeun sareng pager.
///
/// Pager anu ngagaduhan [`SeqCst`] mesen, salian ti ngagaduhan [`Acquire`] sareng [`Release`] semantik, ilubiung dina urutan program global operasi [`SeqCst`] anu sanés sareng/atanapi pager.
///
/// Narima urutan [`Acquire`], [`Release`], [`AcqRel`] sareng [`SeqCst`].
///
/// # Panics
///
/// Panics upami `order` nyaéta [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // A pangaluaran silih primitif dumasar spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Antosan dugi nilai lami nyaéta `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Pager ieu nyingkronkeun-sareng toko di `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // KESELAMATAN: ngagunakeun pager atom aman.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Pager memori kompiler.
///
/// `compiler_fence` henteu ngaluarkeun kode mesin, tapi ngabatesan jinis mémori mesen deui panyusunna diidinan dilakukeun.Khususna, gumantung kana semantik [`Ordering`] anu dipasihkeun, panyusunna tiasa janten teu kéngingkeun maca atanapi nyerat ti sateuacan atanapi saatos nelepon ka sisi sanésna nelepon ka `compiler_fence`.Catet yén éta **henteu** nyegah *hardware* tina ngalakukeun susunan deui sapertos kitu.
///
/// Ieu sanés masalah dina kontéks éksékutip tunggal, tapi nalika utas anu sanés tiasa ngarobih mémori dina waktos anu sami, primitip sinkronisasi langkung kuat sapertos [`fence`] diperyogikeun.
///
/// Pesenan ulang dicegah ku semantik susunan anu béda nyaéta:
///
///  - kalayan [`SeqCst`], henteu mesen ulang bacaan sareng nyerat ngalangkungan titik ieu diijinkeun.
///  - kalawan [`Release`], harita maos na nyerat teu bisa dipindahkeun kaliwat nyerat saterusna.
///  - kalayan [`Acquire`], maca teras nyerat teu tiasa dipindahkeun sateuacan dibaca sateuacanna.
///  - kalayan [`AcqRel`], duanana aturan di luhur diterapkeun.
///
/// `compiler_fence` umumna ukur mangpaat pikeun ngahulag thread ti balap *kalawan sorangan*.Nyaéta, upami benang anu ditetepkeun ngaéksekusi salah sahiji kode, teras diganggu, sareng mimiti ngaéksekusi kode di tempat sanés (nalika masih dina utas anu sami, sareng konsépna tetep dina inti anu sami).Dina program tradisional, ieu ngan bisa lumangsung lamun Handler sinyal geus didaptarkeun.
/// Dina kode tingkat langkung handap, kaayaan sapertos kitu ogé tiasa timbul nalika nanganan gangguan, nalika nerapkeun benang héjo kalayan pre-emption, jsb.
/// Pamiarsa panasaran kadorong pikeun maca sawala kernel Linux ngeunaan [memory barriers].
///
/// # Panics
///
/// Panics upami `order` nyaéta [`Relaxed`].
///
/// # Examples
///
/// Tanpa `compiler_fence`, `assert_eq!` dina kode di handap ieu *henteu* dijamin berhasil, sanaos sadayana aya dina hiji utas.
/// Pikeun ningali kunaon, émut yén panyusunna bébas ngaganti toko ka `IMPORTANT_VARIABLE` sareng `IS_READ` kumargi duanana `Ordering::Relaxed`.Upami éta leres, sareng pawang sinyal disebat pas saatos `IS_READY` diénggalan, maka pawang sinyal bakal ningali `IS_READY=1`, tapi `IMPORTANT_VARIABLE=0`.
/// Maké `compiler_fence` remedies situasi ieu.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // nyegah nyerat saméméhna ti keur dipindahkeun saluareun titik ieu
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // KESELAMATAN: ngagunakeun pager atom aman.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Sinyal prosesor yén éta téh jero hiji sibuk-nungguan spin-loop ("spin konci").
///
/// Pungsi ieu teu nganggo langkung milih [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}