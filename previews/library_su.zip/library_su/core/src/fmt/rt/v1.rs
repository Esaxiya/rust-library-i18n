//! Ieu mangrupa modul internal dipaké ku ifmt nu!runtime.Struktur ieu dipancarkeun kana susunan statik pikeun precompile string format sateuacanna waktos.
//!
//! definisi ieu sarupa jeung `ct` equivalents maranéhanana, tapi béda dina éta ieu bisa statically disadiakeun jeung anu rada dioptimalkeun pikeun runtime nu
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Kamungkinan koréksi anu tiasa dipénta salaku bagian tina arahan pormat.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikasi yen eusi kedah kénca-Blok.
    Left,
    /// Indikasi yen eusi kedah katuhu-Blok.
    Right,
    /// Indikasi yén konténna kedah Blok-Blok.
    Center,
    /// Teu aya panyelarasan anu dipénta.
    Unknown,
}

/// Dipaké ku [width](https://doc.rust-lang.org/std/fmt/#width) sareng [precision](https://doc.rust-lang.org/std/fmt/#precision) spésifis.
#[derive(Copy, Clone)]
pub enum Count {
    /// Dieusian ku jumlah literal, nyimpen ajén
    Is(usize),
    /// Dihususkeun nganggo sintaksis `$` sareng `*`, nyimpen indéks kana `args`
    Param(usize),
    /// Henteu ditangtoskeun
    Implied,
}