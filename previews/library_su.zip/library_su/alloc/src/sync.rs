#![stable(feature = "rust1", since = "1.0.0")]

//! Tulisan rujukan-itung-aman Thread-safe.
//!
//! Tingali dokuméntasi [`Arc<T>`][Arc] pikeun langkung jelasna.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Wates lemes dina jumlah rujukan anu tiasa dilakukeun kana `Arc`.
///
/// Luhureun wates ieu bakal ngabatalkeun program anjeun (sanaos henteu kedah) dina rujukan _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer henteu ngadukung pager mémori.
// Pikeun ngahindarkeun laporan positip palsu dina panerapan Arc/Lemah nganggo beban atom pikeun sinkronisasi.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// A pointer rujukan-cacah pointer.'Arc' singkatan tina 'Atomically Reference Counted'.
///
/// Jinis `Arc<T>` nyayogikeun kapamilikan babarengan jinis `T`, dialokasikan dina tumpukan.Invoking [`clone`][clone] on `Arc` ngahasilkeun conto `Arc` anyar, anu nunjuk kana alokasi anu sami dina tumpukan salaku sumber `Arc`, bari ningkatkeun jumlah rujukan.
/// Nalika pointer `Arc` terakhir kana alokasi anu ditumpes musnah, nilai anu disimpen dina alokasi éta (sering disebut "inner value") ogé turun.
///
/// Rujukan anu dibagikeun dina Rust teu kéngingkeun mutasi sacara standar, sareng `Arc` henteu terkecuali: anjeun moal umum tiasa kéngingkeun rujukan anu tiasa dirobih pikeun anu aya dina `Arc`.Upami anjeun kedah mutasi ngalangkungan `Arc`, anggo [`Mutex`][mutex], [`RwLock`][rwlock], atanapi salah sahiji jinis [`Atomic`][atomic].
///
/// ## Kasalametan Thread
///
/// Béda sareng [`Rc<T>`], `Arc<T>` ngagunakeun operasi atom pikeun cacah rujukan na.Ieu ngandung harti yén éta aman-aman.Anu ngarugikeunana nyaéta operasi atom langkung awis tibatan aksés mémori biasa.Upami anjeun henteu ngabagi alokasi-itungan rujukan di antara utas, pertimbangkeun nganggo [`Rc<T>`] kanggo overhead anu langkung handap.
/// [`Rc<T>`] mangrupikeun standar anu aman, sabab anu nyusun bakal nyobian usaha ngirim [`Rc<T>`] antara benang.
/// Nanging, perpustakaan tiasa milih `Arc<T>` supados masihan konsumén perpustakaan langkung kalenturan.
///
/// `Arc<T>` bakal nerapkeun [`Send`] sareng [`Sync`] salami `T` ngalaksanakeun [`Send`] sareng [`Sync`].
/// Naha anjeun henteu tiasa nempatkeun tipe `T` anu sanés benang dina `Arc<T>` pikeun ngajantenkeun aman-aman?Ieu panginten janten rada kontra-intuitif dina mimitina: saurna, henteu titik kaamanan `Arc<T>` thread?Koncina nyaéta ieu: `Arc<T>` ngajantenkeun aman pikeun gaduh sababaraha kapamilikan data anu sami, tapi henteu nambihan kaamanan thread kana data na.
///
/// Pertimbangkeun `Arc <` ['RefCell<T>`]`> `.
/// [`RefCell<T>`] sanés [`Sync`], sareng upami `Arc<T>` sok [`Send`], `Arc <` ['RefCell<T>`]`> `Bakal jadi ogé.
/// Tapi kami bakal ngagaduhan masalah:
/// [`RefCell<T>`] henteu benang aman;éta ngalacak cacah injeuman ngagunakeun operasi non-atom.
///
/// Tungtungna, ieu ngandung harti yén anjeun panginten kedah masangkeun `Arc<T>` sareng sababaraha jinis [`std::sync`], biasana [`Mutex<T>`][mutex].
///
/// ## Putus siklus sareng `Weak`
///
/// Metodeu [`downgrade`][downgrade] tiasa dianggo pikeun nyiptakeun [`Weak`] pointer anu teu ngagaduhan.A pointer [`Weak`] tiasa [`upgrade`][upgrade] d kana `Arc`, tapi ieu bakal balikkeun [`None`] upami nilai anu disimpen dina alokasi parantos lungsur.
/// Dina basa sejen, `Weak` pointers ulah tetep dina nilai jero alokasi hirup;Nanging, aranjeunna * tetep ngajaga alokasi (toko pangrojong pikeun nilaina) tetep hirup.
///
/// Siklus antara `Arc` pointers moal pernah dirobih.
/// Kusabab kitu, [`Weak`] digunakeun pikeun megatkeun siklus.Salaku conto, tangkal tiasa ngagaduhan petunjuk `Arc` anu kuat ti titik indung ka budak, sareng [`Weak`] petunjuk ti budak deui ka kolotna.
///
/// # Rujukan kloning
///
/// Nyiptakeun rujukan énggal tina panunjuk rujukan anu diitung parantos dilakukeun nganggo `Clone` trait anu dilaksanakeun pikeun [`Arc<T>`][Arc] sareng [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dua sintaksis ieu di handap sami.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, sareng foo sadayana mangrupikeun busur anu nunjuk kana lokasi mémori anu sami
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` otomatis dereferénsi ka `T` (ngalangkungan [`Deref`][deref] trait), janten anjeun tiasa nyauran metode `T` dina nilai jinis `Arc<T>`.Pikeun ngahindaran bentrok nami sareng metode `T`, metode `Arc<T>` nyalira aya pakaitna fungsi, disebat nganggo [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>`Implementations'stina traits kawas `Clone` bisa ogé disebut maké rumpaka mumpuni pinuh.
/// Sababaraha jalma resep ngagunakeun sintaksis anu mumpuni, sedengkeun anu sanés resep ngagunakeun sintaksis-panggero sintaksis.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaksis metode-panggero
/// let arc2 = arc.clone();
/// // Sintaksis mumpuni lengkep
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] henteu otomatis-ngahakan kana `T`, sabab nilai batinna panginten parantos turun.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ngabagikeun sababaraha data anu teu tiasa dirobih antara utas:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Catet yén urang **henteu** ngajalankeun tés ieu di dieu.
// Pembina windows janten super bagja upami utas langkung panjang tina utas utami teras kaluar dina waktos anu sami (hal anu buntu) janten urang ngan ukur nyingkahan ieu ku henteu ngajalankeun tés ieu.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ngabagikeun [`AtomicUsize`] anu tiasa dirobih:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Tingali [`rc` documentation][rc_examples] pikeun langkung seueur conto cacah rujukan sacara umum.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` mangrupikeun vérsi [`Arc`] anu ngagaduhan rujukan anu teu kapimilik pikeun alokasi anu dikokolakeun.
/// Alokasi diaksés ku nelepon [`upgrade`] dina panunjuk `Weak`, anu ngabalikeun hiji [`Option`]`<`[Arc`]`<T>> `.
///
/// Kusabab rujukan `Weak` henteu diitung dina kapamilikan, éta moal nyegah nilai anu disimpen dina alokasi turun, sareng `Weak` nyalira henteu ngajamin ngeunaan nilai anu masih aya.
///
/// Maka éta tiasa mulih [`None`] nalika [`upgrade`] d.
/// Catet kumaha ogé yén rujukan `Weak`*henteu* nyegah alokasi éta nyalira (toko pangrojong) tina transaksi.
///
/// A pointer `Weak` gunana pikeun ngajaga rujukan samentawis kana alokasi anu dikelola ku [`Arc`] tanpa nyegah nilai jero na tina murag.
/// Ogé dianggo pikeun nyegah rujukan bunderan antara poin [`Arc`], kumargi silih referensi anu ngagaduhan moal ngijinkeun [`Arc`] turun.
/// Salaku conto, tangkal tiasa ngagaduhan petunjuk [`Arc`] anu kuat ti titik indung ka budak, sareng `Weak` petunjuk ti budak deui ka kolotna.
///
/// Cara anu khas pikeun kéngingkeun pitunjuk `Weak` nyaéta nyauran [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ieu mangrupikeun `NonNull` kanggo ngamungkinkeun ngaoptimalkeun ukuran tina jenis ieu dina enum, tapi éta henteu kedah janten pointer anu valid.
    //
    // `Weak::new` netepkeun ieu ka `usize::MAX` sahingga henteu kedah nyebarkeun rohangan dina tumpukan.
    // Éta sanés nilai anu ditunjuk pointer anu nyata sabab RcBox gaduh alignment sahenteuna 2.
    // Ieu ngan mungkin nalika `T: Sized`;`T` unsized pernah ngagantung.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ieu repr(C) ka future-buktina ngalawan kamungkinan panataan lapangan, anu bakal ngaganggu [into|from]_raw() anu sanés anu aman tina jinis jero anu tiasa ditransmisikeun.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // nilai usize::MAX tindakan minangka sentinel pikeun samentawis "locking" kamampuan ningkatkeun tunjuk lemah atanapi nurunkeun anu kuat;ieu dipaké pikeun nyingkahan balapan di `make_mut` sareng `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Nyusun `Arc<T>` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Mimitian itungan pointer lemah salaku 1 anu pointer lemah anu dicekel ku sadaya pointers kuat (kinda), tingali std/rc.rs pikeun langkung seueur inpo
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Nyusun `Arc<T>` énggal nganggo rujukan anu lemah pikeun dirina sorangan.
    /// Nyobian ningkatkeun rujukan anu lemah sateuacan fungsi ieu balik bakal ngahasilkeun nilai `None`.
    /// Sanajan kitu, dina rujukan lemah bisa jadi diklon kalawan bébas tur disimpen pikeun pamakéan dina waktu engké.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ngawangun batin dina kaayaan "uninitialized" ku hiji rujukan lemah.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting urang ulah nyerah kapamilikan pointer lemah, atanapi upami mémori éta tiasa dibébaskeun ku waktos `data_fn` mulih.
        // Upami urang leres-leres hoyong lulus kapamilikan, urang tiasa nyiptakeun petunjuk lemah anu lemah pikeun diri urang sorangan, tapi ieu bakal ngahasilkeun pembaruan tambahan kana jumlah rujukan anu lemah anu tiasa henteu diperyogikeun sanésna.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ayeuna urang tiasa leres ngainisialkeun nilai jero sareng ngajantenkeun référénsi lemah kami janten rujukan anu kuat.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Tulis di luhur kana lapangan data kedah katingali ku utas mana waé anu niténan kaitung anu teu nol.
            // Kituna urang peryogi sahenteuna "Release" mesen pikeun nyingkronkeun sareng `compare_exchange_weak` dina `Weak::upgrade`.
            //
            // "Acquire" mesen henteu diperyogikeun.
            // Nalika ngémutan paripolah `data_fn` anu mungkin urang ngan ukur kedah ningali naon anu tiasa dilakukeun ku rujukan kana `Weak` anu henteu tiasa ditingkatkeun:
            //
            // - Éta tiasa * mengkloning `Weak`, ningkatkeun cacah rujukan anu lemah.
            // - Éta tiasa lungsur klon-klon éta, ngirangan itungan rujukan anu lemah (tapi henteu pernah nol).
            //
            // Efek samping ieu henteu mangaruhan urang ku cara naon waé, sareng teu aya efek samping sanés anu dimungkinkeun ku kode aman waé.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Rujukan anu kuat kedah sacara koléktif ngagaduhan rujukan anu lemah, janten henteu ngajalankeun destructor pikeun rujukan lemah kami anu lami.
        //
        mem::forget(weak);
        strong
    }

    /// Nyusunna `Arc` énggal kalayan kontén anu teu dihaja.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Nyusun `Arc` énggal kalayan kontén anu teu dihaja, kalayan mémori dieusian ku `0` bait.
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Nyusun `Pin<Arc<T>>` anyar.
    /// Upami `T` henteu nerapkeun `Unpin`, maka `data` bakal dipasang dina mémori sareng teu tiasa dipindahkeun.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Nyusun `Arc<T>` anyar, balikkeun kasalahan upami alokasi gagal.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Mimitian itungan pointer lemah salaku 1 anu pointer lemah anu dicekel ku sadaya pointers kuat (kinda), tingali std/rc.rs pikeun langkung seueur inpo
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Nyusun `Arc` énggal kalayan kontén anu teu dihaja, balikkeun kasalahan upami alokasi gagal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Nyusun `Arc` énggal kalayan kontén anu teu dihaja, kalayan mémori dieusian ku `0` bait, balikkeun kasalahan upami alokasi gagal.
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Balikkeun nilai jero, upami `Arc` gaduh persis hiji rujukan anu kuat.
    ///
    /// Upami teu kitu, [`Err`] dipulangkeun sareng `Arc` anu sami anu dialirkeun.
    ///
    ///
    /// Ieu bakal hasil sanaos aya rujukan lemah anu luar biasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Ngadamel pointer lemah pikeun ngabersihan nepi ka rujukan kuat-lemah implisit
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ngawangun sekuen atom-referensi atom anu énggal kalayan kontén anu teu acan dirinisikeun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Ngawangun sekuen atom-referensi anu diitung sacara atom anyar kalayan eusi anu teu aya artosialisasi, kalayan mémori dieusian ku `0` bait.
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Ngarobih kana `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Sapertos sareng [`MaybeUninit::assume_init`], terserah ka anu nelepon pikeun ngajamin yén nilai jero saleresna aya dina kaayaan inisialisasi.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku teu langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Ngarobih kana `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sapertos sareng [`MaybeUninit::assume_init`], terserah ka anu nelepon pikeun ngajamin yén nilai jero saleresna aya dina kaayaan inisialisasi.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku teu langsung.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Mésér `Arc`, balikkeun pointer anu dibungkus.
    ///
    /// Pikeun ngahindarkeun bocor ingetan pointer kedah dialihkeun deui ka `Arc` nganggo [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyayogikeun pointer atah kana data.
    ///
    /// Cacah henteu kapangaruhan ku cara naon waé sareng `Arc` henteu dikonsumsi.
    /// Pointer valid pikeun salami aya cacah anu kuat dina `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // Kaamanan: Ieu henteu tiasa ngalangkungan Deref::deref atanapi RcBoxPtr::inner sabab
        // ieu diperyogikeun pikeun ngajaga raw/mut buktina sapertos contona
        // `get_mut` tiasa nyerat nganggo pointer saatos Rc dipulihkeun ngalangkungan `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Nyusunna `Arc<T>` tina pointer atah.
    ///
    /// Pointer atah kedahna sateuacanna dipulangkeun deui ku telepon ka [`Arc<U>::into_raw`][into_raw] dimana `U` kedah gaduh ukuran sareng alignment anu sami sareng `T`.
    /// Ieu leres pisan upami `U` nyaéta `T`.
    /// Catet yén upami `U` sanés `T` tapi ngagaduhan ukuran sareng alignment anu sami, ieu dasarna sapertos transmisi rujukan tina sababaraha jinis.
    /// Tingali [`mem::transmute`][transmute] pikeun langkung seueur inpormasi ngeunaan larangan naon dina hal ieu.
    ///
    /// Pamaké `from_raw` kedah pastikeun nilai khusus `T` ngan ukur lungsur sakali.
    ///
    /// Fungsi ieu henteu aman sabab panggunaan anu salah tiasa ngakibatkeun teu aman, bahkan upami `Arc<T>` anu dipulangkeun henteu acan kantos diakses.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ngarobih deui ka `Arc` pikeun nyegah kabocoran.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telepon salajengna ka `Arc::from_raw(x_ptr)` bakal ingetan-aman.
    /// }
    ///
    /// // Memori dibébaskeun nalika `x` kaluar tina ruang lingkup di luhur, janten `x_ptr` ayeuna ngagantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Balikkeun offset pikeun milarian ArcInner aslina.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Nyiptakeun petunjuk [`Weak`] anyar pikeun alokasi ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Rileks Ieu saé kusabab urang nuju mariksa niléy dina CAS di handap.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // pariksa lamun lemah counter ayeuna "locked";upami kitu, puterkeun.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kode ieu ayeuna teu ngémutan kamungkinan kabanjiran
            // kana usize::MAX;dina umumna boh Rc sareng Arc kedah disaluyukeun pikeun nungkulan limpahan.
            //

            // Beda sareng Clone(), urang peryogi ieu janten maca Acquire pikeun nyingkronkeun sareng nyeratna sumping ti `is_unique`, supados kajadian sateuacan nyerat éta kajantenan sateuacan dibaca ieu.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Pastikeun kami henteu nyiptakeun Lemah anu ngagantung
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Meunangkeun jumlah panunjuk [`Weak`] kana alokasi ieu.
    ///
    /// # Safety
    ///
    /// Cara ieu nyalira aman, tapi ngagunakeunana leres meryogikeun perawatan ekstra.
    /// Utas anu sanés tiasa ngarobih cacah anu lemah iraha waé, kalebet berpotensi antara nelepon metoda ieu sareng nindak hasilna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Cindekna ieu deterministik sabab kami geus moal dibagikeun ka `Arc` atanapi `Weak` antara threads.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Upami itung lemah ayeuna dikonci, nilai itungana 0 sateuacana nyandak konci.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Meunangkeun jumlah panunjuk (`Arc`) anu kuat pikeun alokasi ieu.
    ///
    /// # Safety
    ///
    /// Cara ieu nyalira aman, tapi ngagunakeunana leres meryogikeun perawatan ekstra.
    /// Utas anu sanés tiasa ngarobih jumlah anu kuat iraha waé, kalebet berpotensi antara nelepon metoda ieu sareng akting dina hasilna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Cindekna ieu deterministik sabab kami henteu acan ngabagi `Arc` antara benang.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ningkatkeun itungan rujukan anu kuat dina `Arc<T>` pakait sareng panunjuk anu disayogikeun ku hiji.
    ///
    /// # Safety
    ///
    /// Penunjuk kedah diala ngalangkungan `Arc::into_raw`, sareng conto `Arc` anu pakait kedah sah (nyaéta
    /// itungan anu kuat kedah sahenteuna 1) salami metoda ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Cindekna ieu deterministik sabab kami henteu acan ngabagi `Arc` antara benang.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Tetepkeun Arc, tapi tong toél récount ku bungkus dina ManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ayeuna tingkatkeun récount, tapi tong turun ogé récount énggal
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Decrements itungan rujukan anu kuat dina `Arc<T>` pakait sareng panunjuk anu disayogikeun ku hiji.
    ///
    /// # Safety
    ///
    /// Penunjuk kedah diala ngalangkungan `Arc::into_raw`, sareng conto `Arc` anu pakait kedah sah (nyaéta
    /// nu count kuat sahenteuna kudu 1) nalika invoking metoda ieu.
    /// Cara ieu tiasa dianggo pikeun ngaleupaskeun `Arc` akhir sareng panyimpenan panyokong, tapi **henteu kedah** disebat saatos `Arc` akhir parantos dileupaskeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Éta pernyataan parantos ditangtoskeun sabab urang henteu parantos ngabagi `Arc` antara benang.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // unsafety Ieu ok sabab bari arc ieu hirup urang nuju dijamin yén pointer jero téh sah.
        // Saterasna, urang terang yén struktur `ArcInner` éta sorangan nyaéta `Sync` kusabab data jero `Sync` ogé, janten urang tiasa masihan petunjuk anu teu tiasa robih kana eusi ieu.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Bagian non-inline `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ngancurkeun data dina waktos ayeuna, sanaos urang tiasa henteu ngaleupaskeun alokasi kotak éta nyalira (panginten masih aya poin lemah anu ngagolér).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Leupaskeun ref lemah koléktif dicekel ku sadaya rujukan kuat
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Balikkeun `true` upami dua `Arc`s nunjuk kana alokasi anu sami (dina urat anu sami sareng [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alokasi `ArcInner<T>` kalayan rohangan anu cekap pikeun nilai batin anu tiasa-henteu ukuran dimana nilaina parantos disayogikeun.
    ///
    /// Fungsi `mem_to_arcinner` disebut nganggo data pointer sareng kedah ngauihkeun deui (berpotensi gajih)-panunjuk pikeun `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Ngitung perenah nganggo tata nilai anu parantos dipasihkeun.
        // Sateuacanna, tata ruang diitung dina ungkapan `&*(ptr as* const ArcInner<T>)`, tapi ieu nyiptakeun rujukan anu salah (tingali #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokasi `ArcInner<T>` kalayan rohangan anu cekap pikeun nilai batin anu tiasa-teu disukuran dimana nilaina parantos disayogikeun, mulihkeun kasalahan upami alokasi gagal.
    ///
    ///
    /// Fungsi `mem_to_arcinner` disebut nganggo data pointer sareng kedah ngauihkeun deui (berpotensi gajih)-panunjuk pikeun `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Ngitung perenah nganggo tata nilai anu parantos dipasihkeun.
        // Sateuacanna, tata ruang diitung dina ungkapan `&*(ptr as* const ArcInner<T>)`, tapi ieu nyiptakeun rujukan anu salah (tingali #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialize ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alokasi `ArcInner<T>` kalayan rohangan anu cekap pikeun nilai jero anu henteu ukuran.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Alokasi pikeun `ArcInner<T>` nganggo nilai anu ditangtoskeun.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salin salaku bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Bébaskeun alokasi tanpa leupaskeun eusina
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alokasi `ArcInner<[T]>` kalayan panjang anu ditangtoskeun.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Salin elemen tina keureutan kana Arc <\[T\]> anu nembé dikaluarkeun
    ///
    /// Henteu aman sabab anu nelepon kedah ngagaduhan kapamilikan atanapi ngabeungkeut `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Nyusun `Arc<[T]>` tina iterator anu dipikanyaho ukuranana tangtu.
    ///
    /// Kalakuan teu ditangtoskeun kedah ukuranana lepat.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Penjaga Panic bari kloning elemen T.
        // Dina acara panic, elemen anu parantos ditulis kana ArcInner énggal bakal murag, teras mémori dibébaskeun.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer kana unsur kahiji
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Sadayana jelas.Hilap penjaga supados henteu ngosongkeun ArcInner énggal.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spésialisasi trait dianggo pikeun `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Ngajadikeun hiji clone sahiji pointer `Arc`.
    ///
    /// Ieu nyiptakeun petunjuk anu sanés kana alokasi anu sami, ningkatkeun cacah rujukan anu kuat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Nganggo urutan santai nyaéta leres-leres di dieu, sabab kanyaho ngeunaan référénsi aslina nyegah benang sanés tina salah ngahapus obyék.
        //
        // Saperti dipedar di [Boost documentation][1], Ngaronjatna nu counter rujukan bisa salawasna dilakukeun ku memory_order_relaxed: rujukan Anyar kana hiji obyék ukur bisa dibentuk tina hiji rujukan aya, sarta ngalirkeun hiji rujukan aya ti salah thread kana sejen kudu geus nyadiakeun sagala sinkronisasi diperlukeun.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Nanging urang kedah waspada tina pangirangan deui upami aya anu `mem: : poho`ing Arcs.
        // Upami urang henteu ngalakukeun ieu cacah tiasa ngabahekeun sareng pangguna bakal nganggo-gratis.
        // Kami ras jenuh kana `isize::MAX` dina asumsi yén teu aya ~2 milyar benang nambihan jumlah rujukan sakaligus.
        //
        // branch ieu moal pernah dicandak dina program anu réalistis.
        //
        // Kami ngabatalkeun kusabab program sapertos kitu pisan turun, sareng kami henteu paduli pikeun ngadukung éta.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Ngajantenkeun rujukan anu tiasa dirobih kana `Arc` anu ditangtoskeun.
    ///
    /// Upami aya `Arc` atanapi [`Weak`] pointers anu sanés kana alokasi anu sami, maka `make_mut` bakal nyiptakeun alokasi énggal sareng nyungkeun [`clone`][clone] dina nilai jero pikeun mastikeun kapamilikan unik.
    /// Ieu ogé disebat klon-on-nyerat.
    ///
    /// Catet yén ieu béda tina kabiasaan [`Rc::make_mut`] anu ngaleungitkeun sagala petunjuk `Weak` sésana.
    ///
    /// Tingali ogé [`get_mut`][get_mut], anu bakal gagal tibatan kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Moal klon nanaon
    /// let mut other_data = Arc::clone(&data); // Moal klon data jero
    /// *Arc::make_mut(&mut data) += 1;         // Data batin klon
    /// *Arc::make_mut(&mut data) += 1;         // Moal klon nanaon
    /// *Arc::make_mut(&mut other_data) *= 2;   // Moal klon nanaon
    ///
    /// // Ayeuna `data` sareng `other_data` nunjuk kana alokasi anu béda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Catet yén urang ngagaduhan rujukan anu kuat sareng rujukan anu lemah.
        // Kukituna, ngaleupaskeun référénsi kuat kami ngan moal, ku nyalira, nyababkeun mémori janten paséa.
        //
        // Anggo Acquire pikeun mastikeun yén kami ningali nyerat ka `weak` anu kajantenan sateuacan nyerat nyerat (nyaéta decrement) dugi ka `strong`.
        // Kusabab urang gaduh itungan anu lemah, teu aya kasempetan pikeun ArcInner sorangan tiasa disundakeun.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Panunjuk anu kuat sanésna aya, janten urang kedah diklon.
            // Memori sateuacanna alokasi pikeun ngamungkinkeun nyerat nilai diklon langsung.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Bersantai cekap di luhur kusabab ieu dasarna mangrupikeun optimalisasi: urang teras balap kalayan pointer lemah anu murag.
            // Bisi paling parah, urang tungtungna dialokasikan Arc anyar teu perlu.
            //

            // Kami ngaleupaskeun ref kuat terakhir, tapi aya tambahan ref anu lemah.
            // Urang bakal mindahkeun kontén kana Arc anyar, sareng ngabatalkeun ref anu lemah sanésna.
            //

            // Catet yén teu mungkin pikeun dibaca `weak` ngahasilkeun usize::MAX (nyaéta, dikonci), kusabab itungan anu lemah ngan ukur tiasa dikonci ku utas ku référénsi anu kuat.
            //
            //

            // Ngadamel panunjuk lemah urang sorangan anu lemah, janten tiasa ngabersihan ArcInner sakumaha diperyogikeun.
            //
            let _weak = Weak { ptr: this.ptr };

            // Ngan ukur tiasa maok data, sadayana anu nyésa nyaéta Lemah
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Kami hiji-hijina rujukan pikeun salah sahiji jenis naon;nabrak deui up itungan ref anu kuat.
            //
            this.inner().strong.store(1, Release);
        }

        // Salaku kalawan `get_mut()`, unsafety nyaeta ok sabab rujukan urang éta boh unik keur dimimitian ku, atawa jadi salah kana kloning eusi.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Balikkeun rujukan anu tiasa dirobih kana `Arc` anu ditangtoskeun, upami teu aya panunjuk `Arc` atanapi [`Weak`] anu sanés kana alokasi anu sami.
    ///
    ///
    /// Mulang [`None`] sanésna, sabab henteu aman pikeun ngarobih nilai anu dibagi.
    ///
    /// Tingali ogé [`make_mut`][make_mut], anu bakal [`clone`][clone] nilai jero nalika aya petunjuk anu sanés.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Kaayaan teu aman ieu ok sabab urang dijamin pointer anu dipulangkeun mangrupikeun *hijina* pointer anu bakal kantos dipulangkeun ka T.
            // Cacah rujukan kami dijamin janten 1 dina waktos ieu, sareng kami meryogikeun Arc dirina janten `mut`, janten kami balikkeun hiji-hijina referensi anu mungkin dina data jero.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Balikkeun rujukan anu tiasa dirobih kana `Arc` anu ditangtoskeun, tanpa cek nanaon.
    ///
    /// Tingali ogé [`get_mut`], anu aman sareng teu dipariksa anu pantes.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Nunjuk naon waé `Arc` atanapi [`Weak`] anu sanés kana alokasi anu sami henteu kedah diséferénsi salami waktos ngintunkeun deui.
    ///
    /// Ieu trivially masalahna lamun euweuh pointers misalna aya, contona langsung saatos `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami ati-ati pikeun *henteu* nyiptakeun rujukan anu nutupan lapangan "count", sabab ieu bakal landian sareng aksés anu sami sareng itungan rujukan (mis.
        // ku `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Tangtukeun naha ieu mangrupikeun rujukan anu unik (kalebet lemah refs) kana data anu aya dina dasarna.
    ///
    ///
    /// Catet yén ieu peryogi ngonci count ref anu lemah.
    fn is_unique(&mut self) -> bool {
        // ngonci itungan pointer lemah lamun urang sigana ngan ukur boga pointer lemah.
        //
        // Labél acquisition didieu mastikeun hubungan anu lumangsung-sateuacanna sareng nyeratna kana `strong` (khususna `Weak::upgrade`) sateuacan dikirangan tina jumlah `weak` (ngalangkungan `Weak::drop`, anu ngagunakeun pelepasan).
        // Upami ref anu lemah anu ditingkatkeun henteu kantos lungsur, CAS di dieu bakal gagal janten kami henteu paduli pikeun nyingkronkeun.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ieu kedah janten `Acquire` pikeun nyingkronkeun sareng panurunan tina loket `strong` di `drop`-hiji-hijina aksés anu kajantenan nalika referensi anu terakhir diturunkeun.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Pelepasan nyerat didieu disingkronkeun sareng anu dibaca dina `downgrade`, sacara efektif nyegah bacaan `strong` di luhur tina kajadian saatos nyerat.
            //
            //
            self.inner().weak.store(1, Release); // ngaleupaskeun konci na
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Tetes `Arc`.
    ///
    /// Ieu bakal nurunkeun itungan rujukan anu kuat.
    /// Upami jumlah referensi anu kuat ngahontal enol maka ngan ukur rujukan anu sanés (upami aya) nyaéta [`Weak`], janten kami `drop` nilai jero.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Henteu nyitak nanaon
    /// drop(foo2);   // Nyitak "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Kusabab `fetch_sub` parantos atom, urang henteu kedah nyingkronkeun sareng utas sanés upami urang bade mupus obyékna.
        // Logika anu sami ieu dilarapkeun di handap `fetch_sub` kana itungan `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Pager ieu diperyogikeun pikeun nyegah panyusunan panggunaan data sareng ngahapus data.
        // Kusabab éta ditandaan `Release`, turunna count rujukan bakal disingkronkeun sareng pager `Acquire` ieu.
        // Ieu ngandung harti yén panggunaan data kajantenan sateuacan ngirangan hitungan rujukan, anu kajantenan sateuacan pager ieu, anu kajantenan sateuacan dihapus data.
        //
        // Sakumaha anu dijelaskeun dina [Boost documentation][1],
        //
        // > Penting pikeun maksa aksés kamungkinan kana obyék dina hiji
        // > utas (ngalangkungan rujukan anu aya) pikeun *lumangsung sateuacan* mupus
        // > obyék dina utas anu sanés.Ieu dihontal ku "release"
        // > operasi saatos leupaskeun rujukan (aksés naon kana obyék
        // > ngalangkungan rujukan ieu pasti kedah kajantenan sateuacanna), sareng an
        // > "acquire" operasi sateuacan mupus obyék.
        //
        // Khususna, bari eusi Arc biasana teu tiasa dirobih, dimungkinkeun pikeun nyerat interior ka anu sapertos Mutex<T>.
        // Kusabab Mutex henteu kaala nalika dihapus, urang moal tiasa ngandelkeun logika sinkronisasi na pikeun nyerat dina thread A katingali ku destruktor anu ngalir dina utas B.
        //
        //
        // Ogé perhatoskeun pager Acquire di dieu panginten tiasa diganti ku beban Acquire, anu tiasa ningkatkeun performa dina kaayaan anu diperebutkeun.Tingali [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ngusahakeun downcast `Arc<dyn Any + Send + Sync>` kana jenis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Nyusun `Weak<T>` énggal, tanpa nyebarkeun mémori nanaon.
    /// Nelepon [`upgrade`] dina nilai balik sok masihan [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Nulungan ngetik pikeun ngidinan ngakses ka diitung rujukan tanpa nyieun assertions wae ngeunaan widang data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Balikkeun pointer atah kana obyék `T` anu ditunjuk ku `Weak<T>` ieu.
    ///
    /// pointer ieu valid ngan lamun aya sababaraha rujukan kuat.
    /// Pointer tiasa ngagantung, henteu disaluyukeun atanapi bahkan [`null`] sanés.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Duanana nunjuk kana objék anu sami
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Anu kuat di dieu tetep hirup, janten urang masih tiasa ngakses obyékna.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tapi henteu deui.
    /// // Urang tiasa ngalakukeun weak.as_ptr(), tapi ngaksés pointer bakal ngakibatkeun kabiasaan anu teu ditangtoskeun.
    /// // assert_eq! ("halo", teu aman {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Upami pointer ngagantung, urang langsung ngintunkeun sentinel.
            // Ieu moal tiasa janten alamat muatan anu sah, sabab muatanana sahenteuna sami sareng ArcInner (usize).
            ptr as *const T
        } else {
            // SAFETY: upami_dangling mulih palsu, maka pointer na teu tiasa dibatalkeun.
            // Payload tiasa diturunkeun dina titik ieu, sareng urang kedah ngajaga kasaksian, janten nganggo manipulasi pointer atah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Ngonsumsi `Weak<T>` sareng ngajantenkeun janten pointer atah.
    ///
    /// Ieu ngarobih pointer lemah kana pointer atah, nalika tetep ngajaga kapamilikan hiji rujukan lemah (itungan lemah henteu dirobah ku operasi ieu).
    /// Éta tiasa dirobih deui kana `Weak<T>` sareng [`from_raw`].
    ///
    /// Watesan anu sami pikeun ngakses udagan panunjuk sareng [`as_ptr`] lumaku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ngarobih pointer atah anu sateuacanna diciptakeun ku [`into_raw`] janten `Weak<T>`.
    ///
    /// Ieu tiasa dianggo pikeun sacara aman kéngingkeun rujukan anu kuat (ku nélépon [`upgrade`] engké) atanapi nungkulan jumlah lemah ku muterna `Weak<T>`.
    ///
    /// Butuh kapamilikan hiji rujukan anu lemah (kacuali poin anu diciptakeun ku [`new`], sabab ieu henteu ngagaduhan nanaon; padika masih tiasa dianggo pikeun aranjeunna).
    ///
    /// # Safety
    ///
    /// Pointer kedahna asalna ti [`into_raw`] sareng tetep kedah ngagaduhan poténsi rujukan anu lemah.
    ///
    /// Diidinan pikeun itungan anu kuat janten 0 dina waktos nelepon ieu.
    /// Sanaos kitu, ieu ngagaduhan kapamilikan hiji rujukan lemah anu ayeuna diwakilan salaku panunjuk atah (itungan lemah henteu dirobah ku operasi ieu) sahingga éta kedah dipasangkeun sareng sauran [`into_raw`] sateuacanna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ngirangan itungan lemah anu terakhir.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tingali Weak::as_ptr pikeun kontéks ngeunaan kumaha carana nunjukkeun pointer input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ieu Lemah ngagantung.
            ptr as *mut ArcInner<T>
        } else {
            // Upami teu kitu, urang dijamin panunjuk asalna tina Lemah nondangling.
            // SAFETY: data_offset aman ditelepon, sabab ptr ngarujuk nyata (berpotensi turun) T.
            let offset = unsafe { data_offset(ptr) };
            // Ku kituna, urang ngabalikkeun offset pikeun kéngingkeun sadayana RcBox.
            // SAFETY: pointer asalna tina Lemah, janten offset ieu aman.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: urang ayeuna parantos kéngingkeun pointer Leuleus anu asli, janten tiasa nyiptakeun Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Usaha pikeun ningkatkeun pidangan pointer `Weak` ka [`Arc`], nyangsang muterna nilai jero upami suksés.
    ///
    ///
    /// Mulih [`None`] upami nilai batinna saprak parantos lungsur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ngancurkeun sagala petunjuk anu kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Kami nganggo loop CAS pikeun nambihan jumlah anu kuat tibatan hiji fetch_add sabab fungsi ieu henteu kedah nyandak itungan rujukan tina enol ka hiji.
        //
        //
        let inner = self.inner()?;

        // Beban santai kusabab tulisan naon 0 anu tiasa urang titénan ninggali lapangan dina kaayaan nol permanén (janten "stale" dibaca 0 henteu kunanaon), sareng nilai sanés dikonfirmasi ngalangkungan CAS di handap.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Tingali koméntar dina `Arc::clone` naha urang ngalakukeun ieu (pikeun `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Bersantai henteu kunanaon pikeun kasus kagagalan kusabab urang teu gaduh ekspektasi ngeunaan kaayaan anyar.
            // Acquire perlu pikeun kasus kasuksésan pikeun nyingkronkeun sareng `Arc::new_cyclic`, nalika nilai jero tiasa diinisialkeun saatos référénsi `Weak` parantos didamel.
            // Dina kasus éta, kami ngarepkeun pikeun niténan nilai anu pinuh ku inisialisasi.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // batal diparios di luhur
                Err(old) => n = old,
            }
        }
    }

    /// Meunangkeun jumlah panunjuk (`Arc`) anu kuat nunjuk kana alokasi ieu.
    ///
    /// Upami `self` didamel nganggo [`Weak::new`], ieu bakal balik 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Meunangkeun perkiraan tina jumlah petunjuk `Weak` anu nunjuk kana alokasi ieu.
    ///
    /// Upami `self` didamel nganggo [`Weak::new`], atanapi upami teu aya sésana petunjuk anu kuat, ieu bakal balik 0.
    ///
    /// # Accuracy
    ///
    /// Kusabab detil palaksanaan, nilai anu dipulangkeun tiasa pareum ku 1 dina dua arah nalika thread anu sanésna ngamanipulasi `Arc`s atanapi`Lemah` anu nunjuk kana alokasi anu sami.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kusabab urang niténan yén sahenteuna aya hiji panunjuk anu kuat saatos maca itungan lemah, urang terang yén référénsi lemah implisit (aya iraha waé référénsi anu kuat hirup) masih aya nalika urang niténan jumlah anu lemah, sahingga tiasa sacara aman ngiranganana.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Mulih `None` nalika pointer ngagantung sareng teu aya `ArcInner` dialokasikeun, (nyaéta nalika `Weak` ieu diciptakeun ku `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kami ati-ati pikeun *henteu* nyiptakeun rujukan anu nutupan lapangan "data", sabab lapangan tiasa dirobih sakaligus (contona, upami `Arc` pamungkas digugurkeun, kolom data bakal murag dina tempatna).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Balik `true` upami dua `Lemah` nunjuk kana alokasi anu sami (sami sareng [`ptr::eq`]), atanapi upami duanana henteu nunjuk kana alokasi naon (sabab éta diciptakeun ku `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kusabab ieu ngabandingkeun pointer hartosna `Weak::new()` bakal sami, sanaos henteu nunjukkeun alokasi naon waé.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ngabandingkeun `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ngajantenkeun klon pointer `Weak` anu nunjuk kana alokasi anu sami.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Tingali koméntar dina Arc::clone() kunaon ieu santai.
        // Ieu tiasa nganggo fetch_add (teu malire konci) sabab itungan lemah ngan ukur dikonci dimana *teu aya deui* petunjuk lemah anu aya.
        //
        // (Janten urang moal tiasa ngajalankeun kode ieu bisi éta).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Tingali koméntar dina Arc::clone() naha urang ngalakukeun ieu (pikeun mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Nyusunna `Weak<T>` énggal, tanpa ngémutan mémori.
    /// Nelepon [`upgrade`] dina nilai balik sok masihan [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Turunkeun panunjuk `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Henteu nyitak nanaon
    /// drop(foo);        // Nyitak "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Upami urang mendakan yén kami panunjuk lemah anu lemah, maka waktuna pikeun ngangkut data sadayana.Tingali diskusi dina Arc::drop() ngeunaan mesen memori
        //
        // Henteu kedah parios kaayaan anu dikonci didieu, kusabab jumlah anu lemah ngan ukur tiasa dikonci upami aya tepatna salah sahiji lemah, artina penurunan éta saterasna tiasa ngajalankeun ON sésana lemah ref, anu ngan ukur tiasa kajadian saatos konci dileupaskeun.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Kami ngalakukeun spésialisasi ieu didieu, sareng sanés salaku optimalisasi anu langkung umum dina `&T`, sabab upami éta bakal nambihan biaya pikeun sadaya cek kasetaraan dina refs.
/// Kami nganggap yén `Arc`s dipaké pikeun nyimpen nilai ageung, anu lambat diklon, tapi ogé beurat pikeun mariksa kasetaraan, nyababkeun biaya ieu mayar langkung gampang.
///
/// Éta ogé langkung kamungkinan ngagaduhan dua klon `Arc`, anu nunjuk kana nilai anu sami, tibatan dua `&T`s.
///
/// Urang ngan ukur tiasa ngalakukeun ieu nalika `T: Eq` salaku `PartialEq` panginten tiasa ngahaja teu pikaresepeun.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Sarua pikeun dua `Arc`s.
    ///
    /// Dua `Arc` sami upami nilai jero na sami, bahkan upami disimpen dina alokasi anu béda.
    ///
    /// Mun `T` ogé implements `Eq` (implying reflexivity sarua), dua `Arc`s yen titik ka alokasi sarua sok sarua.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ketimpangan pikeun dua `Arc`s.
    ///
    /// Dua `Arc` henteu sami upami nilai batinna henteu sami.
    ///
    /// Upami `T` ogé nerapkeun `Eq` (nunjukkeun réfléktivitas sasaruaan), dua `Arc`s anu nunjuk kana nilai anu sami henteu pernah sami.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Babandingan parsial pikeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `partial_cmp()` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kurang-tibatan ngabandingkeun pikeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `<` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Kurang atawa sarua jeung' ngabandingkeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `<=` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Babandingan anu langkung saé pikeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `>` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Langkung hébat atanapi sami' ngabandingkeun pikeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `>=` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Babandingan pikeun dua `Arc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `cmp()` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Nyiptakeun `Arc<T>` énggal, kalayan nilai `Default` pikeun `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Alokkeun sapotong anu diitung-rujukan sareng eusian ku ngempelkeun barang-barang `v`'s.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Alokasi `str` anu diitung rujukan sareng nyalin `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Alokasi `str` anu diitung rujukan sareng nyalin `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Mindahkeun objék buleud kana alokasi anu diitung-anyar.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alokasikeun sapotong anu diitung-rujukan sareng ngalihkeun barang-barang `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Ngidinan Vec ngosongkeun ingetanana, tapi henteu ngancurkeun eusina
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Nyandak unggal unsur dina `Iterator` teras ngumpulkeun kana `Arc<[T]>`.
    ///
    /// # Karakteristik kinerja
    ///
    /// ## Kasus umum
    ///
    /// Dina kasus anu umum, ngempelkeun kana `Arc<[T]>` dilakukeun ku mimitina ngempelkeun kana `Vec<T>`.Nyaéta, nalika nyerat kieu:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ieu kalakuanana siga urang nulis:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan alokasi munggaran kajantenan di dieu.
    ///     .into(); // Alokasi kadua pikeun `Arc<[T]>` kajantenan di dieu.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ieu bakal nyayogikeun sababaraha kali diperyogikeun pikeun ngawangun `Vec<T>` teras éta bakal masihan sakali pikeun ngarobah `Vec<T>` kana `Arc<[T]>`.
    ///
    ///
    /// ## Iterators tina panjangna dipikanyaho
    ///
    /// Nalika `Iterator` anjeun ngalaksanakeun `TrustedLen` sareng ukuran anu pas, alokasi tunggal bakal dilakukeun pikeun `Arc<[T]>`.Salaku conto:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Ngan ukur alokasi anu kajantenan di dieu.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spésialisasi trait dianggo pikeun ngumpulkeun kana `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ieu kasus pikeun iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Kaamanan: Urang kedah mastikeun yén iterator ngagaduhan panjang anu pasti sareng urang gaduh.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Turun deui kana palaksanaan normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Kéngingkeun offset dina `ArcInner` kanggo muatan dina hiji poin.
///
/// # Safety
///
/// Penunjuk kedah nunjuk ka (sareng ngagaduhan metadata anu sah pikeun) conto T anu saacanna sah, tapi T diidinan turun.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Align nilai unsized kana tungtung ArcInner.
    // Kusabab RcBox nyaéta repr(C), éta bakal janten lapangan terakhir dina mémori.
    // SAFETY: kumargi hiji-hijina jinis unsized mungkin nyaéta keureut, objék trait,
    // sareng jinis eksternal, sarat kaamanan input ayeuna cukup pikeun nyayogikeun syarat align_of_val_raw;ieu mangrupa jéntré palaksanaan bahasa anu teu meunang relied kana luar tina std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}