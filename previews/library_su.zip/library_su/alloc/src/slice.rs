//! Pintonan saukuran dinamis kana sekuen anu caket, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Irisan mangrupikeun pandangan kana blok mémori anu diwakilan salaku panunjuk sareng panjang.
//!
//! ```
//! // ngiris Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coercing hiji Asép Sunandar Sunarya kana nyiksikan
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Irisan tiasa dimutasi atanapi dibagi.
//! Jenis keureutan anu dibagi nyaéta `&[T]`, sedengkeun jinis keureut anu tiasa dirobih nyaéta `&mut [T]`, dimana `T` ngagambarkeun jinis unsur.
//! Salaku conto, anjeun tiasa mutasi blok mémori anu keureutan anu tiasa ditunjuk nunjuk ka:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ieu sababaraha hal anu ngandung modul ieu:
//!
//! ## Structs
//!
//! Aya sababaraha léngkah anu gunana pikeun keureut, sapertos [`Iter`], anu ngagambarkeun iterasi dina sapotong.
//!
//! ## Palaksanaan Trait
//!
//! Aya sababaraha palaksanaan traits umum pikeun keureut.Sababaraha conto diantarana:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], kanggo keureut anu jinis elemen na [`Eq`] atanapi [`Ord`].
//! * [`Hash`] - pikeun keureut anu tipe unsur nyaéta [`Hash`].
//!
//! ## Iteration
//!
//! Irisan nerapkeun `IntoIterator`.Iterator ngahasilkeun rujukan pikeun elemen keureut.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Irisan anu tiasa dirobih ngahasilkeun rujukan anu tiasa dirobih pikeun unsur-unsur:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iterator ieu ngahasilkeun référénsi anu tiasa dirobih kana unsur-unsur irisan, janten sedengkeun jinis unsur tina potongan nyaéta `i32`, jenis elemen tina iterator nyaéta `&mut i32`.
//!
//!
//! * [`.iter`] sareng [`.iter_mut`] mangrupikeun metode anu jelas pikeun balikkeun iterator standar.
//! * Métode salajengna anu ngulang deui nyaéta [`.split`], [`.splitn`], [`.chunks`], [`.windows`] sareng seueur deui.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Seueur panggunaan dina modul ieu ngan ukur dianggo dina konfigurasi tés.
// Éta langkung bersih pikeun mareuman peringatan anu henteu dianggo tibatan ngalereskeunana.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Metode penyuluhan keureutan dasar
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) diperyogikeun pikeun palaksanaan makro `vec!` nalika uji coba NB, tingali modul `hack` dina file ieu pikeun langkung jelasna.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) diperyogikeun pikeun palaksanaan `Vec::clone` salami uji coba NB, tingali modul `hack` dina file ieu pikeun langkung jelasna.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Kalayan cfg(test) `impl [T]` henteu sayogi, tilu fungsi ieu saleresna metode anu aya dina `impl [T]` tapi henteu dina `core::slice::SliceExt`, urang kedah nyayogikeun fungsi-fungsi ieu pikeun uji `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Kami henteu kedah nambihan atribut inline pikeun ieu kusabab ieu dianggo dina makro `vec!` seuseueurna sareng nyababkeun régrési parfum.
    // Tingali #71204 pikeun hasil diskusi sareng perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // barang ditandaan diinisialisasi dina loop di handap
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) dipikabutuh pikeun LLVM ngaleupaskeun cék wates sareng ngagaduhan codegen langkung saé tibatan pos.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // Vék dialokasikeun sareng diinisialisasi di luhur sahenteuna ieu panjang.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // dialokasikeun di luhur kalayan kapasitas `s`, sareng inisialisasi ka `s.len()` dina ptr::copy_to_non_overlapping di handap.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Nyortir keureutan.
    ///
    /// Urut ieu stabil (nyaéta henteu nyetél ulang unsur anu sami) sareng *O*(*n*\*log(* n*))-kasus anu paling parah.
    ///
    /// Nalika lumaku, asihan henteu stabil langkung dipikaresep sabab umumna langkung gancang tibatan asihan stabil sareng éta henteu ngaalokasikeun mémori bantu.
    /// Tingali [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna mangrupikeun adaptif, iterative merge sortir anu diideuan ku [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Éta dirarancang janten gancang pisan dina kasus dimana irisanna ampir diurutkeun, atanapi diwangun ku dua atanapi sababaraha urutan berurutan anu dikonsep hiji-hiji.
    ///
    ///
    /// Ogé, éta nyayogikeun panyimpenan samentawis satengah ukuran `self`, tapi pikeun keureutan pondok, sisipan sisipan anu henteu nyayogikeun dianggo gantina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Nyortir keureutan ku fungsi komparator.
    ///
    /// Urut ieu stabil (nyaéta henteu nyetél ulang unsur anu sami) sareng *O*(*n*\*log(* n*))-kasus anu paling parah.
    ///
    /// Fungsi komparator kedah ngartikeun total susunan unsur-unsur dina potongan.Upami mesen henteu total, urutan unsur henteu ditangtoskeun.
    /// Pesenan mangrupikeun urutan total upami éta (pikeun sadaya `a`, `b` sareng `c`):
    ///
    /// * total sareng antisymmetric: persis salah sahiji `a < b`, `a == b` atanapi `a > b` leres, sareng
    /// * transitif, `a < b` sareng `b < c` ngakibatkeun `a < c`.Sarua kedah tahan pikeun `==` sareng `>`.
    ///
    /// Salaku conto, nalika [`f64`] henteu nerapkeun [`Ord`] kusabab `NaN != NaN`, urang tiasa nganggo `partial_cmp` salaku fungsi sortir urang nalika urang terang keureutna henteu ngandung `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Nalika lumaku, asihan henteu stabil langkung dipikaresep sabab umumna langkung gancang tibatan asihan stabil sareng éta henteu ngaalokasikeun mémori bantu.
    /// Tingali [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna mangrupikeun adaptif, iterative merge sortir anu diideuan ku [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Éta dirarancang janten gancang pisan dina kasus dimana irisanna ampir diurutkeun, atanapi diwangun ku dua atanapi sababaraha urutan berurutan anu dikonsep hiji-hiji.
    ///
    /// Ogé, éta nyayogikeun panyimpenan samentawis satengah ukuran `self`, tapi pikeun keureutan pondok, sisipan sisipan anu henteu nyayogikeun dianggo gantina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // asihan tibalik
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Susun keureutan ku fungsi ékstraksi konci.
    ///
    /// Urut ieu stabil (nyaéta henteu nyetél ulang unsur anu sami) sareng *O*(*m*\* * n *\* log(*n*))-kasus anu paling parah, dimana fungsi konci na *O*(*m*).
    ///
    /// Pikeun fungsi konci anu mahal (mis
    /// fungsi anu sanés aksés sipat saderhana atanapi operasi dasar), [`sort_by_cached_key`](slice::sort_by_cached_key) sigana bakal langkung gancang, sabab henteu ngeusian konci elemen.
    ///
    ///
    /// Nalika lumaku, asihan henteu stabil langkung dipikaresep sabab umumna langkung gancang tibatan asihan stabil sareng éta henteu ngaalokasikeun mémori bantu.
    /// Tingali [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna mangrupikeun adaptif, iterative merge sortir anu diideuan ku [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Éta dirarancang janten gancang pisan dina kasus dimana irisanna ampir diurutkeun, atanapi diwangun ku dua atanapi sababaraha urutan berurutan anu dikonsep hiji-hiji.
    ///
    /// Ogé, éta nyayogikeun panyimpenan samentawis satengah ukuran `self`, tapi pikeun keureutan pondok, sisipan sisipan anu henteu nyayogikeun dianggo gantina.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Susun keureutan ku fungsi ékstraksi konci.
    ///
    /// Salila asihan, fungsi konci disebatna ngan sakali per unsur.
    ///
    /// Urut ieu stabil (nyaéta henteu nyetél ulang unsur anu sami) sareng *O*(*m*\* * n *+* n *\* log(*n*))-case awon, dimana fungsi konci na *O*(*m*) .
    ///
    /// Pikeun fungsi konci saderhana (contona, fungsi anu aksés properti atanapi operasi dasar), [`sort_by_key`](slice::sort_by_key) sigana bakal langkung gancang.
    ///
    /// # Palaksanaan ayeuna
    ///
    /// Algoritma ayeuna dumasar kana [pattern-defeating quicksort][pdqsort] ku Orson Peters, anu ngahijikeun kasus rata-rata gancang tina quicksort acak sareng kasus paling parah tina heapsort, nalika ngahontal waktos linier dina keureut kalayan pola anu tangtu.
    /// Éta ngagunakeun sababaraha acak pikeun nyingkahan kasus degenerate, tapi ku seed tetep pikeun salawasna nyayogikeun perilaku deterministik.
    ///
    /// Dina kasus anu paling parah, algoritma nyebarkeun panyimpenan samentawis dina `Vec<(K, usize)>` panjang irisan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Pembantu makro pikeun ngaindeks vector urang ku jinis anu pangleutikna, pikeun ngirangan alokasi.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Unsur-unsur `indices` unik, sabab diindéks, janten naon waé anu stabil bakal aya hubunganana sareng keureutan aslina.
                // Kami nganggo `sort_unstable` didieu sabab meryogikeun kirang alokasi memori.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Nyalin `self` kana `Vec` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Di dieu, `s` sareng `x` tiasa dirobih sacara mandiri.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Nyalin `self` kana `Vec` énggal sareng alokasi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Di dieu, `s` sareng `x` tiasa dirobih sacara mandiri.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, tingali modul `hack` dina file ieu pikeun langkung jelasna.
        hack::to_vec(self, alloc)
    }

    /// Ngarobih `self` kana vector tanpa klon atanapi alokasi.
    ///
    /// Hasilna vector tiasa dirobih deui kana kotak ngalangkungan `Vec<T>Metoda `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` teu tiasa dianggo deui sabab parantos dirobih janten `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, tingali modul `hack` dina file ieu pikeun langkung jelasna.
        hack::into_vec(self)
    }

    /// Nyiptakeun vector ku ngulang deui keureutan `n` kali.
    ///
    /// # Panics
    ///
    /// Fungsi ieu bakal panic upami kapasitasna bakal ngabahekeun.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic saatos ngabahekeun:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Upami `n` langkung ageung tibatan enol, éta tiasa dibagi jadi `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` nyaéta nomer anu diwakilan ku '1' paling kénca tina `n`, sareng `rem` mangrupikeun bagian sésana tina `n`.
        //
        //

        // Ngagunakeun `Vec` pikeun ngaksés `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` pangulangan dilakukeun ku dua kali `buf` expn`-kali.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Upami `m > 0`, aya sésa bit dugi ka '1' paling kénca.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ngagaduhan kapasitas `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) pangulangan dilakukeun ku nyalin pangulangan `rem` anu mimitina tina `buf` sorangan.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ieu non-tindih saprak `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` sarua jeung `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens sapotong `T` kana nilai `Self::Output` tunggal.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens sapotong `T` kana nilai `Self::Output` tunggal, nempatkeun SEPARATOR masihan di antara masing-masing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens sapotong `T` kana nilai `Self::Output` tunggal, nempatkeun SEPARATOR masihan di antara masing-masing.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Balikkeun vector anu ngandung salinan irisan ieu dimana unggal bait dipetakeun kana sarimbag na kasus luhur ASCII.
    ///
    ///
    /// hurup ASCII 'a' mun 'z' anu dipetakeun kana 'A' mun 'Z', tapi hurup non-ASCII anu unchanged.
    ///
    /// Pikeun huruf besar nilai di tempatna, anggo [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Balikkeun vector anu ngandung salinan potongan ieu dimana unggal bait dipetakeun kana sarupaning kasus handap ASCII.
    ///
    ///
    /// Huruf ASCII 'A' dugi 'Z' dipetakeun ka 'a' dugi 'z', tapi hurup sanés ASCII henteu robih.
    ///
    /// Pikeun ngaleutikan nilai dina tempatna, anggo [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Extension traits pikeun keureut tina jinis data khusus
////////////////////////////////////////////////////////////////////////////////

/// Pembantu trait pikeun [`[T]: : concat`](keureut::concat).
///
/// Note: parameter tipe `Item` henteu dianggo dina trait ieu, tapi ngamungkinkeun impls janten langkung umum.
/// Tanpa éta, urang meunang kasalahan ieu:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Ieu kusabab aya tiasa aya jinis `V` sareng sababaraha `Borrow<[_]>` impls, sapertos sababaraha jinis `T` bakal diterapkeun:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Jenis anu dihasilkeun saatos concatenation
    type Output;

    /// Palaksanaan [`[T]: : concat`](keureutan::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Pembantu trait kanggo [`[T]: : gabung`](keureutan::gabung)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Jenis anu dihasilkeun saatos concatenation
    type Output;

    /// Palaksanaan [`[T]: : gabung`](keureutan::gabung)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Palaksanaan trait standar pikeun keureut
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // teundeun naon waé dina udagan anu moal ditimpa
        target.truncate(self.len());

        // target.len <= self.len kusabab truncate di luhur, janten keureut didieu sok di-bounds.
        //
        let (init, tail) = self.split_at(target.len());

        // pake deui nilai anu aya allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Nyelapkeun `v[0]` kana urutan `v[1..]` anu tos diurut sahingga sadayana `v[..]` janten diurut.
///
/// Ieu subroutine integral tina asupan sisipan.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Aya tilu cara pikeun ngalaksanakeun sisipan di dieu:
            //
            // 1. Tukeur elemen anu caket dugi anu munggaran dugi ka tujuan akhirna.
            //    Nanging, ku cara ieu urang nyalin data sakitar langkung ti anu diperyogikeun.
            //    Upami elemen mangrupikeun struktur ageung (mahal pikeun disalin), cara ieu bakal lambat.
            //
            // 2. Iterate dugi ka tempat anu leres pikeun unsur anu munggaran dipendakan.
            // Teras ngalihkeun unsur-unsur anu ngagentoskeun pikeun masihan rohangan sareng tungtungna nempatkeun kana liang sésana.
            // Ieu metoda anu saé.
            //
            // 3. Salin unsur kahiji kana variabel samentawis.Iterate dugi ka tempat anu pas pikeun éta dipanggihan.
            // Nalika urang ngiringan, salin unggal unsur anu dilangkungan kana slot anu sateuacanna.
            // Akhirna, salin data tina variabel samentawis kana liang sésana.
            // Cara ieu saé pisan.
            // Tolok ukur nunjukkeun performa anu rada langkung saé tibatan ku padika ka-2.
            //
            // Sadaya padika ditandaan, sareng ka-3 nunjukkeun hasil anu pangsaéna.Janten urang milih anu éta.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Kaayaan panengah tina prosés sisipan sok dilacak ku `hole`, anu ngagaduhan dua tujuan:
            // 1. Ngajaga integritas `v` ti panics dina `is_less`.
            // 2. Ngeusian liang sésana dina `v` tungtungna.
            //
            // Kaamanan Panic:
            //
            // Upami `is_less` panics iraha waé nalika prosés, `hole` bakal turun sareng ngeusian liang dina `v` ku `tmp`, sahingga mastikeun yén `v` masih nyepeng unggal objék anu mimitina dicekel persis sakali.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` bakal turun teras nyalin `tmp` kana liang sésana dina `v`.
        }
    }

    // Nalika turun, salinan tina `src` kana `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Merges non-turunna ngalir `v[..mid]` na `v[mid..]` maké `buf` salaku gudang samentara, sarta toko hasil kana `v[..]`.
///
/// # Safety
///
/// Dua keureut kudu jadi non-kosong jeung `mid` kudu bounds.
/// Buffer `buf` kedah cekap panjang pikeun nyepeng salinan irisan anu langkung pondok.
/// Ogé, `T` kedahna henteu janten ukuran ukuran enol.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Prosés ngahiji mimiti nyalin langkung pondok tina `buf`.
    // Teras ngambah lumpat anu nembé disalin sareng jangka panjang anu langkung maju (atanapi mundur), ngabandingkeun unsur-unsur anu teu nganggo salajengna sareng nyalin anu langkung alit (atanapi langkung ageung) kana `v`.
    //
    // Pas ngajalankeun anu pondok langkung seueur dikonsumsi, prosés na parantos réngsé.Upami jalan anu langkung lami dikonsumsi heula, maka urang kedah nyalin naon waé anu tinggal tina jalan anu langkung pondok kana liang sésana dina `v`.
    //
    // Kaayaan panengah tina prosés sok dilacak ku `hole`, anu ngagaduhan dua tujuan:
    // 1. Ngajaga integritas `v` ti panics dina `is_less`.
    // 2. Ngeusian liang sésana dina `v` upami ngajalankeun anu langkung lami dikonsumsi heula.
    //
    // Kaamanan Panic:
    //
    // Mun `is_less` panics iraha wae titik salila prosés, `hole` bakal meunang turun sarta eusian liang di `v` jeung rentang unconsumed di `buf`, sahingga mastikeun yén `v` masih nyepeng unggal obyek eta mimitina diayakeun persis sakali.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Larian kénca langkung pondok.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Mimitina, petunjuk ieu nunjuk kana awal susunanana.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Meakeun sisi anu langkung alit.
            // Upami sami, langkung resep lumpat kénca pikeun ngajaga stabilitas.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Lumpat ka katuhu langkung pondok.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Mimitina, petunjuk ieu nunjuk ka tungtung tungtung susunanana.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Meakeun sisi anu langkung ageung.
            // Upami sami, langkung resep ngaji anu leres pikeun ngajaga stabilitas.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Tungtungna, `hole` bakal turun.
    // Upami ngajalankeun anu langkung pondok henteu dikonsumsi sapinuhna, naon waé sésa-sésa na ayeuna bakal disalin kana liang `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Nalika turun, salin sauntuyan `start..end` kana `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` sanés jinisna ukuran nol, janten teu kunanaon pikeun ngabagi ku ukuran na.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Urut ngahijina ieu nginjeum sababaraha (tapi henteu sadayana) ideu ti TimSort, anu dijelaskeun sacara rinci [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritma nunjukkeun pasti turunna sacara turun-tumurun sareng teu turun-turunna, anu disebut jalan alami.Aya tumpukan lumpat anu ngantosan teu acan tiasa digabung.
/// Unggal lumpat anu nembé kapendak didorong kana tumpukan, teras sababaraha pasang lumpat anu caket digabungkeun dugi ka dua invarian ieu wareg:
///
/// 1. pikeun unggal `i` dina `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. pikeun unggal `i` dina `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Para invariant mastikeun yén total waktos ngajalankeun nyaéta *O*(*n*\*log(* n*))-kasus anu paling parah.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Irisan dugi ka panjang ieu tiasa diurut nganggo sisipan sisipan.
    const MAX_INSERTION: usize = 20;
    // Jalan anu pondok pisan diperpanjang nganggo sisipan sisipan dugi ka paling henteu seueur ieu elemen.
    const MIN_RUN: usize = 10;

    // Asihan henteu ngagaduhan paripolah anu bermakna pikeun jinis ukuran nol.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Asép pondok tiasa diurut di tempat ngalangkungan sisipan pikeun nyingkahan alokasi.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Alokasi panyangga pikeun dianggo salaku mémori goresan.Kami nyimpen panjang 0 sahingga urang tiasa nyimpen salinan deet tina `v` tanpa nyayogikeun dokter anu ngajalankeun salinan upami `is_less` panics.
    //
    // Nalika ngahijikeun dua jalan anu diurutkeun, panyangga ieu nyayogikeun salinan tina jalan anu langkung pondok, anu bakal ngagaduhan panjang paling `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Dina raraga ngaidentipikasi jalan alami di `v`, urang ngalangkungan éta ka tukang.
    // Éta sigana siga kaputusan anu anéh, tapi pertimbangkeun kanyataan yén ngahijina langkung sering angkat ka arah anu lepat (forwards).
    // Numutkeun patokan, ngahijikeun ka payun rada gancang tibatan ngahiji ka tukang.
    // Pikeun nyimpulkeun, ngaidéntifikasi jalan ku ngalangkungan mundur ningkatkeun kinerja.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Milarian jalan alami salajengna, sareng balikeun deui upami éta turun leres.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Lebetkeun sababaraha unsur deui kana jangka upami pondok teuing.
        // Asihan sisipan langkung gancang tibatan ngahiji dina urutan pondok, janten ieu sacara nyata ningkatkeun kinerja.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Dorong lumpat ieu kana tumpukan.
        runs.push(Run { start, len: end - start });
        end = start;

        // Ngagabungkeun sababaraha pasang lumpat anu caket pikeun nyugemakeun anu teu kawajiban.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Tungtungna, persis hiji ngaji kedah tetep dina tumpukan.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Nalungtik tumpukan lumpat sareng ngaidentipikasi pasangan lumpat salajengna pikeun ngagabung.
    // Leuwih husus, upami `Some(r)` geus balik, éta hartosna `runs[r]` na `runs[r + 1]` kudu dihijikeun salajengna.
    // Upami algoritma kedah neraskeun ngawangun lumpat énggal, `None` bakal dipulangkeun.
    //
    // TimSort terkenal kana implementasi buggy na, sakumaha anu dijelaskeun di dieu:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Intina carita ieu nyaéta: urang kedah ngalaksanakeun panyawat dina opat jalan luhur dina tumpukan.
    // Maksakeun aranjeunna dina tilu waé anu sa luhur henteu cekap pikeun mastikeun yén anu ngondang tetep bakal ngajalankeun *sadayana* dina tumpukan.
    //
    // Fungsi ieu leres mariksa invariants pikeun opat larian top.
    // Salaku tambahan, upami ngajalankeun luhur dimimitian dina indéks 0, éta bakal salawasna nungtut operasi ngagabung dugi tumpukan éta lengkep runtuh, dina raraga ngalengkepan diurutkeun.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}