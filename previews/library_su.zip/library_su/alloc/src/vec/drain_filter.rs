use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iterator anu nganggo panutupanana pikeun nangtoskeun naha unsur kedah dipiceun.
///
/// Struktur ieu didamel ku [`Vec::drain_filter`].
/// Tingali dokuméntasi na pikeun langkung seueur.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Indéks barang anu bakal dipariksa ku panggero salajengna ka `next`.
    pub(super) idx: usize,
    /// Jumlah barang anu parantos dikuras (removed) dugi ka ayeuna.
    pub(super) del: usize,
    /// Panjang aslina `vec` sateuacan dikuras.
    pub(super) old_len: usize,
    /// Prédikat tés saringan.
    pub(super) pred: F,
    /// Bendéra anu nunjukkeun panic parantos kajantenan dina prédikat uji saringan.
    /// Ieu dianggo salaku isarat dina palaksanaan serelek pikeun nyegah konsumsi sesa `DrainFilter`.
    /// Barang naon waé anu teu diolah bakal dibalikkeun deui dina `vec`, tapi henteu barang salajengna bakal lungsur atanapi diuji ku prédikat filter.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Mulihkeun rujukan ka alokator kaayaan.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Anyarkeun indéks *saatos* prédikat disebat.
                // Upami indéks diénggalan sateuacanna sareng predikat panics, unsur dina indéks ieu bakal bocor.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ieu kaayaan anu cukup kacau, sareng teu leres-leres hal anu leres anu kedah dilakukeun.
                        // Kami henteu hoyong teras-terasan ngusahakeun `pred`, janten kami ngan ukur mundur sadayana elemen anu teu diproses sareng nyarioskeun vektor yén éta masih aya.
                        //
                        // Backshift diperyogikeun pikeun nyegah lungsur dua kali tina barang anu terakhir hasil dikeringkeun sateuacan panic dina prédikat.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Usaha pikeun nyéépkeun sésa-sésa unsur sanésna upami saringan predikat teu acan panik.
        // Ieu gé backshift sagala elemen sésana naha urang geus geus panik atawa lamun konsumsi dieu panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}