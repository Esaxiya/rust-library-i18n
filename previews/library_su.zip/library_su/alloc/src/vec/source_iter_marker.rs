use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Spésialisasi kamajuan pikeun ngumpulkeun hiji pipa iterator kana Vec bari reusing alokasi sumber, nyaéta
/// ngajalankeun pipa dina tempatna.
///
/// Indung SourceIter trait diperyogikeun pikeun fungsi ngahususkeun pikeun ngaksés alokasi anu kedah dianggo deui.
/// Tapi henteu cekap pikeun spésialisasi janten valid.
/// Tingali tambihan tambihan dina impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-internal SourceIter/InPlaceIterable traits ngan dilaksanakeun ku ranté Adaptor <Adapter<Adapter<IntoIter>>> (sadayana kagungan core/std).
// Batesan tambahan dina palaksanaan adaptor (saluareun `impl<I: Trait> Trait for Adapter<I>`) ngan ukur gumantung kana traits anu parantos ditandaan salaku spesialisasi traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. spidol henteu gumantung kana umur hirup tina jinis anu disayogikeun ku pangguna.Modulo liang Salin, anu parantos diandelkeun sababaraha spésialisasi sanés.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Syarat tambahan anu teu tiasa dikedalkeun via trait bounds.Kami ngandelkeun const eval tibatan:
        // a) moal ZSTs sakumaha pasti bakal euweuh alokasi pikeun maké deui sarta pointer arithmetic bakal panic b) ukuranana cocok jadi diperlukeun ku Alloc kontrak c) alignments cocog sakumaha diperlukeun ku kontrak Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback kana palaksanaan langkung umum
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // anggo try-fold ti saprak
        // - éta ngajantenkeun langkung saé pikeun sababaraha adaptor iterator
        // - teu sapertos paling metode pangulangan internal, éta ngan ukur butuh &mut
        // - éta ngamungkinkeun urang ngaitkeun pointer nyerat kana jero na sareng nyandak deui tungtungna
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // Iteration hasil, ulah neundeun sirah
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // parios naha kontrak SourceIter dijantenkeun peringatan: upami henteu, maka kami moal dugi ka titik ieu
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // cek kontrak InPlaceIterable.Ieu ngan ukur tiasa upami iterator maju panunjuk sumber pisan.
        // Upami éta nganggo aksés anu teu dipariksa via TrustedRandomAccess maka sumber pointer bakal tetep dina posisi awalna sareng kami moal tiasa nganggo salaku rujukan
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // teundeun nilai sésana dina buntut sumberna tapi cegah jatah alokasi éta nyalira sakali IntoIter kaluar tina ruang lingkup upami turunna panics maka kami ogé ngabocorkeun unsur naon waé anu dikumpulkeun kana dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontrak InPlaceIterable moal tiasa diverifikasi persis di dieu kumargi try_fold gaduh rujukan eksklusif pikeun sumber pointer anu tiasa urang pigawé nyaéta mariksa naha éta masih aya dina jangkauan
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}