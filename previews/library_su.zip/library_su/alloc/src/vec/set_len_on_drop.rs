// Atur panjang vektor nalika nilai `SetLenOnDrop` kaluar tina ruang lingkup.
//
// Ideu na nyaéta: Widang panjang dina SetLenOnDrop mangrupikeun variabel lokal anu bakal ditingali ku pangoptimal henteu alias sareng toko mana waé ngalangkungan panunjuk data Vec.
// Ieu mangrupikeun jalan pikeun masalah analisis alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}