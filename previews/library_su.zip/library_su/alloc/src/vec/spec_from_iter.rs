use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Spésialisasi trait dianggo pikeun Vec::from_iter
///
/// ## Grafik delegasi:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Pasualan umum nyaéta ngalirkeun vector kana fungsi anu langsung dikumpulkeun deui kana vector.
        // Urang tiasa circuit pondok ieu upami IntoIter teu acan maju pisan.
        // Upami parantos maju Urang ogé tiasa nganggo deui mémori sareng mindahkeun data ka payun.
        // Tapi urang ngan ukur ngalakukeun éta nalika Vec anu dihasilkeun moal ngagaduhan kapasitas langkung henteu kapaké tibatan nyiptakeunana ngalangkungan implementasi FromIterator anu umum.
        //
        // watesan nu teu ketat diperlukeun salaku kabiasaan alokasi Vec urang téh ngahaja unspecified.
        // Tapi mangrupakeun pilihan konservatif.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // kedah utusan ka spec_extend() kumargi extend() nyalira utusan ka spec_from kanggo Vecs kosong
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ieu utilizes `iterator.as_slice().to_vec()` saprak spec_extend kudu nyokot léngkah deui alesan ngeunaan final panjangna kapasitas + sahingga ngalakukeun leuwih karya.
// `to_vec()` langsung nyayogikeun jumlah anu leres sareng ngeusian persis.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): kalayan cfg(test) metoda `[T]::to_vec` alami, anu diperyogikeun pikeun watesan metode ieu, henteu sayogi.
    // Sabalikna nganggo fungsi `slice::to_vec` anu ngan sayogi ku cfg(test) NB tingali modul slice::hack dina slice.rs kanggo langkung seueur inpormasi
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}