//! Utiliti pikeun pormat sareng nyetak `String`s.
//!
//! Modul ieu ngandung dukungan runtime pikeun panyambungan sintaksis [`format!`].
//! Makro ieu dilaksanakeun dina panyusun pikeun ngaluarkeun telepon kana modul ieu dina raraga pormat argumén dina runtime kana senar.
//!
//! # Usage
//!
//! Makro [`format!`] dimaksudkeun janten akrab pikeun anu asalna tina fungsi C's `printf`/`fprintf` atanapi fungsi Python's `str.format`.
//!
//! Sababaraha conto penyuluhan [`format!`] nyaéta:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" kalayan nol ngarah
//! ```
//!
//! Tina ieu, anjeun tiasa ningali yén argumén anu munggaran nyaéta senar format.Diperlukan ku panyusun pikeun ieu janten literal literal;éta moal tiasa janten variabel anu diliwatan (dina raraga ngalakukeun validitas mariksa).
//! Kompilator teras bakal ngébréhkeun string format sareng nangtoskeun naha daptar argumén anu disayogikeun cocog pikeun ngalirkeun kana string format ieu.
//!
//! Pikeun ngarobih hiji nilai kana senar, anggo metode [`to_string`].Ieu bakal nganggo [`Display`] pormat trait.
//!
//! ## Parameter posisional
//!
//! Unggal arguméntasi pormat diidinkeun pikeun nunjukkeun argumén mana anu dirujuk, sareng upami disingkirkeun dianggap "the next argument".
//! Salaku conto, format string `{} {} {}` bakal nyandak tilu parameter, sareng éta bakal diformat dina urutan anu sami sakumaha anu parantos dipasihkeun.
//! String format `{2} {1} {0}`, Nanging, bakal pormat argumen dina urutan tibalik.
//!
//! Hal-hal tiasa janten sesah sakedik upami anjeun ngamimitian ngahijikeun dua jinis spésifis posisional.Spesifikasina "next argument" tiasa dianggap salaku iterator dina argumen.
//! Unggal katingali spésipik "next argument", iteratorna maju.Ieu ngakibatkeun tingkah laku sapertos kieu:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iterator internal kana argumen henteu acan maju ku nalika `{}` munggaran ditingali, janten nyitak argumén anu munggaran.Teras dugi kana `{}` kadua, iterator parantos maju ka argumen anu kadua.
//! Intina, parameter anu sacara éksplisit namina argumenna henteu mangaruhan parameter anu henteu namina argumen dina hal spésifis posisional.
//!
//! String format diperyogikeun pikeun nganggo sadayana arguméntasina, upami henteu éta mangrupikeun kasalahan kompilasi-waktos.Anjeun tiasa ningali kana argumen anu sami langkung ti sakali dina senar format.
//!
//! ## Parameter anu namina
//!
//! Rust sorangan henteu ngagaduhan Python sami sareng parameter anu dingaranan kana fungsi, tapi makro [`format!`] mangrupikeun panyambungan sintaksis anu ngamungkinkeun ngungkit parameter anu dingaranan.
//! Paraméter anu namina didaptarkeun dina tungtung daptar argumen sareng gaduh sintaksis:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Salaku conto, ungkapan [`format!`] ieu sadayana nganggo argumen anu dingaranan:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Éta henteu valid pikeun nempatkeun parameter posisional (anu tanpa nami) saatos bantahan anu ngagaduhan nami.Siga sareng parameter posisional, henteu valid pikeun nyayogikeun parameter anu teu dianggo ku senar format.
//!
//! # Parameter Pormat
//!
//! Unggal argumen anu diformat tiasa dirobih ku sababaraha parameter pormat (pakait sareng `format_spec` dina [the syntax](#syntax)). Parameter ieu mangaruhan perwakilan string tina naon anu diformat.
//!
//! ## Width
//!
//! ```
//! // Sadayana print "Hello x !" ieu
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ieu mangrupikeun parameter pikeun "minimum width" anu kedah dijantenkeun dina format.
//! Upami senar nilai henteu ngeusian seueur karakter ieu, maka padding anu ditangtoskeun ku fill/alignment bakal dianggo pikeun nyandak rohangan anu diperyogikeun (tempo di handap).
//!
//! Nilai pikeun lébar ogé tiasa disayogikeun salaku [`usize`] dina daptar parameter ku nambihan postfix `$`, nunjukkeun yén argumen anu kadua nyaéta [`usize`] anu nunjukkeun lébar.
//!
//! Ngarujuk kana argumen sareng sintaksis dolar henteu mangaruhan loket "next argument", janten biasana mangrupakeun ide anu saé pikeun nuduhkeun argumén dumasar posisi, atanapi nganggo alesan anu dibantah.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakter eusian opsional sareng alignment disayogikeun normal ditéang sareng parameter [`width`](#width).Éta kedah dihartikeun sateuacan `width`, pas saatos `:`.
//! Ieu nunjukkeun yén upami nilai anu diformat langkung alit tibatan `width` sababaraha karakter tambahan bakal dicitak di sakurilingna.
//! Ngeusian mangrupikeun varian ieu pikeun alignment anu béda:
//!
//! * `[fill]<` - argumen na kénca-Blok dina kolom `width`
//! * `[fill]^` - argumenna dijajarkeun tengah-tengah dina kolom `width`
//! * `[fill]>` - argumenna leres-leres di kolom `width`
//!
//! [fill/alignment](#fillalignment) standar pikeun non-angka nyaéta rohangan sareng kénca-Blok.Standar pikeun pormat numerik ogé mangrupikeun karakter luar angkasa tapi nganggo alignment-katuhu.
//! Upami bendera `0` (tempo di handap) dieusian pikeun numerik, maka karakter eusian implisit nyaéta `0`.
//!
//! Catet yén alignment tiasa henteu dilaksanakeun ku sababaraha jinis.Khususna, henteu umum dilaksanakeun pikeun `Debug` trait.
//! Cara anu saé pikeun mastikeun padding dilarapkeun nyaéta pormat input anjeun, teras paskeun string anu dihasilkeun ieu pikeun kéngingkeun kaluaran anjeun:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Halo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Ieu sadayana umbul-umbul ngarobih tingkah paripolah anu pormat.
//!
//! * `+` - Ieu dimaksudkeun pikeun jinis angka sareng nunjukkeun yén tandana kedah teras dicetak.tanda positif anu pernah dicitak sacara standar, jeung tanda négatip ieu ngan dicitak sacara standar pikeun `Signed` trait.
//! Bendéra ieu nunjukkeun yén tanda anu leres (`+` atanapi `-`) kedah teras dicetak.
//! * `-` - Ayeuna henteu dianggo
//! * `#` - Bendéra ieu nunjukkeun yén "alternate" bentuk percetakan kedah dianggo.Bentuk alternatipna nyaéta:
//!     * `#?` - lumayan-nyetak format [`Debug`]
//!     * `#x` - miheulaan argumen ku `0x`
//!     * `#X` - miheulaan argumen ku `0x`
//!     * `#b` - miheulaan argumen ku `0b`
//!     * `#o` - miheulaan argumen ku `0o`
//! * `0` - Ieu digunakeun pikeun nunjukkeun format integer yén padding ka `width` kedah duanana dilakukeun ku karakter `0` ogé kudu sadar kana tanda.
//! A format sapertos `{:08}` bakal ngahasilkeun `00000001` kanggo integer `1`, sedengkeun format anu sami ngahasilkeun `-0000001` kanggo integer `-1`.
//! Perhatoskeun yén vérsi négatip gaduh sakedik enol tibatan vérsi positip.
//!         Catet yén padding enol sok disimpen saatos tanda (upami aya) sareng sateuacan digit.Nalika dianggo sasarengan sareng bandéra `#`, aturan anu sami diterapkeun: padding zeros dilebetkeun saatos awalan tapi sateuacan digit.
//!         Awalan kalebet dina total lébar.
//!
//! ## Precision
//!
//! Pikeun jinis non-numerik, ieu tiasa dianggap "maximum width".
//! Upami senar anu dihasilkeun langkung panjang tibatan lébar ieu, maka éta tiasa dipotong dugi ka seueur karakter ieu sareng yén nilai truncated dipancarkeun ku `fill`, `alignment` sareng `width` anu leres upami parameter na diatur.
//!
//! Pikeun jinis anu teu kapisah, ieu teu dipalire.
//!
//! Pikeun jenis titik ngambang, ieu nunjukkeun sabaraha digit saatos titik decimal kedah dicitak.
//!
//! Aya tilu kamungkinan cara pikeun khususkeun `precision` anu dipikahoyong:
//!
//! 1. Angka `.N` integer:
//!
//!    integer `N` sorangan nyaéta presisi.
//!
//! 2. Angka bilangan bulat atanapi nami dituturkeun ku tanda dolar `.N$`:
//!
//!    pamakéan format *argumen*`N` (anu kedah janten `usize`) salaku precision nu.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` hartosna yén `{...}` ieu aya hubunganana sareng input *dua* format tibatan hiji: input anu munggaran nyepeng presisi `usize`, sareng anu kadua nahan nilai pikeun nyetak.
//!    Catet yén dina hal ieu, upami nganggo string format `{<arg>:<spec>.*}`, maka bagian `<arg>` ngarujuk kana* nilai * pikeun nyetak, sareng `precision` kedah sumping dina input sateuacanna `<arg>`.
//!
//! Salaku conto, ieu nyaéta panggero sadayana nyetak hal anu sami `Hello x is 0.01000`:
//!
//! ```
//! // Halo {arg 0 ("x")} nyaéta {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Halo {arg 1 ("x")} nyaéta {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Halo {arg 0 ("x")} nyaéta {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} nyaéta {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} nyaéta {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Halo {next arg ("x")} nyaéta {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Sedengkeun ieu:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! nyitak tilu perkara béda nyata:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Dina sababaraha basa pamrograman, paripolah fungsi pormat string gumantung kana setélan lokal sistem operasi.
//! Fungsi format anu disayogikeun ku perpustakaan standar Rust's henteu ngagaduhan konsep lokal sareng bakal ngahasilkeun hasil anu sami dina sadaya sistem paduli konfigurasi pangguna.
//!
//! Salaku conto, kode di handap ieu bakal salawasna nyetak `1.5` sanajan sistem lokal nganggo SEPARATOR desimal sanés titik.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Hurup literal `{` na `}` bisa jadi kaasup kana string anu ku harita sareng karakter sarua.Salaku conto, karakter `{` kabur nganggo `{{` sareng karakter `}` kabur nganggo `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Pikeun nyimpulkeun, di dieu anjeun tiasa mendakan tata basa lengkep ngeunaan senar format.
//! Sintaksis pikeun bahasa pormat anu dianggo ditarik tina basa anu sanés, janten henteu kedah teuing alien.Arguméntasi diformat ku sintaksis sapertos Python, hartosna yén argumen dikurilingan ku `{}` tibatan C-like `%`.
//! Tata bahasa saleresna pikeun sintaksis pormat nyaéta:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Dina tata basa di luhur, `text` tiasa waé henteu ngandung `'{'` atanapi `'}'` karakter.
//!
//! # Pormat traits
//!
//! Nalika nyungkeun bantosan diformat ku jinis anu khusus, anjeun leres-leres nyungkeun bantosan pikeun trait khusus.
//! Hal ieu ngamungkinkeun sababaraha jinis saleresna diformat ngalangkungan `{:x}` (sapertos [`i8`] ogé [`isize`]).Pemetaan jinis ayeuna ka traits nyaéta:
//!
//! * *nanaon* ⇒ [`Display`]
//! * `?` [`Debug`]
//! * `x?` ⇒ [`Debug`] kalayan bilangan bulat héksadesimal leutik
//! * `X?` ⇒ [`Debug`] kalayan bilangan bulat héksadesimal-luhur
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` [`UpperExp`]
//!
//! Naon ieu hartosna nyaéta naon waé jenis argumen anu ngalaksanakeun [`fmt::Binary`][`Binary`] trait teras tiasa diformat sareng `{:b}`.Palaksanaan disayogikeun pikeun traits ieu pikeun sajumlah jinis primitif ku perpustakaan standar ogé.
//!
//! Upami teu aya format anu ditangtoskeun (sapertos dina `{}` atanapi `{:6}`), maka format trait anu dianggo nyaéta [`Display`] trait.
//!
//! Nalika nerapkeun format trait pikeun jinis anjeun nyalira, anjeun kedah ngalaksanakeun metode tandatangan:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // jenis custom urang
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jenis anjeun bakal diliwatan salaku rujukan `self`, teras fungsina kedah ngaluarkeun kaluaran kana aliran `f.buf`.Éta dugi ka unggal format trait palaksanaan leres taat kana parameter format anu dipénta.
//! Nilai parameter ieu bakal dibéréndélkeun dina bidang strukturna [`Formatter`].Dina raraga ngabantosan ieu, [`Formatter`] struct ogé nyayogikeun sababaraha metode pembantunya.
//!
//! Salaku tambahan, nilai balik fungsi ieu nyaéta [`fmt::Result`] anu mangrupikeun jinis alias [`Hasil`]`<(),`[`std: : fmt::Error`] `>`.
//! Implementasi pormat kedah mastikeun yén aranjeunna nyebarkeun kasalahan ti [`Formatter`] (contona, nalika nelepon [`write!`]).
//! Nanging, aranjeunna henteu kedah ngical kasalahan deui sacara spurious.
//! Nyaéta, palaksanaan pormat kedah sareng ngan ukur ngabalikeun kasalahan upami [`Formatter`] lolos balikkeun kasalahan.
//! Ieu kusabab, bertentangan sareng naon anu tiasa disarankeun ku tandatangan fungsi, pormat string mangrupikeun operasi anu teu lepat.
//! Pungsi ieu ngan ukur ngahasilkeun hasilna sabab nyerat ka aliran anu aya dina dasarna bakal gagal sareng éta kedah nyayogikeun cara pikeun nyebarkeun kanyataan yén aya kasalahan anu nyadangkeun tumpukan éta.
//!
//! Conto ngalaksanakeun pormat traits sapertosna:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Nilai `f` ngalaksanakeun `Write` trait, anu nyeratna!makro ngarepkeun.
//!         // Catet yén pormat ieu teu malire kana sagala rupa bendera anu disayogikeun pikeun senar pormat.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits anu béda ngamungkinkeun sababaraha bentuk kaluaran anu béda-béda.
//! // Harti format ieu nyaéta nyetak gedena vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hormat bendera pormat ku ngagunakeun metode pembantunya `pad_integral` dina obyék Formatter.
//!         // Tingali dokuméntasi metode pikeun detil, sareng fungsi `pad` tiasa dianggo pikeun senar.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Dua format traits ieu ngagaduhan tujuan anu béda:
//!
//! - [`fmt::Display`][`Display`] panerapan negeskeun yén jinisna tiasa leres-leres diwakilan salaku senar UTF-8 sepanjang waktos.Henteu ** diarepkeun yén sadaya jinis ngalaksanakeun [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] palaksanaan kedah dilaksanakeun pikeun **sadayana** jinis umum.
//!   Kaluaran ilaharna bakal ngawakilan kaayaan internal satia anu mungkin.
//!   Tujuan tina [`Debug`] trait nyaéta pikeun mempermudah debugging kode Rust.Dina kaseueuran kasus, nganggo `#[derive(Debug)]` cekap sareng disarankeun.
//!
//! Sababaraha conto kaluaran ti duanana traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Patali makro
//!
//! Aya sababaraha makro patali dina kulawarga [`format!`].Anu ayeuna dilaksanakeun nyaéta:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ieu sareng [`writeln!`] mangrupikeun dua macros anu dianggo pikeun ngaluarkeun string format kana aliran anu ditangtoskeun.Ieu digunakeun pikeun nyegah alokasi panengah tina senar format sareng langsung nyerat kaluaranana.
//! Dina tiung, fungsi ieu leres-leres nyungkeun fungsi [`write_fmt`] anu ditetepkeun dina [`std::io::Write`] trait.
//! Conto panggunaan nyaéta:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ieu sareng [`println!`] ngaluarkeun kaluaranna ka stdout.Nya kitu sareng makro [`write!`], tujuan makro ieu nyaéta ngahindaran alokasi panengah nalika nyetak kaluaran.Conto panggunaan nyaéta:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makro [`eprint!`] sareng [`eprintln!`] identik sareng [`print!`] sareng [`println!`] masing-masing, kecuali aranjeunna ngaluarkeun kaluaranna ka stderr.
//!
//! ### `format_args!`
//!
//! Ieu makro panasaran anu dipaké pikeun ngalirkeun sacara aman di sakitar obyék opak anu ngajelaskeun senar format.Objek ieu henteu meryogikeun alokasi tumpukan pikeun didamel, sareng éta ngan ukur ngarujuk inpormasi dina tumpukan.
//! Dina hood, sadaya makro anu aya hubunganana dilaksanakeun dina hal ieu.
//! Anu mimiti, sababaraha conto panggunaan nyaéta:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Hasil tina makro [`format_args!`] mangrupikeun nilai jinis [`fmt::Arguments`].
//! Struktur ieu teras tiasa diteruskeun kana fungsi [`write`] sareng [`format`] di jero modul ieu dina urutan ngolah senar format.
//! Tujuan tina makro ieu nyaéta pikeun bahkan langkung ngahambat alokasi panengah nalika kaayaan senar pormat.
//!
//! Salaku conto, perpustakaan logging tiasa nganggo sintaksis pormat standar, tapi sacara internal bakal ngalirkeun struktur ieu dugi ka parantos ditangtoskeun dimana kaluaranana kedahna.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Fungsi `format` nyandak struktur [`Arguments`] sareng mulihkeun string anu diformat hasilna.
///
///
/// Conto [`Arguments`] tiasa didamel nganggo makro [`format_args!`].
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Punten dicatet yén nganggo [`format!`] panginten langkung pikaresep.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}