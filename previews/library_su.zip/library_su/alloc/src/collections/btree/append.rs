use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Nambahkeun sadaya pasangan konci-nilai tina gabungan dua iterator naék, nambahan variabel `length` sapanjang jalan.Anu terakhir mempermudah anu nelepon pikeun nyingkahan kabocoran nalika panangan serelek panik.
    ///
    /// Upami duanana iterator ngahasilkeun konci anu sami, cara ieu muragkeun pasangan tina iterator kénca sareng nambihan pasangan ti iterator katuhu.
    ///
    /// Upami anjeun hoyong tangkal na diturunkeun dina urutan anu naék, sapertos pikeun `BTreeMap`, duanana iterator kedah ngahasilkeun konci dina urutan anu naék, masing-masing langkung ageung tibatan sadaya konci dina tangkal, kalebet tombol naon waé anu parantos aya dina tangkal saatos lebet.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Kami siap ngagabungkeun `left` sareng `right` kana sekuen anu diurutkeun dina waktos linier.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Samentawis éta, urang ngawangun tangkal tina sekuen anu diurutkeun dina waktos linier.
        self.bulk_push(iter, length)
    }

    /// Nyorong sadaya pasangan nilai-konci kana tungtung tangkal, nambihan variabel `length` sapanjang jalan.
    /// Anu terakhir mempermudah anu nelepon pikeun nyingkahan kabocoran nalika iteratorna panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Campur sadaya pasangan konci-nilai, ngadorong kana simpul dina tingkat anu leres.
        for (key, value) in iter {
            // Coba dorong pasangan nilai-konci kana simpé daun ayeuna.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Teu aya rohangan deui, naék teras nyurung ka ditu.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Kapendak simpang sareng rohangan kénca, dorong didieu.
                                open_node = parent;
                                break;
                            } else {
                                // Naék deui.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Kami di luhur, nyiptakeun simpul akar anyar teras nyorong diditu.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Nyorong pasangan konci-nilai sareng subtree katuhu anyar.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Turun ka daun-paling katuhu deui.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Panjangna unggal unggal iterasi, pikeun mastikeun peta muragkeun elemen-elemen tambihan sanaos maju ka paner iterator.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterator pikeun ngahijikeun dua urutan anu diurutkeun kana hiji
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Upami dua konci sami, mulih pasangan nilai-konci tina sumber anu leres.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}