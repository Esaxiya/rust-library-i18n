use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modél pamulihan tina sababaraha rujukan unik, nalika anjeun terang yén reb rebébi sareng sadaya turunanana (nyaéta, sadaya panunjuk sareng rujukan anu diturunkeun tina éta) moal dianggo deui di sawatara titik, saatos anjeun hoyong nganggo rujukan unik anu asli deui .
///
///
/// Checker injeuman biasana nanganan tumpukan injeuman ieu kanggo anjeun, tapi sababaraha aliran kontrol anu ngalaksanakeun susun ieu rumit teuing pikeun panyusunan pikeun dituturkeun.
/// `DormantMutRef` ngamungkinkeun anjeun pikeun mariksa nyalukan nyalira, bari masih nganyatakeun sifat na anu ditumpuk, sareng nyandikeun kode pointer atah anu diperyogikeun pikeun ngalakukeun ieu tanpa tingkah laku anu teu ditangtoskeun.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Candak injeuman unik, sareng geuwat tarima deui.
    /// Pikeun panyusunna, hirupna référénsi anyar sami sareng hirupna tina rujukan aslina, tapi anjeun promise nganggo éta pikeun waktos anu langkung pondok.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // KESELAMATAN: kami nyepeng nginjeum sapanjang 'a via `_marker`, sareng kami ngalaan
        // ngan ukur rujukan ieu, jadi éta unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Balikkeun ka injeuman unik mimitina direbut.
    ///
    /// # Safety
    ///
    /// Pemberi pinjaman kedah réngsé, nyaéta rujukan anu dikintunkeun ku `new` sareng sadaya petunjuk sareng rujukan anu diturunkeun tina éta, henteu kedah dianggo deui.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // KESELAMATAN: kaayaan kaamanan urang sorangan nunjukkeun yén rujukan ieu deui unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;