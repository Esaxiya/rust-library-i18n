use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Kaayaan inklusif anu kedah dipilari, sapertos `Bound::Included(T)`.
    Included(T),
    /// Kabeungkeut anu diperyogikeun, sapertos `Bound::Excluded(T)`.
    Excluded(T),
    /// Kaayaan inklusif anu teu aya saratna, sapertos `Bound::Unbounded`.
    AllIncluded,
    /// Hiji wates ekslusif tanpa sarat.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Milarian konci anu dipasihkeun dina (sub) tangkal anu dipingpin ku simpul, sacara rekursif.
    /// Balikkeun `Found` ku gagang KV anu cocog, upami aya.
    /// Upami teu kitu, balikkeun `GoDown` kalayan gagang daun edge dimana koncina dipiboga.
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci, sapertos tangkal dina `BTreeMap` nyaéta.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Turun ka titik anu pang caketna dimana edge anu cocog sareng beungkeut handap kisaran benten sareng edge anu cocog sareng wates luhur, nyaéta titik anu pangcaketna anu ngagaduhan sahanteuna hiji konci anu aya dina kisaran.
    ///
    ///
    /// Upami kapendak, mulihkeun `Ok` sareng simpul éta, sapasang indéks edge di jerona ngabatesan kisaran, sareng pasangan wates anu cocog pikeun neraskeun milarian dina node murangkalih, upami node na internal.
    ///
    /// Upami teu kapendak, mulihkeun `Err` sareng daun edge anu cocog sareng sadaya jajaran.
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Inlining variabel ieu kedah dihindari.
        // Kami anggap wates anu dilaporkeun ku `range` tetep sami, tapi palaksanaan lawan tiasa ngarobih antara panggero (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Milarian edge dina simpul anu ngabatesan wates handap kisaran.
    /// Ogé mulihkeun beungkeut handap anu tiasa dianggo pikeun neraskeun milarian dina node murangkalih anu cocog, upami `self` mangrupikeun simpul internal.
    ///
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon `find_lower_bound_edge` pikeun wates luhur.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Milarian konci anu dipasihkeun dina simpul, tanpa recursion.
    /// Balikkeun `Found` ku gagang KV anu cocog, upami aya.
    /// Upami teu kitu, balikkeun `GoDown` nganggo gagang edge dimana koncina tiasa dipendakan (upami simpul na internal) atanapi dimana konci na tiasa dilebetkeun.
    ///
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci, sapertos tangkal dina `BTreeMap` nyaéta.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Ngahasilkeun indéks KV dina simpul dimana konci (atanapi sasaruaan) aya, atanapi indéks edge dimana tombolna dipiboga.
    ///
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci, sapertos tangkal dina `BTreeMap` nyaéta.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Milarian indéks edge dina simpul anu ngabatesan wates handap kisaran.
    /// Ogé mulihkeun beungkeut handap anu tiasa dianggo pikeun neraskeun milarian dina node murangkalih anu cocog, upami `self` mangrupikeun simpul internal.
    ///
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon `find_lower_bound_index` pikeun wates luhur.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}