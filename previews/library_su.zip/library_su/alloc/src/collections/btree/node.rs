// Ieu mangrupikeun usaha dina palaksanaan nuturkeun cita-cita
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Kusabab Rust saleresna henteu ngagaduhan jinis anu gumantung sareng rekursi polimorfik, urang tiasa ngalakukeun seueur kaamanan.
//

// Tujuan utama modul ieu nyaéta nyingkahan pajeulitna ku ngubaran tangkal salaku wadah umum (upami bentukna anéh) sareng ngahindarkeun kaayaan anu seueur ka B-Tree invarian.
//
// Sapertos kitu, modul ieu henteu paduli naha éntri diurutkeun, titik anu tiasa janten underfull, atanapi bahkan naon hartosna underfull.Nanging, urang ngandelkeun sababaraha invarian:
//
// - Tatangkalan kedah gaduh depth/height seragam.Ieu ngandung harti yén unggal jalan ka daun tina simpul anu dipasihkeun sami panjangna sami.
// - Hiji titik anu `n` panjangna ngagaduhan tombol `n`, nilai `n`, sareng `n + 1` tepi.
//   Ieu ngakibatkeun yén sanajan titik anu kosong ngagaduhan sahanteuna hiji edge.
//   Pikeun simpul daun, "having an edge" ngan ukur hartosna urang tiasa ngaidentipikasi posisi dina simpul, kumargi sisina daun kosong sareng teu peryogi perwakilan data.
// Dina simpul internal, edge duanana ngaidentipikasi posisi sareng ngandung pointer kana simpul murangkalih.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Répréséntasi anu node daun sareng bagian tina ngagambarkeun node internal.
struct LeafNode<K, V> {
    /// Kami hoyong janten kovarian dina `K` sareng `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indéks simpul ieu kana rangkay `edges` indung simpul.
    /// `*node.parent.edges[node.parent_idx]` kedah janten hal anu sami sareng `node`.
    /// Ieu ngan dijamin bakal diinisialisasi nalika `parent` henteu nol.
    parent_idx: MaybeUninit<u16>,

    /// Jumlah konci sareng nilai nyimpen simpul ieu.
    len: u16,

    /// Susunan nyimpen data saleresna tina simpul.
    /// Ngan ukur unsur `len` anu munggaran pikeun unggal susunan anu diinisialisasi sareng valid.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Nginisialisasi `LeafNode` énggal dina tempat.
    unsafe fn init(this: *mut Self) {
        // Salaku kabijakan umum, urang ngantepkeun lapangan teu dihaja upami tiasa, sabab ieu kedahna rada gancang sareng gampang dilacak di Valgrind.
        //
        unsafe {
            // parent_idx, konci, sareng vals sadayana meureunUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Nyiptakeun `LeafNode` kotak anyar.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Répréséntasi anu aya dina simpul internal.Kayaning `LeafNode`s, ieu kedah disumputkeun di tukangeun 'BoxedNode`s kanggo nyegah lungsur konci sareng nilai anu teu dihaja.
/// Naon waé panunjuk kana `InternalNode` tiasa langsung dialungkeun kana panunjuk kana bagian `LeafNode` anu node, ngamungkinkeun kode pikeun meta dina simpul daun sareng internal sacara umum tanpa kedah parios mana ti dua anu ditunjuk ku hiji pointer.
///
/// Sipat ieu diaktipkeun ku panggunaan `repr(C)`.
///
#[repr(C)]
// gdb_providers.py ngagunakeun nami jinis ieu pikeun panineungan.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Nunjuk ka barudak tina titik ieu.
    /// `len + 1` diantarana dianggap inisialisasi sareng valid, kajaba anu caket tungtungna, sedengkeun tangkal dicekel ngalangkungan tipe injeuman `Dying`, sababaraha petunjuk ieu ngagantung.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Nyiptakeun `InternalNode` kotak anyar.
    ///
    /// # Safety
    /// Anu invarian tina simpul internal nyaéta aranjeunna ngagaduhan sahanteuna hiji edge anu inisialisasi sareng valid.
    /// Fungsi ieu henteu nyetél sapertos edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Urang ngan ukur kedah ngainisialisasi data;pasisianna meureunUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// A pointer anu dikokolakeun, non-nol kana simpul.Ieu mangrupikeun pointer milik `LeafNode<K, V>` atanapi pointer anu dimilik pikeun `InternalNode<K, V>`.
///
/// Nanging, `BoxedNode` henteu ngagaduhan inpormasi anu mana tina dua jinis node anu leres-leres dikandungna, sareng, sawaréh kusabab kurangna inpormasi ieu, sanés jinis anu misah sareng teu gaduh destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Node akar tangkal anu dipimilik.
///
/// Catet yén ieu henteu ngagaduhan perusak, sareng kedah diberesihan sacara manual.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Balikkeun tangkal anu kagungan anyar, kalayan simpul akarna sorangan anu mimitina kosong.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` kedah henteu nol.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mutable nginjeum simpul root anu dipimilik.
    /// Beda sareng `reborrow_mut`, ieu aman sabab nilai balik teu tiasa dianggo pikeun ngancurkeun akar, sareng teu tiasa aya rujukan anu sanésna kana tangkal.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Rada dimungkinkeun nginjeum simpul root anu dipimilik.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Teu tiasa dirobih transisi kana rujukan anu ngamungkinkeun traversal sareng nawiskeun metode anu ngarusak sareng sakedik deui.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Nambihan simpul internal anu énggal kalayan edge tunggal anu nunjuk kana titik root anu sateuacana, jantenkeun simpul énggal salaku simpul root, sareng balikeun deui.
    /// Ieu ningkatkeun jangkungna ku 1 sareng sabalikna tina `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kacuali urang hilap kami internal ayeuna:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ngaleungitkeun simpul root internal, ngagunakeun anak kahijina salaku root root anyar.
    /// Sakumaha dimaksudkeun ngan ukur bakal disebat nalika root node ngagaduhan ngan hiji anak, teu aya pembersihan anu dilakukeun dina konci, nilai sareng barudak anu sanés.
    ///
    /// Ieu ngirangan jangkungna ku 1 sareng sabalikna tina `push_internal_level`.
    ///
    /// Meryogikeun aksés ekslusif ka obyék `Root` tapi henteu kana root node;
    /// éta moal ngabatalkeun cecekelan atanapi rujukan anu sanés kana root node.
    ///
    /// Panics upami teu aya tingkat internal, nyaéta, upami root node mangrupikeun daun.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // Kaamanan: kami negeskeun janten internal.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KESELAMATAN: kami nginjeum `self` sacara éksklusif sareng jinis injeuman na éksklusif.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // KESELAMATAN: anu edge anu munggaran sok diinisialisasi.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` sok kovarian di `K` sareng `V`, bahkan nalika `BorrowType` nyaéta `Mut`.
// Ieu téhnisna salah, tapi henteu tiasa ngahasilkeun henteu aman kusabab panggunaan internal `NodeRef` sabab kami tetep lengkep generik ngalangkungan `K` sareng `V`.
//
// Nanging, iraha jinis masarakat ngabungkus `NodeRef`, pastikeun yén éta ngagaduhan varian anu leres.
//
/// Rujukan pikeun simpul.
///
/// Jenis ieu ngagaduhan sajumlah parameter anu ngatur kumaha polahna:
/// - `BorrowType`: Jinis dummy anu ngajelaskeun jinis nginjeum sareng nyandak hirup.
///    - Nalika ieu `Immut<'a>`, `NodeRef` tindakan kasarna sapertos `&'a Node`.
///    - Nalika ieu `ValMut<'a>`, `NodeRef` tindakan kasarna sapertos `&'a Node` anu aya kaitannana sareng konci sareng struktur tangkal, tapi ogé ngamungkinkeun réa rujukan anu tiasa dirobih dina sapanjang tangkal janten hirup babarengan.
///    - Nalika ieu `Mut<'a>`, `NodeRef` polah kasarna sapertos `&'a mut Node`, sanaos metode sisipan ngamungkinkeun pointer anu tiasa dirobih pikeun nilai babarengan.
///    - Nalika ieu `Owned`, `NodeRef` tindakan kasarna sapertos `Box<Node>`, tapi henteu ngagaduhan destruktor, sareng kedah diberesihan sacara manual.
///    - Nalika ieu `Dying`, `NodeRef` masih bertindak kasarna sapertos `Box<Node>`, tapi ngagaduhan metode pikeun ngancurkeun tangkal sakedik-sakedik, sareng metode biasa, sanaos henteu ditandaan henteu aman pikeun ditelepon, tiasa nyungkeun UB upami disebat lepat.
///
///   Kusabab `NodeRef` naon waé ngamungkinkeun ngalangkungan tangkal, `BorrowType` sacara épéktip dilarapkeun ka sakumna tangkal, sanés ngan ukur kana simpul nyalira.
/// - `K` sareng `V`: Ieu mangrupikeun jinis konci sareng nilai anu disimpen dina titik.
/// - `Type`: Ieu tiasa `Leaf`, `Internal`, atanapi `LeafOrInternal`.
/// Nalika ieu `Leaf`, `NodeRef` nunjuk kana simpul daun, nalika ieu `Internal` `NodeRef` nunjuk kana simpul internal, sareng nalika ieu `LeafOrInternal` `NodeRef` tiasa nunjuk kana salah sahiji jenis simpul.
///   `Type` dingaranan `NodeType` nalika dianggo di luar `NodeRef`.
///
/// Duanana `BorrowType` sareng `NodeType` ngawatesan metode naon anu urang diterapkeun, pikeun mangpaatkeun kaamanan tipe statis.Aya watesan cara urang nerapkeun larangan sapertos kitu:
/// - Pikeun unggal jenis parameter, urang ngan ukur tiasa ngahartikeun cara sapertos sacara umum atanapi kanggo hiji jinis khusus.
/// Salaku conto, urang moal tiasa ngartikeun metode sapertos `into_kv` sacara umum pikeun sadaya `BorrowType`, atanapi sakali pikeun sadaya jinis anu ngagaduhan hirupna, sabab urang hoyongkeun deui rujukan `&'a`.
///   Kituna, kami ngartikeun éta ngan pikeun tipe `Immut<'a>` anu paling henteu kuat.
/// - Kami henteu tiasa kéngingkeun paksaan anu tersirat tina nyarios `Mut<'a>` dugi ka `Immut<'a>`.
///   Kituna, urang kedah jelas-jelas nelepon `reborrow` dina `NodeRef` anu langkung kuat pikeun ngahontal metode sapertos `into_kv`.
///
/// Sadaya padika dina `NodeRef` anu balikkeun sababaraha jinis rujukan, naha:
/// - Candak `self` ku nilai, sareng balikeun deui hirupna anu dilakukeun ku `BorrowType`.
///   Kadang-kadang, pikeun ngaguar metode sapertos kitu, urang kedah nyauran `reborrow_mut`.
/// - Candak `self` ku rujukan, sareng (implicitly) balikkeun hirupna référénsi éta, tibatan hirup anu dibawa ku `BorrowType`.
/// Ku cara éta, Checker injeuman ngajamin yén `NodeRef` tetep diinjeumkeun salami référénsi anu dikembalikan dianggo.
///   Metodeu anu ngadukung sisindiran ngabengkokkeun aturan ieu ku ngabalikeun pointer atah, nyaéta rujukan tanpa umur.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Jumlah tingkat anu simpul sareng tingkat daunna pisah, konstanta tina simpul anu teu tiasa ditétélakeun sadayana ku `Type`, sareng yén simpul éta sorangan henteu disimpen.
    /// Urang ukur kedah nyimpen jangkungna simpul akar, sareng nangkep unggal jangkungna simpul sanésna.
    /// Kedah nol upami `Type` nyaéta `Leaf` sareng sanés nol upami `Type` nyaéta `Internal`.
    ///
    ///
    height: usize,
    /// Pointer kana daun atanapi simpul internal.
    /// Definisi `InternalNode` mastikeun yén pointer valid pikeun cara anu mana waé.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ngabongkar rujukan simpul anu dibungkus salaku `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ngalaan data tina hiji simpul internal.
    ///
    /// Mulihkeun ptr atah pikeun ngahindarkeun validasi rujukan sanés kana nod ieu.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAFETY: jinis simpul statik nyaéta `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nginjeum aksés eksklusif kana data tina hiji simpul internal.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Milarian panjang simpul.Ieu jumlah konci atanapi nilai.
    /// Jumlah sisina nyaéta `len() + 1`.
    /// Catet yén, sanaos aman, nyauran fungsi ieu tiasa ngagaduhan efek samping tina ngabatalkeun référénsi mutable anu diciptakeun kode henteu aman.
    ///
    pub fn len(&self) -> usize {
        // Penting, urang ngan ukur aksés kana lapangan `len` di dieu.
        // Upami BorrowType nyaéta marker::ValMut, panginten aya rujukan anu tiasa dirobih pikeun nilai anu urang henteu kedah batal.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Balikkeun jumlah tingkatan anu simpul sareng daunna pisah.
    /// Jangkungna nol hartosna simpul mangrupikeun daun nyalira.
    /// Upami anjeun gambar tangkal kalayan akar na di luhur, jumlahna nyarios dina élévasi titik na némbongan.
    /// Upami anjeun gambar tangkal sareng daun di luhur, jumlahna nyarios sabaraha jangkungna tangkal dugi di luhur simpul.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Samentawis nyandak deui, rujukan anu teu tiasa dirobih kana node anu sami.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ngalaan bagian daun tina sagala daun atanapi simpul internal.
    ///
    /// Mulihkeun ptr atah pikeun ngahindarkeun validasi rujukan sanés kana nod ieu.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Simpul kedah sahanteuna sahenteuna bagian LeafNode.
        // Ieu sanés rujukan dina jinis NodeRef sabab kami henteu terang naha éta kedah unik atanapi dibagi.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Milarian kolot tina nod anu ayeuna.
    /// Mulih `Ok(handle)` upami simpul ayeuna saleresna ngagaduhan induk, dimana `handle` nunjuk ka edge induk anu nunjuk kana simpul anu ayeuna.
    ///
    /// Mulih `Err(self)` upami simpul ayeuna teu ngagaduhan induk, masihan deui `NodeRef` aslina.
    ///
    /// Ngaran metoda nganggap anjeun gambar tangkal sareng root node di luhur.
    ///
    /// `edge.descend().ascend().unwrap()` sareng `node.ascend().unwrap().descend()` kedah duanana, nalika hasil, teu nanaon.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Urang kedah nganggo petunjuk atah kana titik sabab, upami BorrowType nyaéta marker::ValMut, panginten aya rujukan anu tiasa dirobih pikeun nilai anu urang henteu kedah batal.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Catet yén `self` kedah janten nonempty.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Catet yén `self` kedah janten nonempty.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Ngalaan bagian daun tina daun atanapi simpul internal dina tangkal anu teu tiasa dirobih.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAFETY: teu tiasa aya rujukan anu tiasa dirobih kana tangkal ieu anu diinjeum salaku `Immut`.
        unsafe { &*ptr }
    }

    /// Nginjeum tampilan kana konci anu disimpen dina simpul.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Sarupa sareng `ascend`, ngagaduhan rujukan kana simpul induk hiji node, tapi ogé ngaluarkeun titik anu ayeuna dina prosés.
    /// Ieu henteu aman sabab simpul anu ayeuna masih tiasa diaksés sanaos ditepakkeun.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Henteu aman negeskeun ka panyusun inpormasi statis yén titik ieu nyaéta `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Henteu aman negeskeun ka panyusun inpormasi statis yén titik ieu mangrupikeun `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Samentawis nyandak deui rujukan anu tiasa dimutkeun kana simpul anu sami.Ati-ati, sabab metode ieu bahaya pisan, duka kali sabab henteu langsung katingali bahaya.
    ///
    /// Kusabab petunjuk anu tiasa dirobih tiasa ngorondang di mana waé tangkal, pointer anu dipulangkeun tiasa gampang dipaké pikeun nyieun pointer aslina ngagantung, kaluar tina wates, atanapi henteu sah dina aturan pinjaman anu ditumpuk.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) mertimbangkeun nambihan parameter jinis anu sanés kana `NodeRef` anu ngawatesan panggunaan metode navigasi dina petunjuk anu ditampi, nyegah teu aman ieu.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nginjeum aksés éksklusif pikeun bagian daun tina daun atanapi simpul internal.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAFETY: urang gaduh aksés ekslusif ka sadaya simpul.
        unsafe { &mut *ptr }
    }

    /// Nawiskeun aksés éksklusif pikeun bagian daun tina daun atanapi simpul internal.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAFETY: urang gaduh aksés ekslusif ka sadaya simpul.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nginjeum aksés eksklusif kana unsur daérah panyimpenan konci.
    ///
    /// # Safety
    /// `index` aya dina wates 0..KABASITAS
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KESELAMATAN: anu nelepon moal tiasa nyauran metode salajengna dina nyalira
        // dugi ka referensi keureutan konci murag, sabab kami gaduh aksés unik salami waktos nginjeum.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Nginjeum aksés éksklusif pikeun unsur atanapi nyiksikan aréa simpen nilai simpul.
    ///
    /// # Safety
    /// `index` aya dina wates 0..KABASITAS
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KESELAMATAN: anu nelepon moal tiasa nyauran metode salajengna dina nyalira
        // dugi ka referensi potongan nilai turun, sabab urang gaduh aksés anu unik salami waktos nginjeum.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nginjeum aksés ekslusif ka unsur atanapi nyiksikan area panyimpenan simpul pikeun eusi edge.
    ///
    /// # Safety
    /// `index` aya dina wates 0..KABASITAS + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KESELAMATAN: anu nelepon moal tiasa nyauran metode salajengna dina nyalira
        // dugi ka rujukan keureut edge turun, sabab urang gaduh aksés anu unik salami waktos nginjeum.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Simpulna ngagaduhan langkung ti `idx` unsur inisialisasi.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Kami ngan ukur nyiptakeun acuan kana hiji unsur anu dipikaresep ku kami, pikeun nyingkahan aliasing ku référénsi anu luar biasa pikeun elemen séjén, khususna, anu balik ka anu nélépon dina étaran anu sateuacanna.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Urang kedah maksa kana poin anu teu diukur kusabab masalah Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Nginjeum aksés ekslusif kana panjang simpul.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nyetél tautan simpul ka indungna edge, tanpa ngabatalkeun rujukan séjén pikeun simpul.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Mupus tautan akar ka indungna edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Nambahkeun pasangan konci-nilai kana tungtung simpul.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Unggal barang anu dipulang ku `range` mangrupikeun indéks edge anu valid pikeun simpul.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Nambahkeun pasangan konci-nilai, sareng edge pikeun lebet ka katuhu pasangan éta, kana tungtung simpul.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Pariksa naha simpul mangrupikeun simpul `Internal` atanapi simpul `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Rujukan pikeun pasangan konci-nilai spésifik atanapi edge dina hiji titik.
/// Parameter `Node` kedah `NodeRef`, sedengkeun `Type` tiasa `KV` (nandakeun cecekelan dina pasangan konci-nilai) atanapi `Edge` (nandakeun gagang dina edge).
///
/// Catet yén bahkan titik `Leaf` tiasa gaduh `Edge` gagang.
/// Daripada ngagambarkeun pointer kana simpé budak, ieu ngagambarkeun rohangan anu nunjukkeun titik budak antara pasangan konci-nilai.
/// Salaku conto, dina simpul anu panjangna 2, bakal aya 3 kamungkinan lokasi edge, hiji di kénca simpul, hiji diantara dua pasang, sareng hiji di katuhu simpul.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Kami henteu peryogi sacara umum `#[derive(Clone)]`, sabab hiji-hijina waktos `Node` bakal janten `Clone`able nyaéta nalika mangrupikeun rujukan anu teu tiasa dirobih sahingga `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Meunangkeun simpul anu ngandung edge atanapi pasangan konci-nilai anu ditunjuk ieu gagang.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Balikkeun posisi gagang ieu dina simpul.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Nyiptakeun gagang anyar pikeun pasangan konci-nilai dina `node`.
    /// Henteu aman sabab anu nelepon kedah mastikeun yén `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Bisa janten palaksanaan publik PartialEq, tapi ngan ukur dianggo dina modul ieu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Samentawis nyandak gagang anu sanés anu teu tiasa dirobih dina lokasi anu sami.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Kami henteu tiasa nganggo Handle::new_kv atanapi Handle::new_edge sabab kami henteu terang jinisna kami
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Henteu aman negeskeun ka panyusun inpormasi statis yén simpul cecekelan nyaéta `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Samentawis nyandak gagang anu séjén anu tiasa dirobih dina lokasi anu sami.
    /// Ati-ati, sabab metode ieu bahaya pisan, duka kali sabab henteu langsung katingali bahaya.
    ///
    ///
    /// Pikeun detil, tingali `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Kami henteu tiasa nganggo Handle::new_kv atanapi Handle::new_edge sabab kami henteu terang jinisna kami
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Nyiptakeun cecekelan anyar pikeun edge dina `node`.
    /// Henteu aman sabab anu nelepon kedah mastikeun yén `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dibikeun indéks edge dimana kami hoyong lebetkeun kana simpul anu dieusian dugi ka kapasitas, ngitung indéks KV anu raos tina titik pamisah sareng dimana ngalaksanakeun sisipan.
///
/// Tujuan tina titik pamisah nyaéta konci sareng niléyna pikeun tungtungna dina titik indung;
/// konci, nilai sareng pasisian kénca titik pamisah janten anak kénca;
/// konci, nilai sareng pasisian di belah katuhu titik pamisah janten anak anu leres.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Masalah Rust #74834 nyobian ngajelaskeun aturan simetri ieu.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebetkeun pasangan nilai-konci énggal antara pasangan konci-nilai di katuhu sareng kénca edge ieu.
    /// Metoda ieu nganggap yén aya cukup rohangan dina titik pikeun pasangan anyar pas.
    ///
    /// Pointer anu balik nunjuk kana nilai anu dilebetkeun.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebetkeun pasangan nilai-konci énggal antara pasangan konci-nilai di katuhu sareng kénca edge ieu.
    /// Cara ieu meulah simpul upami henteu cekap kamar.
    ///
    /// Pointer anu balik nunjuk kana nilai anu dilebetkeun.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ngalereskeun pointer indéks sareng indéks dina simpul anak anu dihubungkeun ku edge ieu.
    /// Ieu gunana nalika susunan ujungna parantos dirobih,
    fn correct_parent_link(self) {
        // Ngadamel backpointer tanpa ngabatalkeun rujukan anu sanés kana simpul.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Nyelapkeun sapasang konci-nilai énggal sareng edge anu bakal di belah katuhu tina pasangan anyar éta antara edge ieu sareng pasangan konci-nilai di sisi katuhu edge ieu.
    /// Metoda ieu nganggap yén aya cukup rohangan dina titik pikeun pasangan anyar pas.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Nyelapkeun sapasang konci-nilai énggal sareng edge anu bakal di belah katuhu tina pasangan anyar éta antara edge ieu sareng pasangan konci-nilai di sisi katuhu edge ieu.
    /// Cara ieu meulah simpul upami henteu cekap kamar.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Lebetkeun pasangan nilai-konci énggal antara pasangan konci-nilai di katuhu sareng kénca edge ieu.
    /// Cara ieu meulah simpul upami henteu cekap kamar, sareng nyobian ngalebetkeun bagian pamisah kana simpul induk sacara rekursif, dugi ka akar na ngahontal.
    ///
    ///
    /// Upami hasilna anu dipulangkeun nyaéta `Fit`, simpul gagang na tiasa janten simpul edge ieu atanapi karuhun.
    /// Upami hasilna anu dipulangkeun nyaéta `Split`, lapangan `left` bakal janten simpul akar.
    /// Pointer anu balik nunjuk kana nilai anu dilebetkeun.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Milarian simpul anu ditunjuk ku edge ieu.
    ///
    /// Ngaran metoda nganggap anjeun gambar tangkal sareng root node di luhur.
    ///
    /// `edge.descend().ascend().unwrap()` sareng `node.ascend().unwrap().descend()` kedah duanana, nalika hasil, teu nanaon.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Urang kedah nganggo petunjuk atah kana titik sabab, upami BorrowType nyaéta marker::ValMut, panginten aya rujukan anu tiasa dirobih pikeun nilai anu urang henteu kedah batal.
        // Teu aya hariwang ngakses lapangan jangkungna kusabab nilai éta disalin.
        // Ati-ati yén, sakali pointer nod teu diséferénsikeun, urang ngaksés Asép Sunandar Sunarya sareng rujukan (Rust ngaluarkeun #73987) sareng ngabatalkeun rujukan naon waé anu aya kana atanapi dina jero rangkéan, kedah aya di sakitar.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Kami moal tiasa nyauran metodeu konci sareng nilai anu misah, sabab nelepon anu kadua ngabatalkeun rujukan anu dikaluarkeun ku anu munggaran.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ganti konci sareng nilai anu dituduhkeun ku KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ngabantosan palaksanaan `split` pikeun `NodeType` tinangtu, ku ngurus data daun.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Beulah simpul anu janten dasarna janten tilu bagian:
    ///
    /// - Node dipotong janten ngan ngandung pasangan konci-nilai di kénca cecekelan ieu.
    /// - Konci sareng nilai anu ditunjuk ku gagang ieu sasari.
    /// - Sadaya pasangan nilai-konci di sisi katuhu cecekelan ieu dilebetkeun kana simpul anu énggal dikaluarkeun.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ngaleungitkeun pasangan konci-nilai anu ditunjuk ku gagang ieu sareng mulih deui, sareng edge anu pasangan konci-nilai runtuh.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Beulah simpul anu janten dasarna janten tilu bagian:
    ///
    /// - Node dipotong janten ngan ngandung pasisian sareng pasangan konci-nilai di kénca gagang ieu.
    /// - Konci sareng nilai anu ditunjuk ku gagang ieu sasari.
    /// - Sadaya pasisian sareng pasangan konci-nilai di belah katuhu cecekelan ieu dilebetkeun kana simpul anu nembe dialokasikeun.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ngalambangkeun sési pikeun évaluasi sareng ngalakukeun operasi balancing sakitar pasangan konci-nilai internal.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Milih kontéks balancing anu ngalibatkeun titik nalika budak, maka antara KV geuwat ka kénca atanapi ka katuhu dina simpul induk.
    /// Balikkeun `Err` upami teu aya kolot.
    /// Panics upami sepuhna kosong.
    ///
    /// Langkung resep sisi kénca, janten optimal upami titik anu disayogikeun kurang pentingna, hartosna di dieu waé yén éta ngagaduhan unsur anu langkung kirang ti duduluran kénca na tibatan duduluranana anu katuhu, upami éta aya.
    /// Dina kasus éta, ngahijikeun sareng duduluran kénca langkung gancang, kumargi urang ngan ukur kedah ngalihkeun elemen N titik, tibatan ngagentoskeunna ka katuhu sareng mindahkeun langkung seueur ti unsur N di payun.
    /// Nyolong ti duduluran kénca ogé biasana langkung gancang, kumargi urang ngan ukur kedah ngalihkeun elemen N node ka katuhu, tibatan mindahkeun sahenteuna N tina unsur duduluran ka kénca.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Mulih naha tiasa dicantumkeun, nyaéta naha aya cukup rohangan dina hiji titik pikeun ngagabungkeun KV sentral sareng duanana simpul murangkalih anu caket.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Ngalaksanakeun ngagabung sareng ngamungkinkeun panutupanana mutuskeun naon anu kedah dipulangkeun.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KESELAMATAN: jangkungna simpul anu ngahiji hiji handapeun jangkungna
                // tina simpul edge ieu, sahingga luhur nol, janten sipatna internal.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ngahijikeun pasangan konci-nilai pasangan sareng duanana simpé murangkalih anu caket kana simpul murangkalih kénca sareng ngembalikan simpul induk anu ngaleutikan.
    ///
    ///
    /// Panics kacuali urang `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ngagabungkeun pasangan konci-nilai pasangan sareng duanana simpé murangkalih anu caket kana node murangkalih kénca sareng ngembalikan simpé anak éta.
    ///
    ///
    /// Panics kacuali urang `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ngahijikeun pasangan konci-nilai pasangan sareng duanana simpé murangkalih caket kana titik murangkalih kénca sareng mulihkeun gagang edge dina simpul murangkalih dimana anakna edge dilacak réngsé,
    ///
    ///
    /// Panics kacuali urang `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Ngaleungitkeun pasangan nilai-konci ti budak kénca sareng nempatkeun kana panyimpenan nilai-sepuh indungna, bari nyodokkeun pasangan konci-nilai kolot ka budak katuhu.
    ///
    /// Balikkeun gagang kana edge dina budak katuhu anu saluyu sareng dimana edge aslina anu ditangtukeun ku `track_right_edge_idx` réngsé.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Ngaleungitkeun pasangan nilai-konci tina budak katuhu sareng nempatkeun kana panyimpenan nilai-sepuh indungna, bari ngadorong pasangan nilai-konci kolot ka anak kénca.
    ///
    /// Balikkeun gagang kana edge di murangkalih kénca anu ditetepkeun ku `track_left_edge_idx`, anu henteu ngalih.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ieu nyolong sami sareng `steal_left` tapi nyolong sababaraha elemen sakaligus.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikeun yén urang tiasa maok aman.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mindahkeun data daun.
            {
                // Jantenkeun rohangan pikeun unsur anu dipaling ku budak anu leres.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mindahkeun elemen ti anak kénca ka katuhu.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Mindahkeun pasangan anu paling kénca ka kolot.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mindahkeun pasangan nilai konci pikeun budak anu katuhu.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ngadamel kamar pikeun sisina dipaling.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Nyolong sisina.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Klon simétri `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Pastikeun yén urang tiasa maok aman.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mindahkeun data daun.
            {
                // Mindahkeun pasangan anu paling dipaling ka kolot.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mindahkeun pasangan nilai-konci indungna ka budak kénca.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mindahkeun elemen ti anak katuhu ka hiji kénca.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Eusian lolongkrang dimana unsur anu dipaling tiheula.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Nyolong sisina.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Eusian lolongkrang dimana ujung-ujungna dipaling.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ngaleungitkeun inpormasi statis naon waé anu negeskeun yén titik ieu mangrupikeun titik `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ngaleungitkeun inpormasi statis naon waé anu negeskeun yén titik ieu mangrupikeun titik `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Pariksa naha simpul anu janten dasarna nyaéta simpul `Internal` atanapi simpul `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Mindahkeun ahiran saatos `self` tina hiji node kana anu sanés.`right` kedah kosong.
    /// edge munggaran `right` tetep henteu robih.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Hasil panempatan, nalika titik peryogi diperpanjang saluareun kapasitasna.
pub struct SplitResult<'a, K, V, NodeType> {
    // Ngarobih simpul dina tangkal anu aya sareng elemen sareng sisina anu aya dina kénca `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Sababaraha konci sareng nilai dipisahkeun, pikeun dilebetkeun di tempat sanés.
    pub kv: (K, V),
    // Ngagaduhan, teu kahubung, simpul énggal kalayan elemen sareng pasisian anu kagolong kana hak `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Naha rujukan simpul tina jinis injeuman ieu ngamungkinkeun ngalangkungan ka titik anu sanés dina tangkal.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal henteu diperyogikeun, éta kajadian nganggo hasil `borrow_mut`.
        // Ku nganonaktipkeun traversal, sareng ngan ukur nyiptakeun référénsi anyar kana akar, urang terang yén unggal rujukan tina jinis `Owned` nyaéta kana titik root.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Nyelapkeun nilai kana sapotong unsur inisialisasi dituturkeun ku hiji unsur anu teu acan diinalisasi.
///
/// # Safety
/// Irisan ngagaduhan langkung ti `idx` elemen.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Ngaleungitkeun sareng ngasilkeun nilai tina sapotong sadaya unsur anu diinisialisasi, ninggali hiji unsur anu teu acan diinalisasi.
///
///
/// # Safety
/// Irisan ngagaduhan langkung ti `idx` elemen.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Mindahkeun elemen dina posisi `distance` nyiksikan ka kénca.
///
/// # Safety
/// Irisan ngagaduhan sahenteuna elemen `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ngalihkeun elemen dina posisi `distance` nyiksikan ka katuhu.
///
/// # Safety
/// Irisan ngagaduhan sahenteuna elemen `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Mindahkeun sadaya nilai tina sapotong unsur inisialisasi kana sapotong unsur anu henteu diciptakeun, ninggali `src` sakumaha sadayana henteu diartikeun.
///
/// Gawe sareng `dst.copy_from_slice(src)` tapi henteu meryogikeun `T` janten `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;