use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Samentawis nyandak anu sanésna, teu sami robih tina rentang anu sami.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Milarian ujung daun anu béda anu ngabatesan sababaraha rentang anu ditetepkeun dina tangkal.
    /// Ngabalikeun sapasang gagang anu béda kana tangkal anu sami atanapi sapasang pilihan kosong.
    ///
    /// # Safety
    ///
    /// Kacuali `BorrowType` nyaéta `Immut`, henteu nganggo gagang duplikat pikeun nganjang ka KV anu sami dua kali.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Sarua jeung `(root1.first_leaf_edge(), root2.last_leaf_edge())` tapi leuwih éfisién.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Milarian sapasang sisir daun ngabatesan rentang khusus dina tangkal.
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci, sapertos tangkal dina `BTreeMap` nyaéta.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // KESELAMATAN: jenis injeuman urang teu tiasa dirobih.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Milarian sapasang daun sisina ngabatesan hiji tangkal.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Misahkeun rujukan unik kana sapasang daun daun anu ngabatesan kisaran anu parantos ditangtoskeun.
    /// Hasilna mangrupikeun rujukan anu henteu unik anu ngamungkinkeun mutasi (some), anu kedah dianggo sacara ati-ati.
    ///
    /// Hasilna ngan ukur ngandung hartos upami tangkalna dipesen ku konci, sapertos tangkal dina `BTreeMap` nyaéta.
    ///
    ///
    /// # Safety
    /// Entong nganggo gagang duplikat pikeun nganjang ka KV anu sami dua kali.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ngabagi rujukan anu unik kana sapasang daun daun anu ngabatesan sadaya tangkal.
    /// Hasilna mangrupikeun rujukan anu henteu unik anu ngamungkinkeun mutasi (tina nilai-nilai hungkul), janten kedah dianggo kalayan ati-ati.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Kami ngaduplikasi akar NodeRef didieu-kami moal nganjang ka KV anu sami dua kali, sareng henteu pernah ditungtungan ku rujukan nilai anu tindih.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ngabagi rujukan anu unik kana sapasang daun daun anu ngabatesan sadaya tangkal.
    /// Hasilna mangrupikeun rujukan anu henteu unik anu ngamungkinkeun mutasi anu rusak pisan, janten kedah dianggo kalayan ati-ati pisan.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Kami menduplikasi akar NodeRef di dieu-kami moal ngaksésna ku cara tumpang tindih rujukan anu dicandak tina akar.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Dibikeun gagang edge daun, mulih [`Result::Ok`] ku gagangna ka KV tatangga di beulah katuhu, anu dina simpé daun anu sami atanapi dina simpul karuhun.
    ///
    /// Upami daun edge mangrupikeun anu terakhir dina tangkal, balikkeun [`Result::Err`] sareng simpul akar.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Dibikeun gagang edge daun, mulih [`Result::Ok`] ku gagangna ka KV tatangga di beulah kénca, anu dina simpé daun anu sami atanapi dina simpul karuhun.
    ///
    /// Upami daun edge mangrupikeun anu pangheulana dina tangkal, balikkeun [`Result::Err`] sareng simpul akar.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Dibikeun cekelan edge internal, mulih [`Result::Ok`] sareng gagang kana KV tatangga di beulah katuhu, anu dina simpul internal anu sami atanapi dina simpul karuhun.
    ///
    /// Upami edge internal mangrupikeun anu terakhir dina tangkal, mulih [`Result::Err`] sareng simpul akar.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Dibikeun gagang edge kana tangkal anu sakarat, mulih daun edge salajengna di sisi katuhu, sareng pasangan konci-nilai di antawisna, anu dina simpé daun anu sami, dina simpul karuhun, atanapi teu aya.
    ///
    ///
    /// Metoda ieu ogé ngaganggu node(s) naon waé anu dugi ka akhir.
    /// Ieu nunjukkeun yén upami teu aya deui pasangan konci-nilai, sakumna sésana tangkal bakal dialihkeun sareng teu aya anu kénging deui.
    ///
    /// # Safety
    /// edge anu dipasihkeun sanés kedah sateuacanna dipulangkeun ku pasangan `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Dibikeun gagang edge daun kana tangkal anu sakarat, mulih daun salajengna edge di sisi kénca, sareng pasangan konci-nilai di antawisna, anu boh dina simpul daun anu sami, dina simpul karuhun, atanapi teu aya.
    ///
    ///
    /// Metoda ieu ogé ngaganggu node(s) naon waé anu dugi ka akhir.
    /// Ieu nunjukkeun yén upami teu aya deui pasangan konci-nilai, sakumna sésana tangkal bakal dialihkeun sareng teu aya anu kénging deui.
    ///
    /// # Safety
    /// edge anu dipasihkeun sanés kedah sateuacanna dipulangkeun ku pasangan `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates tumpukan simpul tina daun dugi ka akar.
    /// Ieu hiji-hijina cara pikeun méréskeun sesa tangkal saatos `deallocating_next` sareng `deallocating_next_back` parantos nyusut dina dua sisi tangkal, sareng pencét edge anu sami.
    /// Kusabab éta ngan ukur bakal disebut nalika sadaya konci sareng nilai parantos dikembalikan, teu aya pembersihan anu dilakukeun dina konci atanapi nilai mana waé.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pindahkeun gagang edge daun ka daun salajengna edge sareng mulihkeun rujukan kana konci sareng nilai di antawisna.
    ///
    ///
    /// # Safety
    /// Kedah aya KV sanés dina arah anu dituju.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Mindahkeun gagang edge daun ka edge daun sateuacanna sareng mulihkeun rujukan kana konci sareng nilai di antawisna.
    ///
    ///
    /// # Safety
    /// Kedah aya KV sanés dina arah anu dituju.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Pindahkeun gagang edge daun ka daun salajengna edge sareng mulihkeun rujukan kana konci sareng nilai di antawisna.
    ///
    ///
    /// # Safety
    /// Kedah aya KV sanés dina arah anu dituju.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ngalakukeun anu terakhir ieu langkung gancang, numutkeun tolok ukur.
        kv.into_kv_valmut()
    }

    /// Mindahkeun daun edge gagang kana daun sateuacanna sareng mulihkeun rujukan kana konci sareng nilai di antawisna.
    ///
    ///
    /// # Safety
    /// Kedah aya KV sanés dina arah anu dituju.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ngalakukeun anu terakhir ieu langkung gancang, numutkeun tolok ukur.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Mindahkeun daun edge cecekelan ka daun salajengna edge sareng mulih konci sareng nilai di antawisna, nganyahokeun simpul naon waé anu ditinggalkeun bari ngantepkeun edge dina simpul induk na anu ngagantung.
    ///
    /// # Safety
    /// - Kedah aya KV sanés dina arah anu dituju.
    /// - Éta KV sateuacanna henteu dipulangkeun ku réncang `next_back_unchecked` dina salinan panangan anu dianggo pikeun nembak tangkal.
    ///
    /// Hiji-hijina cara anu aman pikeun neraskeun gagang anu diénggalan nyaéta ngabandingkeun éta, leupaskeun, nelepon metoda ieu deui tunduk kana kaayaan kaamananna, atanapi nyauran réncang `next_back_unchecked` anu tunduk kana kaayaan kaamanan na.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Mindahkeun gagang edge daun ka edge daun sateuacanna sareng mulih konci sareng nilai di antawisna, nganyahokeun simpul naon waé anu tinggaleun bari ngantepkeun edge dina simpul induk na anu ngagantung.
    ///
    /// # Safety
    /// - Kedah aya KV sanés dina arah anu dituju.
    /// - Daun éta edge henteu sateuacanna dipulangkeun ku réncang `next_unchecked` dina salinan gagang anu dianggo pikeun nembus tangkal.
    ///
    /// Hiji-hijina cara anu aman pikeun neraskeun gagang anu diénggalan nyaéta ngabandingkeun éta, leupaskeun, nelepon metoda ieu deui tunduk kana kaayaan kaamananna, atanapi nyauran réncang `next_unchecked` anu tunduk kana kaayaan kaamanan na.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Balikkeun daun kénca edge dina atanapi handapeun hiji titik, dina basa sanésna, edge anjeun peryogi heula nalika nganapigasi ka payun (atanapi terakhir nalika nganapigasi mundur).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Balikkeun daun anu paling katuhu edge dina atanapi handapeun hiji titik, dina basa sanésna, edge anu anjeun peryogikeun terakhir nalika napigasi ka payun (atanapi anu munggaran nalika napigasi mundur).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Nganjang ka simpul daun sareng KV internal dina urutan tombol naék, sareng ogé nganjang ka simpul internal dina urutan anu pangpayunna, hartosna titik internal sateuacanna KV masing-masing sareng simpul murangkalihna.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ngitung jumlah unsur dina tangkal (sub).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Balikkeun daun edge pangdeukeutna ka KV pikeun navigasi payun.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Balikkeun daun edge caket kana KV pikeun navigasi mundur.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}