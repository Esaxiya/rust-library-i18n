//! Baris antrian dua kali dilaksanakeun ku panyangga cincin anu tuwuh.
//!
//! Antrian ieu gaduh sisipan amortisasi *O*(1) sareng pananggalan tina kadua tungtung wadah.
//! Éta ogé ngagaduhan indexing *O*(1) sapertos vector.
//! Unsur anu dikandung henteu diperyogikeun pikeun ditiron, sareng antrianana bakal dikirim upami jinis anu aya tiasa dikirim.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Kamungkinan panggedéna dua

/// Baris antrian dua kali dilaksanakeun ku panyangga cincin anu tuwuh.
///
/// Pamakéan "default" tina jenis ieu salaku antrian nyaéta nganggo [`push_back`] pikeun nambihan kana antrian, sareng [`pop_front`] kanggo ngaleungitkeun antrian.
///
/// [`extend`] sareng [`append`] dorong kana tonggong ku cara ieu, sareng iterasi langkung `VecDeque` payunna ka tukang.
///
/// Kusabab `VecDeque` mangrupikeun panyangga cincin, unsur-unsurna henteu kedah caket dina mémori.
/// Upami anjeun hoyong aksés kana elemen salaku sapotong, sapertos pikeun asihan épisién, anjeun tiasa nganggo [`make_contiguous`].
/// Éta muterkeun `VecDeque` supados elemen na henteu bungkus, sareng mulihkeun potongan anu tiasa dirobih kana sekuen elemen anu ayeuna-tiasa caket.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // buntut sareng sirah anu nunjuk kana panyangga.
    // Buntut sok nunjuk unsur anu munggaran anu tiasa dibaca, Kepala sok nunjuk ka mana data kedah ditulis.
    //
    // Upami buntut==sirah buffer kosong.Panjang ringbuffer dihartikeun salaku jarak antara dua.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Ngajalankeun destructor pikeun sadaya item dina keureut nalika turun (normal atanapi nalika ngalaunan).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // nganggo serelek kanggo [T]
            ptr::drop_in_place(front);
        }
        // RawVec nanganan deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Nyiptakeun `VecDeque<T>` kosong.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginal langkung merenah
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginal langkung merenah
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Pikeun jenis ukuran enol, kami salawasna dina kapasitas maksimum
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ngarobih ptr kana keureutan
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ngarobih ptr kana irisan mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Mindahkeun unsur kaluar tina panyangga
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Nyerat unsur kana panyangga, mindahkeun éta.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Mulih `true` upami panyangga dina kapasitas pinuh.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Balikkeun indéks dina panyangga dasar pikeun indéks unsur logis anu ditangtoskeun.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Balikkeun indéks dina panyangga dasar pikeun indéks unsur logis anu + tambahan.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Balikkeun indéks dina panyangga dasar pikeun indéks unsur logis anu ditangtoskeun, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Nyalin blok memori anu caket sareng panjang ti src dugi ka dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Nyalin blok memori anu caket sareng panjang ti src dugi ka dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Nyalin blok pangémutan anu tiasa bungkus mémori panjang ti src dugi ka tujuan.
    /// (abs(dst - src) + len) kedahna henteu langkung ageung ti cap() (Kudu aya paling henteu hiji wilayah anu tumpang tindih kontinyu antara src sareng dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src henteu bungkus, dst henteu bungkus
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst sateuacan src, src henteu mungkus, dst ngabungkus
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src sateuacan dst, src henteu mungkus, dst ngabungkus
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst sateuacan src, src bungkus, dst henteu mungkus
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src sateuacan dst, src bungkus, dst henteu mungkus
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst sateuacan src, src bungkus, dst bungkus
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src sateuacan dst, src bungkus, dst bungkus
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs bagian sirah sareng buntut sakurilingna pikeun ngatur kanyataan yén urang ngan ukur réalokasi.
    /// Henteu aman sabab percanten ka old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Mindahkeun bagian anu paling caket tina panyangga ring TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Henteu
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Nyiptakeun `VecDeque` kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Nyiptakeun `VecDeque` kosong kalayan rohangan pikeun sahenteuna elemen `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 kumargi ringbuffer sok nyéépkeun hiji rohangan kosong
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Nyayogikeun rujukan pikeun unsur dina indéks anu ditangtoskeun.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Nyayogikeun rujukan anu tiasa dirobih kana unsur dina indéks anu ditangtoskeun.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Swap elemen dina indéks `i` sareng `j`.
    ///
    /// `i` sareng `j` tiasa sami.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Panics
    ///
    /// Panics upami indéks anu mana waé teu aya watesnana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Mulih jumlah unsur anu `VecDeque` tiasa tahan tanpa reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Cadangan kapasitas minimum pikeun persis `additional` langkung seueur elemen pikeun dilebetkeun dina `VecDeque` anu ditangtoskeun.
    /// Henteu nanaon upami kapasitasna parantos cekap.
    ///
    /// Catet yén alokator tiasa masihan koleksi langkung rohangan tibatan anu dipénta.
    /// Kituna kapasitas moal tiasa diandelkeun janten tepat minimal.
    /// Resep [`reserve`] upami sisipan future diarepkeun.
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas anyar ngabahekeun `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Kapasitas cadangan sahenteuna `additional` langkung seueur unsur pikeun dilebetkeun dina `VecDeque` anu ditangtoskeun.
    /// Koléksi tiasa nyayogikeun langkung seueur rohangan pikeun nyingkahan réliasi anu sering.
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas anyar ngabahekeun `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Nyobian cagar kapasitas minimum pikeun persis `additional` langkung seueur elemen pikeun dilebetkeun kana `VecDeque<T>` anu ditangtoskeun.
    ///
    /// Saatos nelepon `try_reserve_exact`, kapasitas bakal langkung ageung tibatan atanapi sami sareng `self.len() + additional`.
    /// Henteu nanaon upami kapasitasna parantos cekap.
    ///
    /// Catet yén alokator tiasa masihan koleksi langkung rohangan tibatan anu dipénta.
    /// Ku alatan éta, kapasitas teu tiasa diandelkeun janten tepat minimal.
    /// Resep `reserve` upami sisipan future diarepkeun.
    ///
    /// # Errors
    ///
    /// Upami kapasitas ngabahekeun `usize`, atanapi anu ngalaporkeun ngalaporkeun kagagalan, maka aya kasalahan anu dipulangkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pra-cadangan memori, kaluar upami urang teu tiasa
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ayeuna urang terang ieu moal tiasa OOM(Out-Of-Memory) di tengah padamelan rumit urang
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rumit pisan
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Nyobian cagar kapasitas sahenteuna `additional` langkung seueur unsur pikeun dilebetkeun kana `VecDeque<T>` anu ditangtoskeun.
    /// Koléksi tiasa nyayogikeun langkung seueur rohangan pikeun nyingkahan réliasi anu sering.
    /// Saatos nelepon `try_reserve`, kapasitas bakal langkung ageung tibatan atanapi sami sareng `self.len() + additional`.
    /// Henteu nanaon upami kapasitasna parantos cekap.
    ///
    /// # Errors
    ///
    /// Upami kapasitas ngabahekeun `usize`, atanapi anu ngalaporkeun ngalaporkeun kagagalan, maka aya kasalahan anu dipulangkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pra-cadangan memori, kaluar upami urang teu tiasa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ayeuna urang terang ieu moal tiasa OOM di tengah padamelan rumit urang
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // rumit pisan
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Nyusut kapasitas `VecDeque` saloba mungkin.
    ///
    /// Éta bakal lungsur turun sacaket mungkin ka bujur tapi alokator masih tiasa ngawartosan `VecDeque` yén aya rohangan pikeun sababaraha unsur deui.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Shrinks kapasitas nu `VecDeque` ku wates handap.
    ///
    /// Kapasitas bakal tetep sahenteuna sakumaha ageung duanana panjangna sareng nilai anu disayogikeun.
    ///
    ///
    /// Upami kapasitas ayeuna kirang tina wates anu langkung handap, ieu mangrupikeun no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Kami henteu kedah hariwang ngeunaan kabanjiran sabab sanés `self.len()` atanapi `self.capacity()` tiasa `usize::MAX`.
        // +1 sabab ringbuffer sok nyéépkeun hiji rohangan kosong.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Aya tilu kasus minat:
            //   Sakabéh unsur kaluar tina wates anu dipikahoyong Unsur caket, sareng sirah kaluar tina wates anu dipikahoyong Unsur henteu caket, sareng buntutna kaluar tina wates anu dipikahoyong
            //
            //
            // Dina sadaya waktos anu sanés, posisi unsur henteu mangaruhan.
            //
            // Nunjukkeun yén unsur dina sirah kedah dipindahkeun.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Mindahkeun elemen ti luar wates anu dipikahoyong (posisi saatos target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Shortens `VecDeque`, ngajaga elemen `len` munggaran sareng muterkeun sésana.
    ///
    ///
    /// Upami `len` langkung ageung dibanding panjangna 'VecDeque`, ieu moal aya pangaruh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Ngajalankeun destructor pikeun sadaya item dina keureut nalika turun (normal atanapi nalika ngalaunan).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Aman sabab:
        //
        // * Sagala potongan anu dialirkeun ka `drop_in_place` leres;kasus anu kadua ngagaduhan `len <= front.len()` sareng mulih dina `len > self.len()` mastikeun `begin <= back.len()` dina kasus anu munggaran
        //
        // * Sirah VecDeque dipindahkeun sateuacan nelepon `drop_in_place`, janten teu aya nilai anu turun dua kali upami `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Pastikeun babak kadua turun bahkan nalika destruktoror dina mimiti panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Balikkeun iterator payun-ka-balik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Mulang iterator payun-ka-balik anu mulihkeun rujukan anu tiasa dirobih.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SAFETY: invariant kaamanan `IterMut` internal didirikeun sabab
        // `ring` urang jadikan mangrupikeun irisan anu teu tiasa dipisahkeun saumur hirup '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Balikkeun sapasang irisan anu eusina, dina urutan, eusi `VecDeque`.
    ///
    /// Upami [`make_contiguous`] saacanna disebat, sadaya unsur `VecDeque` bakal aya dina keureut kahiji sareng keureut anu kadua bakal kosong.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Balikkeun sapasang irisan anu eusina, dina urutan, eusi `VecDeque`.
    ///
    /// Upami [`make_contiguous`] saacanna disebat, sadaya unsur `VecDeque` bakal aya dina keureut kahiji sareng keureut anu kadua bakal kosong.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Mulih jumlah unsur dina `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Mulih `true` upami `VecDeque` kosong.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Nyiptakeun iterator anu nutupan rentang anu parantos ditangtoskeun dina `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics upami titik awalna langkung ageung tibatan titik tungtung atanapi upami titik tungtung langkung ageung tibatan panjang vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Kisaran lengkep nutupan sadaya eusi
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Rujukan babarengan anu urang gaduh dina &self dijaga dina '_ of Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Nyiptakeun iterator anu nutupan kisaran anu tiasa ditetepkeun dina `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics upami titik awalna langkung ageung tibatan titik tungtung atanapi upami titik tungtung langkung ageung tibatan panjang vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Kisaran lengkep nutupan sadaya eusi
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SAFETY: invariant kaamanan `IterMut` internal didirikeun sabab
        // `ring` urang jadikan mangrupikeun irisan anu teu tiasa dipisahkeun saumur hirup '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Nyiptakeun iterator draining anu ngaluarkeun rentang anu ditangtoskeun dina `VecDeque` sareng ngahasilkeun barang anu dipiceun.
    ///
    /// Catetan 1: Kisaran unsur dipiceun sanajan iterator henteu dikonsumsi dugi ka tungtungna.
    ///
    /// Catetan 2: Henteu ditangtoskeun sabaraha elemen anu dikaluarkeun tina déca, upami nilai `Drain` henteu turun, tapi injeuman anu dicekel kadaluarsana (contona, kusabab `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics upami titik awalna langkung ageung tibatan titik tungtung atanapi upami titik tungtung langkung ageung tibatan panjang vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Jangkauan lengkep ngahapus sadaya eusi
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Kaamanan mémori
        //
        // Nalika Drain munggaran didamel, sumber sumberna disingget pikeun mastikeun yén henteu aya unsur-unsur anu teu dihaja atanapi dipindahkeun-ti unsur tiasa diaksés pisan upami penghancur Drain henteu kantos ngajalankeun.
        //
        //
        // Drain bakal ptr::read kaluar tina nilai pikeun dicabut.
        // Upami réngsé, data sésana bakal disalin deui pikeun nutupan liang, sareng nilai head/tail bakal disimpen deui leres.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Elemen déque dibagi kana tilu bagéan:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Kami nyimpen drain_tail salaku self.head, sareng drain_head sareng self.head sakumaha after_tail sareng after_head masing-masing dina Drain.
        // Ieu ogé motong susunan anu épéktip sapertos kitu upami Drain dibocorkeun, kami parantos hilap ngeunaan nilai anu berpotensi dipindahkeun saatos mimiti drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" ngeunaan nilai saatos mimiti drain dugi saatos drain lengkep sareng penghancur Drain dijalankeun.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Penting, urang ngan ukur nyiptakeun référénsi anu dibagikeun ti `self` di dieu sareng maca tina éta.
                // Kami henteu nyerat ka `self` atanapi reb rebéh kana rujukan anu tiasa dirobih.
                // Maka pointer atah anu urang ciptakeun di luhur, pikeun `deque`, tetep valid.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Mupus `VecDeque`, ngaleungitkeun sadaya nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Mulih `true` upami `VecDeque` ngandung unsur anu sami sareng nilai anu ditangtoskeun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Nyayogikeun rujukan pikeun unsur payun, atanapi `None` upami `VecDeque` kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Nyayogikeun rujukan anu tiasa dirobih kana unsur payun, atanapi `None` upami `VecDeque` kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Nyayogikeun rujukan pikeun unsur tukang, atanapi `None` upami `VecDeque` kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Nyayogikeun rujukan anu tiasa dirobih kana unsur tukang, atanapi `None` upami `VecDeque` kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Ngaleungitkeun unsur anu munggaran sareng balikeun deui, atanapi `None` upami `VecDeque` kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Ngaluarkeun unsur panungtung tina `VecDeque` sareng balikeun deui, atanapi `None` upami kosong.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Nyiapkeun unsur pikeun `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Nambahkeun unsur dina tukang `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Naha urang nganggap `head == 0` hartosna
        // yén `self` caket?
        self.tail <= self.head
    }

    /// Ngaleungitkeun elemen ti mana waé `VecDeque` sareng balikeun deui, ganti ku unsur anu munggaran.
    ///
    ///
    /// Ieu henteu ngajaga urutan, tapi nyaéta *O*(1).
    ///
    /// Mulih `None` upami `index` kaluar tina wates.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Ngaleungitkeun elemen ti mana waé `VecDeque` sareng balikeun deui, ngagantikeun unsur terakhir.
    ///
    ///
    /// Ieu henteu ngajaga urutan, tapi nyaéta *O*(1).
    ///
    /// Mulih `None` upami `index` kaluar tina wates.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Nyelapkeun unsur dina `index` dina `VecDeque`, mindahkeun sadaya unsur ku indéks anu langkung ageung tibatan atanapi sami sareng `index` ka tukang.
    ///
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Panics
    ///
    /// Panics upami `index` langkung ageung tibatan panjangna 'VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Mindahkeun jumlah unsur panglemahna dina ring buffer teras selapkeun obyék anu dipasihkeun
        //
        // Paling len/2, 1 elemen bakal dipindahkeun. O(min(n, n-i))
        //
        // Aya tilu kasus utama:
        //  Unsur anu padeukeut
        //      - kasus khusus nalika buntut nyaéta 0 Unsur henteu paséa sareng sisipanna aya dina bagian buntut Unsur henteu paséa sareng sisipanna aya dina bagian sirah
        //
        //
        // Pikeun masing-masing éta aya dua kasus deui:
        //  Lebetkeun langkung caket kana buntut Lebetkeun langkung caket kana sirah
        //
        // Konci: H, self.head
        //      T, self.tail o, Unsur anu valid I, elemen Lebetkeun A, Unsur anu kedah saatos titik sisipan M, Nuduhkeun unsur dipindahkeun
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // caket, lebetkeun langkung caket kana buntut:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // caket, lebetkeun langkung caket kana buntut sareng buntut nyaéta 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Parantos ngalih buntutna, janten urang ngan ukur nyalin unsur `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // caket, lebetkeun langkung caket kana sirah:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // henteu paséa, lebetkeun langkung caket kana buntut, bagian buntut:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // henteu paséa, lebetkeun langkung caket kana sirah, bagian buntut:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // nyalin elemen nepi ka sirah anyar
                    self.copy(1, 0, self.head);

                    // salin unsur terakhir kana tempat kosong di handapeun buffer
                    self.copy(0, self.cap() - 1, 1);

                    // mindahkeun elemen ti idx ka tungtung payun henteu kalebet ^ elemen
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // henteu paséa, lebetkeun langkung caket kana buntut, bagian sirah, sareng dina indéks enol dina panyangga internal:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // nyalin unsur nepi ka buntut anyar
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // salin unsur terakhir kana tempat kosong di handapeun buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // henteu paséa, lebetkeun langkung caket kana buntut, bagian sirah:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // nyalin unsur nepi ka buntut anyar
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // salin unsur terakhir kana tempat kosong di handapeun buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // mindahkeun elemen ti idx-1 ka tungtung payun henteu kalebet ^ elemen
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // henteu paséa, lebetkeun langkung caket kana sirah, bagian sirah:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // buntut panginten parantos dirobih janten urang kedah ngitung deui
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Ngaleungitkeun sareng mulihkeun unsur dina `index` tina `VecDeque`.
    /// Sakur tungtung anu langkung caket kana titik panyabutan bakal dipindahkeun janten rohangan, sareng sadaya unsur anu kapangaruhan bakal dipindahkeun kana posisi anu énggal.
    ///
    /// Mulih `None` upami `index` kaluar tina wates.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Aya tilu kasus utama:
        //  Unsur anu caket Elemen anu teu jelas sareng pamiceunan dina bagian buntut Elemen anu teu jelas sareng panyabutan dina bagian sirah
        //
        //      - kasus khusus nalika elemen sacara téhnisna caket, tapi self.head =0
        //
        // Pikeun masing-masing éta aya dua kasus deui:
        //  Lebetkeun langkung caket kana buntut Lebetkeun langkung caket kana sirah
        //
        // Konci: H, self.head
        //      T, self.tail o, Unsur valid x, Unsur anu dicirian pikeun ngaleungitkeun Sunda, Nuduhkeun unsur anu dipiceun M, Nuduhkeun unsur dipindahkeun
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // padeukeut, angkat caket kana buntut:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // caket, angkat caket kana sirah:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, piceun ngadeukeutan ka buntut, bagian buntut:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // teu padu, cabut deukeut kana sirah, bagian sirah:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // teu padu, cabut deukeut kana sirah, bagian buntut:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // atanapi kuasi-teu padu, cabut gigireun sirah, bagian buntut:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // ngagambar unsur dina bagian buntut
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Nyegah arus.
                    if self.head != 0 {
                        // salin unsur kahiji kana tempat kosong
                        self.copy(self.cap() - 1, 0, 1);

                        // mindahkeun unsur dina bagian sirah ka tukang
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // teu padu, cabut deukeut kana buntut, bagian sirah:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // gambar unsur nepi ka idx
                    self.copy(1, 0, idx);

                    // salin unsur terakhir kana tempat kosong
                    self.copy(0, self.cap() - 1, 1);

                    // mindahkeun unsur tina buntut ka tungtung payun, teu kaasup anu terakhir
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Beulah `VecDeque` janten dua dina indéks anu ditangtoskeun.
    ///
    /// Balikkeun `VecDeque` anu énggal dikaluarkeun.
    /// `self` ngandung unsur `[0, at)`, sareng `VecDeque` anu balik ngandung unsur `[at, len)`.
    ///
    /// Catet yén kapasitas `self` henteu robih.
    ///
    /// Unsur dina indéks 0 nyaéta payuneun antrian.
    ///
    /// # Panics
    ///
    /// Panics upami `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` perenahna dina babak kahiji.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ngan ukur nyandak sadayana babak kadua.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` perenahna dina babak kadua, kedah faktor dina unsur-unsur anu urang bolos dina babak kahiji.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Bebersih dimana tungtung buffer
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Mindahkeun sadaya unsur `other` kana `self`, ngantepkeun `other` kosong.
    ///
    /// # Panics
    ///
    /// Panics upami jumlah énggal unsur dina dirina nyalira `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // impl naif
        self.extend(other.drain(..));
    }

    /// Ngan ukur unsur-unsur anu ditangtoskeun ku prédikat.
    ///
    /// Kalayan kecap séjén, hapus sadaya unsur `e` sapertos `f(&e)` mulih palsu.
    /// Cara ieu jalan dina tempatna, nganjang ka unggal unsur persis sakali dina urutan aslina, sareng ngajaga urutan unsur-unsur anu dipikagaduh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Urutan anu pasti tiasa dianggo pikeun nyukcruk kaayaan luar, sapertos indéks.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Ieu tiasa panic atanapi ngagugurkeun
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Ganda ukuran panyangga.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Ngarobih `VecDeque` di tempat supados `len()` sami sareng `new_len`, boh ku ngaleungitkeun kaleuleuwihan elemen ti tukang atanapi ku nambihan elemen anu dihasilkeun ku nelepon `generator` ka tukang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Nyusun deui panyimpenan internal tina deque ieu janten salah sahiji bagian anu caket, anu teras dipulangkeun.
    ///
    /// Cara ieu henteu nyayogikeun sareng henteu ngarobih urutan unsur-unsur anu dilebetkeun.Nalika éta ngahasilkeun nyiksikan anu tiasa dirobih, ieu tiasa dianggo pikeun milah deque.
    ///
    /// Sakali panyimpenan internal caket, metode [`as_slices`] sareng [`as_mut_slices`] bakal balikkeun sadayana eusi `VecDeque` dina sapotong.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Nyortir eusi déka.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // nyortir deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // nyortirna dina urutan terbalik
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Kengingkeun aksés anu teu tiasa dirobih kana keureut anu caket.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // urang ayeuna tiasa yakin yén `slice` ngandung sadaya unsur déka, bari tetep aksés henteu tiasa dirobih ka `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // aya cukup ruang kosong pikeun nyalin buntut sakaligus, ieu ngandung harti yén urang mimiti mindahkeun sirah ka tukang, teras salin buntut kana posisi anu leres.
            //
            //
            // ti: DEFGH .... ABC
            // ka: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Kami ayeuna henteu ngémutan .... ABCDEFGH
            // janten caket sabab `head` bakal `0` dina hal ieu.
            // Sanaos kami sigana badé ngarobih ieu sanés sepele sabab sababaraha tempat ngarepkeun `is_contiguous` hartosna yén urang ngan tiasa nyiksikan nganggo `buf[tail..head]`.
            //
            //

            // aya cukup ruang kosong pikeun nyalin sirah dina sakali jalan, ieu ngandung harti yén urang mimiti mindahkeun buntut payun, teras nyalin sirah kana posisi anu leres.
            //
            //
            // ti: FGH .... ABCDE
            // ka: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // gratis langkung alit tibatan sirah sareng buntut, ieu hartosna urang kedah lalaunan "swap" buntut sareng sirah.
            //
            //
            // ti: EFGHI ... ABCD atanapi HIJK.ABCDEFG
            // ka: ABCDEFGHI ... atanapi ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Masalah umum siga GHIJKLM ieu ... ABCDEF, sateuacan aya pertukaran ABCDEFM ... GHIJKL, saatos 1 kali swap ABCDEFGHIJM ... KL, gentos dugi ka edge kénca dugi ka toko temp
                //                  - teras balikan deui algoritma ku toko (smaller) énggal Kadang-kadang toko temp kahontal nalika edge katuhu aya dina tungtung buffer, ieu hartosna urang pencét urutan anu leres kalayan sakedik swap!
                //
                // E.g
                // EF..ABCD ABCDEF .., saatos opat ngan ukur pertukaran urang parantos bérés
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Muterkeun antrian `mid` antrian dua kali dua kénca.
    ///
    /// Equivalently,
    /// - Muterkeun barang `mid` kana posisi anu munggaran.
    /// - Pops barang `mid` munggaran sareng dorong dugi ka tungtungna.
    /// - Muterkeun tempat `len() - mid` ka katuhu.
    ///
    /// # Panics
    ///
    /// Upami `mid` langkung ageung tibatan `len()`.
    /// Catet yén `mid == len()` ngalakukeun _not_ panic sareng mangrupakeun rotasi no-op.
    ///
    /// # Complexity
    ///
    /// Butuh waktos `*O*(min(mid, len() - mid))` sareng henteu aya rohangan tambahan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Muterkeun antrian `k` antrian dua kali ka katuhu.
    ///
    /// Equivalently,
    /// - Muterkeun barang anu mimiti kana posisi `k`.
    /// - Pops barang `k` pamungkas teras ngadorong ka payun.
    /// - Muterkeun tempat `len() - k` ka kénca.
    ///
    /// # Panics
    ///
    /// Upami `k` langkung ageung tibatan `len()`.
    /// Catet yén `k == len()` ngalakukeun _not_ panic sareng mangrupakeun rotasi no-op.
    ///
    /// # Complexity
    ///
    /// Butuh waktos `*O*(min(k, len() - k))` sareng henteu aya rohangan tambahan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: dua padamelan ieu ngabutuhkeun jumlah rotasi
    // janten kirang ti satengah panjang déque.
    //
    // `wrap_copy` ngabutuhkeun `min(x, cap() - x) + copy_len <= cap()`, tapi tibatan `min` henteu kantos langkung ti satengah kapasitas, henteu paduli x, janten sora pikeun nelepon di dieu sabab kami nganuhunkeun ku hal anu kirang ti satengah panjangna, anu henteu pernah aya di luhur satengah kapasitas.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binér milarian `VecDeque` ieu milah unsur anu parantos dipasihkeun.
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.
    /// Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    ///
    /// # Examples
    ///
    /// Milarian runtuyan opat unsur.
    /// Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Upami anjeun badé ngalebetkeun barang kana `VecDeque` anu diurutkeun, bari ngajaga urutan:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binér milarian `VecDeque` ieu diurutkeun kalayan fungsi komparator.
    ///
    /// Fungsi komparator kedah nerapkeun urutan anu saluyu sareng urutan sortir tina `VecDeque` anu ngadasarkeun, mulihkeun kode urutan anu nunjukkeun naha argumen na nyaéta `Less`, `Equal` atanapi `Greater` tibatan target anu dipikahoyong.
    ///
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    /// # Examples
    ///
    /// Milarian runtuyan opat unsur.Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binér milarian `VecDeque` ieu diurutkeun kalayan fungsi ékstraksi konci.
    ///
    /// Nganggap yén `VecDeque` diurutkeun ku konci, contona sareng [`make_contiguous().sort_by_key()`](#method.make_contiguous) nganggo fungsi ékstraksi konci anu sami.
    ///
    ///
    /// Upami nilai dipanggihan maka [`Result::Ok`] dipulangkeun, ngandung indéks unsur anu cocog.
    /// Upami aya sababaraha pertandingan, maka salah sahiji pertandingan tiasa dipulangkeun.
    /// Upami nilaina henteu kapendak maka [`Result::Err`] dipulangkeun, ngandung indéks dimana unsur anu cocog tiasa dilebetkeun nalika ngajaga urutan anu diurutkeun.
    ///
    /// # Examples
    ///
    /// Néangan séri opat unsur dina sapotong pasang diurut ku unsur kadua na.
    /// Anu munggaran dipendakan, kalayan posisi anu ditangtukeun sacara unik;kadua sareng katilu teu kapendak;anu kaopat tiasa cocog sareng posisi naon dina `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Ngarobih `VecDeque` di tempat supados `len()` sami sareng new_len, boh ku ngaleungitkeun kaleuleuwihan elemen ti tukang atanapi ku nambihan klon `value` ka tukang.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Balikkeun indéks dina panyangga dasar pikeun indéks unsur logis anu ditangtoskeun.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ukuranana salawasna kakuatan 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Itung jumlah unsur anu bakal dibaca dina panyangga
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ukuranana salawasna kakuatan 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Salawasna tiasa dibagi dina tilu bagian, contona: diri: [a b c|d e f] anu sanésna: [0 1 2 3|4 5] payun=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Henteu mungkin pikeun nganggo Hash::hash_slice dina keureut anu dipulang ku metode as_slices sabab panjangna tiasa bénten-bénten deui ogé anu sami.
        //
        //
        // Hasher ngan ngajamin kasetaraan pikeun set telepon anu sami sareng metode na.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ngonsumsi `VecDeque` kana iterator panghareup-hareup ngahasilkeun unsur ku nilai.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Fungsi ieu kedah sami sareng:
        //
        //      pikeun barang dina iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Ngarobih [`Vec<T>`] kana [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ieu nyingkahan réalokasi dimana dimungkinkeun, tapi kaayaan anu ketat, sareng tiasa robih, janten henteu kedah diandelkeun upami `Vec<T>` asalna tina `From<VecDeque<T>>` sareng henteu acan dialokasikan deui.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Teu aya alokasi anu saleresna pikeun ZST salempang ngeunaan kapasitas, tapi `VecDeque` henteu tiasa nahan sakumaha panjangna `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Urang kedah ngarobah ukuran upami kapasitas sanés kakuatan dua, leutik teuing atanapi henteu ngagaduhan sahanteuna hiji rohangan gratis.
            // Kami ngalakukeun ieu nalika éta masih dina `Vec` sahingga barang bakal lungsur dina panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Ngarobih [`VecDeque<T>`] kana [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Ieu henteu kedah alokasi deui, tapi kedah ngalakukeun gerakan data O *(* n *) upami buffer sirkular henteu aya dina awal alokasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Anu ieu nyaéta *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Anu ieu peryogi ngarobih data.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}