#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Eusi mémori énggal henteu dihaja.
    Uninitialized,
    /// Mémori anyar dijamin bakal nol.
    Zeroed,
}

/// Mangpaat tingkat handap pikeun langkung sacara ergonomis nyayogikeun, ngawartosan deui, sareng ngicalkeun panyangga mémori dina tumpukan tanpa kedah hariwang ngeunaan sadaya kasus sudut anu aya.
///
/// Jenis ieu alus teuing pikeun ngawangun struktur data anjeun nyalira sapertos Vec sareng VecDeque.
/// Khususna:
///
/// * Ngahasilkeun `Unique::dangling()` dina jinis ukuran nol.
/// * Ngahasilkeun `Unique::dangling()` dina alokasi nol-panjang.
/// * Nyingkahan ngabébaskeun `Unique::dangling()`.
/// * Nyekel sadaya limpahan dina ngitung kapasitas (ngamajukeun ka "capacity overflow" panics).
/// * Penjaga ngalawan sistem 32-bit anu nyayogikeun langkung ti isize::MAX bait.
/// * Penjaga ngalawan kaleuleuwihan panjang anjeun.
/// * Nelepon `handle_alloc_error` pikeun alokasi fallible.
/// * Ngandung `ptr::Unique` sahingga ngabayangkeun pangguna nganggo sadaya kauntungan anu aya hubunganana.
/// * Ngagunakeun kaleuwihan anu dipulangkeun ti alokasi pikeun nganggo kapasitas anu sayogi panggedéna.
///
/// Jenis ieu henteu tetep mariksa mémori anu dikokolakeunana.Nalika muragkeun éta *bakal* ngabébaskeun mémori na, tapi éta moal * nyobian lungsur eusina.
/// Éta dugi ka pangguna `RawVec` pikeun nanganan hal-hal anu saleresna *disimpen* di jero `RawVec`.
///
/// Catet yén kaleuleuwihan jinis ukuran enol sok teu aya watesna, janten `capacity()` sok mulih `usize::MAX`.
/// Ieu ngandung harti yén anjeun kedah ati-ati nalika bulat-ngalanggar jinis ieu nganggo `Box<[T]>`, kumargi `capacity()` moal ngahasilkeun panjang.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ieu aya kusabab `#[unstable]` `const fn`s teu kedah akur sareng `min_const_fn` sahingga aranjeunna moal tiasa disebat dina`min_const_fn`s ogé.
    ///
    /// Lamun ngarobah `RawVec<T>::new` atawa kabebasan, mangga jaga mun teu ngenalkeun sagala hal anu sabenerna bakal ngalanggar `min_const_fn`.
    ///
    /// NOTE: Urang tiasa nyingkahan hack ieu sareng mariksa kasaluyuan sareng sababaraha atribut `#[rustc_force_min_const_fn]` anu meryogikeun kasaluyuan sareng `min_const_fn` tapi henteu merta ngijinkeun nyauran éta dina `stable(...) const fn`/kode pangguna anu henteu ngamungkinkeun `foo` nalika `#[rustc_const_unstable(feature = "foo", issue = "01234")]` aya.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Nyiptakeun mungkin `RawVec` pangageungna (dina tumpukan sistem) tanpa alokasi.
    /// Upami `T` ngagaduhan ukuran positip, maka ieu ngajadikeun `RawVec` kalayan kapasitas `0`.
    /// Upami `T` ukuranana nol, maka éta ngajadikeun `RawVec` kalayan kapasitas `usize::MAX`.
    /// Baguna pikeun nerapkeun alokasi anu tunda.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Nyiptakeun `RawVec` (dina tumpukan sistem) kalayan persis kapasitas sareng kabutuhan alignment pikeun `[T; capacity]`.
    /// Ieu sami sareng nelepon `RawVec::new` nalika `capacity` nyaéta `0` atanapi `T` saukuran nol.
    /// Catet yén upami `T` ukuranana nol ieu hartosna anjeun moal * kéngingkeun `RawVec` kalayan kapasitas anu dipénta.
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas anu dipénta ngaleuwihan `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Dipotong dina OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Sapertos `with_capacity`, tapi ngajamin panyangga ditoler.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ngatur deui `RawVec` tina panunjuk sareng kapasitas.
    ///
    /// # Safety
    ///
    /// `ptr` kedah dialokasikan (dina tumpukan sistem), sareng `capacity` anu ditangtoskeun.
    /// `capacity` moal tiasa ngaleuwihan `isize::MAX` pikeun ukuran anu ukuran.(ngan ukur masalah dina sistem 32-bit).
    /// ZST vectors mungkin gaduh kapasitas dugi ka `usize::MAX`.
    /// Upami `ptr` sareng `capacity` asalna tina `RawVec`, maka ieu dijamin.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs leutik belet.Luncat ka:
    // - 8 upami ukuran unsur na 1, sabab mana waé anu ngadeudeul tumpukan sigana bakal bulatkeun paménta kirang ti 8 bait dugi sahenteuna 8 bait.
    //
    // - 4 upami unsur ukuran-sedeng (<=1 KiB).
    // - 1 sanésna, pikeun nyingkahan nyéépkeun teuing rohangan pikeun Vecs anu pondok pisan.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Siga `new`, tapi parameterisasi dina pilihan pamilih pikeun `RawVec` anu balik.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` hartosna "unallocated".jenis nol-ukuran teu dipaliré.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Siga `with_capacity`, tapi parameterisasi dina pilihan pamilih pikeun `RawVec` anu balik.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Siga `with_capacity_zeroed`, tapi parameterisasi dina pilihan pamilih pikeun `RawVec` anu balik.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Ngarobih `Box<[T]>` kana `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Ngarobih sadaya panyangga kana `Box<[MaybeUninit<T>]>` kalayan `len` anu ditangtoskeun.
    ///
    /// Catet yén ieu leres bakal ngawangun naon waé perobihan `cap` anu panginten parantos dilakukeun.(Tingali katerangan jinis pikeun detil.)
    ///
    /// # Safety
    ///
    /// * `len` kedah langkung ageung tibatan atanapi sami sareng kapasitas anu paling anyar dipénta, sareng
    /// * `len` kedah kirang ti atanapi sami sareng `self.capacity()`.
    ///
    /// Catetan, yén kapasitas anu dipénta sareng `self.capacity()` tiasa bénten-bénten, sabab hiji alokasi tiasa langkung seueur teuing sareng ngabalikeun blok memori anu langkung ageung tibatan anu dipénta.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-mariksa saparo sarat kaamanan (kami henteu tiasa mariksa anu sanés).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Kami nyingkahan `unwrap_or_else` di dieu sabab ngahasilkeun jumlah LLVM IR anu dihasilkeun.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ngadaptarkeun `RawVec` tina panunjuk, kapasitas, sareng alokasi.
    ///
    /// # Safety
    ///
    /// `ptr` kedah dialokasikeun (ngalangkungan alokasi `alloc`), sareng `capacity` anu ditangtoskeun.
    /// `capacity` moal tiasa ngaleuwihan `isize::MAX` pikeun ukuran anu ukuran.
    /// (ngan ukur masalah dina sistem 32-bit).
    /// ZST vectors mungkin gaduh kapasitas dugi ka `usize::MAX`.
    /// Upami `ptr` sareng `capacity` asalna tina `RawVec` anu didamel ngalangkungan `alloc`, maka ieu dijamin.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Meunangkeun petunjuk atah pikeun ngamimitian alokasi.
    /// Catet yén ieu `Unique::dangling()` upami `capacity == 0` atanapi `T` ukuranana nol.
    /// Dina kasus anu tilas, anjeun kedah ati-ati.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Meunang kapasitas alokasi.
    ///
    /// Ieu bakal `usize::MAX` upami `T` ukuranana nol.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Mulihkeun rujukan anu dibagi kana alokasi anu nyokong `RawVec` ieu.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Kami gaduh sakumpulan memori anu dialokasikeun, janten urang tiasa jalan pintas pikeun mariksa runtime pikeun nampi tata perenah urang ayeuna.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Mastikeun yén panyangga ngandung sahanteuna cekap rohangan pikeun nahan unsur `len + additional`.
    /// Upami éta henteu acan gaduh kapasitas anu cekap, bakal nyéépkeun ruang anu cekap ditambah rohangan kendor anu raoseun pikeun dilunasan *O*(1) tingkah laku.
    ///
    /// Bakal ngawatesan kabiasaan ieu upami éta perlu nyababkeun panic.
    ///
    /// Upami `len` ngaleuwihan `self.capacity()`, ieu panginten gagal pikeun leres-leres masihan ruang anu dipénta.
    /// Ieu leres henteu aman, tapi kode henteu aman *anjeun* nyerat anu ngandelkeun paripolah fungsi ieu tiasa rusak.
    ///
    /// Ieu idéal pikeun ngalaksanakeun operasi bulk-push kawas `extend`.
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas énggal ngaleungitkeun `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Dipotong dina OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // cadangan bakal ngabatalkeun atanapi panik upami len ngaleuwihan `isize::MAX` janten aman pikeun dipilarian ayeuna.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Sarua sareng `reserve`, tapi mulih deui kana kasalahan tibatan panik atanapi ngagugurkeun.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Mastikeun yén panyangga ngandung sahanteuna cekap rohangan pikeun nahan unsur `len + additional`.
    /// Upami éta henteu acan, bakalan reallocate kamungkinan minimum mémori anu diperyogikeun.
    /// Umumna ieu bakalan persis jumlah mémori anu diperyogikeun, tapi dina prinsipna alokator bébas masihan deui langkung ti anu dipénta.
    ///
    ///
    /// Upami `len` ngaleuwihan `self.capacity()`, ieu panginten gagal pikeun leres-leres masihan ruang anu dipénta.
    /// Ieu leres henteu aman, tapi kode henteu aman *anjeun* nyerat anu ngandelkeun paripolah fungsi ieu tiasa rusak.
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas énggal ngaleungitkeun `isize::MAX` bait.
    ///
    /// # Aborts
    ///
    /// Dipotong dina OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Sarua sareng `reserve_exact`, tapi mulih deui kana kasalahan tibatan panik atanapi ngagugurkeun.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Nyusut alokasi turun kana jumlah anu ditangtoskeun.
    /// Upami jumlah anu disayogikeun nyaéta 0, leres-leres leres-leres transaksi.
    ///
    /// # Panics
    ///
    /// Panics upami jumlah anu dipasihkeun *langkung ageung* tibatan kapasitas ayeuna.
    ///
    /// # Aborts
    ///
    /// Dipotong dina OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Mulih upami panyangga kedah tumuh pikeun minuhan kapasitas tambahan anu diperyogikeun.
    /// Utamana dipaké pikeun nyieun inlining cadangan-panggero mungkin tanpa inlining `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Cara ieu biasana diasongkeun sababaraha kali.Janten urang hoyong janten sakedik mungkin, pikeun ningkatkeun waktos nyusun.
    // Tapi kami ogé hoyong saloba eusina janten tiasa diitung sacara statis sabisa, supados kode anu dihasilkeun dijalankeun langkung gancang.
    // Ku alatan éta, metoda ieu ditulis sacara saksama sahingga sadaya kode anu gumantung kana `T` aya di jerona, sedengkeun seueur kode anu henteu gumantung kana `T` sabisa aya dina fungsi anu non-generik langkung `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ieu dijamin ku kontéks nelepon.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Kusabab urang balikkeun kapasitas `usize::MAX` nalika `elem_size` nyaéta
            // 0, dugi ka dieu pasti hartosna `RawVec` langkung seueur.
            return Err(CapacityOverflow);
        }

        // Henteu aya anu leres-leres tiasa dilakukeun ngeunaan cek ieu, hanjakalna.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ieu ngajamin pertumbuhan éksponénsial.
        // Dobel moal tiasa kabanjiran kusabab `cap <= isize::MAX` sareng jinis `cap` nyaéta `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nyaéta non-generik langkung `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Konstrain dina metode ieu sami sareng anu di `grow_amortized`, tapi cara ieu biasana instantiasi kirang sering janten kirang kritis.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Kusabab urang balikkeun kapasitas `usize::MAX` nalika ukuran ukuran na
            // 0, dugi ka dieu pasti hartosna `RawVec` langkung seueur.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nyaéta non-generik langkung `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Fungsi ieu diluar `RawVec` pikeun ngaleutikan waktos kompilasi.Tingali koméntar di luhur `RawVec::grow_amortized` pikeun detil.
// (Parameter `A` henteu penting, kusabab jumlah jinis `A` anu béda dina prakték langkung alit tibatan jumlah jenis `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Pariksa kasalahan di dieu pikeun ngaleutikan ukuran `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokator mariksa persamaan penjajaran
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ngaleupaskeun memori anu dipimilik ku `RawVec`*tanpa* nyobian lungsur eusina.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Fungsi sentral pikeun penanganan kasalahan cadangan.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Urang kedah ngajamin hal-hal ieu:
// * Kami henteu kantos masihan objék ukuran byte `> isize::MAX`.
// * Kami henteu ngabahekeun `usize::MAX` sareng leres-leres masihan sakedik teuing.
//
// Dina 64-bit urang ngan kedah parios kabanjiran kumargi nyobian nyebarkeun bait `> isize::MAX` pasti bakal gagal.
// Dina 32-bit sareng 16-bit urang kedah nambihan penjaga tambahan pikeun ieu upami urang ngajalankeun dina platform anu tiasa nganggo sadayana 4GB dina rohangan pangguna, misal, PAE atanapi x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Hiji fungsi pusat anu tanggung jawab ngalaporkeun overflows kapasitas.
// Ieu bakal mastikeun yén generasi kode anu aya hubungan sareng panics ieu minimal sabab ngan ukur aya hiji lokasi anu panics tinimbang kebat sapanjang modul.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}