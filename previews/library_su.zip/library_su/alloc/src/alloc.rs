//! API alokasi mémori

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ieu mangrupikeun simbol sihir pikeun nyebat alokasi global.rustc ngahasilkeun aranjeunna pikeun nelepon `__rg_alloc` jsb.
    // upami aya atribut `#[global_allocator]` (kode ngembangna atribut makro ngahasilkeun fungsi-fungsi éta), atanapi nelepon implementasi standar dina libstd (`__rdl_alloc` jsb.
    //
    // dina `library/std/src/alloc.rs`) sanésna.
    // rustc fork of LLVM ogé khusus-kasus ngaran fungsi ieu pikeun ngaoptimalkeunana masing-masing sapertos `malloc`, `realloc`, sareng `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Alokasi mémori global.
///
/// Jenis ieu ngalaksanakeun [`Allocator`] trait ku neraskeun telepon ka alokasi anu didaptarkeun sareng atribut `#[global_allocator]` upami aya, atanapi standar `std` crate's.
///
///
/// Note: bari jinis ieu henteu stabil, fungsionalitas anu disayogikeun tiasa diaksés ngalangkungan [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Alokasi mémori sareng alokasi global.
///
/// Fungsi ieu payun nyauran metoda [`GlobalAlloc::alloc`] tina alokasi anu didaptarkeun sareng atribut `#[global_allocator]` upami aya, atanapi standar `std` crate's.
///
///
/// Pungsi ieu diperkirakeun diturunkeun ku metode `alloc` tina jinis [`Global`] nalika éta sareng [`Allocator`] trait janten stabil.
///
/// # Safety
///
/// Tingali [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Memperlokasi mémori sareng alokasi global.
///
/// Fungsi ieu payun nyauran metoda [`GlobalAlloc::dealloc`] tina alokasi anu didaptarkeun sareng atribut `#[global_allocator]` upami aya, atanapi standar `std` crate's.
///
///
/// Pungsi ieu diperkirakeun diturunkeun ku metode `dealloc` tina jinis [`Global`] nalika éta sareng [`Allocator`] trait janten stabil.
///
/// # Safety
///
/// Tingali [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Alokasi memori sareng alokasi global.
///
/// Fungsi ieu payun nyauran metoda [`GlobalAlloc::realloc`] tina alokasi anu didaptarkeun sareng atribut `#[global_allocator]` upami aya, atanapi standar `std` crate's.
///
///
/// Pungsi ieu diperkirakeun diturunkeun ku metode `realloc` tina jinis [`Global`] nalika éta sareng [`Allocator`] trait janten stabil.
///
/// # Safety
///
/// Tingali [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Alokasi mémori nol-inisialisasi ku alokasi global.
///
/// Fungsi ieu payun nyauran metoda [`GlobalAlloc::alloc_zeroed`] tina alokasi anu didaptarkeun sareng atribut `#[global_allocator]` upami aya, atanapi standar `std` crate's.
///
///
/// Pungsi ieu diperkirakeun diturunkeun ku metode `alloc_zeroed` tina jinis [`Global`] nalika éta sareng [`Allocator`] trait janten stabil.
///
/// # Safety
///
/// Tingali [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SAFETY: `layout` ukuranana henteu nol,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // Kaamanan: Sarua sareng `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SAFETY: `new_size` nyaéta non-zero sabab `old_size` langkung ageung tibatan atanapi sami sareng `new_size`
            // sakumaha diperlukeun ku kaayaan kaamanan.Kaayaan sanésna kedah dijaga ku anu nelepon
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` sigana cek `new_size >= old_layout.size()` atanapi anu sami.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: sabab `new_layout.size()` kedah langkung ageung tibatan atanapi sami sareng `old_size`,
            // boh alokasi mémori lami sareng énggal valid pikeun maca sareng nyerat `old_size` bait.
            // Ogé, kusabab alokasi anu lami teu acan diuruskeun, éta moal tiasa tumpang tindih `new_ptr`.
            // Ku kituna, panggero pikeun `copy_nonoverlapping` aman.
            // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SAFETY: `layout` ukuranana henteu nol,
            // kaayaan sanésna kedah dijaga ku anu nelepon
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: sadaya kaayaan kedah dijaga ku anu nelepon
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: sadaya kaayaan kedah dijaga ku anu nelepon
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // KESELAMATAN: kaayaan kedah dijaga ku anu nelepon
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // Kaamanan: `new_size` henteu nol.Kaayaan sanésna kedah dijaga ku anu nelepon
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` sigana cek `new_size <= old_layout.size()` atanapi anu sami.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SAFETY: sabab `new_size` kedah langkung alit tibatan atanapi sami sareng `old_layout.size()`,
            // boh alokasi mémori lami sareng énggal valid pikeun maca sareng nyerat `new_size` bait.
            // Ogé, kusabab alokasi anu lami teu acan diuruskeun, éta moal tiasa tumpang tindih `new_ptr`.
            // Ku kituna, panggero pikeun `copy_nonoverlapping` aman.
            // Kontrak kaamanan pikeun `dealloc` kedah dijaga ku anu nelepon.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Alokasi pikeun petunjuk anu unik.
// Pungsi ieu kedah teu ngéngklak.Upami éta leres, MIR codegen bakal gagal.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Tanda tangan ieu kedah sami sareng `Box`, upami teu kitu ICE bakal kajadian.
// Nalika parameter tambihan kana `Box` ditambihan (sapertos `A: Allocator`), ieu kedah ditambihan ogé di dieu.
// Misalna upami `Box` dirobih janten `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, fungsi ieu kedah dirobih janten `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ogé.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Panyawat kasalahan alokasi

extern "Rust" {
    // Ieu mangrupikeun simbol sihir pikeun nelepon pawang kasalahan alokasi global.
    // rustc ngahasilkeun éta pikeun nelepon `__rg_oom` upami aya `#[alloc_error_handler]`, atanapi nyauran standar implementasi di handap (`__rdl_oom`) sanésna.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abort dina kasalahan alokasi mémori atanapi kagagalan.
///
/// Anu nelepon API alokasi mémori anu hoyong ngiringan perhitungan salaku tanggepan kana kasalahan alokasi didorong pikeun nelepon fungsi ieu, tibatan langsung nyungkeun `panic!` atanapi anu sami.
///
///
/// Paripolah standar tina pungsi ieu nyaéta nyetak pesen pikeun kasalahan standar sareng ngagugurkeun prosésna.
/// Éta tiasa digentos ku [`set_alloc_error_hook`] sareng [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Pikeun uji alokasi `std::alloc::handle_alloc_error` tiasa dianggo langsung.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // disebut via dihasilkeun `__rust_alloc_error_handler`

    // upami teu aya `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // upami aya `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Hususkeun klon kana mémori anu tos teu dialokasikeun.
/// Dipaké ku `Box::clone` sareng `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Saatos dialokasikan *heula* tiasa ngijinkeun pangoptimal pikeun nyiptakeun nilai diklon dina tempatna, ngalangkungan lokal sareng ngalih.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Kami salawasna tiasa nyalin di tempat, tanpa ngalibatkeun nilai lokal.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}