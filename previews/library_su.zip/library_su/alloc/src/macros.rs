/// Nyiptakeun [`Vec`] anu ngandung alesan.
///
/// `vec!` ngamungkinkeun `Vec`s dihartikeun sareng sintaksis anu sami sareng ekspresi susunan.
/// Aya dua bentuk makro ieu:
///
/// - Ngadamel [`Vec`] anu ngandung daptar unsur anu tangtu:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Ngadamel [`Vec`] tina unsur sareng ukuran anu ditangtoskeun:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Catet yén teu sapertos ungkapan rangkep sintaksis ieu ngadukung sadaya unsur anu ngalaksanakeun [`Clone`] sareng jumlah unsur henteu kedah angger-angger.
///
/// Ieu bakal nganggo `clone` pikeun ngaduplikasi ungkapan, janten anu kedah ati-ati nganggo ieu sareng jinis anu ngagaduhan implementasi `Clone` anu teu standar.
/// Salaku conto, `vec![Rc::new(1);5] `bakal nyiptakeun vector tina lima référénsi kana nilai wilangan buleud anu sami, sanés lima référénsi anu nunjuk kana bilangan bulat sacara mandiri.
///
///
/// Ogé, perhatoskeun yén `vec![expr; 0]` diidinan, sareng ngahasilkeun vector kosong.
/// Ieu masih bakal mengevaluasi `expr`, nanging, sareng langsung lungsur nilai anu dihasilkeun, janten épék kana efek samping.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): kalayan cfg(test) metoda `[T]::into_vec` alami, anu diperyogikeun pikeun definisi makro ieu, henteu sayogi.
// Sabalikna nganggo fungsi `slice::into_vec` anu ngan sayogi ku cfg(test) NB tingali modul slice::hack dina slice.rs kanggo langkung seueur inpormasi
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Nyiptakeun `String` nganggo interpolasi ungkapan runtime.
///
/// Argumen munggaran anu `format!` nampi nyaéta senar format.Ieu kedah janten literal literal.Kakuatan senar pormat aya dina `{}` anu dikandung.
///
/// Parameter tambihan anu dikintunkeun ka `format!` ngagentos `{}` s dina string pormat dina urutan anu dipasihkeun kecuali dingaranan atanapi parameter posisional anu dianggo;tingali [`std::fmt`] pikeun langkung seueur inpormasi.
///
///
/// Pamakéan umum pikeun `format!` nyaéta konjétasi sareng interpolasi senar.
/// Konvénsi anu sami dianggo kalayan makro [`print!`] sareng [`write!`], gumantung kana tujuan anu dituju tina senar.
///
/// Pikeun ngarobih hiji nilai kana senar, anggo metode [`to_string`].Ieu bakal nganggo [`Display`] pormat trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics upami pamformatan trait ngalaksanakeun kasalahan.
/// Ieu nunjukkeun palaksanaan anu salah kumargi `fmt::Write for String` henteu kantos ngasilkeun kasalahan nyalira.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Angkatan AST simpul kana ungkapan pikeun ningkatkeun diagnostik dina posisi pola.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}