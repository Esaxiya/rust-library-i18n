//! Nunjuk-ngitung rujukan-étang-tunggal.'Rc' singkatan tina 'Rujukan
//! Counted'.
//!
//! Jinis [`Rc<T>`][`Rc`] nyayogikeun kapamilikan babarengan jinis `T`, dialokasikan dina tumpukan.
//! Invoking [`clone`][clone] on [`Rc`] ngahasilkeun panunjuk anyar kana alokasi anu sami dina tumpukan.
//! Nalika pointer [`Rc`] terakhir kana alokasi anu ditumpes musnah, nilai anu disimpen dina alokasi éta (sering disebut "inner value") ogé turun.
//!
//! Rujukan anu dibagikeun dina Rust teu kéngingkeun mutasi sacara standar, sareng [`Rc`] henteu terkecuali: anjeun moal umum tiasa kéngingkeun rujukan anu tiasa dirobih pikeun anu aya dina [`Rc`].
//! Upami anjeun peryogi mutabilitas, nempatkeun [`Cell`] atanapi [`RefCell`] dina [`Rc`];tingali [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] ngagunakeun cacah rujukan non-atom.
//! Ieu ngandung harti yén overhead lemah pisan, tapi [`Rc`] henteu tiasa dikirim antara utas, sareng akibatna [`Rc`] henteu nerapkeun [`Send`][send].
//! Hasilna, panyusun Rust bakal mariksa *dina waktos nyusun* yén anjeun henteu ngirimkeun [`Rc`] antara benang.
//! Upami anjeun peryogi multi-utas, étang rujukan atom, anggo [`sync::Arc`][arc].
//!
//! Metoda [`downgrade`][downgrade] tiasa dianggo pikeun nyiptakeun pointer [`Weak`] anu teu kagungan.
//! A [`Weak`] pointer tiasa [`upgrade`][upgrade] d kana [`Rc`], tapi ieu bakal balik [`None`] upami nilai anu disimpen dina alokasi parantos lungsur.
//! Kalayan kecap séjén, `Weak` pointers henteu nyimpen nilaina dina alokasi hirup;Nanging, aranjeunna *ngajaga* alokasi (toko pangrojong pikeun nilai batin) tetep hirup.
//!
//! Siklus antara [`Rc`] pointers moal pernah dirobih.
//! Kusabab kitu, [`Weak`] digunakeun pikeun megatkeun siklus.
//! Salaku conto, tangkal tiasa ngagaduhan petunjuk [`Rc`] anu kuat ti titik indung ka budak, sareng [`Weak`] petunjuk ti budak deui ka kolotna.
//!
//! `Rc<T>` otomatis dereferénsi ka `T` (ngalangkungan [`Deref`] trait), janten anjeun tiasa nyauran metode `T` dina nilai jinis [`Rc<T>`][`Rc`].
//! Pikeun ngahindaran bentrok nami sareng metode `T`, metode [`Rc<T>`][`Rc`] nyalira aya fungsi anu pakait, disebat nganggo [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>"Palaksanaan traits sapertos `Clone` ogé tiasa disebat nganggo sintaksis anu mumpuni.
//! Sababaraha jalma resep ngagunakeun sintaksis anu mumpuni, sedengkeun anu sanés resep ngagunakeun sintaksis-panggero sintaksis.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaksis metode-panggero
//! let rc2 = rc.clone();
//! // Sintaksis mumpuni lengkep
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] henteu otomatis-ngahakan kana `T`, sabab nilai batinna panginten parantos turun.
//!
//! # Rujukan kloning
//!
//! Nyiptakeun rujukan énggal kana alokasi anu sami salaku rujukan anu diitung pitunjuk parantos dilakukeun nganggo `Clone` trait anu dilaksanakeun pikeun [`Rc<T>`][`Rc`] sareng [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dua sintaksis ieu di handap sami.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a sareng b duanana nunjuk kana lokasi memori anu sami sareng foo.
//! ```
//!
//! Sintaksis `Rc::clone(&from)` mangrupikeun idiomatik anu paling idiomatik sabab éta langkung jelas ngeunaan hartos kode.
//! Dina conto di luhur, sintaksis ieu matak ngamudahkeun pikeun ningali yén kode ieu nyiptakeun rujukan énggal tibatan nyalin sadaya eusi foo.
//!
//! # Examples
//!
//! Mertimbangkeun skénario dimana sakumpulan `Gadget`s dipimilik ku `Owner` tinangtu.
//! Kami hoyong gaduh `Gadget`s nunjukkeun `Owner` na.Kami henteu tiasa ngalakukeun ieu ku kapamilikan unik, sabab langkung ti hiji gadget tiasa kagolong kana `Owner` anu sami.
//! [`Rc`] ngamungkinkeun urang pikeun ngabagi `Owner` antara sababaraha `Gadget`s, sareng gaduh `Owner` tetep dialokasikeun salami aya `Gadget` poin dina éta.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... sawah séjén
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... sawah séjén
//! }
//!
//! fn main() {
//!     // Ngadamel `Owner` rujukan-diitung.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Ngadamel `Gadget`s milik `gadget_owner`.
//!     // Kloning `Rc<Owner>` masihan kami pitunjuk énggal pikeun alokasi `Owner` anu sami, nambahan jumlah référénsi dina prosés.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Buang variabel lokal `gadget_owner` kami.
//!     drop(gadget_owner);
//!
//!     // Sanaos muterna `gadget_owner`, urang masih tiasa nyetak nami `Owner` tina `Gadget`s.
//!     // Ieu kusabab urang ngan ukur muragkeun hiji `Rc<Owner>`, sanés `Owner` anu ditunjukna.
//!     // Salami aya `Rc<Owner>` anu nunjuk kana alokasi `Owner` anu sami, éta bakal tetep hirup.
//!     // Proyéksi lapangan `gadget1.owner.name` tiasa dianggo kusabab `Rc<Owner>` sacara otomatis ngaleungitkeun `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Dina akhir pungsi, `gadget1` sareng `gadget2` musnah, sareng aranjeunna mangrupikeun rujukan anu terakhir diitung kana `Owner` urang.
//!     // Gadget Man ayeuna janten musnah ogé.
//!     //
//! }
//! ```
//!
//! Upami sarat urang robih, sareng urang ogé kedah tiasa ngalangkungan ti `Owner` dugi ka `Gadget`, urang bakal ngalaman masalah.
//! Panunjuk [`Rc`] tina `Owner` dugi `Gadget` ngenalkeun siklus.
//! Ieu ngandung harti yén itungan rujukanna moal pernah ngahontal 0, sareng alokasi moal pernah musnah:
//! kabocoran mémori.Dina raraga ngurilingan ieu, urang tiasa nganggo panunjuk [`Weak`].
//!
//! Rust sabenerna ngajadikeun eta rada hésé pikeun ngahasilkeun loop ieu dina tempat munggaran.Dina raraga ditungtungan ku dua nilai anu saling nunjuk, salah sahijina kedah dirobih.
//! Ieu sesah sabab [`Rc`] ngalaksanakeun kaamanan ingetan ku ngan ukur masihan rujukan anu dibagi kana nilai anu dibungkusna, sareng ieu henteu ngamungkinkeun mutasi langsung.
//! Urang kedah mungkus bagian tina nilai anu urang pikahoyong pikeun [`RefCell`], anu nyayogikeun *interior mutability*: metoda pikeun ngahontal mutability ngalangkungan rujukan anu dibagi.
//! [`RefCell`] ngalaksanakeun aturan injeuman Rust sacara langsung.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... sawah séjén
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... sawah séjén
//! }
//!
//! fn main() {
//!     // Ngadamel `Owner` rujukan-diitung.
//!     // Catet yén kami parantos nempatkeun 'Owner`'s vector tina`Gadget`s dina `RefCell` sahingga urang tiasa mutasi éta liwat rujukan anu dibagi.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Ngadamel `Gadget` milik `gadget_owner`, sapertos anu sateuacanna.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Tambihkeun `Gadget`s kana `Owner` na.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` injeuman dinamis réngsé di dieu.
//!     }
//!
//!     // Museurkeun 'Gadget`s kami, nyetak rinci aranjeunna kaluar.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` nyaéta `Weak<Gadget>`.
//!         // Kusabab petunjuk `Weak` teu tiasa ngajamin alokasi masih aya, urang kedah nyauran `upgrade`, anu mulih `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Dina hal ieu kami terang alokasi masih aya, janten kami ngan saukur `unwrap` `Option`.
//!         // Dina program anu langkung rumit, anjeun panginten peryogi pananganan kasalahan pikeun hasil `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Dina akhir pungsi, `gadget_owner`, `gadget1`, sareng `gadget2` musnah.
//!     // Ayeuna teu aya panunjuk (`Rc`) anu kuat pikeun alat, janten aranjeunna musnah.
//!     // Ieu nol angka rujukan dina Gadget Man, janten anjeunna ogé bakal musnah.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ieu repr(C) ka future-buktina ngalawan kamungkinan panataan lapangan, anu bakal ngaganggu [into|from]_raw() anu sanés anu aman tina jinis jero anu tiasa ditransmisikeun.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Hiji pointer rujukan-ngitung tunggal-threaded.'Rc' singkatan tina 'Rujukan
/// Counted'.
///
/// Tingali [module-level documentation](./index.html) pikeun langkung jelasna.
///
/// Metode alami `Rc` sadayana fungsina aya hubunganana, anu hartosna anjeun kedah nyauranana sapertos eg, [`Rc::get_mut(&mut value)`][get_mut] tibatan `value.get_mut()`.
/// Ieu nyingkahan konflik sareng metode jinis jero `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Kaayaan teu aman ieu ok sabab nalika Rc ieu hirup urang dijamin yén pointer jero valid.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Nyusun `Rc<T>` anyar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Aya petunjuk anu lemah anu jelas anu dipimilik ku sadayana petunjuk anu kuat, anu mastikeun yén destruktor anu lemah henteu pernah ngabébaskeun alokasi nalika destruktor anu kuat jalan, bahkan upami pointer anu lemah disimpen dina jero anu kuat.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Nyusun `Rc<T>` énggal nganggo rujukan anu lemah pikeun dirina sorangan.
    /// Nyobian ningkatkeun rujukan anu lemah sateuacan fungsi ieu balik bakal ngahasilkeun nilai `None`.
    ///
    /// Sanajan kitu, dina rujukan lemah bisa jadi diklon kalawan bébas tur disimpen pikeun pamakéan dina waktu engké.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... langkung lapangan
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ngawangun batin dina kaayaan "uninitialized" ku hiji rujukan lemah.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Penting urang ulah nyerah kapamilikan pointer lemah, atanapi upami mémori éta tiasa dibébaskeun ku waktos `data_fn` mulih.
        // Upami urang leres-leres hoyong lulus kapamilikan, urang tiasa nyiptakeun petunjuk lemah anu lemah pikeun diri urang sorangan, tapi ieu bakal ngahasilkeun pembaruan tambahan kana jumlah rujukan anu lemah anu tiasa henteu diperyogikeun sanésna.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Rujukan anu kuat kedah sacara koléktif ngagaduhan rujukan anu lemah, janten henteu ngajalankeun destructor pikeun rujukan lemah kami anu lami.
        //
        mem::forget(weak);
        strong
    }

    /// Nyusunna `Rc` énggal kalayan kontén anu teu dihaja.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Nyusun `Rc` énggal kalayan kontén anu teu dihaja, kalayan mémori dieusian ku `0` bait.
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Nyusun `Rc<T>` anyar, balikkeun kasalahan upami alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Aya petunjuk anu lemah anu jelas anu dipimilik ku sadayana petunjuk anu kuat, anu mastikeun yén destruktor anu lemah henteu pernah ngabébaskeun alokasi nalika destruktor anu kuat jalan, bahkan upami pointer anu lemah disimpen dina jero anu kuat.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Nyusun `Rc` énggal kalayan kontén anu teu dihaja, ngabalikeun kasalahan upami alokasi gagal
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ngawangun `Rc` énggal kalayan kontén anu teu aya artosialisasi, kalayan mémori dieusian ku `0` bait, balikkeun kasalahan upami alokasi gagal
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Nyusun `Pin<Rc<T>>` anyar.
    /// Upami `T` henteu nerapkeun `Unpin`, maka `value` bakal dipasang dina mémori sareng teu tiasa dipindahkeun.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Balikkeun nilai jero, upami `Rc` gaduh persis hiji rujukan anu kuat.
    ///
    /// Upami teu kitu, [`Err`] dipulangkeun sareng `Rc` anu sami anu dialirkeun.
    ///
    ///
    /// Ieu bakal hasil sanaos aya rujukan lemah anu luar biasa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // salin obyék anu aya

                // Nunjukkeun ka Lemah yén aranjeunna moal tiasa diwanohkeun ku cara ngirangan hitungan anu kuat, teras nyabut panunjuk "strong weak" anu implisit bari ogé nanganan logika serelek ku ngan ukur ngadamel Lemah palsu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Ngawangun sapotong rujukan-diitung anyar kalayan kontén anu teu dihaja.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Nyusun potongan anu diitung ku référénsi anyar kalayan kontén anu teu dihaja, kalayan mémori dieusian ku `0` bait.
    ///
    ///
    /// Tingali [`MaybeUninit::zeroed`][zeroed] pikeun conto pamakean anu salah sareng lepat tina metode ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Ngarobih kana `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Sapertos sareng [`MaybeUninit::assume_init`], terserah ka anu nelepon pikeun ngajamin yén nilai jero saleresna aya dina kaayaan inisialisasi.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku teu langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Ngarobih kana `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sapertos sareng [`MaybeUninit::assume_init`], terserah ka anu nelepon pikeun ngajamin yén nilai jero saleresna aya dina kaayaan inisialisasi.
    ///
    /// Nelepon ieu nalika eusina henteu acan diinisialisasi lengkep nyababkeun tingkah laku teu langsung.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inisialisasi anu ditangguhkeun:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Mésér `Rc`, balikkeun pointer anu dibungkus.
    ///
    /// Pikeun ngahindarkeun bocor ingetan pointer kedah dialihkeun deui ka `Rc` nganggo [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Nyayogikeun pointer atah kana data.
    ///
    /// Cacah henteu kapangaruhan ku cara naon waé sareng `Rc` henteu dikonsumsi.
    /// Pointer valid pikeun salami aya cacah anu kuat dina `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // Kaamanan: Ieu henteu tiasa ngalangkungan Deref::deref atanapi Rc::inner sabab
        // ieu diperyogikeun pikeun ngajaga raw/mut buktina sapertos contona
        // `get_mut` tiasa nyerat nganggo pointer saatos Rc dipulihkeun ngalangkungan `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Nyusunna `Rc<T>` tina pointer atah.
    ///
    /// Pointer atah kedahna sateuacanna dipulangkeun deui ku telepon ka [`Rc<U>::into_raw`][into_raw] dimana `U` kedah gaduh ukuran sareng alignment anu sami sareng `T`.
    /// Ieu leres pisan upami `U` nyaéta `T`.
    /// Catet yén upami `U` sanés `T` tapi ngagaduhan ukuran sareng alignment anu sami, ieu dasarna sapertos transmisi rujukan tina sababaraha jinis.
    /// Tingali [`mem::transmute`][transmute] pikeun langkung seueur inpormasi ngeunaan larangan naon dina hal ieu.
    ///
    /// Pamaké `from_raw` kedah pastikeun nilai khusus `T` ngan ukur lungsur sakali.
    ///
    /// Fungsi ieu henteu aman sabab panggunaan anu salah tiasa nyababkeun teu aman, bahkan upami `Rc<T>` anu dipulangkeun henteu acan pernah diakses.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ngarobih deui ka `Rc` pikeun nyegah kabocoran.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telepon salajengna ka `Rc::from_raw(x_ptr)` bakal ingetan-aman.
    /// }
    ///
    /// // Memori dibébaskeun nalika `x` kaluar tina ruang lingkup di luhur, janten `x_ptr` ayeuna ngagantung!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Balikkeun offset pikeun milarian RcBox aslina.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Nyiptakeun petunjuk [`Weak`] anyar pikeun alokasi ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Pastikeun kami henteu nyiptakeun Lemah anu ngagantung
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Meunangkeun jumlah panunjuk [`Weak`] kana alokasi ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Meunangkeun jumlah panunjuk (`Rc`) anu kuat pikeun alokasi ieu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Mulih `true` upami teu aya panunjuk `Rc` atanapi [`Weak`] anu sanés kana alokasi ieu.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Balikkeun rujukan anu tiasa dirobih kana `Rc` anu ditangtoskeun, upami teu aya panunjuk `Rc` atanapi [`Weak`] anu sanés kana alokasi anu sami.
    ///
    ///
    /// Mulang [`None`] sanésna, sabab henteu aman pikeun ngarobih nilai anu dibagi.
    ///
    /// Tingali ogé [`make_mut`][make_mut], anu bakal [`clone`][clone] nilai jero nalika aya petunjuk anu sanés.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Balikkeun rujukan anu tiasa dirobih kana `Rc` anu ditangtoskeun, tanpa cek nanaon.
    ///
    /// Tingali ogé [`get_mut`], anu aman sareng teu dipariksa anu pantes.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Nunjuk naon waé `Rc` atanapi [`Weak`] anu sanés kana alokasi anu sami henteu kedah diséferénsi salami waktos ngintunkeun deui.
    ///
    /// Ieu trivially masalahna lamun euweuh pointers misalna aya, contona langsung saatos `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Kami ati-ati pikeun *henteu* nyiptakeun rujukan anu nutupan lapangan "count", sabab ieu bakal bentrok sareng aksés kana jumlah rujukan (mis.
        // ku `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Mulih `true` upami dua `Rc` nunjuk kana alokasi anu sami (dina urat anu sami sareng [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Ngajantenkeun rujukan anu tiasa dirobih kana `Rc` anu ditangtoskeun.
    ///
    /// Upami aya petunjuk `Rc` anu sanés kana alokasi anu sami, maka `make_mut` bakal [`clone`] nilai jero kana alokasi anyar pikeun mastikeun kapamilikan unik.
    /// Ieu ogé disebat klon-on-nyerat.
    ///
    /// Upami teu aya panunjuk `Rc` sanés pikeun alokasi ieu, maka [`Weak`] petunjuk kana alokasi ieu bakal dipisahkeun.
    ///
    /// Tingali ogé [`get_mut`], anu bakal gagal tibatan kloning.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Moal klon nanaon
    /// let mut other_data = Rc::clone(&data);    // Moal klon data jero
    /// *Rc::make_mut(&mut data) += 1;        // Data batin klon
    /// *Rc::make_mut(&mut data) += 1;        // Moal klon nanaon
    /// *Rc::make_mut(&mut other_data) *= 2;  // Moal klon nanaon
    ///
    /// // Ayeuna `data` sareng `other_data` nunjuk kana alokasi anu béda.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] pointer bakal dipisahkeun:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Kudu diklon data, aya deui Rcs anu sanés.
            // Memori sateuacanna alokasi pikeun ngamungkinkeun nyerat nilai diklon langsung.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Ngan ukur tiasa maok data, sadayana anu nyésa nyaéta Lemah
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Cabut ref-kuat lemah implisit (teu kedah ngadamel Lemah palsu di dieu-urang terang Lemah anu sanés tiasa ngabersihkeun pikeun urang)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Kaayaan teu aman ieu ok sabab urang dijamin pointer anu dipulangkeun mangrupikeun *hijina* pointer anu bakal kantos dipulangkeun ka T.
        // Cacah rujukan kami dijamin janten 1 dina waktos ieu, sareng kami meryogikeun `Rc<T>` nyalira janten `mut`, janten urang balikkeun hiji-hijina referensi anu mungkin pikeun alokasi éta.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Usaha pikeun downcast `Rc<dyn Any>` kana jenis konkrit.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alokasi `RcBox<T>` kalayan rohangan anu cekap pikeun nilai batin anu tiasa-henteu ukuran dimana nilaina parantos disayogikeun.
    ///
    /// Fungsi `mem_to_rcbox` disebut nganggo data pointer sareng kedah ngauihkeun deui (berpotensi gajih)-panunjuk pikeun `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Ngitung perenah nganggo tata nilai anu parantos dipasihkeun.
        // Sateuacanna, tata ruang diitung dina ungkapan `&*(ptr as* const RcBox<T>)`, tapi ieu nyiptakeun rujukan anu salah (tingali #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokasi `RcBox<T>` kalayan rohangan anu cekap pikeun nilai batin anu tiasa-teu disukuran dimana nilaina parantos disayogikeun, mulihkeun kasalahan upami alokasi gagal.
    ///
    ///
    /// Fungsi `mem_to_rcbox` disebut nganggo data pointer sareng kedah ngauihkeun deui (berpotensi gajih)-panunjuk pikeun `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Ngitung perenah nganggo tata nilai anu parantos dipasihkeun.
        // Sateuacanna, tata ruang diitung dina ungkapan `&*(ptr as* const RcBox<T>)`, tapi ieu nyiptakeun rujukan anu salah (tingali #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alokasi pikeun perenah.
        let ptr = allocate(layout)?;

        // Ngawitan RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alokasi `RcBox<T>` kalayan rohangan anu cekap pikeun nilai jero anu henteu ukuran
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Alokasi pikeun `RcBox<T>` nganggo nilai anu ditangtoskeun.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nilai salin salaku bait
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Bébaskeun alokasi tanpa leupaskeun eusina
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alokasi `RcBox<[T]>` kalayan panjang anu ditangtoskeun.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Salin elemen tina keureutan kana Rc <\[T\]> anu nembe dialokasikan
    ///
    /// Henteu aman sabab anu nelepon kedah ngagaduhan kapamilikan atanapi ngabeungkeut `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Nyusun `Rc<[T]>` tina iterator anu dipikanyaho ukuranana tangtu.
    ///
    /// Kalakuan teu ditangtoskeun kedah ukuranana lepat.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Penjaga Panic bari kloning elemen T.
        // Dina acara panic, unsur-unsur anu parantos ditulis kana RcBox énggal bakal murag, teras mémori dibébaskeun.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pointer kana unsur kahiji
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Sadayana jelas.Hilap hansip supados henteu ngosongkeun RcBox énggal.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spésialisasi trait dianggo pikeun `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Tetes `Rc`.
    ///
    /// Ieu bakal nurunkeun itungan rujukan anu kuat.
    /// Upami jumlah referensi anu kuat ngahontal enol maka ngan ukur rujukan anu sanés (upami aya) nyaéta [`Weak`], janten kami `drop` nilai jero.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Henteu nyitak nanaon
    /// drop(foo2);   // Nyitak "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // ngancurkeun obyék anu aya
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // hapus petunjuk "strong weak" anu implisit ayeuna yén kami parantos ngancurkeun eusina.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Ngajantenkeun klon pointer `Rc`.
    ///
    /// Ieu nyiptakeun petunjuk anu sanés kana alokasi anu sami, ningkatkeun cacah rujukan anu kuat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Nyiptakeun `Rc<T>` énggal, kalayan nilai `Default` pikeun `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack pikeun ngijinkeun ngahususkeun kana `Eq` sanaos `Eq` ngagaduhan padika.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Kami ngalakukeun spésialisasi ieu didieu, sareng sanés salaku optimalisasi anu langkung umum dina `&T`, sabab upami éta bakal nambihan biaya pikeun sadaya cek kasetaraan dina refs.
/// Kami anggap yén `Rc`s dianggo pikeun nyimpen nilai ageung, anu lambat diklon, tapi ogé beurat pikeun mariksa kasetaraan, ngabalukarkeun biaya ieu mayar langkung gampang.
///
/// Éta ogé langkung kamungkinan ngagaduhan dua klon `Rc`, anu nunjuk kana nilai anu sami, tibatan dua `&T`s.
///
/// Urang ngan ukur tiasa ngalakukeun ieu nalika `T: Eq` salaku `PartialEq` panginten tiasa ngahaja teu pikaresepeun.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Sarua pikeun dua `Rc`s.
    ///
    /// Dua `Rc`s sami upami nilai batinna sami, bahkan upami disimpen dina alokasi anu béda.
    ///
    /// Upami `T` ogé nerapkeun `Eq` (nunjukkeun réfléktivitas sasaruaan), dua `Rc`s anu nunjuk kana alokasi anu sami sok sami.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ketimpangan pikeun dua `Rc`s.
    ///
    /// Dua `Rc` henteu sami upami niléyna batinna henteu sami.
    ///
    /// Upami `T` ogé nerapkeun `Eq` (nunjukkeun réfléktivitas sasaruaan), dua `Rc`s anu nunjuk kana alokasi anu sami henteu pernah sami.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Babandingan parsial pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `partial_cmp()` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Kirang-tibatan ngabandingkeun pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `<` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Kurang ti atanapi sami sareng' ngabandingkeun pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `<=` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Babandingan anu langkung saé pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `>` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Langkung hébat atanapi sami' ngabandingkeun pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `>=` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Babandingan pikeun dua `Rc`s.
    ///
    /// Dua-dua dibandingkeun ku nyauran `cmp()` kana nilai batinna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alokkeun sapotong anu diitung-rujukan sareng eusian ku ngempelkeun barang-barang `v`'s.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Alokkeun sapotong senar anu diitung-referensi sareng nyalin `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Alokkeun sapotong senar anu diitung-referensi sareng nyalin `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Mindahkeun objék kotak kana anu anyar, rujukan diitung, alokasi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alokasikeun sapotong anu diitung-rujukan sareng ngalihkeun barang-barang `v` kana éta.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Ngidinan Vec ngosongkeun ingetanana, tapi henteu ngancurkeun eusina
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Nyandak unggal unsur dina `Iterator` teras ngumpulkeun kana `Rc<[T]>`.
    ///
    /// # Karakteristik kinerja
    ///
    /// ## Kasus umum
    ///
    /// Dina kasus anu umum, ngempelkeun kana `Rc<[T]>` dilakukeun ku mimitina ngempelkeun kana `Vec<T>`.Nyaéta, nalika nyerat kieu:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ieu kalakuanana siga urang nulis:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Kumpulan alokasi munggaran kajantenan di dieu.
    ///     .into(); // Alokasi kadua pikeun `Rc<[T]>` kajantenan di dieu.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ieu bakal allocate saloba kali sakumaha diperlukeun pikeun diwangun dina `Vec<T>` lajeng eta bakal allocate sakali pikeun ngarobah éta `Vec<T>` kana `Rc<[T]>`.
    ///
    ///
    /// ## Iterators tina panjangna dipikanyaho
    ///
    /// Nalika `Iterator` Anjeun implements `TrustedLen` sarta mangrupakeun hiji ukuran pasti, a alokasi tunggal bakal dilakukeun keur `Rc<[T]>`.Salaku conto:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Ngan ukur alokasi anu kajantenan di dieu.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Spésialisasi trait dianggo pikeun ngumpulkeun kana `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ieu kasus pikeun iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Kaamanan: Urang kedah mastikeun yén iterator ngagaduhan panjang anu pasti sareng urang gaduh.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Turun deui kana palaksanaan normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` mangrupikeun vérsi [`Rc`] anu ngagaduhan rujukan anu teu kapimilik pikeun alokasi anu dikokolakeun.Alokasi diaksés ku nelepon [`upgrade`] dina panunjuk `Weak`, anu ngabalikeun hiji [`Option`]`<`[`Rc`] `<T>>`.
///
/// Kusabab rujukan `Weak` henteu diitung dina kapamilikan, éta moal nyegah nilai anu disimpen dina alokasi turun, sareng `Weak` nyalira henteu ngajamin ngeunaan nilai anu masih aya.
/// Maka éta tiasa mulih [`None`] nalika [`upgrade`] d.
/// Catet kumaha ogé yén rujukan `Weak`*henteu* nyegah alokasi éta nyalira (toko pangrojong) tina transaksi.
///
/// A pointer `Weak` gunana pikeun ngajaga rujukan samentawis kana alokasi anu dikelola ku [`Rc`] tanpa nyegah nilai jero na tina murag.
/// Ogé dianggo pikeun nyegah rujukan bunderan antara poin [`Rc`], kumargi silih referensi anu ngagaduhan moal ngijinkeun [`Rc`] turun.
/// Salaku conto, tangkal tiasa ngagaduhan petunjuk [`Rc`] anu kuat ti titik indung ka budak, sareng `Weak` petunjuk ti budak deui ka kolotna.
///
/// Cara anu khas pikeun kéngingkeun pitunjuk `Weak` nyaéta nyauran [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ieu mangrupikeun `NonNull` kanggo ngamungkinkeun ngaoptimalkeun ukuran tina jenis ieu dina enum, tapi éta henteu kedah janten pointer anu valid.
    //
    // `Weak::new` netepkeun ieu ka `usize::MAX` sahingga henteu kedah nyebarkeun rohangan dina tumpukan.
    // Éta sanés nilai anu ditunjuk pointer anu nyata sabab RcBox gaduh alignment sahenteuna 2.
    // Ieu ngan mungkin nalika `T: Sized`;`T` unsized pernah ngagantung.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Nyusun `Weak<T>` énggal, tanpa nyebarkeun mémori nanaon.
    /// Nelepon [`upgrade`] dina nilai balik sok masihan [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Nulungan ngetik pikeun ngidinan ngakses ka diitung rujukan tanpa nyieun assertions wae ngeunaan widang data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Balikkeun pointer atah kana obyék `T` anu ditunjuk ku `Weak<T>` ieu.
    ///
    /// pointer ieu valid ngan lamun aya sababaraha rujukan kuat.
    /// Pointer tiasa ngagantung, henteu disaluyukeun atanapi bahkan [`null`] sanés.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Duanana nunjuk kana objék anu sami
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Anu kuat di dieu tetep hirup, janten urang masih tiasa ngakses obyékna.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Tapi henteu deui.
    /// // Urang tiasa ngalakukeun weak.as_ptr(), tapi ngaksés pointer bakal ngakibatkeun kabiasaan anu teu ditangtoskeun.
    /// // assert_eq! ("halo", teu aman {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Upami pointer ngagantung, urang langsung ngintunkeun sentinel.
            // Teu tiasa alamat payload valid, sakumaha payload nyaeta sahenteuna jadi Blok sakumaha RcBox (usize).
            ptr as *const T
        } else {
            // SAFETY: upami_dangling mulih palsu, maka pointer na teu tiasa dibatalkeun.
            // Payload tiasa diturunkeun dina titik ieu, sareng urang kedah ngajaga kasaksian, janten nganggo manipulasi pointer atah.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Ngonsumsi `Weak<T>` sareng ngajantenkeun janten pointer atah.
    ///
    /// Ieu ngarobih pointer lemah kana pointer atah, nalika tetep ngajaga kapamilikan hiji rujukan lemah (itungan lemah henteu dirobah ku operasi ieu).
    /// Éta tiasa dirobih deui kana `Weak<T>` sareng [`from_raw`].
    ///
    /// Watesan anu sami pikeun ngakses udagan panunjuk sareng [`as_ptr`] lumaku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Ngarobih pointer atah anu sateuacanna diciptakeun ku [`into_raw`] janten `Weak<T>`.
    ///
    /// Ieu tiasa dianggo pikeun sacara aman kéngingkeun rujukan anu kuat (ku nélépon [`upgrade`] engké) atanapi nungkulan jumlah lemah ku muterna `Weak<T>`.
    ///
    /// Butuh kapamilikan hiji rujukan anu lemah (kacuali poin anu diciptakeun ku [`new`], sabab ieu henteu ngagaduhan nanaon; padika masih tiasa dianggo pikeun aranjeunna).
    ///
    /// # Safety
    ///
    /// Pointer kedahna asalna ti [`into_raw`] sareng tetep kedah ngagaduhan poténsi rujukan anu lemah.
    ///
    /// Diidinan pikeun itungan anu kuat janten 0 dina waktos nelepon ieu.
    /// Sanaos kitu, ieu ngagaduhan kapamilikan hiji rujukan lemah anu ayeuna diwakilan salaku panunjuk atah (itungan lemah henteu dirobah ku operasi ieu) sahingga éta kedah dipasangkeun sareng sauran [`into_raw`] sateuacanna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ngirangan itungan lemah anu terakhir.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Tingali Weak::as_ptr pikeun kontéks ngeunaan kumaha carana nunjukkeun pointer input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ieu Lemah ngagantung.
            ptr as *mut RcBox<T>
        } else {
            // Upami teu kitu, urang dijamin panunjuk asalna tina Lemah nondangling.
            // SAFETY: data_offset aman ditelepon, sabab ptr ngarujuk nyata (berpotensi turun) T.
            let offset = unsafe { data_offset(ptr) };
            // Ku kituna, urang ngabalikkeun offset pikeun kéngingkeun sadayana RcBox.
            // SAFETY: pointer asalna tina Lemah, janten offset ieu aman.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAFETY: urang ayeuna parantos kéngingkeun pointer Leuleus anu asli, janten tiasa nyiptakeun Lemah.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Usaha pikeun ningkatkeun pidangan pointer `Weak` ka [`Rc`], nyangsang muterna nilai jero upami suksés.
    ///
    ///
    /// Mulih [`None`] upami nilai batinna saprak parantos lungsur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ngancurkeun sagala petunjuk anu kuat.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Meunangkeun jumlah panunjuk (`Rc`) anu kuat nunjuk kana alokasi ieu.
    ///
    /// Upami `self` didamel nganggo [`Weak::new`], ieu bakal balik 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Meunangkeun jumlah panunjuk `Weak` nunjuk kana alokasi ieu.
    ///
    /// Upami henteu aya petunjuk anu kuat, ieu bakal nol deui.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // subtract nu ptr lemah implisit
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Mulih `None` nalika pointer ngagantung sareng teu aya `RcBox` dialokasikeun, (nyaéta nalika `Weak` ieu diciptakeun ku `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Kami ati-ati pikeun *henteu* nyiptakeun rujukan anu nutupan lapangan "data", sabab lapangan tiasa dirobih sakaligus (contona, upami `Rc` pamungkas digugurkeun, kolom data bakal murag dina tempatna).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Balik `true` upami dua `Lemah` nunjuk kana alokasi anu sami (sami sareng [`ptr::eq`]), atanapi upami duanana henteu nunjuk kana alokasi naon (sabab éta diciptakeun ku `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kusabab ieu ngabandingkeun pointer hartosna `Weak::new()` bakal sami, sanaos henteu nunjukkeun alokasi naon waé.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ngabandingkeun `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Turunkeun panunjuk `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Henteu nyitak nanaon
    /// drop(foo);        // Nyitak "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // itungan lemah dimimitian dina jam 1, sareng ngan ukur bakal nol upami sadaya petunjuk anu kuat parantos ngaleungit.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ngajantenkeun klon pointer `Weak` anu nunjuk kana alokasi anu sami.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Nyusun `Weak<T>` énggal, nyebarkeun mémori pikeun `T` tanpa nginisialisasi.
    /// Nelepon [`upgrade`] dina nilai balik sok masihan [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Kami dipariksa_nambahkeun di dieu pikeun ngurus mem::forget aman.Khususna
// upami anjeun mem::forget Rcs (atanapi Leuleus), ref-count tiasa ngabahekeun, teras anjeun tiasa ngosongkeun alokasi samentawis Rcs anu luar biasa (atanapi Lemah) aya.
//
// Kami ngabatalkeun kusabab ieu mangrupikeun skénario anu turun anu urang henteu paduli kana naon anu lumangsung-henteu aya program anu saéstuna anu kedah ngalaman ieu.
//
// Ieu kedah gaduh overhead anu tiasa dianggurkeun kumargi anjeun henteu leres-leres kedah dikloning ieu dina Rust berkat kapamilikan sareng move-semantik.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Kami hoyong aborsi dina overflow tibatan muterna nilaina.
        // Itungan rujukan moal pernah nol nalika ieu disebat;
        // sanaos kitu, urang lebetkeun abort didieu kanggo ngabayangkeun LLVM dina optimasi anu sanés.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Kami hoyong aborsi dina overflow tibatan muterna nilaina.
        // Itungan rujukan moal pernah nol nalika ieu disebat;
        // sanaos kitu, urang lebetkeun abort didieu kanggo ngabayangkeun LLVM dina optimasi anu sanés.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Kéngingkeun offset dina `RcBox` kanggo muatan dina hiji poin.
///
/// # Safety
///
/// Penunjuk kedah nunjuk ka (sareng ngagaduhan metadata anu sah pikeun) conto T anu saacanna sah, tapi T diidinan turun.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sejajarkeun nilai henteu ukuran kana tungtung RcBox.
    // Kusabab RcBox nyaéta repr(C), éta bakal janten lapangan terakhir dina mémori.
    // SAFETY: kumargi hiji-hijina jinis unsized mungkin nyaéta keureut, objék trait,
    // sareng jinis eksternal, sarat kaamanan input ayeuna cukup pikeun nyayogikeun syarat align_of_val_raw;ieu mangrupa jéntré palaksanaan bahasa anu teu meunang relied kana luar tina std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}