#![stable(feature = "wake_trait", since = "1.51.0")]
//! Jenis sareng Traits pikeun damel sareng tugas anu teu sinkron.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Palaksanaan ngahudangkeun tugas dina pelaksana.
///
/// trait ieu tiasa dianggo pikeun nyiptakeun [`Waker`].
/// Pelaksana tiasa nangtoskeun palaksanaan trait ieu, sareng nganggo éta pikeun ngawangun Waker pikeun ngalirkeun tugas-tugas anu dilaksanakeun dina pelaksana éta.
///
/// trait ieu mangrupikeun alternatif memori-aman sareng ergonomis pikeun ngawangun [`RawWaker`].
/// Éta ngadukung desain pelaksana umum dimana data anu dianggo pikeun ngahudangkeun tugas disimpen dina [`Arc`].
/// Sababaraha palaksana (utamina anu pikeun sistem anu dipasang) teu tiasa nganggo API ieu, naha sababna [`RawWaker`] aya salaku alternatip pikeun sistem éta.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Fungsi `block_on` dasar anu nyandak future sareng ngalir ka réngsé dina thread ayeuna.
///
/// **Note:** Conto ieu dagang kabeneran keur kesederhanaan.
/// Dina raraga nyegah buntu, palaksanaan produksi-tingkat ogé kedah ngadamel telepon panengah ka `thread::unpark` ogé invokasi anu disarapkeun.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Wangun anu ngahudangkeun benang anu ayeuna nalika ditelepon.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ngajalankeun future nepi ka réngsé dina utas ayeuna.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin future supados tiasa disurah.
///     let mut fut = Box::pin(fut);
///
///     // Ngadamel kontéks anyar pikeun diliwatan ka future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Ngajalankeun future dugi ka réngsé.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Bangun tugas ieu.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Bangun tugas ieu tanpa nyéépkeun hudang.
    ///
    /// Upami pelaksana ngadukung cara anu langkung mirah pikeun hudang tanpa nganggo waker, éta kedah ngaleungitkeun metode ieu.
    /// Sacara standar, éta mengklon [`Arc`] sareng nyauran [`wake`] dina klon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // KESELAMATAN: Ieu aman sabab raw_waker aman diwangun
        // a RawWaker ti Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Fungsi pribadi ieu pikeun ngawangun RawWaker dianggo, sanés
// inlining ieu kana impl `From<Arc<W>> for RawWaker`, pikeun mastikeun yén kasalametan `From<Arc<W>> for Waker` henteu gumantung kana pangiriman trait anu leres, tibatan duanana impls nelepon fungsi ieu sacara langsung sareng eksplisit.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Nambahkeun jumlah rujukan tina busur pikeun mengkloningna.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Bangun ku nilaina, mindahkeun Arc kana fungsi Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Bangun ku rujukan, bungkus bangun dina sacara ManualDrop pikeun nyingkahan ragrag na
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Ngurangan count rujukan tina Arc dina serelek
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}