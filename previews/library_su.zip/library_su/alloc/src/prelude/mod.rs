//! Alokasi Prelude
//!
//! Tujuan tina modul ieu nyaéta pikeun ngirangan impor barang anu biasa dianggo tina `alloc` crate ku nambihan impor glob kana bagian luhur modul:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;