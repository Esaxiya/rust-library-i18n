//! A UTF-8 - dikodekeun, string growable.
//!
//! Modul ieu ngandung jenis [`String`], [`ToString`] trait pikeun ngarobah kana senar, sareng sababaraha jinis kasalahan anu tiasa hasil tina damel sareng [`String`] s.
//!
//!
//! # Examples
//!
//! Aya sababaraha cara pikeun nyiptakeun [`String`] anyar tina string anu literal:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Anjeun tiasa nyiptakeun [`String`] énggal tina anu tos aya ku ngahijikeun sareng
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Upami anjeun gaduh vector valid UTF-8 bait, anjeun tiasa ngadamel [`String`] tina na.Anjeun tiasa ogé ngabalikkeun.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Kami terang bait ieu valid, janten kami nganggo `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// A UTF-8 - dikodekeun, string growable.
///
/// Jenis `String` mangrupikeun jenis string anu paling umum anu gaduh kapamilikan eusi senar.Éta ngagaduhan hubungan anu caket sareng réncang anu diinjeum, [`str`] primitif.
///
/// # Examples
///
/// Anjeun tiasa nyiptakeun `String` tina [a literal string][`str`] sareng [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Anjeun tiasa nambihan [`char`] ka `String` kalayan metode [`push`], sareng nambihan [`&str`] kalayan metode [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Upami anjeun ngagaduhan vector UTF-8 bait, anjeun tiasa nyiptakeun `String` ti éta kalayan metoda [`from_utf8`]:
///
/// ```
/// // sababaraha bait, dina vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kami terang bait ieu valid, janten kami nganggo `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s sok valid UTF-8.Ieu gaduh sababaraha implikasi, anu mimiti nyaéta upami anjeun peryogi senar sanés UTF-8, anggap [`OsString`].Éta sami, tapi tanpa UTF-8 konstrain.Implikasi anu kadua nyaéta anjeun moal tiasa indéks kana `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing dimaksudkeun janten operasi konstan-waktu, tapi UTF-8 encoding teu ngidinan urang ngalakonan ieu.Salajengna, éta henteu jelas naon jinis indéks anu kedah dipulangkeun: bait, codepoint, atanapi gugus grapheme.
/// Metodeu [`bytes`] sareng [`chars`] balikkeun iterator dina dua anu munggaran, masing-masing.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s nerapkeun [`Deref`]`<Target=str>`, sareng kitu ngawariskeun sadaya metode [`str`].Salaku tambahan, ieu ngandung harti yén anjeun tiasa ngalirkeun `String` kana fungsi anu nyandak [`&str`] ku ngagunakeun ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ieu bakal nyiptakeun [`&str`] tina `String` teras ngalirkeunana. Konversi ieu langkung mirah, sareng umumna, fungsi bakal nampi [`&str`] salaku argumen kecuali upami aranjeunna peryogi `String` pikeun sababaraha alesan khusus.
///
/// Dina kasus anu tangtu Rust henteu ngagaduhan cekap inpormasi pikeun ngarobah ieu, katelah paksaan [`Deref`].Dina conto di handap ieu sapotong senar [`&'a str`][`&str`] ngalaksanakeun trait `TraitExample`, sareng fungsi `example_func` nyandak naon waé anu nerapkeun trait.
/// Dina hal ieu Rust kedah ngadamel dua konvérsi anu implisit, anu Rust henteu ngagaduhan sarana pikeun dilakukeun.
/// Kusabab éta, conto ieu di handap moal nyusun.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Aya dua pilihan anu tiasa dianggo tibatan.Anu pangpayunna bakal ngarobih garis `example_func(&example_string);` janten `example_func(example_string.as_str());`, ngagunakeun metode [`as_str()`] pikeun eksplisit nimba irisan senar anu ngandung senar.
/// Cara kadua ngarobih `example_func(&example_string);` janten `example_func(&*example_string);`.
/// Dina hal ieu kami ngamajukeun `String` ka [`str`][`&str`], teras ngarujuk [`str`][`&str`] deui [`&str`].
/// Cara anu kadua langkung idiomatik, nanging duanana jalan pikeun ngalakukeun konvérsi sacara jelas tibatan ngandelkeun konvérsi anu implisit.
///
/// # Representation
///
/// `String` diwangun ku tilu komponén: panunjuk pikeun sababaraha bait, panjang, sareng kapasitas.Pointer nunjuk kana panyangga internal `String` anu dianggo pikeun nyimpen data na.Panjangna nyaéta jumlah bait anu ayeuna disimpen dina panyangga, sareng kapasitasna ukuran tina panyangga dina bait.
///
/// Sapertos kitu, panjangna bakal teras-terasan kirang ti atanapi sami sareng kapasitasna.
///
/// Panyangga ieu teras disimpen dina tumpukan.
///
/// Anjeun tiasa ningali ieu nganggo metode [`as_ptr`], [`len`], sareng [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Perbarui ieu nalika vector_into_raw_parts stabilisasi.
/// // Nyegah sacara otomatis ngaleupaskeun data String urang
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // carita boga salapan belas bait
/// assert_eq!(19, len);
///
/// // Urang tiasa ngawangun deui String kaluar tina ptr, len, sareng kapasitas.
/// // Ieu sadayana henteu aman sabab kami tanggel waler pastikeun komponénna leres:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Mun hiji `String` boga kapasitas cukup, nambahan elemen pikeun eta moal deui allocate-.Salaku conto, perhatoskeun program ieu:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ieu bakal ngaluarkeun ieu:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Mimitina, urang henteu gaduh mémori anu dialokasikeun pisan, tapi nalika urang nambihan senar, éta ningkatkeun kapasitas na kalayan pantes.Mun urang gantina nganggo metoda [`with_capacity`] mun allocate kapasitas bener mimitina:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Urang tungtungna kalayan kaluaran anu béda:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Di dieu, teu kedah nyebarkeun langkung seueur mémori dina loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Nilai kasalahan anu mungkin nalika ngarobah `String` tina UTF-8 byte vector.
///
/// Jenis ieu mangrupikeun jinis kasalahan pikeun metode [`from_utf8`] dina [`String`].
/// Hal ieu dirarancang dina cara sapertos ka taliti ulah reallocations: metoda [`into_bytes`] bakal masihan deui nu bait vector yén ieu dipaké dina usaha konvérsi.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Jinis [`Utf8Error`] anu disayogikeun ku [`std::str`] ngagambarkeun kasalahan anu tiasa kajantenan nalika ngarobih sapotong [`u8`] s janten [`&str`].
/// Dina pengertian ieu, éta analog kana `FromUtf8Error`, sareng anjeun tiasa kéngingkeun hiji tina `FromUtf8Error` ngalangkungan padika [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// // sababaraha bait anu henteu valid, dina vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Nilai kasalahan anu mungkin nalika ngarobah `String` tina potongan byte UTF-16.
///
/// Jenis ieu mangrupikeun jinis kasalahan pikeun metode [`from_utf16`] dina [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Dasar panggunaan:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Nyiptakeun `String` kosong anyar.
    ///
    /// Nunjukkeun yén `String` kosong, ieu moal nyayogikeun panyangga awal.Sedengkeun éta hartosna yén operasi awal ieu mahal pisan, éta tiasa nyababkeun alokasi kaleuleuwih engké nalika anjeun nambihan data.
    ///
    /// Upami anjeun ngagaduhan ideu sabaraha data anu bakal dicekel `String`, pertimbangkeun metode [`with_capacity`] pikeun nyegah alokasi ulang anu kaleuleuwihi.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Nyiptakeun `String` kosong anyar kalayan kapasitas khusus.
    ///
    /// `String`s ngagaduhan panyangga internal pikeun nahan data-na.
    /// Kapasitasna panjang tina panyangga éta, sareng tiasa ditaros nganggo metode [`capacity`].
    /// Metoda ieu nyiptakeun `String` kosong, tapi hiji sareng panyangga awal anu tiasa nahan `capacity` bait.
    /// Ieu mangpaat nalika anjeun tiasa nambihan sakumpulan data kana `String`, ngirangan jumlah réalokasi anu kedah dilakukeun.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Upami kapasitas anu dipasihkeun nyaéta `0`, moal aya alokasi anu lumangsung, sareng metoda ieu idéntik sareng metode [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String henteu ngandung chars, sanaos ngagaduhan kapasitas langkung
    /// assert_eq!(s.len(), 0);
    ///
    /// // Ieu sadayana dilakukeun tanpa reallocating ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... tapi ieu tiasa ngajantenkeun senarna malih
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): kalayan cfg(test) metoda `[T]::to_vec` alami, anu diperyogikeun pikeun watesan metode ieu, henteu sayogi.
    // Kusabab kami henteu meryogikeun padika ieu pikeun tujuan uji, kuring ngan ukur ngecepkeunnana NB tingali modul slice::hack dina slice.rs pikeun langkung seueur inpormasi
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Ngarobih vector bait ka `String`.
    ///
    /// Senar ([`String`]) didamel tina bait ([`u8`]), sareng vector bait ([`Vec<u8>`]) didamel ku bait, janten fungsi ieu ngarobah antara dua.
    /// Henteu sadayana keureutan bait sah`String`s, nanging: `String` meryogikeun yén UTF-8 valid.
    /// `from_utf8()` cek pikeun mastikeun yén bait valid UTF-8, teras ngalakukeun konvérsi éta.
    ///
    /// Upami anjeun yakin yén keureutan bait valid UTF-8, sareng anjeun teu hoyong ngahasilkeun overhead cek validitas, aya pérsi anu teu aman tina fungsi ieu, [`from_utf8_unchecked`], anu ngagaduhan paripolah anu sami tapi ngalangkungan cek éta.
    ///
    ///
    /// Metoda ieu bakal jaga pikeun henteu nyalin vector, pikeun efisiensi.
    ///
    /// Lamun perlu [`&str`] tinimbang hiji `String`, mertimbangkeun [`str::from_utf8`].
    ///
    /// Kabalikan tina metoda ieu nyaéta [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Mulih [`Err`] upami keureut sanés UTF-8 kalayan katerangan naha bait anu disayogikeun sanés UTF-8.vector anu anjeun ngalihkeun ogé kalebet.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait, dina vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Kami terang bait ieu valid, janten kami nganggo `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bait salah:
    ///
    /// ```
    /// // sababaraha bait anu henteu valid, dina vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Tingali dokumén pikeun [`FromUtf8Error`] pikeun langkung seueur rinci ngeunaan naon anu anjeun tiasa laksanakeun ku kasalahan ieu.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Ngarobih sapotong bait kana senar, kalebet karakter anu teu valid.
    ///
    /// Senar didamel tina bait ([`u8`]), sareng sapotong bait ([`&[u8]`][byteslice]) didamel tina bait, janten fungsi ieu ngarobah antara keduanya.Henteu sadayana keureutan bait mangrupikeun senar anu sah, nanging: senar diperyogikeun janten UTF-8 anu valid.
    /// Salami konversi ieu, `from_utf8_lossy()` bakal ngagentos séri UTF-8 anu henteu leres ku [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], anu sapertos kieu:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Upami anjeun yakin yén bait keureut valid UTF-8, sareng anjeun teu hoyong ngahasilkeun overhead konvérsi, aya pérsi anu teu aman tina fungsi ieu, [`from_utf8_unchecked`], anu ngagaduhan paripolah anu sami tapi ngalangkungan cek.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Fungsi ieu mulih [`Cow<'a, str>`].Upami keureutan bait kami henteu valid UTF-8, maka urang kedah ngalebetkeun karakter gaganti, anu bakal ngarobih ukuran senarna, sahingga peryogi `String`.
    /// Tapi upami éta parantos valid UTF-8, kami henteu kedah alokasi énggal.
    /// Jenis balik ieu ngamungkinkeun urang pikeun ngatur kadua kasus.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait, dina vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bait salah:
    ///
    /// ```
    /// // sababaraha bait anu henteu valid
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dékodekeun UTF-16 - énkode vector `v` kana `String`, balikkeun [`Err`] upami `v` ngandung data anu salah.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ieu henteu dilakukeun ngalangkungan: : <Result<_, _>> () kusabab alesan kinerja.
        // FIXME: fungsina tiasa disederhanakeun deui nalika #48994 ditutup.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dékodekeun sapotong UTF-16 - énkode `v` kana `String`, ngaganti data anu teu valid ku [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Beda sareng [`from_utf8_lossy`] anu mulih [`Cow<'a, str>`], `from_utf16_lossy` mulih `String` kumargi konversi UTF-16 ka UTF-8 meryogikeun alokasi memori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Ngurai `String` kana komponén atah na.
    ///
    /// Mulih ti pointer atah kana data kaayaan, panjang string (dina bait), sarta kapasitas disadiakeun ngeunaan data (dina bait).
    /// Ieu argumen anu sami dina urutan anu sami sareng argumen ka [`from_raw_parts`].
    ///
    /// Saatos nelepon pungsi ieu, panelepon tanggung jawab mémori anu sateuacanna dikelola ku `String`.
    /// Hiji-hijina cara pikeun ngalakukeun ieu nyaéta ngarobah pointer atah, panjang, sareng kapasitas deui janten `String` kalayan fungsi [`from_raw_parts`], ngamungkinkeun penghancur ngalaksanakeun pembersihan.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Nyiptakeun `String` anyar tina panjang, kapasitas, sareng panunjuk.
    ///
    /// # Safety
    ///
    /// Ieu leres-leres henteu aman, kusabab jumlah invarian anu henteu dipariksa:
    ///
    /// * Mémori dina `buf` kedah parantos dialokasikan ku alokasi anu sami anu dianggo perpustakaan standar, kalayan alignment anu diperyogikeun persis tina 1.
    /// * `length` pangabutuh janten kurang atawa sarua jeung `capacity`.
    /// * `capacity` kedah janten nilai anu leres.
    /// * Bait `length` munggaran di `buf` kedah leres UTF-8.
    ///
    /// Ngalanggar ieu tiasa nyababkeun masalah sapertos ngarusak struktur data internal alokasi.
    ///
    /// Kapamilikan `buf` sacara épéktip ditransferkeun ka `String` anu teras tiasa ngaluarkeun, realokasi atanapi ngarobih eusi mémori anu ditunjuk ku pointer sakahayangna.
    /// Mastikeun yén teu aya anu nganggo pointer saatos nelepon fungsi ieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Perbarui ieu nalika vector_into_raw_parts stabilisasi.
    ///     // Nyegah sacara otomatis ngaleupaskeun data String urang
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Ngarobih vector bait ka `String` tanpa mariksa yén senarna ngandung UTF-8 anu valid.
    ///
    /// Tempo versi aman, [`from_utf8`], pikeun leuwih rinci.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman sabab henteu mariksa yén bait anu diliwatan ka UTF-8 anu valid.
    /// Upami kendala ieu dilanggar, éta tiasa nyababkeun masalah teu aman ingetan ku pangguna future tina `String`, sabab sésana perpustakaan standar nganggap yén `String`s valid UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait, dina vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Ngarobih `String` kana bait vector.
    ///
    /// Ieu nyéépkeun `String`, janten kami henteu kedah nyalin eusina.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ekstrak irisan senar anu ngandung `String` sadayana.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Ngarobih `String` kana irisan senar anu tiasa dirobih.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Nambahkeun potongan irisan dina akhir `String` ieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Balikkeun kapasitas `String` ieu, dina bait.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Mastikeun yén kapasitas `String` ieu sahenteuna `additional` bait langkung ageung tibatan panjangna.
    ///
    /// Kapasitas tiasa ningkat ku langkung ti `additional` bait upami dipilih, pikeun nyegah réliasi sering.
    ///
    ///
    /// Upami anjeun henteu hoyong kabiasaan "at least" ieu, tingali metode [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas anyar ngabahekeun [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ieu bisa jadi teu sabenerna ningkatkeun kapasitas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ayeuna gaduh panjang 2 sareng kapasitas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kusabab urang parantos ngagaduhan kapasitas 8 tambahan, nyauran ieu ...
    /// s.reserve(8);
    ///
    /// // ... henteu leres-leres nambih.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Mastikeun yén kapasitas `String` ieu `additional` bait langkung ageung tibatan panjangna.
    ///
    /// Pertimbangkeun nganggo metodeu [`reserve`] kecuali anjeun leres-leres terang langkung saé tina alokasi.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics upami kapasitas anyar ngabahekeun `usize`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ieu bisa jadi teu sabenerna ningkatkeun kapasitas:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ayeuna gaduh panjang 2 sareng kapasitas 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Kusabab urang parantos ngagaduhan kapasitas 8 tambahan, nyauran ieu ...
    /// s.reserve_exact(8);
    ///
    /// // ... henteu leres-leres nambih.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Nyobian cagar kapasitas sahenteuna `additional` langkung seueur unsur pikeun dilebetkeun kana `String` anu ditangtoskeun.
    /// Koléksi tiasa nyayogikeun langkung seueur rohangan pikeun nyingkahan réliasi anu sering.
    /// Saatos nelepon `reserve`, kapasitas bakal langkung ageung tibatan atanapi sami sareng `self.len() + additional`.
    /// Henteu nanaon upami kapasitasna parantos cekap.
    ///
    /// # Errors
    ///
    /// Upami kapasitasna ngabahekeun, atanapi alokator ngalaporkeun kagagalan, maka kasalahan dipulangkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-cadangan memori, kaluar upami urang teu tiasa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ayeuna urang terang ieu moal tiasa OOM di tengah padamelan rumit urang
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Nyobian cagar kapasitas minimum pikeun persis `additional` langkung seueur elemen pikeun dilebetkeun kana `String` anu ditangtoskeun.
    ///
    /// Saatos nelepon `reserve_exact`, kapasitas bakal langkung ageung tibatan atanapi sami sareng `self.len() + additional`.
    /// Henteu nanaon upami kapasitasna parantos cekap.
    ///
    /// Catet yén alokator tiasa masihan koleksi langkung rohangan tibatan anu dipénta.
    /// Ku alatan éta, kapasitas teu tiasa diandelkeun janten tepat minimal.
    /// Resep `reserve` upami sisipan future diarepkeun.
    ///
    /// # Errors
    ///
    /// Upami kapasitasna ngabahekeun, atanapi alokator ngalaporkeun kagagalan, maka kasalahan dipulangkeun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pra-cadangan memori, kaluar upami urang teu tiasa
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ayeuna urang terang ieu moal tiasa OOM di tengah padamelan rumit urang
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Nyusut kapasitas `String` ieu pikeun cocog sareng panjang na.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Nyusut kapasitas `String` ieu ku wates anu langkung handap.
    ///
    /// Kapasitas bakal tetep sahenteuna sakumaha ageung duanana panjangna sareng nilai anu disayogikeun.
    ///
    ///
    /// Upami kapasitas ayeuna kirang tina wates anu langkung handap, ieu mangrupikeun no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Nambahkeun [`char`] anu dipasihkeun dina akhir `String` ieu.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Mulang sapotong bait tina eusi `String` ieu.
    ///
    /// Kabalikan tina metoda ieu nyaéta [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Shortens `String` ieu kana panjang anu parantos ditangtukeun.
    ///
    /// Upami `new_len` langkung ageung tibatan panjang ayeuna string, ieu moal aya pangaruhna.
    ///
    ///
    /// Catet yén metoda ieu teu aya pangaruh kana kapasitas alokasi senar
    ///
    /// # Panics
    ///
    /// Panics upami `new_len` henteu ngagolér dina wates [`char`].
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Ngaleupaskeun karakter terakhir tina panyangga senar sareng mulih deui.
    ///
    /// Mulih [`None`] upami `String` ieu kosong.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Ngaleungitkeun [`char`] tina `String` ieu dina posisi bait sareng balikeun deui.
    ///
    /// Ieu mangrupikeun operasi *O*(*n*), sabab meryogikeun nyalin unggal unsur dina panyangga.
    ///
    /// # Panics
    ///
    /// Panics upami `idx` langkung ageung tibatan atanapi sami sareng panjangna `String`, atanapi upami éta henteu aya dina wates [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Cabut sadaya pertandingan pola `pat` dina `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Pertandingan bakal kauninga sareng dipiceun iteratif, janten dina kasus pola tumpang tindihna, mung pola anu munggaran bakal dihapus:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // Kasalametan: ngamimitian jeung tungtung bakal on utf8 wates bait per
        // dokumén Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Simpen ngan ukur karakter anu ditangtukeun ku prédikat.
    ///
    /// Kalayan kecap séjén, hapus sadaya karakter `c` sapertos `f(c)` mulih `false`.
    /// Metoda ieu jalan dina tempatna, nganjang ka unggal karakter persis sakali dina urutan aslina, sareng ngajaga urutan karakter anu dipikagaduh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Urutan anu pasti tiasa dianggo pikeun nyukcruk kaayaan luar, sapertos indéks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Arahkeun idx kana char salajengna
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Selapkeun karakter kana `String` ieu dina posisi bait.
    ///
    /// Ieu mangrupikeun operasi *O*(*n*) sabab peryogi nyalin unggal unsur dina panyangga.
    ///
    /// # Panics
    ///
    /// Panics upami `idx` langkung ageung tibatan panjangna 'String`, atanapi upami éta henteu aya dina wates [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Lebetkeun sapotong senar kana `String` ieu dina posisi bait.
    ///
    /// Ieu mangrupikeun operasi *O*(*n*) sabab peryogi nyalin unggal unsur dina panyangga.
    ///
    /// # Panics
    ///
    /// Panics upami `idx` langkung ageung tibatan panjangna 'String`, atanapi upami éta henteu aya dina wates [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Mulihkeun rujukan anu tiasa dirobih kana eusi `String` ieu.
    ///
    /// # Safety
    ///
    /// Fungsi ieu henteu aman sabab henteu mariksa yén bait anu diliwatan ka UTF-8 anu valid.
    /// Upami kendala ieu dilanggar, éta tiasa nyababkeun masalah teu aman ingetan ku pangguna future tina `String`, sabab sésana perpustakaan standar nganggap yén `String`s valid UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Balikkeun panjang `String` ieu, dina bait, sanés [`char`] s atanapi graphemes.
    /// Kalayan kecap séjén, panginten sanés anu dianggap manusa panjang tina senar.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Mulih `true` lamun `String` ieu boga panjang enol, sarta `false` disebutkeun.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Beulah senar kana dua dina indéks bait anu ditangtoskeun.
    ///
    /// Balikkeun `String` anu énggal dikaluarkeun.
    /// `self` ngandung bait `[0, at)`, sarta balik `String` ngandung bait `[at, len)`.
    /// `at` kedah dina wates titik kode UTF-8.
    ///
    /// Catet yén kapasitas `self` henteu robih.
    ///
    /// # Panics
    ///
    /// Panics upami `at` henteu dina wates titik kode `UTF-8`, atanapi upami éta ngalangkungan titik kode terakhir tina senar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Potong `String` ieu, ngaleungitkeun sadaya kontén.
    ///
    /// Nalika ieu hartosna `String` bakal gaduh panjang enol, éta henteu keuna kapasitas na.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Nyiptakeun iterator draining anu ngaluarkeun rentang anu ditangtoskeun dina `String` sareng ngahasilkeun `chars` anu dihapus.
    ///
    ///
    /// Note: Kisaran unsur dipiceun sanajan iterator henteu dikonsumsi dugi ka tungtungna.
    ///
    /// # Panics
    ///
    /// Panics upami titik awal atanapi titik akhir henteu ngagolér dina wates [`char`], atanapi upami aranjeunna henteu aya watesnana.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Cabut jajaran dugi ka β tina senar
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Jangkauan lengkep mupus senar
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Kaamanan mémori
        //
        // Versi String of Drain henteu ngagaduhan masalah kaamanan ingetan tina versi vector.
        // Data ngan ukur bait.
        // Kusabab panyabutan jengkol kajantenan di Drop, upami iterator Drain bocor, panyabutanna moal kajadian.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Candak kaluar dua injeuman sakaligus.
        // &mut String moal diaksés dugi Iteration réngsé, dina Drop.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` sareng `is_char_boundary` ngalakukeun cék wates anu cocog.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Ngaluarkeun rentang dieusian dina senar, sarta ngagantikeun dinya jeung string dibikeun.
    /// Senar anu dipasihkeun henteu kedah panjang anu sami sareng kisaran.
    ///
    /// # Panics
    ///
    /// Panics upami titik awal atanapi titik akhir henteu ngagolér dina wates [`char`], atanapi upami aranjeunna henteu aya watesnana.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ganti jajaran dugi ka β tina senar
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Kaamanan mémori
        //
        // Change_range teu ngagaduhan masalah kaamanan ingetan tina vector Splice.
        // tina versi vector.Data ngan ukur bait.

        // PERHATOSAN: Ngalebetkeun variabel ieu janten unsound (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // PERHATOSAN: Ngalebetkeun variabel ieu janten unsound (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Nganggo `range` deui bakal janten unsound (#81138) Kami anggap wates anu dilaporkeun ku `range` tetep sami, tapi palaksanaan lawan tiasa ngarobih antar telepon
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ngarobih `String` ieu kana [`Box`]`<`[`str`] `>`.
    ///
    /// Ieu bakal lungsur kaleuleusan kapasitas.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Mulih nyiksikan of [`u8`] s bait nya éta nyoba ngarobah ka `String`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait anu henteu valid, dina vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Balikkeun bait anu diusahakeun dikonversi janten `String`.
    ///
    /// Metoda ieu sacara saksama diwangun pikeun nyingkahan alokasi.
    /// Éta bakal nyéépkeun kasalahan, mindahkeun bait, supados salinan bait henteu kedah dilakukeun.
    ///
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait anu henteu valid, dina vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Angkat `Utf8Error` pikeun kéngingkeun langkung seueur rinci ngeunaan kagagalan konversi.
    ///
    /// Jinis [`Utf8Error`] anu disayogikeun ku [`std::str`] ngagambarkeun kasalahan anu tiasa kajantenan nalika ngarobih sapotong [`u8`] s janten [`&str`].
    /// Dina pengertian ieu, éta analog kana `FromUtf8Error`.
    /// Tingali dokuméntasi na pikeun langkung seueur detil tentang ngagunakeun éta.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// // sababaraha bait anu henteu valid, dina vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // bait kahiji henteu valid di dieu
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kusabab urang nuju ngagulkeun `String`s, urang tiasa nyingkahan sahanteuna hiji alokasi ku kéngingkeun string anu pangheulana tina iterator sareng nambihan sadayana senar salajengna.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Kusabab urang ngulang deui kana CoWs, urang tiasa (potentially) nyingkahan sahanteuna hiji alokasi ku kéngingkeun barang anu pangheulana sareng nambihan sadaya item anu salajengna.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// A genah impl anu utusan ka impl pikeun `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Nyiptakeun `String` kosong.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ngalaksanakeun operator `+` pikeun ngagabungkeun dua senar.
///
/// Ieu meakeun `String` di sisi kénca sareng nganggo deui panyangga na (tumuh upami diperyogikeun).
/// Hal ieu dilakukeun pikeun nyingkahan nyawiskeun `String` anyar sareng nyalin sadaya eusi dina unggal operasi, anu bakal ngakibatkeun *O*(*n*^ 2) waktos ngajalankeun nalika ngawangun senar *n*-byte ku concatenation ulang.
///
///
/// Senar di sisi-sisi katuhu ngan ukur diinjeum;eusina disalin kana `String` anu dipulangkeun.
///
/// # Examples
///
/// Ngalangkungan dua `String`s anu mimiti ku nilai sareng diinjeuman anu kadua:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` dipindahkeun sareng teu tiasa dianggo deui didieu.
/// ```
///
/// Upami anjeun hoyong teras-terasan nganggo `String` anu munggaran, anjeun tiasa ngagentoskeun sareng nambihan kana clone.
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` masih valid di dieu.
/// ```
///
/// Campuran keureut `&str` tiasa dilakukeun ku ngarobih anu pangheulana janten `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ngalaksanakeun operator `+=` kanggo nambihan `String`.
///
/// Ieu ngagaduhan kabiasaan anu sami sareng metode [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Jinis alias pikeun [`Infallible`].
///
/// Landian ieu aya kanggo kasaluyuan mundur, sareng akhirna tiasa lungsur.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait pikeun ngarobih nilai kana `String`.
///
/// trait ieu sacara otomatis dilaksanakeun pikeun naon waé jinis anu ngalaksanakeun [`Display`] trait.
/// Sapertos kitu, `ToString` henteu kedah diterapkeun langsung:
/// [`Display`] kedah dilaksanakeun gantina, sareng anjeun kéngingkeun palaksanaan `ToString` gratis.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Ngarobih nilai anu dibéré ka `String`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Dina palaksanaan ieu, metoda `to_string` panics upami palaksanaan `Display` mulihkeun kasalahan.
/// Ieu nunjukkeun palaksanaan `Display` lepat kumargi `fmt::Write for String` henteu pernah ngasilkeun kasalahan nyalira.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Pitunjuk umum pikeun henteu inline fungsi generik.
    // Nanging, ngaleungitkeun `#[inline]` tina metoda ieu nyababkeun régrési anu teu tiasa diémutan.
    // Tingali <https://github.com/rust-lang/rust/pull/74852>, usaha terakhir pikeun nyobaan nyabutna.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Ngarobih `&mut str` kana `String`.
    ///
    /// hasilna ieu disadiakeun dina numpuk.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: tés narik dina libstd, anu nyababkeun kasalahan di dieu
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Ngarobih potongan `str` anu dibérékeun kana `String`.
    /// Éta kasohor yén potongan `str` dipimilik.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Ngarobih `String` anu dipasihkeun kana keureutan `str` kotak anu dipimilik.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Ngarobih sapotong senar kana varian Pinjaman.
    /// Henteu aya alokasi tumpukan, sareng senar na henteu disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Ngarobih senar kana varian Anu Milik.
    /// Henteu aya alokasi tumpukan, sareng senar na henteu disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Ngarobih hiji rujukan String kana varian Pinjaman.
    /// Henteu aya alokasi tumpukan, sareng senar na henteu disalin.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Ngarobih `String` anu dipasihkeun ka vector `Vec` anu ngagaduhan nilai tipe `u8`.
    ///
    /// # Examples
    ///
    /// Dasar panggunaan:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// A iterator draining pikeun `String`.
///
/// Struktur ieu diciptakeun ku metode [`drain`] dina [`String`].
/// Tingali dokuméntasi na pikeun langkung seueur.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Bakal dipaké salaku&'a Mut String dina destructor
    string: *mut String,
    /// Mimiti bagian pikeun dipiceun
    start: usize,
    /// Tungtung bagéan dipiceun
    end: usize,
    /// sésana rentang ayeuna ngaleupaskeun
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Anggo Vec::drain.
            // "Reaffirm" bounds cek pikeun nyingkahan kode panic dilebetkeun deui.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Balikkeun sésana (sub) senar iterator ieu salaku potongan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls handap nalika stabilisasi.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment nalika stabilisasi `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>pikeun Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> pikeun Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}