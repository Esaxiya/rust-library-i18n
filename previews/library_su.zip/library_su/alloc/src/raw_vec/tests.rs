use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Nulis tés integrasi antara alokasi pihak katilu sareng `RawVec` rada hésé kusabab `RawVec` API henteu ngalaan metode alokasi anu lepat, janten kami moal tiasa parios naon anu kajantenan nalika alokator parantos béak (saluareun ngadeteksi panic).
    //
    //
    // Sabalikna, ieu ngan cek yén metode `RawVec` sahenteuna ngaliwat Allocator API nalika nyimpen panyimpenan.
    //
    //
    //
    //
    //

    // Aloktor boloho anu nyéépkeun jumlah BBM anu tetep sateuacan usaha alokasi mimitian gagal.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (nyababkeun realloc, sahingga nganggo 50 + 150=200 unit bahan bakar)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Mimiti, `reserve` alokasi sapertos `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 langkung ti dua kali tina 7, janten `reserve` kedah dianggo sapertos `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 kirang ti satengah tina 12, janten `reserve` kedah tumuh sacara éksponénsial.
        // Dina waktos nyerat ieu tés mangrupikeun 2 faktor, janten kapasitas énggal 24, nanging, faktor pertumbuhan 1.5 henteu kunanaon ogé.
        //
        // Maka `>= 18` dina negeskeun.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}