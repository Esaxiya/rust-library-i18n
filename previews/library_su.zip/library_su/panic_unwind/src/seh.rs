//! Windows SEH
//!
//! Dina Windows (ayeuna ukur dina MSVC), iwal standar mékanisme nanganan ieu terstruktur iwal Ngatur (SEH).
//! Ieu rada béda ti dumasar dwarf-penanganan iwal (misalna naon platform séjénna unix make) dina jihat internals compiler, jadi LLVM anu diperlukeun pikeun boga deal alus pangrojong tambahan pikeun Paséh.
//!
//! Dina nutshell hiji, naon kajadian di dieu nyaéta:
//!
//! 1. Fungsi `panic` nyauran fungsi Windows standar `_CxxThrowException` pikeun maledogkeun C++ -sapertos pengecualian, prosés anu ngiringan.
//! 2.
//! Kabéh hampang badarat dihasilkeun ku compiler anu nganggo fungsi kapribadian `__CxxFrameHandler3`, hiji fungsi dina CRT, sarta kodeu unwinding di Windows bakal ngagunakeun fungsi kapribadian ieu sangkan ngaéksekusi sadayana kode cleanup on tumpukan éta.
//!
//! 3. Kabéh télépon kompiler-dihasilkeun kana `invoke` boga set badarat Pad salaku instruksi `cleanuppad` LLVM, nu nunjukkeun mimiti tina rutin cleanup.
//! Kapribadian (dina léngkah 2, ditetepkeun dina CRT) tanggel waler pikeun ngajalankeun rutinitas beberesih.
//! 4. Akhirna kode "catch" dina `try` intrinsik (dihasilkeun ku panyusunna) dieksekusi sareng nunjukkeun yén kontrol kedahna sumping deui ka Rust.
//! Hal ieu dilakukeun ngalangkungan `catchswitch` ditambah paréntah `catchpad` dina istilah LLVM IR, tungtungna balikkeun kontrol normal pikeun program kalayan paréntah `catchret`.
//!
//! Sababaraha bédana khusus tina pangaturan pengecualian basis gcc nyaéta:
//!
//! * Rust boga fungsi kapribadian custom, éta gantina *salawasna*`__CxxFrameHandler3`.Sajaba, teu nyaring tambahan anu dipigawé, sangkan mungkas nepi catching sagala C++ éntitas nu lumangsung kasampak kawas jenis kami ngalungkeun nuju.
//! Catet yén ngalungkeun pengecualian kana Rust mangrupikeun tingkah laku anu teu ditangtoskeun, janten ieu kedah saé.
//! * Kami ngagaduhan sababaraha data pikeun ngalirkeun wates anu teu dibereskeun, khususna `Box<dyn Any + Send>`.Kawas kalawan iwal dwarf dua pointers ieu disimpen salaku payload dina iwal sorangan.
//! Dina MSVC, kumaha oge, aya henteu butuh hiji alokasi numpuk tambahan kusabab tumpukan panggero ieu dilestarikan bari fungsi filter nu keur dibales.
//! Ieu hartosna yén pointers anu diliwatan langsung ka `_CxxThrowException` nu lajeng pulih dina fungsi filter bisa ditulis kana pigura tumpukan tina intrinsik `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // pangabutuh ieu janten hiji Pilihan sabab kami nyekel iwal ku rujukan tur destructor na geus dieksekusi ku C++ runtime.
    // Nalika urang nyandak Box kaluar tina iwal, urang kudu ninggalkeun iwal dina kaayaan valid pikeun destructor-na pikeun ngajalankeun tanpa ganda-muterna Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// up heula, sacara gembleng kebat tipe definisi.Aya sababaraha oddities platform-spésifik didieu, sarta loba nu bakal ngan blatantly disalin ti LLVM.Tujuan sadayana ieu pikeun nerapkeun fungsi `panic` di handap ngalangkungan panggero ka `_CxxThrowException`.
//
// Fungsi ieu nyandak dua alesan.Anu kahiji mangrupikeun pointer kana data anu nuju kami pasihan, anu dina hal ieu mangrupikeun objék trait urang.Geulis gampang pikeun manggihan!Anu salajengna, Nanging, langkung rumit.
// Ieu pointer kana struktur `_ThrowInfo`, sarta eta umumna geus ngan dimaksudkeun pikeun ngan ngajelaskeun iwal keur dialungkeun.
//
// Ayeuna definisi tipe [1] ieu rada buluan, sareng kaanehan utama (sareng béntenna tina tulisan online) nyaéta dina 32-bit pointer mangrupikeun pointer tapi dina 64-bit pointer dinyatakeun salaku offset 32-bit ti `__ImageBase` simbol.
//
// Makro `ptr_t` sareng `ptr!` dina modul di handap ieu dipaké pikeun nganyatakeun ieu.
//
// Maze tina definisi jenis ogé nuturkeun sacara caket naon anu dikaluarkeun LLVM pikeun operasi sapertos kieu.Contona, lamun compile C ieu++ kode dina MSVC na emit nu IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      batal foo() { rust_panic a = {0, 1};
//          maledog a;}
//
// Éta dasarna naon nuju kami nyoba emulate.Kalolobaan nilai angger handap anu ngan disalin ti LLVM,
//
// Bisi wae, struktur ieu sadayana diwangun dina cara anu sami, sareng éta ngan ukur rada verosa pikeun urang.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Catetan yen urang ngahaja malire ngaran mangling aturan di dieu: urang teu hayang C++ ka bisa nyekel Rust panics ku saukur nyatakeun `struct rust_panic`.
//
//
// Nalika ngarobih, pastikeun yén senar nami jinis pas pisan sareng anu dianggo dina `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // The ngarah `\x01` bait didieu sabenerna ngarupakeun sinyal gaib mun LLVM ka *moal* nerapkeun sagala mangling séjén kawas prefixing kalawan karakter `_`.
    //
    //
    // Simbol ieu mangrupikeun vélét anu dianggo ku C++ `std::type_info`.
    // Objék tina tipe `std::type_info`, tipe descriptors, boga pointer kana méja ieu.
    // Tipe descriptors anu referenced ku struktur C++ EH diartikeun luhur tur nu urang nyusunna handap.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// tipe descriptor Ieu ukur dipaké nalika ngalungkeun iwal.
// Bagian nyekel ieu diatur ku intrinsik try, anu dibangkitkeun TypeDescriptor sorangan.
//
// Ieu rupa ti MSVC kagunaan runtime string ngabandingkeun dina ngaran tipe mun TypeDescriptors cocok tinimbang pointer sarua.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor dipaké lamun C++ kode megatkeun pikeun moto iwal sarta teundeun eta tanpa megat eta.
// Bagian néwak tina intrinsik coba bakal nyetél kecap mimiti objék pangecualian ka 0 ku éta dilewatan ku tukang ngarusak.
//
// Catet yén x86 Windows nganggo konvénsi panggero "thiscall" pikeun fungsi anggota C++ sanés konvénsi standar nelepon "C".
//
// Fungsi exception_copy rada khusus di dieu: diseru ku runtime MSVC handapeun blok try/catch sareng panic anu urang ngahasilkeun di dieu bakal dianggo salaku hasil tina salinan pengecualian.
//
// Ieu dianggo ku waktos runtuhna C++ pikeun ngadukung néwak pengecualian ku std::exception_ptr, anu kami henteu tiasa ngadukung kusabab Box<dyn Any>henteu tiasa dikorupsi.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException laksanakeun sacara lengkep dina pigura tumpukan ieu, janten teu kedah ditransferkeun `data` kana tumpukan.
    // Kami ngan saukur ngalepaskeun pointer tumpukan kana fungsi ieu.
    //
    // The ManuallyDrop ieu diperlukeun dieu saprak urang teu hayang iwal bisa turun lamun unwinding.
    // Sabalikna éta bakal turun ku exception_cleanup anu diseru ku runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ieu ... sigana sigana héran, sareng kabeneran kitu.Dina 32-bit MSVC nu pointers antara struktur ieu ngan éta, pointers.
    // Dina 64-bit MSVC, Nanging, petunjuk antara struktur rada dikedalkeun salaku offset 32-bit ti `__ImageBase`.
    //
    // Akibatna, di 32-bit MSVC bisa dibewarakeun sadayana pointers ieu di `static`s luhur.
    // Dina 64-bit MSVC, urang kedah nganyatakeun pangirangan petunjuk dina statis, anu Rust henteu ayeuna ngantepkeun, janten urang henteu tiasa leres-leres ngalakukeun éta.
    //
    // Hal pangalusna hareup, teras nya mun eusian struktur ieu di runtime (panicking geus di "slow path" atoh).
    // Janten di dieu urang nafsirkeun sadayana bidang pointer ieu salaku bilangan bulat 32-bit teras nyimpen nilai anu aya di dalamnya (sacara atom, sabab panics babarengan tiasa kajadian).
    //
    // Sacara téknis runtime sigana bakal maca nonatomik ngeunaan widang ieu, tapi dina tiori aranjeunna henteu pernah maca nilaina *lepat* janten henteu goréng teuing ...
    //
    // Bisi wae, urang dasarna perlu ngalakukeun hal kawas kieu dugi urang tiasa nganyatakeun operasi beuki di statics (jeung urang bisa pernah bisa).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A muatan Null didieu hartosna yén urang dugi ka dieu tina nyekel (...) tina __rust_try.
    // Ieu kajadian nalika pengecualian asing non-Rust dicekel.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Ieu diperyogikeun ku panyusun pikeun aya (mis., Éta barang hungkul), tapi éta henteu leres-leres disebat ku panyusun kusabab __C_specific_handler atanapi_except_handler3 nyaéta fungsi kapribadian anu sok dianggo.
//
// Mangkana ieu ngan hiji taratas, perlu disampurnakeun aborting.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}