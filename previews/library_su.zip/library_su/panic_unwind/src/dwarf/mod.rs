//! Utiliti pikeun parsing aliran data anu dikodekeun DWARF.
//! Tingali <http://www.dwarfstd.org>, DWARF-4 standar, Bagéan 7, "Data Representation"
//!

// modul ieu ngan dipaké ku x86_64-pc-jandéla-gnu keur ayeuna, tapi urang anu compiling eta madhab ka regressions ulah.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // Aliran DWARF dikemas, janten contona, u32 moal merta dijajarkeun dina wates 4-bait.
    // Ieu tiasa nyababkeun masalah dina platform anu gaduh syarat alignment anu ketat.
    // Ku ngabungkus data dina "packed" struct, urang nyarios ka tukang pikeun ngahasilkeun kode "misalignment-safe".
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 na SLEB128 encodings nu didefinisikeun dina Bagéan 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}