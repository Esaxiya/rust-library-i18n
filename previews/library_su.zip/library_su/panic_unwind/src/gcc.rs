//! Palaksanaan panics didukung ku libgcc/libunwind (dina sababaraha bentuk).
//!
//! Pikeun latar tukang ngeunaan pangecualian pengecualian sareng tumpukan jalan kaluar mangga tingali "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) sareng dokumén anu dikaitkeun tina éta.
//! Ieu ogé maos anu saé:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## A kasimpulan ringkes
//!
//! penanganan iwal kajadian dina dua siklus: fase pilarian sarta fase cleanup.
//!
//! Dina kadua fase éta unwinder milampah pigura tumpukan ti luhur ka handap nganggo inpormasi tina pigura tumpukan ngoringan bagian tina modul prosés ayeuna ("module" di dieu ngarujuk kana modul OS, nyaéta perpustakaan anu tiasa dieksekusi atanapi dinamis).
//!
//!
//! Pikeun unggal pigura tumpukan, éta invokes nu dimaksudkeun "personality routine", anu alamatna oge disimpen di bagian info unwind.
//!
//! Dina fase pilarian, pakasaban of a rutin kapribadian anu nalungtik iwal obyék keur dialungkeun, sarta pikeun mutuskeun kudu bray dina éta pigura tumpukan.Sakali pigura pawang parantos dikenalkeun, fase pembersihan dimimitian.
//!
//! Dina fase cleanup, unwinder nu invokes unggal rutin kapribadian deui.
//! Waktos Ieu mutuskeun anu (upami aya) kode pembersihan kedah ngajalankeun pikeun pigura tumpukan ayeuna.Lamun kitu, kontrol nu ditransferkeun ka branch husus dina awak fungsi, nu "landing pad" nu invokes destructors, frees mémori, jeung sajabana
//! Dina ahir badarat Pad, kontrol ditransferkeun deui ka unwinder na unwinding dihanca.
//!
//! Sakali tumpukan geus unwound handap ka tingkat pigura Handler, unwinding titik jeung kapribadian panungtungan Mindahkeun rutin ngadalikeun ka blok nyekel.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identifier kelas pengecualian Rust.
// Ieu dipake ku rutinitas kapribadian keur ngabedakeun iwal ieu dialungkeun ku runtime sorangan.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 karat-ngajual, basa
    0x4d4f5a_00_52555354
}

// Ngadaptar Gajah Mungkur anu diangkat ti LLVM urang TargetLowering::getExceptionPointerRegister() na TargetLowering::getExceptionSelectorRegister() pikeun tiap arsitektur, teras dipetakeun kana nomer register dwarf via tabel register harti (ilaharna<arch>RegisterInfo.td, milari "DwarfRegNum").
//
// Tempo ogé http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Kodeu handap ieu dumasar kana GCC urang C jeung C++ Kabiasaan kapribadian.Pikeun rujukan, tingali:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI kapribadian rutin.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS nganggo rutin standar tibatan éta nganggo SjLj ngalaunan baju.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces dina ARM bakal nyauran rutinitas kapribadian ku kaayaan==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Dina kasus-kasus éta kami hoyong teraskeun ngagugulung tumpukan, upami henteu sadaya béréndélan urang bakal réngsé dina __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // The DWARF unwinder nganggap yén_Unwind_Context nyepeng hal-hal sapertos fungsi sareng petunjuk LSDA, nanging ARM EHABI nempatkeun aranjeunna kana objék pangecualian.
            // Pikeun ngawétkeun tandatangan fungsi sapertos _Unwind_GetLanguageSpecificData(), anu ngan ukur nganggo pointer kontéks, rutinitas kapribadian GCC nyimpen pointer ka exception_object dina kontéks, nganggo lokasi anu disayogikeun pikeun ARM's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Hiji pendekatan langkung principled bakal nyadiakeun éta harti pinuh ku ARM urang_Unwind_Context di bindings libunwind urang jeung dipulut data diperlukeun ti dinya langsung, bypassing fungsi kasaluyuan dwarf.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI meryogikeun rutinitas kapribadian pikeun ngapdet nilai SP dina cache panghalang tina obyék pengecualian.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Dina ARM EHABI rutinitas kapribadian tanggung jawab pikeun leres-leres ngahanca hiji pigura tumpukan sateuacan balik (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // ditetepkeun dina libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // kapribadian rutin standar, nu geus dipake langsung di paling target na langsung di Windows x86_64 via Paséh.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Dina target x86_64 MinGW, mékanisme unwinding nyaeta Paséh kumaha ogé data Handler unwind (aka LSDA) migunakeun encoding GCC-cocog.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Kapribadian rutin pikeun kalolobaan target urang.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Alamat pengulangan nunjuk 1 bait ngalangkungan paréntah panggero, anu tiasa dina kisaran IP salajengna dina tabel rentang LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Pendaptaran info bingkai bérés
//
// gambar unggal modul urang ngandung pigura info unwind bagian (biasana ".eh_frame").Nalika modul hiji loaded/unloaded kana prosésna, unwinder kudu informed ngeunaan lokasi di bagian ieu memori.Métode achieving yén rupa-rupa ku platform nu.
// Dina sababaraha (mis., Linux), anu tiasa léngkah tiasa mendakan bagian inpormasi nyalira (ku sacara dinamis ngitung modul anu ayeuna dimuat ngalangkungan dl_iterate_phdr() API and finding their ".eh_frame" sections); Anu sanésna, sapertos Windows, meryogikeun modul pikeun aktip ngadaptar bagian inpormasi aranjeunna ngalangkungan ngalangkungan API.
//
//
// modul ieu ngahartikeun dua simbol nu referenced tur disebutna tina rsbegin.rs pikeun ngadaptar informasi urang jeung runtime GCC.
// Implementasi stack unwinding nyaéta (pikeun ayeuna) ditangguhkeun ka libgcc_eh, tapi Rust crates nganggo titik entri khusus Rust ieu pikeun nyegah bénjolan poténsial kalayan runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}