//! Unwinding panics pikeun Miri.
use alloc::boxed::Box;
use core::any::Any;

// Jinis payload anu mesin Miri ngarambat ngaliwatan unwinding pikeun urang.
// Kedah janten pointer-ukuran.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-disadiakeun fungsi extern dimimitian unwinding.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Payload anu urang pasihkeun ka `miri_start_panic` bakalan persis argumen anu urang pikagaduh dina `cleanup` di handap.
    // Janten urang ngan saukur kotakkeun sakali, pikeun kéngingkeun hal ukuran pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Cageur `Box` anu janten dasarna.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}