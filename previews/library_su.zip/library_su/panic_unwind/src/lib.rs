//! Palaksanaan panics via unwinding tumpukan
//!
//! crate ieu mangrupikeun palaksanaan panics dina Rust ngagunakeun mékanisme "most native" X tumpukan undingan platform anu nuju disusun.
//! Ieu dasarna bakal categorized kana tilu ember ayeuna:
//!
//! 1. target MSVC nganggo Paséh dina file `seh.rs`.
//! 2. Emscripten nganggo pengecualian C++ dina file `emcc.rs`.
//! 3. Sadaya target sanés nganggo libunwind/libgcc dina file `gcc.rs`.
//!
//! dokuméntasi Leuwih lengkep ngeunaan unggal palaksanaan bisa kapanggih dina modul masing-masing.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` henteu dianggo sareng Miri, janten tiiseun peringatan.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Obyek ngamimitian Rust runtime gumantung kana simbol ieu, janten jantenkeun aranjeunna umum.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Target anu teu ngarojong unwinding.
        // - arch=wasm32
        // - os=teu aya (target "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Anggo runtime Miri.
        // Simkuring masih perlu ogé muka éta runtime normal luhur, sakumaha rustc ekspektasi item lang tangtu ti dinya mun dihartikeun.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Anggo runtime nyata.
        use real_imp as imp;
    }
}

extern "C" {
    /// Pawang dina libstd disebat nalika obyék panic murag di luar `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler di libstd disebutna lamun iwal asing anu bray.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// titik Éntri pikeun raising hiji mahiwal, ngan delegasi pikeun palaksanaan platform-spésifik.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}