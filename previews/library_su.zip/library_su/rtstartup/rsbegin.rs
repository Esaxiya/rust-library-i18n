// rsbegin.o sareng rsend.o anu disebat "compiler runtime startup objects".
// Éta ngandung kode diperlukeun pikeun neuleu initialize nu runtime compiler.
//
// Nalika hiji gambar laksana atanapi dylib numbu, sadaya kode pamaké sarta perpustakaan anu "sandwiched" antara dua file obyék ieu, jadi kode atanapi data ti rsbegin.o jadi munggaran di bagian masing-masing gambar, sedengkeun kode jeung data ti rsend.o jadi leuwih panungtungan.
// Épék ieu tiasa dianggo pikeun nempatkeun simbol dina mimiti atanapi di tungtung hiji bagian, ogé pikeun ngalebetkeun header atanapi footer anu diperyogikeun.
//
// Catetan yén titik Éntri modul sabenerna aya di C runtime obyék ngamimitian (biasana disebut `crtX.o`), nu lajeng invokes initialization callbacks komponén runtime séjén (didaptarkeun via acan bagian gambar husus sejen).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Tanda mimiti bagian inpo tumpukan undurkeun info
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ruang gores pikeun nyimpen buku internal unwinder.
    // Ieu diartikeun `struct object` dina $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // info Unwind Kabiasaan registration/deregistration.
    // Tingali dokumén libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ngadaptar info unwind on ngamimitian modul
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unregister nalika mareuman
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Pendaptaran rutin XGX khusus MinGW-spésifik
    pub mod mingw_init {
        // MinGW urang ngamimitian objék (crt0.o/dllcrt0.o) baris nu dipake konstruktor global dina .ctors na .dtors bagian on ngamimitian tur kaluar.
        // Dina kasus DLLs, ieu dilakukeun nalika DLL dimuat sareng dimuat.
        //
        // linker bakal nyortir nu bagian, nu ensures nu callbacks kami anu lokasina di ahir daptar.
        // Kusabab konstruktor dijalankeun dina urutan anu tibalik, ieu mastikeun yén callbacks kami anu kahiji sareng anu terakhir dieksekusi.
        //
        //

        #[link_section = ".ctors.65535"] // .ctor. *: C callback inisialisasi
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dokter. *: Callbacks terminasi C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}