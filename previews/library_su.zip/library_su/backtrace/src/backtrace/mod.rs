use core::ffi::c_void;
use core::fmt;

/// Mariksa panggero-tumpukan ayeuna, ngalirkeun sadaya pigura aktip kana panutupanana anu disayogikeun kanggo ngitung tilas tumpukan.
///
/// Pungsi ieu teh workhorse perpustakaan di ngitung ngambah tumpukan pikeun program a.panutupanana `cb` nu dibikeun keur yielded instansi of a `Frame` nu ngagambarkeun informasi ngeunaan eta pigura panggero dina tumpukan nu.
/// Panutupanana ngahasilkeun pigura dina mode luhur-handap (paling anyar disebut fungsi mimitina).
///
/// Nilai balik panutupanana mangrupikeun indikasi naha backtrace kedah diteraskeun.A nilai balikna `false` bakal nungtungan backtrace tur balik langsung.
///
/// Sakali `Frame` kaala anjeun sigana bakal hoyong nelepon `backtrace::resolve` pikeun ngarobih `ip` (instruksi pointer) atanapi alamat simbol kana `Symbol` anu ngalangkungan nami sareng/atanapi nami nami/nomer garis tiasa diajar.
///
///
/// Catet yén ieu mangrupikeun fungsi tingkat rendah sareng upami anjeun hoyong, contona, candak backtrace kanggo diparios engké, maka jinis `Backtrace` panginten langkung pas.
///
/// # Fitur anu diperyogikeun
///
/// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
///
/// # Panics
///
/// Fungsi ieu narékahan pikeun pernah panic, tapi upami `cb` nyayogikeun panics maka sababaraha platform bakal maksa panic dobel pikeun ngagugurkeun prosés na.
/// Sababaraha platform nganggo perpustakaan C anu sacara internal nganggo callbacks anu henteu tiasa dibahas, janten panicking ti `cb` tiasa memicu prosés abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // teraskeun backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sarua sareng `trace`, ngan ukur henteu aman sabab éta henteu disingkronkeun.
///
/// Fungsi ieu henteu ngagaduhan jaminan sinkronisasi tapi sayogi nalika fitur `std` tina crate ieu henteu disusun.
/// Tingali fungsi `trace` pikeun langkung seueur dokuméntasi sareng conto.
///
/// # Panics
///
/// Tempo inpo on `trace` pikeun caveats on `cb` panicking.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait ngalambangkeun hiji pigura tina backtrace, ngahasilkeun fungsi `trace` tina crate ieu.
///
/// panutupanana The tracing fungsi urang bakal yielded pigura, sarta pigura geus ampir dispatched salaku palaksanaan kaayaan henteu salawasna dipikawanoh dugi runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Mulang panunjuk arah ayeuna tina pigura ieu.
    ///
    /// Ieu ilaharna mangrupikeun pitunjuk salajengna pikeun ngaéksekusi dina pigura, tapi henteu sadayana palaksanaan nyatakeun ieu sareng akurasi 100% (tapi sacara umum caket pisan).
    ///
    ///
    /// Disarankeun ngalirkeun nilai ieu ka `backtrace::resolve` pikeun ngajantenkeun kana nami simbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Mulihkeun pointer tumpukan ayeuna tina pigura ieu.
    ///
    /// Dina hal éta backend moal tiasa milarian pointer stack pikeun pigura ieu, pointer null bakal dipulangkeun.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Mulang alamat simbol awal tina pigura fungsi ieu.
    ///
    /// Ieu bakal nyobian mundur petunjuk panunjuk anu dipulang ku `ip` ka mimiti pungsi, balikkeun nilai éta.
    ///
    /// Dina sababaraha kasus, kumaha oge, backends bakal ngan balik `ip` tina fungsi ieu.
    ///
    /// Nilai balik kadang tiasa dianggo upami `backtrace::resolve` gagal dina `ip` anu dipasihkeun di luhur.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Balikkeun alamat dasar tina modul anu dipiboga ku pigura.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ieu kedah didamel heula, pikeun mastikeun yén Miri langkung ngutamakeun platform host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ngan ukur dianggo dina dbghelp ngalambangkeun
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}