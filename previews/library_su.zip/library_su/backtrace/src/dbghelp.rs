//! Modul pikeun ngabantosan dina ngatur dbghelp bindings dina Windows
//!
//! Backtraces on Windows (sahenteuna pikeun MSVC) kalolobaanana didamel ngalangkungan `dbghelp.dll` sareng sababaraha rupa fungsi anu dikandungna.
//! Fungsi-fungsi ieu ayeuna dimuat *dinamis* tibatan ngahubungkeun ka `dbghelp.dll` sacara statis.
//! Ieu ayeuna dilakukeun ku perpustakaan standar (sareng dina tiori anu diperyogikeun di dinya), tapi mangrupikeun upaya pikeun ngabantosan ngirangan kagumantungan dll statis perpustakaan sabab backtraces biasana cukup opsional.
//!
//! Éta anu nyarios, `dbghelp.dll` ampir sok hasil dimuat dina Windows.
//!
//! Catet yén kumargi urang ngamuat sadayana dukungan ieu sacara dinamis, urang henteu tiasa leres-leres nganggo definisi atah dina `winapi`, tapi urang kedah ngahartikeun jinis fungsi pointer na nyalira sareng ngagunakeun éta.
//! Kami henteu leres-leres hoyong dina usaha ngaduplikasi winapi, janten kami ngagaduhan fitur Cargo `verify-winapi` anu negeskeun yén sadaya pangiket cocog sareng anu di winapi sareng fitur ieu diaktipkeun dina CI.
//!
//! Tungtungna, anjeun bakal nyatet di dieu yén dll pikeun `dbghelp.dll` henteu pernah diundeur, sareng anu ayeuna dihaja.
//! Pamikiranna nyaéta urang sacara global tiasa cache na nganggo éta antara nelepon ka API, nyingkahan loads/unloads anu mahal.
//! Upami ieu masalah pikeun detéktor kabocoran atanapi sapertos kitu urang tiasa nyebrang sasak nalika urang dugi ka dinya.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Gawe sareng `SymGetOptions` sareng `SymSetOptions` henteu aya dina winapi nyalira.
// Upami teu kitu ieu ngan ukur dianggo nalika urang nuju mariksa-dua jenis ngalawan winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Teu dihartikeun dina winapi acan
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ieu dihartikeun dina winapi, tapi éta henteu leres (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Teu dihartikeun dina winapi acan
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Makro ieu dianggo pikeun ngartikeun struktur `Dbghelp` anu sacara internal ngandung sadaya point point fungsi anu tiasa urang muatkeun.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL anu dimuat pikeun `dbghelp.dll`
            dll: HMODULE,

            // Unggal fungsi pointer pikeun tiap fungsi anu urang tiasa anggo
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Mimitina kami henteu acan ngunggah DLL
            dll: 0 as *mut _,
            // Initiall sadayana fungsi disetel ka nol pikeun nyarios yén aranjeunna kedah dimuat sacara dinamis.
            //
            $($name: 0,)*
        };

        // Genep typefef pikeun tiap jinis fungsi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Usaha pikeun muka `dbghelp.dll`.
            /// Mulih kasuksésan upami éta jalan atanapi kasalahan upami `LoadLibraryW` gagal.
            ///
            /// Panics upami perpustakaan parantos dimuat.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fungsi pikeun tiap metodeu anu hoyong kami anggo.
            // Upami disebatna naha bakal maca panunjuk fungsi sindangan atanapi muatkeunana sareng ngembalikan nilai anu dimuat.
            // Beban negeskeun pikeun suksés.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proksi genah nganggo konci pembersih pikeun ngarujuk fungsi dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialisasi sadaya dukungan anu diperyogikeun pikeun aksés fungsi `dbghelp` API tina crate ieu.
///
///
/// Catet yén fungsi ieu **aman**, sacara internal gaduh sinkronisasi nyalira.
/// Ogé dicatet yén aman pikeun nelepon fungsi ieu sababaraha kali sacara rekursif.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Hal kahiji anu kedah urang lakukeun nyaéta nyingkronkeun fungsi ieu.Ieu tiasa disebat sasarengan tina utas anu sanés atanapi sacara rekursif dina hiji benang.
        // Catetan yen eta urang trickier ti éta sanajan sabab naon nuju kami nganggo dieu, `dbghelp`,*ogé* pangabutuh bisa nyingkronkeun ku sadayana nelepon séjén pikeun `dbghelp` dina prosés ieu.
        //
        // Ilaharna henteu leres-leres seueur sauran kana `dbghelp` dina prosés anu sami sareng urang sigana tiasa aman nganggap yén urang ngan ukur anu ngaksésna.
        // Nanging, aya hiji pangguna anu utami urang kedah hariwang ngeunaan anu ironisna nyalira, tapi di perpustakaan standar.
        // Perpustakaan standar Rust gumantung kana crate ieu kanggo dukungan backtrace, sareng crate ieu ogé aya dina crates.io.
        // Ieu ngandung harti yén lamun perpustakaan standar nyetak backstace panic éta tiasa balap sareng crate ieu asalna tina crates.io, nyababkeun segfault.
        //
        // Pikeun ngabéréskeun masalah sinkronisasi ieu kami nganggo trik khusus Windows di dieu (saurna, pangwatesan khusus Windows ngeunaan sinkronisasi).
        // Kami nyiptakeun mutex *session-local* anu namina kanggo nangtoskeun telepon ieu.
        // Maksadna di dieu nyaéta perpustakaan standar sareng crate ieu henteu kedah ngabagi API tingkat Rust pikeun nyingkronkeun di dieu tapi tiasa dianggo di tukangeun layar pikeun mastikeun yén aranjeunna saling nyinkronkeun.
        //
        // Ku cara éta nalika fungsi ieu disebut ngalangkungan perpustakaan standar atanapi ngalangkung crates.io urang tiasa pastikeun yén mutex anu sami nuju kaala.
        //
        // Janten sadayana éta nyaéta nyarios yén hal anu mimiti kami laksanakeun di dieu nyaéta sacara atomna nyiptakeun `HANDLE` anu mangrupakeun mutex anu namina dina Windows.
        // Kami nyingkronkeun sakedik sareng utas sanés anu ngabagi fungsi ieu sacara khusus sareng mastikeun yén ngan ukur hiji gagang anu diciptakeun per conto tina fungsi ieu.
        // Catet yén gagangna henteu pernah ditutup sakali disimpen dina global.
        //
        // Saatos urang leres-leres buka konci urang ngan saukur kéngingkeunana, sareng cecekelan `Init` anu urang serahkeun bakal tanggel waler pikeun tungtungna.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, péh!Ayeuna urang sadayana parantos disinkronkeun sacara aman, hayu urang leres-leres ngamimitian ngolah sadayana.
        // Mimiti urang kedah mastikeun yén `dbghelp.dll` saleresna dimuat dina prosés ieu.
        // Urang ngalakukeun dinamis kieu ulah aya hiji kagumantungan statis.
        // Ieu sajarahna parantos dilakukeun pikeun ngabéréskeun masalah anu ngahubungkeun anéh sareng dimaksudkeun pikeun ngadamel binér sakedik langkung portabel kumargi ieu ageung ngan ukur utilitas debugging.
        //
        //
        // Sakali kami geus dibuka `dbghelp.dll` kami kudu nelepon sababaraha fungsi initialization di dinya, sarta eta urang wincikan leuwih handap.
        // Kami ngan ukur ngalakukeun ieu sakali, janten, urang ngagaduhan boolean global nunjukkeun naha urang parantos atos henteu atanapi henteu.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Pastikeun yén bandéra `SYMOPT_DEFERRED_LOADS` disetél, sabab numutkeun kana dokumén MSVC sorangan ngeunaan ieu: "This is the fastest, most efficient way to use the symbol handler.", janten hayu urang ngalakukeun éta!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sabenerna initialize lambang kalawan MSVC.Catet yén ieu tiasa gagal, tapi urang teu malire.
        // Henteu saé ton seni sateuacanna pikeun ieu, tapi LLVM internal sigana henteu nganggap nilai pengembalian di dieu sareng salah sahiji perpustakaan sanitizer di LLVM nyetak peringatan pikasieuneun upami ieu gagal tapi dasarna henteu ngémutanana dina jangka panjang.
        //
        //
        // Hiji hal ieu asalna nepi loba pikeun Rust éta perpustakaan baku sarta crate ieu dina crates.io duanana rék bersaing pikeun `SymInitializeW`.
        // Perpustakaan standar sacara historis hoyong ngainisialisasi teras ngabersihkeun seueur waktos, tapi ayeuna éta nganggo crate ieu ngandung hartos yén batur bakal ngamimitian heula sareng anu sanés bakal nyandak inisialisasi éta.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}