#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// A formatter pikeun backtraces.
///
/// Jenis ieu tiasa dianggo pikeun nyetak backtrace henteu paduli dimana asal backtrace na asalna.
/// Upami anjeun ngagaduhan jinis `Backtrace` maka palaksanaan `Debug` na parantos nganggo format percetakan ieu.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Gaya percetakan anu tiasa urang nyetak
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Prints a backtrace terser nu ideally ngan ngandung émbaran relevan
    Short,
    /// Nyetak backtrace anu ngandung sadaya inpormasi anu mungkin
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Ngadamel `BacktraceFmt` énggal anu bakal nyerat kaluaran kana `fmt` anu disayogikeun.
    ///
    /// The `format` argumen bakal ngadalikeun gaya nu backtrace kasebut dicitak, jeung argumen `print_path` bakal dipaké pikeun nyitak jeung instansi `BytesOrWideString` of filenames.
    /// jenis ieu diri teu ngalakukeun naon baé percetakan of filenames tapi callback ieu diperlukeun pikeun ngalakukeunana.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Prints hiji pamuka keur backtrace rék jadi dicitak.
    ///
    /// Ieu diperyogikeun dina sababaraha platform kanggo backtraces janten lengkep dilambangkeun engké, sareng upami sanésna ieu kedah janten metode anu munggaran anjeun nyauran saatos nyiptakeun `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Nambihan pigura kana kaluaran backtrace.
    ///
    /// Ieu bunuh mulih hiji conto RAII of a `BacktraceFrameFmt` nu bisa dipaké pikeun sabenerna nyitak pigura, sarta dina karuksakan éta bakal increment pigura counter.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Rengse kaluaran backtrace.
    ///
    /// Ieu ayeuna henteu-op tapi ditambihkeun pikeun kasaluyuan future kalayan format backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Ayeuna a no-op-- kaasup hook ieu ngidinan pikeun tambahan future.
        Ok(())
    }
}

/// A formatter pikeun ngan hiji pigura tina backtrace a.
///
/// jenis ieu dijieun ku fungsi `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Nyitak `BacktraceFrame` nganggo pigura formatter ieu.
    ///
    /// Ieu sacara rekursif bakal nyetak sadaya conto `BacktraceSymbol` dina `BacktraceFrame`.
    ///
    /// # Fitur anu diperyogikeun
    ///
    /// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Prints a `BacktraceSymbol` dina hiji `BacktraceFrame`.
    ///
    /// # Fitur anu diperyogikeun
    ///
    /// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ieu henteu saé pisan yén kami henteu tungtungna nyetak nanaon
            // kalayan ngaran filing non-utf8.
            // Thankfully ampir sagalana is utf8 sangkan teu matak teuing goréng teuing.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Nyitak `Frame` at `Symbol` dilacak atah, ilaharna tina jero callbacks atah tina crate ieu.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Nambihan pigura atah kana kaluaran backtrace.
    ///
    /// Cara ieu, henteu sapertos anu sateuacanna, nyandak argumen atah upami aranjeunna janten sumber tina lokasi anu sanés.
    /// Catet yén ieu tiasa disebat sababaraha kali kanggo hiji pigura.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Nambihan pigura atah kana kaluaran backtrace, kalebet inpormasi kolom.
    ///
    /// Cara ieu, sapertos anu sateuacanna, nyandak argumen atah upami aranjeunna janten sumber tina lokasi anu sanés.
    /// Catet yén ieu tiasa disebat sababaraha kali kanggo hiji pigura.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia teu tiasa ngalambangkeun dina prosés maka éta ngagaduhan format khusus anu tiasa dianggo ngalambangkeun engké.
        // Nyitak yén tinimbang percetakan alamat dina format kami sorangan di dieu.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Henteu kedah nyetak pigura "null", dasarna éta hartosna sistem backtrace rada hoyong pisan ngambah jauh pisan.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Pikeun ngirangan ukuran TCB dina enclave Sgx, kami henteu hoyong nerapkeun pungsi résolusi simbol.
        // Rada, bisa nyitak offset sahiji alamatna didieu, nu bisa engké dipetakeun kana fungsi bener.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Nyitak indéks pigura ogé instruksi pointer pilihan pigura.
        // Lamun urang geus saluareun lambang munggaran pigura ieu sanajan kami ngan nyitak whitespace luyu.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Hareup nepi nulis kaluar nami simbol, ngagunakeun alternatif pormat kanggo inpormasi lengkep lamun kami geus a backtrace pinuh.
        // Di dieu kami ogé nanganan simbol anu teu ngagaduhan nami,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Sareng terakhir, nyetak nomer filename/line upami aranjeunna sayogi.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line dicitak dina garis dina nami simbol, janten nyitak sababaraha ruang bodas anu pas pikeun milah-milih diri anu leres.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegasi ka callback internal kami pikeun nyetak nami nami teras nyetak nomer garis.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Tambihkeun nomer kolom, upami sayogi.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Kami ngan ukur paduli lambang mimiti pigura
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}