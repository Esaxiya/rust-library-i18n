use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Ngabéréskeun alamat kana simbol, ngalirkeun simbol kana panutupan anu parantos ditangtukeun.
///
/// Pungsi ieu bakal béda nepi alamat dibikeun di wewengkon kayaning tabel lokal simbol, méja simbol dinamis, atawa dwarf info debug (gumantung palaksanaan nu diaktipkeun) pikeun manggihan simbol pikeun ngahasilkeun.
///
///
/// panutupanana teu meunang disebut lamun resolusi teu bisa dipigawé, sarta eta oge meureun nu disebut leuwih ti sakali dina hal fungsi inlined.
///
/// Simbol anu dihasilkeun ngagambarkeun palaksanaan dina `addr` anu ditangtoskeun, ngabalikeun file/line pasang kanggo alamat éta (upami sayogi).
///
/// Catet yén upami anjeun ngagaduhan `Frame` maka disarankeun nganggo fungsi `resolve_frame` tibatan anu ieu.
///
/// # Fitur anu diperyogikeun
///
/// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
///
/// # Panics
///
/// Fungsi ieu narékahan pikeun pernah panic, tapi upami `cb` nyayogikeun panics maka sababaraha platform bakal maksa panic dobel pikeun ngagugurkeun prosés na.
/// Sababaraha platform nganggo perpustakaan C anu sacara internal nganggo callbacks anu henteu tiasa dibahas, janten panicking ti `cb` tiasa memicu prosés abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ukur ningali pigura luhur
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Ngabéréskeun pigura candak sateuacanna kana simbol, ngalirkeun simbol kana panutupan anu parantos ditangtoskeun.
///
/// Funcin ieu ngalaksanakeun fungsi anu sami sareng `resolve` kecuali anu peryogi `Frame` salaku argumen tibatan alamat.
/// Ieu tiasa ngidinan sabagian implementations platform of backtracing nyadiakeun informasi simbol nu leuwih akurat atawa informasi ngeunaan pigura inline contona.
///
/// Disarankeun ngagunakeun ieu upami anjeun tiasa.
///
/// # Fitur anu diperyogikeun
///
/// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
///
/// # Panics
///
/// Fungsi ieu narékahan pikeun pernah panic, tapi upami `cb` nyayogikeun panics maka sababaraha platform bakal maksa panic dobel pikeun ngagugurkeun prosés na.
/// Sababaraha platform nganggo perpustakaan C anu sacara internal nganggo callbacks anu henteu tiasa dibahas, janten panicking ti `cb` tiasa memicu prosés abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ukur ningali pigura luhur
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Nilai IP tina pigura tumpukan biasana (always?) pitunjuk *saatos* sauran éta tilas tumpukan anu saleresna.
// Symbolizing this on ngabalukarkeun nomer filename/line janten salah payun sareng panginten kana batal upami caket kana tungtung fungsina.
//
// Ieu sigana dasarna sok janten kasus dina sadaya platform, janten kami salawasna ngirangan hiji tina ip anu ngumbar pikeun ngabéréskeun kana paréntah nelepon anu sanés tibatan instruksi anu dikembalikan.
//
//
// Saenyana urang moal ngalakukeun ieu.
// Saenyana urang meryogikeun anu nélépon API `resolve` di dieu pikeun sacara manual ngalakukeun -1 sareng akun anu aranjeunna hoyong inpormasi lokasi pikeun instruksi *saméméhna*, sanés ayeuna.
// Ideally kami ogé kukituna ngalaan on `Frame` lamun kami memang alamat tina instruksi salajengna atanapi ayeuna.
//
// Pikeun ayeuna sanaos ieu mangrupikeun masalah anu cukup janten kami ngan ukur sacara internal ngirangan hiji.
// Pamakéna kudu nyimpen digawé tur meunang hasil geulis alus, sangkan kudu cukup alus.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sarua sareng `resolve`, ngan ukur henteu aman sabab éta henteu disingkronkeun.
///
/// Fungsi ieu henteu ngagaduhan jaminan sinkronisasi tapi sayogi nalika fitur `std` tina crate ieu henteu disusun.
/// Ningali fungsi `resolve` pikeun leuwih dokuméntasi jeung conto.
///
/// # Panics
///
/// Tingali inpormasi ngeunaan `resolve` pikeun peringatan dina panéndaan `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sarua sareng `resolve_frame`, ngan ukur henteu aman sabab éta henteu disingkronkeun.
///
/// Fungsi ieu henteu ngagaduhan jaminan sinkronisasi tapi sayogi nalika fitur `std` tina crate ieu henteu disusun.
/// Tingali fungsi `resolve_frame` pikeun langkung seueur dokuméntasi sareng conto.
///
/// # Panics
///
/// Tingali inpormasi ngeunaan `resolve_frame` pikeun peringatan dina panéndaan `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait ngagambarkeun resolusi simbul dina file.
///
/// trait ieu dihasilkeun salaku obyék trait kana panutupan anu masihan kana fungsi `backtrace::resolve`, sareng éta ampir dikirimkeun sabab henteu kanyahoan palaksanaan mana anu aya di tukangeunana.
///
///
/// Simbol tiasa masihan inpormasi kontekstual ngeunaan fungsi, contona nami, nami nami, nomer garis, alamat anu pas, jst.
/// Henteu sadaya inpormasi salawasna sayogi dina simbol, nanging, janten sadaya metodeu mulihkeun `Option`.
///
///
pub struct Symbol {
    // TODO: kabeungkeut hirup ieu kedah diperyogikeun tungtungna ka `Symbol`,
    // tapi éta ayeuna ngarobih.
    // Pikeun ayeuna ieu aman kumargi `Symbol` ngan ukur kantos dipasihkeun ku rujukan sareng teu tiasa dikloning.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Balikkeun nami pungsi ieu.
    ///
    /// Struktur anu dipulangkeun tiasa dianggo pikeun nungtut sababaraha jinis sipat ngeunaan nami simbol:
    ///
    ///
    /// * Palaksanaan `Display` bakal nyetak simbol anu teu kabéngkah.
    /// * Nilai `str` atah tina simbol nu tiasa diakses (lamun eta urang utf-8 valid).
    /// * Bait atah pikeun nami simbol tiasa diaksés.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Malikeun alamat awal fungsi ieu.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Balikkeun nami nami atah salaku keureutan.
    /// Ieu utamina kapaké pikeun lingkungan `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Balikkeun nomer kolom pikeun tempat simbol ieu ayeuna ngaéksekusi.
    ///
    /// Ngan gimli anu ayeuna nyayogikeun nilai didieu bahkan saatos `filename` mulih `Some`, sareng teras akibatna tunduk kana peringatan anu sami.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Balikkeun nomer garis pikeun tempat simbol ieu ayeuna ngaéksekusi.
    ///
    /// Nilai balik ieu biasana `Some` upami `filename` mulih `Some`, sareng akibatna tunduk kana peringatan anu sami.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Mulih nami file mana fungsi ieu tangtu.
    ///
    /// Ieu ayeuna ngan ukur aya nalika libbacktrace atanapi gimli dianggo (contona
    /// unix platform anu sanés) sareng nalika binér disusun sareng debuginfo.
    /// Lamun ngayakeun kaayaan ieu patepung lajeng ieu dipikaresep bakal balik `None`.
    ///
    /// # Fitur anu diperyogikeun
    ///
    /// Pungsi ieu merlukeun fitur `std` tina `backtrace` crate bisa diaktipkeun, sarta fitur `std` diaktipkeun ku standar.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Meureun hiji C parsed++ simbol, upami FITML lambang mangled sakumaha Rust gagal.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pastikeun tetep kieu enol-ukuran, jadi yén fitur `cpp_demangle` boga ongkos mun ditumpurkeun.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Bungkus sakuriling nami simbol pikeun nyayogikeun aksésoris ergonomis kana nami anu tos robih, bait atah, senar atah, sareng sajabana
///
// Ngawenangkeun kode maot keur nalika fitur `cpp_demangle` teu diaktipkeun.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Nyiptakeun nami simbol anyar tina bait dasar anu atos.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Mulih nami simbol (mangled) atah salaku `str` upami simbol na utf-8 valid.
    ///
    /// Anggo palaksanaan `Display` upami anjeun hoyong vérsi anu demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Balikkeun nami simbol atah salaku daptar bait
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ieu tiasa nyetak upami simbol anu diturunkeun henteu leres-leres leres, janten nanganan kasalahan di dieu kalayan marahmay ku henteu nyebarkeunana ka luar.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Usaha pikeun ngarebut deui mémori anu di-cache dipaké pikeun ngalambangkeun alamat.
///
/// Metoda ieu bakal nyobian ngaleupaskeun sagala struktur data global anu sanés parantos di-cache global atanapi dina utas anu ilaharna ngagambarkeun inpormasi DWARF anu parsed atanapi anu sami.
///
///
/// # Caveats
///
/// Nalika pungsi ieu sok sayogi, éta henteu leres-leres ngalakukeun nanaon dina kalolobaan palaksanaan.
/// Perpustakaan sapertos dbghelp atanapi libbacktrace henteu nyayogikeun fasilitas pikeun kaayaan kaayaan sareng ngatur mémori anu dialokasikan.
/// Kanggo ayeuna fitur `gimli-symbolize` tina crate ieu mangrupikeun hiji-hijina fitur anu fungsina ieu aya pangaruhna.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}