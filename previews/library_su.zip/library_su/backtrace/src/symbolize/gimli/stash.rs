// ngan ukur dianggo dina Linux ayeuna, janten kéngingkeun kode maot di tempat sanés
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Alokasi arena saderhana pikeun penyangga bait.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alokasi panyangga tina ukuran anu parantos ditangtoskeun sareng mulihkeun rujukan anu tiasa dirobih pikeunna.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: ieu mangrupikeun hiji-hijina fungsi anu kantos ngawangun mutable
        // rujukan pikeun `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // Kasalametan: urang pernah nyabut elemen ti `self.buffers`, jadi rujukan a
        // kana data di jero panyangga naon waé bakal hirup salami `self` henteu.
        &mut buffers[i]
    }
}