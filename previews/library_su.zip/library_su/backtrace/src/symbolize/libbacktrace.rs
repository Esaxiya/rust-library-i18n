//! Strategi simbolisasi nganggo kode DWARF-parsing di libbacktrace.
//!
//! Perpustakaan libbacktrace C, biasana disebarkeun sareng gcc, ngadukung henteu ngan ukur ngahasilkeun backtrace (anu saleresna henteu urang anggo) tapi ogé simbolisikeun backtrace sareng nanganan inpormasi debug dwarf ngeunaan hal-hal sapertos pigura anu ditataan sareng anu sanésna.
//!
//!
//! Ieu kawilang rumit kusabab seueur rupa masalah di dieu, tapi ideu dasarna nyaéta:
//!
//! * Mimiti urang nyauran `backtrace_syminfo`.Ieu ngagaduhan inpormasi simbol tina tabel simbol dinamis upami urang tiasa.
//! * Salajengna urang nyauran `backtrace_pcinfo`.Ieu bakal ngébréhkeun tabel debuginfo upami aranjeunna sayogi sareng ngamungkinkeun urang kéngingkeun inpormasi ngeunaan pigura inline, filenames, nomer garis, jst.
//!
//! Aya kavling trickery ngeunaan lalaki tabél dwarf kana libbacktrace tapi mudahan éta teu tungtung dunya tur cukup jelas lamun maca di handap.
//!
//! Ieu mangrupikeun strategi simbolisasi standar pikeun platform non-MSVC sareng non-OSX.Dina libstd sanaos ieu strategi standar pikeun OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Upami tiasa langkung resep nami `function` anu asalna tina debuginfo sareng biasana tiasa langkung akurat pikeun pigura inline contona.
                // Upami éta henteu aya sanaos ragrag deui kana nami tabel simbol anu ditangtoskeun dina `symname`.
                //
                // Catet yén kadang `function` tiasa ngaraos rada kirang akurat, contona didaptarkeun salaku `try<i32,closure>` isntead of `std::panicking::try::do_call`.
                //
                // Henteu jelas pisan sababna, tapi sacara umum nami `function` sigana langkung akurat.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ulah nanaon ayeuna
}

/// Jenis pointer `data` diliwatan kana `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Sakali callback ieu invoked ti `backtrace_syminfo` lamun urang mimitian resolving kami balik salajengna jadi nelepon `backtrace_pcinfo`.
    // Fungsi `backtrace_pcinfo` baris konsultasi informasi debug na attemp tto ngalakukeun hal resep cageur informasi file/line salaku pigura ogé inlined.
    // Catet yén `backtrace_pcinfo` tiasa gagal atanapi henteu ngalakukeun seueur upami henteu aya inpo debug, janten upami éta kajantenan kami pasti bakal nyauran callback ku sahanteuna hiji simbol ti `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Jenis pointer `data` diliwatan kana `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace ngadukung nyiptakeun kaayaan, tapi éta henteu ngadukung ngancurkeun nagara.
// Kuring sacara pribadi nyandak ieu hartosna yén kaayaan dimaksudkan pikeun didamel teras hirup salamina.
//
// Abdi hoyong ngadaptar pawang at_exit() anu ngabersihan kaayaan ieu, tapi libbacktrace teu aya jalan pikeun ngalaksanakeunana.
//
// Kalawan konstrain ieu, fungsi ieu ngabogaan kaayaan statically sindangan nu diitung kahiji waktos ieu dipénta.
//
// Émut yén mundur sadayana kajantenan sacara serial (hiji konci global).
//
// Catetan kurangna sinkronisasi didieu téh alatan sarat yén `resolve` ieu externally nyingkronkeun.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Entong nganggo kamampuan threadsafe tina libbacktrace kumargi kami sering nyebutna dina cara singkronisasi.
        //
        0,
        error_cb,
        ptr::null_mut(), // euweuh data tambahan
    );

    return STATE;

    // Catet yén pikeun libbacktrace tiasa dianggo sadayana éta peryogi milarian inpo debug DWARF pikeun dieksekusi ayeuna.Éta biasana ngalaksanakeun éta ngalangkungan sababaraha mékanisme kalebet, tapi henteu diwatesan ku:
    //
    // * /proc/self/exe dina platform anu didukung
    // * Ngaran koropak diliwatan sacara jelas nalika nyiptakeun kaayaan
    //
    // Perpustakaan libbacktrace mangrupakeun Wad badag tina kode C.Ieu sacara alami hartosna éta ngagaduhan kerentanan kaamanan ingetan, utamina nalika nanganan debuginfo anu salah.
    // Libstd parantos ngalaman seueur sajarah ieu.
    //
    // Mun /proc/self/exe dipaké lajeng urang ilaharna bisa malire ieu salaku urang nganggap yen libbacktrace nyaeta "mostly correct" tur disebutkeun teu ngalakukeun hal aneh jeung "attempted to be correct" dwarf debug info.
    //
    //
    // Upami urang ngalirkeun dina nami nami, maka mungkin dina sababaraha platform (sapertos BSD) dimana palaku jahat tiasa nyababkeun file sawenang-wenang ditempatkeun di lokasi éta.
    // Ieu hartosna yén lamun kami ngabejaan libbacktrace ngeunaan Ngaran koropak a meureun nya ngagunakeun hiji file sawenang, jigana ngabalukarkeun segfaults.
    // Upami urang henteu nyarioskeun libbacktrace naon waé maka éta moal ngalakukeun nanaon dina platform anu henteu ngadukung jalur sapertos /proc/self/exe!
    //
    // Dibikeun sadayana anu urang nyobian sakumaha mungkin pikeun *henteu* lulus dina nami nami, tapi urang kedah dina platform anu henteu ngadukung /proc/self/exe pisan.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Catet yén idéal kami nganggo `std::env::current_exe`, tapi kami henteu tiasa meryogikeun `std` di dieu.
            //
            // Anggo `_NSGetExecutablePath` pikeun ngamuat jalur anu tiasa dieksekusi ayeuna kana daérah statis (anu mana upami alit teuing pasrah).
            //
            //
            // Catet yén urang percanten sacara serius libbacktrace di dieu pikeun henteu maot dina palaksanaan korupsi, tapi pastina henteu ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ngagaduhan modeu muka file dimana saatos dibuka moal tiasa dihapus.
            // Éta sacara umum naon anu urang pikahoyong di dieu sabab kami hoyong mastikeun yén laksana urang henteu robih ti handapeun kami saatos urang pasrahkeun ka libbacktrace, mudah-mudahan ngiringan kamampuan ngalirkeun data sawenang-wenang kana libbacktrace (anu tiasa disalahgunakeun).
            //
            //
            // Nunjukkeun yén urang ngalakukeun sakedik tarian di dieu pikeun nyobian kéngingkeun semacam konci dina gambar urang nyalira:
            //
            // * Kéngingkeun cecekelan pikeun prosés ayeuna, muatkeun nami nami na.
            // * Buka file kana nami file anu nganggo panji katuhu.
            // * Ngamuat Ngaran koropak proses ayeuna urang, mastikeun éta sami
            //
            // Upami éta sadayana lulus sacara tiori urang memang parantos muka file prosés kami sareng kami dijamin moal robih.FWIW sakumpulan ieu disalin tina libstd sajarah, janten ieu tafsir anu pangsaéna mah kana naon anu lumangsung.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ieu hirup di memori statik sangkan bisa balik deui ..
                static mut BUF: [i8; N] = [0; N];
                // ... sareng ieu hirup dina tumpukan kumargi samentawis
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ngahaja ngabocorkeun `handle` di dieu kusabab anu kabuka kedah ngajaga konci urang dina nami file ieu.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Kami hoyong wangsulkeun sapotong anu parantos ditamatkeun, janten upami sadayana dieusian sareng éta sami sareng total panjang maka samikeun éta janten gagal.
                //
                //
                // Upami teu kitu nalika mulih kasuksesan pastikeun nul byte kalebet kana irisan.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // kasalahan backtrace ayeuna disapu handapeun karpét
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Nelepon `backtrace_syminfo` API anu (tina maca kode) kedah nyauran `syminfo_cb` persis sakali (atanapi gagal ku kasalahan panginten).
    // Urang teras ngadamel langkung seueur dina `syminfo_cb`.
    //
    // Catet yén urang ngalakukeun ieu kusabab `syminfo` bakal konsultasi tabel simbol, mendakan nami simbol bahkan upami teu aya inpo debug dina binér.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}