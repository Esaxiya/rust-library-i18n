# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Perpustakaan pikeun kéngingkeun backtraces nalika runtime pikeun Rust.
Perpustakaan ieu ngagaduhan tujuan pikeun ningkatkeun dukungan perpustakaan standar ku nyayogikeun antarmuka programmatic kanggo digarap, tapi ogé ngadukung kantun nyetak backtrace ayeuna sapertos libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Pikeun ngan saukur néwak backtrace sareng nunda nguruskeunana dugi ka waktos engké, anjeun tiasa nganggo jinis `Backtrace` tingkat luhur.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Upami kitu, upami anjeun hoyong aksés langkung atah kana pungsi nyukcruk anu saleresna, anjeun tiasa langsung nganggo fungsi `trace` sareng `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Béréskeun pitunjuk ieu kana nami simbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // teraskeun kana pigura salajengna
    });
}
```

# License

Proyék ieu dilisénsikeun dina salah sahiji

 * Lisénsi Apache, Vérsi 2.0, ([LICENSE-APACHE](LICENSE-APACHE) atanapi http://www.apache.org/licenses/LICENSE-2.0)
 * Lisénsi MIT ([LICENSE-MIT](LICENSE-MIT) atanapi http://opensource.org/licenses/MIT)

dina pilihan anjeun.

### Contribution

Kacuali anjeun sacara éksplisit nyatakeun sanésna, sumbangan naon waé anu ngahaja dikintunkeun pikeun dilebetkeun kana backtrace-rs ku anjeun, sakumaha anu ditetepkeun dina lisénsi Apache-2.0, bakal ngagaduhan dua lisénsi sapertos di luhur, tanpa aya sarat atanapi sarat tambahan.







