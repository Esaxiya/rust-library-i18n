# `rustc-std-workspace-core` crate

crate Ieu shim na kosong crate nu saukur gumantung kana `libcore` na reexports sakabéh eusina.
crate mangrupikeun inti tina pemberdayaan perpustakaan standar pikeun gumantung kana crates ti crates.io

Crates dina crates.io yén perpustakaan standar gumantung kana kedah gumantung kana `rustc-std-workspace-core` crate ti crates.io, anu kosong.

Urang make `[patch]` mun override ka crate ieu Repository ieu.
Hasilna, crates on crates.io bakal ngagambar kagumantungan edge mun `libcore`, versi didefinisikeun dina Repository ieu.
Éta kedah narik sadayana kagumantungan pikeun mastikeun Cargo ngawangun crates hasil!

Catet yén crates on crates.io kedah gumantung kana crate ieu kalayan nami `core` pikeun sadayana tiasa dianggo leres.Jang ngalampahkeun anu aranjeunna tiasa nganggo:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ngaliwatan panggunaan konci `package` crate diganti nami janten `core`, hartosna éta bakal katingali sapertos

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

nalika Cargo nyungkeun kompiler, nyugemakeun diréktif `extern crate core` implisit anu disuntik ku panyusun.




