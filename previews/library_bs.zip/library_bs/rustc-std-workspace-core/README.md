# `rustc-std-workspace-core` crate

Ovaj crate je prazan i prazan crate koji jednostavno ovisi o `libcore` i ponovno izvozi sav njegov sadržaj.
crate je srž osnaživanja standardne biblioteke da ovisi o crates iz crates.io

Crates na crates.io o kojem ovisi standardna knjižnica mora ovisiti o `rustc-std-workspace-core` crate iz crates.io, koji je prazan.

Koristimo `[patch]` da bismo ga nadjačali na ovaj crate u ovom spremištu.
Kao rezultat, crates na crates.io izvući će zavisnost edge do `libcore`, verziju definiranu u ovom spremištu.
To bi trebalo nacrtati sve ivice ovisnosti kako bi se osiguralo da Cargo uspješno gradi crates!

Imajte na umu da crates na crates.io mora ovisiti o ovom crate s imenom `core` da bi sve ispravno radilo.Da bi to učinili, mogu koristiti:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Korištenjem tipke `package` crate je preimenovan u `core`, što znači da će izgledati

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kada Cargo poziva kompajler, zadovoljavajući implicitnu `extern crate core` direktivu koju je ubacio kompajler.




