//! Windows SEH
//!
//! Na Windows (trenutno samo na MSVC), zadani mehanizam za rukovanje iznimkama je Structured Exception Handling (SEH).
//! Ovo se prilično razlikuje od rukovanja iznimkama na osnovu patuljaka (npr. Ono što koriste druge platforme unix) u pogledu internih komponenata kompajlera, pa je LLVM potreban da bi imao dobru količinu dodatne podrške za SEH.
//!
//! Ukratko, ono što se ovdje događa je:
//!
//! 1. Funkcija `panic` poziva standardnu funkciju Windows `_CxxThrowException` da izbaci izuzetak sličan C++ , pokrećući proces odmotavanja.
//! 2.
//! Sve podloge za slijetanje koje generira kompajler koriste funkciju ličnosti `__CxxFrameHandler3`, funkciju u CRT-u, a kôd za odmotavanje u Windows će koristiti ovu funkciju ličnosti za izvršavanje svih kodova za čišćenje na stogu.
//!
//! 3. Svi pozivi `invoke`-a generirani od strane kompajlera imaju podlogu za slijetanje postavljenu kao `cleanuppad` LLVM uputu, koja ukazuje na početak rutine čišćenja.
//! Ličnost (u koraku 2, definirana u CRT-u) odgovorna je za pokretanje rutina čišćenja.
//! 4. Na kraju se izvršava "catch" kôd u intrinzičnom `try` (generiran od strane kompajlera) i ukazuje da bi se kontrola trebala vratiti na Rust.
//! To se radi putem `catchswitch` plus `catchpad` instrukcije u LLVM IR terminima, konačno vraćajući normalnu kontrolu u program sa `catchret` instrukcijom.
//!
//! Neke specifične razlike od rukovanja iznimkama temeljenog na gcc su:
//!
//! * Rust nema prilagođenu funkciju ličnosti, umjesto toga je *uvijek*`__CxxFrameHandler3`.Pored toga, ne izvodi se dodatno filtriranje, tako da na kraju uhvatimo bilo koji izuzetak C++ -a koji izgleda kao da ga bacamo.
//! Imajte na umu da je bacanje iznimke u Rust ionako nedefinirano ponašanje, pa bi ovo trebalo biti u redu.
//! * Imamo neke podatke za prijenos preko granice odmotavanja, posebno `Box<dyn Any + Send>`.Kao i kod patuljastih izuzetaka, i ova dva pokazivača pohranjena su kao korisni teret u samom izuzeću.
//! Na MSVC-u, međutim, nema potrebe za dodatnom dodjelom hrpe jer se skup poziva čuva dok se izvršavaju funkcije filtra.
//! To znači da se pokazivači prenose izravno na `_CxxThrowException` koji se zatim obnavljaju u funkciji filtra da bi se upisali u okvir steka suštinskog `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ovo treba biti opcija, jer izuzetak hvatamo referencom, a njegov destruktor izvršava C++ runtime.
    // Kada izvadimo Box iz izuzetka, moramo ostaviti izuzetak u važećem stanju da bi se njegov destruktor pokrenuo bez dvostrukog ispuštanja Box-a.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Prvo, čitav niz definicija tipova.Ovdje postoji nekoliko neobičnosti specifičnih za platformu i puno toga koji je otvoreno kopiran iz LLVM-a.Svrha svega ovoga je implementirati donju funkciju `panic` kroz poziv na `_CxxThrowException`.
//
// Ova funkcija uzima dva argumenta.Prva je pokazivač na podatke koje prosljeđujemo, što je u ovom slučaju naš Portrait objekt.Prilično lako pronaći!Sljedeća je, međutim, složenija.
// Ovo je pokazivač na `_ThrowInfo` strukturu i uglavnom je namijenjen samo opisu izuzetaka koji se baca.
//
// Trenutno je definicija ovog tipa [1] pomalo dlakava, a glavna neobičnost (i razlika od mrežnog članka) je ta da su 32-bitni pokazivači pokazivači, ali na 64-bitnim pokazivači su izraženi kao 32-bitni pomaci od `__ImageBase` simbol.
//
// Makro `ptr_t` i `ptr!` u donjim modulima koriste se da to izraze.
//
// Lavirint definicija tipova takođe pomno prati šta LLVM emitira za ovu vrstu operacije.Na primjer, ako kompajlirate ovaj C++ kod na MSVC i emitirate LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      praznina foo() { rust_panic a = {0, 1};
//          baciti a;}
//
// To je u osnovi ono što pokušavamo oponašati.Većina donjih konstantnih vrijednosti upravo je kopirana iz LLVM-a,
//
// U svakom slučaju, sve su strukture izgrađene na sličan način i to je za nas samo donekle opširno.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Imajte na umu da ovdje namjerno zanemarujemo pravila za rukovanje imenima: ne želimo da C++ može uhvatiti Rust panics jednostavnom deklaracijom `struct rust_panic`.
//
//
// Prilikom modifikacije, pobrinite se da se niz imena tipa tačno podudara s onim koji se koristi u `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Vodeći bajt `\x01` ovdje je zapravo čarobni signal LLVM-u da *ne* primijeni bilo koje drugo rukovanje poput prefiksa sa znakom `_`.
    //
    //
    // Ovaj simbol je vtable koji koristi C++ `std::type_info`.
    // Objekti tipa `std::type_info`, deskriptori tipa, imaju pokazivač na ovu tablicu.
    // Na deskriptore tipova upućuju se gore definiranim C++ EH strukturama, a mi ih konstruiramo u nastavku.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ovaj deskriptor tipa koristi se samo kada se izuzima iznimka.
// Dio ulova obrađuje try intrinsic, koji generira vlastiti TypeDescriptor.
//
// To je u redu jer MSVC vrijeme izvođenja koristi usporedbu niza na imenu tipa kako bi se podudaralo s TypeDescriptorsima, a ne s jednakošću pokazivača.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor koji se koristi ako C++ kôd odluči uhvatiti izuzetak i ispustiti ga bez širenja.
// Ulovni dio try intrinsic postavit će prvu riječ objekta iznimke na 0 tako da ga destruktor preskoči.
//
// Imajte na umu da x86 Windows koristi konvenciju pozivanja "thiscall" za funkcije člana C++ umjesto zadane konvencije pozivanja "C".
//
// Funkcija iznimka_kopija ovdje je malo posebna: poziva je MSVC vrijeme izvođenja pod try/catch blokom i panic koji ovdje generiramo koristit će se kao rezultat kopije iznimke.
//
// Ovo koristi izvršavanje C++ za podršku hvatanju izuzetaka sa std::exception_ptr, što ne možemo podržati jer Box<dyn Any>nije za kloniranje.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException se u potpunosti izvršava na ovom okviru steka, tako da nema potrebe za prebacivanjem `data` u hrpu.
    // Samo prosljeđujemo pokazivač na stek na ovu funkciju.
    //
    // Ovdje je potreban ManuallyDrop, jer ne želimo da se iznimka ispušta prilikom odmotavanja.
    // Umjesto toga, ispustiće se izuzetkom_čišćenja koji se poziva izvođenjem C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ovo ... može izgledati iznenađujuće i opravdano.Na 32-bitnom MSVC-u pokazivači između ove strukture su upravo to, pokazivači.
    // Na 64-bitnom MSVC-u, međutim, pokazivači između struktura prilično su izraženi kao 32-bitni pomaci od `__ImageBase`.
    //
    // Prema tome, na 32-bitnom MSVC-u možemo deklarirati sve ove pokazivače u gore navedenim `static`ima.
    // Na 64-bitnom MSVC-u morali bismo izraziti oduzimanje pokazivača u statici, što Rust trenutno ne dopušta, pa to zapravo ne možemo učiniti.
    //
    // Sljedeća najbolja stvar je tada popunjavanje ovih struktura tijekom izvođenja (panika je ionako već "slow path").
    // Dakle, ovdje ponovo interpretiramo sva ova polja pokazivača kao 32-bitne cijele brojeve, a zatim u njih pohranimo relevantnu vrijednost (atomski, kao što se istovremeno može dogoditi panics).
    //
    // Tehnički će runtime vjerojatno izvršiti neatomsko očitavanje ovih polja, ali u teoriji nikad ne čitaju *pogrešnu* vrijednost, pa ne bi trebalo biti loše ...
    //
    // U svakom slučaju, u osnovi moramo učiniti nešto slično dok ne možemo više operacija izraziti u statici (a možda to nikada nećemo moći).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL nosivost ovdje znači da smo stigli iz ulova (...) od __rust_try.
    // To se događa kada se uhvati strana iznimka koja nije Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Prevodnik to mora postojati (npr. To je stavka lang-a), ali prevodilac to zapravo nikada ne poziva jer je __C_specific_handler ili_except_handler3 funkcija ličnosti koja se uvijek koristi.
//
// Otuda je ovo samo abortirajuća mrlja.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}