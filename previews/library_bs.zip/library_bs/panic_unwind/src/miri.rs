//! Odmotavanje panics za Miri.
use alloc::boxed::Box;
use core::any::Any;

// Tip korisnog tereta koji Miri motor širi odmotavanjem za nas.
// Mora biti veličine pokazivača.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-osigurana vanjska funkcija za početak odmotavanja.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Korisni teret koji prosljeđujemo `miri_start_panic` bit će upravo argument koji ćemo dobiti u donjem `cleanup`.
    // Dakle, samo jednom upakujemo da dobijemo nešto veličine pokazivača.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Obnovite osnovni `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}