//! Uslužni programi za raščlanjivanje DWARF kodiranih tokova podataka.
//! Pogledajte <http://www.dwarfstd.org>, DWARF-4 standard, odjeljak 7, "Data Representation"
//!

// Ovaj modul za sada koristi samo x86_64-pc-windows-gnu, ali ga svugdje kompiliramo kako bismo izbjegli regresije.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF tokovi su spakirani, pa npr. u32 ne bi nužno bio poravnat na granici od 4 bajta.
    // To može uzrokovati probleme na platformama sa strogim zahtjevima za poravnanje.
    // Omotavanjem podataka u strukturu "packed", govorimo pozadini da generira "misalignment-safe" kôd.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // Kodiranja ULEB128 i SLEB128 definirana su u odjeljku 7.6, "Variable Length Data".
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}