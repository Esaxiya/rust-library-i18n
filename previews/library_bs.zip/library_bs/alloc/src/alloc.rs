//! API-ji za dodjelu memorije

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // To su čarobni simboli za pozivanje globalnog alokatora.rustc ih generira da pozivaju `__rg_alloc` itd.
    // ako postoji `#[global_allocator]` atribut (kod koji širi taj makro atribut generira te funkcije) ili za pozivanje zadanih implementacija u libstd (`__rdl_alloc` itd.)
    //
    // u `library/std/src/alloc.rs`) u suprotnom.
    // rustc fork LLVM-a također posebno koristi ove nazive funkcija kako bi ih mogao optimizirati poput `malloc`, `realloc` i `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Alokator globalne memorije.
///
/// Ovaj tip implementira [`Allocator`] Portrait prosljeđivanjem poziva na dodjeljivač registriran s atributom `#[global_allocator]` ako postoji, ili zadani zadatak `std` crate.
///
///
/// Note: dok je ovaj tip nestabilan, funkcijama koje pruža može se pristupiti putem [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Dodijelite memoriju pomoću globalnog alokatora.
///
/// Ova funkcija prosljeđuje pozive na [`GlobalAlloc::alloc`] metodu raspodjeljivača registriranog s atributom `#[global_allocator]` ako postoji, ili je zadani `std` crate.
///
///
/// Očekuje se da će se ova funkcija zastarjeti u korist metode `alloc` tipa [`Global`] kada ona i [`Allocator`] Portrait postanu stabilni.
///
/// # Safety
///
/// Pogledajte [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Dodijelite memoriju globalnim alokatorom.
///
/// Ova funkcija prosljeđuje pozive na [`GlobalAlloc::dealloc`] metodu raspodjeljivača registriranog s atributom `#[global_allocator]` ako postoji, ili je zadani `std` crate.
///
///
/// Očekuje se da će se ova funkcija zastarjeti u korist metode `dealloc` tipa [`Global`] kada ona i [`Allocator`] Portrait postanu stabilni.
///
/// # Safety
///
/// Pogledajte [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Preraspodijelite memoriju pomoću globalnog alokatora.
///
/// Ova funkcija prosljeđuje pozive na [`GlobalAlloc::realloc`] metodu raspodjeljivača registriranog s atributom `#[global_allocator]` ako postoji, ili je zadani `std` crate.
///
///
/// Očekuje se da će se ova funkcija zastarjeti u korist metode `realloc` tipa [`Global`] kada ona i [`Allocator`] Portrait postanu stabilni.
///
/// # Safety
///
/// Pogledajte [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Dodijelite memoriju inicijaliziranu nulom s globalnim alokatorom.
///
/// Ova funkcija prosljeđuje pozive na [`GlobalAlloc::alloc_zeroed`] metodu raspodjeljivača registriranog s atributom `#[global_allocator]` ako postoji, ili je zadani `std` crate.
///
///
/// Očekuje se da će se ova funkcija zastarjeti u korist metode `alloc_zeroed` tipa [`Global`] kada ona i [`Allocator`] Portrait postanu stabilni.
///
/// # Safety
///
/// Pogledajte [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SIGURNOST: `layout` nije nula,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SIGURNOST: Isto kao i `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SIGURNOST: `new_size` nije nula jer je `old_size` veći ili jednak `new_size`
            // kako zahtijevaju sigurnosni uvjeti.Ostale uvjete pozivatelj mora poštovati
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` vjerovatno provjerava `new_size >= old_layout.size()` ili nešto slično.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIGURNOST: jer `new_layout.size()` mora biti veći ili jednak `old_size`,
            // i stara i nova alokacija memorije vrijede za čitanje i pisanje za `old_size` bajtove.
            // Takođe, budući da stara dodjela još nije oslobođena, ne može se preklapati sa `new_ptr`.
            // Stoga je poziv na `copy_nonoverlapping` siguran.
            // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SIGURNOST: `layout` nije nula,
            // ostale uvjete pozivatelj mora poštovati
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZBEDNOST: pozivatelj mora poštovati sve uslove
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZBEDNOST: pozivatelj mora poštovati sve uslove
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // BEZBEDNOST: pozivalac mora poštovati uslove
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SIGURNOST: `new_size` nije nula.Ostale uvjete pozivatelj mora poštovati
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` vjerovatno provjerava `new_size <= old_layout.size()` ili nešto slično.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIGURNOST: jer `new_size` mora biti manji ili jednak `old_layout.size()`,
            // i stara i nova alokacija memorije vrijede za čitanje i pisanje za `new_size` bajtove.
            // Takođe, budući da stara dodjela još nije oslobođena, ne može se preklapati sa `new_ptr`.
            // Stoga je poziv na `copy_nonoverlapping` siguran.
            // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Alokator za jedinstvene pokazivače.
// Ova se funkcija ne smije odmotati.Ako se dogodi, MIR kodegen neće uspjeti.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ovaj potpis mora biti isti kao `Box`, inače će se dogoditi ICE.
// Kada se doda dodatni parametar `Box` (poput `A: Allocator`), to mora biti dodan i ovdje.
// Na primjer, ako se `Box` promijeni u `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, i ovu funkciju treba promijeniti u `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Rukovatelj greškom dodjele

extern "Rust" {
    // Ovo je čarobni simbol za pozivanje rukovaoca globalnim alok greškama.
    // rustc ga generira da pozove `__rg_oom` ako postoji `#[alloc_error_handler]` ili da pozove zadane implementacije ispod (`__rdl_oom`) u suprotnom.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Prekid greške ili greške pri dodjeli memorije.
///
/// Pozovnici API-ja za dodjelu memorije koji žele prekinuti računanje kao odgovor na grešku u dodjeli, potiču se da pozovu ovu funkciju, umjesto da direktno pozivaju `panic!` ili slično.
///
///
/// Zadano ponašanje ove funkcije je ispis poruke sa standardnom greškom i prekid postupka.
/// Može se zamijeniti sa [`set_alloc_error_hook`] i [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Za alok test `std::alloc::handle_alloc_error` se može koristiti direktno.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // poziva preko generiranog `__rust_alloc_error_handler`

    // ako nema `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ako postoji `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Specijalizirajte klonove u unaprijed dodijeljenu, neinicijaliziranu memoriju.
/// Koriste ih `Box::clone` i `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Dodjeljivanjem *first* može omogućiti optimizatoru da kreira kloniranu vrijednost na mjestu, preskačući lokalno i premještanje.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Uvijek možemo kopirati na mjestu, bez ikakvih lokalnih vrijednosti.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}