use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specijalizacija Portrait koja se koristi za Vec::from_iter
///
/// ## Grafikon delegiranja:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Uobičajeni slučaj je prosljeđivanje vector u funkciju koja se odmah ponovno sakuplja u vector.
        // Možemo ovo kratko spojiti ako IntoIter uopće nije napredan.
        // Kada je napredan, možemo ponovo koristiti memoriju i premjestiti podatke na prednju stranu.
        // Ali to činimo samo kada rezultirajući Vec ne bi imao više neiskorištenog kapaciteta nego što bi ga stvorio generičkom implementacijom FromIterator.
        //
        // To ograničenje nije striktno neophodno jer Vec-ovo ponašanje pri dodjeli nije namjerno određeno.
        // Ali to je konzervativan izbor.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // mora delegirati na spec_extend() jer sam extend() delegira na spec_from za prazne Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ovo koristi `iterator.as_slice().to_vec()`, jer spec_extend mora poduzeti više koraka kako bi zaključio konačni kapacitet + dužina i tako obavio više posla.
// `to_vec()` direktno raspoređuje tačan iznos i tačno ga puni.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): kod cfg(test) inherentna metoda `[T]::to_vec`, koja je potrebna za definiciju ove metode, nije dostupna.
    // Umjesto toga upotrijebite funkciju `slice::to_vec` koja je dostupna samo s cfg(test) NB, pogledajte slice::hack modul u slice.rs za više informacija
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}