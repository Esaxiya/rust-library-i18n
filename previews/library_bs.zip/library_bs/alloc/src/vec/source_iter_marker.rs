use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Oznaka specijalizacije za prikupljanje iteratorskog cjevovoda u Vec uz ponovnu upotrebu alokacije izvora, tj
/// izvođenje cjevovoda na mjestu.
///
/// Nadređeni SourceIter Portrait potreban je specijaliziranoj funkciji za pristup dodjeli koja se treba ponovno koristiti.
/// Ali nije dovoljno da specijalizacija bude valjana.
/// Pogledajte dodatne granice na impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-interni SourceIter/InPlaceIterable traits implementiraju samo lanci adaptera <Adapter<Adapter<IntoIter>>> (sve u vlasništvu core/std).
// Dodatne granice implementacija adaptera (izvan `impl<I: Trait> Trait for Adapter<I>`) ovise samo o drugim traits koji su već označeni kao specijalizacija traits (Kopiraj, TrustedRandomAccess, FusedIterator).
//
// I.e. marker ne ovisi o životnom vijeku vrsta koje isporučuju korisnici.Moduliraj rupu za kopiranje, o kojoj već ovisi nekoliko drugih specijalizacija.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Dodatni zahtjevi koji se ne mogu izraziti putem Portrait bounds.Umjesto toga, oslanjamo se na const eval:
        // a) nema ZST-a jer ne bi bilo dodjele za ponovnu upotrebu i aritmetika pokazivača bi panic b) podudaranje veličine kako zahtijeva ugovor o Allocu c) poravnanje poravnanja prema zahtjevu Alloc ugovora
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // povratak na više generičke implementacije
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // koristi try-fold od
        // - bolje se vektorizira za neke adaptore iteratora
        // - za razliku od većine internih metoda iteracije, potreban je samo &mut
        // - omogućuje nam provlačenje pokazivača za pisanje kroz njegovu unutrašnjost i vraćanje na kraju
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteracija je uspjela, ne ispustite glavu
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // provjerite je li ugovor o SourceIteru podržan, upozorite: ako nisu, možda nećemo stići ni do ove točke
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // provjerite ugovor InPlaceIterable.To je moguće samo ako je iterator uopće unaprijedio izvorni pokazivač.
        // Ako koristi neprovjereni pristup putem TrustedRandomAccess, tada će izvorni pokazivač ostati u početnom položaju i ne možemo ga koristiti kao referencu
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ispustite sve preostale vrijednosti u rep izvora, ali spriječite pad same alokacije kada IntoIter izađe iz opsega ako pad panics tada propuštamo i sve elemente prikupljene u dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ugovor InPlaceIterable ne može se ovdje precizno provjeriti jer try_fold ima ekskluzivnu referencu na izvorni pokazivač, sve što možemo učiniti je provjeriti je li još uvijek u dometu
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}