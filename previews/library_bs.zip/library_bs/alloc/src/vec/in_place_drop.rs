use core::ptr::{self};
use core::slice::{self};

// Pomoćna struktura za iteraciju na mjestu koja ispušta odredišni dio iteracije, tj. Glavu.
// IntoIter ispušta izvornu krišku (rep).
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}