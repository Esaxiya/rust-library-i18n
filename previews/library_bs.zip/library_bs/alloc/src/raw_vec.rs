#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Sadržaj nove memorije je neinicijaliziran.
    Uninitialized,
    /// Nova memorija zagarantovana je na nuli.
    Zeroed,
}

/// Uslužni program niskog nivoa za ergonomskije raspoređivanje, preraspodjelu i uklanjanje međuspremnika memorije na hrpi, bez potrebe za brigom o svim uključenim kutnim slučajevima.
///
/// Ova vrsta je izvrsna za izgradnju vlastitih struktura podataka poput Vec i VecDeque.
/// Konkretno:
///
/// * Proizvodi `Unique::dangling()` na tipovima nulte veličine.
/// * Proizvodi `Unique::dangling()` na alokacijama nulte dužine.
/// * Izbjegava oslobađanje `Unique::dangling()`.
/// * Hvata sve prekomjerne vrijednosti u proračunima kapaciteta (promovira ih u "capacity overflow" panics).
/// * Štiti od 32-bitnih sistema koji dodjeljuju više od isize::MAX bajtova.
/// * Štiti od prekomjerne dužine.
/// * Poziva `handle_alloc_error` na pogrešne dodjele.
/// * Sadrži `ptr::Unique` i tako korisniku pruža sve srodne pogodnosti.
/// * Koristi višak vraćen iz alokatora da koristi najveći raspoloživi kapacitet.
///
/// Ovaj tip ionako ne pregledava memoriju kojom upravlja.Kad ga ispustite, * oslobodit će memoriju, ali neće pokušati ispustiti sadržaj.
/// Na korisniku `RawVec` je da obrađuje stvarne stvari *pohranjene* unutar `RawVec`.
///
/// Imajte na umu da je višak tipova nulte veličine uvijek beskonačan, pa `capacity()` uvijek vraća `usize::MAX`.
/// To znači da morate biti oprezni kada zaobilazite ovaj tip sa `Box<[T]>`, jer `capacity()` neće dati dužinu.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): To postoji zato što `#[unstable]` `const fn` ne moraju biti u skladu s `min_const_fn`, pa se ne mogu pozivati ni u`min_const_fn`s.
    ///
    /// Ako promijenite `RawVec<T>::new` ili zavisnosti, pripazite da ne uvedete ništa što bi zaista kršilo `min_const_fn`.
    ///
    /// NOTE: Mogli bismo izbjeći ovo hakiranje i provjeriti usklađenost s nekim `#[rustc_force_min_const_fn]` atributom koji zahtijeva usklađenost s `min_const_fn`, ali ne mora nužno dopustiti pozivanje u `stable(...) const fn`/korisnički kod koji ne omogućava `foo` kada je prisutan `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Stvara najveći mogući `RawVec` (na sistemskoj hrpi) bez alociranja.
    /// Ako `T` ima pozitivnu veličinu, onda se radi o `RawVec` kapaciteta `0`.
    /// Ako je `T` nulte veličine, tada pravi `RawVec` kapaciteta `usize::MAX`.
    /// Korisno za provedbu odgođene dodjele.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Stvara `RawVec` (na sistemskoj hrpi) sa tačno potrebnim kapacitetom i poravnanjem za `[T; capacity]`.
    /// To je ekvivalentno pozivanju `RawVec::new` kada je `capacity` `0` ili `T` nulte veličine.
    /// Imajte na umu da ako je `T` nulte veličine, to znači da *nećete* dobiti `RawVec` traženog kapaciteta.
    ///
    /// # Panics
    ///
    /// Panics ako traženi kapacitet premašuje `isize::MAX` bajtova.
    ///
    /// # Aborts
    ///
    /// Prekidi na OOM-u.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kao i `with_capacity`, ali garantuje da je međuspremnik nuliran.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituira `RawVec` iz pokazivača i kapaciteta.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti dodijeljen (na sistemskoj hrpi) i sa datim `capacity`.
    /// `capacity` ne može premašiti `isize::MAX` za veličine.(zabrinjava samo 32-bitni sistem).
    /// ZST vektori mogu imati kapacitet do `usize::MAX`.
    /// Ako `ptr` i `capacity` dolaze iz `RawVec`, onda je to zagarantovano.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Mali Vecs su glupi.Preskoči na:
    // - 8 ako je veličina elementa 1, jer će bilo koji alokatori hrpe vjerojatno zaokružiti zahtjev manji od 8 bajtova na najmanje 8 bajtova.
    //
    // - 4 ako su elementi umjerene veličine (<=1 KiB).
    // - 1 inače, kako bi se izbjeglo gubljenje previše prostora za vrlo kratke Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Poput `new`, ali parametriziran pri odabiru alokatora za vraćeni `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` znači "unallocated".tipovi nulte veličine se zanemaruju.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Poput `with_capacity`, ali parametriziran pri odabiru alokatora za vraćeni `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Poput `with_capacity_zeroed`, ali parametriziran pri odabiru alokatora za vraćeni `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Pretvara `Box<[T]>` u `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Pretvara cijeli međuspremnik u `Box<[MaybeUninit<T>]>` sa navedenim `len`.
    ///
    /// Imajte na umu da će ovo ispravno rekonstruirati sve promjene `cap` koje su možda izvršene.(Za detalje pogledajte opis tipa.)
    ///
    /// # Safety
    ///
    /// * `len` mora biti veći ili jednak nedavno zatraženom kapacitetu, i
    /// * `len` mora biti manji ili jednak `self.capacity()`.
    ///
    /// Imajte na umu da bi se traženi kapacitet i `self.capacity()` mogli razlikovati jer bi raspodjeljivač mogao dodijeliti i vratiti veći memorijski blok od traženog.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Provjerite zdrav razum jedne polovine sigurnosnih zahtjeva (drugu polovicu ne možemo provjeriti).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ovdje izbjegavamo `unwrap_or_else` jer smanjuje količinu generiranog LLVM IR-a.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituira `RawVec` iz pokazivača, kapaciteta i alokatora.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti dodijeljen (putem datog alokatora `alloc`) i sa datim `capacity`.
    /// `capacity` ne može premašiti `isize::MAX` za veličine.
    /// (zabrinjava samo 32-bitni sistem).
    /// ZST vektori mogu imati kapacitet do `usize::MAX`.
    /// Ako `ptr` i `capacity` potiču iz `RawVec` stvorenog putem `alloc`, onda je to zagarantovano.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Dobiva sirovi pokazivač na početak dodjele.
    /// Imajte na umu da je ovo `Unique::dangling()` ako je `capacity == 0` ili `T` nulte veličine.
    /// U prvom slučaju, morate biti oprezni.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Dobiva kapacitet dodjele.
    ///
    /// To će uvijek biti `usize::MAX` ako je `T` nulte veličine.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Vraća zajedničku referencu na alokator koji podržava ovaj `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Dodijeljen nam je dio memorije, tako da možemo zaobići provjere vremena izvođenja da bismo dobili naš trenutni izgled.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Osigurava da me uspremnik sadrži barem dovoljno prostora za držanje `len + additional` elemenata.
    /// Ako već nema dovoljno kapaciteta, dodijelit će dovoljno prostora plus udoban opušteni prostor da bi se amortiziralo *O*(1) ponašanje.
    ///
    /// Ograničit će ovo ponašanje ako bi se nepotrebno uzrokovalo panic.
    ///
    /// Ako `len` premaši `self.capacity()`, ovo možda neće uspjeti dodijeliti traženi prostor.
    /// Ovo zapravo nije nesigurno, ali nesigurni kod * koji napišete i oslanja se na ponašanje ove funkcije može se pokvariti.
    ///
    /// Ovo je idealno za implementaciju bulk-push operacije poput `extend`.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet premašuje `isize::MAX` bajtova.
    ///
    /// # Aborts
    ///
    /// Prekidi na OOM-u.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva bi se prekinula ili uspaničila da leća premašuje `isize::MAX`, tako da je to sigurno učiniti sada neprovjerenom.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Isto kao `reserve`, ali vraća greške umjesto panike ili prekida.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Osigurava da me uspremnik sadrži barem dovoljno prostora za držanje `len + additional` elemenata.
    /// Ako već ne, preraspodijelit će najmanju moguću količinu potrebne memorije.
    /// Općenito će ovo biti tačno potrebna količina memorije, ali u principu je alokator slobodan vratiti više nego što smo tražili.
    ///
    ///
    /// Ako `len` premaši `self.capacity()`, ovo možda neće uspjeti dodijeliti traženi prostor.
    /// Ovo zapravo nije nesigurno, ali nesigurni kod * koji napišete i oslanja se na ponašanje ove funkcije može se pokvariti.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet premašuje `isize::MAX` bajtova.
    ///
    /// # Aborts
    ///
    /// Prekidi na OOM-u.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Isto kao `reserve_exact`, ali vraća greške umjesto panike ili prekida.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Smanjuje dodjelu na navedeni iznos.
    /// Ako je zadani iznos 0, zapravo se u potpunosti oslobađa.
    ///
    /// # Panics
    ///
    /// Panics ako je zadani iznos *veći* od trenutnog kapaciteta.
    ///
    /// # Aborts
    ///
    /// Prekidi na OOM-u.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Vraća se ako međuspremnik treba rasti kako bi ispunio potreban dodatni kapacitet.
    /// Uglavnom se koristi za omogućavanje uvrštavanja rezervnih poziva bez ugradnje `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ova metoda se obično instancira mnogo puta.Dakle, želimo da bude što manji, kako bismo poboljšali vrijeme kompajliranja.
    // Ali također želimo da što veći dio njegovog sadržaja bude statički izračunljiv, kako bi generirani kôd radio brže.
    // Stoga je ova metoda pažljivo napisana tako da je sav kôd koji ovisi o `T` unutar nje, dok je što je moguće više koda koji ne ovisi o `T` u funkcijama koje nisu generičke u odnosu na `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // To osiguravaju pozivni konteksti.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Budući da vraćamo kapacitet od `usize::MAX` kada je `elem_size`
            // 0, dolazak ovdje nužno znači da je `RawVec` prenatrpan.
            return Err(CapacityOverflow);
        }

        // Nažalost, ništa ne možemo učiniti s ovim provjerama.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // To garantuje eksponencijalni rast.
        // Udvostručavanje se ne može preliti jer je `cap <= isize::MAX` i tip `cap` `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nije generički u odnosu na `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Ograničenja ove metode su približno ista kao i kod `grow_amortized`, ali ova metoda se obično rjeđe primjenjuje, pa je manje kritična.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Budući da vraćamo kapacitet od `usize::MAX` kada je veličina tipa
            // 0, dolazak ovdje nužno znači da je `RawVec` prenatrpan.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nije generički u odnosu na `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ova funkcija je izvan `RawVec` kako bi se smanjila vremena kompajliranja.Pogledajte komentar iznad `RawVec::grow_amortized` za detalje.
// (Parametar `A` nije značajan, jer je broj različitih tipova `A` viđenih u praksi mnogo manji od broja tipova `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Ovdje potražite grešku da biste smanjili veličinu `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokator provjerava jednakost poravnanja
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Oslobađa memoriju u vlasništvu `RawVec`*bez* pokušaja ispuštanja njenog sadržaja.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centralna funkcija za rukovanje rezervnim greškama.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Moramo garantirati sljedeće:
// * Nikada ne dodjeljujemo objekte veličine bajta `> isize::MAX`.
// * Ne prelijevamo `usize::MAX` i zapravo dodijeljujemo premalo.
//
// Na 64-bitnoj samo trebamo provjeriti preljev jer pokušaj dodjele `> isize::MAX` bajtova sigurno neće uspjeti.
// Na 32-bitne i 16-bitne moramo dodati dodatnu zaštitu za ovo u slučaju da radimo na platformi koja može koristiti svih 4 GB u korisničkom prostoru, npr. PAE ili x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Jedna centralna funkcija odgovorna za prekomjerni kapacitet izvještavanja.
// Ovo će osigurati da generiranje koda povezano sa ovim panics bude minimalno, jer postoji samo jedna lokacija koja je panics, a ne gomila u cijelom modulu.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}