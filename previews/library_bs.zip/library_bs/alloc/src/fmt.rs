//! Uslužni programi za formatiranje i ispis `String`-a.
//!
//! Ovaj modul sadrži runtime podršku za proširenje sintakse [`format!`].
//! Ovaj makronaredba je implementirana u kompajleru da emitira pozive ovom modulu kako bi se formatirali argumenti tokom izvođenja u nizove.
//!
//! # Usage
//!
//! Makro [`format!`] je namijenjen da bude poznat onima koji dolaze iz C-ovih `printf`/`fprintf` funkcija ili Python-ove `str.format` funkcije.
//!
//! Neki primjeri proširenja [`format!`] su:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" sa vodećim nulama
//! ```
//!
//! Iz njih možete vidjeti da je prvi argument niz formata.Prevodnik zahtijeva da ovo bude literal niza;to ne može biti varijabla predata (kako bi se izvršila provjera valjanosti).
//! Kompajler će zatim raščlaniti niz formata i utvrditi je li lista danih argumenata prikladna za prosljeđivanje u ovaj niz formata.
//!
//! Da biste pretvorili jednu vrijednost u niz, koristite [`to_string`] metodu.Ovo će koristiti [`Display`] formatiranje Portrait.
//!
//! ## Pozicijski parametri
//!
//! Svaki argument oblikovanja smije navesti na koji se argument vrijednosti poziva, a ako je izostavljen, pretpostavlja se da je "the next argument".
//! Na primjer, niz formatiranja `{} {} {}` trebao bi uzeti tri parametra i oni bi bili formatirani istim redoslijedom kao što je dato.
//! Niz formatiranja `{2} {1} {0}`, međutim, formatirao bi argumente obrnutim redoslijedom.
//!
//! Stvari mogu postati malo zapetljane kad jednom počnete miješati dvije vrste pozicijskih specifikatora.Specifikator "next argument" može se smatrati iteratorom nad argumentom.
//! Svaki put kad se vidi "next argument" specifikator, iterator napreduje.To dovodi do ovakvog ponašanja:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Interni iterator nad argumentom nije unaprijeđen do trenutka kada se vidi prvi `{}`, pa ispisuje prvi argument.Zatim je po dolasku do drugog `{}`, iterator prešao naprijed na drugi argument.
//! U osnovi, parametri koji eksplicitno imenuju svoj argument ne utječu na parametre koji ne imenuju argument u smislu pozicijskih specifikatora.
//!
//! Niz formata je potreban da bi koristio sve svoje argumente, u suprotnom se radi o pogrešci vremena kompajliranja.Na isti argument možete se pozivati više puta u nizu formata.
//!
//! ## Imenovani parametri
//!
//! Sam Rust nema ekvivalent imenovanih parametara sličnih Python funkciji, ali makro [`format!`] je sintaksno proširenje koje mu omogućava da koristi imenovane parametre.
//! Imenovani parametri navedeni su na kraju popisa argumenata i imaju sintaksu:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Na primjer, svi sljedeći izrazi [`format!`] koriste imenovani argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nije valjano postavljati pozicijske parametre (one bez imena) nakon argumenata koji imaju imena.Kao i kod pozicijskih parametara, ne vrijedi pružiti imenovane parametre koji se ne koriste u formatu stringa.
//!
//! # Parametri formatiranja
//!
//! Svaki argument koji se formatira može se transformirati brojnim parametrima formatiranja (što odgovara `format_spec` u [the syntax](#syntax)). Ti parametri utječu na predstavljanje niza onoga što se formatira.
//!
//! ## Width
//!
//! ```
//! // Sve ovo štampa "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ovo je parametar za "minimum width" koji bi format trebao zauzeti.
//! Ako niz vrijednosti ne popunjava toliko znakova, tada će se popunjavanje određeno fill/alignment koristiti za zauzimanje potrebnog prostora (vidi dolje).
//!
//! Vrijednost za širinu također se može dati kao [`usize`] na listi parametara dodavanjem postfiksa `$`, što ukazuje da je drugi argument [`usize`] koji specificira širinu.
//!
//! Pozivanje na argument sa sintaksom dolara ne utječe na brojač "next argument", pa je obično dobro uputiti se na argumente po položaju ili koristiti imenovane argumente.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Izborni znak za popunjavanje i poravnanje pružaju se obično zajedno s parametrom [`width`](#width).Mora se definirati prije `width`, odmah nakon `:`.
//! To ukazuje da će se, ako je vrijednost koja se formatira manja od `width`, oko nje ispisati neki dodatni znak.
//! Punjenje dolazi u sljedećim varijantama za različita poravnanja:
//!
//! * `[fill]<` - argument je poravnat lijevo u `width` stupcima
//! * `[fill]^` - argument je centriran u sredini u `width` stupcima
//! * `[fill]>` - argument je desno poravnat u `width` stupcima
//!
//! Zadani [fill/alignment](#fillalignment) za nenumeričke brojeve je razmak i poravnat ulijevo.Zadana vrijednost za numeričke formatere je također razmak, ali s desnim poravnanjem.
//! Ako je zastavica `0` (vidi dolje) navedena za brojke, tada je implicitni znak popunjavanja `0`.
//!
//! Imajte na umu da neke vrste poravnanja možda neće biti implementirane.Konkretno, obično se ne primenjuje za `Debug` Portrait.
//! Dobar način da se osigura da se primijeni dodavanje je formatiranje vašeg unosa, a zatim podmetanje ovog rezultirajućeg niza da biste dobili izlaz:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Zdravo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Sve su to zastavice koje mijenjaju ponašanje oblikovača.
//!
//! * `+` - Ovo je namijenjeno numeričkim tipovima i ukazuje na to da znak uvijek treba ispisivati.Pozitivni znakovi se nikad ne ispisuju prema zadanim postavkama, a negativni se prema standardnim postavkama ispisuju samo za `Signed` Portrait.
//! Ova zastavica označava da uvijek treba ispisati ispravan znak (`+` ili `-`).
//! * `-` - Trenutno se ne koristi
//! * `#` - Ova zastavica označava da treba koristiti "alternate" oblik ispisa.Alternativni oblici su:
//!     * `#?` - lijepo ispišite [`Debug`] formatiranje
//!     * `#x` - prethodi argumentu sa `0x`
//!     * `#X` - prethodi argumentu sa `0x`
//!     * `#b` - prethodi argumentu sa `0b`
//!     * `#o` - prethodi argumentu sa `0o`
//! * `0` - Ovo se koristi za ukazivanje na cjelobrojne formate da bi dodavanje do `width` trebalo obaviti znakom `0`, kao i biti svjestan znakova.
//! Format poput `{:08}` dao bi `00000001` za cijeli broj `1`, dok bi isti format dao `-0000001` za cijeli broj `-1`.
//! Primijetite da negativna verzija ima jednu nulu manje od pozitivne verzije.
//!         Imajte na umu da se nule za popunjavanje uvijek stavljaju iza znaka (ako postoji) i ispred znamenki.Kada se koristi zajedno sa zastavicom `#`, primjenjuje se slično pravilo: dodavanje nula ubacuje se nakon prefiksa, ali prije znamenki.
//!         Prefiks je uključen u ukupnu širinu.
//!
//! ## Precision
//!
//! Za ne-numeričke tipove, ovo se može smatrati "maximum width".
//! Ako je rezultirajući niz duži od ove širine, tada je skraćen na toliko znakova i ta skraćena vrijednost emitira se s odgovarajućim `fill`, `alignment` i `width` ako su ti parametri postavljeni.
//!
//! Za integralne tipove ovo se zanemaruje.
//!
//! Za tipove s pomičnom zarezom, ovo pokazuje koliko znamenki nakon decimalne točke treba ispisati.
//!
//! Tri su moguća načina da odredite željeni `precision`:
//!
//! 1. Cijeli broj `.N`:
//!
//!    sam cijeli broj `N` je preciznost.
//!
//! 2. Cijeli broj ili ime praćeno znakom dolara `.N$`:
//!
//!    za preciznost koristite format *argument*`N` (koji mora biti `usize`).
//!
//! 3. Zvezdica `.*`:
//!
//!    `.*` znači da je ovaj `{...}` povezan s *dva* ulaza formata, a ne s jednim: prvi ulaz sadrži preciznost `usize`, a drugi vrijednost za ispis.
//!    Imajte na umu da se u ovom slučaju, ako se koristi niz formata `{<arg>:<spec>.*}`, dio `<arg>` odnosi na* vrijednost * za ispis, a `precision` mora doći na ulazu koji prethodi `<arg>`.
//!
//! Na primjer, svi sljedeći pozivi ispisuju istu stvar `Hello x is 0.01000`:
//!
//! ```
//! // Pozdrav {arg 0 ("x")} je {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Pozdrav {arg 1 ("x")} je {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Pozdrav {arg 0 ("x")} je {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Pozdrav {next arg ("x")} je {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Pozdrav {next arg ("x")} je {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Pozdrav {next arg ("x")} je {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Dok su ovi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! ispisati tri bitno različite stvari:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! U nekim programskim jezicima ponašanje funkcija formatiranja niza ovisi o postavci lokalizacije operativnog sistema.
//! Funkcije formatiranja koje pruža standardna knjižnica Rust nemaju nikakav koncept lokalizacije i proizvest će iste rezultate na svim sistemima bez obzira na korisničku konfiguraciju.
//!
//! Na primjer, sljedeći će kôd uvijek ispisati `1.5`, čak i ako sistemski jezik koristi decimalni separator koji nije tačka.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Doslovni znakovi `{` i `}` mogu se uključiti u niz prethodeći im istim znakom.Na primjer, znak `{` se izbjegava s `{{`, a znak `}` izbjegava se sa `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Da rezimiramo, ovdje možete pronaći punu gramatiku nizova formata.
//! Sintaksa za jezik formatiranja koji se koristi izvučena je iz drugih jezika, pa ne bi trebala biti previše strana.Argumenti su formatirani sintaksom sličnom Python, što znači da su argumenti okruženi `{}` umjesto C-sličnim `%`.
//! Stvarna gramatika za sintaksu oblikovanja je:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! U gornjoj gramatici `text` ne smije sadržavati znakove `'{'` ili `'}'`.
//!
//! # Formatiranje traits
//!
//! Kada tražite da se argument formatira s određenim tipom, zapravo tražite da se argument pripiše određenom Portrait.
//! To omogućava formatiranje više stvarnih tipova putem `{:x}` (poput [`i8`], kao i [`isize`]).Trenutno mapiranje tipova na traits je:
//!
//! * *ništa* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] s malim slovima heksadecimalnih cijelih brojeva
//! * `X?` ⇒ [`Debug`] s velikim heksadecimalnim cijelim brojevima
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! To znači da se bilo koja vrsta argumenta koja implementira [`fmt::Binary`][`Binary`] Portrait može formatirati sa `{:b}`.Standardne biblioteke također pružaju implementacije za ove traits za brojne primitivne tipove.
//!
//! Ako nije naveden nijedan format (kao u `{}` ili `{:6}`), tada se koristi format Portrait [`Display`] Portrait.
//!
//! Kada implementirate format Portrait za svoj tip, morat ćete implementirati metodu potpisa:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // naš prilagođeni tip
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Vaš će se tip proslijediti kao referentna referenca `self`, a zatim bi funkcija trebala emitirati izlaz u `f.buf` tok.Na svakoj implementaciji Portrait formata je da se ispravno pridržava traženih parametara formatiranja.
//! Vrijednosti ovih parametara bit će navedene u poljima [`Formatter`] strukture.Da bi vam pomogao u tome, struktura [`Formatter`] također nudi neke pomoćne metode.
//!
//! Uz to, povratna vrijednost ove funkcije je [`fmt::Result`] koja je pseudonim tipa [`Rezultat`]`<(),`[`std: : fmt::Error`] `>`.
//! Implementacije formatiranja trebaju osigurati da šire greške iz [`Formatter`] (npr. Prilikom pozivanja [`write!`]).
//! Međutim, nikada ne bi trebali pogrešno vraćati pogreške.
//! Odnosno, implementacija formatiranja mora i može vratiti grešku samo ako proslijeđeni [`Formatter`] vrati grešku.
//! To je zato što je, suprotno onome što potpis funkcije može sugerirati, formatiranje niza nepogrešiva operacija.
//! Ova funkcija vraća rezultat samo zato što zapisivanje u temeljni tok može propasti i mora pružiti način za širenje činjenice da je došlo do pogreške u sigurnosnom kopiranju steka.
//!
//! Primjer implementacije formatiranja traits mogao bi izgledati:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Vrijednost `f` implementira `Write` Portrait, što piše!makro očekuje.
//!         // Imajte na umu da ovo formatiranje zanemaruje različite zastave predviđene za formatiranje nizova.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Različite traits omogućavaju različite oblike izlaza tipa.
//! // Značenje ovog formata je ispis veličine vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Poštujte zastavice oblikovanja upotrebom pomoćne metode `pad_integral` na objektu Formatter.
//!         // Pogledajte detalje u dokumentaciji metode, a funkcija `pad` može se koristiti za umetanje nizova.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Ova dva formatiranja traits imaju različite svrhe:
//!
//! - [`fmt::Display`][`Display`] implementacije tvrde da tip može biti vjerno predstavljen kao UTF-8 niz u svakom trenutku.**Ne** očekuje se da svi tipovi implementiraju [`Display`] Portrait.
//! - [`fmt::Debug`][`Debug`] implementacije bi trebale biti implementirane za **sve** javne tipove.
//!   Izlaz će obično predstavljati unutrašnje stanje što je vjernije moguće.
//!   Svrha [`Debug`] Portrait je olakšati otklanjanje pogrešaka kodom Rust.U većini slučajeva upotreba `#[derive(Debug)]` je dovoljna i preporučljiva.
//!
//! Neki primjeri rezultata iz oba traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Povezani makronaredbe
//!
//! Postoji niz srodnih makronaredbi u porodici [`format!`].Trenutno se provode:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ovo i [`writeln!`] su dvije makronaredbe koje se koriste za emitiranje niza formata u određeni tok.To se koristi za sprječavanje posredne dodjele nizova formata i umjesto toga direktno upisuje izlaz.
//! Ispod haube ova funkcija zapravo poziva funkciju [`write_fmt`] definiranu na [`std::io::Write`] Portrait.
//! Primjer upotrebe je:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ovo i [`println!`] emitiraju svoj izlaz na stdout.Slično makronaredbi [`write!`], cilj ovih makronaredbi je izbjeći međuvrijednu dodjelu prilikom ispisa.Primjer upotrebe je:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makronaredbe [`eprint!`] i [`eprintln!`] identične su [`print!`] i [`println!`], osim što emitiraju svoj izlaz na stderr.
//!
//! ### `format_args!`
//!
//! Ovo je znatiželjna makronaredba koja se koristi za sigurno prolazak oko neprozirnog objekta koji opisuje niz formata.Ovaj objekt ne zahtijeva nikakvu dodjelu hrpe za stvaranje, a samo se poziva na informacije na stogu.
//! Ispod haube su svi povezani makronaredbe implementirani u smislu ovoga.
//! Prvo, neki primjeri korištenja su:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Rezultat makronaredbe [`format_args!`] je vrijednost tipa [`fmt::Arguments`].
//! Tada se ova struktura može proslijediti funkcijama [`write`] i [`format`] unutar ovog modula kako bi se obradio niz formata.
//! Cilj ovog makronaredbe je još više spriječiti međuraspodjelu kada se radi sa formatiranjem nizova.
//!
//! Na primjer, knjižnica dnevnika može koristiti standardnu sintaksu formatiranja, ali će interno prolaziti kroz ovu strukturu dok se ne utvrdi kuda izlaz treba ići.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcija `format` uzima strukturu [`Arguments`] i vraća rezultirajući formatirani niz.
///
///
/// Primjerak [`Arguments`] može se kreirati s makronaredbom [`format_args!`].
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Imajte na umu da bi korištenje [`format!`] moglo biti poželjnije.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}