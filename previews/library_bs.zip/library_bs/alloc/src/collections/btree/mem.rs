use core::intrinsics;
use core::mem;
use core::ptr;

/// Ovo zamjenjuje vrijednost iza jedinstvene reference `v` pozivanjem relevantne funkcije.
///
///
/// Ako se panic dogodi u zatvaranju `change`, cijeli će postupak biti prekinut.
#[allow(dead_code)] // čuvati kao ilustraciju i za upotrebu za future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ovo zamjenjuje vrijednost iza jedinstvene reference `v` pozivanjem relevantne funkcije i vraća rezultat dobiven usput.
///
///
/// Ako se panic dogodi u zatvaranju `change`, cijeli će postupak biti prekinut.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}