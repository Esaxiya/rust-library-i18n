use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelira ponovno pokretanje neke jedinstvene reference, kada znate da se ponovna pozajmica i svi njeni potomci (tj. Svi pokazivači i reference izvedeni iz nje) više neće koristiti u nekom trenutku, nakon čega želite ponovo koristiti originalnu jedinstvenu referencu .
///
///
/// Provjera zajmova obično obrađuje ovo slaganje pozajmica umjesto vas, ali neki kontrolni tokovi koji ostvaruju ovo slaganje previše su složeni da bi ih kompajler mogao pratiti.
/// `DormantMutRef` vam omogućava da sami provjerite kako se zadužujete, a da i dalje izražavate njegovu složenu prirodu i enkapsulirate sirovi kôd pokazivača potreban za to bez nedefiniranog ponašanja.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Snimite jedinstvenu pozajmicu i odmah je ponovo pozajmite.
    /// Za kompajler je vijek trajanja nove reference isti kao i vijek izvorne reference, ali vi želite da je koristite promise za kraće vrijeme.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BEZBEDNOST: posuđujemo preko `_marker` i izlažemo
        // samo ova referenca, pa je jedinstvena.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vratite se jedinstvenom posuđivanju u početku snimljenom.
    ///
    /// # Safety
    ///
    /// Ponovno posudba mora biti završena, tj. Referenca koju vraća `new` i svi pokazivači i reference izvedene iz nje, više se ne smiju koristiti.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIGURNOST: vlastiti sigurnosni uvjeti impliciraju da je ova referenca opet jedinstvena.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;