//! Prioritetni red implementiran s binarnom hrpom.
//!
//! Umetanje i iskakanje najvećeg elementa imaju vremensku složenost *O*(log(*n*)).
//! Provjera najvećeg elementa je *O*(1).Pretvaranje vector u binarnu hrpu može se izvršiti na mjestu i ima složenost *O*(*n*).
//! Binarna gomila se također može pretvoriti u sortirani vector na mjestu, omogućavajući mu upotrebu za *O*(*n*\*log(* n*)) na mjestu gomile.
//!
//! # Examples
//!
//! Ovo je veći primjer koji implementira [Dijkstra's algorithm][dijkstra] za rješavanje [shortest path problem][sssp] na [directed graph][dir_graph].
//!
//! Pokazuje kako se [`BinaryHeap`] koristi sa prilagođenim tipovima.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Red prioriteta ovisi o `Ord`.
//! // Eksplicitno implementirajte Portrait tako da red postaje min-hrpa umjesto max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Primijetite da preokrećemo redoslijed troškova.
//!         // U slučaju izjednačenja uspoređujemo pozicije, ovaj korak je neophodan kako bi implementacije `PartialEq` i `Ord` bile dosljedne.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` takođe treba implementirati.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Svaki čvor je predstavljen kao `usize`, radi kraće implementacije.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstrin algoritam najkraćeg puta.
//!
//! // Počnite od `start` i koristite `dist` za praćenje trenutne najkraće udaljenosti do svakog čvora.Ova implementacija nije memorijski učinkovita jer može ostaviti duplirane čvorove u redu.
//! //
//! // Takođe koristi `usize::MAX` kao kontrolnu vrijednost, radi jednostavnije implementacije.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=trenutno najkraća udaljenost od `start` do `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Nalazimo se na `start`, sa nultim troškovima
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Prvo ispitajte granicu sa jeftinijim čvorovima (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternativno, mogli smo nastaviti pronalaziti sve najkraće staze
//!         if position == goal { return Some(cost); }
//!
//!         // Važno jer smo možda već pronašli bolji način
//!         if cost > dist[position] { continue; }
//!
//!         // Za svaki čvor koji možemo doseći, pogledajte možemo li pronaći način s nižim troškovima koji prolazi kroz ovaj čvor
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ako je tako, dodajte je na granicu i nastavite
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Opuštanje, sada smo pronašli bolji način
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Cilj nije dostupan
//!     None
//! }
//!
//! fn main() {
//!     // Ovo je usmjereni graf koji ćemo koristiti.
//!     // Brojevi čvorova odgovaraju različitim stanjima, a ponderi edge simboliziraju cijenu prelaska s jednog čvora na drugi.
//!     //
//!     // Imajte na umu da su ivice jednosmjerne.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||. |
//!     //                   +---------------+
//!     //
//!     // Grafikon je predstavljen kao lista susjednosti gdje svaki indeks, koji odgovara vrijednosti čvora, ima listu odlaznih bridova.
//!     // Izabran zbog svoje efikasnosti.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Čvor 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Čvor 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Čvor 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Čvor 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Čvor 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Prioritetni red implementiran s binarnom hrpom.
///
/// Ovo će biti maksimalna gomila.
///
/// Logična je greška da se stavka modificira na takav način da se redoslijed stavke u odnosu na bilo koju drugu stavku, kako je određeno `Ord` Portrait, mijenja dok je u gomili.
///
/// To je obično moguće samo putem `Cell`, `RefCell`, globalnog stanja, I/O ili nesigurnog koda.
/// Ponašanje koje je rezultat takve logičke pogreške nije specificirano, ali neće rezultirati nedefiniranim ponašanjem.
/// To može uključivati panics, netočne rezultate, prekide, curenje memorije i ne-prekid.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Zaključivanje tipa omogućava nam da izostavimo eksplicitni potpis tipa (koji bi u ovom primjeru bio `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Možemo zaviriti da pogledamo sljedeću stavku na hrpi.
/// // U ovom slučaju još nema predmeta, pa dobivamo Nijedan.
/// assert_eq!(heap.peek(), None);
///
/// // Dodajmo neke rezultate ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Sada zavirite prikazuje najvažniju stavku na hrpi.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Možemo provjeriti dužinu hrpe.
/// assert_eq!(heap.len(), 3);
///
/// // Možemo prelaziti preko stavki u hrpi, iako se vraćaju slučajnim redoslijedom.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ako umjesto toga stavimo ove rezultate, trebali bi se vratiti po redu.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Možemo očistiti hrpu svih preostalih predmeta.
/// heap.clear();
///
/// // Gomila bi sada trebala biti prazna.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Ili `std::cmp::Reverse` ili prilagođena implementacija `Ord` mogu se koristiti za stvaranje `BinaryHeap` min-gomile.
/// To čini da `heap.pop()` vraća najmanju vrijednost umjesto najveće.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Vrijednosti umotavanja u `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ako sada stavimo ove rezultate, trebali bi se vratiti obrnutim redoslijedom.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Složenost vremena
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Vrijednost za `push` je očekivani trošak;dokumentacija o metodi daje detaljniju analizu.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktura koja omotava promjenjivu referencu na najveći predmet na `BinaryHeap`.
///
///
/// Ovaj `struct` je kreiran metodom [`peek_mut`] na [`BinaryHeap`].
/// Pogledajte dokumentaciju za više informacija.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SIGURNOST: PeekMut je instanciran samo za neprazne gomile.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SIGURNO: PeekMut je instanciran samo za neprazne gomile
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SIGURNO: PeekMut je instanciran samo za neprazne gomile
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Uklanja virenu vrijednost iz gomile i vraća je.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Stvara prazan `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Stvara prazan `BinaryHeap` kao max hrpu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Stvara prazan `BinaryHeap` specifičnog kapaciteta.
    /// Ovo unaprijed dodjeljuje dovoljno memorije za `capacity` elemente, tako da `BinaryHeap` ne mora biti preraspodijeljen dok ne sadrži barem toliko vrijednosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Vraća promjenjivu referencu na najveću stavku u binarnoj hrpi ili `None` ako je prazna.
    ///
    /// Note: Ako je vrijednost `PeekMut` procurila, gomila može biti u neskladnom stanju.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Složenost vremena
    ///
    /// Ako je stavka modificirana, tada je najgora vremenska složenost *O*(log(*n*)), inače je *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Uklanja najveću stavku iz binarne hrpe i vraća je, ili `None` ako je prazna.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Složenost vremena
    ///
    /// Najgori slučaj cijene `pop` na hrpi koja sadrži *n* elemente je *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SIGURNOST: !self.is_empty() znači da je self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Gura stavku na binarnu hrpu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Složenost vremena
    ///
    /// Očekivani trošak `push`, izračunat u prosjeku po svakom mogućem redoslijedu potiskivanja elemenata i tijekom dovoljno velikog broja potiskivanja, je *O*(1).
    ///
    /// Ovo je najsmislenija metrika troškova kada se guraju elementi koji *nisu* već u bilo kojem sortiranom uzorku.
    ///
    /// Vremenska složenost se pogoršava ako se elementi guraju u pretežno rastućem redoslijedu.
    /// U najgorem slučaju, elementi se potiskuju rastućim sortiranim redoslijedom, a amortizirana cijena po potiskivanju iznosi *O*(log(*n*)) prema hrpi koja sadrži *n* elemenata.
    ///
    /// Najgori slučaj *pojedinačnog* poziva na `push` je *O*(*n*).Najgori slučaj se događa kada se kapacitet iscrpi i treba mu se promijeniti veličina.
    /// Trošak promjene veličine amortiziran je u prethodnim brojkama.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SIGURNOST: Budući da smo progurali novu stavku, to znači
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Konzumira `BinaryHeap` i vraća vector sortiranim redoslijedom (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SIGURNOST: `end` prelazi sa `self.len() - 1` na 1 (oba su uključena),
            //  tako da je uvijek valjan indeks za pristup.
            //  Sigurno je pristupiti indeksu 0 (tj. `ptr`), jer
            //  1 <=kraj <self.len(), što znači self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SIGURNOST: `end` prelazi sa `self.len() - 1` na 1 (oba su uključena), tako da:
            //  0 <1 <=kraj <= self.len(), 1 <self.len() Što znači 0 <kraj i kraj <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Implementacije sift_up i sift_down koriste nesigurne blokove kako bi premjestili element iz vector (ostavljajući rupu), pomaknuli se duž ostalih i uklonili uklonjeni element natrag u vector na konačnom mjestu rupe.
    //
    // Za predstavljanje se koristi tip `Hole` i pobrinite se da se rupa na kraju opsega napuni, čak i na panic.
    // Korištenje rupe smanjuje konstantni faktor u usporedbi s korištenjem zamjena, koje uključuju dvostruko više poteza.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Pozivatelj mora garantirati da je `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Izvadite vrijednost na `pos` i napravite rupu.
        // SIGURNOST: Pozivatelj garantuje da je poz <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SIGURNOST: hole.pos()> start>=0, što znači hole.pos()> 0
            //  i tako hole.pos(), 1 se ne može preliti.
            //  Ovo garantira da je roditelj <hole.pos(), tako da je to važeći indeks, a također!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SIGURNOST: Isto kao gore
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Uzmite element na `pos` i pomaknite ga niz hrpu, dok su njegova djeca veća.
    ///
    ///
    /// # Safety
    ///
    /// Pozivatelj mora garantirati da je `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SIGURNOST: Pozivatelj garantira da je poz <kraj <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Nepromjenjiva petlja: dijete==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // usporedite s većim od dvoje djece SIGURNOST: dijete <kraj, 1 <self.len() i dijete + 1 <kraj <= self.len(), tako da su važeći indeksi.
            //
            //  dijete==2 *hole.pos() + 1!= hole.pos() i dijete + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ili 2* hole.pos() + 2 mogu se preliti ako je T ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ako smo već u redu, stanite.
            // SIGURNOST: dijete je sada ili staro dijete ili staro dijete + 1
            //  Već smo dokazali da su oba <self.len() i!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SIGURNOST: isto kao gore.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SIGURNOST: &&kratki spoj, što znači da u
        //  drugi uvjet je već tačno da je dijete==kraj, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SIGURNOST: dijete je već dokazano kao valjani indeks i
            //  dijete==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Pozivatelj mora garantirati da je `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SIGURNOST: poz <len garantuje pozivalac i
        //  očigledno len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Uzmite element na `pos` i pomaknite ga skroz niz hrpu, a zatim ga prosijte do svog položaja.
    ///
    ///
    /// Note: To je brže kada se zna da je element velik/ako bi trebao biti bliže dnu.
    ///
    /// # Safety
    ///
    /// Pozivatelj mora garantirati da je `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SIGURNOST: Pozivatelj garantuje da je poz <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Nepromjenjiva petlja: dijete==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SIGURNOST: dijete <kraj, 1 <self.len() i
            //  dijete + 1 <kraj <= self.len(), tako da su važeći indeksi.
            //  dijete==2 *hole.pos() + 1!= hole.pos() i dijete + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ili 2* hole.pos() + 2 mogu se preliti ako je T ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SIGURNOST: Isto kao gore
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SIGURNOST: dijete==kraj, 1 <self.len(), tako da je to važeći indeks
            //  i dijete==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SIGURNOST: poz je položaj u rupi i već je dokazan
        //  da bude važeći indeks.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SIGURNOST: n počinje od self.len()/2 i spušta se na 0.
            //  Jedini slučaj kada! (N <self.len()) je ako je self.len() ==0, ali to isključuje uvjet petlje.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Premješta sve elemente `other` u `self`, ostavljajući `other` praznim.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` uzima O(len1 + len2) operacije i oko 2 *(len1 + len2) poređenja u najgorem slučaju, dok `extend` uzima O(len2* log(len1)) operacije i oko 1 *len2* log_2(len1) poređenja u najgorem slučaju, pod pretpostavkom da je len1>= len2.
        // Za veće hrpe tačka ukrštanja više ne slijedi ovo obrazloženje i određena je empirijski.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Vraća iterator koji dohvaća elemente u redoslijedu hrpe.
    /// Dohvaćeni elementi uklanjaju se s izvorne hrpe.
    /// Preostali elementi uklonit će se u padajućem redoslijedu.
    ///
    /// Note:
    /// * `.drain_sorted()` je *O*(*n*\*log(* n*)); mnogo sporiji od `.drain()`.
    ///   Ovo potonje trebali biste koristiti za većinu slučajeva.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // uklanja sve elemente u redoslijedu hrpe
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Zadržava samo elemente navedene u predikatu.
    ///
    /// Drugim riječima, uklonite sve elemente `e` tako da `f(&e)` vrati `false`.
    /// Elementi se posjećuju nerazvrstanim (i neodređenim) redoslijedom.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // zadržite samo parne brojeve
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Vraća iterator koji posjećuje sve vrijednosti u osnovnom vector, proizvoljnim redoslijedom.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ispis 1, 2, 3, 4 proizvoljnim redoslijedom
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Vraća iterator koji dohvaća elemente u redoslijedu hrpe.
    /// Ova metoda troši izvornu hrpu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Vraća najveću stavku u binarnoj hrpi ili `None` ako je prazna.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Složenost vremena
    ///
    /// Trošak je *O*(1) u najgorem slučaju.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Vraća broj elemenata koje binarna gomila može sadržavati bez ponovnog dodjeljivanja.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Rezervira minimalni kapacitet za tačno `additional` dodatnih elemenata koji se ubacuju u zadati `BinaryHeap`.
    /// Ne čini ništa ako je kapacitet već dovoljan.
    ///
    /// Imajte na umu da alokator kolekciji može dati više prostora nego što traži.
    /// Stoga se ne može pouzdati da je kapacitet tačno minimalan.
    /// Dajte prednost [`reserve`] ako se očekuju umetanja future.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet pređe `usize`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervira kapacitet za najmanje `additional` dodatnih elemenata koji se ubacuju u `BinaryHeap`.
    /// Zbirka može rezervirati više prostora kako bi se izbjegle česte preraspodjele.
    ///
    /// # Panics
    ///
    /// Panics ako novi kapacitet pređe `usize`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Odbacuje što je moguće više dodatnih kapaciteta.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Baca kapacitet s donjom granicom.
    ///
    /// Kapacitet će ostati barem onoliko velik koliko i dužina i isporučena vrijednost.
    ///
    ///
    /// Ako je trenutni kapacitet manji od donje granice, to se ne koristi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Konzumira `BinaryHeap` i vraća osnovni vector proizvoljnim redoslijedom.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Štampati u nekom redoslijedu
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Daje dužinu binarne hrpe.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Provjerava je li binarna hrpa prazna.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Briše binarnu hrpu, vraćajući iterator preko uklonjenih elemenata.
    ///
    /// Elementi se uklanjaju proizvoljnim redoslijedom.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Ispušta sve stavke iz binarne hrpe.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Rupa predstavlja rupu u presjeku, tj. Indeks bez važeće vrijednosti (jer je premještena iz ili duplicirana).
///
/// U padu, `Hole` će vratiti krišku ispunjavajući položaj rupe vrijednošću koja je prvotno uklonjena.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Kreirajte novi `Hole` s indeksom `pos`.
    ///
    /// Nesigurno jer poz mora biti unutar kriške podataka.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SIGURNO: poz treba biti unutar reza
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Vraća referencu na uklonjeni element.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Vraća referencu na element na `index`.
    ///
    /// Nesigurno jer indeks mora biti unutar kriška podataka i ne mora biti jednak poz.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Premjestite rupu na novo mjesto
    ///
    /// Nesigurno jer indeks mora biti unutar kriška podataka i ne mora biti jednak poz.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ponovo popunite rupu
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Iterator nad elementima `BinaryHeap`.
///
/// Ovaj `struct` je kreirao [`BinaryHeap::iter()`].
/// Pogledajte dokumentaciju za više informacija.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Uklonite u korist `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Posjedovanje iteratora nad elementima `BinaryHeap`.
///
/// Ovaj `struct` je kreirao [`BinaryHeap::into_iter()`] (pruža ga `IntoIterator` Portrait).
/// Pogledajte dokumentaciju za više informacija.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Odvodni iterator preko elemenata `BinaryHeap`.
///
/// Ovaj `struct` je kreirao [`BinaryHeap::drain()`].
/// Pogledajte dokumentaciju za više informacija.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Odvodni iterator preko elemenata `BinaryHeap`.
///
/// Ovaj `struct` je kreirao [`BinaryHeap::drain_sorted()`].
/// Pogledajte dokumentaciju za više informacija.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Uklanja elemente hrpe po redoslijedu hrpe.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Pretvara `Vec<T>` u `BinaryHeap<T>`.
    ///
    /// Ova konverzija se događa na mjestu i ima *O*(*n*) vremensku složenost.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Pretvara `BinaryHeap<T>` u `Vec<T>`.
    ///
    /// Ova konverzija ne zahtijeva kretanje ili dodjelu podataka i ima stalnu vremensku složenost.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Stvara konzumirajući iterator, odnosno onaj koji premješta svaku vrijednost iz binarne hrpe u proizvoljnom redoslijedu.
    /// Binarna gomila se ne može koristiti nakon poziva.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Ispis 1, 2, 3, 4 proizvoljnim redoslijedom
    /// for x in heap.into_iter() {
    ///     // x ima tip i32, a ne &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}