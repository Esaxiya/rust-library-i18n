//! Implementacija Rust panics putem prekida postupka
//!
//! U usporedbi s implementacijom odmotavanjem, ovaj crate je *mnogo* jednostavniji!To je rečeno, nije toliko svestran, ali evo!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" korisni teret i podmetač za odgovarajući prekid na dotičnoj platformi.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // nazovite std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Na Windows koristite mehanizam __fastfail specifičan za procesor.U Windows 8 i novijim, ovo će odmah završiti proces bez pokretanja bilo kakvih obrađivača izuzetaka u procesu.
            // U ranijim verzijama Windows, ovaj slijed uputa tretirat će se kao kršenje pristupa, završavajući postupak, ali bez nužnog zaobilaženja svih rukovatelja iznimkama.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ovo je ista implementacija kao u libstd-ovom `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Ovo ... je malo čudno.Tl; dr;je da je ovo potrebno za ispravno povezivanje, dulje objašnjenje je ispod.
//
// Trenutno su binarne datoteke libcore/libstd koje isporučujemo kompajlirane sa `-C panic=unwind`.To se radi kako bi se osiguralo da su binarni programi maksimalno kompatibilni sa što više situacija.
// Kompajler, međutim, zahtijeva "personality function" za sve funkcije kompajlirane s `-C panic=unwind`.Ova funkcija ličnosti kodirana je simbolom `rust_eh_personality` i definirana je stavkom `eh_personality` lang.
//
// So...
// zašto jednostavno ne definirati tu stavku lang-a?Dobro pitanje!Način na koji su povezani runtimeovi panic zapravo je malo suptilan po tome što su "sort of" u spremištu crate spremišta, ali zapravo povezani samo ako drugi zapravo nisu povezani.
//
// To završava, što znači da se i ovaj crate i panic_unwind crate mogu pojaviti u spremištu crate spremišta, a ako oba definiraju `eh_personality` lang stavku, tada će doći do pogreške.
//
// Da bi ovo riješio, kompajler zahtijeva samo da je `eh_personality` definiran ako je vrijeme izvođenja panic na koje se povezuje runtime odmotavanja, a inače nije potrebno definirati (s pravom).
// U ovom slučaju, međutim, ova biblioteka samo definira ovaj simbol tako da negdje postoji barem neka osobnost.
//
// U osnovi je ovaj simbol upravo definiran za povezivanje s binarnim datotekama libcore/libstd, ali ga se nikada ne smije pozivati, jer se uopće ne povezujemo u vremenu odvijanja.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Na x86_64-pc-windows-gnu koristimo vlastitu funkciju ličnosti koja treba vratiti `ExceptionContinueSearch` dok prenosimo sve svoje okvire.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Slično kao i gore, ovo odgovara `eh_catch_typeinfo` jezičnoj stavci koja se trenutno koristi samo na Emscripten-u.
    //
    // Budući da panics ne generira iznimke, a strani izuzeci su trenutno UB s -C panic=abort (iako se ovo može promijeniti), svi pozivi catch_unwind nikada neće koristiti ovu vrstu informacija.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ovu dvojicu pozivaju naši startup objekti na i686-pc-windows-gnu, ali ne trebaju ništa raditi, tako da su tijela nesretna.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}