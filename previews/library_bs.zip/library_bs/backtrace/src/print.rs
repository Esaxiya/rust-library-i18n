#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formator za povratne tragove.
///
/// Ovaj tip se može koristiti za ispis povratnog traga bez obzira na to odakle potiče sam.
/// Ako imate tip `Backtrace`, njegova implementacija `Debug` već koristi ovaj format ispisa.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stilovi štampe koje možemo ispisati
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Štampa terser backtrace koji idealno sadrži samo relevantne informacije
    Short,
    /// Ispisuje backtrace koji sadrži sve moguće informacije
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Stvorite novi `BacktraceFmt` koji će ispisivati izlaz na ponuđeni `fmt`.
    ///
    /// Argument `format` će kontrolirati stil u kojem se ispisuje backtrace, a argument `print_path` će se koristiti za ispis instanci datoteka `BytesOrWideString`.
    /// Ovaj tip sam ne vrši ispis imena datoteka, ali za to je potreban ovaj povratni poziv.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Ispisuje preambulu za backtrace koji će se štampati.
    ///
    /// To je potrebno na nekim platformama da bi se povratni tragovi kasnije u potpunosti simbolizirali, a inače bi ovo trebala biti prva metoda koju pozovete nakon kreiranja `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Dodaje okvir na izlaz povratnog praćenja.
    ///
    /// Ovo urezivanje vraća RAII instancu `BacktraceFrameFmt` koja se može koristiti za stvarno ispisivanje okvira, a nakon uništenja povećat će brojač okvira.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Završava izlaz povratne kopije.
    ///
    /// Ovo trenutno nije dopušteno, ali je dodano zbog kompatibilnosti future s formatima povratnih tragova.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Trenutno se ne radi-uključujući ovaj hook kako bi se omogućile dodavanja future.
        Ok(())
    }
}

/// Formator za samo jedan kadar povratnog traga.
///
/// Ovaj tip kreira funkcija `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Štampa `BacktraceFrame` pomoću ovog formativača okvira.
    ///
    /// Ovo će rekurzivno ispisati sve instance `BacktraceSymbol` unutar `BacktraceFrame`.
    ///
    /// # Potrebne karakteristike
    ///
    /// Ova funkcija zahtijeva omogućavanje `std` značajke `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Štampa `BacktraceSymbol` unutar `BacktraceFrame`.
    ///
    /// # Potrebne karakteristike
    ///
    /// Ova funkcija zahtijeva omogućavanje `std` značajke `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ovo nije sjajno što na kraju ništa ne ispisujemo
            // s ne-utf8 imenima datoteka.
            // Srećom skoro sve je utf8, pa ovo ne bi trebalo biti previše loše.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ispisuje neobrađene tragove `Frame` i `Symbol`, obično iz sirovih povratnih poziva ovog crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Dodaje neobrađeni okvir izlazu za vraćanje unazad.
    ///
    /// Ova metoda, za razliku od prethodne, uzima sirove argumente u slučaju da su izvori s različitih lokacija.
    /// Imajte na umu da se ovo može pozivati više puta za jedan kadar.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Dodaje neobrađeni okvir izlazu za povratno praćenje, uključujući informacije o stupcima.
    ///
    /// Ova metoda, kao i prethodna, uzima sirove argumente u slučaju da su izvori s različitih lokacija.
    /// Imajte na umu da se ovo može pozivati više puta za jedan kadar.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuksija nije u stanju da simbolizira unutar procesa, tako da ima poseban format koji se kasnije može koristiti za simbolizaciju.
        // Ispišite to, umjesto da ovdje ispisujete adrese u našem formatu.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nema potrebe za ispisom "null" okvira, to u osnovi samo znači da je sistemsko praćenje bilo pomalo željno da se vrati super daleko.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Da bismo smanjili veličinu TCB-a u Sgx enklavi, ne želimo implementirati funkcionalnost razlučivanja simbola.
        // Umjesto toga, ovdje možemo ispisati ofset adrese, koji bi kasnije mogao biti mapiran kako bi ispravio funkciju.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Ispišite indeks okvira kao i opcionalni pokazivač uputa okvira.
        // Ako smo iznad prvog simbola ovog okvira, samo ispisujemo odgovarajući razmak.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Dalje ispišite ime simbola, koristeći alternativno formatiranje za više informacija ako smo puni backtrace.
        // Ovdje radimo i sa simbolima koji nemaju ime,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // I na kraju, odštampajte filename/line broj ako su dostupni.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ispisuju se na redovima pod imenom simbola, pa ispišite neki odgovarajući razmak da biste se nekako poravnali.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegirajte na naš interni povratni poziv da biste ispisali ime datoteke, a zatim ispisali broj linije.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Dodajte broj stupca, ako je dostupan.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Stalo nam je samo do prvog simbola okvira
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}