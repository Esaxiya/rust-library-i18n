use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr uzima povratni poziv koji će dobiti dl_phdr_info pokazivač za svaki ODS koji je povezan u proces.
    // dl_iterate_phdr također osigurava da je dinamički povezivač zaključan od početka do kraja iteracije.
    // Ako povratni poziv vrati vrijednost koja nije nula, iteracija se prekida.
    // 'data' će se proslijediti kao treći argument povratnom pozivu za svaki poziv.
    // 'size' daje veličinu dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Moramo raščlaniti ID gradnje i neke osnovne podatke zaglavlja programa, što znači da nam treba i malo stvari iz ELF specifikacija.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Sada moramo replicirati, bit za bit, strukturu tipa dl_phdr_info koju koristi trenutni dinamički povezivač fuchsia.
// Chromium također ima ovu ABI granicu, kao i pad pad.
// Napokon bismo htjeli ove slučajeve premjestiti na elf pretragu, ali to bismo trebali osigurati u SDK-u, a to još nije učinjeno.
//
// Stoga smo (i oni) zaglavili da moramo koristiti ovu metodu koja dovodi do čvrstog spajanja s fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ne možemo znati kako provjeriti jesu li e_phoff i e_phnum valjani.
    // libc bi to trebao osigurati za nas, ali zato je sigurno ovdje formirati dio.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr predstavlja 64-bitno ELF zaglavlje programa u krajnosti ciljne arhitekture.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr predstavlja važeće zaglavlje ELF programa i njegov sadržaj.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ne možemo provjeriti jesu li p_addr ili p_memsz valjani.
    // Fuchsia-in libc prvo raščlanjuje bilješke, međutim, zato što su ovdje, ova zaglavlja moraju biti važeća.
    //
    // NoteIter ne zahtijeva da osnovni podaci budu valjani, ali zahtijevaju da granice budu valjane.
    // Vjerujemo da je libc osigurao da je to slučaj ovdje za nas.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Tip bilješke za ID-ove gradnje.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr predstavlja zaglavlje ELF bilješke u krajnjem cilju.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Napomena predstavlja ELF napomenu (zaglavlje + sadržaj).
// Ime je ostavljeno kao u8 kriška, jer nije uvijek null prekinuto, a rust olakšava provjeru da li se bajtovi ionako podudaraju.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter vam omogućava sigurno prevlačenje kroz segment bilješke.
// Završava se čim se dogodi greška ili više nema napomena.
// Ako ponovite nevažeće podatke, funkcionirat će kao da nisu pronađene bilješke.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Invarijant je funkcije da zadani pokazivač i veličina označavaju valjani raspon bajtova koji se svi mogu pročitati.
    // Sadržaj ovih bajtova može biti bilo koji, ali opseg mora biti valjan da bi ovo bilo sigurno.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to poravnava 'x' sa poravnanjem bajtova 'to' pod pretpostavkom da je 'to' snage 2.
// Ovo slijedi standardni obrazac u C/C ++ ELF kodu za raščlanjivanje gdje se koristi (x + do, 1)&-to.
// Rust vam ne dozvoljava da negirate usize pa ga koristim
// Konverzija komplementa 2 za ponovno stvaranje.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 troši broj bajtova iz presjeka (ako je prisutan) i dodatno osigurava da je konačni presjek pravilno poravnan.
// Ako je ili broj bajtova koji je zatražen prevelik ili se kriška ne može naknadno poravnati zbog nedovoljnog broja preostalih bajtova, vraća se Nijedna i kriška se ne mijenja.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ova funkcija nema stvarne invarijante koje pozivatelj mora podržati, osim možda da bi 'bytes' trebao biti usklađen radi performansi (i na ispravnosti nekih arhitektura).
// Vrijednosti u poljima Elf_Nhdr mogu biti besmislice, ali ova funkcija ne osigurava takvo što.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ovo je sigurno sve dok ima dovoljno prostora i upravo smo to potvrdili u gornjoj izjavi if, tako da ovo ne bi trebalo biti nesigurno.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Imajte na umu da sice_of: :<Elf_Nhdr>() je uvijek poravnato sa 4 bajta.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Provjeri jesmo li stigli do kraja.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutiramo nhdr, ali pažljivo razmatramo rezultirajuću strukturu.
        // Ne vjerujemo imenimaz ili descsz i ne donosimo nesigurne odluke na osnovu tipa.
        //
        // Dakle, čak i ako izvadimo potpuno smeće, i dalje bismo trebali biti sigurni.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Označava da je segment izvršni.
const PERM_X: u32 = 0b00000001;
/// Označava da je u segmentu moguće pisati.
const PERM_W: u32 = 0b00000010;
/// Označava da je segment čitljiv.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Predstavlja ELF segment tokom izvođenja.
struct Segment {
    /// Daje virtualnu adresu izvođenja sadržaja ovog segmenta.
    addr: usize,
    /// Daje veličinu memorije sadržaja ovog segmenta.
    size: usize,
    /// Daje modulu virtualnu adresu ovog segmenta s ELF datotekom.
    mod_rel_addr: usize,
    /// Daje dozvole pronađene u ELF datoteci.
    /// Međutim, ove dozvole nisu nužno dozvole prisutne u vrijeme izvođenja.
    flags: Perm,
}

/// Omogućava iteraciju segmenata od ODS-a.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Predstavlja ELF DSO (dinamički dijeljeni objekt).
/// Ovaj tip upućuje na podatke pohranjene u stvarnom ODS-u, umjesto da pravi vlastitu kopiju.
struct Dso<'a> {
    /// Dinamički povezivač uvijek nam daje ime, čak i ako je ime prazno.
    /// U slučaju glavne izvršne datoteke ovo ime će biti prazno.
    /// U slučaju zajedničkog objekta to će biti soname (pogledajte DT_SONAME).
    name: &'a str,
    /// Na Fuchsia-i gotovo svi binarni programi imaju ID-ove gradnje, ali to nije strog zahtjev.
    /// Ne postoji način da se DSO informacije poklapaju sa stvarnom ELF datotekom nakon što nema build_id, pa zahtijevamo da ga svaki DSO ovdje ima.
    ///
    /// ODS bez build_id se ignoriraju.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Vraća iterator nad segmentima u ovom ODS-u.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Te pogreške kodiraju probleme koji nastaju prilikom raščlanjivanja informacija o svakom ODS-u.
///
enum Error {
    /// NameError znači da se dogodila pogreška prilikom pretvaranja niza stila C u rust niz.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError znači da nismo pronašli ID gradnje.
    /// To može biti zbog toga što ODS nije imao ID gradnje ili zato što je segment koji sadrži ID gradnje bio pogrešno oblikovan.
    ///
    BuildIDError,
}

/// Poziva 'dso' ili 'error' za svaki ODS koji je u proces povezan dinamičkim povezivačem.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter koji će imati jednu od metoda koja se zove foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr osigurava da info.name pokazuje na važeću lokaciju.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ova funkcija ispisuje oznaku Fuchsia simbolizatora za sve informacije sadržane u ODS-u.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}