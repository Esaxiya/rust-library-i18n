use core::ffi::c_void;
use core::fmt;

/// Pregledava trenutni niz poziva, prosljeđujući sve aktivne okvire u zatvarač predviđen za izračunavanje traga steka.
///
/// Ova funkcija je radna snaga ove knjižnice u izračunavanju tragova stogova za program.Dano zatvaranje `cb` daju primjeri `Frame` koji predstavljaju informacije o tom okviru poziva na stogu.
/// Zatvaranje daje okvire odozgo prema dolje (nedavno nazvani prvo funkcije).
///
/// Povratna vrijednost zatvaranja pokazatelj je treba li povratno praćenje nastaviti.Povratna vrijednost `false` završit će povratno praćenje i odmah se vratiti.
///
/// Jednom kada se nabavi `Frame`, vjerojatno ćete htjeti nazvati `backtrace::resolve` da pretvorite `ip` (pokazivač uputa) ili adresu simbola u `Symbol` putem koje se može naučiti ime i/ili naziv datoteke/broj linije.
///
///
/// Imajte na umu da je ovo funkcija relativno niskog nivoa i ako želite, na primjer, snimiti povratnu tragu koja će se kasnije pregledati, tada je tip `Backtrace` možda prikladniji.
///
/// # Potrebne karakteristike
///
/// Ova funkcija zahtijeva omogućavanje `std` značajke `backtrace` crate, a značajka `std` omogućena je prema zadanim postavkama.
///
/// # Panics
///
/// Ova funkcija teži nikada panic, ali ako je `cb` pružio panics, neke će platforme prisiliti dvostruki panic da prekine postupak.
/// Neke platforme koriste C biblioteku koja interno koristi povratne pozive koji se ne mogu odmotati, pa panika iz `cb` može pokrenuti prekid procesa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // nastaviti povratak
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Isto kao i `trace`, samo nesigurno jer je nesinkronizirano.
///
/// Ova funkcija nema garancije za sinkronizaciju, ali je dostupna kada `std` značajka ovog crate nije kompajlirana.
/// Pogledajte funkciju `trace` za više dokumentacije i primjera.
///
/// # Panics
///
/// Pogledajte informacije o `trace` za upozorenja o paničnosti `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Portrait koji predstavlja jedan okvir povratnog traga, ustupio je funkciji `trace` ovog crate.
///
/// Zatvaranje funkcije praćenja dobit će okvire, a okvir se gotovo šalje, jer osnovna implementacija nije uvijek poznata do vremena izvođenja.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vraća trenutni pokazivač uputa ovog okvira.
    ///
    /// Ovo je obično sljedeća uputa za izvršavanje u okviru, ali ne navode je sve implementacije sa 100% preciznošću (ali je uglavnom prilično blizu).
    ///
    ///
    /// Preporučuje se prosljeđivanje ove vrijednosti `backtrace::resolve` da bi se pretvorilo u ime simbola.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Daje trenutni pokazivač na stek ovog okvira.
    ///
    /// U slučaju da pozadina ne može oporaviti pokazivač steka za ovaj okvir, vraća se null pokazivač.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Vraća početnu adresu simbola okvira ove funkcije.
    ///
    /// Ovo će pokušati premotati pokazivač uputa koji je vratio `ip` na početak funkcije, vraćajući tu vrijednost.
    ///
    /// Međutim, u nekim slučajevima, backendovi će samo vratiti `ip` iz ove funkcije.
    ///
    /// Vraćena vrijednost se ponekad može koristiti ako `backtrace::resolve` nije uspio na gore navedenom `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Vraća osnovnu adresu modula kojem pripada okvir.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ovo mora biti na prvom mjestu, kako bi se osiguralo da Miri preuzme prioritet nad glavnom platformom
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // koristi se samo u dbghelp simboliziraju
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}