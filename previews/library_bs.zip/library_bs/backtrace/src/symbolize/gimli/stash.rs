// trenutno se koristi samo na Linux, pa zato dopustite mrtvi kod negdje drugdje
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Jednostavan alokacijski raspored za bajtne međuspremnike.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Dodjeljuje međuspremnik određene veličine i vraća mu promjenjivu referencu.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIGURNOST: ovo je jedina funkcija koja ikad konstruira promjenjivu
        // referenca na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIGURNOST: nikada ne uklanjamo elemente iz `self.buffers`, pa referenca
        // podaci unutar bilo kojeg međuspremnika živjet će sve dok `self` živi.
        &mut buffers[i]
    }
}