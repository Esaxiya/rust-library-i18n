# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Biblioteka za pribavljanje povratnih tragova tokom izvršavanja za Rust.
Cilj ove biblioteke je poboljšati podršku standardne biblioteke pružanjem programskog sučelja za rad, ali također podržava jednostavno ispisivanje trenutnog backtracea poput libstd-ovog panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Da biste jednostavno uhvatili povratnu tragu i odgodili bavljenje njom do kasnijeg vremena, možete koristiti tip `Backtrace` najvišeg nivoa.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ako, međutim, želite više neobrađenog pristupa stvarnoj funkcionalnosti praćenja, možete direktno koristiti funkcije `trace` i `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Riješite ovaj pokazivač uputa na ime simbola
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // nastavite na sljedeći kadar
    });
}
```

# License

Ovaj projekt je licenciran pod bilo kojim od

 * Apache licenca, verzija 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ili http://www.apache.org/licenses/LICENSE-2.0)
 * MIT licenca ([LICENSE-MIT](LICENSE-MIT) ili http://opensource.org/licenses/MIT)

po vašoj želji.

### Contribution

Ako izričito ne navedete drugačije, svaki vaš doprinos koji ste namjerno predali radi uključivanja u backtrace-rs, kako je definirano u licenci Apache-2.0, biće dvostruko licenciran kao gore, bez ikakvih dodatnih uslova ili uslova.







