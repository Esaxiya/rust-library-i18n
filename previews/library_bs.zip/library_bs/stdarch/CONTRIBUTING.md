# Doprinosi stdarchu

`stdarch` crate je više nego spreman prihvatiti doprinose!Prvo ćete vjerojatno htjeti provjeriti spremište i pobrinuti se da testovi prođu za vas:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Gdje je `<your-target-arch>` ciljna trojka kako je koristi `rustup`, npr. `x86_x64-unknown-linux-gnu` (bez prethodnog `nightly-` ili slično).
Imajte na umu i da ovo spremište zahtijeva noćni kanal Rust!
Gornji testovi u stvari zahtijevaju da rust bude noćni zadani zadani način na vašem sistemu, da postavi koji koriste `rustup default nightly` (i `rustup default stable` za vraćanje).

Ako bilo koji od gore navedenih koraka ne uspije, [please let us know][new]!

Dalje možete pomoći [find an issue][issues], odabrali smo nekoliko s oznakama [`help wanted`][help] i [`impl-period`][impl] koji bi mogli posebno koristiti. 
Možda će vas najviše zanimati [#40][vendor], koji implementira sve karakteristike dobavljača na x86.Taj broj ima nekoliko dobrih uputa o tome odakle započeti!

Ako imate općenita pitanja, slobodno se obratite [join us on gitter][gitter] i raspitajte se!Slobodno pitajte ili@BurntSushi ili@alexcrichton s pitanjima.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kako napisati primjere za stdarch intrinsics

Postoji nekoliko karakteristika koje moraju biti omogućene kako bi zadana unutarnja funkcija radila ispravno, a primjer mora pokrenuti `cargo test --doc` samo kada značajku podržava CPU.

Kao rezultat, zadani `fn main` koji generira `rustdoc` neće raditi (u većini slučajeva).
Razmislite o korištenju sljedećeg kao vodiča kako biste osigurali da vaš primjer radi kako se očekuje.

```rust
/// # // Treba nam cfg_target_feature da osiguramo da je samo primjer
/// # // pokreće `cargo test --doc` kada CPU podržava tu funkciju
/// # #![feature(cfg_target_feature)]
/// # // Treba nam target_feature da bi intrinzično funkcioniralo
/// # #![feature(target_feature)]
/// #
/// # // rustdoc po defaultu koristi `extern crate stdarch`, ali trebamo
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Prava glavna funkcija
/// # fn main() {
/// #     // Pokrenite ovo samo ako je podržan `<target feature>`
/// #     ako je cfg_feature_enabled! ("<target feature>"){
/// #         // Stvorite `worker` funkciju koja će se pokretati samo ako je ciljana karakteristika
/// #         // je podržan i osigurajte da je `target_feature` omogućen za vašeg radnika
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nesigurno fn worker() {
/// // Napišite svoj primjer ovdje.Ovdje će raditi karakteristike specifične za značajke!Podivljati!
///
/// #         }
///
/// #         nesigurno { worker(); }
/// #     }
/// # }
```

Ako neka od gornjih sintaksa ne izgleda poznato, [Documentation as tests] odjeljak [Rust Book] prilično dobro opisuje sintaksu `rustdoc`.
Kao i uvijek, budite slobodni za [join us on gitter][gitter] i pitajte nas da li ste zapeli i hvala vam što ste pomogli u poboljšanju dokumentacije `stdarch`!

# Alternativne upute za ispitivanje

Općenito se preporučuje da za pokretanje testova koristite `ci/run.sh`.
Međutim, ovo možda neće raditi za vas, npr. Ako ste na Windows.

U tom slučaju možete se vratiti na pokretanje `cargo +nightly test` i `cargo +nightly test --release -p core_arch` za testiranje generiranja koda.
Imajte na umu da je za to potrebno instalirati noćni lanac alata i da `rustc` zna o vašoj ciljanoj trojki i njenom procesoru.
Konkretno morate postaviti varijablu okruženja `TARGET` kao što biste to učinili za `ci/run.sh`.
Pored toga, morate postaviti `RUSTCFLAGS` (potreban vam je `C`) da naznači ciljne karakteristike, npr `RUSTCFLAGS="-C -target-features=+avx2"`.
Također možete postaviti `-C -target-cpu=native` ako se "just" razvija prema vašem trenutnom CPU-u.

Imajte na umu da kada koristite ove alternativne upute, npr. [things may go less smoothly than they would with `ci/run.sh`][ci-run-good]
testovi generacije instrukcija mogu propasti jer ih je rastavljač drugačije imenovao, npr
može generirati `vaesenc` umjesto `aesenc` uputa uprkos tome što se ponašaju isto.
Također ove upute izvršavaju manje testova nego što bi se to uobičajeno radilo, zato nemojte se iznenaditi da će se kad na kraju povučete zahtjev pojaviti neke greške za testove koji ovdje nisu obrađeni.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






