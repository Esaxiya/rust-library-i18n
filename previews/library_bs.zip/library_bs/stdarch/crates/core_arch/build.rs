use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Koristi se za napomenu našim `#[assert_instr]` napomenama da su svi intimni elementi simd-a dostupni za testiranje njihovog kodegena, jer su neki postavljeni iza dodatnog `-Ctarget-feature=+unimplemented-simd128` koji trenutno nema ekvivalent u `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}