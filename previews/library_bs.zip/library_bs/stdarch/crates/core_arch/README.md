`core::arch` - Osnovne karakteristike arhitekture osnovne biblioteke Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` implementira svojstva ovisna o arhitekturi (npr. SIMD).

# Usage 

`core::arch` dostupan je kao dio `libcore`, a `libstd` ga ponovno izvozi.Radije ga koristite putem `core::arch` ili `std::arch` nego putem ovog crate.
Nestabilne funkcije su često dostupne u noćnom Rust preko `feature(stdsimd)`.

Korištenje `core::arch` putem ovog crate zahtijeva noćni Rust i često se može (i ne mora) kvariti.Jedini slučajevi u kojima biste trebali razmotriti upotrebu putem ovog crate su:

* ako trebate sami prekompajlirati `core::arch`, npr. s omogućenim određenim ciljnim značajkama koje nisu omogućene za `libcore`/`libstd`.
Note: ako ga trebate prekompajlirati za nestandardni cilj, radije upotrijebite `xargo` i ponovno sastavite `libcore`/`libstd` po potrebi, umjesto da koristite ovaj crate.
  
* koristeći neke funkcije koje možda neće biti dostupne čak i iza nestabilnih Rust karakteristika.Trudimo se da ih svede na minimum.
Ako trebate koristiti neke od ovih funkcija, otvorite izdanje kako bismo ih mogli izložiti u noćnom Rust, a vi ih možete koristiti odatle.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` primarno se distribuira pod uvjetima MIT licence i Apache licence (verzija 2.0), s dijelovima pokrivenim različitim BSD-sličnim licencama.

Pogledajte LICENSE-APACHE i LICENSE-MIT za detalje.

# Contribution

Ako izričito ne navedete drugačije, bilo koji doprinos koji ste namjerno predali na uvrštavanje u `core_arch`, kako je definirano u licenci Apache-2.0, biće dvostruko licenciran kao gore, bez ikakvih dodatnih uslova ili odredbi.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












