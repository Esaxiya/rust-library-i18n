use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ali nije nula i kovarijantna.
///
/// To je često ispravno koristiti prilikom izgradnje struktura podataka koristeći sirove pokazivače, ali je u konačnici opasnije za upotrebu zbog njegovih dodatnih svojstava.Ako niste sigurni da li biste trebali koristiti `NonNull<T>`, samo upotrijebite `*mut T`!
///
/// Za razliku od `*mut T`, pokazivač uvijek mora biti ne-null, čak i ako pokazivač nikada nije dereferenciran.To je tako da enumi mogu koristiti ovu zabranjenu vrijednost kao diskriminant-`Option<NonNull<T>>` ima istu veličinu kao `* mut T`.
/// Međutim, pokazivač i dalje može visjeti ako nije dereferenciran.
///
/// Za razliku od `*mut T`, `NonNull<T>` je odabran za kovarijantu u odnosu na `T`.To omogućava upotrebu `NonNull<T>` prilikom izrade kovarijantnih tipova, ali uvodi rizik od nerazumljivosti ako se koristi u tipu koji zapravo ne bi trebao biti kovarijantni.
/// (Suprotan izbor je napravljen za `*mut T` iako je tehnički nerazumnost mogla nastati samo pozivanjem nesigurnih funkcija.)
///
/// Kovarijancija je ispravna za većinu sigurnih apstrakcija, kao što su `Box`, `Rc`, `Arc`, `Vec` i `LinkedList`.To je slučaj jer pružaju javni API koji slijedi uobičajena dijeljena XOR promjenjiva pravila Rust.
///
/// Ako vaš tip ne može sigurno biti kovarijantan, morate osigurati da sadrži neko dodatno polje za pružanje invarijantnosti.Često će ovo polje biti tipa [`PhantomData`] poput `PhantomData<Cell<T>>` ili `PhantomData<&'a mut T>`.
///
/// Primijetite da `NonNull<T>` ima instancu `From` za `&T`.Međutim, to ne mijenja činjenicu da je mutiranje kroz (pokazivač izveden iz a) zajedničke reference nedefinirano ponašanje, osim ako se mutacija dogodi unutar [`UnsafeCell<T>`].Isto vrijedi i za stvaranje promjenjive reference iz zajedničke reference.
///
/// Kada koristite ovu instancu `From` bez `UnsafeCell<T>`, vaša je odgovornost osigurati da se `as_mut` nikada ne pozove i da se `as_ptr` nikada ne koristi za mutaciju.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pokazivači nisu `Send` jer podaci na koje se pozivaju mogu biti aliasi.
// Napomena: ovaj impl je nepotreban, ali trebao bi pružiti bolje poruke o greškama.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pokazivači nisu `Sync` jer podaci na koje se pozivaju mogu biti aliasi.
// Napomena: ovaj impl je nepotreban, ali trebao bi pružiti bolje poruke o greškama.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Stvara novi `NonNull` koji je viseći, ali dobro usklađen.
    ///
    /// Ovo je korisno za inicijalizaciju tipova koji se lijeno dodjeljuju, kao što to čini `Vec::new`.
    ///
    /// Imajte na umu da vrijednost pokazivača može potencijalno predstavljati valjani pokazivač na `T`, što znači da se to ne smije koristiti kao vrijednost sentinela "not yet initialized".
    /// Tipovi koji se lijeno dodjeljuju moraju pratiti inicijalizaciju na neki drugi način.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURNOST: mem::align_of() vraća veličinu koja nije nula i koja se zatim lijeva
        // u * mut T.
        // Stoga `ptr` nije ništavan i poštuju se uvjeti za pozivanje new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Vraća zajedničke reference na vrijednost.Za razliku od [`as_ref`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// Za promjenjivi primjerak pogledajte [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definisanom u [the module documentation].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///
    ///   Konkretno, za vrijeme ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za referencu.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Vraća jedinstvene reference na vrijednost.Za razliku od [`as_mut`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// Za zajednički kolegu pogledajte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definisanom u [the module documentation].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///
    ///   Konkretno, tokom trajanja ovog životnog vijeka, memoriji na koju pokazuje pokazivač ne smije se pristupiti (čitati ili pisati) preko bilo kojeg drugog pokazivača.
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za referencu.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Stvara novi `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti ne-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURNOST: pozivatelj mora jamčiti da `ptr` nije null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Stvara novi `NonNull` ako `ptr` nije null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURNOST: Pokazivač je već provjeren i nije null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Izvodi istu funkcionalnost kao [`std::ptr::from_raw_parts`], osim što se vraća pokazivač `NonNull`, za razliku od sirovog `*const` pokazivača.
    ///
    ///
    /// Pogledajte dokumentaciju [`std::ptr::from_raw_parts`] za više detalja.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIGURNOST: Rezultat `ptr::from::raw_parts_mut` nije nula jer `data_address` jest.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Razložite (moguće široki) pokazivač na komponente adrese i metapodataka.
    ///
    /// Pokazivač se kasnije može rekonstruisati sa [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Nabavlja osnovni pokazivač `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Vraća zajedničku referencu na vrijednost.Ako se vrijednost može neinicijalizirati, umjesto nje mora se koristiti [`as_uninit_ref`].
    ///
    /// Za promjenjivi primjerak pogledajte [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definisanom u [the module documentation].
    ///
    /// * Pokazivač mora ukazivati na inicijaliziranu instancu `T`.
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///
    ///   Konkretno, za vrijeme ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    /// (Dio o inicijalizaciji još nije u potpunosti odlučen, ali dok nije, jedini siguran pristup je osigurati da oni zaista budu inicijalizirani.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za referencu.
        unsafe { &*self.as_ptr() }
    }

    /// Vraća jedinstvenu referencu na vrijednost.Ako se vrijednost može neinicijalizirati, umjesto nje mora se koristiti [`as_uninit_mut`].
    ///
    /// Za zajednički kolegu pogledajte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti pravilno poravnat.
    ///
    /// * To mora biti "dereferencable" u smislu definisanom u [the module documentation].
    ///
    /// * Pokazivač mora ukazivati na inicijaliziranu instancu `T`.
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///
    ///   Konkretno, tokom trajanja ovog životnog vijeka, memoriji na koju pokazuje pokazivač ne smije se pristupiti (čitati ili pisati) preko bilo kojeg drugog pokazivača.
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    /// (Dio o inicijalizaciji još nije u potpunosti odlučen, ali dok nije, jedini siguran pristup je osigurati da oni zaista budu inicijalizirani.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za promjenjivu referencu.
        unsafe { &mut *self.as_ptr() }
    }

    /// Emitira pokazivač drugog tipa.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIGURNOST: `self` je pokazivač `NonNull` koji nužno nije null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Stvara ne-null sirovi presjek od tankog pokazivača i dužine.
    ///
    /// Argument `len` je broj **elemenata**, a ne broj bajtova.
    ///
    /// Ova je funkcija sigurna, ali preusmjeravanje povratne vrijednosti nije sigurno.
    /// Pogledajte dokumentaciju [`slice::from_raw_parts`] za sigurnosne zahtjeve za rezanje.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // kreirajte presjek pokazivača kada započinjete s pokazivačem na prvi element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Imajte na umu da ovaj primjer umjetno pokazuje upotrebu ove metode, ali `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIGURNOST: `data` je pokazivač `NonNull` koji nužno nije null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Daje dužinu ne-null sirovog kriška.
    ///
    /// Vraćena vrijednost je broj **elemenata**, a ne broj bajtova.
    ///
    /// Ova je funkcija sigurna, čak i kad ne-null sirovi presjek ne može biti preusmjeren na presjek jer pokazivač nema valjanu adresu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Vraća ne null pokazivač na međuspremnik presjeka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIGURNOST: Znamo da `self` nije null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Vraća sirovi pokazivač na međuspremnik presjeka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Vraća zajedničku referencu na dio moguće neinicijaliziranih vrijednosti.Za razliku od [`as_ref`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// Za promjenjivi primjerak pogledajte [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti [valid] za čitanje za `ptr.len() * mem::size_of::<T>()` mnogo bajtova i mora biti pravilno poravnan.To posebno znači:
    ///
    ///     * Čitav opseg memorije ove kriške mora biti sadržan u jednom dodijeljenom objektu!
    ///       Kriške se nikada ne mogu proširiti na više dodijeljenih objekata.
    ///
    ///     * Pokazivač mora biti poravnat čak i za kriške nulte dužine.
    ///     Jedan od razloga za to je taj što se optimizacije rasporeda nabrajanja mogu oslanjati na poravnanje referenci (uključujući kriške bilo koje duljine) i one koje nisu nule kako bi se razlikovale od ostalih podataka.
    ///
    ///     Pomoću [`NonNull::dangling()`] možete dobiti pokazivač koji je upotrebljiv kao `data` za kriške nulte dužine.
    ///
    /// * Ukupna veličina kriška `ptr.len() * mem::size_of::<T>()` ne smije biti veća od `isize::MAX`.
    ///   Pogledajte sigurnosnu dokumentaciju za [`pointer::offset`].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///   Konkretno, za vrijeme ovog životnog vijeka, memorija na koju pokazuje pokazivač ne smije biti mutirana (osim unutar `UnsafeCell`).
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// Pogledajte takođe [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Vraća jedinstvenu referencu na dio moguće neinicijaliziranih vrijednosti.Za razliku od [`as_mut`], ovo ne zahtijeva da vrijednost mora biti inicijalizirana.
    ///
    /// Za zajednički kolegu pogledajte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Kada pozivate ovu metodu, morate osigurati da je sve slijedeće tačno:
    ///
    /// * Pokazivač mora biti [valid] za čitanje i pisanje za mnogo bajtova `ptr.len() * mem::size_of::<T>()` i mora biti pravilno poravnan.To posebno znači:
    ///
    ///     * Čitav opseg memorije ove kriške mora biti sadržan u jednom dodijeljenom objektu!
    ///       Kriške se nikada ne mogu proširiti na više dodijeljenih objekata.
    ///
    ///     * Pokazivač mora biti poravnat čak i za kriške nulte dužine.
    ///     Jedan od razloga za to je taj što se optimizacije rasporeda nabrajanja mogu oslanjati na poravnanje referenci (uključujući kriške bilo koje duljine) i one koje nisu nule kako bi se razlikovale od ostalih podataka.
    ///
    ///     Pomoću [`NonNull::dangling()`] možete dobiti pokazivač koji je upotrebljiv kao `data` za kriške nulte dužine.
    ///
    /// * Ukupna veličina kriška `ptr.len() * mem::size_of::<T>()` ne smije biti veća od `isize::MAX`.
    ///   Pogledajte sigurnosnu dokumentaciju za [`pointer::offset`].
    ///
    /// * Morate provesti Zaslanjajuća pravila Rust, jer je vraćeni vijek trajanja `'a` proizvoljno izabran i ne odražava nužno stvarni vijek trajanja podataka.
    ///   Konkretno, tokom trajanja ovog životnog vijeka, memoriji na koju pokazuje pokazivač ne smije se pristupiti (čitati ili pisati) preko bilo kojeg drugog pokazivača.
    ///
    /// Ovo vrijedi čak i ako je rezultat ove metode neiskorišten!
    ///
    /// Pogledajte takođe [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ovo je sigurno jer `memory` vrijedi za čitanje i pisanje za mnogo bajtova `memory.len()`.
    /// // Imajte na umu da pozivanje `memory.as_mut()` ovdje nije dozvoljeno jer se sadržaj može neinicijalizirati.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Vraća sirovi pokazivač na element ili podrezanu, bez provjere granica.
    ///
    /// Pozivanje ove metode s indeksom izvan granica ili kada `self` nije moguće preusmjeriti je *[nedefinirano ponašanje]* čak i ako se rezultirajući pokazivač ne koristi.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIGURNOST: pozivatelj osigurava da `self` nije moguće preusmjeriti i da je `index` u granicama.
        // Kao posljedica, rezultirajući pokazivač ne može biti NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIGURNOST: Jedinstveni pokazivač ne može biti nulan, pa su uslovi za
        // new_unchecked() se poštuju.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURNOST: Promjenjiva referenca ne može biti ništavna.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIGURNOST: Referenca ne može biti ništavna, pa su uslovi za
        // new_unchecked() se poštuju.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}