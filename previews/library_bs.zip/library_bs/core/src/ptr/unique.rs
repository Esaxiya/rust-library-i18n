use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Omotač oko sirovog ne-null `*mut T` koji ukazuje da je posjednik ovog omota vlasnik referenta.
/// Korisno za izgradnju apstrakcija poput `Box<T>`, `Vec<T>`, `String` i `HashMap<K, V>`.
///
/// Za razliku od `*mut T`, `Unique<T>` se ponaša kao "as if" da je bio primjerak `T`.
/// Primjenjuje `Send`/`Sync` ako je `T` `Send`/`Sync`.
/// To takođe podrazumijeva vrstu snažnog udruživanja koje garantuje instancu `T`:
/// referent pokazivača ne treba mijenjati bez jedinstvene putanje do njegovog posjedovanja Uniquea.
///
/// Ako niste sigurni je li ispravno koristiti `Unique` u svoje svrhe, razmislite o upotrebi `NonNull`, koji ima slabiju semantiku.
///
///
/// Za razliku od `*mut T`, pokazivač uvijek mora biti ne-null, čak i ako pokazivač nikada nije dereferenciran.
/// To je tako da enumi mogu koristiti ovu zabranjenu vrijednost kao diskriminant-`Option<Unique<T>>` ima istu veličinu kao `Unique<T>`.
/// Međutim, pokazivač i dalje može visjeti ako nije dereferenciran.
///
/// Za razliku od `*mut T`, `Unique<T>` je kovarijantan u odnosu na `T`.
/// Ovo bi uvijek trebalo biti tačno za bilo koji tip koji udovoljava jedinstvenim aliasing zahtjevima.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ovaj marker nema posljedica za varijance, ali je neophodan
    // da dropck shvati da logično posjedujemo `T`.
    //
    // Za detalje pogledajte:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pokazivači su `Send` ako je `T` `Send` jer su podaci na koje se pozivaju neomjereni.
/// Imajte na umu da ovaj nepromjenjivi invarijant nije prisiljen sistemom tipa;apstrakcija koja koristi `Unique` mora je provesti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pokazivači su `Sync` ako je `T` `Sync` jer su podaci na koje se pozivaju neomjereni.
/// Imajte na umu da ovaj nepromjenjivi invarijant nije prisiljen sistemom tipa;apstrakcija koja koristi `Unique` mora je provesti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Stvara novi `Unique` koji je viseći, ali dobro usklađen.
    ///
    /// Ovo je korisno za inicijalizaciju tipova koji se lijeno dodjeljuju, kao što to čini `Vec::new`.
    ///
    /// Imajte na umu da vrijednost pokazivača može potencijalno predstavljati valjani pokazivač na `T`, što znači da se to ne smije koristiti kao vrijednost sentinela "not yet initialized".
    /// Tipovi koji se lijeno dodjeljuju moraju pratiti inicijalizaciju na neki drugi način.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURNOST: mem::align_of() vraća važeći, ne null pokazivač.The
        // Stoga se poštuju uslovi za pozivanje new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Stvara novi `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti ne-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURNOST: pozivatelj mora jamčiti da `ptr` nije null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Stvara novi `Unique` ako `ptr` nije null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURNOST: Pokazivač je već provjeren i nije null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Nabavlja osnovni pokazivač `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Preusmjeravanje sadržaja.
    ///
    /// Rezultirajući životni vijek vezan je za sebe, pa se ovo ponaša "as if", zapravo je bila instanca T koja se posuđuje.
    /// Ako je potreban duži životni vijek (unbound), koristite `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za referencu.
        unsafe { &*self.as_ptr() }
    }

    /// Izmjenjiv dereferencira sadržaj.
    ///
    /// Rezultirajući životni vijek vezan je za sebe, pa se ovo ponaša "as if", zapravo je bila instanca T koja se posuđuje.
    /// Ako je potreban duži životni vijek (unbound), koristite `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURNOST: pozivatelj mora garantirati da `self` ispunjava sve
        // zahtjevi za promjenjivu referencu.
        unsafe { &mut *self.as_ptr() }
    }

    /// Emitira pokazivač drugog tipa.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIGURNOST: Unique::new_unchecked() stvara novu jedinstvenost i potrebe
        // zadati pokazivač da nije null.
        // Budući da prenosimo self kao pokazivač, on ne može biti null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURNOST: Promjenjiva referenca ne može biti ništavna
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}