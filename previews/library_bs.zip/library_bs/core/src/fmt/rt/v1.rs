//! Ovo je interni modul koji koristi ifmt!vrijeme izvođenja.Te se strukture emitiraju u statičke nizove u pretkompajlirane nizove formata prije vremena.
//!
//! Ove su definicije slične `ct` ekvivalentima, ali se razlikuju po tome što se mogu statički dodijeliti i malo su optimizirane za vrijeme izvođenja
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Moguća poravnanja koja se mogu zatražiti kao dio direktive o oblikovanju.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Oznaka da sadržaj treba poravnati lijevo.
    Left,
    /// Oznaka da sadržaj treba biti poravnat udesno.
    Right,
    /// Oznaka da sadržaj treba biti poravnat prema centru.
    Center,
    /// Nije zatraženo poravnanje.
    Unknown,
}

/// Koriste ga specifikatori [width](https://doc.rust-lang.org/std/fmt/#width) i [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Navedeno s doslovnim brojem, čuva vrijednost
    Is(usize),
    /// Navedeno korištenjem sintaksa `$` i `*`, indeks sprema u `args`
    Param(usize),
    /// Nije određeno
    Implied,
}