//! Suštinske karakteristike sastavljača.
//!
//! Odgovarajuće definicije su u `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Odgovarajuće const implementacije su u `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: o svim promjenama čvrstoće svojstava treba razgovarati s jezičkim timom.
//! To uključuje promjene u stabilnosti čvrstoće.
//!
//! Da bi se intrinzično učinilo upotrebljivim tokom vremena kompajliranja, potrebno je kopirati implementaciju iz <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> u `compiler/rustc_mir/src/interpret/intrinsics.rs` i dodati `#[rustc_const_unstable(feature = "foo", issue = "01234")]` u intrinsic.
//!
//!
//! Ako bi se intrinsic trebao koristiti iz `const fn` s atributom `rustc_const_stable`, atribut intrinsic također mora biti `rustc_const_stable`.
//! Takva promjena ne bi se trebala izvršiti bez konsultacija s T-langom, jer ona u jezik uvrštava značajku koja se ne može preslikati u korisnički kod bez podrške za kompajler.
//!
//! # Volatiles
//!
//! Hlapljive osobine pružaju operacije namijenjene djelovanju na memoriju I/O, za koje garancija neće biti da ih prerađivač preuređuje u druge hlapljive značajke.Pogledajte LLVM dokumentaciju o [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomske osobine pružaju uobičajene atomske operacije na mašinskim riječima, s više mogućih redoslijeda memorije.Oni se pokoravaju istoj semantici kao C++ 11.Pogledajte LLVM dokumentaciju o [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Brzo osvježavanje naručivanja memorije:
//!
//! * Steknite, prepreka za sticanje brave.Sljedeća čitanja i pisanja odvijaju se nakon barijere.
//! * Otpustite, prepreka za oslobađanje brave.Prethodno čitanje i pisanje odvija se prije barijere.
//! * Zajamčeno je da će se sekvencijalno dosljedne, sekvencijalno dosljedne operacije odvijati redom.Ovo je standardni način rada s atomskim tipovima i ekvivalentan je 0Java-ovom `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ovi uvozi se koriste za pojednostavljivanje intra-doc veza
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIGURNOST: vidi `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NAPOMENA, ovi suštinski uzimaju sirove pokazivače jer oni mutiraju alias memoriju, što ne vrijedi ni za `&` ni za `&mut`.
    //

    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::SeqCst`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::Acquire`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::Release`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::AcqRel`] kao `success` i [`Ordering::Acquire`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::Relaxed`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::SeqCst`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::SeqCst`] kao `success` i [`Ordering::Acquire`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::Acquire`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange` prosljeđivanjem [`Ordering::AcqRel`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::SeqCst`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::Acquire`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::Release`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::AcqRel`] kao `success` i [`Ordering::Acquire`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::Relaxed`] kao parametara `success` i `failure`.
    ///
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::SeqCst`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::SeqCst`] kao `success` i [`Ordering::Acquire`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::Acquire`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Pohranjuje vrijednost ako je trenutna vrijednost ista kao vrijednost `old`.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `compare_exchange_weak` prosljeđivanjem [`Ordering::AcqRel`] kao `success` i [`Ordering::Relaxed`] kao parametre `failure`.
    /// Na primjer, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Učitava trenutnu vrijednost pokazivača.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `load` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Učitava trenutnu vrijednost pokazivača.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `load` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Učitava trenutnu vrijednost pokazivača.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `load` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `store` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `store` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `store` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji, vraćajući staru vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `swap` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji, vraćajući staru vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `swap` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji, vraćajući staru vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `swap` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji, vraćajući staru vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `swap` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pohranjuje vrijednost na navedenoj memorijskoj lokaciji, vraćajući staru vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `swap` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dodaje trenutnoj vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_add` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje trenutnoj vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_add` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje trenutnoj vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_add` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje trenutnoj vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_add` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dodaje trenutnoj vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_add` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Oduzmi od trenutne vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_sub` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oduzmi od trenutne vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_sub` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oduzmi od trenutne vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_sub` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oduzmi od trenutne vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_sub` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Oduzmi od trenutne vrijednosti, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_sub` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitno i sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_and` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno i sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_and` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno i sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_and` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno i sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_and` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno i sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_and` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit-nand sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipu [`AtomicBool`] putem metode `fetch_nand` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipu [`AtomicBool`] putem metode `fetch_nand` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipu [`AtomicBool`] putem metode `fetch_nand` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipu [`AtomicBool`] putem metode `fetch_nand` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipu [`AtomicBool`] putem metode `fetch_nand` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitno ili sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_or` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ili sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_or` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ili sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_or` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ili sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_or` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ili sa trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_or` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitno xor s trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_xor` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_xor` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_xor` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_xor` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutnom vrijednošću, vraćajući prethodnu vrijednost.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na tipovima [`atomic`] putem metode `fetch_xor` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_max` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_max` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_max` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_max` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_max` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_min` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_min` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_min` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_min` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći potpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na cjelobrojnim vrstama s potpisom [`atomic`] putem metode `fetch_min` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_min` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_min` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_min` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_min` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_min` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_max` prosljeđivanjem [`Ordering::SeqCst`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_max` prosljeđivanjem [`Ordering::Acquire`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_max` prosljeđivanjem [`Ordering::Release`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_max` prosljeđivanjem [`Ordering::AcqRel`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimalno sa trenutnom vrijednošću koristeći nepotpisanu usporedbu.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je na [`atomic`] nepotpisanim cijelim brojevima putem metode `fetch_max` prosljeđivanjem [`Ordering::Relaxed`] kao `order`.
    /// Na primjer, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Intrinzični `prefetch` je nagovještaj generatoru koda za umetanje uputa za prethodno dohvaćanje ako je podržano;u suprotnom, to je ne-op.
    /// Prethodne preuzimanja nemaju utjecaja na ponašanje programa, ali mogu promijeniti njegove karakteristike izvedbe.
    ///
    /// Argument `locality` mora biti konstantni cijeli broj i specifikator je vremenskog lokaliteta u rasponu od (0), bez lokaliteta, do (3), izuzetno lokalno čuvanje u predmemoriji.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Intrinzični `prefetch` je nagovještaj generatoru koda za umetanje uputa za prethodno dohvaćanje ako je podržano;u suprotnom, to je ne-op.
    /// Prethodne preuzimanja nemaju utjecaja na ponašanje programa, ali mogu promijeniti njegove karakteristike izvedbe.
    ///
    /// Argument `locality` mora biti konstantni cijeli broj i specifikator je vremenskog lokaliteta u rasponu od (0), bez lokaliteta, do (3), izuzetno lokalno čuvanje u predmemoriji.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Intrinzični `prefetch` je nagovještaj generatoru koda za umetanje uputa za prethodno dohvaćanje ako je podržano;u suprotnom, to je ne-op.
    /// Prethodne preuzimanja nemaju utjecaja na ponašanje programa, ali mogu promijeniti njegove karakteristike izvedbe.
    ///
    /// Argument `locality` mora biti konstantni cijeli broj i specifikator je vremenskog lokaliteta u rasponu od (0), bez lokaliteta, do (3), izuzetno lokalno čuvanje u predmemoriji.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Intrinzični `prefetch` je nagovještaj generatoru koda za umetanje uputa za prethodno dohvaćanje ako je podržano;u suprotnom, to je ne-op.
    /// Prethodne preuzimanja nemaju utjecaja na ponašanje programa, ali mogu promijeniti njegove karakteristike izvedbe.
    ///
    /// Argument `locality` mora biti konstantni cijeli broj i specifikator je vremenskog lokaliteta u rasponu od (0), bez lokaliteta, do (3), izuzetno lokalno čuvanje u predmemoriji.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomska ograda.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::fence`] dodavanjem [`Ordering::SeqCst`] kao `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atomska ograda.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::fence`] dodavanjem [`Ordering::Acquire`] kao `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomska ograda.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::fence`] dodavanjem [`Ordering::Release`] kao `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomska ograda.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::fence`] dodavanjem [`Ordering::AcqRel`] kao `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Memorijska barijera samo za kompajler.
    ///
    /// Pristup memoriji kompajler nikada neće preurediti preko ove barijere, ali za to neće biti izdane upute.
    /// Ovo je prikladno za operacije na istoj niti koja može biti unaprijed preuzeta, na primjer kada se komunicira s upravljačima signalima.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::compiler_fence`] dodavanjem [`Ordering::SeqCst`] kao `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Memorijska barijera samo za kompajler.
    ///
    /// Pristup memoriji kompajler nikada neće preurediti preko ove barijere, ali za to neće biti izdane upute.
    /// Ovo je prikladno za operacije na istoj niti koja može biti unaprijed preuzeta, na primjer kada se komunicira s upravljačima signalima.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::compiler_fence`] dodavanjem [`Ordering::Acquire`] kao `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Memorijska barijera samo za kompajler.
    ///
    /// Pristup memoriji kompajler nikada neće preurediti preko ove barijere, ali za to neće biti izdane upute.
    /// Ovo je prikladno za operacije na istoj niti koja može biti unaprijed preuzeta, na primjer kada se komunicira s upravljačima signalima.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::compiler_fence`] dodavanjem [`Ordering::Release`] kao `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Memorijska barijera samo za kompajler.
    ///
    /// Pristup memoriji kompajler nikada neće preurediti preko ove barijere, ali za to neće biti izdane upute.
    /// Ovo je prikladno za operacije na istoj niti koja može biti unaprijed preuzeta, na primjer kada se komunicira s upravljačima signalima.
    ///
    /// Stabilizirana verzija ovog intrinzika dostupna je u [`atomic::compiler_fence`] dodavanjem [`Ordering::AcqRel`] kao `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Čarobna priroda koja svoje značenje izvodi iz atributa vezanih uz funkciju.
    ///
    /// Na primjer, protok podataka koristi ovo za ubrizgavanje statičkih tvrdnji, tako da bi `rustc_peek(potentially_uninitialized)` zapravo dvaput provjerio da li je tok podataka zaista izračunao da je u toj točki kontrolnog toka neinicijaliziran.
    ///
    ///
    /// Ovaj se svojstveni ne smije koristiti izvan kompajlera.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Prekida izvršenje procesa.
    ///
    /// Korisniku jednostavnija i stabilnija verzija ove operacije je [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Obavještava optimizator da ova točka u kodu nije dostupna, omogućavajući daljnje optimizacije.
    ///
    /// NAPOMENA, ovo se vrlo razlikuje od `unreachable!()` makronaredbe: Za razliku od makronaredbe, koja se panics izvršava, postizanje koda označenog ovom funkcijom je *nedefinirano ponašanje*.
    ///
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Obavještava optimizator da je uvjet uvijek istinit.
    /// Ako je uvjet netačan, ponašanje je nedefinirano.
    ///
    /// Ne generira se kôd za ovaj svojstveni, ali optimizator će ga pokušati sačuvati (i njegovo stanje) između prolaza, što može ometati optimizaciju okolnog koda i smanjiti performanse.
    /// Ne smije se koristiti ako optimizator može samostalno otkriti invarijant ili ako ne omogućava značajnije optimizacije.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Savjetuje prevoditelju da je uvjet branch vjerojatno istinit.
    /// Vraća vrijednost koja mu je proslijeđena.
    ///
    /// Bilo koja druga upotreba osim sa `if` izrazima vjerovatno neće imati učinka.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Nagovještava kompajleru da je uvjet branch vjerojatno netačan.
    /// Vraća vrijednost koja mu je proslijeđena.
    ///
    /// Bilo koja druga upotreba osim sa `if` izrazima vjerovatno neće imati učinka.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Izvršava zamku točke prekida za inspekciju pomoću programa za otklanjanje pogrešaka.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn breakpoint();

    /// Veličina tipa u bajtovima.
    ///
    /// Preciznije, ovo je pomak u bajtovima između uzastopnih stavki istog tipa, uključujući dodavanje poravnanja.
    ///
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimalno poravnanje tipa.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Preferirano poravnanje tipa.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Veličina referencirane vrijednosti u bajtovima.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Potrebno poravnanje referencirane vrijednosti.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Dobiva statički srez niza koji sadrži ime tipa.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Dobiva identifikator koji je globalno jedinstven za navedeni tip.
    /// Ova funkcija vratit će istu vrijednost za tip bez obzira na to koji se crate poziva.
    ///
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Zaštita za nesigurne funkcije koje se nikada ne mogu izvršiti ako je `T` nenaseljen:
    /// Ovo će statički ili panic, ili ne učiniti ništa.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Zaštita za nesigurne funkcije koje se nikada neće moći izvršiti ako `T` ne dozvoljava nulu-inicijalizaciju: Ovo će statički ili panic, ili neće učiniti ništa.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn assert_zero_valid<T>();

    /// Zaštita za nesigurne funkcije koje se nikada neće moći izvršiti ako `T` ima nevaljane bitske obrasce: Ovo će statički ili panic ili ne učiniti ništa.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn assert_uninit_valid<T>();

    /// Dobiva referencu na statički `Location` koji pokazuje gdje je pozvan.
    ///
    /// Razmislite o upotrebi [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Premješta vrijednost izvan opsega bez ispuštanja ljepila.
    ///
    /// Ovo postoji isključivo za [`mem::forget_unsized`];normalni `forget` umjesto toga koristi `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Ponovno tumači bitove vrijednosti jednog tipa kao drugi tip.
    ///
    /// Obje vrste moraju imati jednaku veličinu.
    /// Ni original, ni rezultat možda nisu [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` je semantički ekvivalent bitnom premještanju jedne vrste u drugu.Kopira bitove iz izvorne vrijednosti u odredišnu vrijednost, a zatim zaboravlja original.
    /// Ekvivalentno je C-ovom `memcpy` ispod haube, baš kao i `transmute_copy`.
    ///
    /// Budući da je `transmute` operacija vrijednosti, poravnanje *samih transmutiranih vrijednosti* nije problem.
    /// Kao i kod bilo koje druge funkcije, kompajler već osigurava da su i `T` i `U` pravilno poravnati.
    /// Međutim, prilikom transmutovanja vrijednosti koje *usmjeravaju drugdje*(poput pokazivača, referenci, okvira ...), pozivatelj mora osigurati pravilno poravnanje usmjerenih vrijednosti.
    ///
    /// `transmute` je **nevjerovatno** nesigurno.Postoji ogroman broj načina za uzrokovanje [undefined behavior][ub] pomoću ove funkcije.`transmute` bi trebao biti krajnje utočište.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ima dodatnu dokumentaciju.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Postoji nekoliko stvari za koje je `transmute` zaista koristan.
    ///
    /// Pretvaranje pokazivača u pokazivač funkcije.Ovo *nije* prenosivo na strojeve gdje pokazivači funkcija i pokazivači podataka imaju različite veličine.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Produljenje životnog vijeka ili skraćivanje nepromjenjivog vijeka trajanja.Ovo je napredni, vrlo nesigurni Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ne očajavajte: mnoge se upotrebe `transmute` mogu postići na druge načine.
    /// Ispod su uobičajene aplikacije `transmute` koje se mogu zamijeniti sigurnijim konstrukcijama.
    ///
    /// Pretvaranje sirovog bytes(`&[u8]`) u `u32`, `f64` itd.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // umjesto toga koristite `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ili koristite `u32::from_le_bytes` ili `u32::from_be_bytes` da odredite endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Pretvaranje pokazivača u `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Umesto toga koristite `as` cast
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Pretvaranje `*mut T` u `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Umjesto toga upotrijebite ponovno zaduživanje
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Pretvaranje `&mut T` u `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sada, sastavite `as` i ponovite pozajmicu, imajte na umu da lanci `as` `as` nisu tranzitivni
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Pretvaranje `&str` u `&[u8]`:
    ///
    /// ```
    /// // ovo nije dobar način za to.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Možete koristiti `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ili, jednostavno upotrijebite bajtni niz, ako imate kontrolu nad literalnim nizom
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Pretvaranje `Vec<&T>` u `Vec<Option<&T>>`.
    ///
    /// Da biste transformirali unutarnji tip sadržaja spremnika, morate paziti da ne kršite nijedan od invarijanata spremnika.
    /// Za `Vec` to znači da se i veličina *i poravnanje* unutrašnjih tipova moraju podudarati.
    /// Ostali spremnici mogu se osloniti na veličinu tipa, poravnanje ili čak `TypeId`, u tom slučaju prenamjena uopće ne bi bila moguća bez kršenja invarijanta spremnika.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonirajte vector jer ćemo ih kasnije ponovo koristiti
    /// let v_clone = v_orig.clone();
    ///
    /// // Korištenje transmutacije: ovo se oslanja na nespecificirani raspored podataka `Vec`, što je loša ideja i moglo bi prouzročiti nedefinirano ponašanje.
    /////
    /// // Međutim, nije kopiranje.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ovo je predloženi, siguran način.
    /// // Ipak kopira cijeli vector u novi niz.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ovo je ispravan način kopiranja, koji nije siguran, "transmuting" i `Vec`, bez oslanjanja na raspored podataka.
    /// // Umjesto da doslovno zovemo `transmute`, izvodimo pokazivanje pokazivača, ali u smislu pretvaranja originalnog unutrašnjeg tipa (`&i32`) u novi (`Option<&i32>`), ovo ima ista upozorenja.
    /////
    /// // Pored gore navedenih informacija, pogledajte i dokumentaciju [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ažurirajte ovo kada se vec_into_raw_parts stabilizira.
    ///     // Osigurajte da originalni vector nije ispušten.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementacija `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // To možete učiniti na više načina, a na sljedeći način (transmute) postoji više problema.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // prvo: transmutacija nije sigurna za tip;sve što provjerava je da su T i
    ///         // U su iste veličine.
    ///         // Drugo, upravo ovdje, imate dvije izmjenjive reference koje upućuju na istu memoriju.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ovo se rješava problema sa sigurnošću tipa;`&mut *` će vam* dati *samo `&mut T` od `&mut T` ili `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // međutim, još uvijek imate dvije izmjenjive reference koje upućuju na istu memoriju.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tako to radi standardna biblioteka.
    /// // Ovo je najbolja metoda ako trebate učiniti nešto poput ovoga
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ovo sada ima tri promjenjive reference koje upućuju na istu memoriju.`slice`, rvalue ret.0 i rvalue ret.1.
    ///         // `slice` nikada se ne koristi nakon `let ptr = ...`, pa ga tako možemo tretirati kao "dead", pa prema tome imate samo dvije prave promjenjive kriške.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Iako ovo čini unutarnji const stabilnim, u const fn imamo neki prilagođeni kod
    // provjere koje sprečavaju njegovu upotrebu unutar `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Vraća `true` ako stvarni tip naveden kao `T` zahtijeva kap ljepilo;vraća `false` ako stvarni tip predviđen za `T` implementira `Copy`.
    ///
    ///
    /// Ako stvarni tip ne zahtijeva ljepilo za kapanje niti primjenjuje `Copy`, tada je povratna vrijednost ove funkcije neodređena.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Izračunava pomak od pokazivača.
    ///
    /// Ovo se implementira kao suštinsko kako bi se izbjeglo pretvaranje u i iz cijelog broja, jer bi pretvorba bacila zamjenske informacije.
    ///
    /// # Safety
    ///
    /// Početni i rezultirajući pokazivač moraju biti u granicama ili jedan bajt iza kraja dodijeljenog objekta.
    /// Ako je bilo koji pokazivač izvan granica ili se dogodi aritmetičko prelijevanje, svaka daljnja upotreba vraćene vrijednosti rezultirat će nedefiniranim ponašanjem.
    ///
    ///
    /// Stabilizirana verzija ovog suštinskog je [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Izračunava pomak od pokazivača, potencijalno zamotavajući.
    ///
    /// Ovo se implementira kao svojstveno kako bi se izbjeglo pretvaranje u i iz cijelog broja, jer pretvorba inhibira određene optimizacije.
    ///
    /// # Safety
    ///
    /// Za razliku od `offset` intrinsic, ovaj intrinzik ne ograničava rezultirajući pokazivač da upućuje na jedan bajt ili kraj bajta dodijeljenog objekta i obavija se aritmetikom komplementa.
    /// Dobivena vrijednost nije nužno valjana da bi se koristila za stvarni pristup memoriji.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekvivalentno odgovarajućem unutrašnjem `llvm.memcpy.p0i8.0i8.*`, veličine `count`*`size_of::<T>()` i poravnanjem
    ///
    /// `min_align_of::<T>()`
    ///
    /// Hlapljivi parametar postavljen je na `true`, tako da neće biti optimiziran ako veličina nije jednaka nuli.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalentno odgovarajućem unutrašnjem `llvm.memmove.p0i8.0i8.*`, veličine `count* size_of::<T>()` i poravnanja od
    ///
    /// `min_align_of::<T>()`
    ///
    /// Hlapljivi parametar postavljen je na `true`, tako da neće biti optimiziran ako veličina nije jednaka nuli.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalentan odgovarajućem unutrašnjem `llvm.memset.p0i8.*`, veličine `count* size_of::<T>()` i poravnanja `min_align_of::<T>()`.
    ///
    ///
    /// Hlapljivi parametar postavljen je na `true`, tako da neće biti optimiziran ako veličina nije jednaka nuli.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Izvodi hlapljivo opterećenje iz pokazivača `src`.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Izvodi hlapljivo skladište na pokazivač `dst`.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Izvodi hlapljivo opterećenje iz pokazivača `src` Pokazivač nije potreban za poravnanje.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Izvodi hlapljivo skladište na pokazivač `dst`.
    /// Pokazivač nije potrebno poravnati.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Daje kvadratni korijen `f32`
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Daje kvadratni korijen `f64`
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Podiže `f32` do cjelobrojne snage.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Podiže `f64` do cjelobrojne snage.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Daje sinus `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Daje sinus `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Daje kosinus `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Daje kosinus `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Podiže `f32` do snage `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Podiže `f64` do snage `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Daje eksponencijal `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Daje eksponencijal `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Povratak 2 podignut na snagu `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Povratak 2 podignut na snagu `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Daje prirodni logaritam `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Daje prirodni logaritam `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Daje osnovni 10 logaritam `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Daje osnovni 10 logaritam `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Daje osnovni 2 logaritam `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Daje osnovni 2 logaritam `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Vraća `a * b + c` za vrijednosti `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Vraća `a * b + c` za vrijednosti `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Daje apsolutnu vrijednost `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Daje apsolutnu vrijednost `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Vraća najmanje dvije `f32` vrijednosti.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Vraća najmanje dvije `f64` vrijednosti.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Vraća najviše dvije `f32` vrijednosti.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Vraća najviše dvije `f64` vrijednosti.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopira znak od `y` do `x` za vrijednosti `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopira znak od `y` do `x` za vrijednosti `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Daje najveći cijeli broj manji ili jednak `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Daje najveći cijeli broj manji ili jednak `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Daje najmanji cijeli broj veći od ili jednak `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Daje najmanji cijeli broj veći od ili jednak `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Daje cjelobrojni dio `f32`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Daje cjelobrojni dio `f64`.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Daje najbliži cijeli broj `f32`.
    /// Može stvoriti netačan izuzetak s pomičnom zarezom ako argument nije cijeli broj.
    pub fn rintf32(x: f32) -> f32;
    /// Daje najbliži cijeli broj `f64`.
    /// Može stvoriti netačan izuzetak s pomičnom zarezom ako argument nije cijeli broj.
    pub fn rintf64(x: f64) -> f64;

    /// Daje najbliži cijeli broj `f32`.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Daje najbliži cijeli broj `f64`.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Daje najbliži cijeli broj `f32`.Zaokružuje slučajeve na pola puta od nule.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Vraća najbliži cijeli broj `f64`.Zaokružuje slučajeve na pola puta od nule.
    ///
    /// Stabilizirana verzija ovog suštinskog je
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Dodatak plutajućeg slova koji omogućuje optimizacije na osnovu algebarskih pravila.
    /// Može se pretpostaviti da su unosi konačni.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Oduzimanje plutajućeg slova koje omogućava optimizacije na osnovu algebarskih pravila.
    /// Može se pretpostaviti da su unosi konačni.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Množenje plutajućeg slova koje omogućuje optimizacije na osnovu algebarskih pravila.
    /// Može se pretpostaviti da su unosi konačni.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Plutajuća podjela koja omogućuje optimizacije na temelju algebarskih pravila.
    /// Može se pretpostaviti da su unosi konačni.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float ostatak koji omogućava optimizacije na osnovu algebarskih pravila.
    /// Može se pretpostaviti da su unosi konačni.
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Pretvorite sa LLVM-ovim fptoui/fptosi, koji može vratiti undef za vrijednosti izvan opsega
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizirani kao [`f32::to_int_unchecked`] i [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Vraća broj bitova postavljenih u cjelobrojni tip `T`
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `count_ones`.
    /// Na primjer,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Vraća broj vodećih nebitnih bitova (zeroes) u cjelovitom tipu `T`.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `leading_zeros`.
    /// Na primjer,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` s vrijednošću `0` vratit će bitnu širinu `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Poput `ctlz`, ali izuzetno nesigurno jer vraća `undef` kada mu se da `x` s vrijednošću `0`.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Vraća broj pratećih nepostavljenih bitova (zeroes) u cjelobrojnom tipu `T`.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `trailing_zeros`.
    /// Na primjer,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` s vrijednošću `0` vratit će bitnu širinu `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Poput `cttz`, ali izuzetno nesigurno jer vraća `undef` kada mu se da `x` s vrijednošću `0`.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Obrne bajtove u cijelom broju `T`.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `swap_bytes`.
    /// Na primjer,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Obrne bitove u cjelobrojnom tipu `T`.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `reverse_bits`.
    /// Na primjer,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Obavlja provjereno sabiranje cijelih brojeva.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `overflowing_add`.
    /// Na primjer,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvodi provjereno oduzimanje cijelog broja
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `overflowing_sub`.
    /// Na primjer,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvodi provjereno množenje cjelobrojnih vrijednosti
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `overflowing_mul`.
    /// Na primjer,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvodi tačnu podjelu, što rezultira nedefiniranim ponašanjem tamo gdje je `x % y != 0` ili `y == 0` ili `x == T::MIN && y == -1`
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Izvodi nekontroliranu podjelu, što rezultira nedefiniranim ponašanjem tamo gdje je `y == 0` ili `x == T::MIN && y == -1`
    ///
    ///
    /// Sigurni omoti za ovaj suštinski dostupni su na celobrojnim primitivima putem metode `checked_div`.
    /// Na primjer,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Vraća ostatak neprovjerene podjele, što rezultira nedefiniranim ponašanjem kada je `y == 0` ili `x == T::MIN && y == -1`
    ///
    ///
    /// Sigurni omoti za ovaj suštinski dostupni su na celobrojnim primitivima putem metode `checked_rem`.
    /// Na primjer,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Izvodi nekontrolirani pomak ulijevo, što rezultira nedefiniranim ponašanjem kada `y < 0` ili `y >= N`, gdje je N širina T u bitovima.
    ///
    ///
    /// Sigurni omoti za ovaj suštinski dostupni su na celobrojnim primitivima putem metode `checked_shl`.
    /// Na primjer,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Izvodi nekontrolirani pomak udesno, što rezultira nedefiniranim ponašanjem kada je `y < 0` ili `y >= N`, gdje je N širina T u bitovima.
    ///
    ///
    /// Sigurni omoti za ovaj suštinski dostupni su na celobrojnim primitivima putem metode `checked_shr`.
    /// Na primjer,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Vraća rezultat neprovjerenog dodavanja, što rezultira nedefiniranim ponašanjem kada je `x + y > T::MAX` ili `x + y < T::MIN`.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Daje rezultat neprovjerenog oduzimanja, što rezultira nedefiniranim ponašanjem kada je `x - y > T::MAX` ili `x - y < T::MIN`.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Daje rezultat neprovjerenog množenja, što rezultira nedefiniranim ponašanjem kada je `x *y > T::MAX` ili `x* y < T::MIN`.
    ///
    ///
    /// Ova suštinska karakteristika nema stabilnog pandana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Izvodi rotaciju ulijevo.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `rotate_left`.
    /// Na primjer,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Izvodi rotaciju udesno.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `rotate_right`.
    /// Na primjer,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Vraća (a + b) mod 2 <sup>N</sup>, gdje je N širina T u bitovima.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `wrapping_add`.
    /// Na primjer,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Vraća (a, b) mod 2 <sup>N</sup>, gdje je N širina T u bitovima.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `wrapping_sub`.
    /// Na primjer,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Vraća (a * b) mod 2 <sup>N</sup>, gdje je N širina T u bitovima.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `wrapping_mul`.
    /// Na primjer,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Izračunava `a + b`, zasićujući u numeričkim granicama.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `saturating_add`.
    /// Na primjer,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Izračunava `a - b`, zasićujući u numeričkim granicama.
    ///
    /// Stabilizirane verzije ovog intrinzika dostupne su na primesima cijelih brojeva metodom `saturating_sub`.
    /// Na primjer,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Vraća vrijednost diskriminanta za varijantu u 'v';
    /// ako `T` nema diskriminanta, vraća `0`.
    ///
    /// Stabilizirana verzija ovog suštinskog elementa je [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Vraća broj varijanti tipa `T` cast na `usize`;
    /// ako `T` nema varijanti, vraća `0`.Nenaseljene varijante će se računati.
    ///
    /// Verzija ovog bitnog elementa koja će se stabilizirati je [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust-ova "try catch" konstrukcija koja poziva pokazivač funkcije `try_fn` s pokazivačem podataka `data`.
    ///
    /// Treći argument je funkcija koja se poziva ako se dogodi panic.
    /// Ova funkcija uzima pokazivač podataka i pokazivač na ciljni objekt iznimke koji je uhvaćen.
    ///
    /// Za više informacija pogledajte izvor kompajlera kao i implementaciju catch-a std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emitira `!nontemporal` trgovinu prema LLVM (pogledajte njihove dokumente).
    /// Vjerovatno nikada neće postati stabilna.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Za detalje pogledajte dokumentaciju `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Za detalje pogledajte dokumentaciju `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Za detalje pogledajte dokumentaciju `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Dodijeliti u vrijeme sastavljanja.Ne bi trebalo da se zove tokom izvođenja.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Neke su funkcije ovdje definirane jer su slučajno dostupne u ovom modulu na stabilnom.
// Pogledajte <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` također spada u ovu kategoriju, ali se ne može zamotati zbog provjere da li `T` i `U` imaju istu veličinu.)
//

/// Provjerava je li `ptr` pravilno poravnan u odnosu na `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopira `count *size_of::<T>()` bajtove iz `src` u `dst`.Izvor i odredište ne smiju se* preklapati.
///
/// Za područja memorije koja se mogu preklapati, umjesto toga koristite [`copy`].
///
/// `copy_nonoverlapping` je semantički ekvivalent C-ovom [`memcpy`], ali s razmijenjenim redoslijedom argumenata.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uslova:
///
/// * `src` mora biti [valid] za čitanje `count * size_of::<T>()` bajtova.
///
/// * `dst` mora biti [valid] za upisivanje bajtova `count * size_of::<T>()`.
///
/// * I `src` i `dst` moraju biti pravilno poravnati.
///
/// * Područje memorije koja počinje na `src` s veličinom `count *
///   veličina_: :<T>() `bajtovi se ne smiju *ne* preklapati s područjem memorije koja počinje na `dst` iste veličine.
///
/// Kao i [`read`], `copy_nonoverlapping` stvara bitnu kopiju `T`, bez obzira da li je `T` [`Copy`].
/// Ako `T` nije [`Copy`], koristeći *i* vrijednosti u regiji koja počinje na `*src` i regiji koja počinje na `* dst` mogu [violate memory safety][read-ownership].
///
///
/// Imajte na umu da čak i ako efektivno kopirana veličina (`count * size_of: :<T>()`) je `0`, pokazivači moraju biti NULL i pravilno poravnati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ručno implementirajte [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Premješta sve elemente `src` u `dst`, ostavljajući `src` praznim.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Osigurajte da `dst` ima dovoljno kapaciteta da primi cijeli `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Poziv na offset je uvijek siguran jer `Vec` nikada neće dodijeliti više od `isize::MAX` bajtova.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Skratite `src` bez ispuštanja njegovog sadržaja.
///         // To radimo prvo, kako bismo izbjegli probleme u slučaju da se dogodi nešto dalje od panics.
///         src.set_len(0);
///
///         // Dvije se regije ne mogu preklapati jer se promjenjive reference ne zamjenjuju, a dva različita vectors ne mogu posjedovati istu memoriju.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Obavijestite `dst` da sada sadrži sadržaj `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Izvršite ove provjere samo u vrijeme izvođenja
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Bez panike kako bi utjecaj kodegena bio manji.
        abort();
    }*/

    // SIGURNOST: mora biti ugovor o sigurnosti za `copy_nonoverlapping`
    // podržava pozivalac.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopira `count * size_of::<T>()` bajtove iz `src` u `dst`.Izvor i odredište mogu se preklapati.
///
/// Ako se izvor i odredište *nikada* neće preklapati, umjesto toga se može koristiti [`copy_nonoverlapping`].
///
/// `copy` je semantički ekvivalent C-ovom [`memmove`], ali s razmjenom argumenata.
/// Kopiranje se odvija kao da su bajtovi kopirani iz `src` u privremeni niz, a zatim kopirani iz niza u `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uslova:
///
/// * `src` mora biti [valid] za čitanje `count * size_of::<T>()` bajtova.
///
/// * `dst` mora biti [valid] za upisivanje bajtova `count * size_of::<T>()`.
///
/// * I `src` i `dst` moraju biti pravilno poravnati.
///
/// Kao i [`read`], `copy` stvara bitnu kopiju `T`, bez obzira da li je `T` [`Copy`].
/// Ako `T` nije [`Copy`], koristeći vrijednosti u regiji koja počinje na `*src` i regiji koja počinje na `* dst` može [violate memory safety][read-ownership].
///
///
/// Imajte na umu da čak i ako efektivno kopirana veličina (`count * size_of: :<T>()`) je `0`, pokazivači moraju biti NULL i pravilno poravnati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Učinkovito stvorite Rust vector od nesigurnog međuspremnika:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` mora biti pravilno poravnan za svoj tip i nije nula.
/// /// * `ptr` mora vrijediti za čitanje `elts` susjednih elemenata tipa `T`.
/// /// * Ti se elementi ne smiju koristiti nakon poziva ove funkcije, osim ako je `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIGURNOST: Naš preduvjet osigurava da je izvor poravnat i valjan,
///     // i `Vec::with_capacity` osigurava da imamo korisni prostor za njihovo pisanje.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // BEZBEDNOST: Stvorili smo ga sa toliko kapaciteta ranije,
///     // a prethodni `copy` je inicijalizirao ove elemente.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Izvršite ove provjere samo u vrijeme izvođenja
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Bez panike kako bi utjecaj kodegena bio manji.
        abort();
    }*/

    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `copy`.
    unsafe { copy(src, dst, count) }
}

/// Postavlja `count * size_of::<T>()` bajtova memorije počevši od `dst` do `val`.
///
/// `write_bytes` je sličan C-ovom [`memset`], ali postavlja bajtove `count * size_of::<T>()` na `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uslova:
///
/// * `dst` mora biti [valid] za upisivanje bajtova `count * size_of::<T>()`.
///
/// * `dst` moraju biti pravilno poravnati.
///
/// Pored toga, pozivatelj mora osigurati da upisivanje `count * size_of::<T>()` bajtova u dano područje memorije rezultira valjanom vrijednošću `T`.
/// Korištenje regije memorije upisane kao `T` koja sadrži nevaljanu vrijednost `T` je nedefinirano ponašanje.
///
/// Imajte na umu da čak i ako efektivno kopirana veličina (`count * size_of: :<T>()`) je `0`, pokazivač mora biti NULL i pravilno poravnan.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Stvaranje nevažeće vrijednosti:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Procuri prethodno zadržana vrijednost prepisivanjem `Box<T>` null pokazivačem.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // U ovom trenutku, korištenje ili ispuštanje `v` rezultira nedefiniranim ponašanjem.
/// // drop(v); // ERROR
///
/// // Čak i curenje `v` "uses", a time i nedefinisano ponašanje.
/// // mem::forget(v); // ERROR
///
/// // U stvari, `v` je nevažeći prema osnovnim invarijantima rasporeda tipova, tako da *svaka* operacija koja ga dodiruje nije definirano ponašanje.
/////
/// // neka je v2 =v;//GREŠKA
///
/// unsafe {
///     // Umjesto toga stavimo valjanu vrijednost
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Sada je kutija u redu
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}