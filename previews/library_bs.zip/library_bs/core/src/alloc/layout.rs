use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Iako se ova funkcija koristi na jednom mjestu i njena implementacija bi se mogla ocrtati, prethodni pokušaji da se to učini usporili su rustc:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Izgled bloka memorije.
///
/// Primjer `Layout` opisuje određeni raspored memorije.
/// Izgradite `Layout` kao ulazni podatak koji ćete dati alokatoru.
///
/// Svi rasporedi imaju pridruženu veličinu i poravnanje snage dva.
///
/// (Imajte na umu da položaji *ne* trebaju imati veličinu koja nije nula, iako `GlobalAlloc` zahtijeva da svi zahtjevi za memorijom ne budu različiti od nule.
/// Pozivatelj mora ili osigurati da su ispunjeni ovakvi uvjeti, upotrijebiti posebne razdjelnike s labavijim zahtjevima ili upotrijebiti blaži `Allocator` sučelje.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // veličina traženog bloka memorije, mjerena u bajtovima.
    size_: usize,

    // poravnanje traženog bloka memorije, mjereno u bajtovima.
    // osiguravamo da je ovo uvijek snaga dva, jer API-ji poput `posix_memalign` to zahtijevaju i razumno je ograničenje nametnuti Layout konstruktorima.
    //
    //
    // (Međutim, mi analogno ne zahtijevamo `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruira `Layout` iz zadanih `size` i `align` ili vraća `LayoutError` ako nije ispunjen bilo koji od sljedećih uvjeta:
    ///
    /// * `align` ne smije biti nula,
    ///
    /// * `align` mora biti stepen dvojke,
    ///
    /// * `size`, kada se zaokruži na najbliži višekratnik `align`, ne smije prelijevati (tj. zaokružena vrijednost mora biti manja ili jednaka `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two podrazumijeva poravnanje!=0.)

        // Zaokružena veličina je:
        //   size_rounded_up=(veličina + poravnaj, 1)&! (poravnaj, 1);
        //
        // Odozgo znamo da se poravna!=0.
        // Ako se dodavanje (poravnanje, 1) ne prelije, tada će zaokruživanje biti u redu.
        //
        // Suprotno tome,&-maskiranje s! (Align, 1) oduzima samo bitove niskog reda.
        // Prema tome, ako se prekoračenje dogodi sa zbrojem,&-maska ne može oduzeti dovoljno da poništi taj preljev.
        //
        //
        // Gore navedeno implicira da je provjera prekoračenja zbrajanja i potrebna i dovoljna.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BEZBEDNOST: uslovi za `from_size_align_unchecked` su bili
        // gore označeno.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Stvara izgled, zaobilazeći sve provjere.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna jer ne provjerava preduvjete iz [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIGURNOST: pozivatelj mora osigurati da je `align` veći od nule.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimalna veličina u bajtovima za memorijski blok ovog rasporeda.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimalno poravnanje bajtova za memorijski blok ovog izgleda.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruira `Layout` pogodan za držanje vrijednosti tipa `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIGURNOST: poravnanje je zagarantovano od strane Rust snage dva i
        // kombinacija size + align zagarantovano se uklapa u naš adresni prostor.
        // Kao rezultat, ovdje upotrijebite neprovjereni konstruktor kako biste izbjegli umetanje koda koji panics ako nije dovoljno dobro optimiziran.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izrađuje izgled koji opisuje zapis koji bi se mogao koristiti za dodjelu potporne strukture za `T` (što može biti Portrait ili drugi neodređeni tip poput kriška).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZBEDNOST: pogledajte obrazloženje `new` zašto se ovo koristi nesigurnom varijantom
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izrađuje izgled koji opisuje zapis koji bi se mogao koristiti za dodjelu potporne strukture za `T` (što može biti Portrait ili drugi neodređeni tip poput kriška).
    ///
    /// # Safety
    ///
    /// Ovu funkciju je sigurno nazvati samo ako su ispunjeni sljedeći uvjeti:
    ///
    /// - Ako je `T` `Sized`, ovu funkciju je uvijek sigurno nazvati.
    /// - Ako je neodređeni rep `T`:
    ///     - [slice], tada dužina reza reza mora biti incijalizirani cijeli broj, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
    ///     - [trait object], tada vtable dio pokazivača mora voditi na valjani vtable za tip `T` stečen prisilom bez veličine, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
    ///
    ///     - (unstable) [extern type], tada je ovu funkciju uvijek sigurno nazvati, ali može panic ili na drugi način vratiti pogrešnu vrijednost jer raspored vanjskog tipa nije poznat.
    ///     To je isto ponašanje kao i [`Layout::for_value`] u odnosu na rep vanjskog tipa.
    ///     - u suprotnom, konzervativno nije dozvoljeno pozivanje ove funkcije.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIGURNOST: preduvjete ovih funkcija prenosimo na pozivatelja
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZBEDNOST: pogledajte obrazloženje `new` zašto se ovo koristi nesigurnom varijantom
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Stvara `NonNull` koji je viseći, ali dobro poravnat za ovaj izgled.
    ///
    /// Imajte na umu da vrijednost pokazivača potencijalno može predstavljati valjani pokazivač, što znači da se to ne smije koristiti kao vrijednost sentinela "not yet initialized".
    /// Tipovi koji se lijeno dodjeljuju moraju pratiti inicijalizaciju na neki drugi način.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIGURNOST: zajamčeno je da poravnanje nije različito od nule
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Stvara izgled koji opisuje zapis koji može sadržavati vrijednost istog izgleda kao `self`, ali koji je također poravnat s poravnanjem `align` (mjereno u bajtovima).
    ///
    ///
    /// Ako `self` već zadovoljava propisano poravnanje, tada vraća `self`.
    ///
    /// Imajte na umu da ovaj metod ne dodaje nikakvo popunjavanje ukupnoj veličini, bez obzira na to ima li vraćeni izgled drugačije poravnanje.
    /// Drugim riječima, ako `K` ima veličinu 16, `K.align_to(32)` će *i dalje* imati veličinu 16.
    ///
    /// Vraća grešku ako kombinacija `self.size()` i datog `align` krši uvjete navedene u [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Vraća količinu dodataka koju moramo umetnuti nakon `self` da bismo osigurali da sljedeća adresa zadovoljava `align` (mjereno u bajtovima).
    ///
    /// npr. ako je `self.size()` 9, tada `self.padding_needed_for(4)` vraća 3, jer je to najmanji broj bajtova popunjavanja potreban da se dobije 4-poravnana adresa (pod pretpostavkom da odgovarajući memorijski blok započinje s 4-poravnanoj adresi).
    ///
    ///
    /// Povratna vrijednost ove funkcije nema značenja ako `align` nije snaga dva.
    ///
    /// Imajte na umu da korisnost vraćene vrijednosti zahtijeva da `align` bude manji ili jednak poravnanju početne adrese za cijeli dodijeljeni blok memorije.Jedan od načina da se zadovolji ovo ograničenje je osigurati `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Zaokružena vrijednost je:
        //   len_rounded_up=(len + poravnaj, 1)&! (poravnaj, 1);
        // a zatim vraćamo razliku u popunjavanju: `len_rounded_up - len`.
        //
        // Koristimo modularnu aritmetiku kroz:
        //
        // 1. zajamčeno je da je align> 0, tako da align, 1 uvijek vrijedi.
        //
        // 2.
        // `len + align - 1` može se preliti za najviše `align - 1`, pa će&-maska s `!(align - 1)` osigurati da će u slučaju prelijevanja `len_rounded_up` i sam biti 0.
        //
        //    Dakle, vraćeni dodatak, kada se doda u `len`, daje 0, što trivijalno zadovoljava poravnanje `align`.
        //
        // (Naravno, pokušaji da se dodijele blokovi memorije čija se veličina i dopuna prelijevaju na gore navedeni način trebali bi dovesti do toga da alokator ionako dovede do pogreške.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Stvara izgled zaokruživanjem veličine ovog izgleda do višestrukog poravnanja izgleda.
    ///
    ///
    /// To je ekvivalentno dodavanju rezultata `padding_needed_for` trenutnoj veličini izgleda.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ovo se ne može preliti.Citiranje iz invarijanta Layout-a:
        // > `size`, kada se zaokruži na najbliži višekratnik `align`,
        // > ne smije se prelijevati (tj. zaokružena vrijednost mora biti manja od
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Stvara izgled koji opisuje zapis za `n` instance `self`, s prikladnom količinom obloga između svake kako bi se osiguralo da svaka instanca dobije traženu veličinu i poravnanje.
    /// Uspješno vraća `(k, offs)` gdje je `k` raspored polja, a `offs` udaljenost između početka svakog elementa u polju.
    ///
    /// Na aritmetičkom preljevu vraća `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ovo se ne može preliti.Citiranje iz invarijanta Layout-a:
        // > `size`, kada se zaokruži na najbliži višekratnik `align`,
        // > ne smije se prelijevati (tj. zaokružena vrijednost mora biti manja od
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIGURNOST: self.align je već poznato da je valjan i alloc_size je bio
        // podstavljen već.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Stvara izgled koji opisuje zapis za `self` praćen `next`, uključujući sva neophodna popunjavanja kako bi se osiguralo da će `next` biti pravilno poravnan, ali *bez popunjavanja*.
    ///
    /// Da biste se podudarali sa izgledom C predstavljanja `repr(C)`, trebali biste nazvati `pad_to_align` nakon proširenja izgleda sa svim poljima.
    /// (Ne postoji način da se podudara sa zadanim izgledom prikaza Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Imajte na umu da će poravnanje rezultirajućeg izgleda biti maksimalno poravnanje `self` i `next`, kako bi se osiguralo poravnanje oba dijela.
    ///
    /// Vraća `Ok((k, offset))`, gdje je `k` izgled spojenog zapisa, a `offset` je relativna lokacija, u bajtovima, početka `next` ugrađenog u spojeni zapis (pod pretpostavkom da sam zapis započinje s pomakom 0).
    ///
    ///
    /// Na aritmetičkom preljevu vraća `LayoutError`.
    ///
    /// # Examples
    ///
    /// Da biste izračunali izgled `#[repr(C)]` strukture i pomake polja iz rasporeda njenih polja:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ne zaboravite završiti sa `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // testirajte da li radi
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Stvara izgled koji opisuje zapis za `n` instance `self`, bez popunjavanja između svake instance.
    ///
    /// Imajte na umu da, za razliku od `repeat`, `repeat_packed` ne garantira da će ponovljene instance `self` biti pravilno poravnate, čak i ako je zadata instanca `self` pravilno poravnana.
    /// Drugim riječima, ako se raspored koji vraća `repeat_packed` koristi za dodjelu niza, nije zajamčeno da će svi elementi u nizu biti pravilno poravnati.
    ///
    /// Na aritmetičkom preljevu vraća `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Stvara izgled koji opisuje zapis za `self` praćen `next` bez dodatnog popunjavanja između njih.
    /// Budući da nije umetnuto nikakvo popunjavanje, poravnanje `next` je irelevantno i uopće nije ugrađeno * u rezultirajući raspored.
    ///
    ///
    /// Na aritmetičkom preljevu vraća `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Stvara izgled koji opisuje zapis za `[T; n]`.
    ///
    /// Na aritmetičkom preljevu vraća `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametri dani `Layout::from_size_align` ili nekom drugom konstruktoru `Layout` ne zadovoljavaju njegova dokumentirana ograničenja.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ovo nam treba za nizvodno impl. greške Portrait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}