use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Alokator memorije koji se može registrirati kao zadana vrijednost standardne biblioteke putem atributa `#[global_allocator]`.
///
/// Neke od metoda zahtijevaju da se memorijski blok *trenutno dodjeljuje* putem alokatora.Ovo znači to:
///
/// * početna adresa za taj memorijski blok prethodno je vraćena prethodnim pozivom na metodu alokacije kao što je `alloc` i
///
/// * memorijski blok nije naknadno oslobođen, gdje se blokovi oslobađaju bilo prenošenjem na metodu oslobađanja kao što je `dealloc` ili prenošenjem na metodu preraspodjele koja vraća ne-null pokazivač.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` Portrait je `unsafe` Portrait iz više razloga, a izvođači moraju osigurati da se pridržavaju ovih ugovora:
///
/// * To je nedefinirano ponašanje ako se globalni alokatori odmotaju.Ovo ograničenje može se ukinuti u future, ali trenutno panic iz bilo koje od ovih funkcija može dovesti do nesigurnosti memorije.
///
/// * `Layout` upiti i proračuni općenito moraju biti tačni.Pozivači ovog Portrait smiju se osloniti na ugovore definirane za svaku metodu, a implementatori moraju osigurati da takvi ugovori ostanu istiniti.
///
/// * Ne možete se pouzdati u dodjelu koja se stvarno događa, čak i ako u izvoru postoje eksplicitne dodjele hrpe.
/// Optimizator može otkriti neiskorištene alokacije koje može u potpunosti eliminirati ili premjestiti u stog i tako nikada ne pozvati alokator.
/// Optimizator može nadalje pretpostaviti da je alokacija nepogrešiva, tako da kôd koji je nekad uspio zbog kvara alokatora sada može iznenada raditi jer je optimizator zaobišao potrebu za alokacijom.
/// Konkretnije, sljedeći primjer koda nije zvučan, bez obzira na to dopušta li vaš prilagođeni alokator brojanje koliko se dodjela dogodilo.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Imajte na umu da gore spomenute optimizacije nisu jedina optimizacija koja se može primijeniti.Općenito se ne možete pouzdati u dodjelu hrpe koja se može dogoditi ako se ona može ukloniti bez mijenjanja ponašanja programa.
///   Bilo da se dodjele događaju ili ne, nije dio ponašanja programa, čak i ako bi se moglo otkriti pomoću alokatora koji prati dodjelu ispisom ili na drugi način ima nuspojave.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Dodijelite memoriju kako je opisano u datom `layout`.
    ///
    /// Vraća pokazivač na novo dodijeljenu memoriju ili nulu da ukaže na neuspjeh dodjele.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna jer nedefinirano ponašanje može rezultirati ako pozivalac ne osigura da `layout` ima ne-nultu veličinu.
    ///
    /// (Podskupovi proširenja mogu pružiti specifičnije granice ponašanja, npr. Garantirati sentinel adresu ili nulti pokazivač kao odgovor na zahtjev za dodjelu nulte veličine.)
    ///
    /// Dodijeljeni blok memorije može se pokrenuti, a ne mora.
    ///
    /// # Errors
    ///
    /// Vraćanje null pokazivača pokazuje da je ili memorija iscrpljena ili `layout` ne ispunjava ograničenja veličine ili poravnanja ovog alokatora.
    ///
    /// Implementacije se potiču da vrate nulu na iscrpljenost memorije, a ne prekidaju, ali to nije strog zahtjev.
    /// (Konkretno: legalno je * implementirati ovaj Portrait iznad osnovne izvorne biblioteke alokacije koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti računanje kao odgovor na grešku u dodjeli potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da direktno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Dodijelite blok memorije na zadanom pokazivaču `ptr` s danim `layout`.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna jer nedefinirano ponašanje može rezultirati ako pozivatelj ne osigura sve od sljedećeg:
    ///
    ///
    /// * `ptr` mora označavati blok memorije trenutno dodijeljen putem ovog alokatora,
    ///
    /// * `layout` mora biti isti raspored koji je korišten za dodjelu tog bloka memorije.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Ponaša se kao `alloc`, ali takođe osigurava da se sadržaj postavi na nulu prije vraćanja.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna iz istih razloga kao i `alloc`.
    /// Međutim, dodijeljeni blok memorije zajamčeno je inicijaliziran.
    ///
    /// # Errors
    ///
    /// Vraćanje null pokazivača pokazuje da je ili memorija iscrpljena ili `layout` ne zadovoljava ograničenja veličine ili poravnanja alokatora, baš kao u `alloc`.
    ///
    /// Klijenti koji žele prekinuti računanje kao odgovor na grešku u dodjeli potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da direktno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SIGURNOST: kako je dodjela uspjela, regija od `ptr`
            // veličine `size` garantirano vrijedi za upisivanje.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Smanjite ili povećajte blok memorije na zadati `new_size`.
    /// Blok je opisan datim pokazivačem `ptr` i `layout`.
    ///
    /// Ako ovo vrati pokazivač koji nije nula, tada je vlasništvo nad memorijskim blokom na koji se poziva `ptr` preneseno na ovaj alokator.
    /// Memorija je možda oslobođena ili ne, i trebalo bi je smatrati neupotrebljivom (osim ako je ponovo vraćena pozivaocu putem povratne vrijednosti ove metode).
    /// Novi memorijski blok dodijeljen je sa `layout`, ali s `size` ažuriranim na `new_size`.
    /// Ovaj novi raspored trebao bi se koristiti prilikom oslobađanja novog memorijskog bloka sa `dealloc`.
    /// Raspon `0..min(layout.size(), new_size) `novog memorijskog bloka zajamčeno ima iste vrijednosti kao i izvorni blok.
    ///
    /// Ako ovaj metod vrati nulu, tada vlasništvo nad memorijskim blokom nije preneseno na ovaj alokator, a sadržaj memorijskog bloka je nepromijenjen.
    ///
    /// # Safety
    ///
    /// Ova funkcija nije sigurna jer nedefinirano ponašanje može rezultirati ako pozivatelj ne osigura sve od sljedećeg:
    ///
    /// * `ptr` mora se trenutno dodijeliti putem ovog alokatora,
    ///
    /// * `layout` mora biti isti raspored koji je korišten za dodjelu tog bloka memorije,
    ///
    /// * `new_size` mora biti veća od nule.
    ///
    /// * `new_size`, kada se zaokruži na najbliži višekratnik `layout.align()`, ne smije prelijevati (tj. zaokružena vrijednost mora biti manja od `usize::MAX`).
    ///
    /// (Podskupovi proširenja mogu pružiti specifičnije granice ponašanja, npr. Garantirati sentinel adresu ili nulti pokazivač kao odgovor na zahtjev za dodjelu nulte veličine.)
    ///
    /// # Errors
    ///
    /// Vraća nulu ako novi izgled ne zadovoljava ograničenja veličine i poravnanja alokatora ili ako preraspodjela na drugi način ne uspije.
    ///
    /// Implementacije se potiču da vrate nulu na iscrpljenost memorije, a ne na paniku ili prekid, ali to nije strog zahtjev.
    /// (Konkretno: legalno je * implementirati ovaj Portrait iznad osnovne izvorne biblioteke alokacije koja prekida pri iscrpljivanju memorije.)
    ///
    /// Klijenti koji žele prekinuti računanje kao odgovor na grešku u preraspodjeli potiču se da pozovu funkciju [`handle_alloc_error`], umjesto da direktno pozivaju `panic!` ili slično.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SIGURNOST: pozivatelj mora osigurati da se `new_size` ne prelije.
        // `layout.align()` dolazi iz `Layout`-a i zagarantovano je valjano.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SIGURNOST: pozivatelj mora osigurati da je `new_layout` veći od nule.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SIGURNOST: prethodno dodijeljeni blok ne može se preklapati s novo dodijeljenim blokom.
            // Pozivatelj mora održati sigurnosni ugovor za `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}