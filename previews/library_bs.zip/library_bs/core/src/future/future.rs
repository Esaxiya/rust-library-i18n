#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future predstavlja asinkrono računanje.
///
/// future je vrijednost koja možda još nije završila računanje.
/// Ova vrsta "asynchronous value" omogućava niti da nastavi obavljati koristan posao dok čeka da vrijednost postane dostupna.
///
///
/// # Metoda `poll`
///
/// Osnovna metoda future, `poll`,*pokušava* razriješiti future u konačnu vrijednost.
/// Ova metoda ne blokira ako vrijednost nije spremna.
/// Umjesto toga, predviđeno je da se trenutni zadatak probudi kada je moguće daljnji napredak ponovnim `anketiranjem`.
/// `context` proslijeđen metodi `poll` može pružiti [`Waker`], koji predstavlja ručku za buđenje trenutnog zadatka.
///
/// Kada koristite future, obično nećete direktno pozivati `poll`, već `.await` vrijednost.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Tip vrijednosti koja se stvara nakon završetka.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pokušajte riješiti future na konačnu vrijednost, registrirajući trenutni zadatak za buđenje ako vrijednost još nije dostupna.
    ///
    /// # Povratna vrijednost
    ///
    /// Ova funkcija vraća:
    ///
    /// - [`Poll::Pending`] ako future još nije spreman
    /// - [`Poll::Ready(val)`] s rezultatom `val` ovog future ako je uspješno završio.
    ///
    /// Jednom kada future završi, klijenti ga više ne bi smjeli `poll`.
    ///
    /// Kada future još nije spreman, `poll` vraća `Poll::Pending` i pohranjuje klon [`Waker`] kopiran iz trenutnog [`Context`].
    /// Ovaj [`Waker`] se zatim probudi kada future može napredovati.
    /// Na primjer, future koji čeka da utičnica postane čitljiva nazvat će `.clone()` na [`Waker`] i pohraniti je.
    /// Kada signal stigne negdje drugdje koji ukazuje da je utičnica čitljiva, poziva se [`Waker::wake`] i probuđuje se zadatak utičnice future.
    /// Jednom kada se zadatak probudi, treba ponovo pokušati `poll` future, što može ili ne mora dati konačnu vrijednost.
    ///
    /// Imajte na umu da na više poziva na `poll`, samo [`Waker`] iz [`Context`] proslijeđen na najnoviji poziv treba biti zakazan za primanje budenja.
    ///
    /// # Karakteristike izvođenja
    ///
    /// Samo Futures su *inertni*;oni moraju biti *aktivno*`anketirani 'kako bi napredovali, što znači da svaki put kada se trenutni zadatak probudi, on bi trebao aktivno` anketirati' do futures za koji još uvijek ima interesa.
    ///
    /// Funkcija `poll` se ne poziva više puta u uskoj petlji-umjesto toga, trebala bi je pozvati samo kada future ukaže da je spremna za napredak (pozivanjem `wake()`).
    /// Ako ste upoznati sa siskalima `poll(2)` ili `select(2)` na Unix, vrijedi napomenuti da futures obično *ne* trpi iste probleme kao i "all wakeups must poll all events";više su poput `epoll(4)`.
    ///
    /// Implementacija `poll` trebala bi težiti brzom povratku i ne bi trebala blokirati.Povratak brzo sprečava nepotrebno začepljenje niti ili petlje događaja.
    /// Ako se unaprijed zna da poziv na `poll` može potrajati neko vrijeme, rad treba isprazniti u spremište niti (ili nešto slično) kako bi se osiguralo da se `poll` može brzo vratiti.
    ///
    /// # Panics
    ///
    /// Jednom kada se future dovrši (vratio `Ready` iz `poll`), ponovno pozivanje njegove `poll` metode može panic, zauvijek blokirati ili izazvati druge vrste problema;`Future` Portrait ne postavlja zahtjeve za efekte takvog poziva.
    /// Međutim, kako metoda `poll` nije označena kao `unsafe`, primjenjuju se uobičajena pravila Rust: pozivi nikada ne smiju uzrokovati nedefinirano ponašanje (oštećenje memorije, nepravilna upotreba funkcija `unsafe` ili slično), bez obzira na stanje future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}