use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Stvara future koji je odmah spreman s vrijednošću.
///
/// Ovaj `struct` je kreirao [`ready()`].
/// Pogledajte dokumentaciju za više informacija.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// Stvara future koji je odmah spreman s vrijednošću.
///
/// Futures stvoreni kroz ovu funkciju funkcionalno su slični onima kreiranim kroz `async {}`.
/// Glavna razlika je u tome što su futures stvoreni putem ove funkcije imenovani i implementiraju `Unpin`.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}