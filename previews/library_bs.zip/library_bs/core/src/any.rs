//! Ovaj modul implementira `Any` Portrait, koji omogućava dinamičko kucanje bilo kog tipa `'static` kroz runtime refleksiju.
//!
//! `Any` sam se može koristiti za dobivanje `TypeId` i ima više karakteristika kada se koristi kao Portrait objekt.
//! Kao `&dyn Any` (posuđeni Portrait objekt), on ima metode `is` i `downcast_ref`, da testira da li je sadržana vrijednost datog tipa i da dobije referencu na unutrašnju vrijednost kao tip.
//! Kao `&mut dyn Any`, postoji i metoda `downcast_mut` za dobivanje promjenjive reference na unutarnju vrijednost.
//! `Box<dyn Any>` dodaje metodu `downcast`, koja pokušava pretvoriti u `Box<T>`.
//! Potpune detalje potražite u dokumentaciji [`Box`].
//!
//! Imajte na umu da je `&dyn Any` ograničen na testiranje da li je vrijednost određene betonske vrste i ne može se koristiti za testiranje da li neka vrsta implementira Portrait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Pametni pokazivači i `dyn Any`
//!
//! Jedno ponašanje koje morate imati na umu kada koristite `Any` kao Portrait objekt, posebno kod tipova poput `Box<dyn Any>` ili `Arc<dyn Any>`, jest da će jednostavno pozivanje `.type_id()` na vrijednost proizvesti `TypeId`*spremnika*, a ne osnovni Portrait objekt.
//!
//! To se može izbjeći pretvaranjem pametnog pokazivača u `&dyn Any`, koji će vratiti `TypeId` objekta.
//! Na primjer:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Vjerovatnije je da ćete ovo poželjeti:
//! let actual_id = (&*boxed).type_id();
//! // ... nego ovo:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Razmotrimo situaciju u kojoj želimo odjaviti vrijednost prosljeđenu funkciji.
//! Znamo vrijednost na kojoj radimo implementira Debug, ali ne znamo njegovu konkretnu vrstu.Želimo dati poseban tretman određenim vrstama: u ovom slučaju ispisujemo dužinu String vrijednosti prije njihove vrijednosti.
//! Ne znamo konkretan tip naše vrijednosti u vrijeme kompajliranja, pa umjesto toga moramo upotrijebiti refleksiju vremena izvođenja.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger funkcija za bilo koji tip koji implementira otklanjanje grešaka.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Pokušajte našu vrijednost pretvoriti u `String`.
//!     // Ako je uspješno, želimo prikazati dužinu niza kao i njegovu vrijednost.
//!     // Ako ne, to je druga vrsta: jednostavno ispišite bez ukrasa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ova funkcija želi odjaviti svoj parametar prije nego što započne s radom.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... raditi neki drugi posao
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Bilo koji Portrait
///////////////////////////////////////////////////////////////////////////////

/// Portrait za oponašanje dinamičkog kucanja.
///
/// Većina tipova implementira `Any`.Međutim, bilo koji tip koji sadrži ne-"statičnu" referencu ne sadrži.
/// Pogledajte [module-level documentation][mod] za više detalja.
///
/// [mod]: crate::any
// Ovaj Portrait nije nesiguran, iako se oslanjamo na specifičnosti funkcije `type_id` svog jedinog impl-a u nesigurnom kodu (npr. `downcast`).To bi obično bio problem, ali budući da je jedina implikacija `Any` opća primjena, nijedan drugi kôd ne može implementirati `Any`.
//
// Uvjerljivo bismo mogli učiniti ovaj Portrait nesigurnim-to ne bi uzrokovalo lom, jer kontroliramo sve implementacije-ali odlučujemo da to ne učinimo, jer to i nije stvarno potrebno i može zbuniti korisnike oko razlike nesigurnih traits i nesigurnih metoda (tj. `type_id` bi i dalje bilo sigurno nazvati, ali bismo ga vjerojatno željeli naznačiti u dokumentaciji).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Dobija `TypeId` od `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metode produženja za bilo koje Portrait objekte.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Osigurajte da se rezultat npr. Spajanja niti može ispisati i stoga koristiti sa `unwrap`.
// Na kraju možda više neće biti potreban ako slanje uspije s nadogradnjom.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Vraća `true` ako je uokvireni tip isti kao `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Nabavite `TypeId` tipa s kojim je pokrenuta ova funkcija.
        let t = TypeId::of::<T>();

        // Nabavite `TypeId` tipa u Portrait objektu (`self`).
        let concrete = self.type_id();

        // Uporedite oba TypeId-a o jednakosti.
        t == concrete
    }

    /// Vraća neku referencu na uokvirenu vrijednost ako je tipa `T` ili `None` ako nije.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SIGURNOST: upravo smo provjerili pokazujemo li ispravni tip i možemo se osloniti
            // ta provjera sigurnosti memorije jer smo implementirali Any za sve tipove;ne mogu postojati nikakvi drugi impulsi jer bi se sukobili s našim impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Vraća neku promjenjivu referencu na uokvirenu vrijednost ako je tipa `T` ili `None` ako nije.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SIGURNOST: upravo smo provjerili pokazujemo li ispravni tip i možemo se osloniti
            // ta provjera sigurnosti memorije jer smo implementirali Any za sve tipove;ne mogu postojati nikakvi drugi impulsi jer bi se sukobili s našim impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Prosljeđuje na metodu definiranu na tipu `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID i njegove metode
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` predstavlja globalno jedinstveni identifikator tipa.
///
/// Svaki `TypeId` je neprozirni objekt koji ne dozvoljava pregled onoga što je unutra, ali dopušta osnovne operacije kao što su kloniranje, upoređivanje, ispis i prikazivanje.
///
///
/// `TypeId` je trenutno dostupan samo za tipove koji pripisuju `'static`, ali ovo ograničenje može se ukloniti u future.
///
/// Iako `TypeId` implementira `Hash`, `PartialOrd` i `Ord`, vrijedi napomenuti da će hashovi i redoslijed varirati između izdanja Rust.
/// Čuvajte se oslanjanja na njih unutar vašeg koda!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Vraća `TypeId` tipa s kojim je generirana funkcija pokrenuta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Vraća ime tipa kao kriška niza.
///
/// # Note
///
/// Ovo je namijenjeno dijagnostičkoj upotrebi.
/// Tačan sadržaj i format vraćenog niza nisu navedeni, osim što su to najbolji opis tipa.
/// Na primjer, među nizovima koje bi `type_name::<Option<String>>()` mogao vratiti su `"Option<String>"` i `"std::option::Option<std::string::String>"`.
///
///
/// Vraćeni niz ne smije se smatrati jedinstvenim identifikatorom tipa, jer se više tipova može preslikati na isto ime tipa.
/// Slično tome, ne postoji garancija da će se svi dijelovi tipa pojaviti u vraćenom nizu: na primjer, specifikatori životnog vijeka trenutno nisu uključeni.
/// Pored toga, izlaz se može mijenjati između verzija kompajlera.
///
/// Trenutna implementacija koristi istu infrastrukturu kao dijagnostika kompajlera i debuginfo, ali to nije zajamčeno.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Vraća ime tipa ukazane vrijednosti kao kriška niza.
/// Ovo je isto kao `type_name::<T>()`, ali se može koristiti tamo gdje tip varijable nije lako dostupan.
///
/// # Note
///
/// Ovo je namijenjeno dijagnostičkoj upotrebi.Tačan sadržaj i format niza nisu navedeni, osim što predstavljaju najbolji opis vrste.
/// Na primjer, `type_name_of_val::<Option<String>>(None)` može vratiti `"Option<String>"` ili `"std::option::Option<std::string::String>"`, ali ne i `"foobar"`.
///
/// Pored toga, izlaz se može mijenjati između verzija kompajlera.
///
/// Ova funkcija ne rješava Portrait objekte, što znači da `type_name_of_val(&7u32 as &dyn Debug)` može vratiti `"dyn Debug"`, ali ne i `"u32"`.
///
/// Ime tipa ne treba smatrati jedinstvenim identifikatorom tipa;
/// više tipova može dijeliti isto ime tipa.
///
/// Trenutna implementacija koristi istu infrastrukturu kao dijagnostika kompajlera i debuginfo, ali to nije zajamčeno.
///
/// # Examples
///
/// Ispisuje zadani cijeli broj i plutajući tip.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}