//! Rukovanje greškom sa tipom `Result`.
//!
//! [`Result<T, E>`][`Result`] je tip koji se koristi za vraćanje i širenje grešaka.
//! To je nabrajanje sa varijantama, [`Ok(T)`], koje predstavljaju uspjeh i sadrže vrijednost, i [`Err(E)`], koje predstavljaju grešku i sadrže vrijednost greške.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! Funkcije vraćaju [`Result`] kad god se greške očekuju i mogu se oporaviti.U `std` crate, [`Result`] se najviše koristi za [I/O](../../std/io/index.html).
//!
//! Jednostavna funkcija koja vraća [`Result`] može se definirati i koristiti ovako:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! Podudaranje uzoraka na [`Rezultat`] s je jasno i jednostavno za jednostavne slučajeve, ali [`Result`] dolazi s nekoliko pogodnih metoda koje čine rad sa njim sažetijim.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // Metode `is_ok` i `is_err` rade ono što kažu.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` troši `Result` i proizvodi drugi.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // Koristite `and_then` za nastavak izračunavanja.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // Koristite `or_else` za rješavanje pogreške.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // Snimite rezultat i vratite sadržaj sa `unwrap`.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # Moraju se koristiti rezultati
//!
//! Uobičajeni problem korištenja povratnih vrijednosti za ukazivanje na greške je taj što je lako zanemariti povratnu vrijednost, tako da ne uspijeva rukovati pogreškom.
//! [`Result`] je označen s atributom `#[must_use]`, što će uzrokovati da kompajler izda upozorenje kada se zanemari vrijednost rezultata.
//! To čini [`Result`] posebno korisnim kod funkcija koje mogu naići na greške, ali inače ne vraćaju korisnu vrijednost.
//!
//! Razmotrimo metodu [`write_all`] definiranu za tipove I/O pomoću [`Write`] Portrait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: Stvarna definicija [`Write`] koristi [`io::Result`], što je samo sinonim za [`Rezultat`]`<T,`[`io: :Error`]`>`.*
//!
//! Ova metoda ne daje vrijednost, ali upisivanje možda neće uspjeti.Ključno je riješiti slučaj pogreške i *ne* napisati nešto poput ovoga:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // Ako `write_all` pogreši, to nikada nećemo saznati, jer se povratna vrijednost zanemaruje.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Ako *to* napišete u Rust, kompajler će vam dati upozorenje (po defaultu, kontrolirano od `unused_must_use` lint).
//!
//! Umjesto toga, ako ne želite riješiti grešku, jednostavno potvrdite uspjeh s [`expect`].
//! Ovo će panic izvršiti ako upisivanje ne uspije, pružajući marginalno korisnu poruku koja ukazuje zašto:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! Možete i jednostavno ustvrditi uspjeh:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! Ili proširite grešku nizom poziva s [`?`]:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # Operator znaka pitanja, `?`
//!
//! Prilikom pisanja koda koji poziva mnoge funkcije koje vraćaju tip [`Result`], rukovanje greškama može biti zamorno.
//! Operator znaka pitanja, [`?`], sakriva neke od glavnih slojeva pogrešaka širenja u niz poziva.
//!
//! Zamjenjuje ovo:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // Rani povratak na grešku
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! S ovim:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // Rani povratak na grešku
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *Mnogo je ljepše!*
//!
//! Završetak izraza s [`?`] rezultirat će raspakiranom uspjehom ([`Ok`]) vrijednosti, osim ako je rezultat [`Err`], u tom slučaju se [`Err`] vraća rano iz funkcije zatvaranja.
//!
//!
//! [`?`] može se koristiti samo u funkcijama koje vraćaju [`Result`] zbog ranog povratka [`Err`] koji pruža.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` je tip koji predstavlja uspjeh ([`Ok`]) ili neuspjeh ([`Err`]).
///
/// Pogledajte [module documentation](self) za detalje.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// Sadrži vrijednost uspjeha
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// Sadrži vrijednost greške
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// Tip implementacije
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // Ispitivanje sadržanih vrijednosti
    /////////////////////////////////////////////////////////////////////////

    /// Vraća `true` ako je rezultat [`Ok`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// Vraća `true` ako je rezultat [`Err`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// Vraća `true` ako je rezultat vrijednost [`Ok`] koja sadrži zadanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// Vraća `true` ako je rezultat vrijednost [`Err`] koja sadrži zadanu vrijednost.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter za svaku varijantu
    /////////////////////////////////////////////////////////////////////////

    /// Konvertira iz `Result<T, E>` u [`Option<T>`].
    ///
    /// Pretvara `self` u [`Option<T>`], troši `self` i odbacuje grešku, ako postoji.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// Konvertira iz `Result<T, E>` u [`Option<E>`].
    ///
    /// Pretvara `self` u [`Option<E>`], troši `self` i odbacuje vrijednost uspjeha, ako postoji.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adapter za rad sa referencama
    /////////////////////////////////////////////////////////////////////////

    /// Konvertira iz `&Result<T, E>` u `Result<&T, &E>`.
    ///
    /// Izrađuje novi `Result`, koji sadrži referencu na original, ostavljajući original na mjestu.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// Konvertira iz `&mut Result<T, E>` u `Result<&mut T, &mut E>`.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Transformiranje sadržanih vrijednosti
    /////////////////////////////////////////////////////////////////////////

    /// Mapira `Result<T, E>` na `Result<U, E>` primjenom funkcije na sadržanu vrijednost [`Ok`], ostavljajući vrijednost [`Err`] netaknutom.
    ///
    ///
    /// Ova funkcija se može koristiti za sastavljanje rezultata dvije funkcije.
    ///
    /// # Examples
    ///
    /// Ispišite brojeve u svakom retku niza pomnožene s dva.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// Primjenjuje funkciju na sadržanu vrijednost (ako je [`Ok`]) ili vraća zadani zadani (ako je [`Err`]).
    ///
    /// Argumenti proslijeđeni `map_or` se nestrpljivo procjenjuju;ako prosljeđujete rezultat poziva funkcije, preporučuje se upotreba [`map_or_else`], koji se lijeno procjenjuje.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// Mapira `Result<T, E>` na `U` primjenom funkcije na sadržanu vrijednost [`Ok`] ili zamjensku funkciju na sadržanu vrijednost [`Err`].
    ///
    ///
    /// Ova se funkcija može koristiti za raspakiranje uspješnog rezultata dok se rješava greška.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// Mapira `Result<T, E>` na `Result<T, F>` primjenom funkcije na sadržanu vrijednost [`Err`], ostavljajući vrijednost [`Ok`] netaknutom.
    ///
    ///
    /// Ovu funkciju možete koristiti za prolazak kroz uspješan rezultat dok obrađuje grešku.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Konstruktori iteratora
    /////////////////////////////////////////////////////////////////////////

    /// Vraća iterator preko moguće sadržane vrijednosti.
    ///
    /// Iterator daje jednu vrijednost ako je rezultat [`Result::Ok`], inače nijednu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// Vraća promjenjivi iterator preko moguće sadržane vrijednosti.
    ///
    /// Iterator daje jednu vrijednost ako je rezultat [`Result::Ok`], inače nijednu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // Logičke operacije nad vrijednostima, željne i lijene
    /////////////////////////////////////////////////////////////////////////

    /// Vraća `res` ako je rezultat [`Ok`], u suprotnom vraća vrijednost [`Err`] za `self`.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// Poziva `op` ako je rezultat [`Ok`], u suprotnom vraća vrijednost [`Err`] za `self`.
    ///
    ///
    /// Ova funkcija se može koristiti za upravljanje protokom na osnovu `Result` vrijednosti.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// Vraća `res` ako je rezultat [`Err`], u suprotnom vraća vrijednost [`Ok`] za `self`.
    ///
    /// Argumenti proslijeđeni `or` se nestrpljivo procjenjuju;ako prosljeđujete rezultat poziva funkcije, preporučuje se upotreba [`or_else`], koji se lijeno procjenjuje.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// Poziva `op` ako je rezultat [`Err`], u suprotnom vraća vrijednost [`Ok`] za `self`.
    ///
    ///
    /// Ova se funkcija može koristiti za upravljanje protokom na osnovu vrijednosti rezultata.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// Prikazuje sadržanu vrijednost [`Ok`] ili zadanu default.
    ///
    /// Argumenti proslijeđeni `unwrap_or` se nestrpljivo procjenjuju;ako prosljeđujete rezultat poziva funkcije, preporučuje se upotreba [`unwrap_or_else`], koji se lijeno procjenjuje.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// Vraća sadržanu vrijednost [`Ok`] ili je izračunava iz zatvaranja.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// Vraća sadržanu vrijednost [`Ok`], trošeći vrijednost `self`, bez provjere da vrijednost nije [`Err`].
    ///
    ///
    /// # Safety
    ///
    /// Pozivanje ove metode na [`Err`] je *[nedefinirano ponašanje]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // Nedefinisano ponašanje!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// Vraća sadržanu vrijednost [`Err`], trošeći vrijednost `self`, bez provjere da vrijednost nije [`Ok`].
    ///
    ///
    /// # Safety
    ///
    /// Pozivanje ove metode na [`Ok`] je *[nedefinirano ponašanje]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // Nedefinisano ponašanje!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // SIGURNOST: pozivatelj mora održati ugovor o sigurnosti.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// Mapira `Result<&T, E>` na `Result<T, E>` kopiranjem sadržaja dijela `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// Mapira `Result<&mut T, E>` na `Result<T, E>` kopiranjem sadržaja dijela `Ok`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// Mapira `Result<&T, E>` na `Result<T, E>` kloniranjem sadržaja `Ok` dijela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// Mapira `Result<&mut T, E>` na `Result<T, E>` kloniranjem sadržaja `Ok` dijela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// Vraća sadržanu vrijednost [`Ok`], trošeći vrijednost `self`.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost [`Err`], sa panic porukom koja uključuje prosljeđenu poruku i sadržaj [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// Vraća sadržanu vrijednost [`Ok`], trošeći vrijednost `self`.
    ///
    /// Budući da ova funkcija može panic, njezina se upotreba uglavnom ne preporučuje.
    /// Umjesto toga, radije upotrijebite podudaranje uzoraka i izričito rješavajte slučaj [`Err`] ili nazovite [`unwrap_or`], [`unwrap_or_else`] ili [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost [`Err`], sa panic porukom koju daje vrijednost [`Err`].
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// Vraća sadržanu vrijednost [`Err`], trošeći vrijednost `self`.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost [`Ok`], sa panic porukom koja uključuje prosljeđenu poruku i sadržaj [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// Vraća sadržanu vrijednost [`Err`], trošeći vrijednost `self`.
    ///
    /// # Panics
    ///
    /// Panics ako je vrijednost [`Ok`], s prilagođenom panic porukom koju daje vrijednost [`Ok`].
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// Vraća sadržanu [`Ok`] vrijednost ili zadanu vrijednost
    ///
    /// Troši argument `self`, onda, ako [`Ok`], vraća sadržanu vrijednost, u suprotnom ako [`Err`], vraća zadanu vrijednost za taj tip.
    ///
    ///
    /// # Examples
    ///
    /// Pretvara niz u cijeli broj, pretvarajući loše oblikovane nizove u 0 (zadana vrijednost za cijele brojeve).
    /// [`parse`] pretvara niz u bilo koji drugi tip koji implementira [`FromStr`], vraćajući [`Err`] u slučaju greške.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// Vraća sadržanu vrijednost [`Ok`], ali nikada panics.
    ///
    /// Za razliku od [`unwrap`], poznato je da ova metoda nikada nije panic na tipovima rezultata za koje je implementirana.
    /// Stoga se može koristiti umjesto `unwrap` kao zaštita održavanja koja se neće uspjeti kompajlirati ako se tip pogreške `Result` kasnije promijeni u grešku koja se stvarno može dogoditi.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// Pretvara iz `Result<T, E>` (ili `&Result<T, E>`) u `Result<&<T as Deref>::Target, &E>`.
    ///
    /// Prisiljava [`Ok`] varijantu originalnog [`Result`] putem [`Deref`](crate::ops::Deref) i vraća novi [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// Pretvara iz `Result<T, E>` (ili `&mut Result<T, E>`) u `Result<&mut <T as DerefMut>::Target, &mut E>`.
    ///
    /// Prisiljava [`Ok`] varijantu originalnog [`Result`] putem [`DerefMut`](crate::ops::DerefMut) i vraća novi [`Result`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// Transponuje `Result` iz `Option` u `Option` u `Result`.
    ///
    /// `Ok(None)` bit će mapiran na `None`.
    /// `Ok(Some(_))` i `Err(_)` bit će mapirani u `Some(Ok(_))` i `Some(Err(_))`.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// Konvertira iz `Result<Result<T, E>, E>` u `Result<T, E>`
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// Izravnavanjem se uklanja samo jedan nivo gniježđenja odjednom:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// Vraća vrijednost [`Ok`] ako je `self` `Ok`, i vrijednost [`Err`] ako je `self` `Err`.
    ///
    /// Drugim riječima, ova funkcija vraća vrijednost (`T`) `Result<T, T>`, bez obzira je li taj rezultat `Ok` ili `Err`.
    ///
    /// Ovo može biti korisno u vezi s API-ima poput [`Atomic*::compare_exchange`] ili [`slice::binary_search`], ali samo u slučajevima kada vas nije briga je li rezultat bio `Ok` ili ne.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// Ovo je odvojena funkcija za smanjenje veličine koda metoda
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait implementacije
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Vraća konzumirajući iterator preko moguće sadržane vrijednosti.
    ///
    /// Iterator daje jednu vrijednost ako je rezultat [`Result::Ok`], inače nijednu.
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Iteratori rezultata
/////////////////////////////////////////////////////////////////////////////

/// Iterator preko reference na [`Ok`] varijantu [`Result`].
///
/// Iterator daje jednu vrijednost ako je rezultat [`Ok`], inače nijednu.
///
/// Kreirao [`Result::iter`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// Iterator preko promjenjive reference na [`Ok`] varijantu [`Result`].
///
/// Kreirao [`Result::iter_mut`].
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Iterator preko vrijednosti u [`Ok`] varijanti [`Result`].
///
/// Iterator daje jednu vrijednost ako je rezultat [`Ok`], inače nijednu.
///
/// Ova struktura je kreirana [`into_iter`] metodom na [`Result`] (pruža [`IntoIterator`] Portrait).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// Uzima svaki element u `Iterator`: ako je `Err`, ne uzimaju se daljnji elementi i vraća se `Err`.
    /// Ako se ne dogodi `Err`, vraća se spremnik sa vrijednostima svakog `Result`.
    ///
    /// Evo primjera koji povećava svaki cijeli broj u vector, provjeravajući ima li preljeva:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// Evo još jednog primjera koji pokušava oduzeti jedan od drugog popisa cjelobrojnih brojeva, ovaj put provjeravajući da li ima podlijevanja:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// Evo varijacije u prethodnom primjeru koja pokazuje da se iz `iter` ne uzimaju daljnji elementi nakon prvog `Err`.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Budući da je treći element prouzrokovao podliv, nisu uzeti daljnji elementi, pa je konačna vrijednost `shared` 6 (= `3 + 2 + 1`), a ne 16.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): Ovo bi se moglo zamijeniti Iterator::scan kada se ova greška u performansama zatvori.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}