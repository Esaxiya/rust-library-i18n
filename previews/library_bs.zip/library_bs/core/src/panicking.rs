//! Panic podrška za libcore
//!
//! Osnovna biblioteka ne može definirati paniku, ali *deklarira* paniku.
//! To znači da su funkcije unutar libcore-a dopuštene panic, ali da bi bilo korisno gornji crate mora definirati paniku da bi se libcore mogao koristiti.
//! Trenutno sučelje za paniku je:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ova definicija omogućava paniku sa bilo kojom opštom porukom, ali ne dozvoljava neuspjeh s vrijednošću `Box<Any>`.
//! (`PanicInfo` sadrži samo `&(dyn Any + Send)`, za koji u "PanicInfo: : internal_constructor" popunjavamo lažnu vrijednost.) Razlog tome je što libcore ne smije dodijeliti.
//!
//!
//! Ovaj modul sadrži nekoliko drugih funkcija panike, ali to su samo potrebne stavke jezika za kompajler.Svi panics usmjereni su kroz ovu jednu funkciju.
//! Stvarni simbol se deklarira kroz atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Osnovna implementacija libcore-ovog `panic!` makronaredba kada se ne koristi formatiranje.
#[cold]
// nikad u liniji, osim ako panic_immediate_abort ne izbjegne napuhavanje koda na web lokacijama poziva što je više moguće
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // potreban kodegenu za panic na preljevu i druge `Assert` MIR terminatore
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Upotrijebite Arguments::new_v1 umjesto format_args! ("{}", Izraz) da biste potencijalno smanjili režijske troškove.
    // Format_args!makro koristi str-ov Display Portrait za pisanje izraza, koji poziva Formatter::pad, koji mora prilagoditi skraćivanje i dodavanje niza (iako ovdje nije upotrijebljen nijedan).
    //
    // Korištenje Arguments::new_v1 može dopustiti kompajleru da izostavi Formatter::pad iz izlazne binarne datoteke, uštedeći do nekoliko kilobajta.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // potrebno za panics sa procjenom const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // potreban codegenu za panic na OOB array/slice pristupu
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Osnovna implementacija libcore-ovog `panic!` makronaredba prilikom formatiranja.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NAPOMENA Ova funkcija nikada ne prelazi FFI granicu;to je poziv Rust-u-Rust koji se rješava u funkciji `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIGURNOST: `panic_impl` je definiran u sigurnom Rust kodu i stoga je siguran za poziv.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interna funkcija za makronaredbe `assert_eq!` i `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}