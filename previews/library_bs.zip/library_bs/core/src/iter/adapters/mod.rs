use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ovaj Portrait pruža tranzitivni pristup fazi izvora u cjevovodu adapter-adapter pod uvjetima koji
/// * izvor iteratora `S` sam implementira `SourceIter<Source = S>`
/// * postoji delegirajuća implementacija ovog Portrait za svaki adapter u cjevovodu između izvora i potrošača cjevovoda.
///
/// Kada je izvor vlasnička struktura iteratora (obično se naziva `IntoIter`), to može biti korisno za specijaliziranje implementacija [`FromIterator`] ili za oporavak preostalih elemenata nakon što je iterator djelomično iscrpljen.
///
///
/// Imajte na umu da implementacije ne moraju nužno omogućiti pristup najunutarnjem izvoru cjevovoda.Intermedijarni adapter sa statusom mogao bi željno procijeniti dio cjevovoda i izložiti njegovu internu pohranu kao izvor.
///
/// Portrait nije siguran jer realizatori moraju pridržavati dodatna sigurnosna svojstva.
/// Pogledajte [`as_inner`] za detalje.
///
/// # Examples
///
/// Dohvaćanje djelomično potrošenog izvora:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Faza izvora u cjevovodu iteratora.
    type Source: Iterator;

    /// Dohvatite izvor cjevovoda iteratora.
    ///
    /// # Safety
    ///
    /// Implementacije moraju vratiti istu promjenjivu referencu za svog vijeka, osim ako ih ne zamijeni pozivalac.
    /// Pozivači mogu zamijeniti referencu samo kada su zaustavili iteraciju i ispustili cjevovod iteratora nakon izdvajanja izvora.
    ///
    /// To znači da se adapteri iteratora mogu osloniti na izvor koji se neće promijeniti tijekom iteracije, ali se ne mogu osloniti na njega u svojim Drop implementacijama.
    ///
    /// Implementacija ove metode znači da se adapteri odriču samo privatnog pristupa svom izvoru i mogu se osloniti samo na garancije dane na osnovu tipova prijemnika metoda.
    /// Nedostatak ograničenog pristupa također zahtijeva da adapteri moraju podržavati javni API izvora čak i kada imaju pristup njegovim internim komponentama.
    ///
    /// Pozivatelji zauzvrat moraju očekivati da izvor bude u bilo kojem stanju koje je u skladu s njegovim javnim API-jem, jer adapteri koji stoje između njega i izvora imaju isti pristup.
    /// Konkretno, adapter je možda potrošio više elemenata nego što je neophodno.
    ///
    /// Opći cilj ovih zahtjeva je omogućiti potrošaču cjevovoda upotrebu
    /// * sve što ostane u izvoru nakon zaustavljanja iteracije
    /// * memorija koja je postala neiskorištena unapređivanjem konzumirajućeg iteratora
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Adapter iteratora koji proizvodi izlaz sve dok osnovni iterator proizvodi `Result::Ok` vrijednosti.
///
///
/// Ako se naiđe na grešku, iterator se zaustavlja i greška se pohranjuje.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Obradite dati iterator kao da je dao `T` umjesto `Result<T, _>`.
/// Sve pogreške zaustavit će unutarnji iterator i ukupni rezultat bit će pogreška.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}