use crate::iter::{FusedIterator, TrustedLen};

/// Stvara iterator koji daje element tačno jednom.
///
/// Ovo se obično koristi za prilagođavanje jedne vrijednosti u [`chain()`] drugih vrsta iteracija.
/// Možda imate iterator koji pokriva gotovo sve, ali potreban vam je dodatni poseban slučaj.
/// Možda imate funkciju koja radi na iteratorima, ali trebate obraditi samo jednu vrijednost.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::iter;
///
/// // jedan je najusamljeniji broj
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // samo jedan, to je sve što smo dobili
/// assert_eq!(None, one.next());
/// ```
///
/// Povezivanje lanca s drugim iteratorom.
/// Recimo da želimo ponoviti svaku datoteku direktorija `.foo`, ali i konfiguracijsku datoteku,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // moramo pretvoriti iz iteratora DirEntry-a u iterator PathBufsa, pa koristimo mapu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // sada, naš iterator samo za našu konfiguracijsku datoteku
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // povezati dva iteratora u jedan veliki iterator
/// let files = dirs.chain(config);
///
/// // ovo će nam dati sve datoteke u .foo kao i .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator koji daje element tačno jednom.
///
/// Ovaj `struct` kreira funkcija [`once()`].Pogledajte dokumentaciju za više informacija.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}