use crate::fmt;

/// Stvara novi iterator gdje svaka iteracija poziva predviđeno zatvaranje `F: FnMut() -> Option<T>`.
///
/// To omogućava stvaranje prilagođenog iteratora s bilo kojim ponašanjem bez korištenja opširnije sintakse stvaranja namjenskog tipa i implementacije [`Iterator`] Portrait za njega.
///
/// Imajte na umu da iterator `FromFn` ne pretpostavlja pretpostavke o ponašanju zatvaranja, pa prema tome konzervativno ne implementira [`FusedIterator`] ili poništava [`Iterator::size_hint()`] sa svog zadanog `(0, None)`.
///
///
/// Zatvaranje može koristiti snimke i njegovo okruženje za praćenje stanja u iteracijama.Ovisno o načinu korištenja iteratora, ovo može zahtijevati specificiranje ključne riječi [`move`] na zatvaranju.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ponovno implementiramo brojač iteratora iz [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Povećajte naše brojanje.Zbog toga smo započeli s nulom.
///     count += 1;
///
///     // Provjerite jesmo li završili s brojanjem ili nismo.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator u kojem svaka iteracija poziva predviđeno zatvaranje `F: FnMut() -> Option<T>`.
///
/// Ovaj `struct` kreira funkcija [`iter::from_fn()`].
/// Pogledajte dokumentaciju za više informacija.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}