use crate::iter::{FusedIterator, TrustedLen};

/// Stvara novi iterator koji beskrajno ponavlja elemente tipa `A` primjenom predviđenog zatvarača, repetitora, `F: FnMut() -> A`.
///
/// Funkcija `repeat_with()` poziva ponavljač iznova i iznova.
///
/// Beskonačni iteratori poput `repeat_with()` često se koriste s adapterima poput [`Iterator::take()`], kako bi ih učinili konačnim.
///
/// Ako tip elementa iteratora koji vam treba implementira [`Clone`] i u redu je zadržati izvorni element u memoriji, umjesto toga trebali biste koristiti funkciju [`repeat()`].
///
///
/// Iterator proizveden od `repeat_with()` nije [`DoubleEndedIterator`].
/// Ako vam je potreban `repeat_with()` da vratite [`DoubleEndedIterator`], otvorite GitHub problem koji objašnjava vaš slučaj upotrebe.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::iter;
///
/// // pretpostavimo da imamo neku vrijednost tipa koji nije `Clone` ili koji još ne želi imati u memoriji jer je skup:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // određena vrijednost zauvijek:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Korištenje mutacije i postavljanje konačnog:
///
/// ```rust
/// use std::iter;
///
/// // Od nule do treće snage dva:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... i sad smo gotovi
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator koji beskrajno ponavlja elemente tipa `A` primjenom priloženog zatvarača `F: FnMut() -> A`.
///
///
/// Ovaj `struct` kreira funkcija [`repeat_with()`].
/// Pogledajte dokumentaciju za više informacija.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}