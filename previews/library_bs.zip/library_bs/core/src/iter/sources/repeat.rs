use crate::iter::{FusedIterator, TrustedLen};

/// Stvara novi iterator koji beskrajno ponavlja jedan element.
///
/// Funkcija `repeat()` ponavlja jednu vrijednost iznova i iznova.
///
/// Beskonačni iteratori poput `repeat()` često se koriste s adapterima poput [`Iterator::take()`], kako bi ih učinili konačnim.
///
/// Ako tip elementa iteratora koji vam treba ne implementira `Clone` ili ako ponovljeni element ne želite zadržati u memoriji, umjesto toga možete koristiti funkciju [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// use std::iter;
///
/// // broj četiri 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // da, još uvijek četiri
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Konačno sa [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // taj posljednji primjer bio je previše četvorke.Imajmo samo četiri četvorke.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... i sad smo gotovi
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iterator koji beskrajno ponavlja element.
///
/// Ovaj `struct` kreira funkcija [`repeat()`].Pogledajte dokumentaciju za više informacija.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}