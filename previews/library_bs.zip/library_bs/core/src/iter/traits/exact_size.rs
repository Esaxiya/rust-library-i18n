/// Iterator koji zna njegovu tačnu dužinu.
///
/// Mnogi [`Iterator`] ne znaju koliko će puta ponoviti, ali neki znaju.
/// Ako iterator zna koliko puta može ponoviti, pružanje pristupa tim informacijama može biti korisno.
/// Na primjer, ako želite ponavljati unatrag, dobar početak je znati gdje je kraj.
///
/// Kada implementirate `ExactSizeIterator`, morate takođe implementirati [`Iterator`].
/// Pri tome, implementacija [`Iterator::size_hint`]*mora* vratiti tačnu veličinu iteratora.
///
/// Metoda [`len`] ima zadanu implementaciju, pa je obično ne biste trebali implementirati.
/// Međutim, možda ćete moći pružiti učinkovitiju implementaciju od zadane, tako da je poništavanje u ovom slučaju ima smisla.
///
///
/// Imajte na umu da je ovaj Portrait siguran Portrait i kao takav *ne* i *ne može* jamčiti da je vraćena dužina ispravna.
/// To znači da se `unsafe` kod **ne smije** oslanjati na ispravnost [`Iterator::size_hint`].
/// Nestabilni i nesigurni [`TrustedLen`](super::marker::TrustedLen) Portrait daje ovu dodatnu garanciju.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// // konačni raspon tačno zna koliko će puta ponoviti
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// U [module-level docs] smo implementirali [`Iterator`], `Counter`.
/// Primijenimo i `ExactSizeIterator` za to:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Preostali broj iteracija možemo lako izračunati.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // I sada to možemo koristiti!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Vraća tačnu dužinu iteratora.
    ///
    /// Implementacija osigurava da će iterator vratiti tačno `len()` više puta u odnosu na vrijednost [`Some(T)`], prije nego što vrati [`None`].
    ///
    /// Ova metoda ima zadanu implementaciju, pa je obično ne biste trebali implementirati izravno.
    /// Međutim, ako možete osigurati efikasniju implementaciju, možete to i učiniti.
    /// Za primjer pogledajte dokumente [trait-level].
    ///
    /// Ova funkcija ima iste sigurnosne garancije kao i funkcija [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// // konačni raspon tačno zna koliko će puta ponoviti
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ova je tvrdnja pretjerano odbrambena, ali provjerava invarijantu
        // zagarantovano od Portrait.
        // Da je ovaj Portrait interni rust, mogli bismo koristiti debug_assert !;assert_eq!provjerit će i sve implementacije korisnika Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Vraća `true` ako je iterator prazan.
    ///
    /// Ova metoda ima zadanu implementaciju koja koristi [`ExactSizeIterator::len()`], tako da je ne morate sami implementirati.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna upotreba:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}