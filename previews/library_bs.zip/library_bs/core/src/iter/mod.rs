//! Komponirajuća vanjska iteracija.
//!
//! Ako ste se našli s nekom vrstom kolekcije i trebate izvršiti operaciju nad elementima navedene kolekcije, brzo ćete naletjeti na 'iterators'.
//! Iteratori se često koriste u idiomatskom Rust kodu, pa je vrijedno upoznati se s njima.
//!
//! Prije objašnjavanja više, razgovarajmo o tome kako je strukturiran ovaj modul:
//!
//! # Organization
//!
//! Ovaj modul je uglavnom organiziran prema tipu:
//!
//! * [Traits] su glavni dio: ovi traits definiraju kakve vrste iteratora postoje i što s njima možete učiniti.Metode ovih traits vrijede uložiti malo dodatnog vremena za učenje.
//! * [Functions] pružiti neke korisne načine za stvaranje nekih osnovnih iteratora.
//! * [Structs] su često tipovi povratka različitih metoda na traits ovog modula.Obično ćete htjeti pogledati metodu koja kreira `struct`, a ne sam `struct`.
//! Za više detalja o tome, pogledajte '[Implementing Iterator](#implementacija-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! To je to!Idemo kopati po iteratorima.
//!
//! # Iterator
//!
//! Srce i duša ovog modula je [`Iterator`] Portrait.Jezgra [`Iterator`] izgleda ovako:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator ima metodu [`next`], koja kada se pozove, vraća [`Opcija`]`<Item>`.
//! [`next`] vratit će [`Some(Item)`] sve dok postoje elementi, a nakon što se svi iscrpe, vratit će `None` da označi da je iteracija završena.
//! Pojedinačni iteratori mogu odlučiti da nastave iteraciju, pa tako ponovno pozivanje [`next`] u nekom trenutku može ili ne mora početi vraćati [`Some(Item)`] (na primjer, pogledajte [`TryIter`]).
//!
//!
//! Puna definicija [`Iterator`] uključuje i brojne druge metode, ali to su zadane metode, izgrađene na vrhu [`next`], pa ih dobivate besplatno.
//!
//! Iteratori su također sastavni i uobičajeno ih je povezati da bi se obavili složeniji oblici obrade.Pogledajte odeljak [Adapters](#adapters) ispod za više detalja.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tri oblika ponavljanja
//!
//! Tri su uobičajene metode koje mogu kreirati iteratore iz kolekcije:
//!
//! * `iter()`, koji se ponavlja kroz `&T`.
//! * `iter_mut()`, koji se ponavlja kroz `&mut T`.
//! * `into_iter()`, koji se ponavlja kroz `T`.
//!
//! Razne stvari u standardnoj biblioteci mogu implementirati jednu ili više od tri, gdje je to prikladno.
//!
//! # Implementacijski iterator
//!
//! Stvaranje vlastitog iteratora uključuje dva koraka: stvaranje `struct` koji će zadržati stanje iteratora, a zatim implementacija [`Iterator`] za taj `struct`.
//! Zbog toga u ovom modulu postoji toliko `struktura`: postoji po jedan za svaki iterator i adapter iteratora.
//!
//! Napravimo iterator po imenu `Counter` koji broji od `1` do `5`:
//!
//! ```
//! // Prvo, struktura:
//!
//! /// Iterator koji broji od jedan do pet
//! struct Counter {
//!     count: usize,
//! }
//!
//! // želimo da naše brojanje započne u jedan, pa dodajmo new() metodu u pomoć.
//! // Ovo nije strogo potrebno, ali je zgodno.
//! // Imajte na umu da `count` započinjemo s nulom, a u nastavku ćemo vidjeti zašto u implementaciji `next()`'s.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Zatim implementiramo `Iterator` za naš `Counter`:
//!
//! impl Iterator for Counter {
//!     // računat ćemo s uzizom
//!     type Item = usize;
//!
//!     // next() je jedina potrebna metoda
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Povećajte naše brojanje.Zbog toga smo započeli s nulom.
//!         self.count += 1;
//!
//!         // Provjerite jesmo li završili s brojanjem ili nismo.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // I sada to možemo koristiti!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Pozivanje [`next`] na ovaj način se ponavlja.Rust ima konstrukciju koja može pozivati [`next`] na vašem iteratoru, sve dok ne dosegne `None`.Idemo dalje na to.
//!
//! Također imajte na umu da `Iterator` pruža zadanu implementaciju metoda kao što su `nth` i `fold` koje interno pozivaju `next`.
//! Međutim, također je moguće napisati prilagođenu implementaciju metoda poput `nth` i `fold` ako ih iterator može izračunati efikasnije bez pozivanja `next`.
//!
//! # `for` petlje i `IntoIterator`
//!
//! Sintaksa petlje Rust `for` zapravo je šećer za iteratore.Evo osnovnog primjera `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ovo će ispisati brojeve od jedan do pet, svaki na svojoj liniji.Ali ovdje ćete primijetiti nešto: na našem vector nikada nismo ništa zvali da proizvedemo iterator.Šta daje?
//!
//! U standardnoj biblioteci postoji Portrait za pretvaranje nečega u iterator: [`IntoIterator`].
//! Ovaj Portrait ima jednu metodu, [`into_iter`], koja pretvara stvar koja implementira [`IntoIterator`] u iterator.
//! Pogledajmo ponovo tu `for` petlju i u šta je prevodilac pretvara:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ovo uklanja šećere u:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Prvo pozivamo `into_iter()` na vrijednost.Zatim se podudaramo na iteratoru koji se vraća, pozivajući [`next`] iznova i iznova dok ne vidimo `None`.
//! U tom trenutku smo `break` izašli iz petlje i završili smo s ponavljanjem.
//!
//! Ovdje je još jedan suptilan dio: standardna biblioteka sadrži zanimljivu implementaciju [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Drugim riječima, svi [`Iterator`] implementiraju [`IntoIterator`], tako što se samo vrate.To znači dvije stvari:
//!
//! 1. Ako pišete [`Iterator`], možete ga koristiti sa petljom `for`.
//! 2. Ako kreirate kolekciju, implementacija [`IntoIterator`] za nju omogućit će upotrebu vaše kolekcije s petljom `for`.
//!
//! # Iteracija putem reference
//!
//! Budući da [`into_iter()`] uzima `self` po vrijednosti, upotreba petlje `for` za iteraciju preko kolekcije troši tu kolekciju.Često ćete možda htjeti ponoviti kolekciju bez da je potrošite.
//! Mnoge kolekcije nude metode koje pružaju iteratore preko referenci, konvencionalno nazvanih `iter()` i `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` je još uvijek u vlasništvu ove funkcije.
//! ```
//!
//! Ako tip kolekcije `C` pruža `iter()`, obično također implementira `IntoIterator` za `&C`, s implementacijom koja samo poziva `iter()`.
//! Slično tome, kolekcija `C` koja pruža `iter_mut()` generalno implementira `IntoIterator` za `&mut C` delegiranjem na `iter_mut()`.Ovo omogućava prikladnu stenografiju:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // isto kao i `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // isto kao i `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Iako mnoge kolekcije nude `iter()`, ne nude sve `iter_mut()`.
//! Na primjer, mutiranje tipki [`HashSet<T>`] ili [`HashMap<K, V>`] moglo bi zbirku dovesti u nedosljedno stanje ako se promijene hashovi ključeva, pa ove kolekcije nude samo `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcije koje uzimaju [`Iterator`] i vraćaju drugi [`Iterator`] često se nazivaju 'iteratorskim adapterima', jer su oblik 'adaptera
//! pattern'.
//!
//! Uobičajeni adapteri iteratora uključuju [`map`], [`take`] i [`filter`].
//! Više informacija potražite u njihovoj dokumentaciji.
//!
//! Ako je adapter iteratora panics, iterator će biti u nespecificiranom (ali memorijski sigurnom) stanju.
//! Također se ne garantira da će ovo stanje ostati isto u svim verzijama Rust, pa se izbjegavajte oslanjati se na tačne vrijednosti koje je iterator vratio u paniku.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratori (i iterator [adapters](#adapters)) su *lijeni*. To znači da samo stvaranje iteratora ne znači _do_. Ništa se zapravo ne događa dok ne pozovete [`next`].
//! To ponekad dovodi do zabune pri stvaranju iteratora isključivo zbog njegovih nuspojava.
//! Na primjer, metoda [`map`] poziva zatvaranje svakog elementa koji se ponavlja:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ovo neće ispisati nikakve vrijednosti, jer smo samo kreirali iterator, umjesto da ga koristimo.Kompajler će nas upozoriti na takvo ponašanje:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idealan način pisanja [`map`] za njegove nuspojave je upotreba petlje `for` ili pozivanje metode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Još jedan uobičajeni način procjene iteratora je upotreba metode [`collect`] za stvaranje nove kolekcije.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratori ne moraju biti konačni.Kao primjer, otvoreni opseg je beskonačni iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Uobičajeno je koristiti adapter Xeteratora za pretvaranje beskonačnog iteratora u konačni:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ovo će ispisati brojeve od `0` do `4`, svaki na svojoj liniji.
//!
//! Imajte na umu da metode na beskonačnim iteratorima, čak i one za koje se rezultat može matematički odrediti u ograničenom vremenu, možda neće prestati.
//! Konkretno, metode poput [`min`], koje u općenitom slučaju zahtijevaju obilaženje svakog elementa u iteratoru, vjerojatno se neće uspješno vratiti ni za jedan beskonačni iterator.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O ne!Beskonačna petlja!
//! // `ones.min()` uzrokuje beskonačnu petlju, pa nećemo doći do ove točke!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;