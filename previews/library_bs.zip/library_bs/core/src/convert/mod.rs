//! Traits za pretvorbu između tipova.
//!
//! traits u ovom modulu pružaju način za konverziju iz jednog u drugi tip.
//! Svaki Portrait služi u različite svrhe:
//!
//! - Primijenite [`AsRef`] Portrait za jeftine pretvorbe referenca u referencu
//! - Primijenite [`AsMut`] Portrait za jeftine konverzije koje se mogu mijenjati u promjenjive
//! - Primijenite [`From`] Portrait za trošenje pretvorbe vrijednosti u vrijednost
//! - Primijenite [`Into`] Portrait za konzumiranje pretvorbe vrijednosti u vrijednost u tipove izvan trenutnog crate
//! - [`TryFrom`] i [`TryInto`] traits ponašaju se poput [`From`] i [`Into`], ali bi ih trebalo implementirati kada konverzija ne može uspjeti.
//!
//! traits u ovom modulu često se koriste kao Portrait bounds za generičke funkcije tako da su podržani argumenti više tipova.Za primjere pogledajte dokumentaciju svakog Portrait.
//!
//! Kao autor biblioteke, uvijek biste trebali radije implementirati [`From<T>`][`From`] ili [`TryFrom<T>`][`TryFrom`] umjesto [`Into<U>`][`Into`] ili [`TryInto<U>`][`TryInto`], jer [`From`] i [`TryFrom`] pružaju veću fleksibilnost i nude ekvivalentne implementacije [`Into`] ili [`TryInto`] besplatno, zahvaljujući objedinjenoj implementaciji u standardnoj biblioteci.
//! Kada ciljate verziju prije Rust 1.41, možda će biti potrebno implementirati [`Into`] ili [`TryInto`] izravno prilikom konverzije u tip izvan trenutnog crate.
//!
//! # Generičke implementacije
//!
//! - [`AsRef`] i [`AsMut`] automatsko postavljanje reference ako je unutarnji tip referenca
//! - [`From`]`<U>za T` podrazumijeva [`Into`]`</u><T><U>za U`</u>
//! - [`TryFrom`]`<U>za T` podrazumijeva [`TryInto`]`</u><T><U>za U`</u>
//! - [`From`] i [`Into`] su refleksivni, što znači da sve vrste mogu same `into` i same `from`
//!
//! Pogledajte svaki Portrait za primjere upotrebe.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funkcija identiteta.
///
/// O ovoj funkciji je važno napomenuti dvije stvari:
///
/// - Nije uvijek ekvivalent zatvaraču poput `|x| x`, jer zatvaranje može prisiliti `x` na drugi tip.
///
/// - Premješta ulaz `x` proslijeđen u funkciju.
///
/// Iako bi moglo izgledati čudno imati funkciju koja samo vraća natrag unos, postoji nekoliko zanimljivih upotreba.
///
///
/// # Examples
///
/// Korištenje `identity` da ne radite ništa u nizu drugih zanimljivih funkcija:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Pretvarajmo se da je dodavanje jedne zanimljive funkcije.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Korištenje `identity` kao osnovnog slučaja "do nothing" u uvjetnom:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Radite još zanimljivih stvari ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Korištenje `identity` za zadržavanje `Some` inačica iteratora `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Koristi se za jeftinu konverziju referenca u referencu.
///
/// Ovaj Portrait sličan je [`AsMut`] koji se koristi za pretvaranje između promjenjivih referenci.
/// Ako trebate napraviti skupu konverziju, bolje je implementirati [`From`] s tipom `&T` ili napisati prilagođenu funkciju.
///
/// `AsRef` ima isti potpis kao [`Borrow`], ali [`Borrow`] se razlikuje u nekoliko aspekata:
///
/// - Za razliku od `AsRef`, [`Borrow`] ima pokriveni impl za bilo koji `T` i može se koristiti za prihvaćanje reference ili vrijednosti.
/// - [`Borrow`] takođe zahtijeva da su [`Hash`], [`Eq`] i [`Ord`] za posuđenu vrijednost jednake onima u vrijednosti u vlasništvu.
/// Iz tog razloga, ako želite posuditi samo jedno polje strukture, možete implementirati `AsRef`, ali ne i [`Borrow`].
///
/// **Note: Ovaj Portrait ne smije propasti **.Ako pretvorba ne može uspjeti, upotrijebite namjenski metod koji vraća [`Option<T>`] ili [`Result<T, E>`].
///
/// # Generičke implementacije
///
/// - `AsRef` automatske preusmjeravanja ako je unutarnji tip referenca ili promjenjiva referenca (npr .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Korištenjem Portrait bounds možemo prihvatiti argumente različitih tipova sve dok se mogu pretvoriti u navedeni tip `T`.
///
/// Na primjer: Stvaranjem generičke funkcije koja uzima `AsRef<str>` izražavamo da želimo prihvatiti sve reference koje se mogu pretvoriti u [`&str`] kao argument.
/// Budući da i [`String`] i [`&str`] implementiraju `AsRef<str>`, obje možemo prihvatiti kao ulazni argument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Izvodi pretvorbu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Koristi se za izvršavanje jeftine konverzije referentne varijable koja se može mijenjati.
///
/// Ovaj Portrait sličan je [`AsRef`], ali se koristi za konverziju između promjenjivih referenci.
/// Ako trebate napraviti skupu konverziju, bolje je implementirati [`From`] s tipom `&mut T` ili napisati prilagođenu funkciju.
///
/// **Note: Ovaj Portrait ne smije propasti **.Ako pretvorba ne može uspjeti, upotrijebite namjenski metod koji vraća [`Option<T>`] ili [`Result<T, E>`].
///
/// # Generičke implementacije
///
/// - `AsMut` automatske preusmjeravanja ako je unutarnji tip promjenjiva referenca (npr .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Korištenjem `AsMut` kao Portrait bound za generičku funkciju možemo prihvatiti sve izmjenjive reference koje se mogu pretvoriti u tip `&mut T`.
/// Budući da [`Box<T>`] implementira `AsMut<T>`, možemo napisati funkciju `add_one` koja uzima sve argumente koji se mogu pretvoriti u `&mut u64`.
/// Budući da [`Box<T>`] implementira `AsMut<T>`, `add_one` prihvaća i argumente tipa `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Izvodi pretvorbu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Pretvorba vrijednosti u vrijednost koja troši ulaznu vrijednost.Suprotno od [`From`].
///
/// Treba izbjegavati primjenu [`Into`] i umjesto toga implementirati [`From`].
/// Implementacija [`From`] automatski pruža implementaciju [`Into`] zahvaljujući opštoj implementaciji u standardnoj biblioteci.
///
/// Radije koristite [`Into`] nad [`From`] kada specificirate Portrait bounds za generičku funkciju kako biste osigurali da se mogu koristiti i tipovi koji samo implementiraju [`Into`].
///
/// **Note: Ovaj Portrait ne smije propasti **.Ako konverzija ne može uspjeti, upotrijebite [`TryInto`].
///
/// # Generičke implementacije
///
/// - [`From`]`<T>jer U` podrazumijeva `Into<U> for T`
/// - [`Into`] je refleksivan, što znači da je implementiran `Into<T> for T`
///
/// # Implementacija [`Into`] za pretvorbu u vanjske tipove u starim verzijama Rust
///
/// Prije Rust 1.41, ako tip odredišta nije bio dio trenutnog crate, tada niste mogli izravno implementirati [`From`].
/// Na primjer, uzmite ovaj kod:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ovo se neće uspjeti kompajlirati u starijim verzijama jezika jer su Rust-ova pravila o sirotiranju bila malo stroža.
/// Da biste to zaobišli, možete direktno implementirati [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Važno je shvatiti da [`Into`] ne pruža implementaciju [`From`] (kao što to [`From`] čini sa [`Into`]).
/// Stoga, uvijek biste trebali pokušati implementirati [`From`], a zatim se vratiti na [`Into`] ako [`From`] nije moguće implementirati.
///
/// # Examples
///
/// [`String`] implementira [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Da bismo izrazili da želimo da generička funkcija uzima sve argumente koji se mogu pretvoriti u navedeni tip `T`, možemo koristiti Portrait bound od [`Into`]`<T>`.
///
/// Na primjer: Funkcija `is_hello` uzima sve argumente koji se mogu pretvoriti u [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Izvodi pretvorbu.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Koristi se za pretvaranje vrijednosti u vrijednost dok troši ulaznu vrijednost.To je recipročno kao [`Into`].
///
/// Uvijek treba preferirati implementaciju `From` u odnosu na [`Into`], jer implementacija `From` automatski pruža implementaciju [`Into`] zahvaljujući opštoj implementaciji u standardnoj biblioteci.
///
///
/// Primijenite [`Into`] samo kada ciljate verziju prije Rust 1.41 i pretvarate u tip izvan trenutnog crate.
/// `From` nije mogao izvršiti ove vrste konverzija u ranijim verzijama zbog pravila siročišta Rust.
/// Pogledajte [`Into`] za više detalja.
///
/// Radije koristite [`Into`] nego `From` kada specificirate Portrait bounds na generičkoj funkciji.
/// Na taj se način tipovi koji direktno implementiraju [`Into`] mogu koristiti i kao argumenti.
///
/// `From` je takođe vrlo koristan prilikom izvođenja rukovanja greškama.Kada se konstruira funkcija koja može propasti, tip povratka će obično biti oblika `Result<T, E>`.
/// `From` Portrait pojednostavljuje rukovanje greškama dopuštajući funkciji da vrati jedan tip greške koji obuhvaća više vrsta grešaka.Pogledajte odjeljak "Examples" i [the book][book] za više detalja.
///
/// **Note: Ovaj Portrait ne smije propasti **.Ako konverzija ne može uspjeti, upotrijebite [`TryFrom`].
///
/// # Generičke implementacije
///
/// - `From<T> for U` implicira [`Into`]`<U>za T`</u>
/// - `From` je refleksivan, što znači da je implementiran `From<T> for T`
///
/// # Examples
///
/// [`String`] implementira `From<&str>`:
///
/// Eksplicitna konverzija iz `&str` u String vrši se na sljedeći način:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Prilikom rukovanja greškama često je korisno implementirati `From` za svoj tip greške.
/// Pretvaranjem osnovnih tipova grešaka u naš vlastiti prilagođeni tip greške koji obuhvaća osnovni tip greške, možemo vratiti jedan tip greške bez gubitka podataka o osnovnom uzroku.
/// Operator '?' automatski pretvara osnovni tip greške u naš prilagođeni tip greške pozivanjem `Into<CliError>::into` koji se automatski pruža prilikom implementacije `From`.
/// Kompajler tada zaključuje koju implementaciju `Into` treba koristiti.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Izvodi pretvorbu.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Pokušaj konverzije koja troši `self`, što može biti skupo ili ne.
///
/// Autori biblioteka obično ne bi trebali direktno implementirati ovaj Portrait, već bi trebali radije implementirati [`TryFrom`] Portrait, koji nudi veću fleksibilnost i pruža ekvivalentnu implementaciju `TryInto` besplatno, zahvaljujući opštoj implementaciji u standardnoj biblioteci.
/// Za više informacija o tome pogledajte dokumentaciju za [`Into`].
///
/// # Implementacija `TryInto`
///
/// Ovo trpi ista ograničenja i obrazloženja kao i implementacija [`Into`], pogledajte tamo za detalje.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Tip se vraća u slučaju pogreške pretvorbe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Izvodi pretvorbu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Jednostavne i sigurne pretvorbe tipa koje pod određenim okolnostima mogu kontrolirano propasti.To je recipročno kao [`TryInto`].
///
/// Ovo je korisno kada radite konverziju tipa koja može trivijalno uspjeti, ali možda će trebati i posebno rukovanje.
/// Na primjer, ne postoji način za pretvaranje [`i64`] u [`i32`] pomoću [`From`] Portrait, jer [`i64`] može sadržavati vrijednost koju [`i32`] ne može predstavljati, pa bi pretvorba izgubila podatke.
///
/// To se može riješiti skraćivanjem [`i64`] na [`i32`] (u osnovi davanjem vrijednosti [`i64`] modula [`i32::MAX`]) ili jednostavnim vraćanjem [`i32::MAX`] ili nekom drugom metodom.
/// [`From`] Portrait namijenjen je savršenim konverzijama, tako da `TryFrom` Portrait informira programera kada pretvorba tipa može poći loše i dopušta im da odluče kako to riješiti.
///
/// # Generičke implementacije
///
/// - `TryFrom<T> for U` podrazumijeva [`TryInto`]`<U>za T`</u>
/// - [`try_from`] je refleksivan, što znači da je `TryFrom<T> for T` implementiran i ne može uspjeti-pridruženi tip `Error` za pozivanje `T::try_from()` na vrijednosti tipa `T` je [`Infallible`].
/// Kada se stabilizira tip [`!`], [`Infallible`] i [`!`] bit će ekvivalentni.
///
/// `TryFrom<T>` može se implementirati na sljedeći način:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kao što je opisano, [`i32`] implementira `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Tiho skraćuje `big_number`, zahtijeva otkrivanje i rukovanje skraćivanjem nakon činjenice.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Vraća grešku jer je `big_number` prevelik da bi mogao stati u `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Vraća `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Tip se vraća u slučaju pogreške pretvorbe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Izvodi pretvorbu.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// OPŠTI IMPLS
////////////////////////////////////////////////////////////////////////////////

// Kako se dizala preko&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Kao liftovi preko &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): zamijenite gornje implice za&/&mut sljedećim općenitijim:
// // Kao liftovi iznad Derefa
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Veličine> AsRef <U>za D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut se podiže preko &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): zamijenite gornji impl za &mut sljedećim općenitijim:
// // AsMut se podiže iznad DerefMuta
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Veličine> AsMut <U>za D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Od implicira Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (a time i Into) je refleksivan
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Napomena o stabilnosti:** Ovaj impl još ne postoji, ali mi smo "reserving space" da bismo ga dodali u future.
/// Pogledajte [rust-lang/rust#64715][#64715] za detalje.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): umjesto toga napravite principijelni popravak.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom podrazumijeva TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Nepogrešive pretvorbe semantički su ekvivalentne pogrešnim pretvorbama s nenaseljenim tipom pogreške.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONSKI IMPL
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TIP GREŠKE BEZ GREŠKE
////////////////////////////////////////////////////////////////////////////////

/// Tip greške za greške koje se nikada ne mogu dogoditi.
///
/// Budući da ovaj nabrajanje nema varijantu, vrijednost ovog tipa zapravo nikada ne može postojati.
/// Ovo može biti korisno za generičke API-je koji koriste [`Result`] i parameteriziraju tip greške, kako bi naznačili da je rezultat uvijek [`Ok`].
///
/// Na primjer, [`TryFrom`] Portrait (konverzija koja vraća [`Result`]) ima pokrivenu implementaciju za sve tipove gdje postoji obrnuta implementacija [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future kompatibilnost
///
/// Ovaj nabrajanje ima istu ulogu kao [the `!`“never”type][never], koji je nestabilan u ovoj verziji Rust.
/// Kada se `!` stabilizira, planiramo napraviti `Infallible` kao pseudonim tipa:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... i na kraju odbaci `Infallible`.
///
/// Međutim, postoji jedan slučaj kada se sintaksa `!` može koristiti prije nego što se `!` stabilizira kao punopravni tip: u položaju povratnog tipa funkcije.
/// Konkretno, moguće su implementacije za dva različita tipa pokazivača funkcija:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kako je `Infallible` enum, ovaj kôd je važeći.
/// Međutim, kada `Infallible` postane pseudonim za never type, dva `impl-a počet će se preklapati i stoga će biti zabranjena jezičkim pravilima koherentnosti Portrait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}