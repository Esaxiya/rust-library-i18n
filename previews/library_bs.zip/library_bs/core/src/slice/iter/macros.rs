//! Makronaredbe koje koriste iteratori rezanja.

// Umetanje is_empty i len čini veliku razliku u performansama
macro_rules! is_empty {
    // Način na koji kodiramo dužinu ZST iteratora, ovo djeluje i za ZST i za ne-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Da bismo se riješili nekih provjera granica (pogledajte `position`), izračunavamo dužinu na pomalo neočekivan način.
// (Testirano `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ponekad se koristimo u nesigurnom bloku

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ovaj _cannot_ koristi `unchecked_sub`, jer ovisimo o umotavanju da predstavimo dužinu dugih ZST iteratora presjeka.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Znamo da `start <= end` može biti bolji od `offset_from`, koji mora biti potpisan.
            // Postavljanjem odgovarajućih zastavica ovdje to možemo reći LLVM-u, što mu pomaže ukloniti provjere ograničenja.
            // SIGURNOST: Prema vrsti invarijantne, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Rekavši LLVM-u da su pokazivači odvojeni tačnim višekratnikom veličine tipa, on može optimizirati `len() == 0` do `start == end` umjesto `(end - start) < size`.
            //
            // SIGURNOST: Prema vrsti invarijantne, pokazivači su poravnati tako da
            //         udaljenost između njih mora biti višekratnik veličine pointa
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Zajednička definicija iteratora `Iter` i `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Vraća prvi element i pomiče početak iteratora prema naprijed za 1.
        // Značajno poboljšava performanse u odnosu na ugrađenu funkciju.
        // Iterator ne smije biti prazan.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Vraća zadnji element i pomiče kraj iteratora unatrag za 1.
        // Značajno poboljšava performanse u odnosu na ugrađenu funkciju.
        // Iterator ne smije biti prazan.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Smanjuje iterator kada je T ZST, pomicanjem kraja iteratora unazad za `n`.
        // `n` ne smije prelaziti `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pomoćna funkcija za stvaranje izreza iz iteratora.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIGURNOST: iterator je stvoren od kriška s pokazivačem
                // `self.ptr` i dužine `len!(self)`.
                // To garantira da su ispunjeni svi preduvjeti za `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Pomoćna funkcija za pomicanje početka iteratora prema naprijed po elementima `offset`, vraćajući stari početak.
            //
            // Nesigurno jer pomak ne smije premašiti `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIGURNOST: pozivatelj garantuje da `offset` ne prelazi `self.len()`,
                    // tako da je ovaj novi pokazivač unutar `self` i stoga garantuje da neće biti null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pomoćna funkcija za pomicanje kraja iteratora unazad pomoću `offset` elemenata, vraćajući novi kraj.
            //
            // Nesigurno jer pomak ne smije premašiti `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIGURNOST: pozivatelj garantuje da `offset` ne prelazi `self.len()`,
                    // koji garantovano neće preplaviti `isize`.
                    // Također, rezultirajući pokazivač nalazi se u granicama `slice`, koji ispunjava ostale zahtjeve za `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // može se implementirati s kriškama, ali ovo izbjegava provjere granica

                // SIGURNOST: Pozivi `assume` sigurni su od početnog pokazivača odsječka
                // mora biti ne-null, a kriške nad ne-ZST-ovima također moraju imati non-null krajnji pokazivač.
                // Poziv na `next_unchecked!` je siguran jer provjeravamo je li iterator prvo prazan.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ovaj iterator je sada prazan.
                    if mem::size_of::<T>() == 0 {
                        // Moramo to učiniti na ovaj način jer `ptr` možda nikada neće biti 0, ali `end` može biti (zbog umotavanja).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIGURNOST: kraj ne može biti 0 ako T nije ZST, jer ptr nije 0, a end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIGURNOST: U granicama smo.`post_inc_start` čini pravu stvar čak i za ZST-ove.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            // Takođe, `assume` izbjegava provjeru granica.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIGURNOST: Garantovano nam je da smo u granicama invarijanta petlje:
                        // kada `i >= n`, `self.next()` vraća `None` i petlja se prekida.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Nadjačavamo zadanu implementaciju koja koristi `try_fold`, jer ova jednostavna implementacija generira manje LLVM IR-a i brža je za kompajliranje.
            // Takođe, `assume` izbjegava provjeru granica.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIGURNOST: `i` mora biti niži od `n`, jer počinje s `n`
                        // i samo se smanjuje.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIGURNOST: pozivatelj mora garantirati da je `i` u granicama
                // temeljni presjek, tako da `i` ne može prelijevati `isize`, a vraćene reference zajamčeno se odnose na element presjeka i na taj način se jamči da su valjane.
                //
                // Također imajte na umu da pozivatelj također garantira da nas nikada više neće pozvati s istim indeksom i da se neće pozvati druge metode koje će pristupiti ovoj podrezići, tako da vrijedi da vraćena referenca bude promjenjiva u slučaju
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // može se implementirati s kriškama, ali ovo izbjegava provjere granica

                // SIGURNOST: `assume` pozivi su sigurni jer početni pokazivač kriška mora biti ne-null,
                // a kriške nad ne-ZST-ovima također moraju imati krajnji pokazivač koji nije null.
                // Poziv na `next_back_unchecked!` je siguran jer provjeravamo je li iterator prvo prazan.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ovaj iterator je sada prazan.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIGURNOST: U granicama smo.`pre_dec_end` čini pravu stvar čak i za ZST-ove.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}