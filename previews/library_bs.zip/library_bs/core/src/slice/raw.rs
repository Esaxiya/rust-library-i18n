//! Besplatne funkcije za kreiranje `&[T]` i `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Formira presjek od pokazivača i dužine.
///
/// Argument `len` je broj **elemenata**, a ne broj bajtova.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uslova:
///
/// * `data` mora biti [valid] za čitanje za `len * mem::size_of::<T>()` mnogo bajtova i mora biti pravilno poravnato.To posebno znači:
///
///     * Čitav opseg memorije ove kriške mora biti sadržan u jednom dodijeljenom objektu!
///       Kriške se nikada ne mogu proširiti na više dodijeljenih objekata.Pogledajte [below](#incorrect-usage) za primjer pogrešno ne uzimajući ovo u obzir.
///     * `data` mora biti nula i poravnati čak i za kriške nulte duljine.
///     Jedan od razloga za to je taj što se optimizacije rasporeda nabrajanja mogu oslanjati na poravnanje referenci (uključujući kriške bilo koje duljine) i one koje nisu nule kako bi se razlikovale od ostalih podataka.
///     Pomoću [`NonNull::dangling()`] možete dobiti pokazivač koji je upotrebljiv kao `data` za kriške nulte dužine.
///
/// * `data` mora ukazivati na `len` uzastopno pravilno inicijalizirane vrijednosti tipa `T`.
///
/// * Memorija na koju se vraća vraćeni odsječak ne smije se mutirati za vrijeme trajanja `'a`, osim unutar `UnsafeCell`.
///
/// * Ukupna veličina kriška `len * mem::size_of::<T>()` ne smije biti veća od `isize::MAX`.
///   Pogledajte sigurnosnu dokumentaciju za [`pointer::offset`].
///
/// # Caveat
///
/// Životni vijek vraćenog kriška zaključuje se iz njegove upotrebe.
/// Da biste spriječili slučajnu zlouporabu, predlaže se da se životni vijek veže za bilo koji životni vijek izvora koji je siguran u kontekstu, na primjer pružanjem pomoćne funkcije koja uzima životni vijek vrijednosti hosta za presjek ili eksplicitnom bilješkom.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestuje krišku za jedan element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Netačna upotreba
///
/// Sljedeća funkcija `join_slices` je **nezvučna** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Gornja tvrdnja osigurava da su `fst` i `snd` susjedni, ali možda će i dalje biti sadržani u _different allocated objects_, u tom slučaju je stvaranje ovog kriška nedefinirano ponašanje.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` i `b` su različiti dodijeljeni objekti ...
///     let a = 42;
///     let b = 27;
///     // ... koji se bez obzira na to mogu smjestiti u sjećanje: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Obavlja istu funkcionalnost kao [`from_raw_parts`], osim što se vraća promjenjivi dio.
///
/// # Safety
///
/// Ponašanje je nedefinirano ako se prekrši bilo koji od sljedećih uslova:
///
/// * `data` mora biti [valid] za čitanje i pisanje za `len * mem::size_of::<T>()` mnogo bajtova i mora biti pravilno poravnan.To posebno znači:
///
///     * Čitav opseg memorije ove kriške mora biti sadržan u jednom dodijeljenom objektu!
///       Kriške se nikada ne mogu proširiti na više dodijeljenih objekata.
///     * `data` mora biti nula i poravnati čak i za kriške nulte duljine.
///     Jedan od razloga za to je taj što se optimizacije rasporeda nabrajanja mogu oslanjati na poravnanje referenci (uključujući kriške bilo koje duljine) i one koje nisu nule kako bi se razlikovale od ostalih podataka.
///
///     Pomoću [`NonNull::dangling()`] možete dobiti pokazivač koji je upotrebljiv kao `data` za kriške nulte dužine.
///
/// * `data` mora ukazivati na `len` uzastopno pravilno inicijalizirane vrijednosti tipa `T`.
///
/// * Memoriji na koju se vraća vraćeni presjek ne smije se pristupiti preko bilo kojeg drugog pokazivača (koji nije izveden iz povratne vrijednosti) za vrijeme trajanja `'a`.
///   Pristup za čitanje i pisanje je zabranjen.
///
/// * Ukupna veličina kriška `len * mem::size_of::<T>()` ne smije biti veća od `isize::MAX`.
///   Pogledajte sigurnosnu dokumentaciju za [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Pretvara referencu na T u odsječak dužine 1 (bez kopiranja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Pretvara referencu na T u odsječak dužine 1 (bez kopiranja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}