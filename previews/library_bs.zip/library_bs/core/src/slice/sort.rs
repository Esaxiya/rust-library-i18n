//! Sortiranje kriški
//!
//! Ovaj modul sadrži algoritam sortiranja zasnovan na brzom sortu poraza uzorka Orsona Petersa, objavljenom na: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabilno sortiranje kompatibilno je s libcore-om jer ne dodjeljuje memoriju, za razliku od naše stabilne implementacije sortiranja.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nakon ispuštanja, kopije iz `src` u `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIGURNOST: Ovo je pomoćna klasa.
        //          Molimo pogledajte ispravnost upotrebe.
        //          Naime, moramo biti sigurni da se `src` i `dst` ne preklapaju kako zahtijeva `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Pomiče prvi element udesno dok ne naiđe na veći ili jednak element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURNOST: Sljedeće nesigurne operacije uključuju indeksiranje bez vezane provjere (`get_unchecked` i `get_unchecked_mut`)
    // i kopiranje memorije (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksiranje:
    //  1. Provjerili smo veličinu niza na>=2.
    //  2. Sva indeksiranja koja ćemo obaviti uvijek su između {0 <= index < len} i najviše.
    //
    // b.Kopiranje memorije
    //  1. Dobivamo pokazivače na reference za koje se garantira da su valjane.
    //  2. Oni se ne mogu preklapati jer dobivamo pokazivače na indekse razlika kriška.
    //     Naime, `i` i `i-1`.
    //  3. Ako je rez pravilno poravnan, elementi su pravilno poravnati.
    //     Odgovornost pozivatelja je osigurati da je kriška pravilno poravnana.
    //
    // Pogledajte komentare u nastavku za dodatne detalje.
    unsafe {
        // Ako su prva dva elementa u kvaru ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Pročitajte prvi element u varijabli dodijeljenoj steku.
            // Ako slijedi operacija usporedbe panics, `hole` će se ispustiti i automatski zapisati element natrag u rez.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Pomaknite `i`-ti element za jedno mjesto ulijevo, pomerajući tako rupu udesno.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` padne i tako kopira `tmp` u preostalu rupu u `v`.
        }
    }
}

/// Pomjera zadnji element ulijevo dok ne naiđe na manji ili jednak element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURNOST: Sljedeće nesigurne operacije uključuju indeksiranje bez vezane provjere (`get_unchecked` i `get_unchecked_mut`)
    // i kopiranje memorije (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksiranje:
    //  1. Provjerili smo veličinu niza na>=2.
    //  2. Sva indeksiranja koja ćemo obaviti uvijek su između `0 <= index < len-1` i najviše.
    //
    // b.Kopiranje memorije
    //  1. Dobivamo pokazivače na reference za koje se garantira da su valjane.
    //  2. Oni se ne mogu preklapati jer dobivamo pokazivače na indekse razlika kriška.
    //     Naime, `i` i `i+1`.
    //  3. Ako je rez pravilno poravnan, elementi su pravilno poravnati.
    //     Odgovornost pozivatelja je osigurati da je kriška pravilno poravnana.
    //
    // Pogledajte komentare u nastavku za dodatne detalje.
    unsafe {
        // Ako su posljednja dva elementa u kvaru ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Pročitajte posljednji element u varijabli dodijeljenoj steku.
            // Ako slijedi operacija usporedbe panics, `hole` će se ispustiti i automatski zapisati element natrag u rez.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Pomaknite `i`-ti element za jedno mjesto udesno, pomerajući tako rupu ulijevo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` padne i tako kopira `tmp` u preostalu rupu u `v`.
        }
    }
}

/// Djelomično sortira krišku pomičući nekoliko elemenata koji nisu u redu.
///
/// Vraća `true` ako je kriška sortirana na kraju.Ova funkcija je *O*(*n*) u najgorem slučaju.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimalan broj susjednih parova koji nisu u redu, a koji će se pomaknuti.
    const MAX_STEPS: usize = 5;
    // Ako je kriška kraća od ove, nemojte pomicati nijedan element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BEZBEDNOST: Već smo eksplicitno izvršili obaveznu proveru sa `i < len`.
        // Sva naša naknadna indeksiranja nalaze se samo u opsegu `0 <= index < len`
        unsafe {
            // Pronađite sljedeći par susjednih elemenata koji nisu u redu.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Jesmo li gotovi?
        if i == len {
            return true;
        }

        // Ne prebacujte elemente na kratke nizove, što košta troškove.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Zamijenite pronađeni par elemenata.To ih dovodi u ispravan redoslijed.
        v.swap(i - 1, i);

        // Pomaknite manji element ulijevo.
        shift_tail(&mut v[..i], is_less);
        // Pomaknite veći element udesno.
        shift_head(&mut v[i..], is_less);
    }

    // Nije uspio sortirati krišku u ograničenom broju koraka.
    false
}

/// Sortira rezanje pomoću sortiranja umetanja, što je *O*(*n*^ 2) najgori slučaj.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sortira `v` koristeći sortiranje, što garantuje *O*(*n*\*log(* n*)) u najgorem slučaju.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ova binarna gomila poštuje invarijantni `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Djeca `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Odaberite veće dijete.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Zaustavite se ako invarijanta vrijedi na `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Zamijenite `node` s većim djetetom, pomaknite se jedan korak prema dolje i nastavite sa prosijavanjem.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Izgradite gomilu u linearnom vremenu.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Iskočite maksimalne elemente iz gomile.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Pregrađuje `v` na elemente manje od `pivot`, nakon čega slijede elementi veći ili jednaki `pivot`.
///
///
/// Vraća broj elemenata manjih od `pivot`.
///
/// Particioniranje se izvodi blok-po-blok kako bi se smanjili troškovi operacija grananja.
/// Ova ideja je predstavljena u radu [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Broj elemenata u tipičnom bloku.
    const BLOCK: usize = 128;

    // Algoritam particioniranja ponavlja sljedeće korake do završetka:
    //
    // 1. Tragom bloka s lijeve strane identificirajte elemente veće ili jednake osovini.
    // 2. Tragom bloka s desne strane identificirajte elemente manje od osovine.
    // 3. Razmijenite identificirane elemente između lijeve i desne strane.
    //
    // Za blok elemenata čuvamo sljedeće varijable:
    //
    // 1. `block` - Broj elemenata u bloku.
    // 2. `start` - Pokažite pokazivač u `offsets` polje.
    // 3. `end` - Krajnji pokazivač u `offsets` polje.
    // 4. `offset, indeksi neispravnih elemenata unutar bloka.

    // Trenutni blok na lijevoj strani (od `l` do `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Trenutni blok na desnoj strani (od `r.sub(block_r)` to `r`).
    // SIGURNOST: U dokumentaciji za .add() posebno se navodi da je `vec.as_ptr().add(vec.len())` uvijek siguran`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kad dobijemo VLA, pokušajte radije stvoriti jedan niz dužine `min(v.len(), 2 * BLOCK) `
    // nego dva niza fiksne veličine dužine `BLOCK`.VLA-ovi mogu biti efikasniji u predmemoriji.

    // Vraća broj elemenata između pokazivača `l` (inclusive) i `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Završili smo s particioniranjem blok-po-blok kada se `l` i `r` jako približe.
        // Zatim obavimo nekoliko zakrpa kako bismo podijelili preostale elemente između.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Broj preostalih elemenata (još uvijek nije u usporedbi s osovinom).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Prilagodite veličine bloka tako da se lijevi i desni blok ne preklapaju, već se savršeno poravnaju da pokriju cijelu preostalu prazninu.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Trag `block_l` elementima s lijeve strane.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIGURNOST: Dolje navedene radnje u vezi sa sigurnošću uključuju upotrebu `offset`.
                //         Prema uvjetima koje zahtijeva funkcija, mi ih zadovoljavamo jer:
                //         1. `offsets_l` je dodijeljen stogu i stoga se smatra zasebnim dodijeljenim objektom.
                //         2. Funkcija `is_less` vraća `bool`.
                //            Emitiranje `bool` nikada neće preplaviti `isize`.
                //         3. Garantirali smo da će `block_l` biti `<= BLOCK`.
                //            Osim toga, `end_l` je u početku postavljen na početni pokazivač `offsets_` koji je deklariran na steku.
                //            Dakle, znamo da ćemo čak i u najgorem slučaju (svi pozivi `is_less` vraćaju false) imati samo 1 bajt koji prolazi kraj.
                //        Još jedna nesigurna operacija ovdje je preusmjeravanje `elem`.
                //        Međutim, `elem` je u početku bio početni pokazivač na presjek koji je uvijek valjan.
                unsafe {
                    // Usporedba bez grana.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Pratite `block_r` elemente s desne strane.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIGURNOST: Dolje navedene radnje u vezi sa sigurnošću uključuju upotrebu `offset`.
                //         Prema uvjetima koje zahtijeva funkcija, mi ih zadovoljavamo jer:
                //         1. `offsets_r` je dodijeljen stogu i stoga se smatra zasebnim dodijeljenim objektom.
                //         2. Funkcija `is_less` vraća `bool`.
                //            Emitiranje `bool` nikada neće preplaviti `isize`.
                //         3. Garantirali smo da će `block_r` biti `<= BLOCK`.
                //            Osim toga, `end_r` je u početku postavljen na početni pokazivač `offsets_` koji je deklariran na steku.
                //            Dakle, znamo da ćemo i u najgorem slučaju (svi pozivi `is_less` vraćaju se istinito) proći samo 1 bajt.
                //        Još jedna nesigurna operacija ovdje je preusmjeravanje `elem`.
                //        Međutim, `elem` je u početku bio `1 *sizeof(T)` nakon kraja i mi ga smanjujemo za `1* sizeof(T)` prije nego što mu pristupimo.
                //        Osim toga, za `block_r` je utvrđeno da je manji od `BLOCK`, a `elem` će stoga najviše ukazivati na početak rezanja.
                unsafe {
                    // Usporedba bez grana.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Broj elemenata koji nisu u redu za zamjenu između lijeve i desne strane.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Umjesto zamjene jednog para u isto vrijeme, učinkovitije je izvesti cikličku permutaciju.
            // Ovo nije strogo ekvivalentno zamjeni, ali daje sličan rezultat koristeći manje operacija memorije.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Premješteni su svi elementi koji nisu u redu u lijevom bloku.Prelazak na sljedeći blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Premješteni su svi elementi koji nisu u redu u desnom bloku.Prelazak na prethodni blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Sad ostaje samo jedan blok (bilo lijevi ili desni) s vanrednim elementima koje treba premjestiti.
    // Takvi preostali elementi mogu se jednostavno premjestiti do kraja unutar svog bloka.
    //

    if start_l < end_l {
        // Lijevi blok ostaje.
        // Premjestite njegove preostale neispravne elemente u krajnju desnicu.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Desni blok ostaje.
        // Premjestite njegove preostale neispravne elemente u krajnju lijevu stranu.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nemamo ništa drugo za napraviti, gotovi smo.
        width(v.as_mut_ptr(), l)
    }
}

/// Pregrađuje `v` na elemente manje od `v[pivot]`, nakon čega slijede elementi veći ili jednaki `v[pivot]`.
///
///
/// Vraća skup od:
///
/// 1. Broj elemenata manji od `v[pivot]`.
/// 2. Tačno ako je `v` već podijeljen.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Postavite osovinu na početak reza.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Očitajte pivot u varijablu dodijeljenu hrpi radi efikasnosti.
        // Ako slijedi operacija usporedbe panics, zaokret će se automatski zapisati natrag u rez.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Pronađite prvi par elemenata koji nisu u redu.
        let mut l = 0;
        let mut r = v.len();

        // SIGURNOST: Donja nesigurnost uključuje indeksiranje niza.
        // Kao prvo: Ovdje već vršimo provjeru granica sa `l < r`.
        // Za drugu: U početku imamo `l == 0` i `r == v.len()` i provjerili smo `l < r` pri svakoj operaciji indeksiranja.
        //                     Odavde znamo da `r` mora biti najmanje `r == l` za koji se pokazalo da vrijedi od prvog.
        unsafe {
            // Pronađite prvi element veći ili jednak osovini.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pronađite zadnji element manji od osovine.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` izlazi iz opsega i pivot (koji je varijabla dodijeljena steku) zapisuje natrag u presjek gdje je izvorno bio.
        // Ovaj korak je presudan u osiguranju sigurnosti!
        //
    };

    // Postavite osovinu između dvije particije.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Particije `v` na elemente jednake `v[pivot]` nakon kojih slijede elementi veći od `v[pivot]`.
///
/// Vraća broj elemenata jednak osovini.
/// Pretpostavlja se da `v` ne sadrži elemente manje od osovine.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Postavite osovinu na početak reza.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Očitajte pivot u varijablu dodijeljenu hrpi radi efikasnosti.
    // Ako slijedi operacija usporedbe panics, zaokret će se automatski zapisati natrag u rez.
    // SIGURNOST: Ovdje je pokazivač valjan jer je dobiven iz reference na odrezak.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Sada particionirajte krišku.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIGURNOST: Donja nesigurnost uključuje indeksiranje niza.
        // Kao prvo: Ovdje već vršimo provjeru granica sa `l < r`.
        // Za drugu: U početku imamo `l == 0` i `r == v.len()` i provjerili smo `l < r` pri svakoj operaciji indeksiranja.
        //                     Odavde znamo da `r` mora biti najmanje `r == l` za koji se pokazalo da vrijedi od prvog.
        unsafe {
            // Pronađite prvi element veći od osovine.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pronađite posljednji element jednak osovini.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Jesmo li gotovi?
            if l >= r {
                break;
            }

            // Zamijenite pronađeni par elemenata koji nisu u redu.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Pronašli smo `l` elemente jednake osovini.Dodajte 1 na račun za sam pivot.
    l + 1

    // `_pivot_guard` izlazi iz opsega i pivot (koji je varijabla dodijeljena steku) zapisuje natrag u presjek gdje je izvorno bio.
    // Ovaj korak je presudan u osiguranju sigurnosti!
}

/// Razbacuje neke elemente u pokušaju da razbije obrasce koji bi mogli uzrokovati neuravnotežene particije u brzom sortiranju.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator pseudo slučajnih brojeva iz papira "Xorshift RNGs" Georgea Marsaglie.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Uzmi slučajne brojeve po modulu ovog broja.
        // Broj se uklapa u `usize` jer `len` nije veći od `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Neki pivot kandidati bit će u blizini ovog indeksa.Randomizirajmo ih.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generirajte slučajni broj po modulu `len`.
            // Međutim, kako bismo izbjegli skupe operacije, prvo mu uzmemo modul snage dva, a zatim smanjujemo za `len` dok se ne uklapa u raspon `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` zagarantovano je manji od `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Odabire pivot u `v` i vraća indeks i `true` ako je kriška vjerojatno već sortirana.
///
/// Elementi u `v` mogu se preurediti u procesu.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimalna dužina za odabir metode medijane medijana.
    // Kraće kriške koriste jednostavnu metodu medijana-od-tri.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimalan broj zamjena koje se mogu izvršiti u ovoj funkciji.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tri indeksa u blizini kojih ćemo odabrati pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Broji ukupan broj zamjena koje ćemo izvršiti prilikom sortiranja indeksa.
    let mut swaps = 0;

    if len >= 8 {
        // Mijenja indekse tako da `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Mijenja indekse tako da `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Pronalazi medijanu `v[a - 1], v[a], v[a + 1]` i pohranjuje indeks u `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Pronađite medijane u susjedstvu `a`, `b` i `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Pronađite medijanu između `a`, `b` i `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Izvršen je maksimalan broj zamjena.
        // Šanse su da se kriška spušta ili uglavnom spušta, pa će okretanje unazad vjerojatno pomoći bržem sortiranju.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sortira `v` rekurzivno.
///
/// Ako je presjek imao prethodnika u izvornom nizu, naveden je kao `pred`.
///
/// `limit` je broj dozvoljenih neravnotežnih particija prije prelaska na `heapsort`.
/// Ako je nula, ova funkcija će se odmah prebaciti na sortiranje.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kriške do ove dužine sortiraju se pomoću sortiranja umetanjem.
    const MAX_INSERTION: usize = 20;

    // Tačno ako je posljednja particija bila razumno uravnotežena.
    let mut was_balanced = true;
    // Tačno ako zadnja particija nije promiješala elemente (kriška je već bila particionirana).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Vrlo kratke kriške sortiraju se pomoću sortiranja umetanjem.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ako je napravljeno previše loših pivot izbora, jednostavno se vratite na sortiranje kako biste garantirali `O(n * log(n))` najgori slučaj.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ako je posljednja particija bila neuravnotežena, pokušajte razbiti obrasce u rezanju miješajući neke elemente okolo.
        // Nadam se da ćemo ovaj put odabrati bolji oslonac.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Odaberite osovinu i pokušajte pogoditi je li kriška već sortirana.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ako je zadnja particija bila pristojno uravnotežena i nije miješala elemente i ako pivot odabir predviđa da je kriška vjerojatno već sortirana ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Pokušajte prepoznati nekoliko elemenata koji nisu u redu i pomaknite ih u ispravne položaje.
            // Ako se kriška na kraju potpuno sortira, gotovi smo.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ako je izabrani zaokret jednak prethodniku, to je najmanji element u presjeku.
        // Podijelite presjek na elemente jednake i elemente veće od osovine.
        // Ovaj slučaj se obično pogađa kada kriška sadrži mnogo dupliciranih elemenata.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nastavite sortirati elemente veće od osovine.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Podijelite krišku.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Podijelite krišku na `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Preokrenite se na kraću stranu samo da biste umanjili ukupan broj rekurzivnih poziva i potrošili manje prostora na stogu.
        // Zatim samo nastavite s dužom stranom (ovo je slično rekurziji repa).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sortira `v` pomoću brze sorte koja pobjeđuje uzorke, što je *O*(*n*\*log(* n*)) najgori slučaj.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortiranje nema smislenog ponašanja na tipovima nulte veličine.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ograničite broj neuravnoteženih particija na `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Za kriške do ove dužine vjerojatno je brže jednostavno ih razvrstati.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Odaberite osovinu
        let (pivot, _) = choose_pivot(v, is_less);

        // Ako je izabrani zaokret jednak prethodniku, to je najmanji element u presjeku.
        // Podijelite presjek na elemente jednake i elemente veće od osovine.
        // Ovaj slučaj se obično pogađa kada kriška sadrži mnogo dupliciranih elemenata.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ako smo prošli svoj indeks, onda smo dobri.
                if mid > index {
                    return;
                }

                // U suprotnom, nastavite sortirati elemente veće od osovine.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Podijelite krišku na `left`, `pivot` i `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ako je indeks mid==, gotovi smo, jer je partition() garantovao da su svi elementi nakon sredine veći ili jednaki sredini.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortiranje nema smislenog ponašanja na tipovima nulte veličine.Ne radi ništa.
    } else if index == v.len() - 1 {
        // Pronađite element max i postavite ga na posljednju poziciju niza.
        // Ovdje možemo slobodno koristiti `unwrap()` jer znamo da v ne smije biti prazan.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Pronađite element min i postavite ga na prvo mjesto niza.
        // Ovdje možemo slobodno koristiti `unwrap()` jer znamo da v ne smije biti prazan.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}