//! Operacije na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Provjerava jesu li svi bajtovi u ovom rezanju unutar ASCII raspona.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Provjerava jesu li dvije kriške ASCII neosjetljive na velika i mala slova.
    ///
    /// Isto kao i `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ali bez dodjeljivanja i kopiranja vremena.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Pretvara ovu krišku u svoj ASCII ekvivalent velikim slovima na mjestu.
    ///
    /// ASCII slova 'a' do 'z' mapiraju se u 'A' do 'Z', ali slova koja nisu ASCII nepromijenjena su.
    ///
    /// Da biste vratili novu veliku početnu vrijednost bez mijenjanja postojeće, upotrijebite [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Pretvara ovaj presjek u njegov ASCII mali ekvivalent na mjestu.
    ///
    /// ASCII slova 'A' do 'Z' mapiraju se u 'a' do 'z', ali slova koja nisu ASCII nepromijenjena su.
    ///
    /// Da biste vratili novu malu veličinu bez izmjene postojeće, upotrijebite [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Vraća `true` ako je bilo koji bajt u riječi `v` nenascii (>=128).
/// Izbačen iz `../str/mod.rs`, koji radi nešto slično za provjeru utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimizirani ASCII test koji će upotrijebiti usize-at-time operacije umjesto byte-at-time operacija (kada je to moguće).
///
/// Algoritam koji ovdje koristimo je prilično jednostavan.Ako je `s` prekratak, samo provjerimo svaki bajt i završimo s tim.Inače:
///
/// - Pročitajte prvu riječ s neujednačenim opterećenjem.
/// - Poravnajte pokazivač, čitajte naredne riječi do kraja poravnanim opterećenjima.
/// - Pročitajte posljednji `usize` iz `s` s neusklađenim opterećenjem.
///
/// Ako neko od ovih opterećenja proizvede nešto za što `contains_nonascii` (above) vrati istinu, tada znamo da je odgovor netačan.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ako ne bismo ništa dobili od implementacije word-a-time, vratite se na skalarnu petlju.
    //
    // To također radimo za arhitekture gdje `size_of::<usize>()` nije dovoljno poravnanje za `usize`, jer je to čudan slučaj edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Uvijek čitamo prvu riječ neusklađeno, što znači da `align_offset` jest
    // 0, ponovo bismo pročitali istu vrijednost za poravnato čitanje.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIGURNOST: Provjeravamo `len < USIZE_SIZE` gore.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // To smo provjerili gore, pomalo implicitno.
    // Imajte na umu da je `offset_to_aligned` `align_offset` ili `USIZE_SIZE`, oba su izričito potvrđena gore.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIGURNOST: word_ptr je (pravilno poravnan) ptr veličine koji koristimo za čitanje
    // srednji dio kriške.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` je indeks bajtova `word_ptr`, koji se koristi za provjere kraja petlje.
    let mut byte_pos = offset_to_aligned;

    // Provjera paranoje oko poravnanja, jer ćemo napraviti hrpu neusklađenih tereta.
    // U praksi bi to trebalo biti nemoguće, izuzev greške u `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Čitajte naredne riječi do posljednje poravnate riječi, isključujući posljednju poravnatu riječ koja će se sama kasnije izvršiti u provjeri repa, kako biste osigurali da rep uvijek bude najviše jedan `usize` za dodatni branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Provjerite zdrav razum da li je očitanje u granicama
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // I da naše pretpostavke o `byte_pos` vrijede.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIGURNOST: Znamo da je `word_ptr` pravilno poravnan (zbog
        // `align_offset`), i znamo da imamo dovoljno bajtova između `word_ptr` i kraja
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIGURNOST: Znamo taj `byte_pos <= len - USIZE_SIZE`, što znači
        // nakon ovog `add`, `word_ptr` će biti najviše jedan kraj.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Provjera ispravnosti da li je zaista ostao samo jedan `usize`.
    // To bi trebalo garantirati naše stanje petlje.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIGURNOST: Ovo se oslanja na `len >= USIZE_SIZE`, što provjeravamo na početku.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}