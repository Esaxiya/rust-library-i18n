Panics trenutnu nit.

To omogućava programu da se odmah prekine i pruži povratne informacije pozivaocu programa.
`panic!` treba koristiti kada program dostigne nepopravljivo stanje.

Ovaj makro je savršen način za potvrđivanje uvjeta u primjeru koda i u testovima.
`panic!` je usko povezan sa `unwrap` metodom i za [`Option`][ounwrap] i za [`Result`][runwrap] nabrajanja.
Obje implementacije pozivaju `panic!` kada su postavljene na [`None`] ili [`Err`] varijante.

Kada koristite `panic!()`, možete navesti korisni teret niza, koji se izrađuje koristeći sintaksu [`format!`].
To korisno opterećenje koristi se prilikom ubrizgavanja panic u pozivajuću nit Rust, što dovodi do toga da nit u potpunosti panic.

Ponašanje zadanog `std` hook, tj
kôd koji se izvodi neposredno nakon poziva panic je ispis korisnog tereta poruke na `stderr` zajedno s file/line/column informacijama o pozivu `panic!()`.

Možete zamijeniti panic hook pomoću [`std::panic::set_hook()`].
Unutar hook panic se može pristupiti kao `&dyn Any + Send`, koji sadrži `&str` ili `String` za redovite pozive `panic!()`.
Za panic sa vrijednošću drugog tipa, može se koristiti [`panic_any`].

[`Result`] enum je često bolje rješenje za oporavak od grešaka nego korištenje `panic!` makronaredbe.
Ovu makronaredbu treba koristiti za izbjegavanje nastavka s korištenjem netačnih vrijednosti, poput vanjskih izvora.
Detaljne informacije o rukovanju greškama nalaze se u [book].

Pogledajte i makronaredbu [`compile_error!`] za pojačavanje grešaka tokom kompilacije.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Trenutna implementacija

Ako je glavna nit panics, ona će završiti sve vaše niti i završiti vaš program s kodom `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





