/// Portrait za prilagođavanje ponašanja operatora `?`.
///
/// Tip koji implementira `Try` je onaj koji ima kanonski način da ga vidi u smislu dihotomije success/failure.
/// Ovaj Portrait omogućuje i izdvajanje tih vrijednosti uspjeha ili neuspjeha iz postojeće instance i stvaranje nove instance iz vrijednosti uspjeha ili neuspjeha.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Tip ove vrijednosti kada se smatra uspješnim.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Tip ove vrijednosti kada se smatra neuspjelim.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Primjenjuje operater "?".Povratak `Ok(t)` znači da bi se izvršenje trebalo normalno nastaviti, a rezultat `?` je vrijednost `t`.
    /// Povratak `Err(e)` znači da bi izvršenje trebalo branch u najunutarnjiji zatvarajući `catch`, ili povratak iz funkcije.
    ///
    /// Ako se vrati rezultat `Err(e)`, vrijednost `e` bit će "wrapped" u tipu povratka opsega koji obuhvaća (koji sam mora implementirati `Try`).
    ///
    /// Konkretno, vraća se vrijednost `X::from_error(From::from(e))`, gdje je `X` tip povratka funkcije zatvaranja.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Obmotajte vrijednost greške da biste konstruirali kompozitni rezultat.
    /// Na primjer, `Result::Err(x)` i `Result::from_error(x)` su ekvivalentni.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Obmotajte OK vrijednost da biste konstruirali kompozitni rezultat.
    /// Na primjer, `Result::Ok(x)` i `Result::from_ok(x)` su ekvivalentni.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}