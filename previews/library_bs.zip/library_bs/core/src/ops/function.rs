/// Verzija operatora poziva koja uzima nepromjenjivi prijemnik.
///
/// Primjerci `Fn` mogu se pozivati više puta bez stanja mutiranja.
///
/// *Ovaj Portrait (`Fn`) ne treba brkati sa [function pointers] (`fn`).*
///
/// `Fn` implementira se automatski zatvaračima koji uzimaju samo nepromjenjive reference na zarobljene varijable ili uopće ne bilježe ništa, kao i (safe) [function pointers] (uz neke napomene, pogledajte njihovu dokumentaciju za više detalja).
///
/// Pored toga, za bilo koji tip `F` koji implementira `Fn`, `&F` takođe implementira `Fn`.
///
/// Budući da su i [`FnMut`] i [`FnOnce`] supersretine `Fn`, bilo koja instanca `Fn` može se koristiti kao parametar gdje se očekuje [`FnMut`] ili [`FnOnce`].
///
/// Koristite `Fn` kao vezan kada želite prihvatiti parametar funkcijskog tipa i trebate ga pozivati više puta i bez mutirajućih stanja (npr. Kada ga istovremeno pozivate).
/// Ako vam nisu potrebni tako strogi zahtjevi, koristite [`FnMut`] ili [`FnOnce`] kao ograničenja.
///
/// Pogledajte [chapter on closures in *The Rust Programming Language*][book] za neke dodatne informacije o ovoj temi.
///
/// Takođe treba napomenuti posebnu sintaksu za `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Oni koji su zainteresirani za tehničke detalje mogu se pozvati na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Pozivanje zatvaranja
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Korištenje `Fn` parametra
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se regex može osloniti na taj `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Izvodi operaciju poziva.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Verzija operatora poziva koja uzima promenljivi prijemnik.
///
/// Primjerci `FnMut` mogu se pozivati više puta i mogu mijenjati stanje.
///
/// `FnMut` implementira se automatski zatvaračima koji uzimaju promjenjive reference na zarobljene varijable, kao i sve tipove koji implementiraju [`Fn`], npr. (safe) [function pointers] (jer je `FnMut` supersrait [`Fn`]).
/// Pored toga, za bilo koji tip `F` koji implementira `FnMut`, `&mut F` takođe implementira `FnMut`.
///
/// Budući da je [`FnOnce`] supersretit `FnMut`, bilo koja instanca `FnMut` može se koristiti tamo gdje se očekuje [`FnOnce`], a budući da je [`Fn`] podportret `FnMut`, bilo koja instanca [`Fn`] se može koristiti tamo gdje se očekuje `FnMut`.
///
/// Koristite `FnMut` kao vezanu kada želite prihvatiti parametar funkcijskog tipa i trebate ga više puta pozivati, a istovremeno mu dopuštati mutiranje stanja.
/// Ako ne želite da parametar mutira stanje, koristite [`Fn`] kao vezan;ako ga ne morate pozivati više puta, koristite [`FnOnce`].
///
/// Pogledajte [chapter on closures in *The Rust Programming Language*][book] za neke dodatne informacije o ovoj temi.
///
/// Takođe treba napomenuti posebnu sintaksu za `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Oni koji su zainteresirani za tehničke detalje mogu se pozvati na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Pozivanje zamenljivog hvatanja zatvaranja
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Korištenje `FnMut` parametra
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se regex može osloniti na taj `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Izvodi operaciju poziva.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Verzija operatora poziva koja uzima prijemnik vrijednosti.
///
/// Primjeri `FnOnce` se mogu pozivati, ali se možda neće moći pozivati više puta.Zbog toga, ako je o tipu jedino poznato da implementira `FnOnce`, može se pozvati samo jednom.
///
/// `FnOnce` implementira se automatski zatvaračima koji mogu trošiti zarobljene varijable, kao i svi tipovi koji implementiraju [`FnMut`], npr. (safe) [function pointers] (jer je `FnOnce` supersrait [`FnMut`]).
///
///
/// Budući da su i [`Fn`] i [`FnMut`] podznake `FnOnce`, bilo koja instanca [`Fn`] ili [`FnMut`] može se koristiti tamo gdje se očekuje `FnOnce`.
///
/// Koristite `FnOnce` kao vezanu kada želite prihvatiti parametar funkcijskog tipa i trebate ga pozvati samo jednom.
/// Ako parametar trebate pozivati više puta, koristite [`FnMut`] kao vezan;ako vam treba i da ne biste mutirali stanje, koristite [`Fn`].
///
/// Pogledajte [chapter on closures in *The Rust Programming Language*][book] za neke dodatne informacije o ovoj temi.
///
/// Takođe treba napomenuti posebnu sintaksu za `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Oni koji su zainteresirani za tehničke detalje mogu se pozvati na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Korištenje `FnOnce` parametra
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` troši svoje zarobljene varijable, tako da se ne može pokrenuti više od jednom.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Pokušaj ponovnog poziva na `func()` izbaciće `use of moved value` grešku za `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` u ovom se trenutku više ne može pozivati
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se regex može osloniti na taj `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Vraćeni tip nakon korištenja operatora poziva.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Izvodi operaciju poziva.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}