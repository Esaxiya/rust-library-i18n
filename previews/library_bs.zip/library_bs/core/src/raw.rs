#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Sadrži definicije struktura za izgled ugrađenih tipova kompajlera.
//!
//! Mogu se koristiti kao ciljevi transmuta u nesigurnom kodu za direktnu manipulaciju sirovim prikazima.
//!
//!
//! Njihova definicija bi se uvijek trebala podudarati s ABI definiranim u `rustc_middle::ty::layout`.
//!

/// Predstavljanje Portrait objekta poput `&dyn SomeTrait`.
///
/// Ova struktura ima isti izgled kao tipovi poput `&dyn SomeTrait` i `Box<dyn AnotherTrait>`.
///
/// `TraitObject` zagarantovano se podudara s izgledima, ali to nije tip Portrait objekata (npr. poljima nije izravno dostupan `&dyn SomeTrait`) niti kontrolira taj izgled (promjena definicije neće promijeniti izgled `&dyn SomeTrait`).
///
/// Dizajniran je samo za upotrebu nesigurnim kodom koji treba manipulirati detaljima niske razine.
///
/// Ne postoji način da se generički uputi na sve objekte Portrait, pa je jedini način stvaranja vrijednosti ovog tipa funkcije pomoću funkcija poput [`std::mem::transmute`][transmute].
/// Slično tome, jedini način za stvaranje istinskog Portrait objekta od vrijednosti `TraitObject` je pomoću `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sinteza Portrait objekta s neusklađenim tipovima-onim u kojem vtable ne odgovara tipu vrijednosti na koju pokazuje pokazivač podataka-velika je vjerojatnost da će dovesti do nedefiniranog ponašanja.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // primjer Portrait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // neka kompajler napravi Portrait objekt
/// let object: &dyn Foo = &value;
///
/// // pogledajte sirovu predstavu
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // pokazivač podataka je adresa `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruirati novi objekt, usmjeravajući na drugi `i32`, pazeći pri korištenju `i32` vtable iz `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // trebalo bi raditi isto kao da smo iz `other_value` izravno konstruirali Portrait objekt
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}