macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Najmanja vrijednost koju može predstaviti ovaj cijeli broj.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Najveća vrijednost koju može predstaviti ovaj cijeli broj.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Veličina ovog cijelog broja u bitovima.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Pretvara kriška niza u datoj bazi u cijeli broj.
        ///
        /// Očekuje se da će niz biti neobavezni `+` znak praćen znamenkama.
        ///
        /// Vodeći i prateći razmaci predstavljaju grešku.
        /// Znamenke su podskup ovih znakova, ovisno o `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ova funkcija panics ako `radix` nije u rasponu od 2 do 36.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Vraća broj jedinica u binarnom predstavljanju `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Vraća broj nula u binarnom predstavljanju `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Vraća broj vodećih nula u binarnom predstavljanju `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Vraća broj pratećih nula u binarnom predstavljanju `self`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Vraća broj vodećih u binarnom predstavljanju `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Vraća broj pratećih u binarnom predstavljanju `self`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Pomjera bitove ulijevo za navedenu količinu, `n`, omatajući skraćene bitove na kraj rezultirajućeg cijelog broja.
        ///
        ///
        /// Imajte na umu da ovo nije ista operacija kao `<<` mjenjač!
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Pomjera bitove udesno za navedenu količinu, `n`, omatajući skraćene bitove na početak rezultirajućeg cijelog broja.
        ///
        ///
        /// Imajte na umu da ovo nije ista operacija kao `>>` mjenjač!
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Obrne redoslijed bajtova cijelog broja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// neka je m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Obrne redoslijed bitova u cijelom broju.
        /// Najmanji bit postaje najznačajniji bit, drugi najmanji bit postaje drugi najznačajniji bit, itd.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// neka je m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Pretvara cijeli broj iz velikog endijana u endiannost cilja.
        ///
        /// Na velikom endianu ovo je ne-op.
        /// Na malom endianu bajtovi se zamjenjuju.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ako cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ostalo {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Pretvara cijeli broj iz malog endijana u endiannost cilja.
        ///
        /// Na malom endianu ovo je ne-op.
        /// Na velikom endianu bajtovi se zamjenjuju.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ako cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ostalo {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Pretvara `self` u veliki endian iz ciljane endianzije.
        ///
        /// Na velikom endianu ovo je ne-op.
        /// Na malom endianu bajtovi se zamjenjuju.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ako cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ili ne biti?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Pretvara `self` u mali endian iz ciljane endianzije.
        ///
        /// Na malom endianu ovo je ne-op.
        /// Na velikom endianu bajtovi se zamjenjuju.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ako cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Označeno sabiranje cijelih brojeva.
        /// Izračunava `self + rhs`, vraća `None` ako je došlo do prelijevanja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Neoznačeni cjelobrojni dodatak.Izračunava `self + rhs`, pod pretpostavkom da ne može doći do prelijevanja.
        /// To rezultira nedefiniranim ponašanjem kada
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Provjereno oduzimanje cijelog broja.
        /// Izračunava `self - rhs`, vraća `None` ako je došlo do prelijevanja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Neoznačeno oduzimanje cijelog broja.Izračunava `self - rhs`, pod pretpostavkom da ne može doći do prelijevanja.
        /// To rezultira nedefiniranim ponašanjem kada
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Provjereno množenje cjelobrojnih vrijednosti.
        /// Izračunava `self * rhs`, vraća `None` ako je došlo do prelijevanja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Neprovjereno množenje cjelobrojnih vrijednosti.Izračunava `self * rhs`, pod pretpostavkom da ne može doći do prelijevanja.
        /// To rezultira nedefiniranim ponašanjem kada
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIGURNOST: pozivatelj mora poštovati ugovor o sigurnosti za `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Označena cijela podjela.
        /// Izračunava `self / rhs`, vraća `None` ako je `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIGURNOST: div po nuli je gore provjereno, a nepotpisani tipovi nemaju druge
                // načini otkaza za podjelu
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Provjerena euklidska podjela.
        /// Izračunava `self.div_euclid(rhs)`, vraća `None` ako je `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Provjereni ostatak cijelog broja.
        /// Izračunava `self % rhs`, vraća `None` ako je `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIGURNOST: div po nuli je gore provjereno, a nepotpisani tipovi nemaju druge
                // načini otkaza za podjelu
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Provjereno euklidsko modulo.
        /// Izračunava `self.rem_euclid(rhs)`, vraća `None` ako je `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Provjerena negacija.Izračunava `-self`, vraća `None` osim ako `self==
        /// 0`.
        ///
        /// Imajte na umu da će negiranje bilo kojeg pozitivnog cijelog broja preliti.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Označena smjena ulijevo.
        /// Izračunava `self << rhs`, vraća `None` ako je `rhs` veći ili jednak broju bitova u `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Provjerena smjena udesno.
        /// Izračunava `self >> rhs`, vraća `None` ako je `rhs` veći ili jednak broju bitova u `self`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Provjereno potenciranje.
        /// Izračunava `self.pow(exp)`, vraća `None` ako je došlo do prelijevanja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // budući da je exp!=0, napokon exp mora biti 1.
            // Odvojeno se pozabavite završnim bitom eksponenta, jer naknadno kvadriranje baze nije potrebno i može prouzročiti nepotrebno prelijevanje.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Zasićujući zbrajanje cijelih brojeva.
        /// Izračunava `self + rhs`, zasićujući se na numeričkim granicama, umjesto da se prelije.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Zasićeno oduzimanje cijelog broja.
        /// Izračunava `self - rhs`, zasićujući se na numeričkim granicama, umjesto da se prelije.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Zasićeno množenje cjelobrojnih vrijednosti.
        /// Izračunava `self * rhs`, zasićujući se na numeričkim granicama, umjesto da se prelije.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Zasićeno cjelobrojno potenciranje.
        /// Izračunava `self.pow(exp)`, zasićujući se na numeričkim granicama, umjesto da se prelije.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Omotavanje (modular) dodatka.
        /// Izračunava `self + rhs`, obavijajući se na granici tipa.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Omotavanje (modular) oduzimanja.
        /// Izračunava `self - rhs`, obavijajući se na granici tipa.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Umotavanje (modular) množenja.
        /// Izračunava `self * rhs`, obavijajući se na granici tipa.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// Imajte na umu da se ovaj primjer dijeli između cijelih brojeva.
        /// Što objašnjava zašto se ovdje koristi `u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Omotavanje (modular) podjele.Računa `self / rhs`.
        /// Umotana podjela na nepotpisane tipove je sasvim normalna podjela.
        /// Nema šanse da se zamotavanje ikad dogodi.
        /// Ova funkcija postoji, tako da se sve operacije uzimaju u obzir u operacijama umotavanja.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Omotavanje euklidske podjele.Računa `self.div_euclid(rhs)`.
        /// Umotana podjela na nepotpisane tipove je sasvim normalna podjela.
        /// Nema šanse da se zamotavanje ikad dogodi.
        /// Ova funkcija postoji, tako da se sve operacije uzimaju u obzir u operacijama umotavanja.
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, to je točno jednako `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Omotavanje ostatka (modular).Računa `self % rhs`.
        /// Izračun zamotanog ostatka na nepotpisanim tipovima samo je uobičajeni izračun ostatka.
        ///
        /// Nema šanse da se zamotavanje ikad dogodi.
        /// Ova funkcija postoji, tako da se sve operacije uzimaju u obzir u operacijama umotavanja.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Omotavanje euklidskog modula.Računa `self.rem_euclid(rhs)`.
        /// Obmotani modulo-proračun na nepotpisanim tipovima samo je uobičajeni izračun ostatka.
        /// Nema šanse da se zamotavanje ikad dogodi.
        /// Ova funkcija postoji, tako da se sve operacije uzimaju u obzir u operacijama umotavanja.
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, to je točno jednako `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Omotavanje negacije (modular).
        /// Izračunava `-self`, obavijajući se na granici tipa.
        ///
        /// Budući da nepotpisani tipovi nemaju negativne ekvivalente, sve aplikacije ove funkcije će se zamotati (osim za `-0`).
        /// Za vrijednosti manje od maksimuma odgovarajućeg potpisanog tipa rezultat je isti kao i lijevanje odgovarajuće potpisane vrijednosti.
        ///
        /// Sve veće vrijednosti ekvivalentne su `MAX + 1 - (val - MAX - 1)` gdje je `MAX` maksimum odgovarajućeg potpisanog tipa.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// Imajte na umu da se ovaj primjer dijeli između cijelih brojeva.
        /// Što objašnjava zašto se ovdje koristi `i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic bez bitnog pomaka ulijevo;
        /// daje `self << mask(rhs)`, gdje `mask` uklanja sve bitove visokog reda `rhs` zbog kojih bi pomak premašio bitwidth tipa.
        ///
        /// Imajte na umu da ovo *nije* isto što i rotiranje ulijevo;RHS zamotavanja u smjeru lijevo ograničen je na opseg tipa, umjesto da se bitovi pomaknuti iz LHS vraćaju na drugi kraj.
        /// Svi primitivni cijeli brojevi implementiraju [`rotate_left`](Self::rotate_left) funkciju, koja umjesto toga može biti ono što želite.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIGURNOST: maskiranje bit-veličinom tipa osigurava da se ne pomaknemo
            // izvan granica
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic bez bitnog pomaka udesno;
        /// daje `self >> mask(rhs)`, gdje `mask` uklanja sve bitove visokog reda `rhs` zbog kojih bi pomak premašio bitwidth tipa.
        ///
        /// Imajte na umu da ovo *nije* isto što i rotiranje udesno;RHS omatanja pomaka udesno ograničen je na opseg tipa, umjesto da se bitovi pomaknuti iz LHS vraćaju na drugi kraj.
        /// Svi primitivni cijeli brojevi implementiraju [`rotate_right`](Self::rotate_right) funkciju, koja umjesto toga može biti ono što želite.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIGURNOST: maskiranje bit-veličinom tipa osigurava da se ne pomaknemo
            // izvan granica
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Omotavanje potencijacije (modular).
        /// Izračunava `self.pow(exp)`, obavijajući se na granici tipa.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // budući da je exp!=0, napokon exp mora biti 1.
            // Odvojeno se pozabavite završnim bitom eksponenta, jer naknadno kvadriranje baze nije potrebno i može prouzročiti nepotrebno prelijevanje.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Izračunava `self` + `rhs`
        ///
        /// Vraća skup sabiranja zajedno s logičkom vrijednošću koja ukazuje da li će doći do aritmetičkog preljeva.
        /// Ako bi došlo do prekoračenja, tada se vraća umotana vrijednost.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračunava `self`, `rhs`
        ///
        /// Vraća skup oduzimanja zajedno s logičkom vrijednošću koja pokazuje da li će doći do aritmetičkog preljeva.
        /// Ako bi došlo do prekoračenja, tada se vraća umotana vrijednost.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračunava množenje `self` i `rhs`.
        ///
        /// Vraća skup množenja zajedno s logičkom vrijednošću koja pokazuje da li će doći do aritmetičkog preljeva.
        /// Ako bi došlo do prekoračenja, tada se vraća umotana vrijednost.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// Imajte na umu da se ovaj primjer dijeli između cijelih brojeva.
        /// Što objašnjava zašto se ovdje koristi `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračunava djelilac kada je `self` podijeljen sa `rhs`.
        ///
        /// Vraća skup djelitelja zajedno s logičkom vrijednošću koja ukazuje da li će doći do aritmetičkog preljeva.
        /// Imajte na umu da se za nepotpisane cijele brojeve nikada ne događa preljev, pa je druga vrijednost uvijek `false`.
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Izračunava količnik euklidske podjele `self.div_euclid(rhs)`.
        ///
        /// Vraća skup djelitelja zajedno s logičkom vrijednošću koja ukazuje da li će doći do aritmetičkog preljeva.
        /// Imajte na umu da se za nepotpisane cijele brojeve nikada ne događa preljev, pa je druga vrijednost uvijek `false`.
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, to je točno jednako `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Izračunava ostatak kada se `self` podijeli sa `rhs`.
        ///
        /// Vraća skup ostataka nakon dijeljenja zajedno s logičkom vrijednošću koja pokazuje da li će doći do aritmetičkog preljeva.
        /// Imajte na umu da se za nepotpisane cijele brojeve nikada ne događa preljev, pa je druga vrijednost uvijek `false`.
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Izračunava ostatak `self.rem_euclid(rhs)` kao da je euklidskom podjelom.
        ///
        /// Daje skup modula nakon dijeljenja zajedno s logičkom vrijednošću koja ukazuje da li će doći do aritmetičkog preljeva.
        /// Imajte na umu da se za nepotpisane cijele brojeve nikada ne događa preljev, pa je druga vrijednost uvijek `false`.
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, ova je operacija točno jednaka `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negatira sebe na preplavljen način.
        ///
        /// Vraća `!self + 1` koristeći operacije umotavanja za vraćanje vrijednosti koja predstavlja negaciju ove nepotpisane vrijednosti.
        /// Imajte na umu da se za pozitivne nepotpisane vrijednosti uvijek događa prelijevanje, ali negiranje 0 ne prelijeva se.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Prebacuje se samo lijevo od `rhs` bitova.
        ///
        /// Vraća skup pomaknute verzije selfa zajedno s logičkom vrijednošću koja pokazuje je li vrijednost pomaka veća ili jednaka broju bitova.
        /// Ako je vrijednost pomaka prevelika, tada je vrijednost maskirana (N-1) gdje je N broj bitova, a ta vrijednost se zatim koristi za izvođenje pomaka.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Mijenja se samo udesno za `rhs` bitove.
        ///
        /// Vraća skup pomaknute verzije selfa zajedno s logičkom vrijednošću koja pokazuje je li vrijednost pomaka veća ili jednaka broju bitova.
        /// Ako je vrijednost pomaka prevelika, tada je vrijednost maskirana (N-1) gdje je N broj bitova, a ta vrijednost se zatim koristi za izvođenje pomaka.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Podiže sebe do snage `exp`, koristeći potenciranje kvadraturiranjem.
        ///
        /// Vraća skup eksponenciranja zajedno sa bool koji ukazuje da li se dogodilo prelijevanje.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, istina));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Ogrebite prostor za pohranu rezultata overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // budući da je exp!=0, napokon exp mora biti 1.
            // Odvojeno se pozabavite završnim bitom eksponenta, jer naknadno kvadriranje baze nije potrebno i može prouzročiti nepotrebno prelijevanje.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Podiže sebe do snage `exp`, koristeći potenciranje kvadraturiranjem.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // budući da je exp!=0, napokon exp mora biti 1.
            // Odvojeno se pozabavite završnim bitom eksponenta, jer naknadno kvadriranje baze nije potrebno i može prouzročiti nepotrebno prelijevanje.
            //
            //
            acc * base
        }

        /// Izvodi euklidsku podjelu.
        ///
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, to je točno jednako `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Izračunava najmanji ostatak `self (mod rhs)`.
        ///
        /// Budući da su za pozitivne cijele brojeve sve uobičajene definicije dijeljenja jednake, to je točno jednako `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ova funkcija će panic ako je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Vraća `true` ako i samo ako je `self == 2^k` za neki `k`.
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Vraća jedan manje od sljedećeg potencijala dva.
        // (Za 8u8 sljedeća snaga dvoje je 8u8, a za 6u8 je 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Ova metoda se ne može preliti, jer u slučajevima prelijevanja `next_power_of_two` umjesto toga na kraju vraća maksimalnu vrijednost tipa, a može vratiti 0 za 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SIGURNOST: Zbog `p > 0`, ne može se u potpunosti sastojati od vodećih nula.
            // To znači da je pomak uvijek unutar granica, a neki procesori (kao što je Intel pre-haswell) imaju učinkovitiju ctlz osobinu kada argument nije nula.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Daje najmanju snagu od dvije veće ili jednake `self`.
        ///
        /// Kada se povratna vrijednost prelije (tj. `self > (1 << (N-1))` za tip `uN`), ona panics u načinu otklanjanja pogrešaka i povratna vrijednost premotava se na 0 u načinu otpuštanja (jedina situacija u kojoj metoda može vratiti 0).
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Daje najmanju snagu od dvije veće ili jednake `n`.
        /// Ako je sljedeća snaga dvoje veća od maksimalne vrijednosti tipa, vraća se `None`, inače je snaga dvoje umotana u `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Daje najmanju snagu od dvije veće ili jednake `n`.
        /// Ako je sljedeća snaga od dvije veća od maksimalne vrijednosti tipa, povratna vrijednost premotava se u `0`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna upotreba:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Vratite memorijski prikaz ovog cijelog broja kao bajtni niz u big-end (network) redoslijedu bajtova.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Vratite memorijski prikaz ovog cijelog broja kao bajtni niz u malo-endanskom redoslijedu bajtova.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Vratite memorijski prikaz ovog cijelog broja kao bajtni niz u izvornom redoslijedu bajtova.
        ///
        /// Kako se koristi izvorni endijans ciljne platforme, prijenosni kod bi umjesto toga trebao koristiti [`to_be_bytes`] ili [`to_le_bytes`], prema potrebi.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajtova, ako je cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ostalo {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURNOST: const zvuk jer su cijeli brojevi obični stari tipovi podataka, tako da to uvijek možemo
        // pretvoriti ih u niz bajtova
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIGURNOST: cijeli brojevi su obični stari tipovi podataka tako da ih uvijek možemo transformirati
            // nizovi bajtova
            unsafe { mem::transmute(self) }
        }

        /// Vratite memorijski prikaz ovog cijelog broja kao bajtni niz u izvornom redoslijedu bajtova.
        ///
        ///
        /// [`to_ne_bytes`] treba imati prednost nad ovim kad god je to moguće.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// neka bajtovi= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajtova, ako je cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ostalo {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIGURNOST: cijeli brojevi su obični stari tipovi podataka tako da ih uvijek možemo transformirati
            // nizovi bajtova
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Stvorite nativnu endian cijelu vrijednost od njene reprezentacije kao bajt niza u velikom endianu.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// koristite std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ulaz=odmor;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Stvorite nativnu endian cijelu vrijednost od njene reprezentacije kao bajt niza u malom endianu.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// koristite std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ulaz=odmor;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Stvorite nativnu endian cijelu vrijednost iz njene memorijske reprezentacije kao bajtni niz u nativnoj endianness.
        ///
        /// Kako se koristi izvorni endijans ciljne platforme, prijenosni kod vjerovatno želi koristiti [`from_be_bytes`] ili [`from_le_bytes`], prema potrebi.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } ostalo {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// koristite std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ulaz=odmor;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURNOST: const zvuk jer su cijeli brojevi obični stari tipovi podataka, tako da to uvijek možemo
        // transformiraj ih
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIGURNOST: cijeli brojevi su obični stari tipovi podataka tako da ih uvijek možemo transformirati
            unsafe { mem::transmute(bytes) }
        }

        /// Novi kod bi radije koristili
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Vraća najmanju vrijednost koju ovaj cijeli broj može predstaviti.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Novi kod bi radije koristili
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Vraća najveću vrijednost koju ovaj cijeli broj može predstaviti.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}