//! Rust adaptacija algoritma Grisu3 opisana u "Brzo i precizno ispisivanje brojeva s pomičnom zarezom s cijelim brojevima" [^ 1].
//! Koristi oko 1 KB predračunate tablice, a zauzvrat je vrlo brz za većinu ulaza.
//!
//! [^1]: Florian Loitsch.2010. Brzo ispisivanje brojeva s pomičnom zarezom i
//!   tačno sa cijelim brojevima.SIGPLAN Ne.45, 6 (juni 2010.), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// pogledajte komentare u `format_shortest_opt` za obrazloženje.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// S obzirom na `x > 0`, vraća `(k, 10^k)` takav da je `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Najkraća implementacija načina za Grisu.
///
/// Vraća `None` kada bi u suprotnom vratio netačan prikaz.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // trebaju nam najmanje tri bita dodatne preciznosti

    // započnite s normaliziranim vrijednostima sa dijeljenim eksponentom
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // pronađite bilo koji `cached = 10^minusk` takav kao što je `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // budući da je `plus` normaliziran, to znači `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // s obzirom na naš izbor `ALPHA` i `GAMMA`, ovo stavlja `plus * cached` u `[4, 2^32)`.
    //
    // očito je poželjno maksimizirati `GAMMA - ALPHA`, tako da nam ne treba puno predmemoriranih moći od 10, ali postoje neka razmatranja:
    //
    //
    // 1. želimo zadržati `floor(plus * cached)` unutar `u32` jer mu je potrebna skupa podjela.
    //    (ovo se zapravo ne može izbjeći, ostatak je potreban za procjenu tačnosti.)
    // 2.
    // ostatak `floor(plus * cached)` se više puta pomnoži sa 10 i ne bi trebao prelijevati.
    //
    // prvi daje `64 + GAMMA <= 32`, dok drugi daje `10 * 2^-ALPHA <= 2^64`;
    // -60 i -32 je maksimalni domet s ovim ograničenjem, a V8 ih također koristi.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.ovo daje maksimalnu grešku od 1 ulp (dokazano iz teoreme 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-stvarni opseg minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // iznad `minus`, `v` i `plus` su *kvantizirane* aproksimacije (greška <1 ulp).
    // kako ne znamo da je greška pozitivna ili negativna, koristimo dvije aproksimacije jednakomjerno raspoređene i imamo maksimalnu pogrešku od 2 ulpsa.
    //
    // "unsafe region" je liberalni interval koji smo inicijalno generirali.
    // "safe region" je konzervativni interval koji samo prihvaćamo.
    // započinjemo s ispravnim replikacijama u nesigurnoj regiji i pokušavamo pronaći najbližu reputaciju `v` koja je također unutar sigurne regije.
    // ako ne možemo, odustajemo.
    //
    let plus1 = plus.f + 1;
    // neka plus0 = plus.f, 1;//samo za objašnjenje neka je minus0 = minus.f + 1;//samo za objašnjenje
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // dijeljeni eksponent

    // podijeliti `plus1` na integralne i razlomljene dijelove.
    // integralni dijelovi garantirano se uklapaju u u32, jer predmemorirana snaga garantira `plus < 2^32` i normalizirani `plus.f` je uvijek manji od `2^64 - 2^4` zbog zahtjeva preciznosti.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // izračunajte najveći `10^max_kappa` ne više od `plus1` (dakle `plus1 < 10^(max_kappa+1)`).
    // ovo je donja granica `kappa`.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorem 6.2: ako je `k` najveći cijeli broj st
    // `0 <= y mod 10^k <= y - x`,              tada je `V = floor(y / 10^k) * 10^k` u `[x, y]` i jedan od najkraćih prikaza (s minimalnim brojem značajnih znamenki) u tom rasponu.
    //
    //
    // pronaći dužinu znamenke `kappa` između `(minus1, plus1)` prema teoremu 6.2.
    // Teorema 6.2 može se usvojiti za izuzeće `x` zahtijevajući `y mod 10^k < y - x` umjesto toga.
    // (npr. `x` =32000, `y` =32777; `kappa` =2 jer `y mod 10 ^ 3=777 <y, x=777`.) algoritam se oslanja na kasniju fazu verifikacije kako bi isključio `y`.
    //
    let delta1 = plus1 - minus1;
    // neka delta1int=(delta1>> e) kako se koristi;//samo za objašnjenje
    let delta1frac = delta1 & ((1 << e) - 1);

    // čine integralne dijelove, istovremeno provjeravajući tačnost u svakom koraku.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // znamenke koje još nisu prikazane
    loop {
        // uvijek imamo barem jednu znamenku za generiranje, kao `plus1 >= 10^kappa` invarijante:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (slijedi da je `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // podijelite `remainder` sa `10^kappa`.oba su prilagođena `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; pronašli smo ispravan `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa natrag na dijeljeni eksponent
            return round_and_weed(
                // SIGURNOST: gore smo inicijalizirali tu memoriju.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // prekinuti petlju kada smo prikazali sve integralne znamenke.
        // tačan broj znamenki je `max_kappa + 1` kao `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // vratiti invarijante
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // prikazuju frakcijske dijelove, dok provjeravate tačnost u svakom koraku.
    // ovoga puta oslanjamo se na ponovljeno množenje, jer će dijeljenje izgubiti preciznost.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // sljedeća bi cifra trebala biti značajna jer smo to testirali prije izbijanja invarijanata, gdje `m = max_kappa + 1` (broj znamenki u integralnom dijelu):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // neće se preliti, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // podijelite `remainder` sa `10^kappa`.
        // oba su skalirana `2^e / 10^kappa`, tako da je potonje ovdje implicitno.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicitni djelitelj
            return round_and_weed(
                // SIGURNOST: gore smo inicijalizirali tu memoriju.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // vratiti invarijante
        kappa -= 1;
        remainder = r;
    }

    // generirali smo sve značajne znamenke `plus1`, ali nismo sigurni da li je optimalna.
    // na primjer, ako je `minus1` 3.14153 ..., a `plus1` 3.14158 ..., postoji 5 različitih najkraćih prikaza od 3.14154 do 3.14158, ali mi imamo samo najveći.
    // moramo sukcesivno smanjivati zadnju znamenku i provjeriti je li ovo optimalna replika.
    // ima najviše 9 kandidata (.1 do ..9), pa je ovo prilično brzo.("rounding" faza)
    //
    // funkcija provjerava je li ovaj "optimal" ponovljeni prikaz zapravo u rasponu ulp, a također je moguće da "second-to-optimal" ponovni prikaz zaista može biti optimalan zbog pogreške zaokruživanja.
    // u oba slučaja ovo vraća `None`.
    // ("weeding" faza)
    //
    // svi argumenti ovdje se skaliraju zajedničkom (ali implicitnom) vrijednošću `k`, tako da:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (i takođe, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (a takođe i `threshold > plus1v` iz prethodnih invarijanata)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // proizvesti dvije aproksimacije `v` (zapravo `plus1 - v`) unutar 1.5 ulpsa.
        // rezultirajuća reprezentacija trebala bi biti najbliža reprezentaciji obojici.
        //
        // ovdje se koristi `plus1 - v` jer se proračuni rade u odnosu na `plus1` kako bi se izbjegao overflow/underflow (otuda naizgled zamijenjena imena).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // smanjite zadnju znamenku i zaustavite se na najbližem predstavljanju `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // radimo s približnim znamenkama `w(n)`, što je u početku jednako `plus1 - plus1 % 10^kappa`.nakon pokretanja tijela petlje `n` puta, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // postavili smo `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (dakle `ostatak= plus1w(0)`) da pojednostavimo provjere.
            // imajte na umu da se `plus1w(n)` uvijek povećava.
            //
            // imamo tri uslova za raskid.bilo koji od njih onemogućit će ponavljanje petlje, ali tada imamo barem jedan valjani prikaz za koji se zna da je ionako najbliži `v + 1 ulp`.
            // označit ćemo ih kao TC1 do TC3 za kratkoću.
            //
            // TC1: `w(n) <= v + 1 ulp`, tj. Ovo je posljednja replika koja može biti najbliža.
            // ovo je ekvivalentno `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // u kombinaciji s TC2 (koji provjerava je li `w(n+1)` is valid), ovo sprečava moguće preljevanje na izračunavanju `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, tj. Sljedeći izvještaj definitivno ne zaokružuje na `v`.
            // ovo je ekvivalentno `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // lijeva strana se može preliti, ali mi znamo `threshold > plus1v`, pa ako je TC1 netačan, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` i možemo sigurno testirati da li je `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, tj. Sljedeća replika je
            // nije bliži `v + 1 ulp` od trenutne prijave.
            // s obzirom na `z(n) = plus1v_up - plus1w(n)`, ovo postaje `abs(z(n)) <= abs(z(n+1))`.opet pod pretpostavkom da je TC1 netačan, imamo `z(n) > 0`.moramo razmotriti dva slučaja:
            //
            // - kada `z(n+1) >= 0`: TC3 postaje `z(n) <= z(n+1)`.
            // kako se `plus1w(n)` povećava, `z(n)` bi se trebao smanjivati i to je očito netačno.
            // - kada `z(n+1) < 0`:
            //   - TC3a: preduvjet je `plus1v_up < plus1w(n) + 10^kappa`.pod pretpostavkom da je TC2 netačan, `threshold >= plus1w(n) + 10^kappa` pa se ne može preliti.
            //   - TC3b: TC3 postaje `z(n) <= -z(n+1)`, tj. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   negirani TC1 daje `plus1v_up > plus1w(n)`, tako da se ne može prelijevati ili podlijevati u kombinaciji s TC3a.
            //
            // shodno tome, trebali bismo zaustaviti kada `TC1 || TC2 || (TC3a && TC3b)`.sljedeće je jednako njegovoj inverzi, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // najkraći prikaz ne može završiti sa `0`
                plus1w += ten_kappa;
            }
        }

        // provjerite je li ovaj prikaz ujedno i najbliži `v - 1 ulp`.
        //
        // ovo je jednostavno isto kao i završni uvjeti za `v + 1 ulp`, umjesto toga svi `plus1v_up` zamijenjeni su `plus1v_down`.
        // jednako vrijedi i analiza preljeva.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // sada imamo najbliži prikaz `v` između `plus1` i `minus1`.
        // ovo je ipak previše liberalno, pa odbacujemo bilo koji `w(n)` koji nije između `plus0` i `minus0`, tj. `plus1 - plus1w(n) <= minus0` ili `plus1 - plus1w(n) >= plus0`.
        // koristimo činjenice da `threshold = plus1 - minus1` i `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Implementacija najkraćeg načina za Grisu sa zamjenskim zmajem.
///
/// Ovo bi trebalo koristiti u većini slučajeva.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIGURNOST: Provjera posudbe nije dovoljno pametna da bi nam dopustio da koristimo `buf`
    // u drugom branch, pa ovdje peremo cijeli život.
    // Ali `buf` ponovo koristimo samo ako je `format_shortest_opt` vratio `None`, tako da je ovo u redu.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Tačna i fiksna implementacija načina za Grisu.
///
/// Vraća `None` kada bi u suprotnom vratio netačan prikaz.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // trebaju nam najmanje tri bita dodatne preciznosti
    assert!(!buf.is_empty());

    // normalizirajte i prilagodite `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // podijeliti `v` na integralne i razlomljene dijelove.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // i stari `v` i novi `v` (prilagođeni `10^-k`) imaju grešku <1 ulp (teorema 5.1).
    // kako ne znamo da je greška pozitivna ili negativna, koristimo dvije aproksimacije raspoređene podjednako i imamo maksimalnu pogrešku od 2 ulpe (isto u najkraćem slučaju).
    //
    //
    // Cilj je pronaći tačno zaokruženu seriju znamenki koje su zajedničke i `v - 1 ulp` i `v + 1 ulp`, kako bismo bili maksimalno sigurni.
    // ako to nije moguće, ne znamo koji je ispravan izlaz za `v`, pa odustajemo i nazad.
    //
    // `err` ovdje je definiran kao `1 ulp * 2^e` (isto kao i ulp u `vfrac`), a mi ćemo ga skalirati kad god se `v` skalira.
    //
    //
    //
    let mut err = 1;

    // izračunajte najveći `10^max_kappa` ne više od `v` (dakle `v < 10^(max_kappa+1)`).
    // ovo je donja granica `kappa`.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ako radimo s ograničenjem od posljednje znamenke, trebamo skratiti međuspremnik prije stvarnog prikazivanja kako bismo izbjegli dvostruko zaokruživanje.
    //
    // imajte na umu da moramo ponovo povećati me uspremnik kada se dogodi zaokruživanje!
    let len = if exp <= limit {
        // oops, ne možemo proizvesti ni *jednu* cifru.
        // to je moguće kada, recimo, imamo nešto poput 9.5 i zaokružimo na 10.
        //
        // u principu možemo odmah pozvati `possibly_round` s praznim međuspremnikom, ali skaliranje `max_ten_kappa << e` za 10 može rezultirati preljevom.
        //
        // stoga smo ovdje aljkavi i širimo raspon grešaka za faktor 10.
        // ovo će povećati lažno negativnu stopu, ali samo vrlo,*vrlo*;
        // može biti bitno samo kada je mantisa veća od 60 bita.
        //
        // SIGURNOST: `len=0`, tako da je obaveza inicijalizacije ove memorije trivijalna.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // čine sastavni dijelovi.
    // greška je u potpunosti razlomljena, pa je ne trebamo provjeravati u ovom dijelu.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // znamenke koje još nisu prikazane
    loop {
        // uvijek imamo barem jednu cifru za prikaz invarijanata:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (slijedi da je `remainder = vint % 10^(kappa+1)`)
        //
        //

        // podijelite `remainder` sa `10^kappa`.oba su prilagođena `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // je li bafer pun?pokrenite prolaz za zaokruživanje s ostatkom.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIGURNOST: inicijalizirali smo `len` mnogo bajtova.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // prekinuti petlju kada smo prikazali sve integralne znamenke.
        // tačan broj znamenki je `max_kappa + 1` kao `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // vratiti invarijante
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // prikazuju frakcijske dijelove.
    //
    // u principu možemo nastaviti do posljednje dostupne znamenke i provjeriti tačnost.
    // nažalost, radimo s cijelim brojevima konačne veličine, pa su nam potrebni neki kriteriji za otkrivanje prelijevanja.
    // V8 koristi `remainder > err`, koji postaje netačan kada se razlikuju prve značajne cifre `i` `v - 1 ulp` i `v`.
    // međutim ovo odbacuje previše inače važećih unosa.
    //
    // budući da kasnija faza ima ispravno otkrivanje preljeva, umjesto toga koristimo stroži kriterij:
    // nastavljamo dok `err` ne premaši `10^kappa / 2`, tako da raspon između `v - 1 ulp` i `v + 1 ulp` definitivno sadrži dva ili više zaokruženih prikaza.
    //
    // ovo je isto kao i prva dva poređenja sa `possibly_round`, za referencu.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarijante, gdje `m = max_kappa + 1` (broj znamenki u integralnom dijelu):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // neće se preliti, `2^e * 10 < 2^64`
        err *= 10; // neće se preliti, `err * 10 < 2^e * 5 < 2^64`

        // podijelite `remainder` sa `10^kappa`.
        // oba su skalirana `2^e / 10^kappa`, tako da je potonje ovdje implicitno.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // je li bafer pun?pokrenite prolaz za zaokruživanje s ostatkom.
        if i == len {
            // SIGURNOST: inicijalizirali smo `len` mnogo bajtova.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // vratiti invarijante
        remainder = r;
    }

    // daljnji proračun je beskoristan (`possibly_round` definitivno ne uspije), pa odustajemo.
    return None;

    // generirali smo sve tražene znamenke `v`, koje bi također trebale biti jednake odgovarajućim znamenkama `v - 1 ulp`.
    // sada provjeravamo postoji li jedinstveni prikaz koji dijele i `v - 1 ulp` i `v + 1 ulp`;ovo može biti isto za generirane znamenke ili zaokruženu verziju tih znamenki.
    //
    // ako opseg sadrži više prikaza iste dužine, ne možemo biti sigurni i umjesto toga bismo trebali vratiti `None`.
    //
    // svi argumenti ovdje se skaliraju zajedničkom (ali implicitnom) vrijednošću `k`, tako da:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIGURNOST: prvi `len` bajtovi `buf` moraju biti inicijalizirani.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (za referencu, isprekidana linija označava tačnu vrijednost za moguće prikaze u zadanom broju znamenki.)
        //
        //
        // greška je prevelika da postoje najmanje tri moguće predstave između `v - 1 ulp` i `v + 1 ulp`.
        // ne možemo utvrditi koji je tačan.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // u stvari, 1/2 ulp je dovoljan da uvede dvije moguće reprezentacije.
        // (imajte na umu da nam treba jedinstveni prikaz i za `v - 1 ulp` i za `v + 1 ulp`.) ovo se neće preliti, kao `ulp < ten_kappa` od prve provjere.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ako je `v + 1 ulp` bliži zaokruženom predstavljanju (koji je već u `buf`), onda se možemo sigurno vratiti.
        // imajte na umu da `v - 1 ulp`*može* biti manji od trenutne reprezentacije, ali kao `1 ulp < 10^kappa / 2`, ovaj uvjet je dovoljan:
        // udaljenost između `v - 1 ulp` i trenutne reprezentacije ne može biti veća od `10^kappa / 2`.
        //
        // uslov je jednak `remainder + ulp < 10^kappa / 2`.
        // jer se ovo lako može preliti, prvo provjerite je li `remainder < 10^kappa / 2`.
        // već smo provjerili da `ulp < 10^kappa / 2`, tako dugo dok se `10^kappa` ipak nije prelijevao, druga provjera je u redu.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIGURNOST: naš pozivatelj je inicijalizirao tu memoriju.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------ostatak------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // s druge strane, ako je `v - 1 ulp` bliži zaokruženom predstavljanju, trebali bismo zaokružiti i vratiti se.
        // iz istog razloga ne trebamo provjeravati `v + 1 ulp`.
        //
        // uslov je jednak `remainder - ulp >= 10^kappa / 2`.
        // opet prvo provjeravamo je li `remainder > ulp` (imajte na umu da ovo nije `remainder >= ulp`, jer `10^kappa` nikada nije nula).
        //
        // također imajte na umu da `remainder - ulp <= 10^kappa`, tako da druga provjera ne prelijeva.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // BEZBEDNOST: naš pozivatelj mora inicijalizirati tu memoriju.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // dodajte dodatnu znamenku samo kada smo zatraženi od fiksne preciznosti.
                // također moramo provjeriti da, ako je izvorni međuspremnik bio prazan, dodatna znamenka može se dodati samo kada je `exp == limit` (slučaj edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIGURNOST: mi i naš pozivatelj smo inicijalizirali tu memoriju.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // u suprotnom smo osuđeni (tj. neke vrijednosti između `v - 1 ulp` i `v + 1 ulp` se zaokružuju prema dolje, a druge zaokružuju) i odustajemo.
        //
        None
    }
}

/// Tačna i fiksna implementacija načina rada za Grisu s Dragon rezervnim.
///
/// Ovo bi trebalo koristiti u većini slučajeva.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIGURNOST: Provjera posudbe nije dovoljno pametna da bi nam dopustio da koristimo `buf`
    // u drugom branch, pa ovdje peremo cijeli život.
    // Ali `buf` ponovo koristimo samo ako je `format_exact_opt` vratio `None`, tako da je ovo u redu.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}