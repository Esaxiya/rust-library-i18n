//! Konstante za 64-bitni nepotpisani cijeli broj.
//!
//! *[See also the `u64` primitive type][u64].*
//!
//! Novi kôd treba koristiti pridružene konstante direktno na primitivnom tipu.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }