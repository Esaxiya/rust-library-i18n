//! Uslužne funkcije za bignume koje nemaju previše smisla pretvoriti u metode.

// FIXME Ime ovog modula pomalo je žalosno, jer i drugi moduli uvoze `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testirajte da li odsijecanje svih bitova manje značajnih od `ones_place` uvodi relativnu grešku manju, jednaku ili veću od 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ako su svi preostali bitovi nula, to je= 0.5 ULP, u suprotnom> 0.5 Ako više nema bitova (half_bit==0), dolje također ispravno vraća Jednako.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Pretvara ASCII niz koji sadrži samo decimalne znamenke u `u64`.
///
/// Ne vrši provjere za prekomjerne ili nevažeće znakove, pa ako pozivalac nije oprezan, rezultat je lažan i može panic (iako to neće biti `unsafe`).
/// Uz to, prazni nizovi se tretiraju kao nula.
/// Ova funkcija postoji jer
///
/// 1. Korištenje `FromStr` na `&[u8]` zahtijeva `from_utf8_unchecked`, što je loše, i
/// 2. sastavljanje rezultata `integral.parse()` i `fractional.parse()` složenije je od cijele ove funkcije.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Pretvara niz ASCII znamenki u bignum.
///
/// Kao i `from_str_unchecked`, i ova se funkcija oslanja na parser za uklanjanje ne-znamenki.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Omotava bignum u 64-bitni cijeli broj.Panics ako je broj prevelik.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Izdvaja niz bitova.

/// Indeks 0 je najmanje značajni bit, a opseg je poluotvoren kao i obično.
/// Panics ako se zatraži da izvuče više bitova nego što stane u tip povratka.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}