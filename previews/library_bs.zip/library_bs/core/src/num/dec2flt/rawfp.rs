//! Bitno petljanje na pozitivnim IEEE 754 plovcima.Negativni brojevi nisu i ne trebaju se rukovati.
//! Normalni brojevi s pomičnom zarezom imaju kanonski prikaz kao (frac, exp) takav da je vrijednost 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) gdje je N broj bitova.
//!
//! Subnormali su malo različiti i čudni, ali vrijedi isti princip.
//!
//! Ovdje ih, međutim, predstavljamo kao (sig, k) s f pozitivno, tako da je vrijednost f *
//! 2 <sup>e</sup> .Osim što "hidden bit" čini eksplicitnim, ovo mijenja eksponent takozvanim mantissa pomakom.
//!
//! Drugim riječima, plovci se obično pišu kao (1), ali ovdje se pišu kao (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) nazivamo **frakcijskim prikazom**, a (2)**integralnim prikazom**.
//!
//! Mnoge funkcije u ovom modulu obrađuju samo normalne brojeve.Rutine dec2flt konzervativno idu univerzalno ispravnim sporim putem (algoritam M) za vrlo male i vrlo velike brojeve.
//! Za taj algoritam potreban je samo next_float() koji obrađuje subnormale i nule.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Pomoćnik Portrait kako bi se izbjeglo dupliciranje u osnovi svih konverzijskih kodova za `f32` i `f64`.
///
/// Zašto je to potrebno pogledajte u komentaru na dokument nadređenog modula.
///
/// **Nikada** ne bi trebao biti implementiran za druge tipove ili biti korišten izvan dec2flt modula.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tip koji koriste `to_bits` i `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Izvodi sirovu transmutaciju u cijeli broj.
    fn to_bits(self) -> Self::Bits;

    /// Izvodi sirovu transmutaciju iz cijelog broja.
    fn from_bits(v: Self::Bits) -> Self;

    /// Vraća kategoriju u koju spada ovaj broj.
    fn classify(self) -> FpCategory;

    /// Vraća mantisu, eksponent i znak kao cijele brojeve.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekodira plovak.
    fn unpack(self) -> Unpacked;

    /// Emitira iz malog cijelog broja koji se može tačno predstaviti.
    /// Panic ako cijeli broj ne može biti predstavljen, drugi kod u ovom modulu osigurava da se to nikada ne dogodi.
    fn from_int(x: u64) -> Self;

    /// Dobiva vrijednost 10 <sup>e</sup> iz unaprijed izračunate tablice.
    /// Panics za `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Što govori ime.
    /// Jednostavnije je kodirati nego žonglirati s intrinzikama i nadati se da će ga konstanta LLVM preklopiti.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konzervativna veza na decimalne znamenke ulaza koje ne mogu proizvesti preljev ili nulu ili
    /// subnormali.Vjerovatno decimalni eksponent maksimalne normalne vrijednosti, otuda i ime.
    const MAX_NORMAL_DIGITS: usize;

    /// Kada najznačajnija decimalna cifra ima vrijednost mjesta veću od ove, broj se sigurno zaokružuje na beskonačnost.
    ///
    const INF_CUTOFF: i64;

    /// Kada najznačajnija decimalna cifra ima vrijednost mjesta manju od ove, broj se sigurno zaokružuje na nulu.
    ///
    const ZERO_CUTOFF: i64;

    /// Broj bitova u eksponentu.
    const EXP_BITS: u8;

    /// Broj bitova u značenju,*uključujući* skriveni bit.
    const SIG_BITS: u8;

    /// Broj bitova u značenju,*isključujući* skriveni bit.
    const EXPLICIT_SIG_BITS: u8;

    /// Maksimalni pravni eksponent u frakcijskoj zastupljenosti.
    const MAX_EXP: i16;

    /// Minimalni pravni eksponent u razlomljenoj zastupljenosti, isključujući subnormale.
    const MIN_EXP: i16;

    /// `MAX_EXP` za integralni prikaz, tj. sa primijenjenim pomakom.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodirano (tj. sa offset pristranošću)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` za integralni prikaz, tj. sa primijenjenim pomakom.
    const MIN_EXP_INT: i16;

    /// Maksimalan normalizirani značaj u integralnom predstavljanju.
    const MAX_SIG: u64;

    /// Minimalni normalizirani značaj u integralnom predstavljanju.
    const MIN_SIG: u64;
}

// Uglavnom zaobilazno rješenje za #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Vraća mantisu, eksponent i znak kao cijele brojeve.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponentna pristranost + pomak mantise
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe nije siguran da li se `as` pravilno zaokružuje na svim platformama.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Vraća mantisu, eksponent i znak kao cijele brojeve.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponentna pristranost + pomak mantise
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe nije siguran da li se `as` pravilno zaokružuje na svim platformama.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Pretvara `Fp` u najbliži tip plovnog stroja.
/// Ne obrađuje subnormalne rezultate.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f je 64-bitni, tako da xe ima mantisni pomak od 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Zaokružite 64-bitni značaj i na T::SIG_BITS bitove sa pola-do-čak.
/// Ne obrađuje preljev eksponenta.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Podesite pomak mantise
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Obrnuto od `RawFloat::unpack()` za normalizirane brojeve.
/// Panics ako značenje ili eksponent nisu valjani za normalizirane brojeve.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Uklonite skriveni bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Podesite eksponent za pristranost eksponenta i pomak mantise
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Ostavite znakovni bit na 0 ("+"), svi naši brojevi su pozitivni
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruirajte subnormalno.Mantisa od 0 je dozvoljena i konstruira nulu.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodirani eksponent je 0, znakovni bit je 0, tako da samo moramo reinterpretirati bitove.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Približno bignum sa Fp.Zaokružuje unutar 0.5 ULP s pola do ujednačenja.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Odrezali smo sve bitove prije indeksa `start`, tj. Efektivno pomičemo udesno za iznos od `start`, pa je ovo ujedno i eksponent koji nam treba.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Okrugli (half-to-even), ovisno o skraćenim bitovima.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Pronalazi najveći broj s pomičnom zarezom strogo manji od argumenta.
/// Ne obrađuje subnormale, nulu ili podliv eksponenta.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Pronađite najmanji broj s pomičnom zarezom strogo veći od argumenta.
// Ova operacija zasićuje, tj. next_float(inf) ==inf.
// Za razliku od većine koda u ovom modulu, ova funkcija obrađuje nulu, subnormale i beskonačnosti.
// Međutim, kao i svi ostali kodovi ovdje se ne bavi NaN i negativnim brojevima.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Čini se da je ovo previše dobro da bi bilo istina, ali djeluje.
        // 0.0 kodiran je kao riječ koja je nula.Subnormali su 0x000m ... m, gdje je m mantisa.
        // Konkretno, najmanji subnormal je 0x0 ... 01, a najveći 0x000F ... F.
        // Najmanji normalni broj je 0x0010 ... 0, tako da i ovaj kutni slučaj radi.
        // Ako priraštaj preplavi mantisu, nosivi bit povećava eksponent kako želimo, a bitovi mantise postaju nula.
        // Zbog skrivene konvencije bitova, i ovo je upravo ono što želimo!
        // Konačno, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}