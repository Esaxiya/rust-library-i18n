//! Implementacije stvari poput `Eq` za nizove fiksne dužine do određene dužine.
//! Na kraju, trebali bismo biti u mogućnosti generalizirati na sve dužine.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Pretvara referencu na `T` u referencu na niz dužine 1 (bez kopiranja).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // SIGURNOST: Pretvaranje `&T` u `&[T; 1]` je zvuk.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Pretvara promjenjivu referencu na `T` u promjenjivu referencu u niz dužine 1 (bez kopiranja).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // SIGURNOST: Pretvaranje `&mut T` u `&mut [T; 1]` je zvuk.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Uslužni program Portrait implementiran samo na nizovima fiksne veličine
///
/// Ovaj Portrait se može koristiti za implementaciju ostalih traits na nizovima fiksne veličine bez nanošenja velikog napuhavanja metapodataka.
///
/// Portrait je označen kao nesiguran kako bi ograničio implementatore na nizove fiksne veličine.
/// Korisnik ovog Portrait može pretpostaviti da implementatori imaju tačan raspored u memoriji niza fiksne veličine (na primjer, za nesigurnu inicijalizaciju).
///
///
/// Imajte na umu da traits [`AsRef`] i [`AsMut`] pružaju slične metode za tipove koji možda nisu nizovi fiksne veličine.
/// Implementatori bi umjesto toga trebali preferirati one traits.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Pretvara niz u nepromjenjivi presjek
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Pretvara niz u promjenjivu krišku
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Tip greške vraćen kada konverzija iz presjeka u niz ne uspije.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // SIGURNOST: ok jer smo upravo provjerili odgovara li duljina
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // SIGURNOST: ok jer smo upravo provjerili odgovara li duljina
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: izostavljeni su neki manje važni impulsi kako bi se smanjio nadutost koda
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// Provodi usporedbu nizova [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Podrazumijevani implici ne mogu se izvoditi s const genericima, jer `[T; 0]` ne zahtijeva implementaciju Default-a, a posjedovanje različitih blokova impl za različite brojeve još nije podržano.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// Vraća niz iste veličine kao `self`, s funkcijom `f` primijenjenom na svaki element redom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // SIGURNOST: pouzdano znamo da će ovaj iterator dati tačno `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Komprimira' dva niza u jedan niz parova.
    ///
    /// `zip()` vraća novi niz gdje je svaki element nabor gdje prvi element dolazi iz prvog polja, a drugi element dolazi iz drugog niza.
    ///
    /// Drugim riječima, spaja dva niza u jedan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // SIGURNOST: pouzdano znamo da će ovaj iterator dati tačno `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Vraća krišku koja sadrži čitav niz.Ekvivalentno `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Vraća promjenjivu krišku koja sadrži čitav niz.
    /// Ekvivalentno `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Posuđuje svaki element i vraća niz referenci iste veličine kao `self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Ova metoda je posebno korisna ako se kombinira s drugim metodama, poput [`map`](#method.map).
    /// Na ovaj način možete izbjeći premještanje izvornog niza ako njegovi elementi nisu `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // Još uvijek možemo pristupiti izvornom nizu: nije premješten.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // SIGURNOST: pouzdano znamo da će ovaj iterator dati tačno `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Svaki element mijenja posudjivo i vraća niz promjenjivih referenci iste veličine kao `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // SIGURNOST: pouzdano znamo da će ovaj iterator dati tačno `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// Povlači `N` stavke iz `iter` i vraća ih kao niz.
/// Ako iterator daje manje od `N` stavki, ova funkcija pokazuje nedefinirano ponašanje.
///
///
/// Pogledajte [`collect_into_array`] za više informacija.
///
/// # Safety
///
/// Na pozivaocu je da garantuje da `iter` daje najmanje `N` predmeta.
/// Kršenje ovog stanja uzrokuje nedefinirano ponašanje.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` je ovdje donekle eksperiment.Ovo je samo
    // unutarnju funkciju, zato je slobodno uklonite ako se ovo ograničeno pokaže kao loša ideja.
    // U tom slučaju, ne zaboravite ukloniti i donju granicu `debug_assert!` ispod!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // SIGURNOST: obuhvaćeno ugovorom o funkciji.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// Povlači `N` stavke iz `iter` i vraća ih kao niz.Ako iterator daje manje od `N` stavki, vraća se `None` i ispuštaju se sve već dane stavke.
///
/// Budući da se iterator prosljeđuje kao promjenjiva referenca i ova funkcija poziva `next` najviše `N` puta, iterator se i dalje može koristiti za dohvaćanje preostalih stavki.
///
///
/// Ako se `iter.next()` uspaniči, ispuštaju se sve stavke koje je iterator već dao.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // SIGURNOST: Prazan niz je uvijek naseljen i nema invarijante valjanosti.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // SIGURNOST: ova sirova kriška sadržavat će samo inicijalizirane objekte.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // SIGURNOST: `guard.initialized` počinje na 0, uvećava se za jedan u
        // petlja i petlja se prekida kada dostigne N (što je `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Provjerite je li cijeli niz inicijaliziran.
        if guard.initialized == N {
            mem::forget(guard);

            // SIGURNOST: gornji uvjet tvrdi da su svi elementi
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // To se postiže samo ako je iterator iscrpljen prije nego što `guard.initialized` dosegne `N`.
    //
    // Također imajte na umu da je ovdje ispušten `guard`, koji ispušta sve već inicijalizirane elemente.
    None
}