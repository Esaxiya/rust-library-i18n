//! Osnovne funkcije za rad s memorijom.
//!
//! Ovaj modul sadrži funkcije za ispitivanje veličine i poravnanje tipova, inicijalizaciju i manipulaciju memorijom.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Preuzima vlasništvo i "forgets" o vrijednosti **bez pokretanja njegovog destruktora**.
///
/// Svi resursi kojima upravlja vrijednost, poput memorije hrpe ili ručice datoteke, zauvijek će se zadržati u nedostižnom stanju.Međutim, to ne garantira da će pokazivači na ovu memoriju ostati valjani.
///
/// * Ako želite propustiti memoriju, pogledajte [`Box::leak`].
/// * Ako želite dobiti neobrađeni pokazivač na memoriju, pogledajte [`Box::into_raw`].
/// * Ako želite pravilno raspolagati vrijednošću, izvodeći njen destruktor, pogledajte [`mem::drop`].
///
/// # Safety
///
/// `forget` nije označen kao `unsafe`, jer sigurnosne garancije Rust ne uključuju garanciju da će destruktori uvijek raditi.
/// Na primjer, program može stvoriti referentni ciklus pomoću [`Rc`][rc] ili pozvati [`process::exit`][exit] za izlaz bez pokretanja destruktora.
/// Stoga, dopuštanje `mem::forget` sigurnog koda u osnovi ne mijenja sigurnosne garancije Rust.
///
/// Međutim, curenje resursa poput memorije ili I/O objekata je obično nepoželjno.
/// Potreba se javlja u nekim specijaliziranim slučajevima upotrebe za FFI ili nesigurnim kodom, ali čak i tada se obično daje prednost [`ManuallyDrop`].
///
/// Budući da je zaboravljanje vrijednosti dopušteno, svaki `unsafe` kôd koji napišete mora omogućiti ovu mogućnost.Ne možete vratiti vrijednost i očekivati da će pozivatelj nužno pokrenuti destruktor vrijednosti.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanonska sigurna upotreba `mem::forget` je zaobilaženje destruktora vrijednosti implementiranog od `Drop` Portrait.Na primjer, ovo će propustiti `File`, tj
/// povratite prostor koji zauzima varijabla, ali nikada ne zatvorite osnovni sistemski resurs:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ovo je korisno kada je vlasništvo nad temeljnim resursom prethodno preneseno na kod izvan Rust, na primjer prijenosom sirovog deskriptora datoteke na C kod.
///
/// # Odnos sa `ManuallyDrop`
///
/// Iako se `mem::forget` takođe može koristiti za prenos vlasništva *memorije*, to čini podložno greškama.
/// [`ManuallyDrop`] treba koristiti umjesto toga.Razmotrite, na primjer, ovaj kod:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Napravite `String` koristeći sadržaj `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // curi `v` jer njegovom memorijom sada upravlja `s`
/// mem::forget(v);  // POGREŠKA, v je nevažeća i ne smije se proslijediti funkciji
/// assert_eq!(s, "Az");
/// // `s` implicitno se ispušta i memorija se oslobađa.
/// ```
///
/// Postoje dva problema sa gornjim primjerom:
///
/// * Ako bi se dodalo više koda između konstrukcije `String` i pozivanja `mem::forget()`, panic unutar njega prouzročio bi dvostruko oslobađanje jer istom memorijom upravljaju i `v` i `s`.
/// * Nakon poziva `v.as_mut_ptr()` i prijenosa vlasništva nad podacima na `s`, vrijednost `v` je nevaljana.
/// Čak i kada je vrijednost samo premještena u `mem::forget` (koji je neće pregledati), neki tipovi imaju stroge zahtjeve u pogledu vrijednosti zbog kojih su nevažeći kada vise ili više nisu u vlasništvu.
/// Korištenje nevaljanih vrijednosti na bilo koji način, uključujući njihovo prosljeđivanje ili vraćanje iz funkcija, predstavlja nedefinirano ponašanje i može razbiti pretpostavke koje je napravio kompajler.
///
/// Prelaskom na `ManuallyDrop` izbjegavaju se oba problema:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Prije nego što rastavimo `v` na njegove sirove dijelove, pobrinite se da ne padne!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Sada rastavite `v`.Ove operacije ne mogu panic, tako da ne može doći do curenja.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Konačno, napravite `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` implicitno se ispušta i memorija se oslobađa.
/// ```
///
/// `ManuallyDrop` robusno sprječava dvostruko besplatno jer onemogućimo destruktor `v` prije nego što učinimo bilo što drugo.
/// `mem::forget()` to ne dopušta jer troši svoj argument prisiljavajući nas da ga zovemo tek nakon što iz `v` izdvojimo bilo što što nam treba.
/// Čak i ako se panic uvede između izgradnje `ManuallyDrop` i izgradnje niza (što se ne može dogoditi u kodu kao što je prikazano), to bi rezultiralo curenjem, a ne dvostrukim oslobađanjem.
/// Drugim riječima, `ManuallyDrop` griješi na strani curenja, umjesto na strani (dvostrukog) ispuštanja.
///
/// Takođe, `ManuallyDrop` nas sprječava da moramo prijeći na "touch" `v` nakon prijenosa vlasništva na `s`-posljednji korak interakcije s `v` za njegovo uklanjanje bez pokretanja njegovog destruktora u potpunosti je izbjegnut.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kao i [`forget`], ali prihvaća i veličine veličine.
///
/// Ova funkcija je samo podloga namijenjena uklanjanju kada se `unsized_locals` funkcija stabilizira.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Vraća veličinu tipa u bajtovima.
///
/// Preciznije, ovo je pomak u bajtovima između uzastopnih elemenata u nizu s tom vrstom stavke, uključujući poravnanje.
///
/// Dakle, za bilo koji tip `T` i dužinu `n`, `[T; n]` ima veličinu `n * size_of::<T>()`.
///
/// Općenito, veličina tipa nije stabilna u svim kompilacijama, ali specifični tipovi poput primitiva jesu.
///
/// Sljedeća tablica daje veličinu primitiva.
///
/// Upišite |veličina_: :<Type>()
/// ---- | ---------------
/// () |. |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Nadalje, `usize` i `isize` imaju istu veličinu.
///
/// Tipovi `*const T`, `&T`, `Box<T>`, `Option<&T>` i `Option<Box<T>>` imaju istu veličinu.
/// Ako je `T` veličine, svi tipovi imaju istu veličinu kao `usize`.
///
/// Promjenjivost pokazivača ne mijenja njegovu veličinu.Kao takvi, `&T` i `&mut T` imaju istu veličinu.
/// Isto tako za `*const T` i `* mut T`.
///
/// # Veličina `#[repr(C)]` predmeta
///
/// Zastupljenost `C` za stavke ima definiran izgled.
/// Ovim rasporedom veličina stavki je također stabilna sve dok sva polja imaju stabilnu veličinu.
///
/// ## Veličina konstrukcija
///
/// Za `structs`, veličina se određuje prema sljedećem algoritmu.
///
/// Za svako polje u strukturi poredanoj redoslijedom deklaracije:
///
/// 1. Dodajte veličinu polja.
/// 2. Zaokružite trenutnu veličinu na najbliži višekratnik sljedećeg polja [alignment].
///
/// Konačno, zaokružite veličinu strukture na najbliži višekratnik [alignment].
/// Poravnanje strukture je obično najveće poravnanje svih njegovih polja;ovo se može promijeniti upotrebom `repr(align(N))`.
///
/// Za razliku od `C`, strukture nulte veličine nisu zaokružene na jedan bajt.
///
/// ## Veličina Enuma
///
/// Enumi koji ne nose druge podatke osim diskriminanta imaju istu veličinu kao C enumi na platformi za koju su kompajlirani.
///
/// ## Veličina sindikata
///
/// Veličina sindikata je veličina njegovog najvećeg polja.
///
/// Za razliku od `C`, sindikati nulte veličine nisu zaokruženi na jedan bajt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Neki primitivci
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Neki nizovi
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Jednakost veličine pokazivača
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Korišćenje `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Veličina prvog polja je 1, pa dodajte 1 veličini.Veličina je 1.
/// // Poravnanje drugog polja je 2, pa dodajte 1 veličini za popunjavanje.Veličina je 2.
/// // Veličina drugog polja je 2, pa dodajte 2 veličini.Veličina je 4.
/// // Poravnanje trećeg polja je 1, pa dodajte 0 veličini za popunjavanje.Veličina je 4.
/// // Veličina trećeg polja je 1, pa dodajte 1 veličini.Veličina je 5.
/// // Konačno, poravnanje strukture je 2 (jer je najveće poravnanje među njenim poljima 2), pa dodajte 1 veličini za popunjavanje.
/// // Veličina je 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Strukture korijena slijede ista pravila.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Imajte na umu da preuređivanje polja može smanjiti veličinu.
/// // Oba uklonjena bajta možemo ukloniti stavljanjem `third` ispred `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Veličina unije je veličina najvećeg polja.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Vraća veličinu usmjerene vrijednosti u bajtovima.
///
/// To je obično isto kao `size_of::<T>()`.
/// Međutim, kada `T`*nema* statički poznatu veličinu, npr. Krišku [`[T]`][slice] ili [trait object], tada se `size_of_val` može koristiti za dobivanje dinamički poznate veličine.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURNOST: `val` je referenca, tako da je važeći sirovi pokazivač
    unsafe { intrinsics::size_of_val(val) }
}

/// Vraća veličinu usmjerene vrijednosti u bajtovima.
///
/// To je obično isto kao `size_of::<T>()`.Međutim, kada `T`*nema* statički poznatu veličinu, npr. Rez [`[T]`][slice] ili [trait object], tada se `size_of_val_raw` može koristiti za dobivanje dinamički poznate veličine.
///
/// # Safety
///
/// Ovu funkciju je sigurno nazvati samo ako su ispunjeni sljedeći uvjeti:
///
/// - Ako je `T` `Sized`, ovu funkciju je uvijek sigurno nazvati.
/// - Ako je neodređeni rep `T`:
///     - [slice], tada dužina reza reza mora biti inicijalizirani cijeli broj, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
///     - [trait object], tada vtable dio pokazivača mora usmjeravati na valjani vtable stečen prisilom bez veličine, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
///
///     - (unstable) [extern type], tada je ovu funkciju uvijek sigurno nazvati, ali može panic ili na drugi način vratiti pogrešnu vrijednost jer raspored vanjskog tipa nije poznat.
///     To je isto ponašanje kao [`size_of_val`] u odnosu na tip s repom vanjskog tipa.
///     - u suprotnom, konzervativno nije dozvoljeno pozivanje ove funkcije.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURNOST: pozivatelj mora navesti valjani sirovi pokazivač
    unsafe { intrinsics::size_of_val(val) }
}

/// Vraća [ABI] minimalno poravnanje tipa.
///
/// Svaka referenca na vrijednost tipa `T` mora biti višekratnik ovog broja.
///
/// Ovo je poravnanje koje se koristi za strukturna polja.Može biti manji od željenog poravnanja.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vraća [ABI] potrebno minimalno poravnanje tipa vrijednosti na koju ukazuje `val`.
///
/// Svaka referenca na vrijednost tipa `T` mora biti višekratnik ovog broja.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURNOST: val je referenca, tako da je važeći sirovi pokazivač
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vraća [ABI] minimalno poravnanje tipa.
///
/// Svaka referenca na vrijednost tipa `T` mora biti višekratnik ovog broja.
///
/// Ovo je poravnanje koje se koristi za strukturna polja.Može biti manji od željenog poravnanja.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vraća [ABI] potrebno minimalno poravnanje tipa vrijednosti na koju ukazuje `val`.
///
/// Svaka referenca na vrijednost tipa `T` mora biti višekratnik ovog broja.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURNOST: val je referenca, tako da je važeći sirovi pokazivač
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vraća [ABI] potrebno minimalno poravnanje tipa vrijednosti na koju ukazuje `val`.
///
/// Svaka referenca na vrijednost tipa `T` mora biti višekratnik ovog broja.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ovu funkciju je sigurno nazvati samo ako su ispunjeni sljedeći uvjeti:
///
/// - Ako je `T` `Sized`, ovu funkciju je uvijek sigurno nazvati.
/// - Ako je neodređeni rep `T`:
///     - [slice], tada dužina reza reza mora biti inicijalizirani cijeli broj, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
///     - [trait object], tada vtable dio pokazivača mora usmjeravati na valjani vtable stečen prisilom bez veličine, a veličina *cijele vrijednosti*(dinamička dužina repa + prefiks statičke veličine) mora odgovarati `isize`.
///
///     - (unstable) [extern type], tada je ovu funkciju uvijek sigurno nazvati, ali može panic ili na drugi način vratiti pogrešnu vrijednost jer raspored vanjskog tipa nije poznat.
///     To je isto ponašanje kao [`align_of_val`] u odnosu na tip s repom vanjskog tipa.
///     - u suprotnom, konzervativno nije dozvoljeno pozivanje ove funkcije.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURNOST: pozivatelj mora navesti valjani sirovi pokazivač
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vraća `true` ako su ispuštanje vrijednosti tipa `T` bitne.
///
/// Ovo je čisto savjet za optimizaciju i može se primijeniti konzervativno:
/// može vratiti `true` za tipove koje zapravo ne treba ispuštati.
/// Kao takav uvijek vraćanje `true` bila bi valjana implementacija ove funkcije.Međutim, ako ova funkcija zapravo vraća `false`, onda možete biti sigurni da ispuštanje `T` nema nuspojava.
///
/// Implementacije stvari poput zbirki na niskom nivou, koje trebaju ručno ispustiti svoje podatke, trebale bi koristiti ovu funkciju kako bi izbjegle nepotrebno pokušavanje ispuštanja sav njihov sadržaj kada su uništene.
///
/// Ovo možda neće napraviti razliku u verzijama izdanja (gdje se petlja koja nema nuspojave lako otkriva i eliminira), ali je često velika pobjeda za verzije uklanjanja pogrešaka.
///
/// Imajte na umu da [`drop_in_place`] već vrši ovu provjeru, pa ako se vaše radno opterećenje može smanjiti na neki mali broj [`drop_in_place`] poziva, korištenje ovog je nepotrebno.
/// Posebno imajte na umu da možete [`drop_in_place`] odrezati, a to će napraviti jednu provjeru needs_drop za sve vrijednosti.
///
/// Tipovi poput Vec dakle samo `drop_in_place(&mut self[..])` bez eksplicitne upotrebe `needs_drop`.
/// Tipovi poput [`HashMap`], s druge strane, moraju ispuštati vrijednosti jednu po jednu i trebali bi koristiti ovaj API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Evo primjera kako kolekcija može koristiti `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ispustite podatke
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Vraća vrijednost tipa `T` predstavljenu bajt uzorkom nule.
///
/// To znači da, na primjer, bajt za popunjavanje u `(u8, u16)` nije nužno nuliran.
///
/// Ne postoji garancija da uzorak bajtova s nula predstavlja valjanu vrijednost nekog tipa `T`.
/// Na primjer, uzorak bajta sa nulom nije valjana vrijednost za referentne tipove (`&T`, `&mut T`) i pokazivače na funkcije.
/// Korištenje `zeroed` na takvim tipovima uzrokuje trenutno [undefined behavior][ub], jer [the Rust compiler assumes][inv] da uvijek postoji valjana vrijednost u varijabli koju smatra inicijaliziranom.
///
///
/// Ovo ima isti efekat kao i [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ponekad je korisno za FFI, ali ga obično treba izbjegavati.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ispravna upotreba ove funkcije: inicijalizacija cijelog broja s nulom.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Neispravna* upotreba ove funkcije: inicijalizacija reference nulom.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedefinisano ponašanje!
/// let _y: fn() = unsafe { mem::zeroed() }; // I opet!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIGURNOST: pozivatelj mora garantirati da vrijednost nula vrijedi za `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Zaobilazi normalne provjere inicijalizacije memorije Rust pretvarajući se da proizvodi vrijednost tipa `T`, a pritom ne radi ništa.
///
/// **Ova je funkcija zastarjela.** Umjesto nje koristite [`MaybeUninit<T>`].
///
/// Razlog zastarjevanja je taj što se funkcija u osnovi ne može pravilno koristiti: ima isti učinak kao [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kao što [`assume_init` documentation][assume_init] objašnjava, [the Rust compiler assumes][inv] te vrijednosti su pravilno inicijalizirane.
/// Kao posljedica toga, pozivanje npr
/// `mem::uninitialized::<bool>()` uzrokuje trenutno nedefinirano ponašanje za vraćanje `bool` koji definitivno nije ni `true` ni `false`.
/// Još gore, zaista neinicijalizirana memorija, poput onoga što se ovdje vrati, posebna je po tome što kompajler zna da ona nema fiksnu vrijednost.
/// To čini nedefinirano ponašanje neinicijaliziranim podacima u varijabli, čak i ako ta varijabla ima cijeli broj.
/// (Primijetite da pravila oko neinicijaliziranih cijelih brojeva još nisu finalizirana, ali dok nisu, poželjno ih je izbjegavati.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIGURNOST: pozivatelj mora garantirati da je neobavezna vrijednost važeća za `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Mijenja vrijednosti na dvije izmjenjive lokacije, bez deinicijalizacije bilo koje.
///
/// * Ako želite zamijeniti sa zadanom ili lažnom vrijednošću, pogledajte [`take`].
/// * Ako želite zamijeniti s prosljeđenom vrijednošću, vraćajući staru vrijednost, pogledajte [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIGURNOST: sirovi pokazivači su stvoreni od sigurnih promjenjivih referenci koje zadovoljavaju sve
    // ograničenja na `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Zamjenjuje `dest` sa zadanom vrijednošću `T`, vraćajući prethodnu vrijednost `dest`.
///
/// * Ako želite zamijeniti vrijednosti dvije varijable, pogledajte [`swap`].
/// * Ako želite zamijeniti prosljeđenom vrijednošću umjesto zadane vrijednosti, pogledajte [`replace`].
///
/// # Examples
///
/// Jednostavan primjer:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` omogućava preuzimanje vlasništva nad strukturnim poljem zamjenom sa vrijednošću "empty".
/// Bez `take` možete naići na ovakve probleme:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Imajte na umu da `T` ne mora nužno implementirati [`Clone`], pa ne može ni klonirati i resetovati `self.buf`.
/// Ali `take` se može koristiti za razdvajanje izvorne vrijednosti `self.buf` od `self`, omogućavajući mu vraćanje:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Premješta `src` u referencirani `dest`, vraćajući prethodnu vrijednost `dest`.
///
/// Nijedna vrijednost nije ispuštena.
///
/// * Ako želite zamijeniti vrijednosti dvije varijable, pogledajte [`swap`].
/// * Ako želite zamijeniti zadanom vrijednošću, pogledajte [`take`].
///
/// # Examples
///
/// Jednostavan primjer:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` dozvoljava potrošnju polja struct zamjenom s drugom vrijednošću.
/// Bez `replace` možete naići na ovakve probleme:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Imajte na umu da `T` ne mora nužno implementirati [`Clone`], pa ne možemo ni klonirati `self.buf[i]` da izbjegnemo premještanje.
/// Ali `replace` se može koristiti za razdvajanje izvorne vrijednosti po tom indeksu od `self`, omogućavajući joj vraćanje:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIGURNOST: Čitamo iz `dest`, ali nakon toga direktno pišemo `src`,
    // takav da se stara vrijednost ne duplicira.
    // Ništa se ne ispušta i ovdje ništa ne može panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Raspolaže vrijednošću.
///
/// To se čini pozivanjem implementacije argumenta [`Drop`][drop].
///
/// Ovo efektivno ne čini ništa za tipove koji implementiraju `Copy`, npr
/// integers.
/// Takve se vrijednosti kopiraju i _then_ se premješta u funkciju, tako da vrijednost ostaje nakon ovog poziva funkcije.
///
///
/// Ova funkcija nije magija;doslovno se definira kao
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Budući da je `_x` premješten u funkciju, automatski se ispušta prije nego što se funkcija vrati.
///
/// [drop]: Drop
///
/// # Examples
///
/// Osnovna upotreba:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // izričito ispustite vector
/// ```
///
/// Budući da [`RefCell`] provodi pravila posuđivanja za vrijeme izvođenja, `drop` može pustiti [`RefCell`] posuđivanje:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // odreknite promjenjive pozajmice na ovom slotu
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` ne utječe na cijele brojeve i druge tipove koji implementiraju [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopija `x` se premješta i ispušta
/// drop(y); // kopija `y` se premješta i ispušta
///
/// println!("x: {}, y: {}", x, y.0); // još uvijek dostupan
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretira `src` kao tip `&U`, a zatim čita `src` bez premještanja sadržane vrijednosti.
///
/// Ova će funkcija nesigurno pretpostaviti da pokazivač `src` vrijedi za bajtove [`size_of::<U>`][size_of] pretvaranjem `&T` u `&U` i čitanjem `&U` (osim što se to radi na točan način čak i kada `&U` postavlja strože zahtjeve za poravnanje od `&T`).
/// Takođe će nesigurno stvoriti kopiju sadržane vrijednosti umjesto da se preseli iz `src`.
///
/// Nije greška u vremenu kompajliranja ako `T` i `U` imaju različite veličine, ali se preporučuje da se ova funkcija poziva samo tamo gdje `T` i `U` imaju istu veličinu.Ova funkcija aktivira [undefined behavior][ub] ako je `U` veći od `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopirajte podatke iz 'foo_array' i tretirajte ih kao 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Izmijenite kopirane podatke
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Sadržaj 'foo_array' se nije smio mijenjati
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ako U ima veći zahtjev za poravnavanjem, src možda neće biti odgovarajuće poravnat.
    if align_of::<U>() > align_of::<T>() {
        // SIGURNOST: `src` je referenca za koju se garantira da vrijedi za čitanje.
        // Pozivatelj mora jamčiti da je stvarna transmutacija sigurna.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIGURNOST: `src` je referenca za koju se garantira da vrijedi za čitanje.
        // Upravo smo provjerili je li `src as *const U` pravilno poravnan.
        // Pozivatelj mora jamčiti da je stvarna transmutacija sigurna.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Neproziran tip koji predstavlja diskriminaciju enuma.
///
/// Pogledajte funkciju [`discriminant`] u ovom modulu za više informacija.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ove implementacije Portrait ne mogu se izvesti jer ne želimo ograničenja na T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Vraća vrijednost koja jedinstveno identificira varijantu nabrajanja u `v`.
///
/// Ako `T` nije enum, pozivanje ove funkcije neće rezultirati nedefiniranim ponašanjem, ali povratna vrijednost je neodređena.
///
///
/// # Stability
///
/// Diskriminant varijante nabrajanja može se promijeniti ako se promijeni definicija nabrajanja.
/// Diskriminant neke varijante neće se mijenjati između kompilacija s istim kompajlerom.
///
/// # Examples
///
/// Ovo se može koristiti za usporedbu nabrajanja koja nose podatke, a zanemarujući stvarne podatke:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Vraća broj varijanti u tipu enum `T`.
///
/// Ako `T` nije enum, pozivanje ove funkcije neće rezultirati nedefiniranim ponašanjem, ali povratna vrijednost je neodređena.
/// Jednako tako, ako je `T` nabrajanje s više varijanti od `usize::MAX`, povratna vrijednost nije navedena.
/// Nenaseljene varijante će se računati.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}