//! Primitivni traits i tipovi koji predstavljaju osnovna svojstva tipova.
//!
//! Tipovi Rust mogu se klasificirati na razne korisne načine prema njihovim suštinskim svojstvima.
//! Ove klasifikacije su predstavljene kao traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipovi koji se mogu prenijeti preko granica niti.
///
/// Ovaj se Portrait automatski implementira kada kompajler utvrdi da je prikladan.
///
/// Primjer tipa koji nije `Send` je pokazivač za brojanje referenci [`rc::Rc`][`Rc`].
/// Ako dvije niti pokušaju klonirati [`Rc`] koji upućuju na istu vrijednost brojenu referencama, možda će pokušati istovremeno ažurirati broj referenci, što je [undefined behavior][ub], jer [`Rc`] ne koristi atomske operacije.
///
/// Njegov rođak [`sync::Arc`][arc] koristi atomske operacije (što rezultira određenim režijskim rezultatima), a samim tim je i `Send`.
///
/// Pogledajte [the Nomicon](../../nomicon/send-and-sync.html) za više detalja.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipovi sa konstantnom veličinom poznati u vrijeme sastavljanja.
///
/// Svi parametri tipa imaju implicitnu granicu `Sized`.Posebna sintaksa `?Sized` može se koristiti za uklanjanje ove veze ako nije prikladna.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//greška: Veličina nije implementirana za [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Jedini izuzetak je implicitni `Self` tip Portrait.
/// Portrait nema implicitni `Sized` vezan jer je to nekompatibilno sa [Portrait objektom] gdje, prema definiciji, Portrait mora raditi sa svim mogućim implementatorima, pa prema tome može biti bilo koje veličine.
///
///
/// Iako će vam Rust omogućiti da vežete `Sized` sa Portrait, kasnije ga nećete moći koristiti za formiranje objekta Portrait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // neka y: &dyn Bar= &Impl;//greška: Portrait `Bar` ne može se pretvoriti u objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // za Default, na primjer, koji zahtijeva da se `[T]: !Default` može procijeniti
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipovi koji mogu biti "unsized" za dinamički veličine.
///
/// Na primjer, tip niza veličine `[i8; 2]` implementira `Unsize<[i8]>` i `Unsize<dyn fmt::Debug>`.
///
/// Sve implementacije `Unsize` automatski osigurava kompajler.
///
/// `Unsize` implementiran je za:
///
/// - `[T; N]` je `Unsize<[T]>`
/// - `T` je `Unsize<dyn Trait>` kada `T: Trait`
/// - `Foo<..., T, ...>` je `Unsize<Foo<..., U, ...>>` ako:
///   - `T: Unsize<U>`
///   - Foo je struktura
///   - Samo posljednje polje `Foo` ima tip koji uključuje `T`
///   - `T` nije dio tipa bilo kojeg drugog polja
///   - `Bar<T>: Unsize<Bar<U>>`, ako posljednje polje `Foo` ima tip `Bar<T>`
///
/// `Unsize` koristi se zajedno sa [`ops::CoerceUnsized`] kako bi se omogućilo da "user-defined" spremnici poput [`Rc`] sadrže tipove dinamičke veličine.
/// Pogledajte [DST coercion RFC][RFC982] i [the nomicon entry on coercion][nomicon-coerce] za više detalja.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Potreban Portrait za konstante koje se koriste u podudaranju uzoraka.
///
/// Bilo koji tip koji izvodi `PartialEq` automatski implementira ovaj Portrait,*bez obzira* da li njegovi parametri tipa implementiraju `Eq`.
///
/// Ako `const` stavka sadrži neki tip koji ne implementira ovaj Portrait, tada taj tip ili (1.) ne implementira `PartialEq` (što znači da konstanta neće pružiti onu metodu upoređivanja, za koju pretpostavlja da je generiranje koda dostupna), ili (2.) implementira *svoju* verzija `PartialEq` (za koju pretpostavljamo da nije u skladu sa usporedbom strukturne jednakosti).
///
///
/// U bilo kojem od gornja dva scenarija, odbacujemo upotrebu takve konstante u podudaranju uzorka.
///
/// Pogledajte i [structural match RFC][RFC1445] i [issue 63438] koji su motivirali prelazak sa dizajna zasnovan na atributima na ovaj Portrait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Potreban Portrait za konstante koje se koriste u podudaranju uzoraka.
///
/// Bilo koji tip koji izvodi `Eq` automatski implementira ovaj Portrait,*bez obzira* da li njegovi parametri tipa implementiraju `Eq`.
///
/// Ovo je hak za zaobilaženje ograničenja u našem tipskom sistemu.
///
/// # Background
///
/// Želimo da tipovi consts koji se koriste u podudaranju uzoraka imaju atribut `#[derive(PartialEq, Eq)]`.
///
/// U idealnijem svijetu, mogli bismo provjeriti taj zahtjev samo provjerom da li dati tip implementira i `StructuralPartialEq` Portrait *i*`Eq` Portrait.
/// Međutim, možete imati ADT-ove koji *rade*`derive(PartialEq, Eq)` i biti slučaj koji želimo da kompajler prihvati, a opet tip konstante ne uspijeva implementirati `Eq`.
///
/// Naime, slučaj poput ovog:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problem u gornjem kodu je taj što `Wrap<fn(&())>` ne implementira `PartialEq`, niti `Eq`, jer `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Stoga se ne možemo pouzdati u naivnu provjeru `StructuralPartialEq` i pukog `Eq`.
///
/// Kao hak za rješavanje ovog problema, koristimo dva odvojena traits koja ubrizgava svaki od dva izvedena (`#[derive(PartialEq)]` i `#[derive(Eq)]`) i provjeravamo jesu li oba prisutna kao dio provjere strukturnih podudaranja.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipovi čije se vrijednosti mogu duplicirati jednostavnim kopiranjem bitova.
///
/// Prema zadanim postavkama, vezivanje varijabli ima 'semantiku premještanja'.Drugim riječima:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` se preselio u `y` i zato se ne može koristiti
///
/// // println! ("{: ?}", x);//greška: upotreba premještene vrijednosti
/// ```
///
/// Međutim, ako tip implementira `Copy`, on umjesto toga ima 'semantiku kopiranja':
///
/// ```
/// // Možemo izvesti implementaciju `Copy`.
/// // `Clone` je takođe potreban, jer je to supersrait `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` je kopija `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Važno je napomenuti da je u ova dva primjera jedina razlika je li vam dozvoljen pristup `x` nakon dodjele.
/// Ispod haube, kopiranje i premještanje mogu rezultirati kopiranjem bitova u memoriju, iako se to ponekad optimizira.
///
/// ## Kako mogu implementirati `Copy`?
///
/// Postoje dva načina za primenu `Copy` na vašem tipu.Najjednostavnije je koristiti `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Takođe možete ručno implementirati `Copy` i `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Između njih dvije postoji mala razlika: `derive` strategija također će `Copy` postaviti na parametre tipa, što nije uvijek poželjno.
///
/// ## Koja je razlika između `Copy` i `Clone`?
///
/// Kopije se dešavaju implicitno, na primjer kao dio zadatka `y = x`.Ponašanje `Copy` nije za prevaliti;to je uvijek jednostavna bitna kopija.
///
/// Kloniranje je eksplicitna radnja, `x.clone()`.Implementacija [`Clone`] može pružiti svako ponašanje specifično za tip potrebno za sigurno dupliciranje vrijednosti.
/// Na primjer, implementacija [`Clone`] za [`String`] treba kopirati usmjereni me uspremnik niza u hrpu.
/// Jednostavna bitna kopija vrijednosti [`String`] samo bi kopirala pokazivač, što bi dovelo do dvostrukog slobodnog niza.
/// Iz tog razloga, [`String`] je [`Clone`], ali ne i `Copy`.
///
/// [`Clone`] je supersretit `Copy`, tako da sve što je `Copy` mora takođe implementirati [`Clone`].
/// Ako je tip `Copy`, tada njegova implementacija [`Clone`] treba vratiti samo `*self` (vidi gornji primjer).
///
/// ## Kada moj tip može biti `Copy`?
///
/// Tip može implementirati `Copy` ako sve njegove komponente implementiraju `Copy`.Na primjer, ova struktura može biti `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktura može biti `Copy`, a [`i32`] je `Copy`, stoga `Point` ispunjava uvjete da bude `Copy`.
/// Suprotno tome, uzmite u obzir
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` ne može implementirati `Copy`, jer [`Vec<T>`] nije `Copy`.Ako pokušamo izvesti implementaciju `Copy`, dobit ćemo grešku:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Dijeljene reference (`&T`) također su `Copy`, pa tip može biti `Copy`, čak i ako sadrži dijeljene reference tipa `T` koji nisu * `Copy`.
/// Razmotrite sljedeću strukturu, koja može implementirati `Copy`, jer sadrži samo *dijeljenu referencu* na naš ne-`Kopiraj` tip `PointList` odozgo:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kada *ne može* moj tip biti `Copy`?
///
/// Neke se vrste ne mogu sigurno kopirati.Na primjer, kopiranje `&mut T` stvorilo bi zamjenjivu promjenjivu referencu.
/// Kopiranje [`String`] dupliciralo bi odgovornost za upravljanje međuspremnikom [`String`], što bi dovelo do dvostrukog besplatnog.
///
/// Generalizirajući potonji slučaj, bilo koji tip koji implementira [`Drop`] ne može biti `Copy`, jer upravlja nekim resursom, osim vlastitih bajtova [`size_of::<T>`].
///
/// Ako pokušate implementirati `Copy` na strukturu ili enum koji sadrži podatke koji nisu `Kopija`, dobit ćete pogrešku [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kada *treba* da moj tip bude `Copy`?
///
/// Uopšteno govoreći, ako vaš tip _can_ implementira `Copy`, trebao bi.
/// Imajte na umu da je implementacija `Copy` dio javnog API-ja vašeg tipa.
/// Ako tip može postati "Kopija" u future, bilo bi pametno sada izostaviti implementaciju `Copy`, kako bi se izbjegla lomljiva promjena API-ja.
///
/// ## Dodatni realizatori
///
/// Pored [implementors listed below][impls], sljedeći tipovi također implementiraju `Copy`:
///
/// * Tipovi stavki funkcije (tj. Različiti tipovi definirani za svaku funkciju)
/// * Tipovi pokazivača funkcija (npr., `fn() -> i32`)
/// * Tipovi nizova, za sve veličine, ako tip stavke također implementira `Copy` (npr. `[i32; 123456]`)
/// * Tipovi parova, ako svaka komponenta također implementira `Copy` (npr. `()`, `(i32, bool)`)
/// * Tipovi zatvaranja, ako ne zauzimaju vrijednost iz okoline ili ako sve takve zabilježene vrijednosti same implementiraju `Copy`.
///   Imajte na umu da varijable zabilježene dijeljenom referencom uvijek implementiraju `Copy` (čak i ako referent to ne čini), dok varijable zabilježene promjenjivom referencom nikada ne implementiraju `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) To omogućava kopiranje tipa koji ne implementira `Copy` zbog nezadovoljnih životnih granica (kopiranje `A<'_>` kada su samo `A<'static>: Copy` i `A<'_>: Clone`).
// Za sada imamo ovaj atribut samo zato što na `Copy` postoji poprilično postojećih specijalizacija koje već postoje u standardnoj biblioteci, i ne postoji način da se sigurno ponaša trenutno.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Izvedite makro koji generira impl od Portrait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipovi za koje je sigurno dijeliti reference između niti.
///
/// Ovaj se Portrait automatski implementira kada kompajler utvrdi da je prikladan.
///
/// Precizna definicija je: tip `T` je [`Sync`] tada i samo ako je `&T` [`Send`].
/// Drugim riječima, ako ne postoji mogućnost [undefined behavior][ub] (uključujući utrke podataka) prilikom prosljeđivanja `&T` referenci između niti.
///
/// Kao što bi se moglo očekivati, primitivni tipovi poput [`u8`] i [`f64`] su svi [`Sync`], a tako su i jednostavni agregatni tipovi koji ih sadrže, poput korijena, struktura i enuma.
/// Više primjera osnovnih tipova [`Sync`] uključuju tipove "immutable" poput `&T` i one s jednostavnom naslijeđenom promjenjivošću, kao što su [`Box<T>`][box], [`Vec<T>`][vec] i većinu drugih vrsta kolekcije.
///
/// (Generički parametri moraju biti [`Sync`] da bi njihov spremnik bio [`Sync`].)
///
/// Pomalo iznenađujuća posljedica definicije je da je `&mut T` `Sync` (ako je `T` `Sync`) iako se čini da bi to moglo pružiti nesinkroniziranu mutaciju.
/// Trik je u tome što promjenjiva referenca koja stoji iza zajedničke reference (to jest `& &mut T`) postaje samo za čitanje, kao da je `& &T`.
/// Stoga ne postoji rizik od utrke podataka.
///
/// Tipovi koji nisu `Sync` su oni koji imaju "interior mutability" u obliku koji nije siguran u nit, kao što su [`Cell`][cell] i [`RefCell`][refcell].
/// Ovi tipovi omogućavaju mutaciju njihovog sadržaja čak i putem nepromjenjive zajedničke reference.
/// Na primjer, metoda `set` na [`Cell<T>`][cell] uzima `&self`, tako da zahtijeva samo zajedničku referencu [`&Cell<T>`][cell].
/// Metoda ne vrši sinhronizaciju, pa [`Cell`][cell] ne može biti `Sync`.
///
/// Još jedan primjer tipa koji nije `Sync` je pokazivač za brojanje referenci [`Rc`][rc].
/// S obzirom na bilo koji referentni [`&Rc<T>`][rc], možete klonirati novi [`Rc<T>`][rc], mijenjajući brojeve referenci na neatomski način.
///
/// U slučajevima kada je potrebna unutarnja promjenljivost bez navoja, Rust nudi [atomic data types], kao i eksplicitno zaključavanje putem [`sync::Mutex`][mutex] i [`sync::RwLock`][rwlock].
/// Ovi tipovi osiguravaju da bilo koja mutacija ne može uzrokovati rase podataka, stoga su tipovi `Sync`.
/// Isto tako, [`sync::Arc`][arc] pruža analogni [`Rc`][rc] bez niti.
///
/// Sve vrste sa unutrašnjom promjenljivošću također moraju koristiti omot [`cell::UnsafeCell`][unsafecell] oko value(s) koji može biti mutiran putem zajedničke reference.
/// Ako to ne učinim, to je [undefined behavior][ub].
/// Na primjer, [`transmute`][transmute]-ing iz `&T` u `&mut T` je nevaljano.
///
/// Pogledajte [the Nomicon][nomicon-send-and-sync] za više detalja o `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): jednom kada podrška za dodavanje napomena u `rustc_on_unimplemented` pređe u beta verziju, a ona je proširena kako bi se provjerilo je li zatvaranje bilo gdje u lancu zahtjeva, proširite je kao takvu (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tip nulte veličine koji se koristi za označavanje stvari koje "act like" posjeduju `T`.
///
/// Dodavanje polja `PhantomData<T>` vašem tipu govori kompajleru da se vaš tip ponaša kao da čuva vrijednost tipa `T`, iako to zapravo i ne čini.
/// Ove informacije koriste se pri izračunavanju određenih sigurnosnih svojstava.
///
/// Za detaljnija objašnjenja kako koristiti `PhantomData<T>`, molimo pogledajte [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Užasna nota 👻👻👻
///
/// Iako oboje imaju zastrašujuća imena, `PhantomData` i 'fantomski tipovi' su povezani, ali nisu identični.Parametar fantomskog tipa je jednostavno parametar tipa koji se nikada ne koristi.
/// U Rust, ovo često dovodi do prigovora kompajlera, a rješenje je dodati "dummy" upotrebu putem `PhantomData`.
///
/// # Examples
///
/// ## Neiskorišteni životni parametri
///
/// Možda je najčešći slučaj upotrebe za `PhantomData` struktura koja ima neiskorišteni parametar životnog vijeka, obično kao dio nekog nesigurnog koda.
/// Na primjer, ovdje je struktura `Slice` koja ima dva pokazivača tipa `*const T`, koji vjerojatno negdje pokazuju u niz:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Namjera je da osnovni podaci vrijede samo za životni vijek `'a`, tako da `Slice` ne bi trebao nadživjeti `'a`.
/// Međutim, ova namjera nije izražena u kodu, jer ne postoji upotreba cijelog životnog vijeka `'a`, pa stoga nije jasno na koje se podatke odnosi.
/// To možemo ispraviti rekavši kompajleru da se ponaša *kao da* struktura `Slice` sadrži referencu `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ovo takođe zahtijeva napomenu `T: 'a`, koja ukazuje da su sve reference u `T` važeće tokom životnog vijeka `'a`.
///
/// Pri inicijalizaciji `Slice` jednostavno navedete vrijednost `PhantomData` za polje `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Neiskorišteni parametri tipa
///
/// Ponekad se dogodi da imate neiskorištene parametre tipa koji pokazuju koji tip podataka strukturi pripada "tied", iako ti podaci zapravo nisu pronađeni u samoj strukturi.
/// Evo primjera kada se ovo javlja kod [FFI].
/// Strano sučelje koristi ručke tipa `*mut ()` za upućivanje na vrijednosti Rust različitih tipova.
/// Pratimo tip Rust koristeći parametar fantomskog tipa na strukturi `ExternalResource` koji obavija ručicu.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Vlasništvo i provjera ispuštanja
///
/// Dodavanje polja tipa `PhantomData<T>` ukazuje na to da vaš tip posjeduje podatke tipa `T`.To zauzvrat implicira da kada vaš tip padne, on može ispustiti jedan ili više primjeraka tipa `T`.
/// Ovo ima utjecaja na analizu [drop check] kompajlera Rust.
///
/// Ako vaša struktura zapravo ne *posjeduje* podatke tipa `T`, bolje je koristiti referentni tip, poput `PhantomData<&'a T>` (ideally) ili `PhantomData<*const T>` (ako se ne primjenjuje životni vijek), kako ne bi naznačili vlasništvo.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Interni kompajler Portrait koristi se za označavanje vrste enum diskriminatora.
///
/// Ovaj Portrait se automatski primjenjuje za svaki tip i ne dodaje nikakve garancije za [`mem::Discriminant`].
/// **Nije definirano ponašanje** transmutirati između `DiscriminantKind::Discriminant` i `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Tip diskriminanta koji mora zadovoljiti Portrait bounds koji zahtijeva `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Interni kompajler Portrait koji se koristi za određivanje sadrži li tip neki `UnsafeCell` interno, ali ne posrednim putem.
///
/// To utječe, na primjer, na to da li je `static` te vrste smješten u statičku memoriju samo za čitanje ili statičku memoriju koja se može pisati.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Vrste koje se mogu sigurno premjestiti nakon pričvršćivanja.
///
/// Sam Rust nema pojam nepokretnih tipova i smatra da su potezi (npr. Dodjelom ili [`mem::replace`]) uvijek sigurni.
///
/// Umjesto toga koristi se tip [`Pin`][Pin] za sprečavanje kretanja kroz sistem tipova.Pokazivači `P<T>` zamotani u omot [`Pin<P<T>>`][Pin] ne mogu se pomaknuti.
/// Pogledajte dokumentaciju [`pin` module] za više informacija o pričvršćivanju.
///
/// Implementacija `Unpin` Portrait za `T` ukida ograničenja odvajanja tipa, što zatim omogućava premještanje `T` iz [`Pin<P<T>>`][Pin] s funkcijama kao što je [`mem::replace`].
///
///
/// `Unpin` uopće nema posljedicu za neprikvačene podatke.
/// Konkretno, [`mem::replace`] sretno premješta `!Unpin` podatke (radi za bilo koji `&mut T`, ne samo kada je `T: Unpin`).
/// Međutim, ne možete koristiti [`mem::replace`] na podacima umotanim u [`Pin<P<T>>`][Pin], jer ne možete dobiti `&mut T` koji vam je potreban za to, a *to* čini ono što ovaj sistem radi.
///
/// To se, na primjer, može učiniti samo na tipovima koji implementiraju `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Potrebna nam je promjenjiva referenca za poziv `mem::replace`.
/// // Takvu referencu možemo dobiti ako (implicitly) poziva `Pin::deref_mut`, ali to je moguće samo zato što `String` implementira `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ovaj Portrait se automatski implementira za gotovo sve tipove.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Tip markera koji ne implementira `Unpin`.
///
/// Ako tip sadrži `PhantomPinned`, prema zadanim postavkama neće implementirati `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementacije `Copy` za primitivne tipove.
///
/// Implementacije koje se ne mogu opisati u Rust implementirane su u `traits::SelectionContext::copy_clone_conditions()` u `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Dijeljene reference mogu se kopirati, ali izmjenjive reference *ne mogu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}