#![stable(feature = "core_hint", since = "1.27.0")]

//! Savjeti kompajleru koji utječe na to kako kod treba emitirati ili optimizirati.
//! Savjeti mogu biti vrijeme kompajliranja ili vrijeme izvođenja.

use crate::intrinsics;

/// Obavještava kompajler da ova točka u kodu nije dostupna, omogućavajući daljnje optimizacije.
///
/// # Safety
///
/// Postizanje ove funkcije potpuno je *nedefinirano ponašanje*(UB).Konkretno, kompajler pretpostavlja da se svi UB nikada ne smiju dogoditi, i stoga će eliminirati sve grane koje dođu do poziva na `unreachable_unchecked()`.
///
/// Kao i svi slučajevi UB-a, ako se pokaže da je ta pretpostavka pogrešna, tj. Ako je poziv `unreachable_unchecked()` zapravo dostupan među svim mogućim protocima kontrole, kompajler će primijeniti pogrešnu strategiju optimizacije, a ponekad može čak i oštetiti naizgled nepovezani kod, što uzrokuje za otklanjanje grešaka.
///
///
/// Koristite ovu funkciju samo kada možete dokazati da je kôd nikada neće pozvati.
/// U suprotnom, razmislite o korištenju makronaredba [`unreachable!`], koji ne dopušta optimizacije, ali će panic biti izveden.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` je uvijek pozitivan (ne nula), stoga `checked_div` nikada neće vratiti `None`.
/////
///     // Stoga je ostalo branch nedostižno.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIGURNOST: ugovor o sigurnosti za `intrinsics::unreachable` mora
    // biti prihvaćen od strane pozivaoca.
    unsafe { intrinsics::unreachable() }
}

/// Emitira mašinsku naredbu da signalizira procesoru da radi u spin-loop-u zauzetog čekanja ("spin lock").
///
/// Po primanju spin-loop signala procesor može optimizirati svoje ponašanje, na primjer, uštedom energije ili prebacivanjem hyper-niti.
///
/// Ova se funkcija razlikuje od [`thread::yield_now`] koja izravno ustupa planeru sistema, dok `spin_loop` ne komunicira s operativnim sistemom.
///
/// Uobičajeni slučaj upotrebe za `spin_loop` je primjena ograničenog optimističnog okretanja u CAS petlji u primitivima sinhronizacije.
/// Da bi se izbjegli problemi poput prioritetne inverzije, toplo se preporučuje da se spin petlja prekine nakon konačne količine iteracija i napravi odgovarajući syscall za blokiranje.
///
///
/// **Napomena**: Na platformama koje ne podržavaju primanje spin-loop nagovještaja, ova funkcija uopće ne radi ništa.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Zajednička atomska vrijednost koju će niti koristiti za koordinaciju
/// let live = Arc::new(AtomicBool::new(false));
///
/// // U pozadini ćemo na kraju postaviti vrijednost
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Uradite nešto, a zatim vrijednost učinite živom
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Natrag na našu trenutnu nit, čekamo da se vrijednost postavi
/// while !live.load(Ordering::Acquire) {
///     // Okretna petlja je nagovještaj CPU-u da ga čekamo, ali vjerojatno ne baš dugo
/////
///     hint::spin_loop();
/// }
///
/// // Vrijednost je sada postavljena
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIGURNOST: atribut `cfg` osigurava da ovo izvršavamo samo na ciljevima x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIGURNOST: atribut `cfg` osigurava da ovo izvršavamo samo na ciljevima x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIGURNOST: atribut `cfg` osigurava da ovo izvršavamo samo na ciljevima aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIGURNOST: `cfg` attr osigurava da ovo izvršavamo samo na ciljevima s oružjem
            // sa podrškom za funkciju v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funkcija identiteta koja *__ nagovještava __* kompajleru da bude maksimalno pesimističan u pogledu onoga što `black_box` može učiniti.
///
/// Za razliku od [`std::convert::identity`], kompajleru Rust podstiče se da pretpostavi da `black_box` može koristiti `dummy` na bilo koji mogući valjani način na koji je Rust kôd dozvoljen bez uvođenja nedefiniranog ponašanja u pozivni kod.
///
/// Ovo svojstvo čini `black_box` korisnim za pisanje koda u kojem određene optimizacije nisu željene, poput mjerila.
///
/// Međutim, imajte na umu da se `black_box` pruža (i može biti samo) na bazi "best-effort".Opseg u kojem može blokirati optimizacije može se razlikovati ovisno o platformi i upotrebi genetske kode.
/// Programi se ni na koji način ne mogu osloniti na `black_box` za *ispravnost*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Moramo "use" argumentirati na neki način da LLVM ne može introspektirati, a na ciljevima koji ga podržavaju obično možemo koristiti ugrađeni sklop da to učinimo.
    // LLVM-ovo tumačenje inline montaže je da je to, pa, crna kutija.
    // Ovo nije najbolja implementacija jer vjerovatno optimizira više nego što želimo, ali zasad je dovoljno dobra.
    //
    //

    #[cfg(not(miri))] // Ovo je samo nagovještaj, pa je lijepo preskočiti Miri.
    // SIGURNOST: inline sklop je ne-op.
    unsafe {
        // FIXME: Ne mogu koristiti `asm!` jer ne podržava MIPS i druge arhitekture.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}