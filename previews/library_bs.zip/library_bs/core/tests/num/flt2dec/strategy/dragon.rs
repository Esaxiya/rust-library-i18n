use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri je prespora
fn exact_sanity_test() {
    // Ovaj test završava sa onim što mogu samo pretpostaviti da je neki ugaoni slučaj funkcije biblioteke `exp2`, definiran u bilo kojem C izvođenju koje koristimo.
    // U VS 2013 ova je funkcija očito imala grešku jer ovaj test ne uspijeva kad je povezana, ali s VS 2015 greška izgleda ispravljeno jer test radi sasvim u redu.
    //
    // Čini se da je greška razlika u povratnoj vrijednosti `exp2(-1057)`, gdje u VS 2013 vraća dvostruko s bitnim uzorkom 0x2, a u VS 2015 vraća 0x20000.
    //
    //
    // Za sada samo zanemarite ovaj test u potpunosti na MSVC-u jer je ionako testiran negdje drugdje i nismo previše zainteresirani za testiranje implementacije exp2 svake platforme.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}