//! A support ìkàwé fun Makiro onkọwe nigbati asọye titun macros.
//!
//! Ikawe ikawe yii, ti a pese nipasẹ pinpin boṣewa, n pese awọn oriṣi ti a run ninu awọn atọkun ti awọn asọye macro asọye nipa ilana gẹgẹbi macros `#[proc_macro]` iṣẹ, awọn abuda macro `#[proc_macro_attribute]` ati awọn abuda itọsẹ aṣa##[proc_macro_derive] `.
//!
//!
//! Wo [the book] fun diẹ sii.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Ipinnu boya proc_macro ti a ti ṣe wiwọle si awọn Lọwọlọwọ nṣiṣẹ eto.
///
/// Proc_macro crate ti pinnu nikan fun lilo inu imuse ti awọn macros ilana.Gbogbo awọn iṣẹ ni yi crate panic ti o ba ti invoked lati ita kan ti a ti ti ilana Makiro, gẹgẹ bi awọn lati kan Kọ akosile tabi kuro igbeyewo tabi arinrin Rust alakomeji.
///
/// Pẹlu ero fun awọn ile-ikawe Rust ti a ṣe apẹrẹ lati ṣe atilẹyin macro ati awọn ọran lilo ti kii ṣe macro, `proc_macro::is_available()` n pese ọna ti kii ṣe ẹru lati wa boya awọn amayederun ti o nilo lati lo API ti proc_macro wa ni lọwọlọwọ.
/// Padà otitọ ti o ba ti invoked lati inu ti a ti ilana Makiro, eke ti o ba ti invoked lati eyikeyi miiran alakomeji.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Iru akọkọ ti a pese nipasẹ crate yii, ti o nsoju ṣiṣan abayọ ti tokens, tabi, ni pataki diẹ sii, ọkọọkan awọn igi token.
/// Awọn iru pese atọkun fun iterating lori awon token igi ati, Lọna, gba nọmba kan ti token igi sinu ọkan san.
///
///
/// Eleyi jẹ mejeeji ti awọn input ki o si wu wa ti `#[proc_macro]`, `#[proc_macro_attribute]` ati `#[proc_macro_derive]` itumo.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Aṣiṣe pada lati `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Pada ohun ṣofo `TokenStream` ti o ni awọn ti ko si token igi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Sọwedowo o ba ti yi `TokenStream` ti ṣofo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Awọn igbiyanju lati fọ okun sinu tokens ati ṣe itupalẹ awọn tokens wọnyẹn sinu ṣiṣan token kan.
/// Ṣe le kuna fun awọn idi pupọ, fun apẹẹrẹ, ti okun ba ni awọn ipin-aiṣedeede aiṣedeede tabi awọn ohun kikọ ti ko si ninu ede naa.
///
/// Gbogbo tokens ni parsed san gba `Span::call_site()` Gbese.
///
/// NOTE: diẹ ninu awọn aṣiṣe le fa panics dipo ti o pada `LexError`.A ni ẹtọ lati yi awọn aṣiṣe wọnyi pada si `LexError`s nigbamii.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ṣe atẹjade ṣiṣan token bi okun ti o yẹ ki o ṣe iyipada adanu pipadanu pada sinu ṣiṣan token kanna (awọn igba modulo), ayafi fun o ṣee ṣe `TokenTree: : Group`s pẹlu awọn onipin `Delimiter::None` ati awọn iwe kika nọmba odi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Tẹ jade token ni a fọọmu rọrun fun ṣatunṣe.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ṣẹda ṣiṣan token kan ti o ni igi token kan ṣoṣo ninu.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Gba nọmba awọn igi token sinu ṣiṣan kan.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// A "flattening" išišẹ lori token ṣiṣan, gba token igi lati ọpọ token ṣiṣan sinu kan nikan san.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Lo ohun iṣapeye imuse if/when o ti ṣee.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Awọn alaye imuse ti gbogbo eniyan fun iru `TokenStream`, gẹgẹbi awọn olutọtọ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Olutayo lori TokenStream`'s` TokenTree`s.
    /// Awọn aṣetunṣe ni "shallow", fun apẹẹrẹ, awọn iterator ko ni recurse sinu delimited awọn ẹgbẹ, ati padà gbogbo awọn ẹgbẹ bi token igi.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` gba lainidii tokens ati gbooro sinu `TokenStream` ti n ṣapejuwe igbewọle.
/// Fun apẹẹrẹ, `quote!(a + b)` yoo ṣe agbejade ikosile kan, pe, nigba ti a ba ṣe ayẹwo, o kọ `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting ni ṣe pẹlu `$`, ati ki o ṣiṣẹ nipa gbigbe awọn nikan tókàn ident bi awọn unquoted oro.
/// Lati lò `$` ara, lo `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// A ekun ti orisun koodu, pẹlú pẹlu Makiro imugboroosi alaye.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Ṣẹda `Diagnostic` tuntun pẹlu `message` ti a fun ni igba `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Igba kan ti o yanju ni aaye itumọ macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Awọn igba ti awọn epe ti isiyi ti ilana Makiro.
    /// Identifiers da pẹlu yi igba yoo wa ni resolved bi ti o ba ti won ni won kọ taara ni Makiro ipe ipo (ipe-ojula tenilorun) ati awọn miiran koodu ni Makiro ipe Aaye yoo ni anfani lati tọka si wọn bi daradara.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Iwọn kan ti o duro fun imototo `macro_rules`, ati nigbakan awọn ipinnu ni aaye itumọ macro (awọn oniyipada agbegbe, awọn akole, `$crate`) ati nigbakan ni aaye ipe macro (ohun gbogbo miiran).
    ///
    /// Awọn igba ipo ni ya lati awọn ipe-ojula.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Awọn atilẹba orisun faili sinu eyi ti yi igba ojuami.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` fun tokens ninu imugboroosi macro ti tẹlẹ lati eyiti o ti ipilẹṣẹ `self` lati, ti o ba jẹ eyikeyi.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Awọn igba fun awọn origin orisun koodu ti `self` a ti ipilẹṣẹ lati.
    /// Ti o ba ti yi `Span` a ko ti ipilẹṣẹ lati miiran Makiro expansions ki o si awọn pada iye jẹ kanna bi `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Gba line/column ibẹrẹ ni faili orisun fun igba yii.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// N ni awọn opin line/column ni orisun faili fun yi igba.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Ṣẹda igba tuntun ti o yika `self` ati `other`.
    ///
    /// Padà `None` ti o ba ti `self` ati `other` ni o wa lati yatọ si awọn faili.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Ṣẹda igba tuntun pẹlu alaye line/column kanna bi `self` ṣugbọn iyẹn yanju awọn aami bi ẹnipe o wa ni `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Ṣẹda igba tuntun pẹlu ihuwasi ipinnu orukọ kanna bi `self` ṣugbọn pẹlu alaye line/column ti `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Ṣe afiwe si awọn igba lati rii boya wọn ba dọgba.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Pada awọn orisun ọrọ sile kan igba.
    /// Eyi tọju koodu orisun atilẹba, pẹlu awọn aye ati awọn asọye.
    /// O pada nikan abajade ti igba naa baamu koodu orisun gidi.
    ///
    /// Note: Awọn observable esi ti a Makiro yẹ ki o nikan gbekele lori tokens ati ki o ko lori yi orisun ọrọ.
    ///
    /// Awọn esi ti yi iṣẹ ni a ti o dara ju akitiyan lati ṣee lo fun àyẹwò nikan.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tẹ a igba ni a fọọmu rọrun fun ṣatunṣe.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// A ila-iwe bata o nsoju ni ibere tabi opin ti a `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Laini itọka 1 ni faili orisun lori eyiti igba bẹrẹ tabi pari (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Awọn 0-iwon iwe (ni UTF-8 ohun kikọ) ni orisun faili lori eyi ti awọn igba bẹrẹ tabi pari (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Faili orisun ti `Span` ti a fun.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// N ni awọn ona si yi orisun faili.
    ///
    /// ### Note
    /// Ti o ba ti awọn koodu igba ni nkan ṣe pẹlu yi `SourceFile` a ti ipilẹṣẹ nipa ohun ita Makiro, yi Makiro, yi le ma wa ni ohun gangan ona lori awọn filesystem.
    /// Lo [`is_real`] lati ṣayẹwo.
    ///
    /// Tun akọsilẹ ti paapa ti o ba `is_real` pada `true`, ti o ba `--remap-path-prefix` a ti kọja lori awọn pipaṣẹ ila, awọn ona bi fun ko le kosi jẹ wulo.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Pada `true` o ba ti yi orisun faili ti wa ni a gidi orisun faili, ati ki o ko ipilẹṣẹ nipa ohun ita Makiro ká imugboroosi.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Eyi jẹ gige titi di igba ti a ṣe imuse awọn igba larin ati pe a le ni awọn faili orisun gidi fun awọn igba ti ipilẹṣẹ ni awọn macro itagbangba.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A nikan token tabi a delimited ọkọọkan ti token igi (eg, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// A token san yika nipasẹ akọmọ delimiters.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// An idamo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// A nikan aami ifamisi ohun kikọ ('+', `,`, `$`, bbl).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// A gegebi ohun kikọ (`'a'`), okun (`"hello"`), nọmba (`2.3`), bbl
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Padà awọn igba ti yi igi, delegating si awọn `span` ọna ti awọn ti o wa ninu token tabi a delimited san.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Ṣe atunto igba fun *nikan token* yii.
    ///
    /// Akọsilẹ ti o ba ti yi token ni a `Group` ki o si yi ọna ti yoo ko tunto awọn igba ti kọọkan ninu awọn ti abẹnu tokens, yi yoo nìkan Egypt si awọn `set_span` ọna ti kọọkan iyatọ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Awọn igi token tẹ jade ni fọọmu ti o rọrun fun n ṣatunṣe aṣiṣe.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Olukuluku iwọnyi ni orukọ ninu iru apẹrẹ ni yokokoro ti o wa, nitorinaa maṣe yọ ara rẹ lẹnu pẹlu ipele afikun ti aibikita
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Ṣe atẹjade igi token bi okun ti o yẹ ki o jẹ iyipada aibikita pada sinu igi token kanna (awọn igba modulo), ayafi fun o ṣee ṣe `TokenTree: : Group`s pẹlu awọn ipin-iye `Delimiter::None` ati awọn iwe kika nọmba odi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// A delimited token san.
///
/// A `Group` fipa ni a `TokenStream` eyi ti o ti yika nipasẹ `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Apejuwe bawo ni a ṣe fi ọna kan lẹsẹsẹ ti awọn igi token ṣe.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Olupin ti ko mọ, ti o le, fun apẹẹrẹ, han ni ayika tokens nbo lati "macro variable" `$var` kan.
    /// O ṣe pataki lati tọju awọn iṣiṣẹ awọn oniṣẹ ni awọn ọran bii `$var * 3` nibiti `$var` jẹ `1 + 2`.
    /// Awọn onigbọwọ aibikita ko le ye yika iyipo ti ṣiṣan token kan nipasẹ okun kan.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Ṣẹda titun kan `Group` pẹlu awọn ti fi fun delimiter ati token san.
    ///
    /// Eleyi Constructor yoo ṣeto awọn igba fun egbe yi to `Span::call_site()`.
    /// Lati yi igba pada o le lo ọna `set_span` ni isalẹ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Pada ni delimiter ti yi `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Pada awọn `TokenStream` ti tokens ti o ṣe iyasọtọ ni `Group` yii.
    ///
    /// Akọsilẹ ti awọn pada token san ko ni awọn delimiter pada loke.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Pada igba fun awọn ipinlẹ ti ṣiṣan token yii, o gbooro si gbogbo `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Pada ni igba ntokasi si awọn šiši delimiter ti yi ẹgbẹ.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Pada igba ti o tọka si opin ti ẹgbẹ yii.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configures awọn igba fun yi `Group` ká delimiters, sugbon ko awọn oniwe-ti abẹnu tokens.
    ///
    /// Yi ọna ti yoo **ko** ṣeto awọn igba ti gbogbo awọn ti abẹnu tokens nkowe nipa egbe yi, sugbon dipo o yoo nikan ṣeto awọn igba ti awọn delimiter tokens ni awọn ipele ti awọn `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Jade awọn ẹgbẹ bi a okun ti o yẹ ki o wa losslessly alayipada pada sinu kanna ẹgbẹ (ìfiwọn Gbese), ayafi fun o ṣee 'TokenTree: : Group`s pẹlu `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` jẹ kikọ kikọsilẹ ọkan bi `+`, `-` tabi `#`.
///
/// Olona-kikọ awọn oniṣẹ bi `+=` ti wa ni ipoduduro bi meji instances ti `Punct` pẹlu o yatọ si iwa ti `Spacing` pada.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Boya ohun `Punct` ni atẹle lẹsẹkẹsẹ nipasẹ miiran `Punct` tabi atẹle nipa miiran token tabi whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// eg, `+` ni `Alone` ni `+ =`, `+ident` tabi `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eg, `+` ni `Joint` ni `+=` tabi `'#`.
    /// Ni afikun, agbasọ ẹyọkan `'` le darapọ mọ awọn idanimọ lati dagba awọn igbesi aye `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Ṣẹda `Punct` tuntun kan lati kikọ ti o fun ati aye.
    /// Ariyanjiyan `ch` gbọdọ jẹ ohun kikọ silẹ to wulo ti ede gba laaye, bibẹkọ ti iṣẹ naa yoo jẹ panic.
    ///
    /// Awọn pada `Punct` yoo ni awọn aiyipada igba ti `Span::call_site()` eyi ti le wa siwaju ni tunto pẹlu awọn `set_span` ọna isalẹ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Pada ni iye ti yi aami ifamisi ti ohun kikọ silẹ bi `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Pada aye ti ohun kikọ silẹ kikọ sii, n tọka boya o tẹle atẹle lẹsẹkẹsẹ nipasẹ `Punct` miiran ni ṣiṣan token, nitorinaa wọn le ni idapọ pọ si oniṣẹ oniye-pupọ pupọ (`Joint`), tabi ti o tẹle pẹlu diẹ ninu token miiran tabi aaye fifin (`Alone`) nitorinaa oniṣẹ naa ni otitọ pari.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Pada ni igba fun yi aami ifamisi ohun kikọ silẹ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Tunto awọn igba fun yi aami ifamisi ohun kikọ silẹ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tẹ awọn aami ti ohun kikọ silẹ bi a okun ti o yẹ ki o wa losslessly alayipada pada sinu kanna ohun kikọ silẹ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// An idamo (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Ṣẹda titun kan `Ident` pẹlu awọn ti fi fun `string` bi daradara bi awọn kan `span`.
    /// The `string` ariyanjiyan gbọdọ jẹ a wulo idamo idasilẹ nipasẹ awọn ede (pẹlu koko, fun apẹẹrẹ `self` tabi `fn`).Tabi ki, awọn iṣẹ yio panic.
    ///
    /// Akiyesi pe `span`, lọwọlọwọ ni rustc, tunto alaye imototo fun idanimọ yii.
    ///
    /// Gẹgẹ bi ti akoko yii `Span::call_site()` yọkuro ni gbangba si "call-site" imototo ti o tumọ si pe awọn idamo ti a ṣẹda pẹlu igba yii yoo yanju bi ẹni pe wọn kọ taara ni ipo ipe macro, ati pe koodu miiran ni aaye ipe macro yoo ni anfani lati tọka si wọn bi daradara.
    ///
    ///
    /// Nigbamii Gbese bi `Span::def_site()` yoo gba to ijade ni lati "definition-site" tenilorun afipamo pe identifiers da pẹlu yi igba yoo wa ni resolved ni awọn ipo ti awọn Makiro definition ati awọn miiran koodu ni Makiro ipe ojula yoo ko ni anfani lati tọka si wọn.
    ///
    /// Nitori pataki lọwọlọwọ ti imototo ẹniti nṣe nkan yii, laisi tokens miiran, nilo `Span` lati ṣalaye ni ikole.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Kanna bi `Ident::new`, ṣugbọn ṣẹda a aise idamo (`r#ident`).
    /// The `string` ariyanjiyan wa a wulo idamo idasilẹ nipasẹ awọn ede (pẹlu koko, eg `fn`).
    /// Koko eyi ti o wa nkan elo ni ona àáyá (eg
    /// `self`, 'Super`) ti wa ni ko ni atilẹyin, ati ki o yoo fa a panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Pada ni igba ti yi `Ident`, yàtò gbogbo okun pada nipa [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configures awọn igba ti yi `Ident`, o ṣee iyipada awọn oniwe-tenilorun o tọ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tẹ awọn idamo bi a okun ti o yẹ ki o wa losslessly alayipada pada sinu kanna idamo.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Okun gangan (`"hello"`), okun baiti (`b"hello"`), ohun kikọ (`'a'`), ohun kikọ baiti (`b'a'`), odidi tabi nọmba ojuami ti n ṣanfo pẹlu pẹlu tabi laisi suffix (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Awọn onkọwe Boolean bii `true` ati `false` ko wa nibi, wọn jẹ `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ṣẹda odidi odidi afetigbọ titun pẹlu iye ti a ṣalaye.
        ///
        /// Iṣẹ yi yoo ṣẹda ohun odidi bi `1u32` ibi ti awọn odidi iye kan ni akọkọ apa ti awọn token ati awọn je ti wa ni tun suffixed ni opin.
        /// Literals da lati odi awọn nọmba ko le yọ ninu ewu yika-ajo nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
        ///
        ///
        /// Literals da nipasẹ yi ọna ni awọn `Span::call_site()` igba nipa aiyipada, eyi ti o le wa ni tunto pẹlu awọn `set_span` ọna isalẹ.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ṣẹda titun kan unsuffixed odidi gegebi pẹlu awọn pàtó kan iye.
        ///
        /// Iṣẹ yi yoo ṣẹda ohun odidi bi `1` ibi ti awọn odidi iye kan ni akọkọ apa ti awọn token.
        /// Ko si suffix ti a ṣalaye lori token yii, tumọ si pe awọn ebe bi `Literal::i8_unsuffixed(1)` jẹ deede si `Literal::u32_unsuffixed(1)`.
        /// Literals da lati odi awọn nọmba ko le yọ ninu ewu rountrips nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
        ///
        ///
        /// Literals da nipasẹ yi ọna ni awọn `Span::call_site()` igba nipa aiyipada, eyi ti o le wa ni tunto pẹlu awọn `set_span` ọna isalẹ.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Ṣẹda titun kan unsuffixed lilefoofo-ojuami gegebi.
    ///
    /// Eleyi Constructor ni iru si awon bi `Literal::i8_unsuffixed` ibi ti awọn leefofo ká iye ti wa ni emitted taara sinu token sugbon ko si suffix ti lo, ki o le wa ni mu lero jade lati wa ni a `f64` igbamiiran ni awọn alakojo.
    ///
    /// Literals da lati odi awọn nọmba ko le yọ ninu ewu rountrips nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
    ///
    /// # Panics
    ///
    /// Yi iṣẹ nbeere wipe awọn pàtó kan leefofo jẹ adópin, fun apẹẹrẹ ti o ba jẹ infinity tabi Nan iṣẹ yi yoo panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ṣẹda oju-eeyan lilefoofo tuntun ti suffixed.
    ///
    /// Eleyi Constructor yoo ṣẹda a gegebi bi `1.0f32` ibi ti awọn iye kan ni awọn opin apa ti awọn token ati `f32` ni awọn suffix ti awọn token.
    /// token yii nigbagbogbo yoo ni agbara lati jẹ `f32` ninu akopọ.
    /// Literals da lati odi awọn nọmba ko le yọ ninu ewu rountrips nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
    ///
    ///
    /// # Panics
    ///
    /// Yi iṣẹ nbeere wipe awọn pàtó kan leefofo jẹ adópin, fun apẹẹrẹ ti o ba jẹ infinity tabi Nan iṣẹ yi yoo panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Ṣẹda titun kan unsuffixed lilefoofo-ojuami gegebi.
    ///
    /// Eleyi Constructor ni iru si awon bi `Literal::i8_unsuffixed` ibi ti awọn leefofo ká iye ti wa ni emitted taara sinu token sugbon ko si suffix ti lo, ki o le wa ni mu lero jade lati wa ni a `f64` igbamiiran ni awọn alakojo.
    ///
    /// Literals da lati odi awọn nọmba ko le yọ ninu ewu rountrips nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
    ///
    /// # Panics
    ///
    /// Yi iṣẹ nbeere wipe awọn pàtó kan leefofo jẹ adópin, fun apẹẹrẹ ti o ba jẹ infinity tabi Nan iṣẹ yi yoo panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ṣẹda oju-eeyan lilefoofo tuntun ti suffixed.
    ///
    /// Olukọ yii yoo ṣẹda gege bi `1.0f64` nibiti iye ti a ṣalaye ni apakan iṣaaju ti token ati `f64` ni iyọ ti token.
    /// token yii nigbagbogbo yoo ni agbara lati jẹ `f64` ninu akopọ.
    /// Literals da lati odi awọn nọmba ko le yọ ninu ewu rountrips nipasẹ `TokenStream` tabi awọn gbolohun ọrọ ati ki o le wa ni dà si meji tokens (`-` ati ki o rere gegebi).
    ///
    ///
    /// # Panics
    ///
    /// Yi iṣẹ nbeere wipe awọn pàtó kan leefofo jẹ adópin, fun apẹẹrẹ ti o ba jẹ infinity tabi Nan iṣẹ yi yoo panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Okun gegebi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Ohun kikọ gegebi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Baiti okun gegebi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Pada igba ti o yika yi gegebi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ṣe atunto igba ti o ni ibatan fun gegebi yii.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Pada `Span` kan ti o jẹ ipin ti `self.span()` ti o ni awọn baiti orisun nikan ni ibiti o wa ni `range`.
    /// Pada `None` ti o ba ti fẹ-o wa ni ayodanu igba ni ita àla `self`.
    ///
    // FIXME(SergioBenitez): ṣayẹwo pe awọn baiti ibiti o bẹrẹ si pari ni a UTF-8 ala ti awọn orisun.
    // bibẹkọ ti, o ni seese wipe a panic yoo waye ni bomi nigbati awọn orisun ọrọ ti wa ni tejede.
    // FIXME(SergioBenitez): nibẹ ni ko si ona fun awọn olumulo lati mọ ohun ti `self.span()` kosi maapu to, ki yi ọna ti o le Lọwọlọwọ nikan wa ni a npe laimọdi rẹ.
    // Fun apẹẹrẹ, `to_string()` fun kikọ 'c' pada "'\u{63}'";nibẹ ni ko si ona fun awọn olumulo lati mọ boya awọn orisun ọrọ je 'c' tabi boya o je '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) nkankan ti o jọra si `Option::cloned`, ṣugbọn fun `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, Afara nikan pese `to_string`, ṣe `fmt::Display` ti o da lori rẹ (yiyipada ibatan deede laarin awọn meji).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Jade awọn gegebi bi a okun ti o yẹ ki o wa losslessly alayipada pada sinu kanna gegebi (ayafi fun ṣee ṣe ikotan fun lilefoofo ojuami literals).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Tọpinpin iraye si awọn oniyipada ayika.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Gba oniyipada ayika kan pada ki o ṣafikun rẹ lati kọ alaye igbẹkẹle.
    /// Kọ eto ṣiṣe olupilẹṣẹpọ yoo mọ pe a wọle si oniyipada lakoko akopọ, ati pe yoo ni anfani lati tun kọ kọ nigbati iye ti iyipada yẹn yipada.
    ///
    /// Yato si awọn durode ipasẹ yi iṣẹ yẹ ki o wa deede si `env::var` lati awọn boṣewa ìkàwé, ayafi ti awọn ariyanjiyan gbọdọ jẹ UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}