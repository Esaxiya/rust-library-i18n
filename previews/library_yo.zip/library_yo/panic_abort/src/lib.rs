//! Imuse ti Rust panics nipasẹ awọn abort ilana
//!
//! Nigba ti akawe si imuse nipasẹ unwinding, yi crate ni *Elo* rọrun!Nigba ti o ti wa ni wi, o jẹ ko oyimbo bi wapọ, sugbon nibi lọ!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" awọn payload ati shim si awọn ti o yẹ abort lori Syeed ni ibeere.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ipe std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Lori Windows, lo ẹrọ isise-pato __fastfail siseto.Ni Windows 8 ati ki o nigbamii, yi yoo fopin si lẹsẹkẹsẹ awọn ilana lai nṣiṣẹ eyikeyi ni-ilana sile handlers.
            // Ni sẹyìn awọn ẹya ti Windows, yi ọkọọkan ti awọn ilana ti yoo le ṣe mu bi ohun wiwọle ṣẹ, terminating awọn ilana sugbon laisi dandan bypassing gbogbo sile handlers.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: eyi ni imuse kanna bi ni libstd's `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Eleyi ... ni a bit ti ẹya oddity.Awọn TL; dr;ni wipe yi wa ni ti beere lati jápọ ti tọ, awọn gun alaye ni isalẹ.
//
// Ọtun nisisiyi ni binaries ti libcore/libstd ti a omi ti wa ni gbogbo compiled pẹlu `-C panic=unwind`.Eleyi ni a ṣe lati rii daju wipe binaries ni o wa maximally ni ibamu pẹlu bi ọpọlọpọ ipo bi o ti ṣee.
// The alakojo, sibẹsibẹ, nilo a "personality function" fun gbogbo iṣẹ compiled pẹlu `-C panic=unwind`.Eleyi eniyan iṣẹ ti wa ni hardcoded si awọn aami `rust_eh_personality` si ti wa ni asọye nipa awọn `eh_personality` Lang ohun kan.
//
// So...
// kilode ti kii ṣe ṣalaye ohun pẹpẹ yẹn nibi?Ibeere to dara!Awọn ọna ti panic runtimes ti wa ni ti sopọ mọ ni kosi kekere kan abele ni wipe ti won ba "sort of" ni alakojo ká crate itaja, sugbon nikan kosi ti sopọ mọ ti o ba ti miran ti wa ni ko kosi ti sopọ mọ.
//
// Yi pari soke afipamo pe mejeji yi crate ati awọn panic_unwind crate le han ninu alakojo ká crate itaja, ati awọn ti o ba ti mejeeji setumo awọn `eh_personality` Lang ohun kan ki o si ti yoo lu ohun ašiše.
//
// Lati mu awọn yi ni alakojo nikan nbeere `eh_personality` ti wa ni telẹ ti o ba ti panic asiko isise ni ti sopọ mọ ni ni awọn unwinding asiko isise, ati ki o bibẹkọ ti o ti n ko ti beere lati wa ni telẹ (rightfully ki).
// Ni idi eyi, sibẹsibẹ, yi ìkàwé kan asọye yi aami bẹ nibẹ ni ni o kere diẹ ninu awọn eniyan ibikan ni.
//
// Pataki yi aami wa ni o kan telẹ lati gba firanṣẹ soke si libcore/libstd binaries, ṣugbọn o yẹ ki o ko wa ni a npe bi a ko ba jápọ ni ohun unwinding asiko isise ni gbogbo.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // On x86_64-pc-windows-gnu ti a lo ara wa eniyan iṣẹ ti aini lati pada `ExceptionContinueSearch` bi a ba ran lori gbogbo wa awọn fireemu.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Iru si loke, yi ibamu si awọn `eh_catch_typeinfo` Lang ohun kan ti n nikan lo lori Emscripten Lọwọlọwọ.
    //
    // Niwon panics ko ina imukuro ati ajeji imukuro ni o wa Lọwọlọwọ UB pẹlu -C panic=abort (biotilejepe yi le jẹ koko ọrọ si ayipada), eyikeyi catch_unwind ipe yoo ko lo yi typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Awọn meji ti wa ni a npe ni nipa wa ibẹrẹ ohun lori i686-pc-windows-gnu, sugbon ti won ko ba ko nilo lati se ohunkohun ki awọn ara wa ni nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}