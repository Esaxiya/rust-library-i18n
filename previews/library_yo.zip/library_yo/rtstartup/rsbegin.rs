// rsbegin.o ati rsend.o ni o wa ni ki a npe ni "compiler runtime startup objects".
// Wọn ni koodu ti o nilo lati ṣe ipilẹṣẹ akoko asiko alakojo.
//
// Nigbati ohun executable tabi dylib aworan ti wa ni ti sopọ mọ, gbogbo olumulo koodu ati ikawe ti wa ni "sandwiched" laarin awọn wọnyi meji ohun awọn faili, ki koodu tabi data lati rsbegin.o di akọkọ ninu awọn oniwun ruju ti awọn aworan, ko da koodu ati data lati rsend.o di awọn ti o kẹhin eyi.
// Ipa yii le ṣee lo lati gbe awọn aami sii ni ibẹrẹ tabi ni opin abala kan, bakanna lati fi sii eyikeyi awọn akọle ti a beere tabi awọn ẹlẹsẹ.
//
// Akiyesi pe aaye titẹsi modulu gangan wa ni nkan ibẹrẹ ibẹrẹ akoko C (eyiti a npe ni `crtX.o` nigbagbogbo), eyiti lẹhinna pe awọn ipe ipadabọ ti awọn paati asiko miiran (ti a forukọsilẹ nipasẹ sibẹsibẹ apakan aworan pataki miiran).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Awọn ami ibẹrẹ ti fireemu akopọ ṣii apakan alaye alaye
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Ibere aaye fun unwinder ká ti abẹnu iwe-maaki.
    // Eyi ti ṣalaye bi `struct object` ni $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind info registration/deregistration awọn ipa ọna.
    // Wo awọn iwe ti libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // forukọsilẹ unwind Alaye lori module ikinni
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ko forukọsilẹ lori tiipa
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-kan pato init/uninit baraku registration
    pub mod mingw_init {
        // Awọn nkan ibẹrẹ MinGW (crt0.o/dllcrt0.o) yoo pe awọn akọle agbaye ni awọn apakan .ctors ati .dtors lori ibẹrẹ ati ijade.
        // Ninu ọran ti awọn DLL, eyi ni a ṣe nigbati DLL ti kojọpọ ati ti kojọpọ.
        //
        // Awọn linker yoo to awọn ruju, eyi ti o idaniloju pe wa callbacks ti wa ni be ni opin ti awọn akojọ.
        // Niwon constructors ti wa ni ṣiṣe awọn ni ọna ibere, yi idaniloju wipe wa callbacks o wa ni akọkọ ati ki o kẹhin àwọn executed.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Awọn ipe ipadabọ C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Awọn ipe ifopinsi C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}