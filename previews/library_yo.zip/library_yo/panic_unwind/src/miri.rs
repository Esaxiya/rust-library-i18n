//! Unwinding panics fun Miri.
use alloc::boxed::Box;
use core::any::Any;

// Awọn iru ti awọn payload ti awọn Miri engine propagates nipasẹ unwinding fun wa.
// Gbọdọ jẹ iwọn ijuboluwole.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Iṣẹ ita ti a pese Miri lati bẹrẹ itusilẹ.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ipese isanwo ti a kọja si `miri_start_panic` yoo jẹ ariyanjiyan ti a gba ni `cleanup` ni isalẹ.
    // Ki a kan apoti o soke ni ẹẹkan, lati gba nkankan ijuboluwole-won.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Bọsipọ awọn abele `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}