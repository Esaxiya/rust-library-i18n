//! Imuse ti panics ti o ni atilẹyin nipasẹ libgcc/libunwind (ni ọna diẹ).
//!
//! Fun ipilẹṣẹ lori imukuro imukuro ati tito nkan silẹ jọwọ wo "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ati awọn iwe aṣẹ ti o sopọ mọ lati rẹ.
//! Iwọnyi tun dara kika:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## A finifini ni ṣoki
//!
//! Imudani imukuro ṣẹlẹ ni awọn ipele meji: apakan wiwa ati apakan afọmọ.
//!
//! Ni mejeji awọn ifarahan awọn unwinder rin akopọ awọn fireemu lati oke si isalẹ lilo alaye lati akopọ fireemu unwind ruju ti isiyi ilana ká modulu ("module" nibi ntokasi si ohun OS module, ie, ohun executable tabi a ìmúdàgba ìkàwé).
//!
//!
//! Fun fireemu akopọ kọọkan, o pe "personality routine" ti o ni ibatan, ti adirẹsi rẹ tun wa ni fipamọ ni apakan alaye aifọwọyi.
//!
//! Ninu ipele wiwa, iṣẹ ti iṣe deede eniyan ni lati ṣayẹwo ohun ti o da sile ti o da, ati lati pinnu boya o yẹ ki o mu ni aaye akopọ naa.Ni kete ti awọn imudani fireemu ti a ti mọ, afọmọ alakoso bẹrẹ.
//!
//! Ni awọn afọmọ alakoso, awọn unwinder invokes kọọkan eniyan baraku lẹẹkansi.
//! Akoko yi o pinnu eyi ti (ti o ba eyikeyi) afọmọ koodu aini to wa ni ṣiṣe fun awọn ti isiyi akopọ fireemu.Ti o ba bẹ bẹ, a ti gbe iṣakoso si branch pataki ninu ara iṣẹ, "landing pad", eyiti o pe awọn apanirun, iranti ọfẹ, ati bẹbẹ lọ.
//! Ni ipari ti paadi ibalẹ, iṣakoso ti wa ni gbigbe pada si aifọwọyi ati ṣiṣi pada.
//!
//! Lọgan ti akopọ ti unwound si isalẹ lati awọn ohun imudani fireemu ipele, unwinding iduro ati awọn ti o kẹhin eniyan baraku gbigbe sakoso si awọn apeja Àkọsílẹ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Idanimọ kilasi iyasọtọ ti Rust.
// Eleyi ti lo nipa eniyan awọn ipa ọna lati mọ boya awọn sile ti a da nipa ara wọn isise.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 ipata-ataja, ede
    0x4d4f5a_00_52555354
}

// A gbe awọn ids Forukọsilẹ kuro lati LLVM's TargetLowering::getExceptionPointerRegister() ati TargetLowering::getExceptionSelectorRegister() fun faaji kọọkan, lẹhinna ya aworan si awọn nọmba iforukọsilẹ DWARF nipasẹ awọn tabili alaye iforukọsilẹ (deede<arch>RegisterInfo.td, wa fun "DwarfRegNum").
//
// Wo tun http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Awọn wọnyi koodu ti wa ni da lori GCC ká C ati C++ eniyan ipa ọna.Fun itọkasi, wo:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Ilana eniyan EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS nlo ilana aiyipada niwọn igba ti o nlo SjLj ṣiṣi silẹ.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces on apa yoo pe awọn eniyan baraku pẹlu ipinle==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Ni awọn iṣẹlẹ wọnyẹn a fẹ lati tẹsiwaju ṣiṣii akopọ naa, bibẹkọ ti gbogbo awọn ẹhin wa yoo pari ni __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Aifọwọyi DWARF dawọle pe_Unwind_Context mu awọn ohun bii iṣẹ ati awọn itọka LSDA dani, sibẹsibẹ ARM EHABI fi wọn si nkan imukuro.
            // Lati tọju awọn ibuwọlu ti awọn iṣẹ bii _Unwind_GetLanguageSpecificData(), eyiti o gba ijuboluwole ti o tọ nikan, awọn ipa ọna eniyan GCC ṣe itọka ijuboluwole si iyasọtọ_awọn ọrọ ninu ọrọ, ni lilo ipo ti o wa ni ipamọ fun apa "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... A diẹ principled ona yoo si wa lati pese ni kikun definition ti apa ká _Unwind_Context ninu wa libunwind bindings ki o si bu awọn ti a beere data lati ibẹ taara, bypassing arara ibamu awọn iṣẹ.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI nilo awọn eniyan baraku lati mu awọn SP iye ninu awọn idankan kaṣe ti awọn sile ohun na.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Lori ARM EHABI ilana iṣe ti eniyan jẹ iduro fun ṣiṣii fireemu akopọ kan ṣaaju ki o to pada (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // asọye ni libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Aiyipada eniyan baraku, eyi ti o ti lo taara lori julọ fojusi ati ekoro lori Windows x86_64 nipasẹ SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // On x86_64 MinGW fojusi, awọn unwinding siseto ni SEH sibẹsibẹ awọn unwind imudani data (aka LSDA) nlo GCC-ibaramu aiyipada.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Awọn eniyan baraku fun julọ ti wa fojusi.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Awọn pada adirẹsi ojuami 1 baiti ti o ti kọja awọn ipe ẹkọ, eyi ti o le wa ni awọn nigbamii ti IP ibiti o ni LSDA ibiti o tabili.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Fireemu unwind info registration
//
// Kọọkan module aworan ni a fireemu unwind info apakan (maa ".eh_frame").Nigba ti a module ni loaded/unloaded sinu awọn ilana, awọn unwinder gbọdọ wa ni fun nipa awọn ipo ti yi apakan ninu iranti.Awọn ọna ti iyọrisi ti o yatọ nipasẹ awọn Syeed.
// Lori diẹ ninu (fun apẹẹrẹ, Linux), alainidena le ṣe awari awọn apakan alaye aifọkanbalẹ funrararẹ (nipa titọka kika awọn modulu ti a kojọpọ lọwọlọwọ nipasẹ dl_iterate_phdr() API and finding their ".eh_frame" sections); Awọn miiran, bii Windows, nilo awọn modulu lati forukọsilẹ fun awọn apakan alaye aifọwọyi wọn nipasẹ API ailopin.
//
//
// Eleyi module asọye meji aami eyi ti o ti wa ni rannileti o si pè lati rsbegin.rs lati forukọsilẹ wa alaye pẹlu awọn GCC asiko isise.
// Imuse ti ṣiṣii akopọ jẹ (fun bayi) firanṣẹ si libgcc_eh, sibẹsibẹ Rust crates lo awọn aaye titẹsi pato Rust wọnyi lati yago fun awọn ikọlu ti o le pẹlu akoko asiko GCC eyikeyi.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}