//! Ṣi kuro fun *emscripten* afojusun.
//!
//! Ko da Rust ká ibùgbé unwinding imuse fun Unix iru awọn ipe sinu libunwind APIs taara, on Emscripten a dipo pe sinu C++ unwinding APIs.
//! Eleyi jẹ o kan ohun expedience niwon Emscripten ká asiko isise nigbagbogbo alailewu awon APIs ati ki o ko se libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Eyi baamu si ipilẹ ti std::type_info ni C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Baiti `\x01` ti o niyi nibi jẹ ami idan kan si LLVM si *ko* lo eyikeyi mangling miiran bi prefixing pẹlu ohun kikọ `_`.
    //
    //
    // Ami yi jẹ vtable ti C00 ti `std::type_info` lo.
    // Ohun ti Iru `std::type_info`, Iru descriptors, ni a ijuboluwole si yi tabili.
    // Iru descriptors ti wa ni rannileti nipa awọn C++ EH ẹya telẹ loke ati pe a òrùka ni isalẹ.
    //
    // Akiyesi pe iwọn gidi tobi ju lilo 3 lọ, ṣugbọn a nilo vtable wa nikan lati tọka si nkan kẹta.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info fun kilasi rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Deede a yoo lo .as_ptr().add(2) sugbon eyi ko ba ṣiṣẹ ni a const o tọ.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Eyi ni imomose ko lo ilana mangling orukọ deede nitori a ko fẹ C++ lati ni anfani lati ṣe tabi mu Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Eyi jẹ pataki nitori pe koodu C++ le mu ipaniyan wa pẹlu std::exception_ptr ki o tun sọ di pupọ ni igba pupọ, o ṣee ṣe paapaa ninu okun miiran.
    //
    //
    caught: AtomicBool,

    // Eleyi nilo lati wa ni ohun aṣayan nitori awọn ohun ká s'aiye wọnyi C++ oro ijora: nigbati catch_unwind rare ni Box jade ti awọn sile o gbodo tun fi awọn sile ohun ni kan wulo ipinle nitori awọn oniwe-destructor ti wa ni ṣi lilọ si ti wa ni a npe ni nipa __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try kosi yoo fun wa kan ijuboluwole si yi be.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Niwọn igba ti a ko gba cleanup() laaye si panic, a kan da iṣẹtọ dipo.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}