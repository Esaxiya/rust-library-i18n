//! Imuse ti panics nipasẹ akopọ unwinding
//!
//! crate yii jẹ imuse ti panics ni Rust nipa lilo ilana fifin "most native" ti pẹpẹ ti a n ṣajọ fun.
//! Eleyi pataki olubwon tito lẹšẹšẹ si meta buckets Lọwọlọwọ:
//!
//! 1. MSVC fojusi lo SEH ni `seh.rs` faili.
//! 2. Emscripten nlo C++ imukuro ni `emcc.rs` faili.
//! 3. Gbogbo awọn miiran fojusi lo libunwind/libgcc ni `gcc.rs` faili.
//!
//! Awọn iwe diẹ sii nipa imuse kọọkan ni a le rii ninu module oniwun.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ko lo pẹlu Miri, nitorinaa awọn ikilọ ipalọlọ.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Awọn nkan ibẹrẹ akoko Rust dale lori awọn aami wọnyi, nitorinaa ṣe wọn ni gbangba.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Fojusi ti ko ni atilẹyin unwinding.
        // - arch=wasm32
        // - OS=kò ("bare metal" fojusi)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Lo awọn Miri asiko isise.
        // A si tun nilo lati tun fifuye awọn deede asiko isise loke, bi rustc retí awọn Lang ohun kan lati nibẹ lati wa ni telẹ.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Lo asiko asiko gidi.
        use real_imp as imp;
    }
}

extern "C" {
    /// Olutọju ni libstd pe nigbati ohun elo panic silẹ silẹ ni ita ti `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Olutọju ni libstd pe nigbati a mu imukuro ajeji.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Titẹsi ojuami fun igbega ohun sile, o kan asoju si awọn Syeed-kan pato imuse.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}