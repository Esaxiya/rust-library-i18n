use core::ptr::{self};
use core::slice::{self};

// Ṣiṣeto oluranlọwọ fun aṣetunṣe ibi ti o ju ẹbẹ ibi-afẹde ti aṣetunṣe, ie ori.
// Bibẹrẹ orisun (iru) ti lọ silẹ nipasẹ IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}