use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specialization trait ti a lo fun Vec::from_iter
///
/// ## Awonya aṣoju:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ọran ti o wọpọ n kọja vector sinu iṣẹ eyiti o tun gba lẹsẹkẹsẹ lẹsẹkẹsẹ sinu vector kan.
        // A le ṣe iyika kukuru eyi ti IntoIter ko ba ti ni ilọsiwaju rara.
        // Nigbati o ti ni ilọsiwaju A tun le tun lo iranti ki o gbe data si iwaju.
        // Ṣugbọn a ṣe bẹ nikan nigbati Abajade Vec kii yoo ni agbara ti ko lo diẹ sii ju ṣiṣẹda rẹ lọ nipasẹ imuse imulẹ FromIterator yoo ṣe.
        //
        // Idiwọn naa ko ṣe pataki bi ihuwasi ipin ipin Vec jẹ amọdaju ti a ko sọ tẹlẹ.
        // Ṣugbọn o jẹ yiyan Konsafetifu.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // gbọdọ ṣe aṣoju si spec_extend() nitori extend() funrararẹ ṣe aṣoju si spec_from fun Vecs ofo
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Eyi lo `iterator.as_slice().to_vec()` nitori pe spec_extend gbọdọ ṣe awọn igbesẹ diẹ sii lati ronu nipa agbara ipari + gigun ati nitorinaa ṣe iṣẹ diẹ sii.
// `to_vec()` taara pin iye ti o tọ ati fọwọsi ni deede.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): pẹlu cfg(test) ọna abuda `[T]::to_vec`, eyiti o nilo fun itumọ ọna yii, ko si.
    // Dipo lilo iṣẹ `slice::to_vec` eyiti o wa pẹlu cfg(test) NB nikan wo modulu slice::hack ni slice.rs fun alaye diẹ sii
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}