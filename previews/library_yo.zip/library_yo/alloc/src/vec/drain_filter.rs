use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Olutumọ eyi ti o nlo pipade lati pinnu boya o yẹ ki o yọ nkan kan kuro.
///
/// Eto yii ni a ṣẹda nipasẹ [`Vec::drain_filter`].
/// Wo iwe rẹ fun diẹ sii.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Atọka ti nkan ti yoo ṣe ayewo nipasẹ ipe ti nbọ si `next`.
    pub(super) idx: usize,
    /// Nọmba awọn ohun kan ti o ti gbẹ (removed) bayi.
    pub(super) del: usize,
    /// Gigun atilẹba ti `vec` ṣaaju ṣiṣan omi.
    pub(super) old_len: usize,
    /// Asọtẹlẹ idanwo àlẹmọ.
    pub(super) pred: F,
    /// Flag kan ti o tọka panic kan ti waye ninu asọtẹlẹ idanwo idanimọ.
    /// Eyi ni a lo bi itọkasi ninu imulẹ silẹ lati ṣe idiwọ agbara ti iyoku ti `DrainFilter`.
    /// Eyikeyi awọn ohun ti ko ni ilana yoo ni iyipada sẹhin ni `vec`, ṣugbọn ko si awọn ohun miiran ti yoo silẹ tabi idanwo nipasẹ asọtẹlẹ asẹ.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Pada itọkasi si ipin ipilẹ.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Ṣe imudojuiwọn itọka *lẹhin* ti pe pe asọtẹlẹ naa.
                // Ti itọka ba ti ni imudojuiwọn tẹlẹ ati asọtẹlẹ asọtẹlẹ panics, eroja ti o wa ni itọka yii yoo jo.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Eyi jẹ ipo ibajẹ lẹwa, ati pe ko si ohun ti o han ni ohun ti o tọ lati ṣe.
                        // A ko fẹ lati tẹsiwaju ni igbiyanju lati ṣiṣẹ `pred`, nitorinaa a kan sẹhin gbogbo awọn eroja ti ko ni ilana ati sọ fun vec pe wọn tun wa.
                        //
                        // A nilo afẹhinti lati ṣe idiwọ ida-meji ti nkan ṣiṣan ti o kẹhin ni aṣeyọri ṣaaju panic kan ninu asọtẹlẹ.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Igbidanwo lati jẹ eyikeyi awọn eroja ti o ku ti asọtẹlẹ asọtẹlẹ ko tii bẹru.
        // A yoo pada sẹhin eyikeyi awọn eroja ti o ku boya a ti bẹru tẹlẹ tabi ti agbara naa nibi panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}