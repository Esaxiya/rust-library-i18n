//! Iru ọna kika dagba dagba pọ pẹlu awọn akoonu ti a pin sọtọ, ti a kọ `Vec<T>`.
//!
//! Vectors ni titọka `O(1)`, amortized `O(1)` titari (si opin) ati `O(1)` pop (lati opin).
//!
//!
//! Vectors rii daju pe wọn ko pin diẹ sii ju awọn baiti `isize::MAX`.
//!
//! # Examples
//!
//! O le ṣẹda [`Vec`] ni kedere pẹlu [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... tabi nipa lilo macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // odo mẹwa
//! ```
//!
//! O le awọn iye [`push`] pẹlẹpẹlẹ opin vector kan (eyiti yoo dagba vector bi o ṣe nilo):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Awọn iye yiyo ṣiṣẹ ni ọna kanna:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors tun ṣe atilẹyin itọka (nipasẹ [`Index`] ati [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Iru iru ọna dagba ti o le dagba, ti a kọ bi `Vec<T>` ati pe o sọ 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// A pese Makiro [`vec!`] lati jẹ ki ipilẹṣẹ rọrun diẹ sii:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// O tun le ṣe ipilẹṣẹ eroja kọọkan ti `Vec<T>` pẹlu iye ti a fun.
/// Eyi le jẹ daradara siwaju sii ju ṣiṣe ipin ati ipilẹṣẹ ni awọn igbesẹ lọtọ, ni pataki nigbati o ba bẹrẹ vector ti awọn odo:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Atẹle yii jẹ deede, ṣugbọn o lọra diẹ sii:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Fun alaye diẹ sii, wo [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Lo `Vec<T>` bi akopọ daradara:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Awọn titẹ 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Iru `Vec` ngbanilaaye lati wọle si awọn iye nipasẹ itọka, nitori pe o ṣe awọn [`Index`] trait.Apẹẹrẹ yoo jẹ alaye diẹ sii:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // yoo han '2'
/// ```
///
/// Sibẹsibẹ ṣọra: ti o ba gbiyanju lati wọle si itọka eyiti ko si ninu `Vec`, sọfitiwia rẹ yoo jẹ panic!O ko le ṣe eyi:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Lo [`get`] ati [`get_mut`] ti o ba fẹ ṣayẹwo boya itọka wa ni `Vec`.
///
/// # Slicing
///
/// A `Vec` le jẹ iyipada.Ni apa keji, awọn ege jẹ awọn ohun-ka-nikan.
/// Lati gba [slice][prim@slice] kan, lo [`&`].Apẹẹrẹ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ati pe gbogbo rẹ ni!
/// // o tun le ṣe bi eleyi:
/// let u: &[usize] = &v;
/// // tabi bi eleyi:
/// let u: &[_] = &v;
/// ```
///
/// Ni Rust, o wọpọ julọ lati kọja awọn ege bi awọn ariyanjiyan ju vectors nigbati o kan fẹ lati pese iraye si kika.Kanna n lọ fun [`String`] ati [`&str`].
///
/// # Agbara ati reallocation
///
/// Agbara vector ni iye aaye ti a pin fun eyikeyi awọn eroja future ti yoo fi kun si vector.Eyi kii ṣe lati dapo pẹlu *ipari* ti vector kan, eyiti o ṣe afihan nọmba awọn eroja gangan laarin vector.
/// Ti gigun vector ba kọja agbara rẹ, agbara rẹ yoo pọ si laifọwọyi, ṣugbọn awọn eroja rẹ yoo ni lati tun sọtọ.
///
/// Fun apẹẹrẹ, vector pẹlu agbara 10 ati gigun 0 yoo jẹ vector ti o ṣofo pẹlu aye fun awọn eroja 10 diẹ sii.Titari 10 tabi awọn eroja diẹ si vector kii yoo yi agbara rẹ pada tabi fa ki ipin gidi waye.
/// Sibẹsibẹ, ti gigun vector ba pọ si 11, yoo ni lati tun gbe, eyiti o le fa fifalẹ.Fun idi eyi, o ni iṣeduro lati lo [`Vec::with_capacity`] nigbakugba ti o ṣee ṣe lati ṣọkasi bi nla vector ti nireti lati gba.
///
/// # Guarantees
///
/// Nitori iseda ipilẹ iyalẹnu iyalẹnu, `Vec` ṣe ọpọlọpọ awọn iṣeduro nipa apẹrẹ rẹ.Eyi ṣe idaniloju pe o wa ni oke-kekere bi o ti ṣee ninu ọran gbogbogbo, ati pe o le ni ifọwọyi ni deede ni awọn ọna aye atijọ nipasẹ koodu aiwuwu.Ṣe akiyesi pe awọn iṣeduro wọnyi tọka si `Vec<T>` ti ko yẹ.
/// Ti a ba ṣafikun awọn ipilẹ iru afikun (fun apẹẹrẹ, lati ṣe atilẹyin awọn oluṣeto aṣa), yiyoju awọn aiyipada wọn le yi ihuwasi pada.
///
/// Ni pataki julọ, `Vec` jẹ ati nigbagbogbo yoo jẹ (ijuboluwole, agbara, ipari) ni ẹẹmẹta.Ko si siwaju sii, ko kere.A ko le ṣalaye aṣẹ ti awọn aaye wọnyi patapata, ati pe o yẹ ki o lo awọn ọna ti o yẹ lati yipada awọn wọnyi.
/// Atọka naa kii yoo jẹ asan, nitorina oriṣi yii jẹ iṣapeye asan-iṣapeye.
///
/// Sibẹsibẹ, ijuboluwole le ma ṣe tọka si iranti ti a pin.
/// Ni pato, ti o ba òrùka a `Vec` pẹlu agbara 0 nipasẹ [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], tabi nipa pipe [`shrink_to_fit`] lori ohun ṣofo Vec, o yoo ko allocate iranti.Bakanna, ti o ba ti o fipamọ odo-won orisi inu a `Vec`, o yoo ko allocate aaye fun wọn.
/// *Ṣe akiyesi pe ninu ọran yii `Vec` ko le ṣe ijabọ [`capacity`] ti 0*.
/// `Vec` yoo soto ti o ba jẹ pe nikan ti [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ni gbogbogbo, `Awọn alaye ipin Vec` jẹ arekereke pupọ-ti o ba ni ipinnu lati fi ipin iranti si ni lilo `Vec` ki o lo fun nkan miiran (boya lati kọja si koodu ti ko ni aabo, tabi lati kọ ikojọpọ ti o ni atilẹyin iranti tirẹ), rii daju lati ṣe ipinpo iranti yii nipa lilo `from_raw_parts` lati bọsipọ `Vec` ati lẹhinna sọkalẹ.
///
/// Ti o ba ti a `Vec`*ti* soto iranti, ki o si iranti ti o ojuami si jẹ lori awọn okiti (bi asọye nipa awọn allocator Rust wa ni tunto lati lilo nipa aiyipada), ati awọn oniwe-ijuboluwole ojuami si [`len`] initialized, contiguous eroja ni ibere (ohun ti o ṣe fẹ rii boya o fi agbara mu u si ege kan), atẹle nipa ``agbara`] ``,`[`len`] aibikita ainiti oye, awọn eroja ti o leralera.
///
///
/// vector kan ti o ni awọn eroja `'a'` ati `'b'` pẹlu agbara 4 le jẹ iworan bi isalẹ.Apakan oke ni ọna `Vec`, o ni itọka si ori ipin ipin ninu okiti, gigun ati agbara.
/// Awọn isalẹ apakan ni ipin lori akojo, a contiguous iranti Àkọsílẹ.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **yiyọ** duro fun iranti ti ko ni ipilẹṣẹ, wo [`MaybeUninit`].
/// - Note: ABI ko ni iduroṣinṣin ati `Vec` ko ṣe awọn iṣeduro nipa ipilẹ iranti rẹ (pẹlu aṣẹ awọn aaye).
///
/// `Vec` kii yoo ṣe "small optimization" kan nibiti awọn eroja ti wa ni fipamọ gangan lori akopọ fun awọn idi meji:
///
/// * Yoo jẹ ki o nira sii fun koodu ailewu lati ṣe afọwọyi `Vec` kan.Awọn akoonu ti `Vec` kii yoo ni adirẹsi iduroṣinṣin ti o ba gbe nikan, ati pe yoo nira sii lati pinnu boya `Vec` kan ti ṣe iranti iranti gangan.
///
/// * Yoo jẹ ijiya ọran gbogbogbo, ti o fa afikun branch lori gbogbo iraye si.
///
/// `Vec` kii yoo dinku ararẹ laifọwọyi, paapaa ti o ba ṣofo patapata.Eyi ṣe idaniloju pe ko si awọn ipin ti ko ni dandan tabi awọn ipin adehun ti o waye.Fo kan `Vec` ati lẹhinna fọwọsi rẹ pada si [`len`] kanna ko yẹ ki o fa awọn ipe kankan si olupilẹṣẹ.Ti o ba ti o ba fẹ lati laaye soke ajeku iranti, lo [`shrink_to_fit`] tabi [`shrink_to`].
///
/// [`push`] ati [`insert`] kii yoo tun (tun) fi ipinlẹ ti agbara iroyin ba to.[`push`] ati [`insert`]*yoo*(tun) soto ti o ba ti [`len`]]`==`[`agbara`].Iyẹn ni pe, agbara ti a royin jẹ deede pipe, ati pe o le gbarale.O le paapaa lo lati ṣe iranti iranti pẹlu ọwọ pẹlu `Vec` ti o ba fẹ.
/// Awọn ọna ifibọ olopobobo *le* ṣe atunto, paapaa nigbati ko ba ṣe pataki.
///
/// `Vec` ko ṣe onigbọwọ eyikeyi ilana idagbasoke pato nigbati o ba npinnu nigba ti o kun, tabi nigba ti a pe [`reserve`].Igbimọ lọwọlọwọ jẹ ipilẹ ati pe o le ṣe afihan wuni lati lo ifosiwewe idagba ti kii ṣe deede.Eyikeyi igbimọ ti o lo yoo dajudaju ẹri *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, ati [`Vec::with_capacity(n)`][`Vec::with_capacity`], gbogbo wọn yoo ṣe `Vec` kan pẹlu agbara ti o beere gangan.
/// Ti [`len`]]==`[`agbara`]], (bii o ṣe ri fun macro [`vec!`]), lẹhinna `Vec<T>` le yipada si ati lati [`Box<[T]>`][owned slice] kan lai ṣe ipin tabi gbe awọn eroja lọ.
///
/// `Vec` yoo ko pataki tun eyikeyi data ti o ti wa ni kuro lati o, sugbon o tun yoo ko pataki itoju o.Awọn oniwe-uninitialized iranti jẹ ibere aaye ti o le lo sibẹsibẹ o fe.Ni gbogbogbo yoo ṣe ohunkohun ti o munadoko julọ tabi bibẹkọ ti o rọrun lati ṣe.Maṣe gbekele data ti o yọ lati parẹ fun awọn idi aabo.
/// Paapa ti o ba sọ `Vec` silẹ, ifipamọ rẹ le jẹ lilo lẹẹkansi nipasẹ `Vec` miiran.
/// Paapa ti o ba sọ iranti `Vec` lakọkọ, iyẹn le ma ṣẹlẹ niti gidi nitori oluṣapẹrẹ ko ṣe akiyesi eyi ipa-ẹgbẹ kan ti o gbọdọ wa ni ipamọ.
/// Ọran kan wa ti a ko ni fọ, sibẹsibẹ: lilo koodu `unsafe` lati kọ si agbara apọju, ati lẹhinna jijẹ gigun lati baamu, jẹ deede nigbagbogbo.
///
/// Lọwọlọwọ, `Vec` ko ṣe oniduro ibere ninu eyi ti eroja ti wa ni silẹ.
/// Ibere naa ti yipada ni igba atijọ ati pe o le yipada lẹẹkansii.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Awọn ọna atorunwa
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Ṣe `Vec<T>` tuntun, ṣofo.
    ///
    /// The vector yoo ko allocate titi eroja ti wa ni lai-pẹlẹpẹlẹ o.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ṣe `Vec<T>` tuntun, ofo pẹlu agbara ti a ṣalaye.
    ///
    /// vector yoo ni anfani lati mu deede awọn eroja `capacity` laisi atunto.
    /// Ti `capacity` jẹ 0, vector kii yoo pin.
    ///
    /// O ṣe pataki lati ṣe akiyesi pe botilẹjẹpe vector ti o pada ni agbara *ti a tọka, vector yoo ni ipari* odo * kan.
    ///
    /// Fun ẹya alaye ti awọn iyato laarin awọn ipari ki o si agbara, wo *[Agbara ati reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ko ni awọn ohun kan, botilẹjẹpe o ni agbara fun diẹ sii
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Gbogbo wọn ni a ṣe laisi tito ipin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ṣugbọn eyi le ṣe vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Ṣẹda `Vec<T>` taara lati awọn paati aise ti vector miiran.
    ///
    /// # Safety
    ///
    /// Eyi jẹ ailewu ti o ga julọ, nitori nọmba awọn alailera ti a ko ṣayẹwo:
    ///
    /// * `ptr` nilo lati ti ni ipin tẹlẹ nipasẹ [`Okun`]/`Vec<T>`(o kere ju, o ṣeeṣe ki o jẹ aṣiṣe ti ko ba jẹ).
    /// * `T` nilo lati ni iwọn kanna ati titete bi ohun ti a fi ipin `ptr` pẹlu.
    ///   (`T` ti o ni titọ titọ to kere ko to, titootọ nilo lati jẹ deede lati ni itẹlọrun ibeere [`dealloc`] pe iranti gbọdọ pin ati pin pẹlu ipin kanna.)
    ///
    /// * `length` nilo lati kere tabi dọgba si `capacity`.
    /// * `capacity` nilo lati jẹ agbara ti a pin ijuboluwole pẹlu.
    ///
    /// Riru awọn wọnyi le fa awọn iṣoro bii ibajẹ awọn ẹya data inu ti ipin.Fun apẹẹrẹ o **kii ṣe** ailewu lati kọ `Vec<u8>` lati ọdọ ijuboluwole si ọna ẹrọ C `char` pẹlu ipari `size_t`.
    /// Ko tun ni ailewu lati kọ ọkan lati `Vec<u16>` ati ipari rẹ, nitori olupilẹṣẹ bikita nipa titete, ati awọn oriṣi meji wọnyi ni awọn tito lẹtọ oriṣiriṣi.
    /// Awọn saarin ti a soto pẹlu titete 2 (fun `u16`), ṣugbọn lẹhin titan o sinu kan `Vec<u8>` o yoo wa ni deallocated pẹlu titete 1.
    ///
    /// A ni gbigbe ohun-ini ti `ptr` ni gbigbe si `Vec<T>` eyiti o le lẹhinna ṣe ipinpo, tunto tabi yi awọn akoonu ti iranti ti o tọka si nipasẹ itọka naa ni ifẹ rẹ.
    /// Rii daju pe ko si ohun miiran ti o lo ijuboluwole lẹhin pipe iṣẹ yii.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Ṣe imudojuiwọn eyi nigbati vec_into_raw_parts ti wa ni diduro.
    ///     // Ṣe idiwọ ṣiṣe apanirun `v` nitorinaa a wa ni iṣakoso pipe ti ipin.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Fa orisirisi awọn ege pataki ti alaye jade nipa `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // ・Kọ iranti pẹlu 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Fi ohun gbogbo pada si Vec kan
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Ṣe `Vec<T, A>` tuntun, ṣofo.
    ///
    /// The vector yoo ko allocate titi eroja ti wa ni lai-pẹlẹpẹlẹ o.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ṣe `Vec<T, A>` tuntun, ofo pẹlu agbara ti a ṣalaye pẹlu olupilẹṣẹ ti a pese.
    ///
    /// vector yoo ni anfani lati mu deede awọn eroja `capacity` laisi atunto.
    /// Ti `capacity` jẹ 0, vector kii yoo pin.
    ///
    /// O ṣe pataki lati ṣe akiyesi pe botilẹjẹpe vector ti o pada ni agbara *ti a tọka, vector yoo ni ipari* odo * kan.
    ///
    /// Fun ẹya alaye ti awọn iyato laarin awọn ipari ki o si agbara, wo *[Agbara ati reallocation]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ko ni awọn ohun kan, botilẹjẹpe o ni agbara fun diẹ sii
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Gbogbo wọn ni a ṣe laisi tito ipin ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ṣugbọn eyi le ṣe vector reallocate
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Ṣẹda a `Vec<T, A>` taara lati aise irinše ti awọn miran vector.
    ///
    /// # Safety
    ///
    /// Eyi jẹ ailewu ti o ga julọ, nitori nọmba awọn alailera ti a ko ṣayẹwo:
    ///
    /// * `ptr` nilo lati ti ni ipin tẹlẹ nipasẹ [`Okun`]/`Vec<T>`(o kere ju, o ṣeeṣe ki o jẹ aṣiṣe ti ko ba jẹ).
    /// * `T` nilo lati ni iwọn kanna ati titete bi ohun ti a fi ipin `ptr` pẹlu.
    ///   (`T` ti o ni titọ titọ to kere ko to, titootọ nilo lati jẹ deede lati ni itẹlọrun ibeere [`dealloc`] pe iranti gbọdọ pin ati pin pẹlu ipin kanna.)
    ///
    /// * `length` nilo lati kere tabi dọgba si `capacity`.
    /// * `capacity` nilo lati jẹ agbara ti a pin ijuboluwole pẹlu.
    ///
    /// Riru awọn wọnyi le fa awọn iṣoro bii ibajẹ awọn ẹya data inu ti ipin.Fun apẹẹrẹ o **kii ṣe** ailewu lati kọ `Vec<u8>` lati ọdọ ijuboluwole si ọna ẹrọ C `char` pẹlu ipari `size_t`.
    /// Ko tun ni ailewu lati kọ ọkan lati `Vec<u16>` ati ipari rẹ, nitori olupilẹṣẹ bikita nipa titete, ati awọn oriṣi meji wọnyi ni awọn tito lẹtọ oriṣiriṣi.
    /// Awọn saarin ti a soto pẹlu titete 2 (fun `u16`), ṣugbọn lẹhin titan o sinu kan `Vec<u8>` o yoo wa ni deallocated pẹlu titete 1.
    ///
    /// A ni gbigbe ohun-ini ti `ptr` ni gbigbe si `Vec<T>` eyiti o le lẹhinna ṣe ipinpo, tunto tabi yi awọn akoonu ti iranti ti o tọka si nipasẹ itọka naa ni ifẹ rẹ.
    /// Rii daju pe ko si ohun miiran ti o lo ijuboluwole lẹhin pipe iṣẹ yii.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Ṣe imudojuiwọn eyi nigbati vec_into_raw_parts ti wa ni diduro.
    ///     // Ṣe idiwọ ṣiṣe apanirun `v` nitorinaa a wa ni iṣakoso pipe ti ipin.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Fa orisirisi awọn ege pataki ti alaye jade nipa `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // ・Kọ iranti pẹlu 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Fi ohun gbogbo pada si Vec kan
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decomposes `Vec<T>` kan sinu awọn paati aise rẹ.
    ///
    /// Pada ijuboluwole aise si data ipilẹ, gigun ti vector (ninu awọn eroja), ati agbara ti a ti sọtọ ti data (ninu awọn eroja).
    /// Awọn wọnyi ni awọn ariyanjiyan kanna ni aṣẹ kanna bi awọn ariyanjiyan si [`from_raw_parts`].
    ///
    /// Lẹhin pipe iṣẹ yii, olupe naa ni ẹri fun iranti ti iṣakoso tẹlẹ nipasẹ `Vec`.
    /// Ọna kan ti o le ṣe eyi ni lati yi iyipada ijuboluwole gigun, gigun, ati agbara pada si `Vec` pẹlu iṣẹ [`from_raw_parts`], gbigba gbigba apanirun lati ṣe afọmọ.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // A le ṣe awọn ayipada bayi si awọn paati, gẹgẹ bi gbigbe irekọja aise si iru iru ibaramu kan.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decomposes `Vec<T>` kan sinu awọn paati aise rẹ.
    ///
    /// Pada ijuboluwole ainiti si data ipilẹ, gigun ti vector (ninu awọn eroja), agbara ti a ti sọtọ ti data (ninu awọn eroja), ati olupilẹṣẹ.
    /// Awọn wọnyi ni awọn ariyanjiyan kanna ni aṣẹ kanna bi awọn ariyanjiyan si [`from_raw_parts_in`].
    ///
    /// Lẹhin pipe iṣẹ yii, olupe naa ni ẹri fun iranti ti iṣakoso tẹlẹ nipasẹ `Vec`.
    /// Nikan ni ona lati se eyi ni lati se iyipada awọn aise ijuboluwole, ipari, ati agbara pada sinu a `Vec` pẹlu awọn [`from_raw_parts_in`] iṣẹ, gbigba awọn destructor lati ṣe awọn afọmọ.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // A le ṣe awọn ayipada bayi si awọn paati, gẹgẹ bi gbigbe irekọja aise si iru iru ibaramu kan.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Pada awọn nọmba ti eroja awọn vector le mu lai reallocating.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Ifipamọ agbara fun o kere ju `additional` awọn eroja diẹ sii lati fi sii ninu `Vec<T>` ti a fun.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    /// Lẹhin pipe `reserve`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba ju awọn baiti `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Ṣe ifipamo agbara to kere fun `additional` awọn eroja diẹ sii lati fi sii ninu `Vec<T>` ti a fun.
    ///
    /// Lẹhin pipe `reserve_exact`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa, a ko le gbarale agbara lati jẹ pọọku ni deede.
    /// Fẹ `reserve` ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Gbiyanju lati ṣura agbara fun o kere ju `additional` awọn eroja diẹ sii lati fi sii ni `Vec<T>` ti a fun.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    /// Lẹhin pipe `try_reserve`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// # Errors
    ///
    /// Ti agbara ba ṣan, tabi olupilẹṣẹ ṣe ijabọ ikuna, lẹhinna aṣiṣe kan ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM ni agbedemeji iṣẹ eka wa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // idiju pupọ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Gbìyànjú lati ṣura kere agbara fun gangan `additional` eroja to wa ni fi sii ni awọn ti fi fun `Vec<T>`.
    /// Lẹhin pipe `try_reserve_exact`, agbara ni yio je tobi ju tabi dogba si `self.len() + additional` ti o ba pada `Ok(())`.
    ///
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa, a ko le gbarale agbara lati jẹ pọọku ni deede.
    /// Fẹ `reserve` ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Errors
    ///
    /// Ti agbara ba ṣan, tabi olupilẹṣẹ ṣe ijabọ ikuna, lẹhinna aṣiṣe kan ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM ni agbedemeji iṣẹ eka wa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // idiju pupọ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Dinku agbara ti vector bi o ti ṣeeṣe.
    ///
    /// Yoo ṣubu silẹ bi o ti ṣee ṣe to ipari ṣugbọn ipin naa le tun sọ fun vector pe aye wa fun awọn eroja diẹ diẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Agbara naa ko kere ju gigun lọ, ati pe ko si nkankan lati ṣe nigbati wọn ba dọgba, nitorinaa a le yago fun ọran panic ni `RawVec::shrink_to_fit` nipa pipe nikan pẹlu agbara nla kan.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Isunki agbara ti vector pẹlu okun kekere.
    ///
    /// Agbara naa yoo wa ni o kere bi o tobi bi gigun ati iye ti a pese.
    ///
    ///
    /// Ti agbara lọwọlọwọ ba kere si opin isalẹ, eyi kii ṣe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Iyipada vector sinu [`Box<[T]>`][owned slice].
    ///
    /// Akiyesi pe eyi yoo ju eyikeyi agbara apọju silẹ.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Ti yọ eyikeyi agbara ti o pọ julọ:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Shortens awọn vector, fifi awọn akọkọ `len` eroja ati sisọ awọn iyokù.
    ///
    /// Ti `len` ba tobi ju gigun lọwọlọwọ vector, eyi ko ni ipa.
    ///
    /// Ọna [`drain`] le farawe `truncate`, ṣugbọn fa ki a da awọn eroja ti o pọ pada dipo ti silẹ.
    ///
    ///
    /// Akiyesi pe yi ọna ni o ni ko ipa lori soto agbara ti awọn vector.
    ///
    /// # Examples
    ///
    /// Truncating eroja marun vector si awọn eroja meji:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ko si isokuso ti o waye nigbati `len` tobi ju ipari lọwọlọwọ vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Ṣiṣẹ nigbati `len == 0` jẹ deede lati pe ọna [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Eyi jẹ ailewu nitori:
        //
        // * ege ti o kọja si `drop_in_place` wulo;ọran `len > self.len` yago fun ṣiṣẹda bibẹ pẹlẹbẹ ti ko wulo, ati
        // * awọn `len` ti awọn vector ti wa ni shrunk ṣaaju ki o to pipe `drop_in_place`, iru awọn ti ko si iye ti yoo wa ni silẹ lemeji ni irú `drop_in_place` wà to panic ni kete ti (ti o ba ti o panics lemeji, awọn eto aborts).
        //
        //
        //
        unsafe {
            // Note: O jẹ ipinnu pe eyi jẹ `>` ati kii ṣe `>=`.
            //       Yiyipada rẹ si `>=` ni awọn ipa iṣẹ odi ni awọn igba miiran.
            //       Wo #78884 fun diẹ sii.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Mu awọn ege kan ti o ni gbogbo vector jade.
    ///
    /// Ni ibamu si `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Mu awọn ege gige kan ti gbogbo vector jade.
    ///
    /// Ni ibamu si `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Pada a aise ijuboluwole si awọn vector ká saarin.
    ///
    /// Olupe naa gbọdọ rii daju pe vector pọ ju ijuboluwole iṣẹ yii pada, tabi bẹẹkọ o yoo pari si tọka si idoti.
    /// Ṣiṣatunṣe vector le fa ki ifipamọ rẹ wa ni atunto, eyiti yoo tun jẹ ki awọn itọkasi eyikeyi tọ si.
    ///
    /// Olupe naa gbọdọ tun rii daju pe iranti ti XXXX ijuboluwole tọka si ko kọ si (ayafi inu `UnsafeCell` kan) ni lilo ijuboluwole tabi ijuboluwo eyikeyi ti o wa lati inu rẹ.
    /// Ti o ba nilo lati paarọ awọn akoonu ti bibẹ pẹlẹbẹ naa, lo [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // A ṣe ojiji ọna bibẹrẹ ti orukọ kanna lati yago fun lilọ nipasẹ `deref`, eyiti o ṣẹda itọkasi agbedemeji.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Pada ohun lewu mutable ijuboluwole si awọn vector ká saarin.
    ///
    /// Olupe naa gbọdọ rii daju pe vector pọ ju ijuboluwole iṣẹ yii pada, tabi bẹẹkọ o yoo pari si tọka si idoti.
    ///
    /// Ṣiṣatunṣe vector le fa ki ifipamọ rẹ wa ni atunto, eyiti yoo tun jẹ ki awọn itọkasi eyikeyi tọ si.
    ///
    /// # Examples
    ///
    /// ```
    /// // Pin vector nla to fun awọn eroja 4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Ni ipilẹṣẹ awọn eroja nipasẹ ijuboluwole kikọ, lẹhinna ṣeto gigun.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // A ṣe ojiji ọna bibẹrẹ ti orukọ kanna lati yago fun lilọ nipasẹ `deref_mut`, eyiti o ṣẹda itọkasi agbedemeji.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Pada itọkasi si ipin ipilẹ.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Fi agbara mu ipari vector si `new_len`.
    ///
    /// Eyi jẹ iṣẹ ipele-kekere ti o ṣetọju ko si ọkan ti awọn aiṣe deede iru.
    /// Ni deede yiyipada ipari ti vector ti ṣe ni lilo ọkan ninu awọn iṣẹ ailewu ni dipo, bii [`truncate`], [`resize`], [`extend`], tabi [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` gbọdọ jẹ kere ju tabi dogba si [`capacity()`].
    /// - Awọn eroja ni `old_len..new_len` gbọdọ jẹ ipilẹṣẹ.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ọna yii le wulo fun awọn ipo ninu eyiti vector n ṣiṣẹ bi ifipamọ fun koodu miiran, ni pataki lori FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Eyi jẹ egungun ti o kere ju fun apẹẹrẹ doc;
    /// # // maṣe lo eyi bi ibẹrẹ fun ile-ikawe gidi kan.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Fun awọn iwe aṣẹ ọna FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // Aabo: Nigbati `deflateGetDictionary` ba pada `Z_OK`, o ni pe:
    ///     // 1. `dict_length` eroja ti a initialized.
    ///     // 2.
    ///     // `dict_length` <=agbara (32_768) eyiti o jẹ ki `set_len` lailewu lati pe.
    ///     unsafe {
    ///         // Ṣe ipe FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ki o ṣe imudojuiwọn gigun si ohun ti a ṣe ipilẹṣẹ.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Lakoko ti apẹẹrẹ atẹle jẹ ohun ti o dun, ṣiṣan iranti wa lati igba ti inu vectors ko ni ominira ṣaaju ipe `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ṣofo nitorina ko si awọn eroja ti o nilo lati ni ipilẹṣẹ.
    /// // 2. `0 <= capacity` nigbagbogbo mu ohunkohun ti `capacity` jẹ.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Ni deede, nibi, ẹnikan yoo lo [`clear`] dipo lati sọ awọn akoonu silẹ ni deede ati nitorinaa kii ṣe jo iranti.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Yọ ano kuro lati vector ati da pada.
    ///
    /// A ti yọ eroja ti a yọ kuro nipasẹ eroja ti o kẹhin ti vector.
    ///
    /// Eyi ko tọju aṣẹ, ṣugbọn jẹ O(1).
    ///
    /// # Panics
    ///
    /// Panics ti `index` ko ba ni opin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // A ropo ara [atọka] pẹlu awọn ti o kẹhin ano.
            // Akiyesi pe ti ṣayẹwo awọn igboro loke ba ṣaṣeyọri nibẹ gbọdọ wa ni nkan ti o kẹhin (eyiti o le jẹ ara ẹni [itọka] funrararẹ).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Awọn ifibọ ano ni ipo `index` laarin vector, yiyi gbogbo awọn eroja lẹhin rẹ si apa ọtun.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // aaye fun eroja tuntun
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // aiṣe aṣiṣe Awọn iranran lati fi iye tuntun sii
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Naficula ohun gbogbo lori si Rii aaye.
                // (Ṣiṣe ẹda `index`th element si awọn aaye itẹlera meji.)
                ptr::copy(p, p.offset(1), len - index);
                // Kọ ọ sinu, atunkọ ẹda akọkọ ti eroja `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Yọ kuro o pada si ipo ni ipo `index` laarin vector, yiyi gbogbo awọn eroja lẹhin rẹ si apa osi.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `index` ko ba ni opin.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ibi ti a n gba.
                let ptr = self.as_mut_ptr().add(index);
                // daakọ jade, lailewu ni ẹda ti iye lori akopọ ati ninu vector ni akoko kanna.
                //
                ret = ptr::read(ptr);

                // Yipada ohun gbogbo si isalẹ lati kun aaye yẹn.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Ṣe idaduro awọn eroja ti a ṣalaye nipasẹ asọtẹlẹ tẹlẹ nikan.
    ///
    /// Ni awọn ọrọ miiran, yọ gbogbo awọn eroja `e` kuro bii `f(&e)` pada `false`.
    /// Ọna yii n ṣiṣẹ ni aye, ṣe abẹwo si eroja kọọkan ni ẹẹkan ni aṣẹ atilẹba, ati tọju aṣẹ ti awọn eroja idaduro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Nitori pe a ṣabẹwo si awọn eroja ni ẹẹkan ni aṣẹ atilẹba, a le lo ipo ita lati pinnu iru awọn eroja lati tọju.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Yago fun ju silẹ meji ti a ko ba ṣiṣẹ olusona ju, nitori a le ṣe awọn iho diẹ lakoko ilana naa.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-processing len-> |-atẹle lati ṣayẹwo
        //                  | <-paarẹ cnt-> |
        //      | <-original_len-> |Ti tọju: Awọn eroja ti asọtẹlẹ pada si otitọ lori.
        //
        // Iho: Gbe tabi ju ano Iho.
        // Sisoô: sisoô wulo eroja.
        //
        // Eleyi ju oluso yoo wa ni invoked nigbati predicate tabi `drop` ti ano isoretinu.
        // O iṣinipo a sisoô eroja to ideri ihò ati `set_len` si tọ ipari.
        // Ni igba nigba ti predicate ati `drop` ko panick, o yoo wa ni iṣapeye jade.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // Aabo: Titele awọn ohun ti a ko tii ṣayẹwo gbọdọ jẹ deede nitori a ko fi ọwọ kan wọn.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // Aabo: Lẹhin ti o kun awọn iho, gbogbo awọn nkan wa ni iranti ti o jọra.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // Aabo: Ero ti a ko ṣayẹwo gbọdọ jẹ deede.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ni ilosiwaju ni kutukutu lati yago fun isubu meji ti `drop_in_place` ba bẹru.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // Aabo: A ko fi ọwọ kan nkan yii lẹẹkan lẹhin ti o lọ silẹ.
                unsafe { ptr::drop_in_place(cur) };
                // A ti ni ilọsiwaju counter tẹlẹ.
                continue;
            }
            if g.deleted_cnt > 0 {
                // Aabo: `deleted_cnt`> 0, nitorinaa iho iho ko gbọdọ bori pẹlu eroja lọwọlọwọ.
                // A lo daakọ fun Gbe, ati ki o ko fi ọwọ kan yi ano lẹẹkansi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Gbogbo nkan ti ni ilọsiwaju.Eyi le ṣe iṣapeye si `set_len` nipasẹ LLVM.
        drop(g);
    }

    /// Yọ gbogbo rẹ kuro ṣugbọn akọkọ ti awọn eroja itẹlera ni vector ti o yanju si bọtini kanna.
    ///
    ///
    /// Ti a ba to vector lẹsẹsẹ, eyi yọ gbogbo awọn ẹda-iwe kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Yọ gbogbo rẹ kuro ṣugbọn akọkọ ti awọn eroja itẹlera ninu vector ni itẹlọrun ibatan ibatan ti a fifun.
    ///
    /// Iṣẹ `same_bucket` ti kọja awọn itọkasi si awọn eroja meji lati vector ati pe o gbọdọ pinnu ti awọn eroja ba fiwegba.
    /// Awọn eroja naa ti kọja ni ọna idakeji lati aṣẹ wọn ni ege, nitorina ti `same_bucket(a, b)` ba pada `true`, `a` ti yọ.
    ///
    ///
    /// Ti a ba to vector lẹsẹsẹ, eyi yọ gbogbo awọn ẹda-iwe kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Fi ohun ano si ẹhin gbigba kan.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba ju awọn baiti `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Eyi yoo jẹ panic tabi abort ti a ba fi ipin> Awọn baiti isize::MAX tabi ti afikun gigun yoo ṣan fun awọn iru iwọn odo.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Yọ nkan ti o kẹhin lati vector ki o pada si, tabi [`None`] ti o ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Gbe gbogbo awọn eroja ti `other` sinu `Self`, fifi `other` silẹ ofo.
    ///
    /// # Panics
    ///
    /// Panics ti nọmba awọn eroja ninu vector ba bori `usize` kan.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Fi awọn eroja kun si `Self` lati ifipamọ miiran.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Ṣẹda aṣetunṣe imugbẹ ti o yọ ibiti a ti sọ tẹlẹ ni vector ati mu awọn nkan ti a yọ kuro.
    ///
    /// Nigbati aṣiṣẹ ite **ba ti lọ silẹ**, gbogbo awọn eroja ti o wa ni ibiti a yọ kuro lati vector, paapaa ti aṣetunṣe ko ba ni kikun.
    /// Ti aṣiṣẹ ite **ko ba lọ silẹ**(pẹlu [`mem::forget`] fun apẹẹrẹ), ko sọ tẹlẹ iye awọn eroja ti yọ.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ ba tobi ju aaye ipari lọ tabi ti aaye ipari ba tobi ju ipari vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ibiti o wa ni kikun nu vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Aabo iranti
        //
        // Nigbati a ṣẹda akọkọ Drain, o dinku gigun ti orisun vector lati rii daju pe ko si aimọ tabi gbigbe-lati awọn eroja ti o wa ni wiwọle rara ti apanirun Drain ko ni ṣiṣe.
        //
        //
        // Drain yoo ptr::read jade ni iye lati yọ.
        // Nigbati o ba pari, iru ẹda ti o ku ti vec naa ni a daakọ pada lati bo iho naa, ati pe gigun vector ti wa ni pada si ipari tuntun.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // ṣeto ipari self.vec lati bẹrẹ, lati ni aabo ti o ba jẹ pe Drain ti jo
            self.set_len(start);
            // Lo yawo ni IterMut lati tọka ihuwasi yiya ti gbogbo oluṣe Drain (bii &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Fọ vector kuro, yọ gbogbo awọn iye kuro.
    ///
    /// Akiyesi pe yi ọna ni o ni ko ipa lori soto agbara ti awọn vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Pada nọmba awọn eroja inu vector, tun tọka si bi 'length' rẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Pada `true` ti vector ko ba ni awọn eroja ninu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Pinpin gbigba si meji ni itọka ti a fun.
    ///
    /// Pada vector tuntun ti a pin sọtọ ti o ni awọn eroja inu ibiti o wa ni `[at, len)`.
    /// Lẹhin ipe, atilẹba vector yoo wa ni osi ti o ni awọn eroja `[0, at)` pẹlu agbara iṣaaju rẹ ko yipada.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // tuntun vector le gba ifipamọ atilẹba ati yago fun ẹda naa
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Aabo `set_len` ati daakọ awọn ohun kan si `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ṣe atunṣe `Vec` ni ibi ki `len` jẹ dọgba si `new_len`.
    ///
    /// Ti `new_len` ba tobi ju `len` lọ, `Vec` naa ni afikun nipasẹ iyatọ, pẹlu iho kọọkan kọọkan ti o kun pẹlu abajade pipe pipe `f`.
    ///
    /// Awọn iye ipadabọ lati `f` yoo pari ni `Vec` ni aṣẹ ti wọn ti ṣẹda.
    ///
    /// Ti `new_len` ba kere ju `len`, `Vec` ti wa ni irọrun.
    ///
    /// Ọna yii nlo pipade lati ṣẹda awọn iye tuntun lori gbogbo titari.Ti o ba fẹ dipo [`Clone`] a fi iye, lilo [`Vec::resize`].
    /// Ti o ba fẹ lo [`Default`] trait lati ṣe awọn iye, o le kọja [`Default::default`] bi ariyanjiyan keji.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Gba ati jo `Vec` naa, n pada tọka iyipada si awọn akoonu, `&'a mut [T]`.
    /// Akiyesi pe iru `T` gbọdọ ni igbesi aye `'a` ti o yan laaye.
    /// Ti oriṣi ba ni awọn itọkasi aimi nikan, tabi ko si rara rara, lẹhinna o le yan eyi lati jẹ `'static`.
    ///
    /// Iṣẹ yii jọra si iṣẹ [`leak`][Box::leak] lori [`Box`] ayafi pe ko si ọna lati bọsipọ iranti ti jo.
    ///
    ///
    /// Iṣẹ yii jẹ pataki julọ fun data ti o ngbe fun iyoku ti igbesi aye eto naa.
    /// Sisọ itọkasi ti o pada yoo fa jo iranti kan.
    ///
    /// # Examples
    ///
    /// Lilo to rọrun:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Pada agbara iyoku ti vector pada bi ege `MaybeUninit<T>` kan.
    ///
    /// A le lo nkan ti a da pada lati kun vector pẹlu data (fun apẹẹrẹ
    /// nipa kika lati faili kan) ṣaaju ki o to samisi data bi ipilẹṣẹ nipa lilo ọna [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Pin vector nla to fun awọn eroja 10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Kun akọkọ 3 eroja.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Samisi awọn eroja 3 akọkọ ti vector bi ipilẹṣẹ.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // A ko ṣe agbekalẹ ọna yii ni awọn ofin ti `split_at_spare_mut`, lati yago fun ailagbara ti awọn itọka si ibi ipamọ.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Pada akoonu vector gege bi ege `T`, pẹlu agbara apoju ti o ku ti vector gege bi ege `MaybeUninit<T>`.
    ///
    /// A le ge nkan elo agbara apoju ti a pada lati kun vector pẹlu data (fun apẹẹrẹ nipasẹ kika lati faili kan) ṣaaju samisi data bi ipilẹṣẹ nipa lilo ọna [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Akiyesi pe eyi jẹ API ipele-kekere, eyiti o yẹ ki o lo pẹlu abojuto fun awọn idi ti o dara ju.
    /// Ti o ba nilo lati fi kun data si `Vec` o le lo [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] tabi [`resize_with`], da lori awọn aini rẹ gangan.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Ṣura aaye afikun si tobi to fun awọn eroja 10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Kun tókàn 4 eroja.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Samisi awọn eroja mẹrin ti vector bi ipilẹṣẹ.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ko bikita ati nitorinaa ko yipada
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Aabo: iyipada ti o pada .2 (&mut usize) jẹ kanna bii pipe `.set_len(_)`.
    ///
    /// A lo ọna yii lati ni iraye si alailẹgbẹ si gbogbo awọn ẹya vec ni ẹẹkan ni `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` jẹ ẹri lati wulo fun awọn eroja `len`
        // - `spare_ptr` n tọka nkan kan ti o kọja saarin naa, nitorinaa ko ṣe pẹlu `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ṣe atunṣe `Vec` ni ibi ki `len` jẹ dọgba si `new_len`.
    ///
    /// Ti o ba ti `new_len` pọ ju `len`, awọn `Vec` ti wa ni tesiwaju nipa iyato, pẹlu kọọkan afikun Iho kún pẹlu `value`.
    ///
    /// Ti `new_len` ba kere ju `len`, `Vec` ti wa ni irọrun.
    ///
    /// Yi ọna ti nilo `T` lati se [`Clone`], ni ibere lati wa ni anfani lati oniye awọn koja iye.
    /// Ti o ba nilo irọrun diẹ sii (tabi fẹ gbekele [`Default`] dipo [`Clone`]), lo [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Awọn ere ibeji ati ṣe ifilọlẹ gbogbo awọn eroja ninu ege kan si `Vec`.
    ///
    /// Iterates lori bibẹ `other`, awọn ẹda oniye kọọkan eroja, ati lẹhinna ṣe afikun si `Vec` yii.
    /// `other` vector ti wa ni kọja ni aṣẹ.
    ///
    /// Akiyesi pe iṣẹ yii jẹ kanna bi [`extend`] ayafi pe o jẹ amọja lati ṣiṣẹ pẹlu awọn ege dipo.
    ///
    /// Ti ati nigbawo ti Rust gba amọja iṣẹ yii yoo ṣeeṣe ki o dinku (ṣugbọn o wa sibẹ).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Didaakọ awọn eroja lati ibiti `src` de opin vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` awọn onigbọwọ pe ibiti a fun ni wulo fun titọka ara ẹni
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Koodu yii ṣakopọ `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Faagun awọn iye vector nipasẹ awọn iye `n`, ni lilo monomono ti a fun.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Lo SetLenOnDrop lati ṣiṣẹ ni ayika kokoro nibiti akopọ ko le mọ ile itaja nipasẹ `ptr` nipasẹ self.set_len() maṣe inagijẹ.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Kọ gbogbo awọn eroja ayafi ti o kẹhin
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Alekun gigun ni gbogbo igbesẹ ni ọran next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // A le kọ awọn ti o kẹhin ano taara laisi ti ẹda oniye needlessly
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // yiya ṣeto nipasẹ oluso dopin
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Yọ awọn eroja ti a tun ṣe leralera ni vector ni ibamu si imuse [`PartialEq`] trait.
    ///
    ///
    /// Ti a ba to vector lẹsẹsẹ, eyi yọ gbogbo awọn ẹda-iwe kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Awọn ọna ati awọn iṣẹ inu
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` nilo lati jẹ itọka atọka
    /// - `self.capacity() - self.len()` gbọdọ jẹ `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len ti pọ sii nikan lẹhin awọn eroja ipilẹṣẹ
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - awọn igbimọ olupe ti src jẹ itọka ti o wulo
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - A ti ṣetan Element pẹlu `MaybeUninit::write`, nitorinaa o dara lati ṣe yiya len
            // - len ti pọ si lẹhin eroja kọọkan lati ṣe idiwọ awọn jijo (wo ọrọ #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - awọn olutọsọna olupe ti `src` jẹ itọka ti o wulo
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - A ṣẹda awọn itọka mejeeji lati awọn itọkasi bibẹ pẹlẹbẹ alailẹgbẹ (`&mut [_]`) nitorinaa wọn wulo ati pe wọn ko bori.
            //
            // - Awọn eroja ni: Daakọ nitorinaa O dara lati daakọ wọn, laisi ṣe ohunkohun pẹlu awọn iye atilẹba
            // - `count` jẹ dọgba pẹlu yiya ti `source`, nitorinaa orisun jẹ wulo fun awọn kika `count`
            // - `.reserve(count)` onigbọwọ ti `spare.len() >= count` ki spare ni wulo fun `count` Levin
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - `copy_nonoverlapping` ni ipilẹṣẹ awọn eroja naa
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Awọn imuṣẹ trait ti o wọpọ fun Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): pẹlu cfg(test) ọna abuda `[T]::to_vec`, eyiti o nilo fun itumọ ọna yii, ko si.
    // Dipo lilo iṣẹ `slice::to_vec` eyiti o wa pẹlu cfg(test) NB nikan wo modulu slice::hack ni slice.rs fun alaye diẹ sii
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ju ohunkohun silẹ ti kii yoo tun kọ
        self.truncate(other.len());

        // self.len <= other.len nitori truncate loke, nitorinaa awọn ege ti o wa nibi wa ni aala nigbagbogbo.
        //
        let (init, tail) = other.split_at(self.len());

        // tun lo awọn iye ti o wa ninu allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Ṣẹda aṣetunṣe ti n gba, iyẹn ni, ọkan ti o gbe iye kọọkan jade kuro ni vector (lati ibẹrẹ si ipari).
    /// The vector ko le ṣee lo lẹhin pipe yi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ni iru Okun, kii ṣe &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // bunkun ọna lati eyi ti orisirisi SpecFrom/SpecExtend imuṣẹ Egypt nigba ti won ba ni ko si si siwaju optimizations to waye
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Eyi ni ọran fun aṣetun gbogbogbo.
        //
        // Iṣẹ yii yẹ ki o jẹ deede ti iwa ti:
        //
        //      fun ohun kan ninu aṣetunṣe {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ko le ṣan silẹ nitori a yoo ni lati fi aaye adirẹsi sii
                self.set_len(len + 1);
            }
        }
    }

    /// Ṣẹda olutẹtisi onilọpọ ti o rọpo ibiti a ti sọ tẹlẹ ninu vector pẹlu oluṣewe `replace_with` ti a fun ati mu awọn nkan ti a yọ kuro.
    ///
    /// `replace_with` ko nilo lati jẹ ipari kanna bi `range`.
    ///
    /// `range` ti yọ paapaa ti a ko ba pa aṣetunṣe run titi de opin.
    ///
    /// O jẹ aisọye bawo ni ọpọlọpọ awọn eroja ti yọ kuro lati vector ti iye `Splice` ba jo.
    ///
    /// `replace_with` onitumọ titẹ sii jẹun nikan nigbati iye `Splice` ba lọ silẹ.
    ///
    /// Eyi jẹ ti o dara julọ ti:
    ///
    /// * Iru (awọn eroja inu vector lẹhin `range`) ṣofo,
    /// * tabi `replace_with` ṣe agbejade din tabi awọn eroja to dogba ju gigun 'ibiti' lọ
    /// * tabi isalẹ owun ti awọn oniwe-`size_hint()` jẹ gangan.
    ///
    /// Bibẹẹkọ, a pin vector fun igba diẹ ati iru ti wa ni gbigbe lẹmeji.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ ba tobi ju aaye ipari lọ tabi ti aaye ipari ba tobi ju ipari vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Ṣẹda aṣetunṣe eyiti o nlo pipade lati pinnu boya o yẹ ki o yọ nkan kan kuro.
    ///
    /// Ti pipade ba pada jẹ otitọ, lẹhinna a yọ ohun-elo kuro ki o fun ni agbara.
    /// Ti ipari ba pada jẹ eke, eroja yoo wa ni vector ati pe kii yoo fun ni alamọja.
    ///
    /// Lilo ọna yii jẹ deede si koodu atẹle:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // koodu rẹ nibi
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ṣugbọn `drain_filter` rọrun lati lo.
    /// `drain_filter` tun jẹ daradara siwaju sii, nitori pe o le ṣe afẹyinti awọn eroja ti orun ni olopobobo.
    ///
    /// Akiyesi pe `drain_filter` tun jẹ ki o ṣe iyipada gbogbo eroja ninu pipade àlẹmọ, laibikita boya o yan lati tọju tabi yọ kuro.
    ///
    ///
    /// # Examples
    ///
    /// Yapa ohun orun sinu evens ati awọn aidọgba, reusing atilẹba ipin:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Ṣọra fun wa ni jijo (titobi n jo)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Faagun imuse ti o daakọ awọn eroja kuro ninu awọn itọkasi ṣaaju titari wọn sori Vec.
///
/// Imuse yii jẹ amọja fun awọn olutọpa ege, nibiti o nlo [`copy_from_slice`] lati fi kun gbogbo ege ni ẹẹkan.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Ọlọnà lafiwe ti vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Awọn ohun elo paṣẹ ti vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // lilo ju fun [T] lo kan aise bibẹ to tọka si awọn eroja ti awọn vector bi weakest pataki Iru;
            //
            // le yago fun ibeere ti Wiwulo ni awọn igba miiran
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec n kapa ipinfunni
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Ṣẹda ohun ṣofo `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: idanwo fa ni libstd, eyiti o fa awọn aṣiṣe nibi
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: idanwo fa ni libstd, eyiti o fa awọn aṣiṣe nibi
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Gba gbogbo awọn akoonu ti `Vec<T>` bi titobi kan, ti iwọn rẹ ba baamu ti orun ti o beere.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Ti ipari ko ba baamu, igbewọle yoo pada wa ni `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Ti o ba dara pẹlu gbigba prefix kan ti `Vec<T>`, o le pe [`.truncate(N)`](Vec::truncate) ni akọkọ.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // Aabo: `.set_len(0)` jẹ ohun nigbagbogbo.
        unsafe { vec.set_len(0) };

        // Aabo: Olubasọrọ `Vec` kan wa ni deede deedee, ati
        // tito sile awọn iwulo nilo jẹ kanna bii awọn ohun kan.
        // A ṣayẹwo tẹlẹ pe a ni awọn ohun kan ti o to.
        // Awọn nkan naa kii yoo ni ilọpo meji bi `set_len` ṣe sọ fun `Vec` lati ma ṣe ju wọn silẹ.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}