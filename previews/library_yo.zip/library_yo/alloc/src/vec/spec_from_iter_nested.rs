use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Amọja trait miiran fun Vec::from_iter pataki lati ṣe ọwọ pẹlu ọwọ ni pataki awọn amọja fifipamọ wo [`SpecFromIter`](super::SpecFromIter) fun awọn alaye.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Unroll aṣetunṣe akọkọ, bi vector yoo ṣe fẹ siwaju lori aṣetunṣe yii ni gbogbo ọran nigbati iterable ko ba ṣofo, ṣugbọn lupu ti o wa ni extend_desugared() kii yoo rii pe vector ti o kun ni awọn ite lilu atẹle diẹ.
        //
        // Nitorina a ni asọtẹlẹ branch ti o dara julọ.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // gbọdọ ṣe aṣoju si spec_extend() nitori extend() funrararẹ ṣe aṣoju si spec_from fun Vecs ofo
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // gbọdọ ṣe aṣoju si spec_extend() nitori extend() funrararẹ ṣe aṣoju si spec_from fun Vecs ofo
        //
        vector.spec_extend(iterator);
        vector
    }
}