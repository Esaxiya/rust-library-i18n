#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Awọn akoonu ti iranti tuntun ko ni oye.
    Uninitialized,
    /// Iranti tuntun ti ni idaniloju pe ko ni odo.
    Zeroed,
}

/// IwUlO ipele-kekere fun ipin ipin ergonomically diẹ sii, ipinpinpin, ati sisọpo ifipamọ iranti kan lori okiti laisi nini wahala nipa gbogbo awọn ọran igun ti o kan.
///
/// Iru yii dara julọ fun kikọ awọn ẹya data tirẹ bi Vec ati VecDeque.
/// Gegebi bi:
///
/// * Ṣe agbejade `Unique::dangling()` lori awọn iru iwọn odo.
/// * Ṣe agbejade `Unique::dangling()` lori awọn ipin ipin gigun-odo.
/// * Yago fun freeing `Unique::dangling()`.
/// * Mu gbogbo iṣan omi ni awọn iṣiro agbara (ṣe igbega wọn si "capacity overflow" panics).
/// * Awọn oluṣọ lodi si awọn eto 32-bit ti n pin diẹ sii ju awọn baiti isize::MAX.
/// * Awọn olusona lodi si iṣan gigun gigun rẹ.
/// * Awọn ipe `handle_alloc_error` fun awọn ipin isubu.
/// * Ni `ptr::Unique` kan ati nitorinaa fun olumulo ni gbogbo awọn anfani ti o jọmọ.
/// * Nlo apọju ti a pada lati ipin lati lo agbara ti o tobi julọ ti o wa.
///
/// Iru yii ko ṣe ayẹwo ayewo ti o ṣakoso.Nigbati o ba sọ silẹ *yoo* ṣe iranti iranti rẹ, ṣugbọn kii yoo * gbiyanju lati ju awọn akoonu rẹ silẹ.
/// O jẹ fun olumulo ti `RawVec` lati mu awọn ohun gangan *ti o fipamọ* inu ti `RawVec` kan.
///
/// Akiyesi pe apọju ti awọn iru iwọn odo jẹ ailopin nigbagbogbo, nitorinaa `capacity()` nigbagbogbo pada `usize::MAX`.
/// Eyi tumọ si pe o nilo lati ṣọra nigbati o ba n yi iru iru pẹlu `Box<[T]>` kan, nitori `capacity()` kii yoo fun ni ipari.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Eyi wa nitori `#[unstable]` `const fn` ko nilo lati ni ibamu si `min_const_fn` ati nitorinaa wọn ko le pe wọn ni`min_const_fn`s boya.
    ///
    /// Ti o ba yipada `RawVec<T>::new` tabi awọn igbẹkẹle, jọwọ ṣọra lati ma ṣe ṣafihan ohunkohun ti yoo ṣẹ `min_const_fn` ni otitọ.
    ///
    /// NOTE: A le yago fun gige yii ati ṣayẹwo ibaramu pẹlu diẹ ninu ẹda `#[rustc_force_min_const_fn]` eyiti o nilo ibaramu pẹlu `min_const_fn` ṣugbọn ko ṣe dandan gba ipe ni `stable(...) const fn`/koodu olumulo ko jẹ ki `foo` ṣiṣẹ nigbati `#[rustc_const_unstable(feature = "foo", issue = "01234")]` wa.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ṣẹda `RawVec` ti o tobi julọ ti o ṣeeṣe (lori okiti eto) laisi ipinya.
    /// Ti `T` ba ni iwọn rere, lẹhinna eyi ṣe `RawVec` pẹlu agbara `0`.
    /// Ti `T` ba jẹ iwọn-odo, lẹhinna o ṣe `RawVec` pẹlu agbara `usize::MAX`.
    /// Wulo fun imuse ipin ti o pẹ.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Ṣẹda `RawVec` kan (lori okiti eto) pẹlu deede agbara ati awọn ibeere titete fun `[T; capacity]` kan.
    /// Eyi jẹ deede si pipe `RawVec::new` nigbati `capacity` jẹ `0` tabi `T` jẹ iwọn odo.
    /// Akiyesi pe ti `T` ba ni iwọn odo eyi tumọ si pe iwọ kii yoo * gba `RawVec` pẹlu agbara ti a beere.
    ///
    /// # Panics
    ///
    /// Panics ti agbara ti a beere ba kọja awọn baiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts lori OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Bii `with_capacity`, ṣugbọn awọn onigbọwọ ifipamọ ti ni odo.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ṣe atunto `RawVec` kan lati ọdọ ijuboluwole ati agbara.
    ///
    /// # Safety
    ///
    /// A gbọdọ pin `ptr` (lori okiti eto), ati pẹlu `capacity` ti a fun.
    /// `capacity` ko le kọja `isize::MAX` fun awọn iru iwọn.(nikan a ibakcdun lori 32-bit awọn ọna šiše).
    /// ZST vectors le ni agbara to `usize::MAX`.
    /// Ti `ptr` ati `capacity` wa lati `RawVec` kan, lẹhinna eyi jẹ ẹri.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs yadi.Rekọja si:
    // - 8 ti iwọn abawọn ba jẹ 1, nitori eyikeyi awọn olupilẹpo okiti ṣee ṣe lati yika ibeere ti o kere ju baiti 8 si o kere awọn baiti mẹjọ.
    //
    // - 4 ti awọn eroja ba jẹ iwọn alabọde (<=1 KiB).
    // - 1 bibẹẹkọ, lati yago fun jafara aaye pupọ ju fun Vecs kuru pupọ.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Bii `new`, ṣugbọn o ṣe ipinnu lori yiyan ti ipin fun `RawVec` ti o pada.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tumo si "unallocated".awọn iru iwọn odo ko foju.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Bii `with_capacity`, ṣugbọn o ṣe ipinnu lori yiyan ti ipin fun `RawVec` ti o pada.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Bii `with_capacity_zeroed`, ṣugbọn o ṣe ipinnu lori yiyan ti ipin fun `RawVec` ti o pada.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Awọn iyipada `Box<[T]>` kan sinu `RawVec<T>` kan.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Yi gbogbo ifipamọ pada sinu `Box<[MaybeUninit<T>]>` pẹlu `len` ti a ṣalaye.
    ///
    /// Akiyesi pe eyi yoo tun ṣe atunto eyikeyi awọn ayipada `cap` ti o le ti ṣe.(Wo apejuwe iru fun awọn alaye.)
    ///
    /// # Safety
    ///
    /// * `len` gbọdọ tobi ju tabi dogba si agbara ti o beere julọ laipe, ati
    /// * `len` gbọdọ jẹ kere ju tabi dogba si `self.capacity()`.
    ///
    /// Akiyesi, pe agbara ti a beere ati `self.capacity()` le yato, bi olupilẹṣẹ le ṣe ipinpopopopopopopopada ati dapada iwe iranti iranti ti o tobi ju ti a beere lọ.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Mimọ-ṣayẹwo ọkan idaji ti ibeere aabo (a ko le ṣayẹwo idaji keji).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // A yago fun `unwrap_or_else` nibi nitori pe o tan iye ti LLVM IR ti ipilẹṣẹ.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ṣe atunto `RawVec` kan lati ọdọ ijuboluwole, agbara, ati ipin.
    ///
    /// # Safety
    ///
    /// A gbọdọ pin `ptr` (nipasẹ ipin ti a fun ni `alloc`), ati pẹlu `capacity` ti a fun.
    /// `capacity` ko le kọja `isize::MAX` fun awọn iru iwọn.
    /// (nikan a ibakcdun lori 32-bit awọn ọna šiše).
    /// ZST vectors le ni agbara to `usize::MAX`.
    /// Ti `ptr` ati `capacity` wa lati `RawVec` ti a ṣẹda nipasẹ `alloc`, lẹhinna eyi jẹ ẹri.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// N ni itọka aise si ibẹrẹ ipin.
    /// Akiyesi pe eyi ni `Unique::dangling()` ti `capacity == 0` tabi `T` jẹ iwọn-odo.
    /// Ninu ọran iṣaaju, o gbọdọ ṣọra.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Gba agbara ti ipin.
    ///
    /// Eyi yoo jẹ `usize::MAX` nigbagbogbo ti `T` ba ni iwọn odo.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Pada itọkasi itọka si ipin ti n ṣe atilẹyin `RawVec` yii.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // A ni ipin ti iranti ti a fi sọtọ, nitorinaa a le kọja awọn sọwedowo asiko lati gba ipilẹ akọkọ wa.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Ṣe idaniloju pe ifipamọ ni o kere ju aaye to lati mu awọn eroja `len + additional` dani.
    /// Ti ko ba ni agbara to tẹlẹ, yoo tun gbe aaye ti o to pẹlu aaye ọra ti o ni itunu lati ni ihuwasi ihuwasi *O*(1).
    ///
    /// Yoo ṣe idinwo ihuwasi yii ti yoo jẹ ki o fa ararẹ si panic.
    ///
    /// Ti `len` ba kọja `self.capacity()`, eyi le kuna lati pin aaye ti o beere fun gangan.
    /// Eyi kii ṣe ailewu ni otitọ, ṣugbọn koodu ti ko ni ailewu *iwọ* kọ ti o gbẹkẹle ihuwasi ti iṣẹ yii le fọ.
    ///
    /// Eyi jẹ apẹrẹ fun imuse iṣipo-titari iṣẹ bi `extend`.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba ju awọn baiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts lori OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ifipamọ yoo ti yọ kuro tabi bẹru ti iya ba kọja `isize::MAX` nitorinaa eyi jẹ ailewu lati ṣe ayẹwo ni bayi.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Kanna bi `reserve`, ṣugbọn o pada lori awọn aṣiṣe dipo ijaya tabi iṣẹyun.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Ṣe idaniloju pe ifipamọ ni o kere ju aaye to lati mu awọn eroja `len + additional` dani.
    /// Ti ko ba ṣe tẹlẹ, yoo ṣe ipin iye ti o kere julọ ti iranti pataki.
    /// Ni gbogbogbo eyi yoo jẹ deede iye iranti ti o ṣe pataki, ṣugbọn ni ipilẹ ipin naa ni ominira lati funni ni diẹ sii ju ti a beere lọ.
    ///
    ///
    /// Ti `len` ba kọja `self.capacity()`, eyi le kuna lati pin aaye ti o beere fun gangan.
    /// Eyi kii ṣe ailewu ni otitọ, ṣugbọn koodu ti ko ni ailewu *iwọ* kọ ti o gbẹkẹle ihuwasi ti iṣẹ yii le fọ.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba ju awọn baiti `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Aborts lori OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Kanna bi `reserve_exact`, ṣugbọn o pada lori awọn aṣiṣe dipo ijaya tabi iṣẹyun.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Pipin ipin si isalẹ si iye pàtó kan.
    /// Ti iye ti a fun ni 0, kosi awọn ipinpinpin patapata.
    ///
    /// # Panics
    ///
    /// Panics ti iye ti a fun ni *tobi* ju agbara lọwọlọwọ lọ.
    ///
    /// # Aborts
    ///
    /// Aborts lori OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Pada ti ifipamọ ba nilo lati dagba lati mu agbara afikun ti o nilo ṣẹ.
    /// Ti a lo ni akọkọ lati ṣe awọn ipe ifipamọ pamọ ṣee ṣe laisi fifa fifa `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ọna yii ni igbagbogbo instantiated ni ọpọlọpọ awọn igba.Nitorinaa a fẹ ki o jẹ kekere bi o ti ṣee ṣe, lati ṣe ilọsiwaju awọn akoko ikojọpọ.
    // Sugbon a tun fẹ bi Elo ti awọn oniwe-ni awọn akoonu ti lati wa ni statically computable bi o ti ṣee, lati ṣe awọn ti ipilẹṣẹ koodu run yiyara.
    // Nitorinaa, a kọ ọna yii daradara ki gbogbo koodu ti o da lori `T` wa ninu rẹ, lakoko ti ọpọlọpọ ti koodu ti ko dale lori `T` bi o ti ṣee ṣe ni awọn iṣẹ ti kii ṣe jenera lori `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Eyi ni idaniloju nipasẹ awọn ipo ipe.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Niwon a pada agbara ti `usize::MAX` nigbati `elem_size` jẹ
            // 0, gbigba si ibi dandan tumọ si pe `RawVec` ti bori.
            return Err(CapacityOverflow);
        }

        // Ko si ohun ti a le ṣe gaan nipa awọn sọwedowo wọnyi, ni ibanujẹ.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Eyi ṣe onigbọwọ idagbasoke idagbasoke.
        // Lemeji naa ko le ṣan nitori `cap <= isize::MAX` ati iru `cap` jẹ `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` jẹ aisi-jeneriki lori `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Awọn idiwọ lori ọna yii jẹ bakanna bii ti awọn ti o wa lori `grow_amortized`, ṣugbọn ọna yii nigbagbogbo ni igbagbogbo ni a fi sori ẹrọ diẹ nitorinaa ko ṣe pataki.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Niwon a pada agbara ti `usize::MAX` nigbati iwọn iru jẹ
            // 0, gbigba si ibi dandan tumọ si pe `RawVec` ti bori.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` jẹ aisi-jeneriki lori `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Iṣẹ yii wa ni ita `RawVec` lati dinku awọn akoko ikojọpọ.Wo asọye loke `RawVec::grow_amortized` fun awọn alaye.
// (Iwọn `A` ko ṣe pataki, nitori nọmba ti awọn oriṣiriṣi `A` oriṣiriṣi ti a rii ni iṣe jẹ kere pupọ ju nọmba awọn iru `T` lọ.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Ṣayẹwo fun aṣiṣe nibi lati dinku iwọn ti `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Oluṣeto sọwedowo fun isọgba titọ
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Yoo iranti ti ohun-ini nipasẹ `RawVec`*laisi* gbiyanju lati ju awọn akoonu rẹ silẹ.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Iṣẹ aarin fun mimu aṣiṣe ifiṣura.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// A nilo lati ṣe iṣeduro awọn atẹle:
// * A ko ṣe ipin awọn ohun elo iwọn baiti `> isize::MAX`.
// * A ko ṣan omi lori `usize::MAX` ati ṣe ipinfunni pupọ diẹ.
//
// Lori 64-bit a kan nilo lati ṣayẹwo fun iṣanju niwon igbiyanju lati fi awọn baiti `> isize::MAX` sọtọ yoo daju pe yoo kuna.
// Lori 32-bit ati 16-bit a nilo lati ṣafikun aabo afikun fun eyi bi o ba jẹ pe a n ṣiṣẹ lori pẹpẹ eyiti o le lo gbogbo 4GB ni aaye olumulo, fun apẹẹrẹ, PAE tabi x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Iṣẹ aringbungbun kan ti o ni idawọle fun agbara iroyin.
// Eyi yoo rii daju pe iran koodu ti o ni ibatan si panics wọnyi jẹ iwonba nitori ipo kan nikan wa eyiti panics kuku ju opo lọ jakejado module naa.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}