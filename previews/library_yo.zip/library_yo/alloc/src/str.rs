//! Awọn ege okun Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Iru `&str` jẹ ọkan ninu awọn oriṣi okun akọkọ meji, ekeji ni `String`.
//! Ko dabi ẹlẹgbẹ `String` rẹ, awọn akoonu rẹ ti ya.
//!
//! # Ipilẹ Lilo
//!
//! Ikede okun ipilẹ ti iru `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Nibi a ti kede gegebi okun, ti a tun mọ ni gige ege.
//! Awọn litireso okun ni igbesi aye aimi, eyiti o tumọ si okun `hello_world` jẹ ẹri lati wulo fun iye gbogbo eto naa.
//!
//! A le ṣe alaye ni gbangba ni igbesi aye `hello_world` daradara:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Ọpọlọpọ awọn lilo ti o wa ninu module yii ni lilo nikan ni iṣeto idanwo.
// O jẹ mimọ julọ lati kan pa ikilọ ailorukọ_akopọ ju lati ṣatunṣe wọn lọ.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` ni `Concat<str>` kii ṣe itumọ nibi.
/// Iru paramita ti trait nikan wa lati jẹki iwuri miiran.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // awọn losiwajulosehin pẹlu awọn iwọn lile koodu ṣiṣe ni iyara pupọ ni amọja awọn ọran pẹlu awọn gigun gigun ipin kekere
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // lainidii ti kii-odo iwọn fallback
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Iṣapeye darapọ mọ imuse ti o ṣiṣẹ fun Vec mejeeji<T>(T: Daakọ) ati Ẹrọ inu ti okun Lọwọlọwọ (2018-05-13) aṣiṣe kan wa pẹlu irufẹ irufẹ ati amọja (wo ọrọ #36262) Fun idi eyi SliceConcat<T>ko jẹ amọja fun T: Daakọ ati SliceConcat<str>nikan ni olumulo iṣẹ yii.
// O ti wa ni osi ni aye fun akoko ti o wa titi.
//
// awọn igboro fun Okun-darapọ jẹ S: Yiya<str>ati fun Vec-join Borrow <[T]> [T] ati str mejeeji impl AsRef <[T]> fun diẹ ninu T
// => s.borrow().as_ref() ati pe a ni awọn ege nigbagbogbo
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ekini akọkọ jẹ ọkan nikan laisi ipinya ti o ṣaju rẹ
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // ṣe iṣiro ipari lapapọ ti Vec ti o darapọ ti iṣiro `len` ba ṣan, a yoo panic a yoo ti pari iranti ni bakanna ati iyoku iṣẹ naa nilo gbogbo Vec ti a ti sọ tẹlẹ fun aabo
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // mura ipamọ ti ko ni oye
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // daakọ oluyapaya ati awọn ege lori laisi awọn sọwedowo aala ṣe ina awọn iyipo pẹlu awọn aiṣedede lile fun awọn ilọsiwaju nla nla awọn oluya ṣee ṣe (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Imuse awin ajeji le pada awọn ege oriṣiriṣi fun iṣiro gigun ati ẹda gangan.
        //
        // Rii daju pe a ko ṣe afihan awọn baiti ti ko mọ si olupe naa.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Awọn ọna fun awọn ege okun.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Iyipada `Box<str>` kan sinu `Box<[u8]>` laisi didakọ tabi ipinpin.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Rọpo gbogbo awọn ere-kere ti apẹẹrẹ pẹlu okun miiran.
    ///
    /// `replace` ṣẹda [`String`] tuntun, ati awọn ẹda awọn data lati okun gige yi sinu rẹ.
    /// Lakoko ti o ṣe bẹ, o gbiyanju lati wa awọn ere-kere ti apẹẹrẹ kan.
    /// Ti o ba rii eyikeyi, o rọpo wọn pẹlu gige gige okun rirọpo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Nigbati apẹẹrẹ ko baamu:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Rọpo awọn ibaamu N akọkọ ti apẹẹrẹ pẹlu okun miiran.
    ///
    /// `replacen` ṣẹda [`String`] tuntun, ati awọn ẹda awọn data lati okun gige yi sinu rẹ.
    /// Lakoko ti o ṣe bẹ, o gbiyanju lati wa awọn ere-kere ti apẹẹrẹ kan.
    /// Ti o ba rii eyikeyi, o rọpo wọn pẹlu gige ege rirọpo ni ọpọlọpọ awọn akoko `count`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Nigbati apẹẹrẹ ko baamu:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Ireti lati dinku awọn akoko ti ipin-ipin
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Pada deede kekere kekere ti ege okun yi, bi [`String`] tuntun.
    ///
    /// 'Lowercase' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `Lowercase`.
    ///
    /// Niwọn igba ti diẹ ninu awọn ohun kikọ le faagun si awọn kikọ pupọ nigbati wọn ba yipada ọran naa, iṣẹ yii da [`String`] kan pada dipo yiyipada paramita ni ipo.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Apẹẹrẹ ti ẹtan, pẹlu sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ṣugbọn ni ipari ọrọ kan, o jẹ ς, kii ṣe σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Awọn ede laisi ọran ko yipada:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Awọn maapu si σ, ayafi ni ipari ọrọ kan nibiti o ti maapu si ς.
                // Eyi ni (contextual) ti o ni majemu nikan ṣugbọn aworan agbaye ti ominira ni `SpecialCasing.txt`, nitorinaa ṣe koodu-lile rẹ dipo ki o ni ilana "condition" jeneriki kan.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // fun itumọ ti `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Pada deede oke nla ti ege okun yi, bi [`String`] tuntun kan.
    ///
    /// 'Uppercase' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `Uppercase`.
    ///
    /// Niwọn igba ti diẹ ninu awọn ohun kikọ le faagun si awọn kikọ pupọ nigbati wọn ba yipada ọran naa, iṣẹ yii da [`String`] kan pada dipo yiyipada paramita ni ipo.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Awọn iwe afọwọkọ laisi ọran ko yipada:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Ohun kikọ kan le di pupọ:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Iyipada [`Box<str>`] kan sinu [`String`] laisi didakọ tabi ipinpin.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Ṣẹda [`String`] tuntun nipasẹ tun ṣe awọn akoko `n` okun kan.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo jẹ panic ti agbara naa ba le bori.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic kan lori iṣan omi:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Pada ẹda ti okun yii nibiti a ti ya ohun kikọ kọọkan si deede ọran nla ASCII rẹ.
    ///
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati ṣe agbepo iye ni ipo, lo [`make_ascii_uppercase`].
    ///
    /// Si awọn ohun kikọ ASCII oke nla ni afikun si awọn ohun kikọ ti kii ṣe ASCII, lo [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() ṣe itọju ailopin UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Pada ẹda ti okun yii nibiti a ti ya ohun kikọ kọọkan si deede ọrọ kekere ASCII rẹ.
    ///
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati kekere iye ni ipo, lo [`make_ascii_lowercase`].
    ///
    /// To lowercase ASCII ohun kikọ ni afikun si ti kii-ASCII ohun kikọ, lo [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() ṣe itọju ailopin UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Yi awọn ege ti awọn baiti ti o ni apoti pada si bibẹ pẹlẹbẹ ti o ni apoti laisi ṣayẹwo pe okun ni UTF-8 to wulo.
///
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}