//! Wiwo ti iṣan-ara sinu ọkọọkan onigbọwọ, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Awọn ege jẹ wiwo si apo-iranti ti o ni ipoduduro bi ijuboluwole ati gigun kan.
//!
//! ```
//! // gige kan Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // coercing ohun orun si ege kan
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Awọn ege jẹ boya iyipada tabi pinpin.
//! Iru iru nkan bibẹ ti a pin jẹ `&[T]`, lakoko ti iru nkan gbigbẹ ti o le yipada jẹ `&mut [T]`, nibiti `T` duro fun iru eroja.
//! Fun apẹẹrẹ, o le ṣe iyipada ohun amorindun ti iranti ti gige gige kan tọka si:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Eyi ni diẹ ninu awọn nkan ti module yii ni:
//!
//! ## Structs
//!
//! Awọn ọna pupọ lo wa ti o wulo fun awọn ege, bii [`Iter`], eyiti o ṣe aṣoju aṣetunṣe lori ege kan.
//!
//! ## Awọn imuse Trait
//!
//! Awọn imuṣẹ lọpọlọpọ lo wa ti traits ti o wọpọ fun awọn ege.Diẹ ninu awọn apẹẹrẹ pẹlu:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], fun awọn ege ti iru eroja jẹ [`Eq`] tabi [`Ord`].
//! * [`Hash`] - fun awọn ege ti iru eroja jẹ [`Hash`].
//!
//! ## Iteration
//!
//! Awọn ege n ṣe `IntoIterator`.Aṣetunṣe n mu awọn itọkasi si awọn eroja ege.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Bibẹ pẹlẹbẹ ti o ni iyipada n mu awọn itọkasi iyipada si awọn eroja lọ:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Olutumọ yii n mu awọn ifọkasi iyipada si awọn nkan ti ege, nitorinaa lakoko ti iru eroja ti ege jẹ `i32`, iru eroja ti aṣetunṣe jẹ `&mut i32`.
//!
//!
//! * [`.iter`] ati [`.iter_mut`] jẹ awọn ọna ti o fojuhan lati da awọn olutọju aiyipada pada.
//! * Awọn ọna siwaju ti o da awọn onigbọwọ pada jẹ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ati diẹ sii.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Ọpọlọpọ awọn lilo ti o wa ninu module yii ni lilo nikan ni iṣeto idanwo.
// O jẹ mimọ julọ lati kan pa ikilọ ailorukọ_akopọ ju lati ṣatunṣe wọn lọ.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Awọn ọna itẹsiwaju bibẹ pẹlẹbẹ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nilo fun imuse ti Makiro `vec!` lakoko idanwo NB, wo modulu `hack` ninu faili yii fun awọn alaye diẹ sii.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nilo fun imuse ti `Vec::clone` lakoko idanwo NB, wo modulu `hack` ninu faili yii fun awọn alaye diẹ sii.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Pẹlu cfg(test) `impl [T]` ko si, awọn iṣẹ mẹta wọnyi jẹ awọn ọna gangan ti o wa ni `impl [T]` ṣugbọn kii ṣe ni `core::slice::SliceExt`, a nilo lati pese awọn iṣẹ wọnyi fun idanwo `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // A ko yẹ ki o ṣafikun abuda inline si eyi nitori eyi ni a lo ninu `vec!` macro julọ ati fa ifasẹyin perf.
    // Wo #71204 fun ijiroro ati awọn abajade perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // awọn ohun kan ti samisi ipilẹṣẹ ni ọna yii ni isalẹ
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) jẹ pataki fun LLVM lati yọ awọn sọwedowo aala kuro ati pe o ni codegen ti o dara julọ ju zip lọ.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // a ti pin vec ati ipilẹṣẹ loke si o kere ju gigun yii.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // sọtọ loke pẹlu agbara ti `s`, ati ipilẹṣẹ si `s.len()` ni ptr::copy_to_non_overlapping ni isalẹ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Awọn iru nkan naa.
    ///
    /// Iru yii jẹ iduroṣinṣin (ie, ko ṣe atunṣe awọn eroja to dogba) ati *O*(*n*\*log(* n*)) buru-nla.
    ///
    /// Nigbati o ba wulo, tito lẹsẹsẹ riru jẹ ayanfẹ nitori pe o yarayara ju iyatọ iduroṣinṣin ati pe ko ṣe ipin iranti oluranlọwọ.
    /// Wo [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu lọwọlọwọ jẹ aṣamubadọgba, isomọ idapọ iru ti atilẹyin nipasẹ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// A ṣe apẹrẹ lati wa ni iyara pupọ ni awọn ọran nibiti o ti fẹrẹ to lẹsẹsẹ, tabi ni awọn ọna itẹlera meji tabi diẹ sii ti a ṣe pọpọ lẹkan miiran.
    ///
    ///
    /// Paapaa, o pin ibi ipamọ igba diẹ idaji iwọn ti `self`, ṣugbọn fun awọn ege kukuru ọna iru ifibọ ti kii ṣe ipinya ni a lo dipo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Awọn ege bibẹ pẹlu iṣẹ afiwera.
    ///
    /// Iru yii jẹ iduroṣinṣin (ie, ko ṣe atunṣe awọn eroja to dogba) ati *O*(*n*\*log(* n*)) buru-nla.
    ///
    /// Iṣẹ afiwera gbọdọ ṣalaye aṣẹ-aṣẹ lapapọ fun awọn eroja inu ege.Ti aṣẹ ko ba jẹ apapọ, aṣẹ ti awọn eroja ko ṣalaye.
    /// Ibere jẹ aṣẹ lapapọ ti o ba jẹ (fun gbogbo `a`, `b` ati `c`):
    ///
    /// * lapapọ ati antisymmetric: deede ọkan ninu `a < b`, `a == b` tabi `a > b` jẹ otitọ, ati
    /// * transitive, `a < b` ati `b < c` tumọ si `a < c`.Kanna gbọdọ mu fun `==` ati `>` mejeeji.
    ///
    /// Fun apẹẹrẹ, lakoko ti [`f64`] ko ṣe imuse [`Ord`] nitori `NaN != NaN`, a le lo `partial_cmp` bi iru iṣẹ wa nigbati a mọ pe ege naa ko ni `NaN` kan.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Nigbati o ba wulo, tito lẹsẹsẹ riru jẹ ayanfẹ nitori pe o yarayara ju iyatọ iduroṣinṣin ati pe ko ṣe ipin iranti oluranlọwọ.
    /// Wo [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu lọwọlọwọ jẹ aṣamubadọgba, isomọ idapọ iru ti atilẹyin nipasẹ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// A ṣe apẹrẹ lati wa ni iyara pupọ ni awọn ọran nibiti o ti fẹrẹ to lẹsẹsẹ, tabi ni awọn ọna itẹlera meji tabi diẹ sii ti a ṣe pọpọ lẹkan miiran.
    ///
    /// Paapaa, o pin ibi ipamọ igba diẹ idaji iwọn ti `self`, ṣugbọn fun awọn ege kukuru ọna iru ifibọ ti kii ṣe ipinya ni a lo dipo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // yiyipada ayokuro
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Awọn iru nkan pẹlu iṣẹ isediwon bọtini.
    ///
    /// Iru yii jẹ iduroṣinṣin (ie, ko ṣe atunṣe awọn eroja to dogba) ati *O*(*m*\* * n *\* log(*n*)) buru-nla, nibiti iṣẹ bọtini jẹ *O*(*m*).
    ///
    /// Fun awọn iṣẹ bọtini gbowolori (fun apẹẹrẹ
    /// awọn iṣẹ ti kii ṣe awọn iraye si ohun-ini ti o rọrun tabi awọn iṣẹ ipilẹ), [`sort_by_cached_key`](slice::sort_by_cached_key) le jẹ yiyara ni iyara, nitori ko ṣe san awọn bọtini eroja.
    ///
    ///
    /// Nigbati o ba wulo, tito lẹsẹsẹ riru jẹ ayanfẹ nitori pe o yarayara ju iyatọ iduroṣinṣin ati pe ko ṣe ipin iranti oluranlọwọ.
    /// Wo [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu lọwọlọwọ jẹ aṣamubadọgba, isomọ idapọ iru ti atilẹyin nipasẹ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// A ṣe apẹrẹ lati wa ni iyara pupọ ni awọn ọran nibiti o ti fẹrẹ to lẹsẹsẹ, tabi ni awọn ọna itẹlera meji tabi diẹ sii ti a ṣe pọpọ lẹkan miiran.
    ///
    /// Paapaa, o pin ibi ipamọ igba diẹ idaji iwọn ti `self`, ṣugbọn fun awọn ege kukuru ọna iru ifibọ ti kii ṣe ipinya ni a lo dipo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Awọn iru nkan pẹlu iṣẹ isediwon bọtini.
    ///
    /// Lakoko tito lẹsẹsẹ, iṣẹ bọtini ni a pe ni ẹẹkan fun eroja.
    ///
    /// Iru yii jẹ iduroṣinṣin (ie, ko ṣe atunṣe awọn eroja to dogba) ati *O*(*m*\* * n *+* n *\* log(*n*)) buru-nla, nibiti iṣẹ bọtini jẹ *O*(*m*) .
    ///
    /// Fun awọn iṣẹ bọtini ti o rọrun (fun apẹẹrẹ, awọn iṣẹ ti o jẹ awọn iraye si ohun-ini tabi awọn iṣẹ ipilẹ), o ṣeeṣe ki [`sort_by_key`](slice::sort_by_key) yiyara.
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori [pattern-defeating quicksort][pdqsort] nipasẹ Orson Peters, eyiti o ṣe idapọ ọrọ ọran ti o yara iyara ti iyara oninọrun pẹlu ọran ti o buru ju ti akopọ, lakoko ti o ṣaṣeyọri akoko laini lori awọn ege pẹlu awọn ilana kan.
    /// O nlo diẹ ninu iyatọ lati yago fun awọn ọran ibajẹ, ṣugbọn pẹlu seed ti o wa titi lati pese ihuwasi ṣiṣe ipinnu nigbagbogbo.
    ///
    /// Ninu ọran ti o buru julọ, algorithm sọtọ ibi ipamọ igba diẹ ninu `Vec<(K, usize)>` gigun pẹlẹbẹ naa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Makiro Oluranlọwọ fun titọka vector wa nipasẹ oriṣi ti o kere julọ, lati dinku ipin.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Awọn eroja ti `indices` jẹ alailẹgbẹ, bi wọn ti ṣe itọka, nitorinaa iru eyikeyi yoo jẹ idurosinsin pẹlu ọwọ si bibẹ pẹlẹbẹ.
                // A lo `sort_unstable` nibi nitori pe o nilo ipin iranti kekere.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Awọn ẹda Awọn `self` sinu `Vec` tuntun.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Nibi, `s` ati `x` le yipada ni ominira.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Awọn ẹda `self` sinu `Vec` tuntun pẹlu ipinya kan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Nibi, `s` ati `x` le yipada ni ominira.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, wo modulu `hack` ninu faili yii fun awọn alaye diẹ sii.
        hack::to_vec(self, alloc)
    }

    /// Yipada `self` sinu vector laisi awọn ere ibeji tabi ipin.
    ///
    /// Abajade vector le ti wa ni iyipada pada sinu apoti kan nipasẹ `Vec<T>Ọna `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ko le lo mọ nitori o ti yipada si `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, wo modulu `hack` ninu faili yii fun awọn alaye diẹ sii.
        hack::into_vec(self)
    }

    /// Ṣẹda vector nipasẹ tun ṣe awọn akoko `n` ege kan.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo jẹ panic ti agbara naa ba le bori.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic kan lori iṣan omi:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ti `n` tobi ju odo lọ, o le pin bi `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ni nọmba ti o jẹ aṣoju nipasẹ apa '1' ti o sunmọ julọ ti `n`, ati pe `rem` jẹ apakan ti o ku ti `n`.
        //
        //

        // Lilo `Vec` lati wọle si `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` atunwi ti ṣe nipasẹ ilọpo meji `buf` ``awọn akoko expn`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ti `m > 0` ba wa, awọn idinku to ku wa si '1' ti o sunmọ julọ.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ni agbara ti `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) atunwi ti ṣe nipasẹ didakọ awọn atunwi `rem` akọkọ lati `buf` funrararẹ.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Eyi kii ṣe agbekọja lati igba `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` dogba si `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens ege ti `T` sinu iye kan ṣoṣo `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens ege ti `T` sinu iye `Self::Output` kan ṣoṣo, fifi ipinya ti a fun laarin ọkọọkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens ege ti `T` sinu iye `Self::Output` kan ṣoṣo, fifi ipinya ti a fun laarin ọkọọkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Pada vector kan ti o ni ẹda ti bibẹ pẹlẹbẹ yii nibiti a ti ya baiti kọọkan si deede ọran nla ASCII rẹ.
    ///
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati ṣe agbepo iye ni ipo, lo [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Pada vector kan ti o ni ẹda ti bibẹ pẹlẹbẹ yii nibiti a ti ya baiti kọọkan si deede iru ọrọ kekere ASCII rẹ.
    ///
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati kekere iye ni ipo, lo [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ifaagun traits fun awọn ege lori iru data kan pato
////////////////////////////////////////////////////////////////////////////////

/// Oluranlọwọ trait fun [`[T]: : concat`]](bibẹ::concat).
///
/// Note: a ko lo paramita iru `Item` ni trait yii, ṣugbọn o gba awọn iwuri laaye lati jẹ jeneriki diẹ sii.
/// Laisi o, a gba aṣiṣe yii:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Eyi jẹ nitori awọn iru `V` le wa pẹlu ọpọlọpọ awọn igbewọle `Borrow<[_]>` lọpọlọpọ, bii iru awọn iru `T` pupọ yoo lo:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Iru abajade lẹhin igbimọ
    type Output;

    /// Imuṣẹ ti [`[T]: : concat`](bibẹ::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Oluranlọwọ trait fun [`[T]: : join`](bibẹ::dapọ)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Iru abajade lẹhin igbimọ
    type Output;

    /// Imuṣẹ ti [`[T]: : join`](bibẹ::dapọ)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Awọn imuṣẹ boṣewa trait fun awọn ege
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ju ohunkohun silẹ ninu ibi-afẹde ti kii yoo tun kọ
        target.truncate(self.len());

        // target.len <= self.len nitori truncate loke, nitorinaa awọn ege ti o wa nibi wa ni aala nigbagbogbo.
        //
        let (init, tail) = self.split_at(target.len());

        // tun lo awọn iye ti o wa ninu allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Awọn ifibọ `v[0]` sinu ọna kika lẹsẹsẹ `v[1..]` tẹlẹ ki gbogbo `v[..]` di tito lẹsẹsẹ.
///
/// Eyi ni abẹ-abẹ abẹ ti iru ifibọ.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Awọn ọna mẹta lo wa lati ṣe ifibọ sii nibi:
            //
            // 1. Siparọ awọn eroja to wa nitosi titi akọkọ yoo fi de opin opin rẹ.
            //    Sibẹsibẹ, ọna yii a daakọ data ni ayika diẹ sii ju pataki lọ.
            //    Ti awọn eroja jẹ awọn ẹya nla (idiyele lati daakọ), ọna yii yoo lọra.
            //
            // 2. Iterate titi di aaye ti o tọ fun eroja akọkọ ti wa.
            // Lẹhinna yi awọn eroja ti n ṣaṣeyọri rẹ lati ṣe aye fun rẹ ati nikẹhin gbe si iho ti o ku.
            // Eyi jẹ ọna ti o dara.
            //
            // 3. Daakọ ẹda akọkọ sinu oniyipada igba diẹ.Ṣe imukuro titi ti o fi yẹ aaye ti o wa.
            // Bi a ṣe n lọ, daakọ gbogbo nkan ti a kọja kọja si iho ti o ṣaju rẹ.
            // Lakotan, daakọ data lati oniyipada igba diẹ sinu iho ti o ku.
            // Ọna yii dara pupọ.
            // Awọn aṣepari ṣe afihan iṣẹ diẹ ti o dara julọ ju pẹlu ọna 2nd lọ.
            //
            // Gbogbo awọn ọna ni a fi aami si, ati pe 3rd fihan awọn esi to dara julọ.Nitorina a yan ọkan naa.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ipo agbedemeji ti ilana ifibọ ni atẹle nigbagbogbo nipasẹ `hole`, eyiti o ṣe iṣẹ awọn idi meji:
            // 1. Ṣe aabo iduroṣinṣin ti `v` lati panics ni `is_less`.
            // 2. Kun iho ti o ku ni `v` ni ipari.
            //
            // Aabo Panic:
            //
            // Ti `is_less` panics ni eyikeyi aaye lakoko ilana, `hole` yoo lọ silẹ ki o kun iho ni `v` pẹlu `tmp`, nitorinaa rii daju pe `v` tun di gbogbo ohun ti o kọkọ mu mu ni deede lẹẹkan.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ti lọ silẹ ati nitorinaa awọn ẹda `tmp` sinu iho ti o ku ni `v`.
        }
    }

    // Nigbati o ba silẹ, awọn ẹda lati `src` sinu `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Dapọ awọn ti ko dinku dinku gbalaye `v[..mid]` ati `v[mid..]` ni lilo `buf` bi ibi ipamọ igba diẹ, ati tọju abajade sinu `v[..]`.
///
/// # Safety
///
/// Awọn ege meji naa gbọdọ jẹ ofo ati `mid` gbọdọ wa ni awọn aala.
/// Buffer `buf` gbọdọ ni pipẹ to lati mu ẹda ti ege kukuru.
/// Paapaa, `T` ko gbọdọ jẹ iru iwọn odo.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Ilana isopọ akọkọ awọn ẹda idapọ kukuru si `buf`.
    // Lẹhinna o wa kakiri ṣiṣe dakọ tuntun ati ṣiṣe to gun siwaju (tabi sẹhin), ni afiwe awọn eroja wọn ti ko jinle ti o tẹle ati didakọ ọkan ti o kere julọ (tabi tobi julọ) sinu `v`.
    //
    // Ni kete ti ṣiṣe kukuru ti pari ni kikun, ilana naa ti ṣe.Ti ṣiṣe ti o gun ba gba run ni akọkọ, lẹhinna a gbọdọ daakọ ohunkohun ti o ku ninu ṣiṣe kukuru si iho ti o ku ni `v`.
    //
    // Ipo agbedemeji ti ilana naa ni atẹle nigbagbogbo nipasẹ `hole`, eyiti o ṣe iṣẹ awọn idi meji:
    // 1. Ṣe aabo iduroṣinṣin ti `v` lati panics ni `is_less`.
    // 2. Kun iho ti o ku ni `v` ti ṣiṣe to gun ba jẹ akọkọ.
    //
    // Aabo Panic:
    //
    // Ti `is_less` panics ni eyikeyi aaye lakoko ilana naa, `hole` yoo lọ silẹ ki o kun iho ni `v` pẹlu ibiti a ko tii ronu ni `buf`, nitorinaa rii daju pe `v` tun di gbogbo ohun ti o kọkọ mu mu ni deede lẹẹkan.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Osi ṣiṣe ni kikuru.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Ni ibẹrẹ, awọn itọka wọnyi tọka si ibẹrẹ ti awọn eto wọn.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Je egbe ti o kere ju.
            // Ti o ba dọgba, fẹran ṣiṣe osi lati ṣetọju iduroṣinṣin.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Ṣiṣe ọtun jẹ kikuru.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Ni ibẹrẹ, awọn itọka wọnyi tọka si awọn opin ti awọn eto wọn.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Je apa ti o tobi ju.
            // Ti o ba dọgba, fẹran ṣiṣe to tọ lati ṣetọju iduroṣinṣin.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Lakotan, `hole` n silẹ.
    // Ti ṣiṣe kukuru ko ba jẹ kikun, ohunkohun ti o ku ninu rẹ yoo di bayi ni iho ni `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Nigbati o ba silẹ, daakọ ibiti `start..end` sinu `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` kii ṣe iru iwọn odo, nitorinaa o dara lati pin nipasẹ iwọn rẹ.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Iru iṣọpọ yii ya awọn imọran diẹ (ṣugbọn kii ṣe gbogbo) lati TimSort, eyiti o ṣe apejuwe ni apejuwe [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Alugoridimu ṣe idanimọ wiwọn isalẹ ati awọn atẹle ti kii ṣe sọkalẹ, eyiti a pe ni awọn ṣiṣan ti ara.Akopọ kan ti awọn ṣiṣiṣẹ ni isunmọtosi wa sibẹsibẹ lati dapọ.
/// Igbesi aye tuntun ti a rii tuntun ni a ti le lori akopọ naa, lẹhinna diẹ ninu awọn orisii ti awọn isunmọ ti o sunmọ ni a dapọ titi ti awọn alaipa meji wọnyi yoo fi ni itẹlọrun:
///
/// 1. fun gbogbo `i` ni `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. fun gbogbo `i` ni `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Awọn alailera rii daju pe apapọ akoko ṣiṣiṣẹ jẹ *O*(*n*\*log(* n*)) buru-nla.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Awọn ege ti o to gigun yii ni lẹsẹsẹ nipa lilo iru ifibọ.
    const MAX_INSERTION: usize = 20;
    // Awọn ṣiṣiṣẹ kukuru kukuru ti wa ni ilọsiwaju nipa lilo iru ifibọ lati na ni o kere ju ọpọlọpọ awọn eroja yii.
    const MIN_RUN: usize = 10;

    // Tito lẹsẹsẹ ko ni ihuwasi ti o ni itumọ lori awọn iru iwọn odo.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Awọn ọna kukuru ni a to lẹsẹsẹ ni ipo nipasẹ iru ifibọ lati yago fun awọn ipin.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Pin saarin kan lati lo bi iranti ibere.A tọju gigun 0 nitorina a le tọju ninu rẹ awọn ẹda aijinile ti awọn akoonu ti `v` laisi eewu awọn dtors ti n ṣiṣẹ lori awọn ẹda ti `is_less` panics ba jẹ.
    //
    // Nigbati o ba n dapọ awọn ṣiṣiṣẹ lẹsẹsẹ meji, ifipamọ yii ni ẹda ti ṣiṣe kukuru, eyiti yoo ni ipari nigbagbogbo julọ `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Lati ṣe idanimọ awọn ṣiṣan ti ara ni `v`, a kọja rẹ sẹhin.
    // Iyẹn le dabi ipinnu ajeji, ṣugbọn ṣe akiyesi o daju pe awọn iṣọkan darapọ nigbagbogbo ma nlo ni ọna idakeji (forwards).
    // Gẹgẹbi awọn aṣepari, didapọ awọn iwaju jẹ yiyara diẹ sii ju didọpọ sẹhin.
    // Lati pari, idanimọ awọn ṣiṣe nipasẹ lilọ kakiri sẹhin n mu ilọsiwaju dara.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Wa ṣiṣe ṣiṣe ti atẹle, ki o yi pada ti o ba sọkalẹ ni muna.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Fi diẹ ninu awọn eroja sii sinu ṣiṣe ti o ba kuru ju.
        // Iru ifibọ sii yara ju sisopọ iru lori awọn ọna kukuru, nitorinaa eyi mu ilọsiwaju dara si ni pataki.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Titari ṣiṣe yii pẹpẹ si akopọ naa.
        runs.push(Run { start, len: end - start });
        end = start;

        // Darapọ diẹ ninu awọn bata ti awọn ṣiṣiṣẹ ti o wa nitosi lati ni itẹlọrun awọn alailera.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Lakotan, ṣiṣe gangan kan gbọdọ wa ninu akopọ naa.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Ṣe ayẹwo akopọ awọn ṣiṣiṣẹ ati ṣe idanimọ awọn bata ti atẹle lati dapọ.
    // Ni pataki diẹ sii, ti `Some(r)` ba pada, iyẹn tumọ si `runs[r]` ati `runs[r + 1]` gbọdọ wa ni iṣọkan ni atẹle.
    // Ti algorithm yẹ ki o tẹsiwaju kọ ṣiṣe tuntun kan dipo, `None` ti pada.
    //
    // TimSort jẹ ailokiki fun awọn imuse buggy rẹ, bi a ti ṣalaye rẹ nibi:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Koko-ọrọ itan naa ni: a gbọdọ mu lagabara awọn alailera lori awọn ṣiṣan mẹrin ti o ga julọ lori akopọ naa.
    // Fifi agbara mu wọn lori oke mẹta nikan ko to lati rii daju pe awọn alailera yoo tun mu fun * gbogbo awọn ṣiṣe ni akopọ.
    //
    // Iṣẹ yii ṣayẹwo awọn aiṣe deede fun awọn ṣiṣiṣẹ mẹrin mẹrin.
    // Ni afikun, ti iṣiṣẹ oke ba bẹrẹ ni itọka 0, yoo ma beere iṣẹ iṣakopọ nigbagbogbo titi ti akopọ naa yoo wolẹ ni kikun, lati le pari iru.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}