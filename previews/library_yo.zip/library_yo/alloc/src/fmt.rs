//! Awọn ohun elo fun kika ati titẹ sita `String`s.
//!
//! Atokun yii ni atilẹyin asiko asiko fun itẹsiwaju sintasi [`format!`].
//! A ṣe agbekalẹ Makiro yii ni akopọ lati gbe awọn ipe si modulu yii lati le ṣe agbekalẹ awọn ariyanjiyan ni asiko asiko si awọn okun.
//!
//! # Usage
//!
//! Makiro [`format!`] ti pinnu lati jẹ faramọ si awọn ti nbọ lati awọn iṣẹ C's `printf`/`fprintf` tabi iṣẹ Python's `str.format`.
//!
//! Diẹ ninu awọn apẹẹrẹ ti itẹsiwaju [`format!`] ni:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" pẹlu asiwaju odo
//! ```
//!
//! Lati iwọnyi, o le rii pe ariyanjiyan akọkọ jẹ okun kika.O nilo nipasẹ olupilẹṣẹ fun eyi lati jẹ gegebi okun;ko le jẹ oniyipada ti o kọja ninu (lati le ṣayẹwo yiyewo).
//! Olupilẹṣẹ naa yoo ṣe itọsẹ okun kika ki o pinnu boya atokọ ti awọn ariyanjiyan ti a pese ni o yẹ lati kọja si okun kika.
//!
//! Lati yipada iye kan si okun, lo ọna [`to_string`].Eyi yoo lo ọna kika [`Display`] trait.
//!
//! ## Awọn ipo ipo ipo
//!
//! Gbogbo ariyanjiyan akoonu kika ni a gba laaye lati ṣafihan iru ariyanjiyan iye ti o n tọka si, ati pe ti o ba kuro ni a gba pe o jẹ "the next argument".
//! Fun apẹẹrẹ, okun kika kika `{} {} {}` yoo gba awọn ipele mẹta, ati pe wọn yoo ṣe kika ni ọna kanna bi wọn ti fun wọn.
//! Okun kika `{2} {1} {0}`, sibẹsibẹ, yoo ṣe agbekalẹ awọn ariyanjiyan ni aṣẹ yiyipada.
//!
//! Awọn nkan le jẹ ẹtan kekere kan ni kete ti o ba dapọ awọn oriṣi meji ti awọn alaye ipo ipo.Ayẹwo "next argument" le jẹ ero bi aṣetunṣe lori ariyanjiyan.
//! Ni igbakugba ti a ba rii olutọpa "next argument" kan, aṣetọju ilọsiwaju.Eyi nyorisi ihuwasi bii eleyi:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Olutọju inu lori ariyanjiyan ko ti ni ilọsiwaju nipasẹ akoko ti a rii `{}` akọkọ, nitorinaa o tẹ ariyanjiyan akọkọ.Lẹhinna de `{}` keji, aṣetunṣe ti ni ilọsiwaju siwaju si ariyanjiyan keji.
//! Ni pataki, awọn ipele ti o fun lorukọ ariyanjiyan ariyanjiyan wọn ko ni ipa lori awọn aye ti ko darukọ ariyanjiyan ni awọn ofin ti awọn alaye ipo.
//!
//! O nilo ọna kika ọna kika lati lo gbogbo awọn ariyanjiyan rẹ, bibẹkọ ti o jẹ aṣiṣe akoko ikojọ.O le tọka si ariyanjiyan kanna ju ẹẹkan ninu okun kika.
//!
//! ## Awọn ipilẹ ti a darukọ
//!
//! Rust funrararẹ ko ni irufẹ Python ti o jọra ti awọn ipilẹ ti a darukọ si iṣẹ kan, ṣugbọn macro [`format!`] jẹ itẹsiwaju sintasi ti o fun laaye lati lo awọn ipo ti a darukọ.
//! Awọn atokọ ti a darukọ ti wa ni atokọ ni opin atokọ ariyanjiyan ati pe o ni itumọ:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Fun apẹẹrẹ, awọn ifihan [`format!`] atẹle gbogbo wọn lo ariyanjiyan ti a npè ni:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Ko wulo lati fi awọn ipo ipo (awọn ti ko ni awọn orukọ) lẹhin awọn ariyanjiyan ti o ni awọn orukọ.Bii pẹlu awọn ipo ipo, ko wulo lati pese awọn ipilẹ ti a darukọ ti a ko lo nipasẹ okun kika.
//!
//! # Awọn Sisọ kika
//!
//! Gbogbo ariyanjiyan ti o jẹ kika ni a le yipada nipasẹ nọmba awọn ipilẹ kika (ti o baamu si `format_spec` ni [the syntax](#syntax)). Awọn ipele wọnyi ni ipa lori aṣoju ti okun ti ohun ti n ṣe kika.
//!
//! ## Width
//!
//! ```
//! // Gbogbo awọn wọnyi tẹjade "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Eyi jẹ paramita fun "minimum width" pe ọna kika yẹ ki o gba.
//! Ti okun iye ko kun fun ọpọlọpọ awọn ohun kikọ yii, lẹhinna fifẹ ti fill/alignment sọ tẹlẹ yoo lo lati gba aaye ti o nilo (wo isalẹ).
//!
//! Iye fun iwọn naa le tun pese bi [`usize`] ninu atokọ awọn ipele nipasẹ fifi `$` ifiweranṣẹ ranṣẹ, n tọka pe ariyanjiyan keji jẹ [`usize`] ti n ṣalaye iwọn naa.
//!
//! N tọka si ariyanjiyan pẹlu sisọtọ dola ko ni ipa lori kika "next argument", nitorinaa o jẹ igbagbogbo imọran lati tọka awọn ariyanjiyan nipasẹ ipo, tabi lo awọn ariyanjiyan ti a darukọ.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Ihuwasi kun aṣayan ati titete ni a pese ni deede ni apapo pẹlu paramita [`width`](#width).O gbọdọ ṣalaye ṣaaju `width`, ni kete lẹhin `:`.
//! Eyi tọka pe ti iye ti a ṣe kika ba kere ju `width` diẹ ninu awọn ohun kikọ afikun yoo tẹ ni ayika rẹ.
//! Kikun wa ninu awọn abawọn atẹle fun awọn titete oriṣiriṣi:
//!
//! * `[fill]<` - ariyanjiyan naa wa ni ibamu-osi ni awọn ọwọn `width`
//! * `[fill]^` - awọn ariyanjiyan ti wa ni aarin-deedee ni `width` ọwọn
//! * `[fill]>` - ariyanjiyan naa jẹ deede ni awọn ọwọn `width`
//!
//! [fill/alignment](#fillalignment) aiyipada fun awọn aisi-nọmba jẹ aaye kan ati tito-osi.Awọn aiyipada fun awọn apẹrẹ awọn nọmba tun jẹ ihuwasi aaye ṣugbọn pẹlu titọ-ọtun.
//! Ti asia `0` (wo isalẹ) ti wa ni pato fun awọn nọmba, lẹhinna ohun kikọ ti o kun fun aiṣe afọwọkọ ni `0`.
//!
//! Akiyesi pe titete le ma ṣe imuse nipasẹ diẹ ninu awọn oriṣi.Ni pataki, kii ṣe imuse gbogbogbo fun `Debug` trait.
//! Ọna ti o dara lati rii daju pe a lo fifẹ ni lati ṣe agbekalẹ igbewọle rẹ, lẹhinna paadi okun ti o ni abajade yii lati gba iṣejade rẹ:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Kaabo Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Iwọnyi jẹ gbogbo awọn asia ti n yi ihuwasi ti kika pada pada.
//!
//! * `+` - Eyi ti pinnu fun awọn oriṣi nọmba ati tọka pe ami yẹ ki o tẹjade nigbagbogbo.A ko tẹ awọn ami rere da si aiyipada, ati pe ami odi nikan ni a tẹjade nipasẹ aiyipada fun `Signed` trait.
//! Flag yii tọka pe ami to tọ (`+` tabi `-`) yẹ ki o tẹjade nigbagbogbo.
//! * `-` - Lọwọlọwọ ko lo
//! * `#` - Flag yii tọka pe o yẹ ki a lo fọọmu titẹ sita "alternate".Awọn fọọmu miiran ni:
//!     * `#?` - lẹwa-tẹ kika [`Debug`]
//!     * `#x` - ṣaju ariyanjiyan pẹlu `0x` kan
//!     * `#X` - ṣaju ariyanjiyan pẹlu `0x` kan
//!     * `#b` - ṣaju ariyanjiyan pẹlu `0b` kan
//!     * `#o` - ṣaju ariyanjiyan pẹlu `0o` kan
//! * `0` - Eyi ni a lo lati tọka fun awọn ọna kika odidi pe fifẹ si `width` yẹ ki o ṣee ṣe mejeeji pẹlu ohun kikọ `0` bakanna lati jẹ akiyesi-ami.
//! Ọna kika bii `{:08}` yoo fun `00000001` fun odidi `1`, lakoko ti ọna kika kanna yoo fun `-0000001` fun odidi `-1`.
//! Ṣe akiyesi pe ẹya odi ni o kere ju odo lọ ju ẹya ti o dara.
//!         Akiyesi pe awọn odo fifẹ ti wa ni igbagbogbo lẹhin ami (ti o ba jẹ eyikeyi) ati ṣaaju awọn nọmba.Nigbati a ba lo papọ pẹlu asia `#`, ofin ti o jọra kan: awọn odo fifẹ ni a fi sii lẹhin ìpele ṣugbọn ṣaaju awọn nọmba.
//!         Awọn prefix ti wa ninu lapapọ iwọn.
//!
//! ## Precision
//!
//! Fun awọn oriṣi ti kii ṣe nọmba, eyi ni a le ka si "maximum width".
//! Ti okun ti o ni abajade gun ju iwọn yii lọ, lẹhinna o ti ge si isalẹ si ọpọlọpọ awọn ohun kikọ yii ati pe iye truncated ti njade pẹlu `fill` to dara, `alignment` ati `width` ti o ba ṣeto awọn ipilẹ wọnyẹn.
//!
//! Fun awọn oriṣi idapọmọra, eyi ko foju.
//!
//! Fun awọn oriṣi aaye lilefoofo, eyi tọka iye awọn nọmba lẹhin ti aaye eleemewa yẹ ki o tẹjade.
//!
//! Awọn ọna mẹta ti o ṣee ṣe lati ṣalaye `precision` ti o fẹ:
//!
//! 1. Nọmba odidi `.N`:
//!
//!    odidi `N` funrararẹ ni konge.
//!
//! 2. Nọmba odidi kan tabi orukọ ti o tẹle pẹlu ami dola `.N$`:
//!
//!    lo ọna kika *ariyanjiyan*`N` (eyiti o gbọdọ jẹ `usize`) bi iṣiro.
//!
//! 3. Aami akiyesi `.*`:
//!
//!    `.*` tumọ si pe `{...}` yii ni nkan ṣe pẹlu awọn igbewọle ọna kika *meji* kuku ju ọkan: iṣagbewọle akọkọ mu deede `usize`, ati keji ni o ni iye lati tẹjade.
//!    Akiyesi pe ninu ọran yii, ti ẹnikan ba lo okun kika kika `{<arg>:<spec>.*}`, lẹhinna apakan `<arg>` tọka si* iye * lati tẹjade, ati pe `precision` gbọdọ wa ninu igbewọle ti tẹlẹ `<arg>`.
//!
//! Fun apẹẹrẹ, awọn ipe atẹle gbogbo tẹ nkan kanna `Hello x is 0.01000`:
//!
//! ```
//! // Hello {arg 0 ("x")} jẹ {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} jẹ {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} jẹ {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} jẹ {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} jẹ {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} jẹ {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Lakoko ti awọn wọnyi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! tẹ sita awọn ohun ti o yatọ si mẹta pataki:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Ni diẹ ninu awọn ede siseto, ihuwasi ti awọn iṣẹ ọna kika okun da lori eto agbegbe ti eto iṣẹ.
//! Awọn iṣẹ ọna kika ti a pese nipasẹ ile-ikawe boṣewa Rust ko ni imọran eyikeyi ti agbegbe ati pe yoo ṣe awọn abajade kanna lori gbogbo awọn ọna ṣiṣe laibikita iṣeto olumulo.
//!
//! Fun apẹẹrẹ, koodu atẹle yoo ma tẹjade `1.5` nigbagbogbo paapaa ti agbegbe agbegbe eto ba nlo ipinya eleemewa miiran ju aami kan lọ.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Awọn ohun kikọ gegebi `{` ati `}` le wa ninu okun nipa ṣiwaju wọn pẹlu iwa kanna.Fun apẹẹrẹ, ohun kikọ `{` sa asala pẹlu `{{` ati kikọ `}` sa asala pẹlu `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Lati ṣe akopọ, nibi o le wa ilo ọrọ kikun ti awọn okun kika.
//! Iṣeduro fun ede kika ti o lo ni a fa lati awọn ede miiran, nitorinaa ko yẹ ki o jẹ ajeji.Ariyanjiyan ti wa ni akoonu pẹlu Python-bi sintasi, afipamo pe ariyanjiyan ti wa ni ti yika nipasẹ `{}` dipo ti awọn C-bi `%`.
//! Awọn gangan èdè fun awọn akoonu rẹ sintasi ni:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Ninu ilo-ọrọ ti o wa loke, `text` le ma ni eyikeyi awọn ohun kikọ `'{'` tabi `'}'`.
//!
//! # Ṣiṣe kika traits
//!
//! Nigbati o ba beere pe ki a ṣe agbero ariyanjiyan pẹlu oriṣi kan pato, o n beere gangan pe ariyanjiyan kan sọ fun trait kan pato.
//! Eyi gba awọn oriṣi pupọ pupọ laaye lati ṣe kika nipasẹ `{:x}` (bii [`i8`] ati [`isize`]).Aworan agbaye ti isiyi si awọn iru si traits ni:
//!
//! * *ko si nkankan* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] pẹlu awọn odidi hexadecimal kekere-kekere
//! * `X?` ⇒ [`Debug`] pẹlu awọn odidi hexadecimal oke-nla
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Kini eyi tumọ si ni pe iru ariyanjiyan eyikeyi eyiti o ṣe imuse [`fmt::Binary`][`Binary`] trait le lẹhinna ṣe kika pẹlu `{:b}`.Awọn imuse ni a pese fun traits wọnyi fun nọmba awọn oriṣi atijo nipasẹ ile-ikawe boṣewa pẹlu.
//!
//! Ti ko ba ṣe apejuwe kika (bii `{}` tabi `{:6}`), lẹhinna ọna kika trait ti a lo ni [`Display`] trait.
//!
//! Nigbati o ba n ṣe agbekalẹ kika trait fun iru tirẹ, iwọ yoo ni lati ṣe ọna ti ibuwọlu naa:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // iru aṣa wa
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Iru rẹ yoo kọja bi `self` nipasẹ-itọkasi, lẹhinna iṣẹ yẹ ki o gbejade iṣelọpọ sinu ṣiṣan `f.buf`.O wa si ọna kika trait ọna kika kọọkan lati faramọ ni deede si awọn ọna kika kika ti a beere.
//! Awọn iye ti awọn iwọn wọnyi yoo wa ni atokọ ni awọn aaye ti ipilẹ [`Formatter`].Lati ṣe iranlọwọ pẹlu eyi, eto [`Formatter`] tun pese diẹ ninu awọn ọna iranlọwọ.
//!
//! Ni afikun, iye ipadabọ iṣẹ yii jẹ [`fmt::Result`] eyiti o jẹ inagijẹ iru ti [`Abajade`]`<(),`[`std: : fmt::Error`] `>`.
//! Awọn imuṣẹ kika kika yẹ ki o rii daju pe wọn ṣe ikede awọn aṣiṣe lati [`Formatter`] (fun apẹẹrẹ, nigba pipe [`write!`]).
//! Sibẹsibẹ, wọn ko gbọdọ da awọn aṣiṣe pada laiparu.
//! Iyẹn ni pe, imuṣẹ kika kika gbọdọ ati pe o le da aṣiṣe pada nikan ti [`Formatter`] ti o kọja ba da aṣiṣe kan pada.
//! Eyi jẹ nitori, ni ilodi si ohun ti ibuwọlu iṣẹ le daba, ọna kika okun jẹ iṣẹ ti ko ni aṣiṣe.
//! Iṣẹ yii nikan ni o da abajade nitori kikọ si ṣiṣan ṣiṣan le kuna ati pe o gbọdọ pese ọna lati ṣe itankale otitọ pe aṣiṣe ti ṣẹlẹ lati ṣe afẹyinti akopọ naa.
//!
//! Apẹẹrẹ ti imuṣe kika traits yoo dabi:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Iye `f` ṣe imuse `Write` trait, eyiti o jẹ ohun ti kikọ naa!macro n reti.
//!         // Akiyesi pe kika yii kọ awọn oriṣiriṣi awọn asia ti a pese si ọna kika awọn okun.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // O yatọ si traits gba awọn ọna oriṣiriṣi iṣejade ti iru kan.
//! // Itumọ ọna kika yii ni lati tẹ bii vector kan.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Fi ọwọ fun awọn asia kika nipa lilo ọna iranlọwọ oluranlọwọ `pad_integral` lori nkan Ọna kika.
//!         // Wo iwe ọna fun awọn alaye, ati pe iṣẹ `pad` le ṣee lo lati paadi awọn okun.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` la `fmt::Debug`
//!
//! Ọna kika meji wọnyi traits ni awọn idi ọtọtọ:
//!
//! - [`fmt::Display`][`Display`] awọn imuṣẹ fi idi rẹ mulẹ pe oriṣi le ni iduroṣinṣin ni aṣoju bi okun UTF-8 ni gbogbo igba.O jẹ **kii ṣe** o nireti pe gbogbo awọn oriṣiriṣi ṣe imuse [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] awọn imuse yẹ ki o wa ni imuse fun **gbogbo** awọn iru ilu.
//!   Ijade yoo ṣe aṣoju ipo ti inu bi iṣotitọ bi o ti ṣee.
//!   Idi ti [`Debug`] trait ni lati dẹrọ n ṣatunṣe aṣiṣe koodu Rust.Ni ọpọlọpọ awọn ọran, lilo `#[derive(Debug)]` jẹ to ati iṣeduro.
//!
//! Diẹ ninu awọn apẹẹrẹ ti iṣelọpọ lati traits mejeeji:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Jẹmọ macros
//!
//! Nọmba awọn macros ti o ni ibatan wa ninu idile [`format!`].Awọn ti a ṣe lọwọlọwọ ni:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Eyi ati [`writeln!`] jẹ awọn macros meji eyiti a lo lati firanṣẹ okun ọna kika si ṣiṣan pàtó kan.Eyi ni a lo lati yago fun awọn ipin agbedemeji ti awọn okun ọna kika ati dipo taara kọjade.
//! Labẹ ibode, iṣẹ yii n bẹbẹ pe iṣẹ [`write_fmt`] ti a ṣalaye lori [`std::io::Write`] trait.
//! Apẹẹrẹ lilo ni:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Eyi ati [`println!`] gbejade iṣelọpọ wọn si stdout.Bakan naa si macro [`write!`], ibi-afẹde ti awọn macro wọnyi ni lati yago fun awọn ipin agbedemeji nigba titẹjade.Apẹẹrẹ lilo ni:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Awọn macros [`eprint!`] ati [`eprintln!`] jẹ aami kanna si [`print!`] ati [`println!`], lẹsẹsẹ, ayafi ti wọn ba njadejadejade wọn si stderr.
//!
//! ### `format_args!`
//!
//! Eyi jẹ macro iyanilenu ti a lo lati kọja lailewu ni ayika ohun akomo ti o n ṣalaye okun ọna kika.Ohun yii ko nilo eyikeyi awọn ipin okiti lati ṣẹda, ati pe o tọka alaye nikan lori akopọ naa.
//! Labẹ ibori, gbogbo awọn macros ti o ni ibatan ni imuse ni awọn ofin ti eyi.
//! Ni akọkọ, diẹ ninu apẹẹrẹ lilo ni:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Abajade ti Makiro [`format_args!`] jẹ iye ti iru [`fmt::Arguments`].
//! Eto yii le ṣee kọja si awọn iṣẹ [`write`] ati [`format`] inu module yii lati le ṣe ilana okun kika.
//! Idi ti macro yii ni lati yago siwaju siwaju sii awọn ipin agbedemeji nigbati o ba n ba awọn ọna kika kika ṣe.
//!
//! Fun apẹẹrẹ, ile-ikawe ti n wọle le lo ọna kika kika bošewa, ṣugbọn yoo kọja inu inu eto yii titi ti o fi pinnu ibiti o ti yẹ ki o lọ si.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Iṣẹ `format` gba eto [`Arguments`] kan o si da okun kika kika pada.
///
///
/// Apeere [`Arguments`] le ṣẹda pẹlu macro [`format_args!`].
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Jọwọ ṣe akiyesi pe lilo [`format!`] le jẹ ayanfẹ.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}