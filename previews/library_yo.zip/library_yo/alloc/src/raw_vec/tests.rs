use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Kikọ idanwo ti isopọmọ laarin awọn olupilẹṣẹ ẹni-kẹta ati `RawVec` jẹ ẹtan kekere nitori `RawVec` API ko ṣe afihan awọn ọna ipin ipin ti o le kuna, nitorinaa a ko le ṣayẹwo ohun ti o ṣẹlẹ nigbati olupilẹṣẹ ba rẹwẹsi (kọja wiwa panic).
    //
    //
    // Dipo, eyi kan ṣayẹwo pe awọn ọna `RawVec` ṣe o kere ju lọ nipasẹ Allocator API nigbati o ba ni ipamọ.
    //
    //
    //
    //
    //

    // Olupin odi kan ti o jẹ iye epo ti o wa titi ṣaaju awọn igbiyanju ipin bẹrẹ ikuna.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (o fa realloc, nitorinaa ni lilo 50 + 150=Awọn ẹya idana 200)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Ni akọkọ, awọn ipin `reserve` bii `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 jẹ diẹ sii ju ilọpo meji ti 7, nitorinaa `reserve` yẹ ki o ṣiṣẹ bi `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 kere ju idaji 12 lọ, nitorinaa `reserve` gbọdọ dagba laipẹ.
        // Ni akoko kikọ kikọ ifosiwewe idagba idanwo yii jẹ 2, nitorinaa agbara tuntun jẹ 24, sibẹsibẹ, ifosiwewe dagba ti 1.5 tun dara.
        //
        // Nitorinaa `>= 18` ni idaniloju.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}