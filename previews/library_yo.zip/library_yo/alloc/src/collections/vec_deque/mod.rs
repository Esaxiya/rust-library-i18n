//! Iṣẹ isinyi ti o pari lẹẹme ti a ṣe pẹlu ifipamọ ohun orin dagba.
//!
//! Ikini yii ni awọn ifibọ amortized *O*(1) ati awọn iyọkuro lati opin mejeeji ti apoti.
//! O tun ni itọka *O*(1) bi vector kan.
//! A ko nilo awọn eroja ti o wa ninu lati jẹ ẹda, ati pe isinyi yoo jẹ fifiranṣẹ ti o ba jẹ pe iru ti o wa ninu naa ni a firanṣẹ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Agbara ti o tobi julo ti agbara meji

/// Iṣẹ isinyi ti o pari lẹẹme ti a ṣe pẹlu ifipamọ ohun orin dagba.
///
/// Lilo "default" ti iru yii bi isinyi ni lati lo [`push_back`] lati ṣafikun si isinyi, ati [`pop_front`] lati yọ kuro ni isinyi.
///
/// [`extend`] ati [`append`] titari sẹhin sẹhin ni ọna yii, ati sisẹ lori `VecDeque` lọ iwaju si ẹhin.
///
/// Niwọn igba ti `VecDeque` jẹ ifipamọ ohun orin, awọn eroja rẹ kii ṣe pataki ni iranti.
/// Ti o ba fẹ lati wọle si awọn eroja bi ẹyọ kan ṣoṣo, gẹgẹbi fun tito lẹsẹsẹ daradara, o le lo [`make_contiguous`].
/// O rotates awọn `VecDeque` ki awọn oniwe eroja ko ba fi ipari, ati ki o pada a mutable bibẹ si awọn bayi-contiguous ano ọkọọkan.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // iru ati ori jẹ awọn itọka sinu ifipamọ.
    // Iru nigbagbogbo tọka si nkan akọkọ ti o le ka, Ori nigbagbogbo tọka si ibiti o yẹ ki o kọ data.
    //
    // Ti iru==ori saarin ba ṣofo.Awọn ipari ti ringbuffer ti wa ni asọye bi aaye laarin awọn meji.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Ṣiṣẹ apanirun fun gbogbo awọn ohun kan ninu gige nigbati o ba lọ silẹ (deede tabi lakoko ṣiṣi silẹ).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // lo ju silẹ fun [T]
            ptr::drop_in_place(front);
        }
        // RawVec n kapa ipinfunni
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Ṣẹda ohun ṣofo `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Iwonba diẹ rọrun
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Iwonba diẹ rọrun
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Fun awọn iru iwọn odo, a wa nigbagbogbo ni agbara to pọ julọ
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Yipada ptr sinu ege kan
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Yipada ptr sinu gige gige kan
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Rare ohun ano jade lati saarin
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Kọ nkan kan sinu ipamọ, gbigbe si.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Pada `true` ti ifipamọ ba wa ni agbara ni kikun.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Pada atọka ninu ipilẹ saarin fun itọka eroja ti ọgbọn ti a fun.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Pada atọka ninu saarin ipilẹ fun fifun itọka eroja ọgbọn + afikun.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Pada atọka ninu saarin ipilẹ fun itọka eroja ti ọgbọn ti a fun, atunkọ.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Awọn ẹda Awọn ohun idiwọ ti iranti len ti pẹ lati src si dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Awọn ẹda Awọn ohun idiwọ ti iranti len ti pẹ lati src si dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Awọn ẹda Awọn bulọọki wiwu oyi ti iranti ti ya ni pipẹ lati src si opin.
    /// (abs(dst - src) + len) ko gbọdọ tobi ju cap() (O gbọdọ jẹ pupọ julọ agbegbe agbekọja lemọlemọfún laarin src ati opin).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src ko ni ipari, dst ko ni ipari
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst ṣaaju src, src ko ni ipari, dst murasilẹ
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ṣaaju dst, src ko ni ipari, dst murasilẹ
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ṣaaju src, src murasilẹ, dst ko ni ipari
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src ṣaaju dst, src murasilẹ, dst ko ni ipari
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst ṣaaju src, src murasilẹ, dst murasilẹ
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src ṣaaju dst, src murasilẹ, dst murasilẹ
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs ori ati iru awọn apakan ni ayika lati mu o daju pe a kan sọ di aye.
    /// Ailewu nitori o gbekele old_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Gbe apakan contiguous kuru ju ti ifipamọ ohun orin TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              Eshitisii [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Ṣẹda ohun ṣofo `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Ṣẹda `VecDeque` ti o ṣofo pẹlu aye fun o kere ju awọn eroja `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 nitori ringbuffer nigbagbogbo fi aye kan ṣofo
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Pese itọkasi si eroja ni itọka ti a fun.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Pese itọkasi iyipada si eroja ni itọka ti a fun.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Awọn eroja Swaps ni awọn atọka `i` ati `j`.
    ///
    /// `i` ati `j` le jẹ dogba.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ pe itọka meji ko ni opin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Pada nọmba awọn eroja ti `VecDeque` le mu laisi ipinfunni gidi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Ṣe ifipamo agbara to kere fun `additional` awọn eroja diẹ sii lati fi sii ninu `VecDeque` ti a fun.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa agbara ko le gbarale lati jẹ pọọku deede.
    /// Fẹ [`reserve`] ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Ifipamọ agbara fun o kere ju `additional` awọn eroja diẹ sii lati fi sii ninu `VecDeque` ti a fun.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Gbiyanju lati ṣura agbara to kere julọ fun gangan awọn eroja diẹ sii `additional` lati fi sii ninu `VecDeque<T>` ti a fun.
    ///
    /// Lẹhin pipe `try_reserve_exact`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa, a ko le gbarale agbara lati jẹ pọọku ni deede.
    /// Fẹ `reserve` ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Errors
    ///
    /// Ti agbara ba bori `usize`, tabi ipinfunni ṣe ijabọ ikuna, lẹhinna a da aṣiṣe kan pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM(Out-Of-Memory) ni aarin ti iṣẹ eka wa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // idiju pupọ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Gbiyanju lati ṣura agbara fun o kere ju `additional` awọn eroja diẹ sii lati fi sii ni `VecDeque<T>` ti a fun.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    /// Lẹhin pipe `try_reserve`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// # Errors
    ///
    /// Ti agbara ba bori `usize`, tabi ipinfunni ṣe ijabọ ikuna, lẹhinna a da aṣiṣe kan pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM ni agbedemeji iṣẹ eka wa
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // idiju pupọ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Isunki agbara ti `VecDeque` bi o ti ṣee ṣe.
    ///
    /// Yoo ṣubu silẹ bi o ti ṣee ṣe to ipari ṣugbọn ipin naa le tun sọ fun `VecDeque` pe aye wa fun awọn eroja diẹ diẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Fọ agbara ti `VecDeque` pẹlu adehun isalẹ.
    ///
    /// Agbara naa yoo wa ni o kere bi o tobi bi gigun ati iye ti a pese.
    ///
    ///
    /// Ti agbara lọwọlọwọ ba kere si opin isalẹ, eyi kii ṣe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // A ko ni lati ṣàníyàn nipa iṣan-omi bi `self.len()` tabi `self.capacity()` ko ṣe le jẹ `usize::MAX`.
        // +1 bi ringbuffer nigbagbogbo fi aye kan ṣofo.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Awọn ọran mẹta ni iwulo:
            //   Gbogbo awọn eroja ko si ni awọn aala ti o fẹ Awọn eroja ni o ni nkan, ati pe ori ko si awọn aala ti o fẹ Awọn eroja ko ni nkan, ati iru ko ni awọn aala ti o fẹ.
            //
            //
            // Ni gbogbo awọn akoko miiran, awọn ipo eroja ko ni fowo kan.
            //
            // Ṣe afihan pe awọn eroja ni ori yẹ ki o gbe.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Gbe awọn eroja kuro lati awọn aala ti o fẹ (awọn ipo lẹhin target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Ṣe kukuru `VecDeque`, titọju awọn eroja `len` akọkọ ati fifisilẹ iyoku.
    ///
    ///
    /// Ti `len` ba tobi ju gigun lọ lọwọlọwọ `VecDeque`, eyi ko ni ipa kankan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Ṣiṣẹ apanirun fun gbogbo awọn ohun kan ninu gige nigbati o ba lọ silẹ (deede tabi lakoko ṣiṣi silẹ).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Ailewu nitori:
        //
        // * Eyikeyi ege ti o kọja si `drop_in_place` wulo;ọran keji ni `len <= front.len()` ati ipadabọ lori `len > self.len()` ṣe idaniloju `begin <= back.len()` ni ọran akọkọ
        //
        // * Ti gbe ori VecDeque ṣaaju pipe `drop_in_place`, nitorinaa ko si iye silẹ lẹẹmeji ti `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Rii daju pe idaji keji ti lọ silẹ paapaa nigbati apanirun ni akọkọ panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Pada aṣetunṣe iwaju-si-ẹhin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Pada aṣetunṣe iwaju-si-ẹhin ti o pada awọn itọka iyipada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // Aabo: Awọn ti abẹnu `IterMut` ailewu ko baramu wa ni idasilẹ nitori awọn
        // `ring` a ṣẹda jẹ nkan ti a ti kọ silẹ fun igbesi aye '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Pada awọn ege meji eyiti o ni, ni aṣẹ, awọn akoonu ti `VecDeque`.
    ///
    /// Ti a ba pe [`make_contiguous`] tẹlẹ, gbogbo awọn eroja ti `VecDeque` yoo wa ni ege akọkọ ati bibẹ pẹlẹbẹ keji yoo ṣofo.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Pada awọn ege meji eyiti o ni, ni aṣẹ, awọn akoonu ti `VecDeque`.
    ///
    /// Ti a ba pe [`make_contiguous`] tẹlẹ, gbogbo awọn eroja ti `VecDeque` yoo wa ni ege akọkọ ati bibẹ pẹlẹbẹ keji yoo ṣofo.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Pada nọmba awọn eroja ninu `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Pada `true` ti `VecDeque` ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Ṣẹda aṣetunṣe ti o bo ibiti a ti sọ tẹlẹ ninu `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ ba tobi ju aaye ipari lọ tabi ti aaye ipari ba tobi ju ipari vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ibiti o wa ni kikun bo gbogbo awọn akoonu
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Itọkasi pipin ti a ni ninu &self jẹ itọju ni '_ ti Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Ṣẹda aṣetunṣe kan ti o ni wiwa ibiti o ti le yipada ni `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ ba tobi ju aaye ipari lọ tabi ti aaye ipari ba tobi ju ipari vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ibiti o wa ni kikun bo gbogbo awọn akoonu
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // Aabo: Awọn ti abẹnu `IterMut` ailewu ko baramu wa ni idasilẹ nitori awọn
        // `ring` a ṣẹda jẹ nkan ti a ti kọ silẹ fun igbesi aye '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Ṣẹda aṣetunṣe imugbẹ ti o yọ ibiti a ti sọ tẹlẹ ninu `VecDeque` ati mu awọn ohun ti a yọ kuro.
    ///
    /// Akiyesi 1: A ti yọ ibiti a ti yọ kuro paapaa ti a ko ba lo aṣetunṣe titi di opin.
    ///
    /// Akiyesi 2: O ti wa ni lalaïkomogba ti bi o ọpọlọpọ awọn eroja ti wa ni kuro lati deque, ti o ba ti `Drain` iye ti ko ba silẹ, ṣugbọn awọn wín, ti o Oun ni dopin (eg, nitori `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ ba tobi ju aaye ipari lọ tabi ti aaye ipari ba tobi ju ipari vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ibiti o wa ni kikun ko gbogbo awọn akoonu kuro
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Aabo iranti
        //
        // Nigbati a ṣẹda akọkọ Drain, a ti kuru dique orisun lati rii daju pe ko si aimọ tabi gbigbe-lati awọn eroja ti o wa ni wiwọle rara ti apanirun Drain ko ni ṣiṣe.
        //
        //
        // Drain yoo ptr::read jade ni iye lati yọ.
        // Nigbati o ba pari, data ti o ku yoo wa ni dakọ pada lati bo iho naa, ati pe awọn iye head/tail yoo pada sipo ni deede.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Awọn eroja deque ti pin si awọn ipele mẹta:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // A tọju drain_tail bi self.head, ati drain_head ati self.head bi after_tail ati lẹhin-head lẹsẹsẹ lori Drain.
        // Eyi tun ge ọna kika ti o munadoko bii pe ti Drain ba jo, a ti gbagbe nipa awọn iye ti o ṣee gbe lẹhin ibẹrẹ ti drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" nipa awọn iye lẹhin ibẹrẹ ti drain titi lẹhin ti drain ti pari ati pe apanirun Drain ti ṣiṣẹ.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ni pataki, a ṣẹda awọn itọkasi ti a pin nikan lati `self` nibi ati ka lati ọdọ rẹ.
                // A ko kọwe si `self` tabi tun pada si itọkasi itọkasi iyipada.
                // Nitorinaa ijuboluwo aise ti a ṣẹda loke, fun `deque`, wa ni deede.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Ko `VecDeque` kuro, yiyọ gbogbo awọn iye kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Pada `true` ti `VecDeque` ba ni eroja ti o dọgba pẹlu iye ti a fun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Pese itọkasi si eroja iwaju, tabi `None` ti `VecDeque` ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Pese itọkasi iyipada si eroja iwaju, tabi `None` ti `VecDeque` ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Pese itọkasi si eroja ẹhin, tabi `None` ti `VecDeque` ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Pese itọkasi iyipada si eroja ẹhin, tabi `None` ti `VecDeque` ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Yọ ano akọkọ ki o pada si, tabi `None` ti `VecDeque` ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Yọ nkan ti o kẹhin lati `VecDeque` ki o pada si, tabi `None` ti o ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Ṣetan nkan si `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Fi ohun ano si ẹhin `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Ṣe o yẹ ki a ṣe akiyesi `head == 0` lati tumọ si
        // pe `self` jẹ ifaramọ?
        self.tail <= self.head
    }

    /// Yọ ano kuro nibikibi ninu `VecDeque` ati da pada, rirọpo pẹlu eroja akọkọ.
    ///
    ///
    /// Eyi ko tọju aṣẹ, ṣugbọn jẹ *O*(1).
    ///
    /// Pada si `None` ti `index` ko ba ni opin.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Yọ ano kuro nibikibi ninu `VecDeque` ati da pada, rirọpo pẹlu eroja ti o kẹhin.
    ///
    ///
    /// Eyi ko tọju aṣẹ, ṣugbọn jẹ *O*(1).
    ///
    /// Pada si `None` ti `index` ko ba ni opin.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Awọn ifibọ ano ni `index` laarin `VecDeque`, yiyi gbogbo awọn eroja pẹlu awọn atọka ti o tobi ju tabi dogba si `index` si ẹhin.
    ///
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Panics
    ///
    /// Panics ti `index` ba tobi ju gigun VecDeque` lọ
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Gbe nọmba ti o kere julọ ti awọn eroja ninu ifipamọ oruka ati fi nkan ti a fun sii
        //
        // Ni pupọ julọ len/2, awọn eroja 1 yoo gbe. O(min(n, n-i))
        //
        // Awọn ọran akọkọ mẹta wa:
        //  Eroja ni o wa contiguous
        //      - ọran pataki nigbati iru jẹ 0 Awọn eroja ko ni nkan ati pe ohun ti a fi sii wa ni apakan iru Awọn eroja ko ni nkan ati pe ohun ti a fi sii wa ni apakan ori
        //
        //
        // Fun ọkọọkan ninu awọn ọran meji miiran wa:
        //  Ifibọ ti sunmọ jo iru Fi sii sunmọ ori
        //
        // Bọtini: H, self.head
        //      T, self.tail o, Ohun elo Wulo I, A fi sii A, Ano ti o yẹ ki o wa lẹhin aaye ifibọ M, Tọkasi eroja ti gbe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contiguous, fi sii sunmọ iru:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // contiguous, fi sii sunmọ iru ati iru ni 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       Mm

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Tẹlẹ gbe iru, nitorinaa a daakọ awọn eroja `index - 1` nikan.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, fi sii sunmọ ori:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, fi sii sunmọ iru, iru apakan:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, fi sii sunmọ ori, apakan iru:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // daakọ awọn eroja soke si ori tuntun
                    self.copy(1, 0, self.head);

                    // daakọ ano ikẹhin sinu iranran ofo ni isalẹ ti ifipamọ
                    self.copy(0, self.cap() - 1, 1);

                    // gbe awọn eroja lati idx lati pari siwaju ko pẹlu ^ eroja
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, ifibọ jẹ isunmọ si iru, apakan ori, ati pe o wa ni itọka odo ninu ifipamọ inu:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // daakọ awọn eroja soke si iru tuntun
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // daakọ ano ikẹhin sinu iranran ofo ni isalẹ ti ifipamọ
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, fi sii sunmọ iru, apakan ori:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // daakọ awọn eroja soke si iru tuntun
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // daakọ ano ikẹhin sinu iranran ofo ni isalẹ ti ifipamọ
                    self.copy(self.cap() - 1, 0, 1);

                    // gbe awọn eroja lati idx-1 lati pari siwaju kii ṣe pẹlu eroja
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, fi sii sunmọ ori, apakan ori:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // iru le ti yipada nitorinaa a nilo lati tun iṣiro
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Yọ kuro o pada si nkan ni `index` lati `VecDeque`.
    /// Eyikeyi opin ti o sunmọ aaye iyọkuro yoo ṣee gbe lati ṣe yara, ati pe gbogbo awọn eroja ti o kan yoo ṣee gbe si awọn ipo tuntun.
    ///
    /// Pada si `None` ti `index` ko ba ni opin.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Awọn ọran akọkọ mẹta wa:
        //  Awọn eroja jẹ ṣiropọ Awọn eroja jẹ discontiguous ati yiyọ kuro ni apakan iru Awọn eroja ko ni nkan ati yiyọ kuro ni apakan ori
        //
        //      - ọran pataki nigbati awọn eroja jẹ ilopọ imọ-ẹrọ, ṣugbọn self.head =0
        //
        // Fun ọkọọkan ninu awọn ọran meji miiran wa:
        //  Ifibọ ti sunmọ jo iru Fi sii sunmọ ori
        //
        // Bọtini: H, self.head
        //      T, self.tail o, Wulo ano x, Ano samisi fun yiyọ R, Tọkasi eroja ti n yọkuro M, Ntọka eroja ti gbe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // contiguous, yọ sunmọ jo:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // contiguous, yọ sunmọ ori:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, yọ jo si iru, apakan iru:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, yọ jo si ori, apakan ori:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, yọ jo si ori, apakan iru:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // tabi disasi-discontiguous, yọ lẹgbẹẹ ori, apakan iru:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // fa ninu awọn eroja ni apakan iru
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Awọn idilọwọ iṣan-omi.
                    if self.head != 0 {
                        // daakọ akọkọ nkan si aaye ti o ṣofo
                        self.copy(self.cap() - 1, 0, 1);

                        // gbe awọn eroja ni apakan ori sẹhin
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, yọ jo si iru, apakan apakan:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // fa awọn eroja soke si idx
                    self.copy(1, 0, idx);

                    // daakọ ano ikẹhin sinu iranran ofo
                    self.copy(0, self.cap() - 1, 1);

                    // gbe awọn eroja lati iru lati pari siwaju, laisi ọkan ti o kẹhin
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Pin `VecDeque` si meji ni itọka ti a fun.
    ///
    /// Pada `VecDeque` tuntun ti a pin.
    /// `self` ni awọn eroja `[0, at)`, ati pe `VecDeque` ti o pada wa ninu awọn eroja `[at, len)`.
    ///
    /// Ṣe akiyesi pe agbara ti `self` ko yipada.
    ///
    /// Ano ni itọka 0 ni iwaju ti isinyi.
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` wa ni idaji akọkọ.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // kan gba gbogbo idaji keji.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` wa ni idaji keji, nilo lati ṣe ifosiwewe ninu awọn eroja ti a fo ni idaji akọkọ.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Afọmọ ibi ti awọn opin ti awọn ifipamọ wa
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Gbe gbogbo awọn eroja ti `other` sinu `self`, fifi `other` silẹ ofo.
    ///
    /// # Panics
    ///
    /// Panics ti nọmba tuntun ti awọn eroja ninu ara ẹni ba bori `usize` kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // iwuri impl
        self.extend(other.drain(..));
    }

    /// Ṣe idaduro awọn eroja ti a ṣalaye nipasẹ asọtẹlẹ tẹlẹ nikan.
    ///
    /// Ni awọn ọrọ miiran, yọ gbogbo awọn eroja `e` kuro bii `f(&e)` ṣe pada asan.
    /// Ọna yii n ṣiṣẹ ni aye, ṣe abẹwo si eroja kọọkan ni ẹẹkan ni aṣẹ atilẹba, ati tọju aṣẹ ti awọn eroja idaduro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Ibere deede le wulo fun titele ipo ita, bii itọka kan.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Eyi le panic tabi yọ
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Ilọpo iwọn meji.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Ṣe atunṣe `VecDeque` ni ibi ki `len()` ba dọgba si `new_len`, boya nipa yiyọ awọn eroja ti o pọ ju lati ẹhin tabi nipa fifi awọn eroja sii ti ipilẹṣẹ nipasẹ pipe `generator` si ẹhin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Ṣe atunto ibi ipamọ inu ti ofin yii nitorina o jẹ bibẹ pẹlẹbẹ kan, eyiti a da pada.
    ///
    /// Ọna yii ko ṣe ipin ati pe ko yipada aṣẹ ti awọn eroja ti a fi sii.Bi o ṣe n da nkan gige ti o le yipada pada, eyi le ṣee lo lati to lẹsẹsẹ ni ofin kan.
    ///
    /// Lọgan ti ibi ipamọ inu jẹ ṣiṣọn, awọn ọna [`as_slices`] ati [`as_mut_slices`] yoo da gbogbo awọn akoonu ti `VecDeque` pada ni ẹyọ kan.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Lẹsẹẹsẹ awọn akoonu ti a deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ayokuro awọn deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ayokuro rẹ ni aṣẹ yiyipada
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Wiwọle ailopin si bibẹ pẹlẹbẹ naa.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // a le rii daju bayi pe `slice` ni gbogbo awọn eroja ti aṣa, lakoko ti o ni iraye si aiyipada si `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // aaye ọfẹ wa to lati daakọ iru ni igba kan, eyi tumọ si pe a kọkọ yi ori pada sẹhin, lẹhinna daakọ iru si ipo to tọ.
            //
            //
            // lati: DEFGH .... ABC
            // si: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Lọwọlọwọ a ko ronu .... ABCDEFGH
            // lati jẹ ifaramọ nitori `head` yoo jẹ `0` ninu ọran yii.
            // Lakoko ti o ṣee ṣe ki a fẹ yipada eyi kii ṣe pataki bi awọn aaye diẹ ti n reti `is_contiguous` lati tumọ si pe a le ge ni lilo `buf[tail..head]`.
            //
            //

            // aaye ọfẹ wa ti to lati daakọ ori ni ẹẹkan, eyi tumọ si pe a kọkọ yi iru si siwaju, lẹhinna daakọ ori si ipo to tọ.
            //
            //
            // lati: FGH .... ABCDE
            // si: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ọfẹ jẹ kere ju ori ati iru lọ, eyi tumọ si pe a ni laiyara "swap" iru ati ori.
            //
            //
            // lati: EFGHI ... ABCD tabi HIJK.ABCDEFG
            // si: ABCDEFGHI ... tabi ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Iṣoro gbogbogbo dabi GHIJKLM yii ... ABCDEF, ṣaaju eyikeyi swaps ABCDEFM ... GHIJKL, lẹhin igbasẹ 1 ti awọn swaps ABCDEFGHIJM ... KL, swap titi di apa osi edge de ile itaja afẹfẹ
                //                  - lẹhinna tun bẹrẹ alugoridimu pẹlu ile itaja (smaller) tuntun Nigbakanna a ti de ile itaja afẹfẹ nigba ti edge ọtun wa ni opin ifipamọ, eyi tumọ si pe a ti lu aṣẹ ti o tọ pẹlu awọn swaps diẹ!
                //
                // E.g
                // EF..ABCD ABCDEF .., lẹhin awọn swaps mẹrin mẹrin ti a ti pari
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// N yi awọn ibi ila `mid` ti o pari lẹẹkeji si apa osi.
    ///
    /// Equivalently,
    /// - N yi ohun kan `mid` sinu ipo akọkọ.
    /// - Pipi awọn ohun `mid` akọkọ ati titari wọn si opin.
    /// - N yi awọn aaye `len() - mid` si apa ọtun.
    ///
    /// # Panics
    ///
    /// Ti `mid` tobi ju `len()` lọ.
    /// Akiyesi pe `mid == len()` ṣe _not_ panic ati pe o jẹ iyipo ti kii-op.
    ///
    /// # Complexity
    ///
    /// Gba akoko `*O*(min(mid, len() - mid))` ati pe ko si aaye afikun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// N yi awọn ibi ila `k` ti o pari lẹẹmeji si apa ọtun.
    ///
    /// Equivalently,
    /// - N yi ohun akọkọ pada si ipo `k`.
    /// - Pops awọn ohun elo `k` kẹhin ati titari wọn si iwaju.
    /// - N yi awọn aaye `len() - k` si apa osi.
    ///
    /// # Panics
    ///
    /// Ti `k` tobi ju `len()` lọ.
    /// Akiyesi pe `k == len()` ṣe _not_ panic ati pe o jẹ iyipo ti kii-op.
    ///
    /// # Complexity
    ///
    /// Gba akoko `*O*(min(k, len() - k))` ati pe ko si aaye afikun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // Aabo: awọn ọna meji wọnyi nbeere pe iye iyipo
    // jẹ kere ju idaji gigun ti aṣa.
    //
    // `wrap_copy` nilo `min(x, cap() - x) + copy_len <= cap()`, ṣugbọn ju `min` ko ju idaji agbara lọ, laibikita x, nitorinaa o dun lati pe nihin nitori a n pe pẹlu nkan ti o kere ju idaji gigun lọ, eyiti ko ga ju idaji agbara lọ.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Alakomeji wa `VecDeque` lẹsẹsẹ yii fun nkan ti a fun.
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.
    /// Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    ///
    /// # Examples
    ///
    /// Nwa soke kan lẹsẹsẹ ti mẹrin eroja.
    /// Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Ti o ba fẹ fi ohun kan sii si `VecDeque` ti a ṣe lẹsẹsẹ, lakoko ti o n ṣetọju aṣẹ lẹsẹsẹ:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Alakomeji wa `VecDeque` ti a ṣe lẹsẹsẹ pẹlu iṣẹ afiwe kan.
    ///
    /// Iṣẹ iṣapẹẹrẹ yẹ ki o ṣe aṣẹ ti o ni ibamu pẹlu irufẹ iru ti `VecDeque` ipilẹ, dapada koodu aṣẹ ti o tọka boya ariyanjiyan rẹ jẹ `Less`, `Equal` tabi `Greater` ju afojusun ti o fẹ lọ.
    ///
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    /// # Examples
    ///
    /// Nwa soke kan lẹsẹsẹ ti mẹrin eroja.Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Alakomeji wa `VecDeque` lẹsẹsẹ pẹlu iṣẹ yiyọ bọtini.
    ///
    /// Ṣebi pe `VecDeque` ti wa ni tito lẹsẹsẹ nipasẹ bọtini, fun apẹẹrẹ pẹlu [`make_contiguous().sort_by_key()`](#method.make_contiguous) lilo iṣẹ isediwon bọtini kanna.
    ///
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.
    /// Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    /// # Examples
    ///
    /// Wulẹ lẹsẹsẹ awọn eroja mẹrin ninu ege ege meji ti a to lẹsẹsẹ nipasẹ awọn eroja keji wọn.
    /// Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Ṣe atunṣe `VecDeque` ni ibi ki `len()` jẹ dọgba si new_len, boya nipa yiyọ awọn eroja ti o pọ julọ lati ẹhin tabi nipa fifi awọn ere ibeji ti `value` si ẹhin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Pada atọka ninu ipilẹ saarin fun itọka eroja ti ọgbọn ti a fun.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // iwọn nigbagbogbo jẹ agbara ti 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Ṣe iṣiro nọmba ti awọn eroja ti o kù lati ka ninu ifipamọ naa
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // iwọn nigbagbogbo jẹ agbara ti 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Pin nigbagbogbo ni awọn apakan mẹta, fun apẹẹrẹ: ara: [a b c|d e f] omiiran: [0 1 2 3|4 5] iwaju=3, aarin=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Ko ṣee ṣe lati lo Hash::hash_slice lori awọn ege ti a da pada nipasẹ ọna as_slices nitori gigun wọn le yato ni bibẹẹkọ awọn ami-ami kanna.
        //
        //
        // Hasher ṣe onigbọwọ nikan ni deede fun ṣeto kanna ti awọn ipe si awọn ọna rẹ.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Gba `VecDeque` sinu aṣetunṣe iwaju-si-ẹhin ti n fun awọn eroja ni iye.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Iṣẹ yii yẹ ki o jẹ deede ti iwa ti:
        //
        //      fun ohun kan ninu iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Tan [`Vec<T>`] sinu [`VecDeque<T>`] kan.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Eyi yago fun tito ipinlẹ nibiti o ti ṣee ṣe, ṣugbọn awọn ipo fun iyẹn muna, ati labẹ iyipada, ati nitorinaa ko yẹ ki o gbẹkẹle ayafi ti `Vec<T>` ba wa lati `From<VecDeque<T>>` ati pe ko ti tun gbe.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Ko si ipin gidi fun awọn ZST lati ṣe aniyan nipa agbara, ṣugbọn `VecDeque` ko le mu ipari gigun bi `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // A nilo lati tun iwọn ti agbara ko ba jẹ agbara ti meji, ti o kere ju tabi ko ni o kere ju aaye ọfẹ kan lọ.
            // A ṣe eyi lakoko ti o wa ninu `Vec` nitorinaa awọn ohun naa yoo ju silẹ lori panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Tan [`VecDeque<T>`] sinu [`Vec<T>`] kan.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Eyi ko nilo lati tun ṣe ipin-ipin, ṣugbọn o nilo lati ṣe iwọle data *O*(*n*) ti ifipin ipin naa ko ba wa ni ibẹrẹ ipin naa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Eyi ni *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Eyi nilo atunto data.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}