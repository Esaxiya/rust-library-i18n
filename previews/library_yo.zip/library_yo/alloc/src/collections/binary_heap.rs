//! Ti isinyi ayo ti a ṣe pẹlu okiti alakomeji.
//!
//! Fifi sii ati yiyo eroja ti o tobi julọ ni idiju akoko *O*(log(*n*)).
//! Ṣiṣayẹwo ano ti o tobi julọ ni *O*(1).Yiyipada vector si okiti alakomeji le ṣee ṣe ni aye, ati pe o ni idiwọn *O*(*n*).
//! O le jẹ ki okiti alakomeji kan yipada si vector ti o wa ni ipo, gbigba laaye lati ṣee lo fun *O*(*n*\*log(* n*)) ibi-akọọlẹ ipo-ibi.
//!
//! # Examples
//!
//! Eyi jẹ apẹẹrẹ ti o tobi julọ ti o ṣe awọn [Dijkstra's algorithm][dijkstra] lati yanju [shortest path problem][sssp] lori [directed graph][dir_graph] kan.
//!
//! O fihan bi a ṣe le lo [`BinaryHeap`] pẹlu awọn oriṣi aṣa.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Ti isinyi ayo da lori `Ord`.
//! // Ṣe imuse ni imuse ni trait nitorinaa isinyi di kikoro min dipo okiti-okiti kan.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Ṣe akiyesi pe a yi isipade paṣẹ lori awọn idiyele.
//!         // Ni ọran ti tai a ṣe afiwe awọn ipo, igbesẹ yii jẹ pataki lati ṣe awọn imuse ti `PartialEq` ati `Ord` ni ibamu.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` nilo lati ṣe imuse daradara.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ipele kọọkan jẹ aṣoju bi `usize`, fun imuse kuru.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra ọna ọna kuru ju algorithm.
//!
//! // Bẹrẹ ni `start` ki o lo `dist` lati tọpinpin aaye to kuru ju lọwọlọwọ si oju ipade kọọkan.Imuse yii kii ṣe daradara-iranti bi o ṣe le fi awọn apa ẹda meji silẹ ninu isinyi.
//! //
//! // O tun nlo `usize::MAX` bi iye sentinel, fun imuse ti o rọrun.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=ijinna to kuru ju lọwọlọwọ lati `start` si `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // A wa ni `start`, pẹlu idiyele odo kan
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Ṣe ayẹwo aala pẹlu awọn apa iye owo kekere (min-heap) akọkọ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Ni omiiran a le ti tẹsiwaju lati wa gbogbo awọn ọna to kuru ju
//!         if position == goal { return Some(cost); }
//!
//!         // Pataki bi a ṣe le ti rii ọna ti o dara julọ
//!         if cost > dist[position] { continue; }
//!
//!         // Fun oju ipade kọọkan ti a le de ọdọ, rii boya a le wa ọna kan pẹlu idiyele kekere ti o kọja nipasẹ oju ipade yii
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Ti o ba bẹ bẹ, ṣafikun si aala naa ki o tẹsiwaju
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Isinmi, a ti wa ọna ti o dara julọ bayi
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Afojusun ko le de ọdọ
//!     None
//! }
//!
//! fn main() {
//!     // Eyi ni aworan atokọ ti a yoo lo.
//!     // Awọn nọmba ipade naa baamu si awọn ipinlẹ oriṣiriṣi, ati awọn iwuwo edge ṣe afihan iye owo gbigbe lati oju ipade kan si ekeji.
//!     //
//!     // Akiyesi pe awọn egbegbe jẹ ọna kan.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Awọnya ti wa ni ipoduduro bi atokọ adjacency nibiti atọka kọọkan, ti o baamu si iye ipade, ni atokọ ti awọn egbegbe ti njade.
//!     // Ti yan fun ṣiṣe rẹ.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Ti isinyi ayo ti a ṣe pẹlu okiti alakomeji.
///
/// Eyi yoo jẹ okiti-okiti kan.
///
/// O jẹ aṣiṣe ọgbọn fun ohun kan lati tunṣe ni ọna ti aṣẹ aṣẹ nkan naa ni ibatan si eyikeyi ohun miiran, gẹgẹbi ipinnu nipasẹ `Ord` trait, yipada lakoko ti o wa ni okiti.
///
/// Eyi jẹ deede ṣee ṣe nikan nipasẹ `Cell`, `RefCell`, ipinle agbaye, I/O, tabi koodu ti ko ni aabo.
/// Ihuwasi ti o jẹ iru aṣiṣe aṣiṣe bẹ ko ṣe apejuwe, ṣugbọn kii yoo ni ihuwasi ihuwasi ti a ko ṣalaye.
/// Eyi le pẹlu panics, awọn abajade ti ko tọ, awọn abort, jo n jo, ati ailopin.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Iru ifunni jẹ ki a fi silẹ iru ibuwọlu ti o fojuhan (eyiti yoo jẹ `BinaryHeap<i32>` ni apẹẹrẹ yii).
/////
/// let mut heap = BinaryHeap::new();
///
/// // A le lo yoju lati wo nkan ti o tele ninu okiti.
/// // Ni ọran yii, ko si awọn ohun kan sibẹ sibẹ nitorinaa a ko ri Nkan.
/// assert_eq!(heap.peek(), None);
///
/// // Jẹ ki a ṣafikun diẹ ninu awọn ikun ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Bayi yoju fihan ohun pataki julọ ninu okiti.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // A le ṣayẹwo gigun ti okiti kan.
/// assert_eq!(heap.len(), 3);
///
/// // A le ṣe itita lori awọn ohun kan ninu okiti, botilẹjẹpe wọn pada ni aṣẹ laileto.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Ti a ba dipo agbejade awọn ikun wọnyi, wọn yẹ ki o pada wa ni tito.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // A le nu okiti eyikeyi awọn ohun ti o ku silẹ.
/// heap.clear();
///
/// // Kiti yẹ ki o di ofo ni bayi.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Boya `std::cmp::Reverse` tabi imuse `Ord` aṣa le ṣee lo lati ṣe `BinaryHeap` min-okiti.
/// Eyi jẹ ki `heap.pop()` pada iye ti o kere ju dipo ti o tobi julọ.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Fi ipari awọn iye ni `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Ti a ba ṣe agbejade awọn ikun wọnyi bayi, wọn yẹ ki o pada wa ni aṣẹ yiyipada.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Igbaju akoko
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Iye fun `push` jẹ idiyele ti a reti;iwe ilana ọna fun onínọmbà alaye diẹ sii.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Igbekale murasilẹ itọkasi iyipada si nkan nla julọ lori `BinaryHeap` kan.
///
///
/// `struct` yii ni a ṣẹda nipasẹ ọna [`peek_mut`] lori [`BinaryHeap`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // Aabo: PeekMut ti wa ni idasilẹ nikan fun awọn okiti ti ko ni ofo.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut ti wa ni idasilẹ nikan fun awọn okiti ti ko ni ofo
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut ti wa ni idasilẹ nikan fun awọn okiti ti ko ni ofo
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Yọ iye yoju kuro ninu okiti o si da pada.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Ṣẹda ohun ṣofo `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Ṣẹda `BinaryHeap` ti o ṣofo bi okiti-nla.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Ṣẹda `BinaryHeap` ti o ṣofo pẹlu agbara kan pato.
    /// Eyi preallocates iranti ti o to fun awọn eroja `capacity`, nitorinaa `BinaryHeap` ko ni lati wa ni tunto titi ti o ni o kere ju ọpọlọpọ awọn iye lọ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Pada tọka iyipada kan si ohun nla julọ ninu okiti alakomeji, tabi `None` ti o ba ṣofo.
    ///
    /// Note: Ti iye `PeekMut` ba ti jo, okiti le wa ni ipo aisedede.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Igbaju akoko
    ///
    /// Ti nkan naa ba yipada lẹhinna idibajẹ akoko ọran ti o buru julọ ni *O*(log(*n*)), bibẹkọ ti o jẹ *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Yọ nkan nla julọ kuro ninu okiti alakomeji ati da pada, tabi `None` ti o ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Igbaju akoko
    ///
    /// Iye owo ọran ti o buru julọ ti `pop` lori okiti kan ti o ni awọn eroja *n* jẹ *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // Aabo: !self.is_empty() tumọ si pe self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Titari ohun kan sori okiti alakomeji.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Igbaju akoko
    ///
    /// Iye owo ti a ti nireti ti `push`, ni apapọ lori gbogbo aṣẹ ti o le ṣee ṣe ti awọn eroja ti n ti, ati lori nọmba ti o tobi to ti awọn titari, jẹ *O*(1).
    ///
    /// Eyi ni metric iye owo ti o ni itumọ julọ nigbati o ba n fa awọn eroja ti ko jẹ * tẹlẹ ni eyikeyi apẹẹrẹ lẹsẹsẹ.
    ///
    /// Isoro akoko naa bajẹ ti awọn eroja ba wa ni tito ni aṣẹ ti o ga julọ.
    /// Ninu ọran ti o buru julọ, awọn eroja ti wa ni tito lẹsẹsẹ ti o gòke ati idiyele amortized fun titari jẹ *O*(log(*n*)) lodi si okiti ti o ni awọn eroja *n*.
    ///
    /// Iye owo ọran ti o buru julọ ti *ẹyọkan* ipe si `push` ni *O*(*n*).Ọran ti o buru julọ waye nigbati agbara ba rẹ ati nilo iwọn.
    /// Iwọn iye iwọn ti ni atunṣe ni awọn nọmba iṣaaju.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // Aabo: Niwọn igba ti a ti ta ohunkan tuntun o tumọ si pe
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Gba `BinaryHeap` ati da pada vector ni tito lẹsẹsẹ (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // Aabo: `end` lọ lati `self.len() - 1` si 1 (mejeeji wa pẹlu),
            //  nitorinaa o jẹ atokọ to wulo nigbagbogbo lati wọle si.
            //  O jẹ ailewu lati wọle si itọka 0 (ie `ptr`), nitori
            //  1 <=ipari <self.len(), eyiti o tumọ si self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // Aabo: `end` lọ lati `self.len() - 1` si 1 (mejeeji wa pẹlu) nitorinaa:
            //  0 <1 <=ipari <= self.len(), 1 <self.len() Eyi ti o tumọ si 0 <ipari ati ipari <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Awọn imuse ti sift_up ati sift_down lo awọn bulọọki ti ko ni aabo lati le gbe nkan kuro ninu vector (fifi iho silẹ), yipada pẹlu awọn miiran ki o gbe nkan ti a yọ kuro pada si vector ni ipo ipari ti iho naa.
    //
    // A lo iru `Hole` lati ṣe aṣoju eyi, ati rii daju pe iho ti kun pada ni opin aaye rẹ, paapaa lori panic.
    // Lilo iho dinku ifosiwewe igbagbogbo ni akawe si lilo awọn swaps, eyiti o ni ilọpo meji bi ọpọlọpọ awọn gbigbe.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Olupe gbọdọ rii daju pe `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Mu iye ni `pos` jade ki o ṣẹda iho kan.
        // Aabo: Awọn onigbọwọ onigbọwọ pe pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // Aabo: hole.pos()> bẹrẹ>=0, eyiti o tumọ si hole.pos()> 0
            //  ati nitorinaa hole.pos(), 1 ko le ṣan silẹ.
            //  Eyi ṣe onigbọwọ pe obi naa <hole.pos() nitorinaa o jẹ itọka ti o wulo ati tun!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // Aabo: Kanna bi loke
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Mu ano ni `pos` ki o gbe e lulẹ okiti, lakoko ti awọn ọmọ rẹ tobi.
    ///
    ///
    /// # Safety
    ///
    /// Olupe gbọdọ rii daju pe `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // Aabo: Awọn onigbọwọ onigbọwọ pe pos <ipari <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop ailopin: ọmọ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // afiwe pẹlu ti o tobi julọ ninu awọn ọmọde meji Aabo: ọmọ <ipari, 1 <self.len() ati ọmọde + 1 <ipari <= self.len(), nitorinaa wọn jẹ awọn atọka to wulo.
            //
            //  ọmọ==2 *hole.pos() + 1!= hole.pos() ati ọmọ + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 tabi 2* hole.pos() + 2 le ṣan ti T jẹ ZST kan
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ti a ba ti wa tẹlẹ, da duro.
            // Aabo: ọmọde ti wa ni bayi boya ọmọ atijọ tabi ọmọ arugbo + 1
            //  A ti ṣafihan tẹlẹ pe awọn mejeeji jẹ <self.len() ati!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // Aabo: kanna bi loke.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // Aabo: &&Circuit kukuru, eyiti o tumọ si pe ninu
        //  majemu keji o ti jẹ otitọ pe ọmọ naa==ipari, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // Aabo: ọmọ ti fihan tẹlẹ lati jẹ atọka ti o wulo ati
            //  ọmọ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Olupe gbọdọ rii daju pe `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // Aabo: pos <len jẹ onigbọwọ nipasẹ olupe ati
        //  o han ni len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Mu eroja ni `pos` ki o gbe e ni gbogbo ọna isalẹ okiti, lẹhinna yọọ si ipo rẹ.
    ///
    ///
    /// Note: Eyi yarayara nigbati a mọ pe eroja tobi/yẹ ki o sunmọ si isalẹ.
    ///
    /// # Safety
    ///
    /// Olupe gbọdọ rii daju pe `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // Aabo: Awọn onigbọwọ onigbọwọ pe pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop ailopin: ọmọ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // Aabo: ọmọ <ipari, 1 <self.len() ati
            //  ọmọ + 1 <ipari <= self.len(), nitorinaa wọn jẹ awọn atọka to wulo.
            //  ọmọ==2 *hole.pos() + 1!= hole.pos() ati ọmọ + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 tabi 2* hole.pos() + 2 le ṣan ti T jẹ ZST kan
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // Aabo: Kanna bi loke
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // Aabo: ọmọ=ipari, 1 <self.len(), nitorinaa itọka ti o wulo
            //  ati ọmọ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // Aabo: pos ni ipo ninu iho o ti fihan tẹlẹ
        //  lati jẹ atokọ to wulo.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // Aabo: n bẹrẹ lati self.len()/2 o sọkalẹ si 0.
            //  Ọran kan nigbati! (N <self.len()) jẹ ti self.len() ==0, ṣugbọn o ti ṣakoso nipasẹ ipo lupu.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Gbe gbogbo awọn eroja ti `other` sinu `self`, fifi `other` silẹ ofo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` mu awọn iṣẹ O(len1 + len2) ati nipa awọn afiwe 2 *(len1 + len2) ninu ọran ti o buru julọ lakoko ti `extend` gba awọn iṣẹ O(len2* log(len1)) ati nipa awọn afiwe 1 *len2* log_2(len1) ninu ọran ti o buru julọ, ti o gba len1>= len2.
        // Fun awọn okiti nla, aaye adakoja ko tẹle ero yii mọ o ti pinnu ni agbara.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Pada aṣetunṣe eyiti o gba awọn eroja pada ni aṣẹpojo.
    /// Awọn eroja ti a gba pada ti yọ kuro lati okiti atilẹba.
    /// Awọn eroja to ku yoo yọ kuro ni isubu ninu aṣẹ okiti.
    ///
    /// Note:
    /// * `.drain_sorted()` jẹ *O*(*n*\*log(* n*)); o lọra pupọ ju `.drain()` lọ.
    ///   O yẹ ki o lo igbehin fun ọpọlọpọ awọn ọran.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // yọ gbogbo awọn eroja kuro ni aṣẹpo
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Ṣe idaduro awọn eroja ti a ṣalaye nipasẹ asọtẹlẹ tẹlẹ nikan.
    ///
    /// Ni awọn ọrọ miiran, yọ gbogbo awọn eroja `e` kuro bii `f(&e)` pada `false`.
    /// Awọn abuda ti wa ni ibẹwo ni aṣẹ ti a ko sọ (ati ti a ko sọ tẹlẹ).
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // nikan pa ani awọn nọmba
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Pada aṣetunṣe kan ti o ṣabẹwo si gbogbo awọn iye ni ipilẹ vector, ni aṣẹ lainidii.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Tẹjade 1, 2, 3, 4 ni aṣẹ lainidii
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Pada aṣetunṣe eyiti o gba awọn eroja pada ni aṣẹpojo.
    /// Ọna yii jẹ okiti atilẹba.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Pada ohun ti o tobi julọ ninu okiti alakomeji, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Igbaju akoko
    ///
    /// Iye owo jẹ *O*(1) ninu ọran ti o buru julọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Pada nọmba awọn eroja ti okiti alakomeji le mu laisi ipinpin.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Ṣe ifipamo agbara to kere fun `additional` awọn eroja diẹ sii lati fi sii ninu `BinaryHeap` ti a fun.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa agbara ko le gbarale lati jẹ pọọku deede.
    /// Fẹ [`reserve`] ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Fi agbara pamọ fun o kere ju awọn eroja diẹ sii `additional` lati fi sii ninu `BinaryHeap`.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Sọ awọn agbara pupọ bi o ti ṣee ṣe.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Yọọ agbara kuro pẹlu okun kekere.
    ///
    /// Agbara naa yoo wa ni o kere bi o tobi bi gigun ati iye ti a pese.
    ///
    ///
    /// Ti agbara lọwọlọwọ ba kere si opin isalẹ, eyi kii ṣe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Gba `BinaryHeap` ati da pada ipilẹ vector ni aṣẹ lainidii.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Yoo tẹ sita ni aṣẹ kan
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Pada gigun ti okiti alakomeji.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Awọn iṣayẹwo ti okiti alakomeji ba ṣofo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ti mu okiti alakomeji kuro, n da aṣetunṣe pada lori awọn eroja ti a yọ kuro.
    ///
    /// Ti yọ awọn eroja kuro ni aṣẹ lainidii.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Ṣubu gbogbo awọn ohun kan silẹ lati okiti alakomeji.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Iho duro iho kan ninu ege kan ie, itọka laisi iye to wulo (nitori o ti gbe lati tabi ṣe ẹda meji).
///
/// Ni silẹ, `Hole` yoo mu nkan pada sipo nipa kikun ipo iho pẹlu iye ti a yọ ni akọkọ.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Ṣẹda `Hole` tuntun ni itọka `pos`.
    ///
    /// Ailewu nitori pe pos gbọdọ wa laarin bibẹ pẹlẹbẹ data.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // Ailewu: pos yẹ ki o wa ninu ege
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Pada a tọka si ano kuro.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Pada itọkasi si eroja ni `index`.
    ///
    /// Ailewu nitori atọka gbọdọ wa laarin bibẹ pẹlẹbẹ data ati pe ko dọgba pẹlu pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Gbe iho si ipo tuntun
    ///
    /// Ailewu nitori atọka gbọdọ wa laarin bibẹ pẹlẹbẹ data ati pe ko dọgba pẹlu pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // kun iho lẹẹkansi
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Atunṣe lori awọn eroja ti `BinaryHeap` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`BinaryHeap::iter()`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Yọ kuro ni ojurere ti `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Atunṣe ti o ni lori awọn eroja ti `BinaryHeap` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`BinaryHeap::into_iter()`] (ti a pese nipasẹ `IntoIterator` trait).
/// Wo iwe rẹ fun diẹ sii.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Olutọju ṣiṣan lori awọn eroja ti `BinaryHeap` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`BinaryHeap::drain()`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Olutọju ṣiṣan lori awọn eroja ti `BinaryHeap` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`BinaryHeap::drain_sorted()`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Yọ awọn eroja akopọ jọ ni tito-ọrọ okiti.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Awọn iyipada `Vec<T>` kan sinu `BinaryHeap<T>` kan.
    ///
    /// Iyipada yii ṣẹlẹ ni aaye, ati pe o ni idiwọn akoko *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Awọn iyipada `BinaryHeap<T>` kan sinu `Vec<T>` kan.
    ///
    /// Iyipada yii ko nilo iṣipopada data tabi ipin, ati pe o ni idiju akoko igbagbogbo.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ṣẹda aṣetunṣe ti n gba, iyẹn ni, ọkan ti o gbe iye kọọkan jade kuro ni okiti alakomeji ni aṣẹ lainidii.
    /// A ko le lo okiti alakomeji lẹhin pipe eyi.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Tẹjade 1, 2, 3, 4 ni aṣẹ lainidii
    /// for x in heap.into_iter() {
    ///     // x ni iru i32, kii ṣe &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}