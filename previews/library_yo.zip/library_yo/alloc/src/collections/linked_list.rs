//! Atokọ ti o ni asopọ ilọpo meji pẹlu awọn apa ti o ni.
//!
//! `LinkedList` ngbanilaaye titari ati yiyo awọn eroja ni boya ipari ni akoko igbagbogbo.
//!
//! NOTE: O fẹrẹ dara nigbagbogbo lati lo [`Vec`] tabi [`VecDeque`] nitori awọn apoti ti o da lori orun jẹ yiyara ni gbogbogbo, ṣiṣe iranti diẹ sii, ati lilo dara julọ ti kaṣe CPU.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// Atokọ ti o ni asopọ ilọpo meji pẹlu awọn apa ti o ni.
///
/// `LinkedList` ngbanilaaye titari ati yiyo awọn eroja ni boya ipari ni akoko igbagbogbo.
///
/// NOTE: O fẹrẹ dara nigbagbogbo lati lo `Vec` tabi `VecDeque` nitori awọn apoti ti o da lori orun jẹ yiyara ni gbogbogbo, ṣiṣe iranti diẹ sii, ati lilo dara julọ ti kaṣe CPU.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// Atunṣe lori awọn eroja ti `LinkedList` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`LinkedList::iter()`].
/// Wo iwe rẹ fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) Yọ kuro ni ojurere ti `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// Atunṣe iyipada kan lori awọn eroja ti `LinkedList` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ [`LinkedList::iter_mut()`].
/// Wo iwe rẹ fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // A ko * kii ṣe iyasọtọ ti o ni gbogbo atokọ nibi, awọn itọkasi si `element` ti oju ipade ni a ti fi jade nipasẹ aṣetunṣe!Nitorina ṣọra nigba lilo eyi;awọn ọna ti a pe gbọdọ jẹ akiyesi pe awọn itọka aliasing le wa si `element`.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// Atunṣe ti o ni lori awọn eroja ti `LinkedList` kan.
///
/// `struct` yii ni a ṣẹda nipasẹ ọna [`into_iter`] lori [`LinkedList`] (ti a pese nipasẹ `IntoIterator` trait).
/// Wo iwe rẹ fun diẹ sii.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// ikọkọ awọn ọna
impl<T> LinkedList<T> {
    /// Ṣe afikun oju ipade ti a fun ni iwaju atokọ naa.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // Yi ọna ti gba bikita ko lati ṣẹda mutable jo si gbogbo apa, lati ṣetọju Wiwulo ti aliasing ifẹnule sinu `element`.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // Ko ṣiṣẹda awọn itọkasi (unique!) iyipada ti o le yipada `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// Yọ kuro ki o pada si oju ipade ni iwaju atokọ naa.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // Yi ọna ti gba bikita ko lati ṣẹda mutable jo si gbogbo apa, lati ṣetọju Wiwulo ti aliasing ifẹnule sinu `element`.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // Ko ṣiṣẹda awọn itọkasi (unique!) iyipada ti o le yipada `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Afikun awọn ti fi fun ipade si pada ti awọn akojọ.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // Yi ọna ti gba bikita ko lati ṣẹda mutable jo si gbogbo apa, lati ṣetọju Wiwulo ti aliasing ifẹnule sinu `element`.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // Ko ṣiṣẹda awọn itọkasi (unique!) iyipada ti o le yipada `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// Yọ kuro o si da oju ipade pada ni ẹhin atokọ naa.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // Yi ọna ti gba bikita ko lati ṣẹda mutable jo si gbogbo apa, lati ṣetọju Wiwulo ti aliasing ifẹnule sinu `element`.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // Ko ṣiṣẹda awọn itọkasi (unique!) iyipada ti o le yipada `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// Unlinks awọn pàtó kan ipade lati isiyi akojọ.
    ///
    /// Ikilọ: eyi kii yoo ṣayẹwo pe oju ipade ti a pese jẹ ti atokọ lọwọlọwọ.
    ///
    /// Ọna yii ṣe itọju kii ṣe lati ṣẹda awọn itọkasi iyipada si `element`, lati ṣetọju iduroṣinṣin ti awọn itọka aliasing.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ọkan yii jẹ tiwa bayi, a le ṣẹda &mut kan.

        // Ko ṣiṣẹda awọn itọkasi (unique!) iyipada ti o le yipada `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ipade yii ni oju ipade ori
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // oju ipade yii ni oju iru
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// Awọn ipin lẹsẹsẹ laarin awọn apa meji to wa tẹlẹ.
    ///
    /// Ikilọ: eyi kii yoo ṣayẹwo pe oju ipade ti a pese jẹ ti awọn atokọ meji ti o wa tẹlẹ.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // Ọna yii ṣe itọju ki o ma ṣe ṣẹda awọn itọka iyipada pupọ si awọn apa gbogbo ni akoko kanna, lati ṣetọju iduroṣinṣin ti awọn itọka titọ si `element`.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// Yọọ gbogbo awọn apa kuro lati atokọ ti a sopọ mọ bi lẹsẹsẹ awọn apa.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Nọmba pipin jẹ oju ipade ori tuntun ti apakan keji
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // Ṣe atunṣe ori ptr ti apakan keji
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // Nọmba pipin jẹ oju iru iru tuntun ti apakan akọkọ ati pe o ni ori apakan keji.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // Ṣe atunṣe iru ptr ti apakan akọkọ
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// Ṣẹda ohun ṣofo `LinkedList<T>`.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// Ṣẹda ohun ṣofo `LinkedList`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// Gbe gbogbo awọn eroja lati `other` si opin atokọ naa.
    ///
    /// Eyi tun lo gbogbo awọn apa lati `other` ati gbe wọn sinu `self`.
    /// Lẹhin isẹ yii, `other` di ofo.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1) ati iranti *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` dara nibi nitori a ni iraye si iyasoto si gbogbo awọn atokọ mejeeji.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Gbe gbogbo awọn eroja lati `other` si ibẹrẹ ti atokọ naa.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` dara nibi nitori a ni iraye si iyasoto si gbogbo awọn atokọ mejeeji.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// Pese aṣetunṣe siwaju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// Pese aṣetunṣe siwaju pẹlu awọn itọkasi didaba.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// Pese kọsọ kan ni eroja iwaju.
    ///
    /// Kọsọ naa n tọka si aisi-ailorukọ "ghost" ti atokọ ba ṣofo.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// Pese kọsọ kan pẹlu awọn iṣẹ ṣiṣatunkọ ni eroja iwaju.
    ///
    /// Kọsọ naa n tọka si aisi-ailorukọ "ghost" ti atokọ ba ṣofo.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// Pese kọsọ kan ni ẹhin ẹhin.
    ///
    /// Kọsọ naa n tọka si aisi-ailorukọ "ghost" ti atokọ ba ṣofo.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Pese kọsọ kan pẹlu awọn iṣẹ ṣiṣatunkọ ni eroja ẹhin.
    ///
    /// Kọsọ naa n tọka si aisi-ailorukọ "ghost" ti atokọ ba ṣofo.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// Pada `true` ti `LinkedList` ba ṣofo.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// Pada ipari ti `LinkedList`.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Yọ gbogbo awọn eroja kuro ninu `LinkedList`.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(*n*).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// Pada `true` ti `LinkedList` ba ni eroja ti o dọgba pẹlu iye ti a fun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// Pese itọkasi si eroja iwaju, tabi `None` ti atokọ ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Pese itọkasi iyipada si eroja iwaju, tabi `None` ti atokọ ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Pese itọkasi si eroja ẹhin, tabi `None` ti atokọ ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// Pese itọkasi iyipada si eroja ẹhin, tabi `None` ti atokọ ba ṣofo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// Ṣafikun ipilẹṣẹ akọkọ ninu atokọ naa.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// Yọ ano akọkọ ki o pada si, tabi `None` ti atokọ ba ṣofo.
    ///
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// Fikun ano si ẹhin atokọ kan.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// Yọ eroja ti o kẹhin kuro ninu atokọ kan o si da pada, tabi `None` ti o ba ṣofo.
    ///
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// Pin akojọ naa si meji ni itọka ti a fun.
    /// Pada ohun gbogbo lẹhin itọka ti a fun, pẹlu itọka naa.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(*n*).
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // Ni isalẹ, a ṣe itusilẹ si oju ipade i-1`th, boya lati ibẹrẹ tabi ipari, da lori eyiti yoo yara.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // dipo rirọ ni lilo .skip() (eyiti o ṣẹda eto tuntun), a fo ni ọwọ ki a le wọle si aaye ori laisi da lori awọn alaye imuse ti Rekọja
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // dara lati bẹrẹ lati opin
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// Yọ ano kuro ni itọka ti a fun ati da pada.
    ///
    /// Iṣẹ yii yẹ ki o ṣe iṣiro ni akoko *O*(*n*).
    ///
    /// # Panics
    /// Panics ti o ba wa ni>=yiya
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // Ni isalẹ, a ṣe itusilẹ si oju ipade ni itọka ti a fun, boya lati ibẹrẹ tabi ipari, da lori eyiti yoo yara.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// Ṣẹda aṣetunṣe eyiti o nlo pipade lati pinnu boya o yẹ ki o yọ nkan kan kuro.
    ///
    /// Ti pipade ba pada jẹ otitọ, lẹhinna a yọ ohun-elo kuro ki o fun ni agbara.
    /// Ti pipade ba pada jẹ eke, eroja yoo wa ninu atokọ naa kii yoo fun ni ni iteye.
    ///
    /// Akiyesi pe `drain_filter` n jẹ ki o ṣe iyipada gbogbo eroja ninu pipade àlẹmọ, laibikita boya o yan lati tọju tabi yọ kuro.
    ///
    ///
    /// # Examples
    ///
    /// Pinpin atokọ kan si awọn irọlẹ ati awọn idiwọn, tun lo atokọ atilẹba:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // yago fun awọn oran yiya.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // Tẹsiwaju lupu kanna ti a ṣe ni isalẹ.Eyi nikan n ṣiṣẹ nigbati oluparun kan ba bẹru.
                // Ti o ba jẹ pe panics miiran eyi yoo yo.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Nilo igbesi aye ailopin lati gba 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Nilo igbesi aye ailopin lati gba 'a
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // Nilo igbesi aye ailopin lati gba 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // Nilo igbesi aye ailopin lati gba 'a
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// Atọka lori `LinkedList` kan.
///
/// `Cursor` kan dabi aṣetunṣe, ayafi ti o le larọwọto wa ẹhin-ati-jade.
///
/// Awọn kọsọ nigbagbogbo sinmi laarin awọn eroja meji ninu atokọ, ati atọka ni ọna ipin oye.
/// Lati gba eyi, aisi-aini "ghost" wa ti o mu `None` wa laarin ori ati iru ti atokọ naa.
///
///
/// Nigbati o ṣẹda, awọn kọsọ bẹrẹ ni iwaju atokọ, tabi "ghost" ti kii ṣe eroja ti atokọ ba ṣofo.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// Atọka lori `LinkedList` kan pẹlu awọn iṣatunṣe ṣiṣatunkọ.
///
/// `Cursor` kan dabi aṣetunṣe, ayafi ti o le wa larọwọto sẹhin ati siwaju, ati pe o le paarọ atokọ lailewu lakoko aṣetunṣe.
/// Eyi jẹ nitori igbesi aye ti awọn itọka ikore rẹ ni asopọ si igbesi aye tirẹ, dipo kikojọ atokọ nikan.
/// Eyi tumọ si pe awọn kọsọ ko le fun awọn eroja pupọ ni ẹẹkan.
///
/// Awọn kọsọ nigbagbogbo sinmi laarin awọn eroja meji ninu atokọ, ati atọka ni ọna ipin oye.
/// Lati gba eyi, aisi-aini "ghost" wa ti o mu `None` wa laarin ori ati iru ti atokọ naa.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// Pada itọka ipo kọsọ laarin `LinkedList`.
    ///
    /// Eyi pada `None` ti kọsọ ba n tọka si lọwọlọwọ ti kii ṣe eroja "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Gbe kọsọ si nkan ti o tẹle ti `LinkedList`.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna eyi yoo gbe e si eroja akọkọ ti `LinkedList`.
    /// Ti o ba n tọka si nkan ti o kẹhin ti `LinkedList` lẹhinna eyi yoo gbe si "ghost" aiṣe-ano.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // A ko ni eroja lọwọlọwọ;kọsọ naa joko ni ipo ibẹrẹ Ipele atẹle yẹ ki o jẹ ori atokọ naa
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // A ni eroja ti tẹlẹ, nitorinaa jẹ ki a lọ si atẹle rẹ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Gbe kọsọ si nkan ti tẹlẹ ti `LinkedList`.
    ///
    /// Ti kọsọ ba n tọka si aisi-aisi-"ghost" lẹhinna eyi yoo gbe e si ipin ti o kẹhin ti `LinkedList`.
    /// Ti o ba n tọka si nkan akọkọ ti `LinkedList` lẹhinna eyi yoo gbe si "ghost" aiṣe-ano.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ko si lọwọlọwọ.A wa ni ibẹrẹ atokọ naa.Ikore Ko si ki o fo si opin.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Ni a prev.Mu ki o lọ si eroja ti tẹlẹ.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Pada itọkasi si eroja ti kọsọ n tọka si lọwọlọwọ.
    ///
    /// Eyi pada `None` ti kọsọ ba n tọka si lọwọlọwọ ti kii ṣe eroja "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// Pada a tọka si awọn nigbamii ti ano.
    ///
    /// Ti kọsọ ba n tọka si aisi-aisi-"ghost" lẹhinna eyi pada nkan akọkọ ti `LinkedList`.
    /// Ti o ba n tọka si nkan ikẹhin ti `LinkedList` lẹhinna eyi pada `None` pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// Pada a tọka si awọn ti tẹlẹ ano.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna eyi pada ipin ti o kẹhin ti `LinkedList`.
    /// Ti o ba n tọka si nkan akọkọ ti `LinkedList` lẹhinna eyi pada `None` pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// Pada itọka ipo kọsọ laarin `LinkedList`.
    ///
    /// Eyi pada `None` ti kọsọ ba n tọka si lọwọlọwọ ti kii ṣe eroja "ghost".
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// Gbe kọsọ si nkan ti o tẹle ti `LinkedList`.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna eyi yoo gbe e si eroja akọkọ ti `LinkedList`.
    /// Ti o ba n tọka si nkan ti o kẹhin ti `LinkedList` lẹhinna eyi yoo gbe si "ghost" aiṣe-ano.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // A ko ni eroja lọwọlọwọ;kọsọ naa joko ni ipo ibẹrẹ Ipele atẹle yẹ ki o jẹ ori atokọ naa
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // A ni eroja ti tẹlẹ, nitorinaa jẹ ki a lọ si atẹle rẹ
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// Gbe kọsọ si nkan ti tẹlẹ ti `LinkedList`.
    ///
    /// Ti kọsọ ba n tọka si aisi-aisi-"ghost" lẹhinna eyi yoo gbe e si ipin ti o kẹhin ti `LinkedList`.
    /// Ti o ba n tọka si nkan akọkọ ti `LinkedList` lẹhinna eyi yoo gbe si "ghost" aiṣe-ano.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // Ko si lọwọlọwọ.A wa ni ibẹrẹ atokọ naa.Ikore Ko si ki o fo si opin.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // Ni a prev.Mu ki o lọ si eroja ti tẹlẹ.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// Pada itọkasi si eroja ti kọsọ n tọka si lọwọlọwọ.
    ///
    /// Eyi pada `None` ti kọsọ ba n tọka si lọwọlọwọ ti kii ṣe eroja "ghost".
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// Pada a tọka si awọn nigbamii ti ano.
    ///
    /// Ti kọsọ ba n tọka si aisi-aisi-"ghost" lẹhinna eyi pada nkan akọkọ ti `LinkedList`.
    /// Ti o ba n tọka si nkan ikẹhin ti `LinkedList` lẹhinna eyi pada `None` pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// Pada a tọka si awọn ti tẹlẹ ano.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna eyi pada ipin ti o kẹhin ti `LinkedList`.
    /// Ti o ba n tọka si nkan akọkọ ti `LinkedList` lẹhinna eyi pada `None` pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// Pada kọsọ-ka-nikan ti o tọka si eroja lọwọlọwọ.
    ///
    /// Igbesi aye `Cursor` ti o pada wa ni asopọ si ti `CursorMut`, eyiti o tumọ si pe ko le ye ju `CursorMut` lọ ati pe `CursorMut` ti di fun igbesi aye ti `Cursor`.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// Bayi awọn iṣẹ ṣiṣatunkọ atokọ

impl<'a, T> CursorMut<'a, T> {
    /// Awọn ifibọ eroja tuntun sinu `LinkedList` lẹhin ti isiyi.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna a ti fi nkan tuntun sii ni iwaju `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // Atọka ti kii ṣe eroja ti "ghost" ti yipada.
                self.index = self.list.len;
            }
        }
    }

    /// Awọn ifibọ eroja tuntun sinu `LinkedList` ṣaaju ọkan ti isiyi.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna a ti fi nkan tuntun sii ni ipari `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// Yọ eroja lọwọlọwọ lati `LinkedList`.
    ///
    /// A ti mu ano ti o yọ kuro pada, ati pe kọsọ naa ti gbe lati tọka si eroja ti o tẹle ninu `LinkedList`.
    ///
    ///
    /// Ti kọsọ ba n tọka si lọwọlọwọ "ghost" ti kii ṣe eroja lẹhinna ko si ohunkan ti yọkuro ati pe `None` ti pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// Yọ eroja lọwọlọwọ lati `LinkedList` laisi ipinpinpin oju ipade atokọ.
    ///
    /// Node ti o yọ kuro ti pada bi `LinkedList` tuntun ti o ni ipade nikan.
    /// Ti gbe kọsọ si aaye si nkan atẹle ninu `LinkedList` lọwọlọwọ.
    ///
    /// Ti kọsọ ba n tọka si lọwọlọwọ "ghost" ti kii ṣe eroja lẹhinna ko si ohunkan ti yọkuro ati pe `None` ti pada.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// Awọn ifibọ awọn eroja lati `LinkedList` ti a fun lẹhin ti lọwọlọwọ.
    ///
    /// Ti kọsọ ba n tọka si aiṣe-aini "ghost" lẹhinna a ti fi awọn eroja tuntun sii ni ibẹrẹ `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // Atọka ti kii ṣe eroja ti "ghost" ti yipada.
                self.index = self.list.len;
            }
        }
    }

    /// Awọn ifibọ awọn eroja lati `LinkedList` ti a fun ṣaaju ọkan ti isiyi.
    ///
    /// Ti kọsọ ba n tọka si aisi-aiṣe-"ghost" lẹhinna a ti fi awọn eroja tuntun sii ni ipari `LinkedList`.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// Pin akojọ naa si meji lẹhin eroja lọwọlọwọ.
    /// Eyi yoo pada akojọ tuntun kan ti o ni ohun gbogbo lẹhin ti kọsọ, pẹlu atokọ atilẹba ti o mu ohun gbogbo duro ṣaaju.
    ///
    ///
    /// Ti kọsọ ba n tọka si aiṣe-nkan "ghost" lẹhinna gbogbo awọn akoonu ti `LinkedList` ni a gbe.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // Atọka ti kii ṣe eroja ti "ghost" ti yipada si 0.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// Pin akojọ naa si meji ṣaaju eroja lọwọlọwọ.
    /// Eyi yoo pada akojọ tuntun kan ti o ni ohun gbogbo ṣaaju kọsọ, pẹlu atokọ atilẹba ti o mu ohun gbogbo duro lẹhin.
    ///
    ///
    /// Ti kọsọ ba n tọka si aiṣe-nkan "ghost" lẹhinna gbogbo awọn akoonu ti `LinkedList` ni a gbe.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// Aṣatunṣe ti a ṣe nipasẹ pipe `drain_filter` lori LinkedList.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` o dara pẹlu awọn itọkasi awọn itọkasi `element`.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Gba atokọ naa sinu awọn eroja ti n fun ni eroja ni iye.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// Rii daju pe `LinkedList` ati awọn onigbọwọ kika-nikan ni o wa ni itara ninu awọn ipilẹ iru wọn.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}