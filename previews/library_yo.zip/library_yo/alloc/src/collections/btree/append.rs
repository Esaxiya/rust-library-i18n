use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Fikun gbogbo awọn orisii iye-iye bọtini lati isopọmọ ti awọn olutọju meji ti n goke, ni afikun oniyipada `length` kan ni ọna.Igbẹhin naa jẹ ki o rọrun fun olupe lati yago fun jijo nigbati oluṣọn silẹ ti o ya.
    ///
    /// Ti awọn olutọju mejeeji ṣe agbejade bọtini kanna, ọna yii ju awọn meji silẹ lati aṣetunṣe apa osi ati ṣe afikun bata naa lati aṣetunṣe ọtun.
    ///
    /// Ti o ba fẹ ki igi naa pari ni aṣẹ ti o gòke ti o muna, bii `BTreeMap` kan, awọn olutọju mejeeji yẹ ki o ṣe awọn bọtini ni aṣẹ ti o ga soke ti o muna, ọkọọkan tobi ju gbogbo awọn bọtini ninu igi lọ, pẹlu awọn bọtini eyikeyi tẹlẹ ninu igi lori titẹsi.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // A mura silẹ lati dapọ `left` ati `right` sinu ọkọọkan lẹsẹsẹ ni akoko laini.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Nibayi, a kọ igi kan lati ori ila lẹsẹsẹ ni akoko laini.
        self.bulk_push(iter, length)
    }

    /// Titari gbogbo awọn orisii iye-bọtini si opin igi naa, ni alekun iyipada `length` kan ni ọna.
    /// Igbẹhin naa jẹ ki o rọrun fun olupe lati yago fun jijo nigbati aṣenọju ba n bẹru.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ṣe iṣiro nipasẹ gbogbo awọn orisii iye-bọtini, titari wọn sinu awọn apa ni ipele ti o tọ.
        for (key, value) in iter {
            // Gbiyanju lati Titari bata iye iye si oju ipade bunkun lọwọlọwọ.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ko si aye ti o ku, lọ si oke ki o ta sibẹ.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Wa oju ipade pẹlu aaye ti osi, Titari ibi.
                                open_node = parent;
                                break;
                            } else {
                                // Lọ lẹẹkansi.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // A wa ni oke, ṣẹda oju ipade tuntun ati titari sibẹ.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Titari iye-bọtini bọtini ati ipilẹ kekere ẹtọ tuntun.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Sọkalẹ lọ si bunkun-julọ ọtun lẹẹkansi.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Gigun gigun ni gbogbo aṣetunṣe, lati rii daju pe maapu ju awọn eroja ti a fi sii silẹ paapaa ti ilọsiwaju awọn panẹli aṣetunṣe.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Atunṣe kan fun didọpọ awọn lẹsẹsẹ lẹsẹsẹ meji si ọkan
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ti awọn bọtini meji ba dọgba, dapada iye iye bọtini lati orisun ọtun.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}