use core::marker::PhantomData;
use core::ptr::NonNull;

/// Awọn awoṣe ni reborrow ti diẹ ninu itọkasi alailẹgbẹ, nigbati o ba mọ pe reborrow ati gbogbo awọn ọmọ rẹ (ie, gbogbo awọn itọka ati awọn itọkasi ti o wa lati ọdọ rẹ) kii yoo lo eyikeyi diẹ sii ni aaye kan, lẹhin eyi ti o fẹ lati lo itọkasi alailẹgbẹ akọkọ .
///
///
/// Oluyẹwo yawo nigbagbogbo n kapọ awọn ikopọ yii fun ọ, ṣugbọn diẹ ninu awọn ṣiṣakoso iṣakoso ti o ṣaṣeyọri akopọ yii jẹ idiju pupọ fun akopọ lati tẹle.
/// A `DormantMutRef` ngbanilaaye lati ṣayẹwo yiya ara rẹ, lakoko ti o n ṣalaye ẹda iseda rẹ, ati ṣiṣi koodu ijuboluwo alailo nilo lati ṣe eyi laisi ihuwasi ti a ko ṣalaye.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Gba yawo alailẹgbẹ kan, ati lẹsẹkẹsẹ tun pada si.
    /// Fun akopọ, igbesi aye itọkasi tuntun jẹ bakanna bi igbesi aye itọkasi atilẹba, ṣugbọn iwọ promise lati lo fun akoko kukuru kan.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // Aabo: a mu yiya ni gbogbo `kan nipasẹ `_marker`, ati pe a ṣafihan
        // itọkasi yii nikan, nitorina o jẹ alailẹgbẹ.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Pada si awin alailẹgbẹ ti o gba lakoko.
    ///
    /// # Safety
    ///
    /// Reborrow gbọdọ ti pari, ie, itọkasi ti o pada nipasẹ `new` ati gbogbo awọn itọka ati awọn itọkasi ti o gba lati ọdọ rẹ, ko gbọdọ lo mọ.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // Aabo: awọn ipo aabo tiwa tumọ si pe itọkasi yii tun jẹ alailẹgbẹ.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;