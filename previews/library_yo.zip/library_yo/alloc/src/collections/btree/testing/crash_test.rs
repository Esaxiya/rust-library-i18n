use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Iwe apẹrẹ fun awọn iṣẹlẹ idinilẹnu idanwo jamba ti o ṣe atẹle awọn iṣẹlẹ pataki.
/// Diẹ ninu awọn iṣẹlẹ le wa ni tunto si panic ni aaye kan.
/// Awọn iṣẹlẹ jẹ `clone`, `drop` tabi diẹ ninu ailorukọ `query`.
///
/// A mọ awọn aṣiwọn idanwo jamba ti idanimọ ati paṣẹ nipasẹ id, nitorinaa wọn le ṣee lo bi awọn bọtini ninu BTreeMap kan.
/// Imuṣiṣẹ imomose nlo ko gbẹkẹle ohunkan ti a ṣalaye ninu crate, yatọ si `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Ṣẹda apẹrẹ idinilẹnu idanwo jamba kan.`id` ṣe ipinnu aṣẹ ati isọgba ti awọn apẹẹrẹ.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Ṣẹda apeere kan ti idinwon idanwo jamba ti o ṣe igbasilẹ iru awọn iṣẹlẹ ti o ni iriri ati ni yiyan panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Pada bawo ni ọpọlọpọ awọn igba ti idinwon ti ni ẹda oniye.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Awọn ipadabọ melo ni awọn apẹẹrẹ ti idinwon ti lọ silẹ.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Awọn ipadabọ melo ni awọn apeere ti idinwon ti pe ọmọ ẹgbẹ `query` wọn.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Diẹ ninu ibeere alailorukọ, abajade eyi ti a ti fun tẹlẹ.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}