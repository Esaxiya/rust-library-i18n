// Eyi jẹ igbiyanju si imuse ti o tẹle apẹrẹ
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Niwọn igba ti Rust ko ni awọn oriṣi igbẹkẹle ati ifasẹyin polymorphic, a ṣe pẹlu ọpọlọpọ ailewu.
//

// Idi pataki kan ti module yii ni lati yago fun idiju nipa titọju igi naa bi ohun elo jeneriki (ti o ba jẹ apẹrẹ ajeji) ati yago fun ibaṣowo pẹlu ọpọlọpọ awọn aiṣe B-Igi.
//
// Bii iru eyi, module yii ko ṣe abojuto boya awọn titẹ sii ti wa ni lẹsẹsẹ, eyiti awọn apa le jẹ labẹ, tabi paapaa kini itumo underfull.Sibẹsibẹ, a gbẹkẹle igbẹkẹle diẹ:
//
// - Awọn igi gbọdọ ni aṣọ depth/height.Eyi tumọ si pe gbogbo ọna si isalẹ lati bunkun lati oju ipade ti a fun ni ipari gigun kanna.
// - Node ti gigun `n` ni awọn bọtini `n`, awọn iye `n`, ati awọn egbe `n + 1`.
//   Eyi tumọ si pe paapaa oju ipade ti o ṣofo ni o kere ju edge kan.
//   Fun oju ipade ewe kan, "having an edge" nikan tumọ si pe a le ṣe idanimọ ipo kan ninu oju ipade, nitori awọn ẹgbẹ bunkun ṣofo ati pe ko nilo aṣoju data.
// Ninu oju ipade inu, edge mejeeji ṣe idanimọ ipo kan ati pe o ni itọka si oju ipade ọmọde.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Aṣoju ipilẹ ti awọn apa bunkun ati apakan ti aṣoju ti awọn apa inu.
struct LeafNode<K, V> {
    /// A fẹ lati wa ni akọpọ ni `K` ati `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Atọka oju ipade yii sinu ọna `edges` oju ipade ti obi.
    /// `*node.parent.edges[node.parent_idx]` yẹ ki o jẹ ohun kanna bi `node`.
    /// Eyi jẹ ẹri nikan lati jẹ ipilẹṣẹ nigbati `parent` jẹ asan.
    parent_idx: MaybeUninit<u16>,

    /// Nọmba awọn bọtini ati awọn iye awọn ile itaja ipade yii.
    len: u16,

    /// Awọn ipilẹ ti o tọju data gangan ti oju ipade naa.
    /// Awọn eroja `len` akọkọ nikan ti ọna kọọkan ni ipilẹ ati wulo.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Ṣiṣẹ `LeafNode` tuntun ni ibi.
    unsafe fn init(this: *mut Self) {
        // Gẹgẹbi eto imulo gbogbogbo, a fi awọn aaye silẹ lainidi ti wọn ba le jẹ, nitori eyi yẹ ki o yara yiyara ati rọrun lati tọpinpin ni Valgrind.
        //
        unsafe {
            // parent_idx, awọn bọtini, ati awọn vals jẹ gbogbo BoyaUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Ṣẹda apoti `LeafNode` tuntun.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Aṣoju ipilẹ ti awọn apa inu.Bii pẹlu `LeafNode`s, iwọnyi yẹ ki o wa ni pamọ sẹhin`BoxedNode`s lati yago fun sisọ awọn bọtini ati awọn iye ti ko ni oye silẹ.
/// Atọka eyikeyi si `InternalNode` le ni taara taara si ijuboluwo si apakan `LeafNode` ipilẹ ti oju ipade, gbigba koodu laaye lati ṣiṣẹ lori bunkun ati awọn apa inu jeneriki laisi nini paapaa ṣayẹwo eyi ti ninu ami-ifọkasi meji ti o tọka si.
///
/// Ohun-ini yii ṣiṣẹ nipasẹ lilo `repr(C)`.
///
#[repr(C)]
// gdb_providers.py nlo orukọ iru yii fun iṣaro.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Awọn itọka si awọn ọmọ ti oju ipade yii.
    /// `len + 1` ti awọn wọnyi ni a ṣe akiyesi ipilẹṣẹ ati iwulo, ayafi ti o sunmọ opin, lakoko ti o waye igi nipasẹ iru yiya `Dying`, diẹ ninu awọn atọka wọnyi n tan.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Ṣẹda apoti `InternalNode` tuntun.
    ///
    /// # Safety
    /// Alaiṣẹ ti awọn apa inu ni pe wọn ni o kere ju ọkan ti ipilẹṣẹ ati deede edge.
    /// Iṣẹ yii ko ṣeto iru edge kan.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // A nilo lati ṣe ipilẹṣẹ data nikan;awọn egbegbe jẹ BoyaUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Itọsọna ti a ṣakoso, ti kii ṣe asan si oju ipade kan.Eyi jẹ boya ijuboluwo ti o ni si `LeafNode<K, V>` tabi ijuboluwo ti o ni si `InternalNode<K, V>`.
///
/// Sibẹsibẹ, `BoxedNode` ko ni alaye kankan si iru iru awọn apa meji ti o ni ninu gangan, ati pe, ni apakan nitori aini alaye yii, kii ṣe iru lọtọ ati pe ko ni apanirun.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Ipile ipade ti igi ti o ni.
///
/// Akiyesi pe eyi ko ni apanirun, ati pe o gbọdọ di mimọ pẹlu ọwọ.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Padà a titun ini igi, pẹlu awọn oniwe-ara root ipade ti o jẹ wa lakoko sofo.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ko gbọdọ jẹ odo.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Ni adaṣe ya awin ipade ti o ni.
    /// Kii `reborrow_mut`, eyi jẹ ailewu nitori iye ipadabọ ko le lo lati pa gbongbo run, ati pe awọn itọkasi miiran ko le wa si igi naa.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Diẹ di oniduro ya kode ipade ti ohun-ini.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Awọn iyipada ti a ko le yipada si itọkasi kan ti o gba laaye kọja kọja ati awọn ọna iparun ati kekere miiran.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ṣafikun ipade inu inu tuntun pẹlu edge ẹyọkan ti o tọka si oju ipade gbongbo ti tẹlẹ, ṣe oju ipade tuntun ni oju ipade, ki o da pada.
    /// Eyi mu ki giga pọ si nipasẹ 1 ati pe idakeji ti `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ayafi pe a kan gbagbe pe a jẹ ti inu ni bayi:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yọ oju ipade gbongbo inu, ni lilo ọmọ akọkọ bi oju ipade tuntun.
    /// Bi o ti pinnu nikan lati pe nigba ti ipade gbongbo ni ọmọ kan ṣoṣo, ko si afọmọ afọwọkọ ti a ṣe lori eyikeyi awọn bọtini, awọn iye ati awọn ọmọde miiran.
    ///
    /// Eyi dinku giga nipasẹ 1 ati pe idakeji ti `push_internal_level`.
    ///
    /// Nbeere iraye si iyasoto si ohun `Root` ṣugbọn kii ṣe si oju ipade;
    /// kii yoo ṣe idiwọn awọn kapa miiran tabi awọn itọkasi si oju ipade.
    ///
    /// Panics ti ko ba si ipele ti inu, ie, ti oju ipade gbongbo ba jẹ ewe.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // Aabo: a tẹnumọ lati jẹ ti inu.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // Aabo: a ya `self` ni iyasọtọ ati iru awin rẹ jẹ iyasoto.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // Aabo: edge akọkọ jẹ ipilẹṣẹ nigbagbogbo.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` jẹ covariant nigbagbogbo ni `K` ati `V`, paapaa nigbati `BorrowType` jẹ `Mut`.
// Eyi jẹ aṣiṣe ti imọ-ẹrọ, ṣugbọn ko le ja si ailewu eyikeyi nitori lilo ti inu ti `NodeRef` nitori a duro jeneriki patapata lori `K` ati `V`.
//
// Sibẹsibẹ, nigbakugba ti oriṣi ti gbogbo eniyan ba fi ipari si `NodeRef`, rii daju pe o ni iyatọ to tọ.
//
/// Itọkasi si ipade kan.
///
/// Iru yii ni awọn aye ti nọmba ti o ṣakoso bi o ṣe n ṣiṣẹ:
/// - `BorrowType`: Iru iru eeyan kan ti o ṣe apejuwe iru yiya ati gbe igbesi aye kan.
///    - Nigbati eyi jẹ `Immut<'a>`, `NodeRef` ṣiṣẹ ni aijọju bi `&'a Node`.
///    - Nigbati eyi jẹ `ValMut<'a>`, `NodeRef` ṣiṣẹ ni aijọju bi `&'a Node` pẹlu ọwọ si awọn bọtini ati iṣeto igi, ṣugbọn tun gba ọpọlọpọ awọn itọkasi iyipada si awọn iye jakejado igi lati gbe pọ.
///    - Nigbati eyi jẹ `Mut<'a>`, `NodeRef` ṣiṣẹ ni aijọju bi `&'a mut Node`, botilẹjẹpe awọn ọna ifibọ gba aaye ijuboluwole iyipada si iye lati gbe pọ.
///    - Nigbati eyi jẹ `Owned`, `NodeRef` ṣiṣẹ ni aijọju bi `Box<Node>`, ṣugbọn ko ni apanirun kan, ati pe o gbọdọ sọ di mimọ pẹlu ọwọ.
///    - Nigbati eyi jẹ `Dying`, `NodeRef` tun ṣiṣẹ ni aijọju bi `Box<Node>`, ṣugbọn ni awọn ọna lati pa igi run diẹ diẹ, ati awọn ọna lasan, lakoko ti a ko samisi bi aiwuwu lati pe, le pe UB ti a ba pe ni aṣiṣe.
///
///   Niwọn igba ti eyikeyi `NodeRef` ngbanilaaye lilọ kiri nipasẹ igi, `BorrowType` munadoko kan si gbogbo igi, kii ṣe si oju ipade funrararẹ.
/// - `K` ati `V`: Iwọnyi ni awọn oriṣi awọn bọtini ati awọn iye ti a fipamọ sinu awọn apa.
/// - `Type`: Eyi le jẹ `Leaf`, `Internal`, tabi `LeafOrInternal`.
/// Nigbati eyi jẹ `Leaf`, `NodeRef` tọka si oju ipade ewe kan, nigbati eyi jẹ `Internal` awọn aami `NodeRef` si oju ipade inu, ati pe nigbati eyi jẹ `LeafOrInternal` `NodeRef` le ṣe itọka si boya iru ipade.
///   `Type` ti wa ni orukọ `NodeType` nigba lilo ni ita `NodeRef`.
///
/// Mejeeji `BorrowType` ati `NodeType` ni ihamọ awọn ọna wo ni a ṣe, lati lo iru aabo iru aimi.Awọn idiwọn wa ni ọna ti a le lo iru awọn ihamọ bẹẹ:
/// - Fun iru paramita kọọkan, a le ṣalaye ọna kan boya jeneriki tabi fun iru kan pato.
/// Fun apẹẹrẹ, a ko le ṣalaye ọna bi `into_kv` jeneriki fun gbogbo `BorrowType`, tabi lẹẹkan fun gbogbo awọn oriṣi ti o gbe igbesi aye kan, nitori a fẹ ki o pada awọn itọkasi `&'a`.
///   Nitorinaa, a ṣalaye rẹ nikan fun iru agbara ti o kere ju `Immut<'a>`.
/// - A ko le gba ifipa mu lati sọ `Mut<'a>` si `Immut<'a>`.
///   Nitorinaa, a ni lati pe ni kedere `reborrow` lori `NodeRef` ti o ni agbara diẹ sii lati le de ọna bi `into_kv`.
///
/// Gbogbo awọn ọna lori `NodeRef` ti o da iru itọkasi kan pada, boya:
/// - Mu `self` nipasẹ iye, ki o pada si igbesi aye ti `BorrowType` gbe.
///   Nigba miiran, lati pe iru ọna bẹẹ, a nilo lati pe `reborrow_mut`.
/// - Mu `self` nipasẹ itọkasi, ati (implicitly) pada s`aiye itọkasi rẹ, dipo igbesi aye ti `BorrowType` gbe.
/// Ni ọna yẹn, olutọju awin ṣe onigbọwọ pe `NodeRef` ṣi yawo niwọn igba ti a lo itọkasi ti o pada.
///   Awọn ọna ti o ṣe atilẹyin ifibọ tẹ ofin yii nipa pipada ijuboluwo to aise, ie, itọkasi kan laisi igbesi aye eyikeyi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Nọmba ti awọn ipele ti oju ipade ati ipele ti awọn ewe wa lọtọ, ibakan ti oju ipade ti a ko le ṣe apejuwe rẹ ni kikun nipasẹ `Type`, ati pe oju ipade funrararẹ ko tọju.
    /// A nilo lati tọju giga ti oju ipade, ki o si gba gbogbo iga ipade miiran lati ọdọ rẹ.
    /// Gbọdọ jẹ odo ti `Type` jẹ `Leaf` ati ti kii-odo ti `Type` jẹ `Internal`.
    ///
    ///
    height: usize,
    /// Atọka si bunkun tabi oju ipade inu.
    /// Itumọ ti `InternalNode` ṣe idaniloju pe ijuboluwole wulo ni ọna kan.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ṣii itọkasi itọkasi kan ti o ti ṣajọ bi `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ṣe afihan data ti oju ipade inu.
    ///
    /// Pada a ptr aise lati yago fun invalidating awọn itọkasi miiran si oju ipade yii.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // Aabo: oriṣi oju ipade aimi ni `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Yọọ iraye si iyasoto si data ti oju ipade inu.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Wa gigun ti oju ipade naa.Eyi ni nọmba awọn bọtini tabi awọn iye.
    /// Nọmba awọn egbegbe jẹ `len() + 1`.
    /// Akiyesi pe, laibikita pe o wa ni ailewu, pipe iṣẹ yii le ni ipa ẹgbẹ ti invalidating awọn itọkasi iyipada ti koodu alaiwu ti ṣẹda.
    ///
    pub fn len(&self) -> usize {
        // Ni pataki, a nikan wọle si aaye `len` nibi.
        // Ti BorrowType jẹ marker::ValMut, awọn itọkasi iyipada titayọ le wa si awọn iye ti a ko gbọdọ sọ di asan.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Pada nọmba awọn ipele ti oju ipade ati awọn leaves yato si.
    /// Giga giga odo tumọ si pe ipade jẹ bunkun funrararẹ.
    /// Ti o ba ya aworan awọn igi pẹlu gbongbo lori oke, nọmba naa sọ ni ibiti igbega ti ipade yoo han.
    /// Ti o ba ya aworan awọn igi pẹlu awọn leaves ni oke, nọmba naa sọ bi giga igi ṣe gun loke oju ipade naa.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ni igba diẹ mu jade miiran, itọkasi aiyipada si oju ipade kanna.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ṣafihan apakan ewe ti eyikeyi bunkun tabi oju ipade inu.
    ///
    /// Pada a ptr aise lati yago fun invalidating awọn itọkasi miiran si oju ipade yii.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Node naa gbọdọ jẹ deede fun o kere ju apakan LeafNode.
        // Eyi kii ṣe itọkasi ninu iru NodeRef nitori a ko mọ boya o yẹ ki o jẹ alailẹgbẹ tabi pinpin.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Wa obi ti ibudo lọwọlọwọ.
    /// Pada `Ok(handle)` ti oju ipade lọwọlọwọ ba ni obi gangan, nibiti `handle` tọka si edge ti obi ti o tọka si oju ipade lọwọlọwọ.
    ///
    /// Pada `Err(self)` ti oju ipade lọwọlọwọ ko ni obi, fifun pada ni atilẹba `NodeRef`.
    ///
    /// Orukọ ọna naa dawọle pe o jẹ awọn igi aworan pẹlu oju ipade ni oke.
    ///
    /// `edge.descend().ascend().unwrap()` ati `node.ascend().unwrap().descend()` yẹ ki awọn mejeeji, lori aṣeyọri, ṣe ohunkohun.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // A nilo lati lo awọn itọka aise si awọn apa nitori, ti BorrowType ba jẹ marker::ValMut, awọn itọkasi mutable ti o ni iyasọtọ le wa si awọn iye ti a ko gbọdọ sọ di asan.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Akiyesi pe `self` gbọdọ jẹ alailowaya.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Akiyesi pe `self` gbọdọ jẹ alailowaya.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Ṣafihan apakan ewe ti eyikeyi bunkun tabi oju ipade inu inu igi ti ko le yipada.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // Aabo: ko le si awọn ifọkasi iyipada si igi yii ti ya bi `Immut`.
        unsafe { &*ptr }
    }

    /// Yọọ wiwo sinu awọn bọtini ti o fipamọ sinu oju ipade.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Bii `ascend`, n ni itọkasi si oju ipade obi obi, ṣugbọn tun ṣe ipin ipo ipade lọwọlọwọ ninu ilana.
    /// Eyi ko ni aabo nitori pe oju ipade lọwọlọwọ yoo tun wa ni iraye paapaa ti a ti pin ni ipo.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Awọn igboya lainidena si akopọ oniye alaye aimi pe oju ipade yii jẹ `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Awọn igboya ti ko ni aabo sọ fun akopọ alaye aimi pe oju ipade yii jẹ `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ni igba diẹ mu jade miiran, itọkasi iyipada si oju ipade kanna.Ṣọra, bi ọna yii ṣe lewu pupọ, lẹẹmeji nitorinaa o le ma han lẹsẹkẹsẹ eewu.
    ///
    /// Nitori awọn atọka iyipada le lọ kiri nibikibi ni ayika igi, ijuboluwole ti o pada le ṣee lo ni irọrun lati ṣe itọka atokasi atilẹba, jade ti awọn aala, tabi aiṣe labẹ awọn ofin awin ti a fi pamọ.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ronu fifi kun iru paramita iru miiran si `NodeRef` eyiti o ni ihamọ lilo awọn ọna lilọ kiri lori awọn itọka ti a tun gbe pada, ni idilọwọ ailewu yii.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Yọọ iraye si iyasoto si apakan ewe ti eyikeyi bunkun tabi oju ipade inu.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // Aabo: a ni iraye si iyasoto si gbogbo oju ipade.
        unsafe { &mut *ptr }
    }

    /// N funni ni iraye si iyasoto si apakan ewe ti eyikeyi bunkun tabi oju ipade inu.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // Aabo: a ni iraye si iyasoto si gbogbo oju ipade.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Yọọ iraye si iyasoto si eroja ti agbegbe ibi ipamọ bọtini.
    ///
    /// # Safety
    /// `index` wa ni awọn aala ti 0..AGBARA
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // Aabo: olupe naa kii yoo ni anfani lati pe awọn ọna siwaju si ara ẹni
        // titi ti itọkasi bibẹ bọtini ti lọ silẹ, nitori a ni iraye si alailẹgbẹ fun igbesi aye yiya.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Gbigbe iraye si iyasoto si eroja tabi ege ti agbegbe ibi ipamọ iye iye.
    ///
    /// # Safety
    /// `index` wa ni awọn aala ti 0..AGBARA
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // Aabo: olupe naa kii yoo ni anfani lati pe awọn ọna siwaju si ara ẹni
        // titi ti itọkasi bibẹ iye ti lọ silẹ, nitori a ni iraye si alailẹgbẹ fun igbesi aye yiya.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Yọọ iraye si iyasoto si eroja tabi ege ti ibi ipamọ ibi ipade naa fun awọn akoonu edge.
    ///
    /// # Safety
    /// `index` wa ni awọn aala ti 0..AGBARA + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // Aabo: olupe naa kii yoo ni anfani lati pe awọn ọna siwaju si ara ẹni
        // titi ti itọkasi bibẹ pẹlẹpẹlẹ edge yoo lọ silẹ, nitori a ni iraye si alailẹgbẹ fun igbesi aye yiya.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Nọmba naa ni diẹ sii ju awọn eroja ipilẹṣẹ `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // A ṣẹda itọka nikan si nkan kan ti a nifẹ si, lati yago fun titọ orukọ pẹlu awọn itọkasi titayọ si awọn eroja miiran, ni pataki, awọn ti o pada si olupe ni awọn aṣaaju iṣaaju.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // A gbọdọ fi ipa mu si awọn itọka orun ti a ko iwọn nitori ti ọrọ Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Yọọ iraye si iyasilẹ si ipari ti oju ipade naa.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ṣeto ọna asopọ ipade si obi edge rẹ, laisi sọ awọn itọkasi miiran di asan.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Fọ ọna asopọ gbongbo si obi edge rẹ.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Afikun iye iye bọtini kan si opin oju ipade naa.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Gbogbo ohun ti o pada nipasẹ `range` jẹ itọka edge to wulo fun oju ipade.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Afikun iye iye bọtini kan, ati edge lati lọ si apa ọtun ti bata yẹn, si opin ipade naa.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Awọn iṣayẹwo boya apa kan jẹ oju ipade `Internal` tabi oju ipade `Leaf` kan.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Itọkasi si bata-iye iye kan pato tabi edge laarin oju ipade kan.
/// Iwọn paramita `Node` gbọdọ jẹ `NodeRef`, lakoko ti `Type` le jẹ `KV` (ti o ṣe afihan mimu lori iye iye bọtini kan) tabi `Edge` (ti o ṣe afihan mimu lori edge).
///
/// Akiyesi pe paapaa awọn apa `Leaf` le ni awọn kapa `Edge`.
/// Dipo lati ṣe aṣoju ijuboluwo si oju ipade ọmọde, iwọnyi ṣe aṣoju awọn aye nibiti awọn itọka ọmọde yoo lọ laarin awọn orisii iye-bọtini.
/// Fun apẹẹrẹ, ninu apa kan pẹlu gigun 2, awọn ipo edge 3 ṣee ṣe yoo wa, ọkan si apa osi ti oju ipade, ọkan laarin awọn meji meji, ati ọkan ni apa ọtun ipade.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// A ko nilo gbogbogbo ti `#[derive(Clone)]`, bi akoko nikan `Node` yoo jẹ `Clone`able ni nigbati o jẹ itọkasi aiyipada ati nitorinaa `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Ṣe igbasilẹ oju ipade ti o ni edge tabi bata-iye iye bọtini mimu yii tọka si.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Pada ipo ipo mu yii ni oju ipade.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Ṣẹda mu tuntun si bata iye iye bọtini ni `node`.
    /// Ailewu nitori olupe gbọdọ rii daju pe `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Ṣe le jẹ imuse ti gbogbo eniyan ti PartialEq, ṣugbọn o lo ni module yii nikan.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Ni igba diẹ mu jade miiran, mimu ti ko le yipada lori ipo kanna.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // A ko le lo Handle::new_kv tabi Handle::new_edge nitori a ko mọ iru wa
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Awọn igboya ti ko ni aabo sọ si akopọ naa alaye aimi ti oju ipade mu naa jẹ `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ni igba die mu miiran jade, mu idari lori ipo kanna.
    /// Ṣọra, bi ọna yii ṣe lewu pupọ, lẹẹmeji nitorinaa o le ma han lẹsẹkẹsẹ eewu.
    ///
    ///
    /// Fun awọn alaye, wo `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // A ko le lo Handle::new_kv tabi Handle::new_edge nitori a ko mọ iru wa
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Ṣẹda mu tuntun si edge kan ni `node`.
    /// Ailewu nitori olupe gbọdọ rii daju pe `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Ti fun ni atọka edge nibiti a fẹ fi sii sinu oju ipade ti o kun si agbara, ṣe iṣiro itọka KV ti o ni oye ti aaye pipin ati ibiti o ti le ṣe ifibọ sii.
///
/// Idi ti aaye pipin jẹ fun bọtini ati iye rẹ lati pari ni oju ipade obi;
/// awọn bọtini, awọn iye ati awọn ẹgbẹ si apa osi ti aaye pipin di ọmọ osi;
/// awọn bọtini, iye ati egbegbe si awọn ọtun ti awọn pipin ojuami di ọtun ọmọ.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Ọrọ Rust #74834 gbidanwo lati ṣalaye awọn ofin isedogba wọnyi.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Awọn ifibọ iye iye bọtini tuntun laarin awọn orisii iye-bọtini si ọtun ati apa osi ti edge yii.
    /// Ọna yii dawọle pe aaye to wa ninu oju ipade fun bata tuntun lati baamu.
    ///
    /// Atọka ti o pada wa si iye ti a fi sii.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Awọn ifibọ iye iye bọtini tuntun laarin awọn orisii iye-bọtini si ọtun ati apa osi ti edge yii.
    /// Ọna yii pin node naa ti ko ba si yara to.
    ///
    /// Atọka ti o pada wa si iye ti a fi sii.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Awọn atunṣe ijuboluwole obi ati itọka ninu oju ipade ọmọ ti edge yii sopọ mọ si.
    /// Eyi wulo nigbati aṣẹ ti awọn egbegbe ti yipada,
    fn correct_parent_link(self) {
        // Ṣẹda onikawehinti lai ṣe atunṣe awọn itọkasi miiran si oju ipade.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Awọn ifibọ iye-iye bọtini tuntun ati edge kan ti yoo lọ si apa ọtun ti bata tuntun yẹn laarin edge yii ati bata iye iye bọtini si apa ọtun ti edge yii.
    /// Ọna yii dawọle pe aaye to wa ninu oju ipade fun bata tuntun lati baamu.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Awọn ifibọ iye-iye bọtini tuntun ati edge kan ti yoo lọ si apa ọtun ti bata tuntun yẹn laarin edge yii ati bata iye iye bọtini si apa ọtun ti edge yii.
    /// Ọna yii pin node naa ti ko ba si yara to.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Awọn ifibọ iye iye bọtini tuntun laarin awọn orisii iye-bọtini si ọtun ati apa osi ti edge yii.
    /// Ọna yii pin pin oju ipade ti ko ba si yara to, ati gbiyanju lati fi ipin pipin si apa oju-iwe obi pada, titi ti gbongbo yoo fi de.
    ///
    ///
    /// Ti abajade ti o pada ba jẹ `Fit`, ipade ti mimu rẹ le jẹ oju ipade edge yii tabi baba nla kan.
    /// Ti abajade ti o pada ba jẹ `Split`, aaye `left` yoo jẹ oju ipade.
    /// Atọka ti o pada wa si iye ti a fi sii.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Wa oju ipade ti o tọka si nipasẹ edge yii.
    ///
    /// Orukọ ọna naa dawọle pe o jẹ awọn igi aworan pẹlu oju ipade ni oke.
    ///
    /// `edge.descend().ascend().unwrap()` ati `node.ascend().unwrap().descend()` yẹ ki awọn mejeeji, lori aṣeyọri, ṣe ohunkohun.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // A nilo lati lo awọn itọka aise si awọn apa nitori, ti BorrowType ba jẹ marker::ValMut, awọn itọkasi mutable ti o ni iyasọtọ le wa si awọn iye ti a ko gbọdọ sọ di asan.
        // Ko si wahala lati wọle si aaye giga nitori iye naa ti daakọ.
        // Ṣọra pe, ni kete ti ijuboluwole atokọ ti ni ifasilẹ, a wọle si awọn ẹgbẹ ẹgbẹ pẹlu itọkasi kan (ọrọ Rust #73987) ati pe ko wulo eyikeyi awọn itọkasi miiran si tabi inu orun, yẹ ki eyikeyi wa ni ayika.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // A ko le pe bọtini lọtọ ati awọn ọna iye, nitori pipe ekeji ko wulo itọkasi ti o pada nipasẹ akọkọ.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Rọpo bọtini ati iye ti mimu KV tọka si.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ṣe iranlọwọ awọn imuṣẹ ti `split` fun `NodeType` kan pato, nipa abojuto data ewe.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Pinpin oju ipade si awọn ẹya mẹta:
    ///
    /// - Nọmba naa ti wa ni gige lati ni awọn orisii iye-bọtini si apa osi ti mu mu yii nikan.
    /// - Bọtini ati iye ti o tọka si nipasẹ mimu yii ni a fa jade.
    /// - Gbogbo awọn orisii iye-bọtini si apa ọtun ti mu mu ni a fi sinu oju ipade tuntun ti a pin.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Yọ bata iye iye bọtini ti o tọka si nipasẹ mimu yii ki o pada si, pẹlu edge ti bata iye-bọtini naa wolulẹ sinu.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Pinpin oju ipade si awọn ẹya mẹta:
    ///
    /// - Nọmba naa ti dinku lati ni awọn egbegbe nikan ati awọn orisii iye bọtini si apa osi ti mimu yii.
    /// - Bọtini ati iye ti o tọka si nipasẹ mimu yii ni a fa jade.
    /// - Gbogbo awọn egbegbe ati awọn orisii iye bọtini si apa ọtun ti mimu yii ni a fi sinu oju ipade ti a ṣẹṣẹ pin.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Ṣe aṣoju igba fun ṣiṣe iṣiro ati ṣiṣe iṣẹ iṣuwọn kan ni ayika bata iye-bọtini inu.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Yan o tọ dọgbadọgba ti o kan ipade naa bi ọmọde, nitorinaa laarin KV lẹsẹkẹsẹ si apa osi tabi si ọtun ni oju ipade obi.
    /// Pada `Err` kan ti ko ba si obi.
    /// Panics ti obi ba ṣofo.
    ///
    /// Ṣe ayanfẹ ẹgbẹ apa osi, lati jẹ ti o dara julọ ti oju ipade ti a fifun ba jẹ bakan labẹ, ti o tumọ si nihin nikan pe o ni awọn eroja diẹ ju ẹgbọn rẹ ti osi ati ju arakunrin arakunrin ọtun rẹ lọ, ti wọn ba wa tẹlẹ.
    /// Ni ọran yẹn, didapọ pẹlu arakunrin ti osi wa ni iyara, nitori a nilo nikan lati gbe awọn eroja N ti oju ipade naa, dipo yiyi wọn si apa ọtun ati gbigbe diẹ sii ju awọn eroja N ni iwaju.
    /// Jiji lati arakunrin ti osi tun jẹ iyara ni igbagbogbo, nitori a nilo lati yi awọn eroja N nikan si apa ọtun, dipo yiyi o kere ju N ti awọn eroja sibling si apa osi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Pada boya didakopọ ṣee ṣe, ie, boya yara to wa ni oju ipade lati ṣapọpọ KV aringbungbun pẹlu awọn apa ọmọ to wa nitosi.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Ṣe iṣọkan kan ati ki o jẹ ki pipade pinnu ohun ti o le pada.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // Aabo: giga ti awọn apa ti a dapọ jẹ ọkan ni isalẹ giga
                // ti oju ipade ti edge yii, nitorinaa loke odo, nitorinaa wọn jẹ ti inu.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Dapọ iye iye bọtini ti obi ati awọn apa ọmọ ti o wa nitosi si ibi ipade ọmọ osi ati da oju ipade obi ti o dinku.
    ///
    ///
    /// Panics ayafi ti a `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Dapọ iye iye bọtini ti obi ati awọn apa ọmọ ti o wa nitosi si ibi ipade ọmọ ti osi ati da ipade ọmọ yẹn pada.
    ///
    ///
    /// Panics ayafi ti a `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Dapọ iye iye bọtini ti obi ati awọn apa ọmọ ti o wa nitosi si ibi ipade ọmọ osi o si da ifipamọ edge ni oju ipade ọmọ yẹn nibiti ọmọ ti o tọpinpin edge pari,
    ///
    ///
    /// Panics ayafi ti a `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Yọ bata iye-bọtini kan kuro ninu ọmọ osi o si gbe si ibi ipamọ iye-bọtini ti obi, lakoko ti o n ta bata iye bọtini bọtini obi atijọ si ọmọ ti o tọ.
    ///
    /// Pada idari kan si edge ninu ọmọ ti o baamu ti o baamu si ibiti edge atilẹba ti `track_right_edge_idx` sọ tẹlẹ pari.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Yọ iye iye bọtini lati ọmọ ọtun ki o gbe si ibi ipamọ iye-bọtini ti obi, lakoko ti o n ta bata iye bọtini obi atijọ si ọmọ osi.
    ///
    /// Pada idari kan si edge ninu ọmọ osi ti a sọ nipa `track_left_edge_idx`, eyiti ko gbe.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Eyi ṣe jiji ti o jọra si `steal_left` ṣugbọn jiji awọn eroja pupọ ni ẹẹkan.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Rii daju pe a le jile lailewu.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Gbe data bunkun.
            {
                // Ṣe aye fun awọn eroja ji ni ọmọ ti o tọ.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Gbe awọn eroja lati ọmọ osi si apa ọtun.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Gbe bata ti o ji julọ julọ si obi.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Gbe bata iye-bọtini ti obi si ọmọ ti o tọ.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ṣe aye fun awọn ẹgbẹ ji.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ji egbegbe.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Oniye oniye ti `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Rii daju pe a le jile lailewu.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Gbe data bunkun.
            {
                // Gbe bata ti o ji julọ julọ si obi.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Gbe bata iye-bọtini ti obi si ọmọ osi.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Gbe awọn eroja lati ọmọ ọtun si apa osi.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Kun aafo nibiti awọn eroja ji ti lo lati wa.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ji egbegbe.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Kun aafo nibiti awọn egbegbe ti ji tẹlẹ ti wa.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Yọ eyikeyi alaye aimi ti o ni idaniloju pe oju ipade yii jẹ oju ipade `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Yọ eyikeyi alaye aimi tẹnumọ pe oju ipade yii jẹ oju ipade `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Awọn iṣayẹwo boya oju opo jẹ ipilẹ `Internal` tabi oju ipade `Leaf` kan.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Gbe suffix lẹhin `self` lati oju ipade kan si ọkan miiran.`right` gbọdọ ṣofo.
    /// edge akọkọ ti `right` ko wa ni iyipada.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Abajade ti ifibọ, nigbati ipade kan nilo lati faagun kọja agbara rẹ.
pub struct SplitResult<'a, K, V, NodeType> {
    // Apo ti a yipada ninu igi ti o wa pẹlu awọn eroja ati awọn ẹgbẹ ti o jẹ ti apa osi ti `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Diẹ ninu bọtini ati iye pin kuro, lati fi sii ni ibomiiran.
    pub kv: (K, V),
    // Ti o ni, ti ko ni asopọ, oju ipade tuntun pẹlu awọn eroja ati awọn ẹgbẹ ti o jẹ ti ọtun ti `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Boya awọn itọkasi node ti iru awin yii gba laaye lilọ kiri si awọn apa miiran ninu igi.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal kii ṣe aini, o ṣẹlẹ nipa lilo abajade ti `borrow_mut`.
        // Nipa didi ipa kọja, ati ṣiṣẹda awọn itọkasi tuntun si awọn gbongbo, a mọ pe gbogbo itọkasi ti iru `Owned` jẹ si oju ipade.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Awọn ifibọ iye kan sinu bibẹ pẹlẹbẹ ti awọn eroja ipilẹṣẹ ti o ni atẹle nipa eroja kan ti ko ni oye.
///
/// # Safety
/// Bibẹ ni diẹ sii ju awọn eroja `idx` lọ.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Yọ kuro ki o pada si iye kan lati ori nkan ti gbogbo awọn eroja ti a ṣe ipilẹ, ni fifi silẹ ọkan ti n tẹle nkan ti ko ni oye.
///
///
/// # Safety
/// Bibẹ ni diẹ sii ju awọn eroja `idx` lọ.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Yipada awọn eroja ni awọn ipo ege `distance` si apa osi.
///
/// # Safety
/// Bibẹ ni o kere ju awọn eroja `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Yi awọn eroja pada si awọn ipo `distance` pẹlẹbẹ si apa ọtun.
///
/// # Safety
/// Bibẹ ni o kere ju awọn eroja `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ngbe gbogbo awọn iye lati ori nkan ti awọn eroja ipilẹṣẹ si ege ti awọn eroja ti ko mọ, nlọ sile `src` bi gbogbo ainidi.
///
/// Awọn iṣẹ bi `dst.copy_from_slice(src)` ṣugbọn ko beere `T` lati jẹ `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;