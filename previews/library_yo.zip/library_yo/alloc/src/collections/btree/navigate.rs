use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Ni igba diẹ mu jade miiran, deede aiyipada ti iwọn kanna.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Wa awọn ẹgbẹ bunkun ọtọtọ ti o ṣe opin ibiti a ti pàtó ninu igi kan.
    /// Pada boya bata ti awọn kapa oriṣiriṣi sinu igi kanna tabi bata awọn aṣayan ofo.
    ///
    /// # Safety
    ///
    /// Ayafi ti `BorrowType` jẹ `Immut`, maṣe lo awọn kaakiri ẹda lati ṣe ibẹwo si KV kanna ni igba meji.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ni ibamu si `(root1.first_leaf_edge(), root2.last_leaf_edge())` ṣugbọn o munadoko diẹ sii.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Wa awọn ẹgbẹ ti bunkun bunkun ti o ni opin ibiti o kan pato ninu igi kan.
    ///
    /// Abajade jẹ itumọ nikan ti igi ba paṣẹ nipasẹ bọtini, bii igi ti o wa ninu `BTreeMap` jẹ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Aabo: oriṣi awin wa jẹ alaileṣe.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Wa awọn ẹgbẹ ti bunkun bunkun ni pipin gbogbo igi kan.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Pin itọkasi alailẹgbẹ sinu bata ti awọn egbegbe bunkun ti o ni opin ibiti a ti pàtó kan.
    /// Abajade jẹ awọn itọkasi ti kii ṣe alailẹgbẹ ti o fun laaye iyipada (some), eyiti o gbọdọ lo ni iṣọra.
    ///
    /// Abajade jẹ itumọ nikan ti igi ba paṣẹ nipasẹ bọtini, bii igi ti o wa ninu `BTreeMap` jẹ.
    ///
    ///
    /// # Safety
    /// Maṣe lo awọn kaamu ẹda lati ṣe ibẹwo si KV kanna ni igba meji.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Pin itọkasi alailẹgbẹ sinu bata ti awọn ẹgbẹ bunkun ti o ni opin ibiti kikun ti igi naa.
    /// Awọn esi ti wa ni ti kii-oto jo gbigba iyipada (ti iye nikan), ki gbọdọ ṣee lo pẹlu itoju.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // A ṣe ẹda NodeRef gbongbo nibi-a kii yoo ṣe ibẹwo si KV kanna lẹẹmeji, ati pe a ko ni pari pẹlu awọn itọkasi iye ti o pọ.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Pin itọkasi alailẹgbẹ sinu bata ti awọn ẹgbẹ bunkun ti o ni opin ibiti kikun ti igi naa.
    /// Awọn abajade naa jẹ awọn itọkasi ti kii ṣe alailẹgbẹ ti o fun laaye iyipada pupọ iparun, nitorina o gbọdọ lo pẹlu abojuto to ga julọ.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // A ṣe ẹda NodeRef gbongbo nibi-a kii yoo ni iwọle si ni ọna ti o fi awọn ifunmọ awọn itọkasi ti a gba lati gbongbo naa.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Fun bunkun edge bun kan, pada [`Result::Ok`] pẹlu mimu si KV aladugbo ni apa ọtun, eyiti o jẹ boya ni oju ipade kanna tabi ni oju ipade baba nla kan.
    ///
    /// Ti bunkun edge jẹ eyiti o kẹhin ninu igi, da [`Result::Err`] pada pẹlu oju ipade.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Fun bunkun edge bunkun kan, pada [`Result::Ok`] pẹlu mimu si KV aladugbo ni apa osi, eyiti o jẹ boya ni oju ipade kanna tabi ni oju ipade baba nla kan.
    ///
    /// Ti bunkun edge jẹ akọkọ ninu igi, da [`Result::Err`] pada pẹlu oju ipade.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ti a fun ni mu edge inu, pada [`Result::Ok`] pẹlu mimu si KV aladugbo ni apa ọtun, eyiti o jẹ boya ni oju ipade inu kanna tabi ni ipade baba nla kan.
    ///
    /// Ti edge ti inu jẹ ọkan ti o kẹhin ninu igi, da [`Result::Err`] pada pẹlu oju ipade.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ti a fun ni mu bunkun edge sinu igi ti o ku, o pada bunkun ti o tẹle edge ni apa ọtun, ati bata iye iye bọtini laarin, eyiti o jẹ boya ni oju ewe kanna, ni oju ipade baba nla kan, tabi ti ko si.
    ///
    ///
    /// Ọna yii tun ṣe ipinpo eyikeyi node(s) ti o de opin ti.
    /// Eyi tumọ si pe ti ko ba si iye-iye iye diẹ sii, gbogbo iyoku ti igi yoo ti ni ipinpin ati pe ko si ohunkan ti o ku lati pada.
    ///
    /// # Safety
    /// edge ti a fun ko gbọdọ ti pada tẹlẹ nipasẹ alabaṣepọ `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Fun bunkun edge ti o mu sinu igi ti o ku, o pada ewe ti o tẹle edge ni apa osi, ati iye iye bọtini ni aarin, eyiti o jẹ boya ni oju ewe kanna, ni oju ila baba nla kan, tabi ti ko si.
    ///
    ///
    /// Ọna yii tun ṣe ipinpo eyikeyi node(s) ti o de opin ti.
    /// Eyi tumọ si pe ti ko ba si iye-iye iye diẹ sii, gbogbo iyoku ti igi yoo ti ni ipinpin ati pe ko si ohunkan ti o ku lati pada.
    ///
    /// # Safety
    /// edge ti a fun ko gbọdọ ti pada tẹlẹ nipasẹ alabaṣepọ `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Deallocates opoplopo awọn apa lati bunkun soke si gbongbo.
    /// Eyi ni ọna kan ṣoṣo lati ṣe ipinku iyoku igi kan lẹhin ti `deallocating_next` ati `deallocating_next_back` ti nibbing ni ẹgbẹ mejeeji ti igi naa, ti wọn si ti lu edge kanna.
    /// Bi o ti pinnu nikan lati pe nigbati gbogbo awọn bọtini ati awọn iye ti pada, ko si afọmọ mọ lori eyikeyi awọn bọtini tabi awọn iye.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Rare mu mu bunkun edge si ewe ti o tẹle edge o si da awọn itọkasi si bọtini ati iye wa laarin.
    ///
    ///
    /// # Safety
    /// KV miiran gbọdọ wa ni itọsọna irin-ajo.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Rare mu mu bunkun edge si bunkun ti tẹlẹ edge o si da awọn itọkasi si bọtini ati iye wa laarin.
    ///
    ///
    /// # Safety
    /// KV miiran gbọdọ wa ni itọsọna irin-ajo.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Rare mu mu bunkun edge si ewe ti o tẹle edge o si da awọn itọkasi si bọtini ati iye wa laarin.
    ///
    ///
    /// # Safety
    /// KV miiran gbọdọ wa ni itọsọna irin-ajo.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ṣiṣe eyi kẹhin ni yiyara, ni ibamu si awọn aṣepari.
        kv.into_kv_valmut()
    }

    /// Rare mu mu bunkun edge si ewe ti tẹlẹ ki o pada awọn ifọkasi si bọtini ati iye laarin.
    ///
    ///
    /// # Safety
    /// KV miiran gbọdọ wa ni itọsọna irin-ajo.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ṣiṣe eyi kẹhin ni yiyara, ni ibamu si awọn aṣepari.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Rare mu mu bunkun edge si ewe ti o tẹle edge o si da bọtini ati iye pada laarin, ṣe ipinya eyikeyi oju eelo ti o fi silẹ lakoko ti o fi edge ti o baamu silẹ ni oju ipade obi rẹ.
    ///
    /// # Safety
    /// - KV miiran gbọdọ wa ni itọsọna irin-ajo.
    /// - Ti KV ko ni da pada tẹlẹ nipasẹ alabaṣiṣẹpọ `next_back_unchecked` lori eyikeyi ẹda awọn kapa ti a lo lati kọja igi naa.
    ///
    /// Ọna ailewu kan ṣoṣo lati tẹsiwaju pẹlu mimu imudojuiwọn ni lati ṣe afiwe rẹ, ju silẹ, pe ọna yii lẹẹkan si labẹ awọn ipo aabo rẹ, tabi pe alabaṣiṣẹpọ `next_back_unchecked` labẹ awọn ipo aabo rẹ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Rare mu mu bunkun edge si ewe ti tẹlẹ edge o si da bọtini ati iye pada laarin, ṣe ipinya eyikeyi oju eelo ti o fi silẹ lakoko ti o fi edge ti o baamu silẹ ninu oju ipade obi rẹ.
    ///
    /// # Safety
    /// - KV miiran gbọdọ wa ni itọsọna irin-ajo.
    /// - Ewe yẹn edge ko ni ipadabọ tẹlẹ nipasẹ alabaṣiṣẹpọ `next_unchecked` lori eyikeyi ẹda awọn kapa ti a lo lati kọja igi naa.
    ///
    /// Ọna ailewu kan ṣoṣo lati tẹsiwaju pẹlu mimu imudojuiwọn ni lati ṣe afiwe rẹ, ju silẹ, pe ọna yii lẹẹkan si labẹ awọn ipo aabo rẹ, tabi pe alabaṣiṣẹpọ `next_unchecked` labẹ awọn ipo aabo rẹ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Pada ewe kekere ti o wa ni apa osi edge sinu tabi labẹ oju ipade kan, ni awọn ọrọ miiran, edge ti o nilo ni akọkọ nigbati o ba nlọ kiri siwaju (tabi ti o kẹhin nigbati o nlọ kiri sẹhin).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Pada ewe kekere ti o dara julọ edge sinu tabi labẹ oju ipade, ni awọn ọrọ miiran, edge ti o nilo ni igbẹhin nigbati o nlọ kiri siwaju (tabi akọkọ nigbati o nlọ kiri sẹhin).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ṣabẹwo si awọn apa bunkun ati awọn KV inu ninu ọkọọkan awọn bọtini giga, ati tun ṣabẹwo si awọn apa inu bi odidi ninu ilana akọkọ ijinle, itumo pe awọn apa inu ti ṣaju KV kọọkan wọn ati awọn apa ọmọ wọn.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ṣe iṣiro nọmba awọn eroja inu igi (iha).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Pada ewe edge ti o sunmọ KV kan fun lilọ kiri siwaju.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Pada ewe edge ti o sunmọ to KV kan fun lilọ kiri sẹhin.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}