use core::intrinsics;
use core::mem;
use core::ptr;

/// Eyi rọpo iye lẹhin itọkasi iyasọtọ oto `v` nipa pipe iṣẹ ti o yẹ.
///
///
/// Ti panic kan ba waye ni pipade `change`, gbogbo ilana naa yoo yo.
#[allow(dead_code)] // tọju bi apejuwe ati fun lilo future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Eyi rọpo iye lẹhin itọka iyasọtọ `v` nipasẹ pipe iṣẹ ti o yẹ, ati dapada abajade ti o gba ni ọna.
///
///
/// Ti panic kan ba waye ni pipade `change`, gbogbo ilana naa yoo yo.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}