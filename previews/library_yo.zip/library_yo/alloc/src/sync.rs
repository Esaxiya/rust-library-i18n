#![stable(feature = "rust1", since = "1.0.0")]

//! Awọn itọka kika kika kika ailewu-ailewu.
//!
//! Wo iwe [`Arc<T>`][Arc] fun awọn alaye diẹ sii.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Ifilelẹ asọ lori iye awọn itọkasi ti o le ṣe si `Arc` kan.
///
/// Lilọ loke opin yii yoo ṣetọju eto rẹ (botilẹjẹpe kii ṣe dandan) ni awọn itọkasi _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ko ṣe atilẹyin awọn odi iranti.
// Lati yago fun awọn ijabọ rere eke ni imuse Arc/Alailagbara lo awọn ẹmu atomiki fun amuṣiṣẹpọ dipo.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Atọka kika kika-ailewu-tẹle.'Arc' duro fun 'Tika Atọka Atomiki'.
///
/// Iru `Arc<T>` n pese nini nini ti iye ti iru `T`, ti a pin ni okiti.Wiwa [`clone`][clone] lori `Arc` ṣe apẹẹrẹ `Arc` tuntun kan, eyiti o tọka si ipin kanna lori okiti bi orisun `Arc`, lakoko ti o npọ si kika itọkasi kan.
/// Nigbati ijuboluwole `Arc` ti o kẹhin si ipin ti a fifun ni parun, iye ti o fipamọ sinu ipin yẹn (ti a tọka si bi "inner value") tun ti lọ silẹ.
///
/// Awọn itọkasi ti a pin ni Rust yiyipada iyipada kuro ni aiyipada, ati pe `Arc` kii ṣe iyatọ: o ko le ni gbogbogbo gba itọkasi iyipada si nkan inu `Arc` kan.Ti o ba nilo lati yipada nipasẹ `Arc` kan, lo [`Mutex`][mutex], [`RwLock`][rwlock], tabi ọkan ninu awọn iru [`Atomic`][atomic].
///
/// ## Aabo okun
///
/// Kii [`Rc<T>`], `Arc<T>` nlo awọn iṣẹ atomiki fun kika kika rẹ.Eyi tumọ si pe o jẹ ailewu-tẹle-ara.Aṣiṣe ni pe awọn iṣẹ atomiki jẹ diẹ gbowolori ju awọn iraye iranti lasan lọ.Ti o ko ba pin awọn ipin ti a ka-itọkasi laarin awọn okun, ronu nipa lilo [`Rc<T>`] fun ori isalẹ.
/// [`Rc<T>`] jẹ aiyipada ailewu, nitori apejọ yoo mu eyikeyi igbiyanju lati firanṣẹ [`Rc<T>`] laarin awọn okun.
/// Sibẹsibẹ, ile-ikawe kan le yan `Arc<T>` lati fun awọn alabara ikawe ni irọrun diẹ sii.
///
/// `Arc<T>` yoo ṣe [`Send`] ati [`Sync`] niwọn igba ti `T` ṣe imuse [`Send`] ati [`Sync`].
/// Kini idi ti o ko le fi iru `T` ti ko ni okun-tẹle-ara ni `Arc<T>` lati jẹ ki o ni ailewu-tẹle-ara?Eyi le jẹ itara-inu diẹ ni akọkọ: lẹhinna, kii ṣe aaye ti ailewu ila `Arc<T>`?Bọtini naa ni eyi: `Arc<T>` jẹ ki o tẹle ara ailewu lati ni nini pupọ ti data kanna, ṣugbọn kii ṣe afikun ailewu o tẹle ara si data rẹ.
///
/// Ro `Arc <` [`RefCell<T>"]">".
/// [`RefCell<T>`] kii ṣe [`Sync`], ati pe ti `Arc<T>` ba jẹ [`Send`] nigbagbogbo, `Arc <` [`RefCell<T>`]`>`yoo jẹ bakanna.
/// Ṣugbọn lẹhinna a fẹ ni iṣoro kan:
/// [`RefCell<T>`] kii ṣe okun lailewu;o tọju ipa-ọna kika yiya nipa lilo awọn iṣẹ ti kii ṣe atomiki.
///
/// Ni ipari, eyi tumọ si pe o le nilo lati ṣe alawẹ-`Arc<T>` pẹlu iru iru [`std::sync`] kan, nigbagbogbo [`Mutex<T>`][mutex].
///
/// ## Awọn iyipo fifọ pẹlu `Weak`
///
/// Ọna [`downgrade`][downgrade] ni a le lo lati ṣẹda ijuboluwole [`Weak`] ti ko ni.O ijuboluwole [`Weak`] le jẹ [`igbesoke`][igbesoke] d si `Arc` kan, ṣugbọn eyi yoo pada [`None`] ti iye ti o fipamọ sinu ipin naa ba ti lọ silẹ tẹlẹ.
/// Ni gbolohun miran, `Weak` ifẹnule ko pa awọn iye inu awọn ipin láàyè;sibẹsibẹ, wọn *ṣe* tọju ipin naa (ile itaja atilẹyin fun iye) laaye.
///
/// Ayika kan laarin awọn atọka `Arc` kii yoo pin ni ibi rara.
/// Fun idi eyi, a lo [`Weak`] lati fọ awọn iyika.Fun apẹẹrẹ, igi kan le ni awọn itọka `Arc` ti o lagbara lati awọn apa obi si awọn ọmọde, ati awọn atọka [`Weak`] lati ọdọ awọn ọmọde pada si awọn obi wọn.
///
/// # Awọn itọkasi awọ
///
/// Ṣiṣẹda itọkasi tuntun lati ọdọ ijuboluwo ti a ka kika ti o wa tẹlẹ ni a ṣe nipa lilo `Clone` trait ti a ṣe fun [`Arc<T>`][Arc] ati [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Awọn sintasi meji ti o wa ni isalẹ jẹ deede.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, ati foo jẹ gbogbo Awọn Arcs ti o tọka si ipo iranti kanna
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` awọn iforukọsilẹ laifọwọyi si `T` (nipasẹ [`Deref`][deref] trait), nitorinaa o le pe awọn ọna T`lori iye ti iru `Arc<T>`.Lati yago fun awọn ijakadi orukọ pẹlu awọn ọna`T`, awọn ọna ti `Arc<T>` funrararẹ jẹ awọn iṣẹ to somọ, ti a pe ni lilo [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// Arc<T>Awọn imuṣẹ ti traits bii `Clone` le tun pe ni lilo sintasi ti o pe ni kikun.
/// Diẹ ninu awọn eniyan fẹran lati lo ilana itọsẹ ti o ni kikun, lakoko ti awọn miiran fẹran lilo sintasi ọna-ipe.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Iṣeduro ipe-ọna
/// let arc2 = arc.clone();
/// // Iṣeduro ti o ni kikun
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ko ṣe iforukọsilẹ-aifọwọyi si `T`, nitori iye ti inu le ti lọ silẹ tẹlẹ.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Pinpin diẹ ninu awọn alaye ti ko le yipada laarin awọn okun:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Akiyesi pe a **maṣe** ṣiṣe awọn idanwo wọnyi nibi.
// Awọn ọmọle windows ko ni inudidun pupọ ti okun kan ba kọja okun akọkọ ati lẹhinna jade ni akoko kanna (nkan ti o ku) nitorinaa a kan yago fun eyi patapata nipasẹ ṣiṣisẹ awọn idanwo wọnyi.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Pinpin [`AtomicUsize`] ti o le yipada:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Wo awọn [`rc` documentation][rc_examples] fun diẹ ẹ sii apeere ti itọkasi kika ni apapọ.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` jẹ ẹya ti [`Arc`] ti o mu itọkasi ti kii ṣe nini si ipin ti a ṣakoso.
/// Ti wọle ipin naa nipa pipe [`upgrade`] lori ijuboluwole `Weak`, eyiti o pada [`Aṣayan]]` <`[` Arc`]]`<T>>
///
/// Niwọn igba ti itọkasi `Weak` ko ka si nini, kii yoo ṣe idiwọ iye ti o fipamọ sinu ipin naa silẹ, ati pe `Weak` funrararẹ ko ṣe awọn onigbọwọ nipa iye ti o tun wa.
///
/// Bayi o le da [`None`] pada nigbati [`igbesoke`] d.
/// Akiyesi sibẹsibẹ pe itọkasi `Weak`*ṣe* ṣe idiwọ ipin ipin funrararẹ (ile itaja atilẹyin) lati pin ni ipin.
///
/// Atọka `Weak` kan wulo fun titọju itọkasi igba diẹ si ipin ti a ṣakoso nipasẹ [`Arc`] laisi idilọwọ iye inu rẹ lati ju silẹ.
/// O tun lo lati ṣe idiwọ awọn itọkasi iyipo laarin awọn itọka [`Arc`], nitori awọn itọkasi nini ti ara ẹni kii yoo gba laaye boya [`Arc`] lọ silẹ.
/// Fun apẹẹrẹ, igi kan le ni awọn itọka [`Arc`] ti o lagbara lati awọn apa obi si awọn ọmọde, ati awọn atọka `Weak` lati ọdọ awọn ọmọ pada si awọn obi wọn.
///
/// Ọna aṣoju lati gba ijuboluwole `Weak` ni lati pe [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Eyi jẹ `NonNull` lati gba laaye iṣapeye iwọn ti iru yii ni awọn enum, ṣugbọn kii ṣe itọka to tọ.
    //
    // `Weak::new` ṣeto eyi si `usize::MAX` ki o ko nilo lati pin aaye lori okiti naa.
    // Iyẹn kii ṣe iye ti ijuboluwo gidi kan yoo ni nitori RcBox ni titete ni o kere ju 2.
    // Eyi ṣee ṣe nikan nigbati `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Eyi ni repr(C) si ẹri future lodi si atunṣe-pada aaye, eyiti yoo dabaru pẹlu bibẹkọ ti [into|from]_raw() ailewu ti awọn oriṣi gbigbe to ṣee gbe.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // iye usize::MAX n ṣiṣẹ bi apinfunni fun igba diẹ "locking" agbara lati ṣe igbesoke awọn itọka ailagbara tabi dinku awọn ti o lagbara;eyi ni a lo lati yago fun awọn ije ni `make_mut` ati `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Ṣe `Arc<T>` tuntun kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Bẹrẹ ka ijuboluwole ijuboluwole bi 1 eyiti o jẹ ijuboluwole ti ko lagbara ti o waye nipasẹ gbogbo awọn atọka to lagbara (kinda), wo std/rc.rs fun alaye diẹ sii
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Ṣe `Arc<T>` tuntun ni lilo itọkasi ailagbara si ara rẹ.
    /// Igbidanwo lati ṣe igbesoke itọkasi alailagbara ṣaaju iṣẹ yii pada yoo mu ki iye `None` kan wa.
    /// Sibẹsibẹ, itọkasi alailagbara le jẹ cloned larọwọto ati fipamọ fun lilo ni akoko nigbamii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ṣe akojọpọ inu ni ipo "uninitialized" pẹlu itọkasi alailagbara kan.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // O ṣe pataki ki a maṣe fi ohun-ini silẹ ti ijuboluwo ailagbara, tabi bẹẹkọ iranti le ni ominira nipasẹ akoko `data_fn` ti o pada.
        // Ti a ba fẹ gaan lati kọja nini, a le ṣẹda atokun alailagbara afikun fun ara wa, ṣugbọn eyi yoo ja si awọn afikun awọn imudojuiwọn si kika itọkasi ailagbara eyiti o le ma ṣe pataki bibẹẹkọ.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Bayi a le ṣe ipilẹṣẹ iye ti inu daradara ki o yi iyika ailagbara wa sinu itọkasi to lagbara.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Kọ loke si aaye data gbọdọ han si eyikeyi awọn okun eyiti o ṣe akiyesi kika agbara ti kii-odo.
            // Nitorinaa a nilo o kere ju aṣẹ "Release" lati le muuṣiṣẹpọ pẹlu `compare_exchange_weak` ni `Weak::upgrade`.
            //
            // "Acquire" ibere ko nilo.
            // Nigbati a ba ṣe akiyesi awọn ihuwasi ti o ṣeeṣe ti `data_fn` a nilo nikan lati wo ohun ti o le ṣe pẹlu itọkasi si `Weak` ti kii ṣe igbesoke:
            //
            // - O le *ẹda oniye*`Weak` naa, jijẹ kika itọkasi alailagbara.
            // - O le sọ awọn ere ibeji silẹ, dinku kika itọkasi alailagbara (ṣugbọn kii ṣe si odo).
            //
            // Awọn ipa ẹgbẹ wọnyi ko ni ipa lori wa ni eyikeyi ọna, ati pe ko si awọn ipa ẹgbẹ miiran ti o ṣee ṣe pẹlu koodu ailewu nikan.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Awọn itọkasi to lagbara yẹ ki o jọ ni itọkasi alailagbara pipin, nitorinaa maṣe ṣiṣe apanirun fun itọkasi atijọ wa.
        //
        mem::forget(weak);
        strong
    }

    /// Ṣe `Arc` tuntun pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Oro titun kan `Arc` pẹlu uninitialized akoonu ti, pẹlu awọn iranti ni kún pẹlu `0` baiti.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ṣe `Pin<Arc<T>>` tuntun kan.
    /// Ti o ba ti `T` ko ni se `Unpin`, ki o si `data` yoo wa ni pinned ni iranti ati ki o lagbara to ṣee gbe.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Ṣe `Arc<T>` tuntun kan, dapada aṣiṣe kan ti ipin ba kuna.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Bẹrẹ ka ijuboluwole ijuboluwole bi 1 eyiti o jẹ ijuboluwole ti ko lagbara ti o waye nipasẹ gbogbo awọn atọka to lagbara (kinda), wo std/rc.rs fun alaye diẹ sii
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Ṣe `Arc` tuntun pẹlu awọn akoonu ti ko ni oye, dapada aṣiṣe kan ti ipin ba kuna.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ṣe `Arc` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`, dapada aṣiṣe kan ti ipin ba kuna.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Pada iye inu, ti `Arc` ba ni itọkasi itọkasi to lagbara kan.
    ///
    /// Bibẹẹkọ, [`Err`] ti pada pẹlu `Arc` kanna ti o kọja.
    ///
    ///
    /// Eyi yoo ṣaṣeyọri paapaa ti awọn itọkasi ailagbara titayọ wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Ṣe ijuboluwole alailagbara lati nu itọkasi pipe-lagbara
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ṣe gige ege-ka atomiki tuntun ti a ka pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Ṣe gige ege tuntun ti a tọka atomiki-pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Awọn to `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe iye ti inu wa gaan ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Awọn iyipada si `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe iye ti inu wa gaan ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Je `Arc` run, n pada ijuboluwole ti a we.
    ///
    /// Lati yago fun jo iranti ijuboluwole gbọdọ wa ni iyipada pada si `Arc` nipa lilo [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pese ijuboluwole ijuboluwole si data naa.
    ///
    /// Awọn kika ko ni ipa ni eyikeyi ọna ati pe `Arc` ko run.
    /// Atọka naa wulo fun igba ti awọn iṣiro to lagbara ninu `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // Aabo: Eyi ko le kọja nipasẹ Deref::deref tabi RcBoxPtr::inner nitori
        // eyi ni a nilo lati ṣe idaduro imudaniloju raw/mut bii apẹẹrẹ
        // `get_mut` le kọ nipasẹ ijuboluwole lẹhin ti Rc ti gba pada nipasẹ `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Ṣe `Arc<T>` kan lati ọdọ ijuboluwo to aise.
    ///
    /// Atọka aise gbọdọ ti ni iṣaaju nipasẹ ipe si [`Arc<U>::into_raw`][into_raw] nibiti `U` gbọdọ ni iwọn kanna ati titọ bi `T`.
    /// Eyi jẹ otitọ bintin ti `U` jẹ `T`.
    /// Akiyesi pe ti `U` kii ṣe `T` ṣugbọn o ni iwọn kanna ati titete, eyi jẹ ipilẹ bi awọn itọkasi gbigbejade ti awọn oriṣiriṣi oriṣi.
    /// Wo [`mem::transmute`][transmute] fun alaye diẹ sii lori awọn ihamọ wo lo ninu ọran yii.
    ///
    /// Olumulo ti `from_raw` ni lati rii daju pe iye kan pato ti `T` nikan silẹ lẹẹkan.
    ///
    /// Iṣẹ yii ko ni aabo nitori lilo aibojumu le ja si ailewu ailewu, paapaa ti `Arc<T>` ti o pada ko wọle rara.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pada pada si `Arc` lati yago fun jijo.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Awọn ipe siwaju si `Arc::from_raw(x_ptr)` yoo jẹ ailewu-iranti.
    /// }
    ///
    /// // Iranti naa ti ni ominira nigbati `x` ti jade ni aaye ti o wa loke, nitorinaa `x_ptr` ti nsaba bayi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Yiyipada aiṣedeede lati wa atilẹba ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ṣẹda ijuboluwole [`Weak`] tuntun si ipin yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Itura yii jẹ O DARA nitori a n ṣayẹwo iye ni CAS ni isalẹ.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ṣayẹwo ti o ba jẹ alatako alailagbara Lọwọlọwọ "locked";ti o ba ti bẹ, omo.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: koodu yii kọju iṣeeṣe ti iṣanju lọwọlọwọ
            // sinu usize::MAX;ni gbogbogbo Rc ati Arc nilo lati ṣatunṣe lati ba ibajẹ pọ.
            //

            // Kii pẹlu Clone(), a nilo eyi lati jẹ kika Gba lati muuṣiṣẹpọ pẹlu kikọ ti o nbọ lati `is_unique`, ki awọn iṣẹlẹ ṣaaju iṣaaju kikọ naa ṣẹlẹ ṣaaju kika yii.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Rii daju a ko ṣẹda a purpili lagbara
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Gba nọmba ti awọn itọka [`Weak`] si ipin yii.
    ///
    /// # Safety
    ///
    /// Ọna yii funrararẹ jẹ ailewu, ṣugbọn lilo rẹ ni deede nilo itọju afikun.
    /// O tẹle miiran le yi iyipada kaakiri ailera nigbakugba, pẹlu agbara laarin pipe ọna yii ati ṣiṣe lori abajade.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Itọkasi yii jẹ ipinnu nitori a ko pin `Arc` tabi `Weak` laarin awọn okun.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ti o ba ka iye ailagbara lọwọlọwọ, iye ti kika naa jẹ 0 ṣaaju gbigba titiipa.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Gba nọmba ti awọn itọka (`Arc`) lagbara si ipin yii.
    ///
    /// # Safety
    ///
    /// Ọna yii funrararẹ jẹ ailewu, ṣugbọn lilo rẹ ni deede nilo itọju afikun.
    /// O tẹle ara miiran le yi iyipada ka lagbara nigbakugba, pẹlu agbara laarin pipe ọna yii ati ṣiṣe lori abajade.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Itọkasi yii jẹ ipinnu nitori a ko pin `Arc` laarin awọn okun.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Awọn alekun kika itọkasi lagbara lori `Arc<T>` ti o ni nkan ṣe pẹlu itọka ti a pese nipasẹ ọkan.
    ///
    /// # Safety
    ///
    /// A gbọdọ gba ijuboluwole nipasẹ `Arc::into_raw`, ati apeere `Arc` ti o ni ibatan gbọdọ jẹ deede (ie
    /// ka lagbara gbọdọ jẹ o kere ju 1) fun iye akoko ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Itọkasi yii jẹ ipinnu nitori a ko pin `Arc` laarin awọn okun.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Ṣe idaduro Arc, ṣugbọn maṣe fi ọwọ kan atunṣe nipasẹ ipari si ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Bayi mu afikun sii, ṣugbọn maṣe sọ atunyẹwo titun boya
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Awọn ipinnu ipinnu kika to lagbara lori `Arc<T>` ti o ni nkan ṣe pẹlu itọka ti a pese nipasẹ ọkan.
    ///
    /// # Safety
    ///
    /// A gbọdọ gba ijuboluwole nipasẹ `Arc::into_raw`, ati apeere `Arc` ti o ni ibatan gbọdọ jẹ deede (ie
    /// ka lagbara gbọdọ jẹ o kere ju 1) nigbati o ba n pe ọna yii.
    /// Ọna yii le ṣee lo lati tu silẹ `Arc` ikẹhin ati ipamọ ifipamọ, ṣugbọn **ko yẹ ki o pe** lẹhin ti o ti tu `Arc` ikẹhin silẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Awọn idaniloju wọnyi jẹ ipinnu nitori a ko pin `Arc` laarin awọn okun.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ailewu yii dara nitori pe lakoko ti aaki yii wa laaye a ni idaniloju pe ijuboluwole inu jẹ wulo.
        // Siwaju si, a mọ pe ilana `ArcInner` funrararẹ jẹ `Sync` nitori data inu jẹ `Sync` bakanna, nitorinaa a dara lati ya awin ijuboluwo ti ko ni iyipada si awọn akoonu wọnyi.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ti kii ṣe ilana ilana ti `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Pa data run ni akoko yii, botilẹjẹpe a le ma ṣe ipin ipin apoti funrararẹ (awọn itọka ailagbara le tun wa ti o wa ni ayika).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Ju atunṣe alailera silẹ ni apapọ nipasẹ gbogbo awọn itọkasi to lagbara
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Pada `true` ti o ba jẹ pe `Arc`s meji naa tọka si ipin kanna (ni iṣọn ti o jọ [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Yipada `ArcInner<T>` kan pẹlu aaye ti o to fun iye ti inu ti o ṣee-ko ṣe iwọn nibiti iye ti ni ipilẹ ti a pese.
    ///
    /// Iṣẹ `mem_to_arcinner` ni a pe pẹlu ijuboluwo data ati pe o gbọdọ pada apilẹkọ kan (ti o ni agbara ti o sanra) fun `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Ṣe iṣiro ipilẹ nipa lilo ifilelẹ iye ti a fun.
        // Ni iṣaaju, a ṣe iṣiro akọkọ lori ikosile `&*(ptr as* const ArcInner<T>)`, ṣugbọn eyi ṣẹda itọkasi ti ko tọ (wo #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Pin `ArcInner<T>` kan pẹlu aaye ti o to fun iye ti inu ti o ṣee-ko ṣe iwọn nibiti iye ti ni ipilẹ ti a pese, dapada aṣiṣe kan ti ipin ba kuna.
    ///
    ///
    /// Iṣẹ `mem_to_arcinner` ni a pe pẹlu ijuboluwo data ati pe o gbọdọ pada apilẹkọ kan (ti o ni agbara ti o sanra) fun `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Ṣe iṣiro ipilẹ nipa lilo ifilelẹ iye ti a fun.
        // Ni iṣaaju, a ṣe iṣiro akọkọ lori ikosile `&*(ptr as* const ArcInner<T>)`, ṣugbọn eyi ṣẹda itọkasi ti ko tọ (wo #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Ni ipilẹṣẹ ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Pín ohun `ArcInner<T>` pẹlu aaye ti o to fun iye ti inu ti ko ni iwọn.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Pin fun `ArcInner<T>` nipa lilo iye ti a fun.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Daakọ iye bi awọn baiti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Gba ipinfunni laaye laisi sisọ awọn akoonu rẹ silẹ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Pin `ArcInner<[T]>` kan pẹlu ipari ti a fifun.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Daakọ awọn eroja lati ori nkan sinu Arc ti a pin sita tuntun <\[T\]>
    ///
    /// Ailewu nitori olupe gbọdọ boya gba nini tabi di `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ṣe `Arc<[T]>` kan lati aṣetunṣe ti a mọ lati jẹ iwọn kan.
    ///
    /// Ihuwasi jẹ aisọye yẹ ki iwọn jẹ aṣiṣe.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Olutọju Panic lakoko ti o ṣe amọda awọn eroja T.
        // Ni iṣẹlẹ ti panic, awọn eroja ti a ti kọ sinu ArcInner tuntun yoo ju silẹ, lẹhinna iranti ti ni ominira.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Atọka si akọkọ ano
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gbogbo ko o.Gbagbe oluso naa ki o ko gba ArcInner tuntun laaye.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait ti a lo fun `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Ṣe ẹda oniye ti ijuboluwole `Arc`.
    ///
    /// Eyi ṣẹda ijuboluwo miiran si ipin kanna, jijẹ kika itọkasi lagbara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Lilo pipaṣẹ ihuwasi jẹ dara nibi, bi imọ ti itọkasi atilẹba ṣe idiwọ awọn okun miiran lati ṣe aṣiṣe paarẹ nkan naa.
        //
        // Gẹgẹbi a ti ṣalaye ninu [Boost documentation][1], Pipọsi iwe itọkasi le ṣee ṣe nigbagbogbo pẹlu memory_order_relaxed: Awọn itọkasi tuntun si nkan le ṣee ṣe nikan lati itọkasi ti o wa tẹlẹ, ati gbigbe itọkasi tẹlẹ lati okun kan si omiiran gbọdọ ti pese tẹlẹ amuṣiṣẹpọ ti a beere.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Sibẹsibẹ a nilo lati ṣọ lodi si awọn atunṣe nla bi o ba jẹ pe ẹnikan ni `mem: : gbagbe Arcs.
        // Ti a ko ba ṣe eyi kika naa le ṣan ati awọn olumulo yoo lo-lẹhin ọfẹ.
        // A jẹ ẹyẹ kẹlẹkẹlẹ si `isize::MAX` lori ero pe ko si awọn okun ~2 bilionu ti o npọ si kika itọkasi lẹẹkan.
        //
        // branch yii kii yoo gba ni eyikeyi eto to daju.
        //
        // A yọ kuro nitori iru eto bẹẹ jẹ ibajẹ iyalẹnu, ati pe a ko fiyesi lati ṣe atilẹyin fun.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Ṣe itọkasi iyipada si `Arc` ti a fun.
    ///
    /// Ti awọn atọka `Arc` tabi [`Weak`] miiran wa si ipin kanna, lẹhinna `make_mut` yoo ṣẹda ipin tuntun kan ati pe [`clone`][clone] lori iye inu lati rii daju nini nini alailẹgbẹ.
    /// Eyi tun tọka si bi ẹda-on-kọ.
    ///
    /// Ṣe akiyesi pe eyi yatọ si ihuwasi ti [`Rc::make_mut`] eyiti o ṣe ipinya eyikeyi awọn itọka `Weak` ti o ku.
    ///
    /// Wo tun [`get_mut`][get_mut], eyiti yoo kuna kuku ju ẹda oniye.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Yoo ko oniye ohunkohun
    /// let mut other_data = Arc::clone(&data); // Yoo ko oniye data inu
    /// *Arc::make_mut(&mut data) += 1;         // Clones data inu
    /// *Arc::make_mut(&mut data) += 1;         // Yoo ko oniye ohunkohun
    /// *Arc::make_mut(&mut other_data) *= 2;   // Yoo ko oniye ohunkohun
    ///
    /// // Bayi `data` ati `other_data` tọka si awọn ipin oriṣiriṣi.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Akiyesi pe a mu mejeeji itọkasi to lagbara ati itọkasi alailagbara.
        // Nitorinaa, itusilẹ itọkasi itọkasi wa nikan kii yoo, funrararẹ, fa ki iranti wa ni pinpin.
        //
        // Lo Gba lati rii daju pe a rii eyikeyi kikọ si `weak` ti o ṣẹlẹ ṣaaju itusilẹ kikọ (ie, awọn idinku) si `strong`.
        // Niwọn igba ti a gba iye ailagbara kan, ko si aye kankan ti ArcInner funrararẹ le ni pinpin.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ojuami to lagbara miiran wa, nitorinaa a gbọdọ jẹ ẹda oniye.
            // Ṣaaju-fi iranti silẹ lati gba kikọ iye oniye taara.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Isunmi ti o ni isimi ni eyi ti o wa loke nitori eyi jẹ ipilẹ ti o dara julọ: a n ṣe ere-ije nigbagbogbo pẹlu awọn itọka ailagbara ti o lọ silẹ.
            // Ọran ti o buru julọ, a pari ipinpin Arc tuntun lainidi.
            //

            // A yọ atunṣe to lagbara ti o kẹhin, ṣugbọn awọn afikun awọn atunṣe ti ko lagbara wa ti o ku.
            // A yoo gbe awọn akoonu naa si Arc tuntun kan, ki o sọ di asan awọn atunṣe alailagbara miiran.
            //

            // Akọsilẹ wipe o ni ko ṣee ṣe fun awọn kika ti `weak` lati ikore usize::MAX (ie, ni titiipa), niwon awọn lagbara ka le nikan wa ni titiipa nipa a tẹle pẹlu kan to lagbara itọkasi.
            //
            //

            // Ṣe apẹrẹ ijuboluwo alailagbara ti ara wa, ki o le sọ ArcInner di mimọ bi o ti nilo.
            //
            let _weak = Weak { ptr: this.ptr };

            // Le kan ji data naa, gbogbo ohun ti o ku ni Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // A jẹ itọkasi ẹri ti boya iru;ijalu ṣe afẹyinti kika kika to lagbara.
            //
            this.inner().strong.store(1, Release);
        }

        // Bii `get_mut()`, ailewu naa dara nitori pe itọkasi wa jẹ boya alailẹgbẹ lati bẹrẹ pẹlu, tabi di ọkan lori ṣiṣii awọn akoonu naa.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Pada itọkasi iyipada sinu `Arc` ti a fun, ti ko ba si awọn itọka `Arc` miiran tabi [`Weak`] si ipin kanna.
    ///
    ///
    /// Pada [`None`] bibẹkọ, nitori ko ṣe ailewu lati yi iye ti o pin pada.
    ///
    /// Wo tun [`make_mut`][make_mut], eyiti yoo [`clone`][clone] iye inu nigbati awọn itọka miiran wa.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ailewu yii dara nitori a ni idaniloju pe ijuboluwole ti o pada ni itọka *nikan* ti yoo tun pada si T.
            // Nọmba itọkasi wa ni idaniloju lati jẹ 1 ni aaye yii, ati pe a nilo Arc funrararẹ lati jẹ `mut`, nitorinaa a pada tọka nikan ti o le ṣee ṣe si data inu.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Pada itọkasi iyipada kan sinu `Arc` ti a fun, laisi ayẹwo eyikeyi.
    ///
    /// Wo tun [`get_mut`], eyiti o jẹ ailewu ati pe o ṣe awọn sọwedowo ti o yẹ.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Eyikeyi awọn itọka `Arc` tabi [`Weak`] miiran si ipin kanna ko gbọdọ ṣe igbasilẹ fun iye akoko awin ti o pada.
    ///
    /// Eyi jẹ ọrọ kekere ti ko ba si iru awọn atọka tẹlẹ, fun apẹẹrẹ lẹsẹkẹsẹ lẹhin `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // A ṣọra lati *ma ṣe* ṣẹda itọkasi kan ti o bo awọn aaye "count", nitori eyi yoo jẹ inagijẹ pẹlu iraye si igbakanna si awọn nọmba itọkasi (fun apẹẹrẹ.
        // nipasẹ `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Pinnu boya eyi ni itọkasi alailẹgbẹ (pẹlu awọn atunyẹwo ailera) si data ipilẹ.
    ///
    ///
    /// Akiyesi pe eyi nilo titiipa kika atunṣe ailera.
    fn is_unique(&mut self) -> bool {
        // tii ka ijuboluwole ti ko lagbara ti a ba han pe o jẹ alatako ijuboluwo ti ko lagbara.
        //
        // Ami ami gba nibi ni idaniloju iṣẹlẹ-ṣaaju ibasepọ pẹlu eyikeyi kikọ si `strong` (ni pataki ni `Weak::upgrade`) ṣaaju awọn idinku ti kika `weak` (nipasẹ `Weak::drop`, eyiti o lo itusilẹ).
        // Ti Ref ailagbara ti igbesoke ko ba silẹ rara, CAS nibi yoo kuna nitorinaa a ko fiyesi lati muuṣiṣẹpọ.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Eyi nilo lati jẹ `Acquire` lati muuṣiṣẹpọ pẹlu idinku ti kika `strong` ni `drop`-iraye nikan ti o ṣẹlẹ nigbati eyikeyi ṣugbọn itọkasi ikẹhin ti wa ni silẹ.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Tu silẹ nibi ṣiṣẹpọ pẹlu kika ni `downgrade`, ni idiwọ idiwọ kika loke ti `strong` lati ṣẹlẹ lẹhin kikọ.
            //
            //
            self.inner().weak.store(1, Release); // tu titiipa
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Silẹ `Arc`.
    ///
    /// Eyi yoo dinku iye itọkasi itọkasi.
    /// Ti ka itọkasi itọkasi lagbara ba de odo odo lẹhinna awọn itọkasi miiran (ti o ba jẹ eyikeyi) ni [`Weak`], nitorinaa a jẹ `drop` iye inu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ko tẹ ohunkohun
    /// drop(foo2);   // Awọn titẹ "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Nitori `fetch_sub` ti jẹ atomiki tẹlẹ, a ko nilo lati muuṣiṣẹpọ pẹlu awọn okun miiran ayafi ti a yoo paarẹ ohun naa.
        // Ilana kanna ni o kan `fetch_sub` ti o wa ni isalẹ si kika `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // O nilo odi yii lati yago fun atunṣe ti lilo data ati piparẹ data naa.
        // Nitori pe o ti samisi `Release`, idinku ti kika kika muṣiṣẹpọ pẹlu odi `Acquire` yii.
        // Eyi tumọ si pe lilo data naa ṣaaju ki o to dinku kika itọkasi, eyiti o ṣẹlẹ ṣaaju odi yii, eyiti o ṣẹlẹ ṣaaju piparẹ data naa.
        //
        // Gẹgẹbi a ti ṣalaye ninu [Boost documentation][1],
        //
        // > O ṣe pataki lati lagabara eyikeyi wiwọle ti o ṣeeṣe si nkan ni ọkan
        // > okun (nipasẹ itọkasi ti o wa tẹlẹ) lati *ṣẹlẹ ṣaaju* piparẹ
        // > nkan ti o wa ni okun ti o yatọ.Eyi ni aṣeyọri nipasẹ "release" kan
        // > isẹ lẹhin sisọ itọkasi kan (eyikeyi iraye si nkan naa
        // > nipasẹ itọkasi yii gbọdọ han gbangba ṣẹlẹ ṣaaju), ati ẹya
        // > "acquire" isẹ ṣaaju piparẹ nkan naa.
        //
        // Ni pataki, lakoko ti awọn akoonu ti Arc jẹ igbagbogbo ti kii ṣe iyipada, o ṣee ṣe lati ni kikọ inu inu si nkan bi Mutex<T>.
        // Niwọn igba ti a ko ti gba Mutex nigbati o paarẹ, a ko le gbekele ọgbọn imuṣiṣẹpọ rẹ lati ṣe awọn kikọ ni okun A han si apanirun ti o nṣiṣẹ ni okun B.
        //
        //
        // Tun ṣe akiyesi pe Acquire odi nibi le ṣee rọpo pẹlu ẹrù Gba, eyiti o le mu ilọsiwaju dara si awọn ipo ti o ni ija pupọ.Wo [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Igbiyanju lati sọ isalẹ `Arc<dyn Any + Send + Sync>` si iru nja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ṣe `Weak<T>` tuntun kan, laisi sọtọ eyikeyi iranti.
    /// Pipe [`upgrade`] lori iye ipadabọ nigbagbogbo fun [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Iru oluranlọwọ lati gba laaye wọle si awọn iṣiro itọkasi laisi ṣiṣe awọn idaniloju eyikeyi nipa aaye data.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Pada ijuboluwo aise si nkan `T` ti `Weak<T>` toka si.
    ///
    /// Awọn ijuboluwole wulo nikan ti o ba ti nibẹ ni o wa diẹ ninu awọn lagbara to jo.
    /// Atọka le jẹ purpili, aiṣedede tabi paapaa [`null`] bibẹẹkọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Awọn mejeeji tọka si ohun kanna
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Alagbara nibi n jẹ ki o wa laaye, nitorinaa a tun le wọle si nkan naa.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ṣugbọn kii ṣe diẹ sii.
    /// // A le ṣe weak.as_ptr(), ṣugbọn iraye si ijuboluwole yoo yorisi ihuwasi ti a ko ṣalaye.
    /// // assert_eq! ("hello", ailewu {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ti o ba ti ijuboluwole ti wa ni purpili, a pada awọn Sentinel taara.
            // Eyi ko le jẹ adirẹsi isanwo isanwo to wulo, bi isanwo isanwo ni o kere ju ti o baamu bi ArcInner (usize).
            ptr as *const T
        } else {
            // Aabo: ti is_dangling ba pada jẹ eke, lẹhinna ijuboluwole jẹ igbasilẹ.
            // O le jẹ ki isanwo sisan silẹ ni aaye yii, ati pe a ni lati ṣetọju imudaniloju, nitorinaa lo ifọwọyi ijuboluwole aise.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Gba `Weak<T>` run o si sọ di ijuboluwole aise.
    ///
    /// Eyi ṣe iyipada ijuboluwole alailera sinu ijuboluwole aise, lakoko ti o tọju ẹtọ ti nini itọkasi kan ti ko lagbara (iye ailagbara ko ni atunṣe nipasẹ iṣiṣẹ yii).
    /// O le yipada si `Weak<T>` pẹlu [`from_raw`].
    ///
    /// Awọn ihamọ kanna ti iraye si afojusun ti ijuboluwole bi pẹlu [`as_ptr`] lo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Awọn oluyipada ijuboluwole ti a ṣẹda tẹlẹ nipasẹ [`into_raw`] pada si `Weak<T>`.
    ///
    /// Eyi le ṣee lo lati ni itọkasi itọkasi lailewu (nipa pipe [`upgrade`] nigbamii) tabi lati pin ipin kaakiri ailera nipasẹ sisọ `Weak<T>` silẹ.
    ///
    /// O gba nini ti itọkasi alailagbara kan (pẹlu ayafi awọn atọka ti a ṣẹda nipasẹ [`new`], nitori iwọnyi ko ni ohunkohun; ọna naa tun n ṣiṣẹ lori wọn).
    ///
    /// # Safety
    ///
    /// Atọka gbọdọ ti ipilẹṣẹ lati [`into_raw`] ati pe o tun gbọdọ ni itọkasi itọkasi agbara rẹ.
    ///
    /// A gba ọ laaye fun kika to lagbara lati jẹ 0 ni akoko pipe eyi.
    /// Sibẹsibẹ, eyi gba nini ti itọkasi alailagbara kan ti o ni aṣoju lọwọlọwọ bi ijuboluwọn aise (iye ailagbara ko ni atunṣe nipasẹ iṣiṣẹ yii) ati nitorinaa o gbọdọ ṣe pọ pọ pẹlu ipe ti tẹlẹ si [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement kẹhin ka ka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Wo Weak::as_ptr fun o tọ lori bi o ti jẹ ki ijuboluwole kikọ sii.

        let ptr = if is_dangling(ptr as *mut T) {
            // Eyi jẹ ailagbara purọ.
            ptr as *mut ArcInner<T>
        } else {
            // Bibẹẹkọ, a ni idaniloju pe ijuboluwole wa lati Alailera ti ko ni wahala.
            // Aabo: data_offset jẹ ailewu lati pe, bi awọn itọkasi ptr gidi (eyiti o le lọ silẹ) T.
            let offset = unsafe { data_offset(ptr) };
            // Bayi, a yiyipada aiṣedeede lati gba gbogbo RcBox.
            // Aabo: ijuboluwo naa ti ipilẹṣẹ lati Alailagbara kan, nitorinaa aiṣedeede yii jẹ ailewu.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // Aabo: a ti gba atunyẹwo atilẹba Alailagbara akọkọ, nitorinaa o le ṣẹda Alailera naa.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Awọn igbiyanju lati ṣe igbesoke ijuboluwole `Weak` si [`Arc`] kan, idaduro fifipamọ iye inu ti o ba ṣaṣeyọri.
    ///
    ///
    /// Pada [`None`] ti iye ti inu ba ti lọ silẹ lati igba naa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Run gbogbo awọn itọka ti o lagbara.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // A lo lupu CAS lati ṣe alekun kika to lagbara dipo fetch_add nitori iṣẹ yii ko yẹ ki o ka kika itọkasi lati odo si ọkan.
        //
        //
        let inner = self.inner()?;

        // Ẹru ti o ni idarẹ nitori eyikeyi kikọ ti 0 ti a le ṣe akiyesi fi oju aaye silẹ ni ipo odo titilai (nitorinaa kika "stale" ti 0 dara), ati pe iye eyikeyi miiran ti jẹrisi nipasẹ CAS ni isalẹ.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Wo awọn asọye ni `Arc::clone` fun idi ti a fi ṣe eyi (fun `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Itura jẹ itanran fun ọran ikuna nitori a ko ni awọn ireti eyikeyi nipa ipinlẹ tuntun.
            // Gba jẹ pataki fun ọran aṣeyọri lati muuṣiṣẹpọ pẹlu `Arc::new_cyclic`, nigbati iye ti inu le jẹ ipilẹ lẹhin ti a ti ṣẹda awọn itọkasi `Weak` tẹlẹ.
            // Ni ọran naa, a nireti lati ṣe akiyesi iye ti ipilẹṣẹ ni kikun.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // asan ti a ṣayẹwo loke
                Err(old) => n = old,
            }
        }
    }

    /// Gba nọmba ti awọn itọka (`Arc`) lagbara ti o tọka si ipin yii.
    ///
    /// Ti o ba ṣẹda `self` nipa lilo [`Weak::new`], eyi yoo pada 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Gba isunmọ ti nọmba ti awọn atọka `Weak` ntokasi si ipin yii.
    ///
    /// Ti o ba ṣẹda `self` ni lilo [`Weak::new`], tabi ti ko ba si awọn abawọn to lagbara, eyi yoo pada 0.
    ///
    /// # Accuracy
    ///
    /// Nitori awọn alaye imuse, iye ti o pada le ti wa ni pipa nipasẹ 1 ni boya itọsọna nigbati awọn okun miiran n ṣe afọwọyi eyikeyi `Arc`s tabi`Awọn ailera`ti o tọka si ipin kanna.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Niwọn igba ti a ṣe akiyesi pe o kere ju ijuboluwole to lagbara kan lẹhin kika kika ailagbara, a mọ pe itọkasi ailagbara ti ko tọ (bayi nigbakugba ti awọn itọkasi to lagbara ba wa laaye) wa ni ayika nigba ti a ṣe akiyesi iye ailagbara, ati nitorinaa o le yọkuro kuro lailewu.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Pada `None` nigbati ijuboluwole n tan ati pe ko si ipin `ArcInner`, (ie, nigbati a ṣẹda `Weak` yii nipasẹ `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // A ṣọra lati *kii ṣe* ṣẹda itọkasi kan ti o bo aaye "data", bi aaye le ṣe yipada ni igbakanna (fun apẹẹrẹ, ti `Arc` ti o kẹhin ba lọ silẹ, aaye data yoo ju silẹ ni aaye).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Pada `true` ti awọn `ailera` meji ba tọka si ipin kanna (ti o jọra si [`ptr::eq`]), tabi ti awọn mejeeji ko ba tọka si ipin kankan (nitori a ṣẹda wọn pẹlu `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Niwọn igba ti eyi ṣe afiwe awọn itọka o tumọ si pe `Weak::new()` yoo dọgba ara wọn, botilẹjẹpe wọn ko tọka si ipin kankan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ifiwera `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ṣe ẹda oniye ti ijuboluwole `Weak` ti o tọka si ipin kanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Wo awọn asọye ni Arc::clone() fun idi ti eyi fi ni ihuwasi.
        // Eyi le lo fetch_add (kọju titiipa) nitori pe kaakiri ailera ti wa ni titiipa nikan nibiti * ko si awọn abawọn ailagbara miiran ti o wa laaye.
        //
        // (Nitorinaa a ko le ṣiṣẹ koodu yii ni ọran yẹn).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Wo awọn asọye ni Arc::clone() fun idi ti a fi ṣe eyi (fun mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ṣe `Weak<T>` tuntun kan, laisi ipin iranti.
    /// Pipe [`upgrade`] lori iye ipadabọ nigbagbogbo fun [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ṣubu ijuboluwole `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ko tẹ ohunkohun
    /// drop(foo);        // Awọn titẹ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ti a ba rii pe a jẹ ijuboluwo to kẹhin, lẹhinna akoko rẹ lati ṣe ipinpo data naa patapata.Wo ijiroro ni Arc::drop() nipa awọn aṣẹ iranti
        //
        // Ko ṣe pataki lati ṣayẹwo fun ipo titiipa nibi, nitori kika ailagbara le ṣee tii nikan ti o ba jẹ pe adaṣe alailera kan wa, ti o tumọ si pe silẹ nikan le ṣee ṣiṣẹ LATI eyi ti o ku atunṣe ti o ku, eyiti o le ṣẹlẹ lẹhin titiipa titiipa.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// A n ṣe amọja yii nibi, ati kii ṣe bi iṣapeye gbogbogbo diẹ sii lori `&T`, nitori yoo bibẹẹkọ yoo ṣafikun iye owo si gbogbo awọn iṣayẹwo idogba lori awọn agbapada.
/// A ro pe `A lo Arc` lati tọju awọn iye nla, ti o lọra lati ẹda oniye, ṣugbọn o tun wuwo lati ṣayẹwo fun aidogba, nfa idiyele yii lati sanwo diẹ sii ni rọọrun.
///
/// O tun ṣee ṣe ki o ni awọn oniye `Arc` meji, ti o tọka si iye kanna, ju meji&T`s lọ.
///
/// A le ṣe eyi nikan nigbati `T: Eq` bi `PartialEq` kan le jẹ alainidena iyipada.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Equality fun meji `Arc`s.
    ///
    /// Meji `Arc`s dogba ti awọn iye inu wọn ba dọgba, paapaa ti wọn ba wa ni fipamọ ni ipin ipin ọtọtọ.
    ///
    /// Ti `T` ba tun ṣe `Eq` (ti o tumọ si ifọkansi ti isọgba), awọn `Arc` meji ti o tọka si ipin kanna ni o dọgba nigbagbogbo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Aidogba fun `Arc`s meji.
    ///
    /// Meji `Arc`s jẹ aidogba ti awọn iye inu wọn ko ba dọgba.
    ///
    /// Ti o ba ti `T` tun alailewu `Eq` (gégè reflexivity ti Equality), meji `Arc`s ti ojuami si awọn kanna iye ti wa ni ko unequal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Afiwe apakan fun meji `Arc`s.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `partial_cmp()` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ifiwera kere ju fun `Arc`s meji.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `<` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Kere tabi dogba si' afiwe fun `Arc`s meji.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `<=` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Ifiwera titobi ju `Arc`s meji lọ.
    ///
    /// A fiwe awọn meji nipa pipe `>` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Ti o tobi ju tabi dogba si' afiwe fun 'Arc`s meji.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `>=` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Ifiwera fun `Arc`s meji.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `cmp()` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Ṣẹda `Arc<T>` tuntun, pẹlu iye `Default` fun `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Ṣe ipin ipin ti a ka-itọkasi kan ki o fọwọsi nipasẹ ṣiṣọn awọn ohun kan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Ṣe ipin `str` ti a ka-itọkasi kan ati daakọ `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Ṣe ipin `str` ti a ka-itọkasi kan ati daakọ `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Gbe ohun ti o ni apoti si ipin tuntun, ipin ti a ka-itọkasi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Pin ipin kan ti a ka kika rẹ ki o gbe awọn ohun kan `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Gba Vec laaye lati ṣe iranti iranti rẹ, ṣugbọn kii ṣe pa awọn akoonu rẹ run
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Gba eroja kọọkan ninu `Iterator` o si gba a sinu `Arc<[T]>` kan.
    ///
    /// # Awọn abuda iṣẹ
    ///
    /// ## Gbogbogbo ọrọ
    ///
    /// Ninu ọran gbogbogbo, gbigba sinu `Arc<[T]>` ni ṣiṣe nipasẹ gbigba akọkọ sinu `Vec<T>` kan.Iyẹn ni, nigba kikọ nkan wọnyi:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// eyi huwa bi ẹni pe a kọwe:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Eto akọkọ ti awọn ipin ṣẹlẹ nibi.
    ///     .into(); // Pipin keji fun `Arc<[T]>` ṣẹlẹ nibi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Eyi yoo pin bi ọpọlọpọ awọn akoko bi o ṣe nilo fun kikọ `Vec<T>` ati lẹhinna o yoo pin lẹẹkan fun titan `Vec<T>` sinu `Arc<[T]>`.
    ///
    ///
    /// ## Iterators ti ipari ti a mọ
    ///
    /// Nigbati `Iterator` rẹ ba ṣe `TrustedLen` ati pe o jẹ iwọn gangan, ipin kan ni yoo ṣe fun `Arc<[T]>`.Fun apere:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // O kan ipin kan nikan ṣẹlẹ nibi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialization trait ti a lo fun gbigba sinu `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Eyi ni ọran fun aṣetunṣe `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Aabo: A nilo lati rii daju pe aṣetunṣe ni ipari deede ati pe a ni.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Ṣubu pada si imuse deede.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Gba aiṣedeede laarin `ArcInner` fun isanwo isanwo ni atokọ kan.
///
/// # Safety
///
/// Atọka gbọdọ tọka si (ati ni metadata to wulo fun) apeere ti o wulo tẹlẹ ti T, ṣugbọn a gba T laaye lati ju silẹ.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ṣe deede iye ti ko ni iwọn si opin ArcInner.
    // Nitori RcBox jẹ repr(C), yoo ma jẹ aaye ti o kẹhin ninu iranti.
    // Aabo: nitori awọn iru unsized nikan ti o ṣee ṣe jẹ awọn ege, awọn nkan trait,
    // ati awọn oriṣi ita, ibeere aabo aabo titẹ sii lọwọlọwọ to lati ni itẹlọrun awọn ibeere ti align_of_val_raw;eyi jẹ alaye imuse ti ede ti o le ma gbarale ni ita ti std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}