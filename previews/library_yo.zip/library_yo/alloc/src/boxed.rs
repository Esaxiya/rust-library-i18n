//! Iru ijuboluwo fun ipin okiti.
//!
//! [`Box<T>`], laigba tọka si bi 'box' kan, n pese ọna ti o rọrun julọ fun ipin okiti ni Rust.Awọn apoti pese ohun-ini fun ipin yii, ki o sọ awọn akoonu wọn silẹ nigbati wọn ba kọja ni agbegbe.Awọn apoti tun rii daju pe wọn ko pin diẹ sii ju awọn baiti `isize::MAX`.
//!
//! # Examples
//!
//! Gbe iye kan lati inu akopọ si okiti nipa ṣiṣẹda [`Box`] kan:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Gbe iye kan lati [`Box`] pada si akopọ nipasẹ [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Ṣiṣẹda eto data atunkọ:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Eyi yoo tẹjade `Cons (1, Cons(2, Nil))`.
//!
//! Awọn ẹya atunkọ gbọdọ wa ni apoti, nitori ti itumọ ti `Cons` dabi eleyi:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Yoo ko ṣiṣẹ.Eyi jẹ nitori iwọn ti `List` da lori iye awọn eroja ti o wa ninu atokọ naa, nitorinaa a ko mọ iye iranti ti o le pin fun `Cons` kan.Nipa ṣafihan [`Box<T>`] kan, eyiti o ni iwọn asọye, a mọ bi `Cons` nla ṣe nilo lati jẹ.
//!
//! # Ifilelẹ iranti
//!
//! Fun awọn iye ti kii ṣe iwọn odo, [`Box`] kan yoo lo ipin [`Global`] fun ipin rẹ.O wulo lati yi awọn ọna mejeeji pada laarin [`Box`] ati ijuboluwo aise ti a pin pẹlu olupilẹṣẹ [`Global`], ni fifun pe [`Layout`] ti a lo pẹlu olupilẹṣẹ jẹ deede fun iru.
//!
//! Ni deede diẹ sii, `value:*mut T` kan ti a ti pin pẹlu olupilẹṣẹ [`Global`] pẹlu `Layout::for_value(&* value)` le yipada si apoti kan nipa lilo [`Box::<T>::from_raw(value)`].
//! Ni ọna miiran, atilẹyin iranti ti `value:*mut T` kan ti a gba lati [`Box::<T>::into_raw`] le ṣee pin nipasẹ lilo olupilẹṣẹ [`Global`] pẹlu [`Layout::for_value(&* value)`].
//!
//! Fun awọn iye iwọn odo, ijuboluwole `Box` tun ni lati jẹ [valid] fun awọn kika ati kikọ ati ibaramu to.
//! Ni pataki, sisọ eyikeyi odidi odidi ti kii ṣe-odo ti o ni ibamu si ijuboluwole agbejade ṣe itọka to wulo, ṣugbọn ijuboluwole ti o tọka si iranti ti a ti pin tẹlẹ pe lati igba ti o ti ni ominira ko wulo.
//! Ọna ti a ṣe iṣeduro lati kọ Apoti si ZST ti `Box::new` ko ba le lo ni lati lo [`ptr::NonNull::dangling`].
//!
//! Nitorinaa bi `T: Sized`, a ṣe idaniloju `Box<T>` kan lati wa ni ipoduduro bi ijuboluwo kan ati pe o tun jẹ ibaramu ABI pẹlu awọn itọka C (ie C iru `T*`).
//! Eyi tumọ si pe ti o ba ni awọn iṣẹ "C" Rust ita ti yoo pe lati C, o le ṣalaye awọn iṣẹ Rust wọnyẹn nipa lilo awọn oriṣi `Box<T>`, ki o lo `T*` bi iru ti o baamu lori ẹgbẹ C.
//! Gẹgẹbi apẹẹrẹ, ṣe akiyesi akọle C yii eyiti o kede awọn iṣẹ ti o ṣẹda ati run iru iye `Foo` kan:
//!
//! ```c
//! /* C akọsori */
//!
//! /* Pada nini si olupe naa */
//! struct Foo* foo_new(void);
//!
//! /* Gba nini lati ọdọ olupe;ko si-op nigbati a ba pe pẹlu NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Awọn iṣẹ meji wọnyi le ṣe imuse ni Rust gẹgẹbi atẹle.Nibi, iru `struct Foo*` lati C ni itumọ si `Box<Foo>`, eyiti o mu awọn ihamọ nini.
//! Akiyesi tun pe ariyanjiyan alailopin si `foo_delete` ni aṣoju ni Rust bi `Option<Box<Foo>>`, nitori `Box<Foo>` ko le jẹ asan.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Botilẹjẹpe `Box<T>` ni aṣoju kanna ati C ABI bi ijuboluwole C, eyi ko tumọ si pe o le yipada `T*` lainidii sinu `Box<T>` ki o reti awọn nkan lati ṣiṣẹ.
//! `Box<T>` awọn iye yoo ma wa ni deede ni kikun, awọn itọka ti kii ṣe asan.Pẹlupẹlu, apanirun fun `Box<T>` yoo gbiyanju lati laaye iye naa pẹlu olupilẹṣẹ kariaye.Ni gbogbogbo, iṣe ti o dara julọ ni lati lo `Box<T>` nikan fun awọn itọka ti o bẹrẹ lati olupilẹṣẹ agbaye.
//!
//! **Pataki.** Ni o kere ju ni bayi, o yẹ ki o yago fun lilo awọn iru `Box<T>` fun awọn iṣẹ ti o ṣalaye ni C ṣugbọn pe lati Rust.Ni awọn ọran wọnyẹn, o yẹ ki o digi taara awọn oriṣi C ni pẹkipẹki bi o ti ṣee.
//! Lilo awọn oriṣi bii `Box<T>` nibiti itumọ C ti nlo `T*` kan le ja si ihuwasi ti a ko ṣalaye, bi a ti ṣalaye ninu [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Iru ijuboluwo fun ipin okiti.
///
/// Wo [module-level documentation](../../std/boxed/index.html) fun diẹ sii.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Ṣe iranti iranti lori okiti ati lẹhinna gbe `x` sinu rẹ.
    ///
    /// Eyi ko ṣe ipinnu gangan ti `T` jẹ iwọn-odo.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Ṣe apoti tuntun pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Ṣe `Box` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Ṣe `Pin<Box<T>>` tuntun kan.
    /// Ti `T` ko ba ṣe `Unpin`, lẹhinna `x` yoo wa ni PIN ni iranti ati pe ko le gbe.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Ṣe iranti iranti lori okiti lẹhinna gbe `x` sinu rẹ, da aṣiṣe kan pada ti ipin naa ba kuna
    ///
    ///
    /// Eyi ko ṣe ipinnu gangan ti `T` jẹ iwọn-odo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Ṣe apoti tuntun pẹlu awọn akoonu ti ko ni oye lori okiti, dapada aṣiṣe kan ti ipin naa ba kuna
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Ṣe `Box` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0` lori okiti
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Ṣe iranti iranti ni ipin ti a fun lẹhinna gbe `x` sinu rẹ.
    ///
    /// Eyi ko ṣe ipinnu gangan ti `T` jẹ iwọn-odo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Ṣe iranti iranti ni ipin ti a fun lẹhinna gbe `x` sinu rẹ, da aṣiṣe kan pada ti ipin naa ba kuna
    ///
    ///
    /// Eyi ko ṣe ipinnu gangan ti `T` jẹ iwọn-odo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Ṣe apoti tuntun pẹlu awọn akoonu ti ko ni oye ninu ipin ti a pese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Fẹ ibaramu lori unwrap_or_else nitori pipade nigbamiran kii ṣe alaini.
        // Iyẹn yoo jẹ ki titobi koodu tobi.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ṣe apoti tuntun pẹlu awọn akoonu ti ko ni oye ninu ipin ti a pese, dapada aṣiṣe kan ti ipin naa ba kuna
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Ṣe `Box` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0` ninu olupilẹṣẹ ti a pese.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Fẹ ibaramu lori unwrap_or_else nitori pipade nigbamiran kii ṣe alaini.
        // Iyẹn yoo jẹ ki titobi koodu tobi.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ṣe `Box` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0` ninu olupilẹṣẹ ti a pese, dapada aṣiṣe kan ti ipin naa ba kuna,
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Ṣe `Pin<Box<T, A>>` tuntun kan.
    /// Ti `T` ko ba ṣe `Unpin`, lẹhinna `x` yoo wa ni PIN ni iranti ati pe ko le gbe.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Awọn iyipada `Box<T>` kan sinu `Box<[T]>` kan
    ///
    /// Iyipada yii ko ṣe ipin lori okiti o si ṣẹlẹ ni aye.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Je `Box`, n pada iye ti a we.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Ṣe iru ege boti apoti titun pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Ko iru nkan boti apoti titun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Ko iru nkan boti apoti titun pẹlu awọn akoonu ti ko ni oye ninu ipin ti a pese.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Ṣe nkan ege boti tuntun pẹlu awọn akoonu ti ko ni oye ninu ipin ti a pese, pẹlu iranti ti kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Awọn iyipada si `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe iye gaan wa ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Awọn iyipada si `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe awọn iye wa gaan ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Ṣe apoti kan lati ọdọ ijuboluwole alaiṣẹ kan.
    ///
    /// Lẹhin pipe iṣẹ yii, ijuboluwole ohun-ini nipasẹ abajade `Box`.
    /// Ni pataki, apanirun `Box` yoo pe apanirun ti `T` ati laaye iranti ti a pin.
    /// Fun eyi lati ni aabo, iranti gbọdọ ti pin ni ibamu pẹlu [memory layout] ti `Box` lo.
    ///
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori lilo aibojumu le ja si awọn iṣoro iranti.
    /// Fun apẹẹrẹ, ominira meji-meji le waye ti a ba pe iṣẹ ni ilọpo meji lori ijuboluwo ihuwa kanna.
    ///
    /// Awọn ipo aabo ni a sapejuwe ninu apakan [memory layout].
    ///
    /// # Examples
    ///
    /// Tun `Box` tun ṣe eyiti o yipada tẹlẹ si ijuboluwole lilo [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Pẹlu ọwọ ṣẹda `Box` lati ibere nipa lilo olupilẹṣẹ kariaye:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Ni apapọ .write ni a nilo lati yago fun igbiyanju lati pa awọn akoonu (uninitialized) ti tẹlẹ ti `ptr` run, botilẹjẹpe fun apẹẹrẹ rọrun yii `*ptr = 5` yoo ti ṣiṣẹ daradara.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Ṣe apoti kan lati inu itọka aise ninu ipin ti a fifun.
    ///
    /// Lẹhin pipe iṣẹ yii, ijuboluwole ohun-ini nipasẹ abajade `Box`.
    /// Ni pataki, apanirun `Box` yoo pe apanirun ti `T` ati laaye iranti ti a pin.
    /// Fun eyi lati ni aabo, iranti gbọdọ ti pin ni ibamu pẹlu [memory layout] ti `Box` lo.
    ///
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori lilo aibojumu le ja si awọn iṣoro iranti.
    /// Fun apẹẹrẹ, ominira meji-meji le waye ti a ba pe iṣẹ ni ilọpo meji lori ijuboluwo ihuwa kanna.
    ///
    /// # Examples
    ///
    /// Tun `Box` tun ṣe eyiti o yipada tẹlẹ si ijuboluwole lilo [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Pẹlu ọwọ ṣẹda `Box` lati ibere nipa lilo olupilẹṣẹ eto:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Ni apapọ .write ni a nilo lati yago fun igbiyanju lati pa awọn akoonu (uninitialized) ti tẹlẹ ti `ptr` run, botilẹjẹpe fun apẹẹrẹ rọrun yii `*ptr = 5` yoo ti ṣiṣẹ daradara.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Je `Box`, n da pada ijuboluwole ti a we.
    ///
    /// Atọka yoo wa ni deedee deede ati kii ṣe asan.
    ///
    /// Lẹhin pipe iṣẹ yii, olupe naa ni ẹri fun iranti ti iṣakoso tẹlẹ nipasẹ `Box`.
    /// Ni pataki, olupe yẹ ki o pa `T` run daradara ki o tu iranti silẹ, ni akiyesi [memory layout] ti `Box` lo.
    /// Ọna to rọọrun lati ṣe eyi ni lati yi iyipada ijuboluwo pada si `Box` pẹlu iṣẹ [`Box::from_raw`], gbigba gbigba apanirun `Box` lati ṣe afọmọ.
    ///
    ///
    /// Note: eyi jẹ iṣẹ ti o ni nkan, eyiti o tumọ si pe o ni lati pe ni `Box::into_raw(b)` dipo `b.into_raw()`.
    /// Eyi jẹ ki pe ko si ariyanjiyan pẹlu ọna kan lori oriṣi inu.
    ///
    /// # Examples
    /// Iyipada iyipada ijuboluwole pada sinu `Box` pẹlu [`Box::from_raw`] fun afọmọ adaṣe:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Afọmọ afọwọyi nipa ṣiṣapẹẹrẹ ṣiṣe apanirun ati ṣiṣe ipin iranti:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Gba `Box`, n da pada ijuboluwole ti a we ati ipin.
    ///
    /// Atọka yoo wa ni deedee deede ati kii ṣe asan.
    ///
    /// Lẹhin pipe iṣẹ yii, olupe naa ni ẹri fun iranti ti iṣakoso tẹlẹ nipasẹ `Box`.
    /// Ni pataki, olupe yẹ ki o pa `T` run daradara ki o tu iranti silẹ, ni akiyesi [memory layout] ti `Box` lo.
    /// Ọna to rọọrun lati ṣe eyi ni lati yi iyipada ijuboluwo pada si `Box` pẹlu iṣẹ [`Box::from_raw_in`], gbigba gbigba apanirun `Box` lati ṣe afọmọ.
    ///
    ///
    /// Note: eyi jẹ iṣẹ ti o ni nkan, eyiti o tumọ si pe o ni lati pe ni `Box::into_raw_with_allocator(b)` dipo `b.into_raw_with_allocator()`.
    /// Eyi jẹ ki pe ko si ariyanjiyan pẹlu ọna kan lori oriṣi inu.
    ///
    /// # Examples
    /// Iyipada iyipada ijuboluwole pada sinu `Box` pẹlu [`Box::from_raw_in`] fun afọmọ adaṣe:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Afọmọ afọwọyi nipa ṣiṣapẹẹrẹ ṣiṣe apanirun ati ṣiṣe ipin iranti:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // A mọ Apoti bi "unique pointer" nipasẹ Stacked Borrows, ṣugbọn ni inu o jẹ itọka aise fun eto iru.
        // Titan-an taara sinu ijuboluwole aise kii yoo ṣe idanimọ bi "releasing" ijuboluwo alailẹgbẹ lati gba awọn iraye si aise laaye, nitorina gbogbo awọn ọna ijuboluwole aise ni lati lọ nipasẹ `Box::leak`.
        //
        // Titan *pe* si ijuboluwole ihuwasi huwa deede.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Pada itọkasi si ipin ipilẹ.
    ///
    /// Note: eyi jẹ iṣẹ ti o ni nkan, eyiti o tumọ si pe o ni lati pe ni `Box::allocator(&b)` dipo `b.allocator()`.
    /// Eyi jẹ ki pe ko si ariyanjiyan pẹlu ọna kan lori oriṣi inu.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Je ati jo ni `Box`, n da iwe itọkasi iyipada pada, `&'a mut T`.
    /// Akiyesi pe iru `T` gbọdọ ni igbesi aye `'a` ti o yan laaye.
    /// Ti oriṣi ba ni awọn itọkasi aimi nikan, tabi ko si rara rara, lẹhinna o le yan eyi lati jẹ `'static`.
    ///
    /// Iṣẹ yii jẹ pataki julọ fun data ti o ngbe fun iyoku ti igbesi aye eto naa.
    /// Sisọ itọkasi ti o pada yoo fa jo iranti kan.
    /// Ti eyi ko ba ṣe itẹwọgba, itọkasi yẹ ki o kọkọ ni akọkọ pẹlu iṣẹ [`Box::from_raw`] ti n ṣe `Box` kan.
    ///
    /// `Box` yii le lẹhinna silẹ eyiti yoo parun `T` daradara ati tu silẹ iranti ti a pin.
    ///
    /// Note: eyi jẹ iṣẹ ti o ni nkan, eyiti o tumọ si pe o ni lati pe ni `Box::leak(b)` dipo `b.leak()`.
    /// Eyi jẹ ki pe ko si ariyanjiyan pẹlu ọna kan lori oriṣi inu.
    ///
    /// # Examples
    ///
    /// Lilo to rọrun:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Alaiwọn data:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Awọn iyipada `Box<T>` kan sinu `Pin<Box<T>>` kan
    ///
    /// Iyipada yii ko ṣe ipin lori okiti o si ṣẹlẹ ni aye.
    ///
    /// Eyi tun wa nipasẹ [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Ko ṣee ṣe lati gbe tabi rọpo awọn inu ti `Pin<Box<T>>` kan nigbati `T: !Unpin`, nitorinaa o jẹ ailewu lati pin ni taara laisi awọn ibeere afikun.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ṣe ohunkohun, ju silẹ lọwọlọwọ nipasẹ alapọpọ.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Ṣẹda `Box<T>` kan, pẹlu iye `Default` fun T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Pada apoti tuntun pẹlu `clone()` ti awọn akoonu inu apoti yii.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Iye naa jẹ kanna
    /// assert_eq!(x, y);
    ///
    /// // Ṣugbọn wọn jẹ awọn ohun alailẹgbẹ
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Ṣaaju-fi iranti silẹ lati gba kikọ iye oniye taara.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Awọn akoonu ti orisun `awọn ẹda` sinu `self` laisi ṣiṣẹda ipin tuntun kan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Iye naa jẹ kanna
    /// assert_eq!(x, y);
    ///
    /// // Ati pe ko si ipin kankan ti o ṣẹlẹ
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // eyi ṣe ẹda ti data naa
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Iyipada iru iru jeneriki `T` sinu `Box<T>` kan
    ///
    /// Iyipada naa sọtọ lori okiti ati gbe `t` lati akopọ sinu rẹ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Awọn iyipada `Box<T>` kan sinu `Pin<Box<T>>` kan
    ///
    /// Iyipada yii ko ṣe ipin lori okiti o si ṣẹlẹ ni aye.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Awọn iyipada `&[T]` kan sinu `Box<[T]>` kan
    ///
    /// Iyipada yii sọtọ lori okiti ati ṣe ẹda ti `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ṣẹda a&[u8] eyi ti yoo ṣee lo lati ṣẹda Apoti Apoti <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Awọn iyipada `&str` kan sinu `Box<str>` kan
    ///
    /// Iyipada yii sọtọ lori okiti ati ṣe ẹda ti `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Awọn iyipada `Box<str>` kan sinu `Box<[u8]>` kan
    /// Iyipada yii ko ṣe ipin lori okiti o si ṣẹlẹ ni aye.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ṣẹda Apoti kan<str>eyi ti yoo ṣee lo lati ṣẹda Apoti Apoti <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // ṣẹda a&[u8] eyi ti yoo ṣee lo lati ṣẹda Apoti Apoti <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Awọn iyipada `[T; N]` kan sinu `Box<[T]>` kan
    /// Iyipada yii gbe orun si iranti ti a pin sọtọ tuntun.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Igbidanwo lati sọ apoti si isalẹ si iru nja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Igbidanwo lati sọ apoti si isalẹ si iru nja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Igbidanwo lati sọ apoti si isalẹ si iru nja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ko ṣee ṣe lati yọ Uniq ti inu taara lati Apoti, dipo a sọ ọ si * const eyiti o pe Orukọ Alailẹgbẹ naa
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Pataki fun titobi `I`s ti o nlo`I` imuse ti `last()` dipo aiyipada.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}