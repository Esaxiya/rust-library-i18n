//! Awọn ipin ipin iranti

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Iwọnyi ni awọn aami idan lati pe olupilẹṣẹ kariaye.rustc ṣe ipilẹṣẹ wọn lati pe `__rg_alloc` ati bẹbẹ lọ.
    // ti o ba jẹ pe ẹda `#[global_allocator]` kan (koodu ti n gbooro sii pe eroja macro ṣe awọn iṣẹ wọnyẹn), tabi lati pe awọn imuse aiyipada ni libstd (`__rdl_alloc` ati bẹbẹ lọ)
    //
    // ni `library/std/src/alloc.rs`) bibẹkọ.
    // rustc fork ti LLVM tun jẹ awọn ọran pataki-awọn orukọ iṣẹ wọnyi lati ni anfani lati je ki wọn bii `malloc`, `realloc`, ati `free`, lẹsẹsẹ.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Olupin iranti agbaye.
///
/// Iru yii n ṣe imuṣe [`Allocator`] trait nipasẹ gbigbe awọn ipe si ipin ti a forukọsilẹ pẹlu aami `#[global_allocator]` ti o ba wa ọkan, tabi aiyipada `std` crate.
///
///
/// Note: lakoko ti iru yii jẹ riru, iṣẹ-ṣiṣe ti o pese ni a le wọle nipasẹ [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Ṣe iranti iranti pẹlu oluṣeto agbaye.
///
/// Iṣẹ yii n tẹsiwaju awọn ipe si ọna [`GlobalAlloc::alloc`] ti ipin ti a forukọsilẹ pẹlu ẹya `#[global_allocator]` ti o ba wa ọkan, tabi aiyipada ti `std` crate.
///
///
/// Iṣẹ-ṣiṣe yii ni a nireti lati sọ di mimọ ni ojurere fun ọna `alloc` ti iru [`Global`] nigbati rẹ ati [`Allocator`] trait di iduroṣinṣin.
///
/// # Safety
///
/// Wo [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Ṣe iranti ipinpo pẹlu oluṣeto agbaye.
///
/// Iṣẹ yii n tẹsiwaju awọn ipe si ọna [`GlobalAlloc::dealloc`] ti ipin ti a forukọsilẹ pẹlu ẹya `#[global_allocator]` ti o ba wa ọkan, tabi aiyipada ti `std` crate.
///
///
/// Iṣẹ-ṣiṣe yii ni a nireti lati sọ di mimọ ni ojurere fun ọna `dealloc` ti iru [`Global`] nigbati rẹ ati [`Allocator`] trait di iduroṣinṣin.
///
/// # Safety
///
/// Wo [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Ṣe iranti aye gidi pẹlu oluṣeto agbaye.
///
/// Iṣẹ yii n tẹsiwaju awọn ipe si ọna [`GlobalAlloc::realloc`] ti ipin ti a forukọsilẹ pẹlu ẹya `#[global_allocator]` ti o ba wa ọkan, tabi aiyipada ti `std` crate.
///
///
/// Iṣẹ-ṣiṣe yii ni a nireti lati sọ di mimọ ni ojurere fun ọna `realloc` ti iru [`Global`] nigbati rẹ ati [`Allocator`] trait di iduroṣinṣin.
///
/// # Safety
///
/// Wo [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Pin iranti ti ipilẹṣẹ odo pẹlu olupilẹṣẹ kariaye.
///
/// Iṣẹ yii n tẹsiwaju awọn ipe si ọna [`GlobalAlloc::alloc_zeroed`] ti ipin ti a forukọsilẹ pẹlu ẹya `#[global_allocator]` ti o ba wa ọkan, tabi aiyipada ti `std` crate.
///
///
/// Iṣẹ-ṣiṣe yii ni a nireti lati sọ di mimọ ni ojurere fun ọna `alloc_zeroed` ti iru [`Global`] nigbati rẹ ati [`Allocator`] trait di iduroṣinṣin.
///
/// # Safety
///
/// Wo [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // Aabo: `layout` jẹ aisi-odo ni iwọn,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // Aabo: Kanna bi `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // Aabo: `new_size` kii ṣe odo bi `old_size` ṣe tobi ju tabi dọgba si `new_size`
            // bi o ṣe nilo nipasẹ awọn ipo aabo.Awọn ipo miiran gbọdọ wa ni atilẹyin nipasẹ olupe naa
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` jasi ṣayẹwo fun `new_size >= old_layout.size()` tabi nkan ti o jọra.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Aabo: nitori `new_layout.size()` gbọdọ tobi ju tabi dọgba pẹlu `old_size`,
            // ipin atijọ ati tuntun ti iranti jẹ wulo fun awọn kika ati kikọ fun awọn baiti `old_size`.
            // Pẹlupẹlu, nitori ipin atijọ ko tii pin ni ipin, ko le ṣe atunṣe `new_ptr`.
            // Nitorinaa, ipe si `copy_nonoverlapping` jẹ ailewu.
            // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // Aabo: `layout` jẹ aisi-odo ni iwọn,
            // awọn ipo miiran gbọdọ wa ni atilẹyin nipasẹ olupe naa
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Aabo: gbogbo awọn ipo gbọdọ wa ni atilẹyin nipasẹ olupe naa
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Aabo: gbogbo awọn ipo gbọdọ wa ni atilẹyin nipasẹ olupe naa
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // Aabo: Awọn ipo gbọdọ wa ni atilẹyin nipasẹ olupe naa
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // Aabo: `new_size` kii ṣe odo.Awọn ipo miiran gbọdọ wa ni atilẹyin nipasẹ olupe naa
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` jasi ṣayẹwo fun `new_size <= old_layout.size()` tabi nkan ti o jọra.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // Aabo: nitori `new_size` gbọdọ jẹ kere ju tabi dọgba pẹlu `old_layout.size()`,
            // ipin atijọ ati tuntun ti iranti jẹ wulo fun awọn kika ati kikọ fun awọn baiti `new_size`.
            // Pẹlupẹlu, nitori ipin atijọ ko tii pin ni ipin, ko le ṣe atunṣe `new_ptr`.
            // Nitorinaa, ipe si `copy_nonoverlapping` jẹ ailewu.
            // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Olupin fun awọn itọka alailẹgbẹ.
// Iṣẹ yii ko gbọdọ yọ kuro.Ti o ba ṣe, MIR codegen yoo kuna.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ibuwọlu yii gbọdọ jẹ bakanna bi `Box`, bibẹkọ ti ICE yoo ṣẹlẹ.
// Nigbati a ba fi afikun paramita si `Box` kun (bii `A: Allocator`), o ni lati ṣafikun eyi daradara.
// Fun apẹẹrẹ ti o ba yipada `Box` si `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, o yẹ ki a yipada iṣẹ yii si `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` daradara.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Olutọju aṣiṣe ipin

extern "Rust" {
    // Eyi ni aami idan lati pe olutọju aṣiṣe ipin agbaye.
    // rustc ṣe ipilẹṣẹ lati pe `__rg_oom` ti o ba jẹ `#[alloc_error_handler]` kan, tabi lati pe awọn imuse aiyipada ni isalẹ (`__rdl_oom`) bibẹkọ.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abort lori aṣiṣe ipin ipin iranti tabi ikuna.
///
/// Awọn olupe ti awọn API ipin ipin iranti ti o fẹ lati ṣe iṣiro iṣiro ni idahun si aṣiṣe ipin kan ni iwuri lati pe iṣẹ yii, dipo ki o ma pe `panic!` taara tabi iru.
///
///
/// Ihuwasi aiyipada ti iṣẹ yii ni lati tẹ ifiranṣẹ kan si aṣiṣe boṣewa ati ṣiṣe ilana naa.
/// O le paarọ rẹ pẹlu [`set_alloc_error_hook`] ati [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Fun idanwo ipin `std::alloc::handle_alloc_error` le ṣee lo taara.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ti a pe nipasẹ ipilẹṣẹ `__rust_alloc_error_handler`

    // ti ko ba si `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ti o ba wa `#[alloc_error_handler]` kan
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Ṣe pataki awọn ere ibeji sinu ipin-tẹlẹ, iranti ti a ko mọ.
/// Lo nipasẹ `Box::clone` ati `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Lehin ti o ti pin *akọkọ* le gba laaye optimizer lati ṣẹda iye ti ẹda oniye ni aaye, n fo agbegbe ati gbe.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // A le ṣe adaakọ nigbagbogbo ninu-aye, laisi okiki iye agbegbe kan.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}