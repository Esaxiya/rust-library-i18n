//! Awọn atọka kika kika kika-tẹle-tẹle.'Rc' duro fun 'Itọkasi
//! Counted'.
//!
//! Iru [`Rc<T>`][`Rc`] n pese nini nini ti iye ti iru `T`, ti a pin ni okiti.
//! Pipe si [`clone`][clone] lori [`Rc`] n ṣe itọka tuntun si ipin kanna ni okiti.
//! Nigbati ijuboluwole [`Rc`] ti o kẹhin si ipin ti a fifun ni parun, iye ti o fipamọ sinu ipin yẹn (ti a tọka si bi "inner value") tun ti lọ silẹ.
//!
//! Awọn itọkasi ti a pin ni Rust yiyipada iyipada kuro ni aiyipada, ati pe [`Rc`] kii ṣe iyatọ: o ko le gba gbogbo tọka iyipada si nkankan ninu [`Rc`] kan.
//! Ti o ba nilo iyipada, fi [`Cell`] tabi [`RefCell`] sii inu [`Rc`];wo [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] nlo kika kika itọkasi ti kii ṣe atomiki.
//! Eyi tumọ si pe ori oke jẹ pupọ, ṣugbọn [`Rc`] ko le firanṣẹ laarin awọn okun, ati nitorinaa [`Rc`] ko ṣe imuse [`Send`][send].
//! Bi abajade, olupilẹṣẹ Rust yoo ṣayẹwo *ni sakojo akoko* pe o ko firanṣẹ [`Rc`] s laarin awọn okun.
//! Ti o ba nilo ọpọ-asapo, kika kika atomiki, lo [`sync::Arc`][arc].
//!
//! Ọna [`downgrade`][downgrade] ni a le lo lati ṣẹda ijuboluwole [`Weak`] ti ko ni.
//! O ijuboluwole [`Weak`] le jẹ [`igbesoke`][igbesoke] d si [`Rc`] kan, ṣugbọn eyi yoo pada [`None`] ti iye ti o fipamọ sinu ipin naa ba ti lọ silẹ tẹlẹ.
//! Ni awọn ọrọ miiran, awọn itọka `Weak` ko tọju iye inu inu ipin naa laaye;sibẹsibẹ, wọn *ṣe* tọju ipin naa (ile itaja atilẹyin fun iye ti inu) laaye.
//!
//! Ayika kan laarin awọn atọka [`Rc`] kii yoo pin ni ibi rara.
//! Fun idi eyi, a lo [`Weak`] lati fọ awọn iyika.
//! Fun apẹẹrẹ, igi kan le ni awọn itọka [`Rc`] ti o lagbara lati awọn apa obi si awọn ọmọde, ati awọn atọka [`Weak`] lati ọdọ awọn ọmọ pada si awọn obi wọn.
//!
//! `Rc<T>` awọn iforukọsilẹ laifọwọyi si `T` (nipasẹ [`Deref`] trait), nitorinaa o le pe awọn ọna T` lori iye ti iru [`Rc<T>`][`Rc`].
//! Lati yago fun awọn iforukọsilẹ orukọ pẹlu awọn ọna T`, awọn ọna ti [`Rc<T>`][`Rc`] funrararẹ jẹ awọn iṣẹ to somọ, ti a pe ni lilo [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! Rc<T>Awọn imuṣẹ ti traits bii `Clone` le tun pe ni lilo sintasi ti o pe ni kikun.
//! Diẹ ninu awọn eniyan fẹran lati lo ilana itọsẹ ti o ni kikun, lakoko ti awọn miiran fẹran lilo sintasi ọna-ipe.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Iṣeduro ipe-ọna
//! let rc2 = rc.clone();
//! // Iṣeduro ti o ni kikun
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ko ṣe iforukọsilẹ-aifọwọyi si `T`, nitori iye ti inu le ti lọ silẹ tẹlẹ.
//!
//! # Awọn itọkasi awọ
//!
//! Ṣiṣẹda itọkasi tuntun si ipin kanna bi itọkasi itọkasi ti a ka kika ijuboluwo ti ṣe ni lilo `Clone` trait ti a ṣe fun [`Rc<T>`][`Rc`] ati [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Awọn sintasi meji ti o wa ni isalẹ jẹ deede.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ati b mejeji ntoka si ipo iranti kanna bi foo.
//! ```
//!
//! Iṣeduro `Rc::clone(&from)` jẹ idiomatiki ti o pọ julọ nitori pe o ṣafihan alaye kedere ni koodu naa.
//! Ninu apẹẹrẹ loke, iṣọpọ yii jẹ ki o rọrun lati rii pe koodu yii n ṣẹda itọkasi tuntun dipo ki o daakọ gbogbo akoonu foo.
//!
//! # Examples
//!
//! Wo iwoye kan nibiti a ti ṣeto `Gadget`s ti ohun-ini nipasẹ `Owner` ti a fifun.
//! A fẹ lati ni aaye `Gadget`s wa si `Owner` wọn.A ko le ṣe eyi pẹlu ohun-ini alailẹgbẹ, nitori pe ohun elo ju ọkan lọ le jẹ ti `Owner` kanna.
//! [`Rc`] gba wa laaye lati pin `Owner` laarin ọpọ `Gadget`s, ati pe ki `Owner` wa ni ipin sọtọ niwọn igba ti awọn aaye `Gadget` eyikeyi ninu rẹ.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... awọn aaye miiran
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... awọn aaye miiran
//! }
//!
//! fn main() {
//!     // Ṣẹda itọkasi-ka `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Ṣẹda ti ohun elo `Gadget` ti iṣe ti `gadget_owner`.
//!     // Ṣiṣẹda `Rc<Owner>` fun wa ni ijuboluwole tuntun si ipin `Owner` kanna, ni afikun iye kika ni ilana naa.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Sọ oniyipada agbegbe wa `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Pelu sisọ `gadget_owner` silẹ, a tun ni anfani lati tẹ orukọ `Owner` ti `Gadget`s jade.
//!     // Eyi jẹ nitori a ti sọ `Rc<Owner>` nikan silẹ, kii ṣe `Owner` ti o tọka si.
//!     // Niwọn igba ti `Rc<Owner>` miiran ti n tọka si ipin `Owner` kanna, yoo wa laaye.
//!     // Asọtẹlẹ aaye `gadget1.owner.name` n ṣiṣẹ nitori `Rc<Owner>` awọn iforukọsilẹ laifọwọyi si `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ni opin iṣẹ naa, `gadget1` ati `gadget2` ti parun, ati pẹlu wọn awọn itọkasi ti o kẹhin ti o ka si `Owner` wa.
//!     // Eniyan Gadget bayi di iparun pẹlu.
//!     //
//! }
//! ```
//!
//! Ti awọn ibeere wa ba yipada, ati pe a tun nilo lati ni anfani lati kọja lati `Owner` si `Gadget`, a yoo ni awọn iṣoro.
//! Atọka [`Rc`] kan lati `Owner` si `Gadget` ṣafihan iyipo kan.
//! Eyi tumọ si pe awọn iṣiro itọkasi wọn ko le de ọdọ 0, ati pe ipin naa kii yoo run:
//! iranti jo.Lati le wa nitosi eyi, a le lo awọn itọka [`Weak`].
//!
//! Rust kosi jẹ ki o nira diẹ lati ṣe agbejade lupu yii ni akọkọ.Lati le pari pẹlu awọn iye meji ti o tọka si ara wọn, ọkan ninu wọn nilo lati jẹ iyipada.
//! Eyi nira nitori [`Rc`] n mu aabo iranti ṣiṣẹ nipa fifun awọn itọkasi pinpin nikan si iye ti o di, ati awọn wọnyi ko gba laaye iyipada taara.
//! A nilo lati fi ipari si apakan ti iye ti a fẹ lati yipada ni [`RefCell`] kan, eyiti o pese *iyipada inu*: ọna lati ṣe aṣeyọri iyipada nipasẹ itọkasi pinpin.
//! [`RefCell`] mu lagabara awọn ofin yiya Rust ni asiko asiko.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... awọn aaye miiran
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... awọn aaye miiran
//! }
//!
//! fn main() {
//!     // Ṣẹda itọkasi-ka `Owner`.
//!     // Akiyesi pe a ti fi vector ti Olohun ti `Gadget` inu inu `RefCell` kan ki a le ṣe iyipada rẹ nipasẹ itọkasi itọkasi.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Ṣẹda ti ohun elo `Gadget` ti iṣe ti `gadget_owner`, bi tẹlẹ.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Ṣafikun awọn `Gadget`s si `Owner` wọn.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ìmúdàgba yiya pari nibi.
//!     }
//!
//!     // Ṣe imukuro lori awọn ohun elo `Gadget`s wa, titẹ awọn alaye wọn jade.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` jẹ `Weak<Gadget>`.
//!         // Niwọn igba ti awọn atọka `Weak` ko le ṣe onigbọwọ ipin naa ṣi wa, a nilo lati pe `upgrade`, eyiti o da `Option<Rc<Gadget>>` kan pada.
//!         //
//!         //
//!         // Ni ọran yii a mọ pe ipin naa tun wa, nitorinaa a rọrun `unwrap` `Option` naa.
//!         // Ninu eto ti o nira diẹ sii, o le nilo mimu aṣiṣe aṣiṣe ore-ọfẹ fun abajade `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ni opin iṣẹ naa, `gadget_owner`, `gadget1`, ati `gadget2` ti parun.
//!     // Ko si awọn itọka (`Rc`) lagbara si awọn irinṣẹ, nitorinaa wọn run.
//!     // Eyi jẹ odo kaakiri itọkasi lori Man Gadget, nitorinaa o parun bakanna.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Eyi ni repr(C) si ẹri future lodi si atunṣe-pada aaye, eyiti yoo dabaru pẹlu bibẹkọ ti [into|from]_raw() ailewu ti awọn oriṣi gbigbe to ṣee gbe.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Atọka kika kika kika kan-asapo.'Rc' duro fun 'Itọkasi
/// Counted'.
///
/// Wo [module-level documentation](./index.html) fun awọn alaye diẹ sii.
///
/// Awọn ọna abayọ ti `Rc` jẹ gbogbo awọn iṣẹ to somọ, eyiti o tumọ si pe o ni lati pe wọn bi apẹẹrẹ, [`Rc::get_mut(&mut value)`][get_mut] dipo `value.get_mut()`.
/// Eyi yago fun awọn ija pẹlu awọn ọna ti iru `T` ti inu.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ailewu yii dara nitori pe lakoko ti Rc yii wa laaye a ni idaniloju pe ijuboluwole inu jẹ wulo.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Oro titun kan `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // O wa ijuboluwo ailagbara ti o jẹ ti gbogbo awọn itọka ti o lagbara, eyiti o ṣe idaniloju pe apanirun ti ko lagbara ko ṣe ipin ipin lakoko ti apanirun ti o lagbara n ṣiṣẹ, paapaa ti o ba tọka ijuboluwo ti o lagbara ninu ọkan lagbara.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Ṣe `Rc<T>` tuntun ni lilo itọkasi ailagbara si ara rẹ.
    /// Igbidanwo lati ṣe igbesoke itọkasi alailagbara ṣaaju iṣẹ yii pada yoo mu ki iye `None` kan wa.
    ///
    /// Sibẹsibẹ, itọkasi alailagbara le jẹ cloned larọwọto ati fipamọ fun lilo ni akoko nigbamii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... diẹ awọn aaye
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ṣe akojọpọ inu ni ipo "uninitialized" pẹlu itọkasi alailagbara kan.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // O ṣe pataki ki a maṣe fi ohun-ini silẹ ti ijuboluwo ailagbara, tabi bẹẹkọ iranti le ni ominira nipasẹ akoko `data_fn` ti o pada.
        // Ti a ba fẹ gaan lati kọja nini, a le ṣẹda atokun alailagbara afikun fun ara wa, ṣugbọn eyi yoo ja si awọn afikun awọn imudojuiwọn si kika itọkasi ailagbara eyiti o le ma ṣe pataki bibẹẹkọ.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Awọn itọkasi to lagbara yẹ ki o jọ ni itọkasi alailagbara pipin, nitorinaa maṣe ṣiṣe apanirun fun itọkasi atijọ wa.
        //
        mem::forget(weak);
        strong
    }

    /// Ṣe `Rc` tuntun pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ṣe `Rc` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ṣe `Rc<T>` tuntun kan, dapada aṣiṣe kan ti ipin naa ba kuna
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // O wa ijuboluwo ailagbara ti o jẹ ti gbogbo awọn itọka ti o lagbara, eyiti o ṣe idaniloju pe apanirun ti ko lagbara ko ṣe ipin ipin lakoko ti apanirun ti o lagbara n ṣiṣẹ, paapaa ti o ba tọka ijuboluwo ti o lagbara ninu ọkan lagbara.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Ṣe `Rc` tuntun pẹlu awọn akoonu ti ko ni oye, dapada aṣiṣe kan ti ipin naa ba kuna
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ṣe `Rc` tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`, dapada aṣiṣe kan ti ipin naa ba kuna
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ṣe `Pin<Rc<T>>` tuntun kan.
    /// Ti `T` ko ba ṣe `Unpin`, lẹhinna `value` yoo wa ni PIN ni iranti ati pe ko le gbe.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Pada iye inu, ti `Rc` ba ni itọkasi itọkasi to lagbara kan.
    ///
    /// Bibẹẹkọ, [`Err`] ti pada pẹlu `Rc` kanna ti o kọja.
    ///
    ///
    /// Eyi yoo ṣaṣeyọri paapaa ti awọn itọkasi ailagbara titayọ wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // daakọ nkan ti o wa ninu rẹ

                // Ṣe afihan si Weaks pe wọn ko le ṣe igbega nipasẹ didin ka iye to lagbara, ati lẹhinna yọ ijuboluwole "strong weak" ti o han gbangba lakoko ti o tun mu ọgbọn ọgbọn ti o ju silẹ nipasẹ sisẹ ni iro Alailagbara kan.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Ṣe gige ege kika-itọkasi tuntun pẹlu awọn akoonu ti ko ni oye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Ṣe iru ege ti a ka-itọkasi tuntun pẹlu awọn akoonu ti ko ni oye, pẹlu iranti ti o kun pẹlu awọn baiti `0`.
    ///
    ///
    /// Wo [`MaybeUninit::zeroed`][zeroed] fun awọn apẹẹrẹ ti lilo ti o tọ ati ti ko tọ ti ọna yii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Awọn iyipada si `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe iye ti inu wa gaan ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Awọn iyipada si `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Bii [`MaybeUninit::assume_init`], o jẹ fun olupe naa lati ṣe idaniloju pe iye ti inu wa gaan ni ipo ipilẹṣẹ.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ibẹrẹ ti a da duro:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Je `Rc` run, n pada ijuboluwole ti a we.
    ///
    /// Lati yago fun jo iranti ijuboluwole gbọdọ wa ni iyipada pada si `Rc` nipa lilo [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pese ijuboluwole ijuboluwole si data naa.
    ///
    /// Awọn kika ko ni ipa ni eyikeyi ọna ati pe `Rc` ko run.
    /// Atọka naa wulo fun igba ti awọn iṣiro to lagbara ni `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // Aabo: Eyi ko le kọja nipasẹ Deref::deref tabi Rc::inner nitori
        // eyi ni a nilo lati ṣe idaduro imudaniloju raw/mut bii apẹẹrẹ
        // `get_mut` le kọ nipasẹ ijuboluwole lẹhin ti Rc ti gba pada nipasẹ `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Ṣe `Rc<T>` kan lati ọdọ ijuboluwo to aise.
    ///
    /// Atọka aise gbọdọ ti ni iṣaaju nipasẹ ipe si [`Rc<U>::into_raw`][into_raw] nibiti `U` gbọdọ ni iwọn kanna ati titọ bi `T`.
    /// Eyi jẹ otitọ bintin ti `U` jẹ `T`.
    /// Akiyesi pe ti `U` kii ṣe `T` ṣugbọn o ni iwọn kanna ati titete, eyi jẹ ipilẹ bi awọn itọkasi gbigbejade ti awọn oriṣiriṣi oriṣi.
    /// Wo [`mem::transmute`][transmute] fun alaye diẹ sii lori awọn ihamọ wo lo ninu ọran yii.
    ///
    /// Olumulo ti `from_raw` ni lati rii daju pe iye kan pato ti `T` nikan silẹ lẹẹkan.
    ///
    /// Iṣẹ yii ko ni aabo nitori lilo aibojumu le ja si ailewu ailewu, paapaa ti `Rc<T>` ti o pada ko wọle rara.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pada pada si `Rc` lati yago fun jijo.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Awọn ipe siwaju si `Rc::from_raw(x_ptr)` yoo jẹ ailewu-iranti.
    /// }
    ///
    /// // Iranti naa ti ni ominira nigbati `x` ti jade ni aaye ti o wa loke, nitorinaa `x_ptr` ti nsaba bayi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Yiyipada aiṣedeede lati wa atilẹba RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ṣẹda ijuboluwole [`Weak`] tuntun si ipin yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Rii daju a ko ṣẹda a purpili lagbara
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Gba nọmba ti awọn itọka [`Weak`] si ipin yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Gba nọmba ti awọn itọka (`Rc`) lagbara si ipin yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Pada `true` ti ko ba si awọn atọka `Rc` tabi [`Weak`] miiran si ipin yii.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Pada itọkasi iyipada sinu `Rc` ti a fun, ti ko ba si awọn itọka `Rc` miiran tabi [`Weak`] si ipin kanna.
    ///
    ///
    /// Pada [`None`] bibẹkọ, nitori ko ṣe ailewu lati yi iye ti o pin pada.
    ///
    /// Wo tun [`make_mut`][make_mut], eyiti yoo [`clone`][clone] iye inu nigbati awọn itọka miiran wa.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Pada itọkasi iyipada kan sinu `Rc` ti a fun, laisi ayẹwo eyikeyi.
    ///
    /// Wo tun [`get_mut`], eyiti o jẹ ailewu ati pe o ṣe awọn sọwedowo ti o yẹ.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Eyikeyi awọn itọka `Rc` tabi [`Weak`] miiran si ipin kanna ko gbọdọ ṣe igbasilẹ fun iye akoko awin ti o pada.
    ///
    /// Eyi jẹ ọrọ kekere ti ko ba si iru awọn atọka tẹlẹ, fun apẹẹrẹ lẹsẹkẹsẹ lẹhin `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // A ṣọra lati *ma ṣe* ṣẹda itọkasi kan ti o bo awọn aaye "count", nitori eyi yoo rogbodiyan pẹlu awọn iraye si awọn iṣiro itọkasi (fun apẹẹrẹ.
        // nipasẹ `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Pada `true` ti o ba jẹ pe awọn `Rc`s meji naa tọka si ipin kanna (ni iṣọn ti o jọra [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Ṣe itọkasi iyipada si `Rc` ti a fun.
    ///
    /// Ti awọn atọka `Rc` miiran wa si ipin kanna, lẹhinna `make_mut` yoo [`clone`] iye inu si ipin tuntun lati rii daju nini nini alailẹgbẹ.
    /// Eyi tun tọka si bi ẹda-on-kọ.
    ///
    /// Ti ko ba si awọn itọka `Rc` miiran si ipin yii, lẹhinna awọn atọka [`Weak`] si ipin yii yoo pin.
    ///
    /// Wo tun [`get_mut`], eyiti yoo kuna kuku ju ẹda oniye.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Yoo ko oniye ohunkohun
    /// let mut other_data = Rc::clone(&data);    // Yoo ko oniye data inu
    /// *Rc::make_mut(&mut data) += 1;        // Clones data inu
    /// *Rc::make_mut(&mut data) += 1;        // Yoo ko oniye ohunkohun
    /// *Rc::make_mut(&mut other_data) *= 2;  // Yoo ko oniye ohunkohun
    ///
    /// // Bayi `data` ati `other_data` tọka si awọn ipin oriṣiriṣi.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] awọn itọka yoo wa ni ipin:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Yoo ṣe ẹda oniye data naa, awọn Rcs miiran wa.
            // Ṣaaju-fi iranti silẹ lati gba kikọ iye oniye taara.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Le kan ji data naa, gbogbo ohun ti o ku ni Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Yọ adaṣe alailagbara lagbara (ko si ye lati ṣiṣẹda Ailagbara irọ kan nibi-a mọ pe Awọn Weaks miiran le sọ di mimọ fun wa)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ailewu yii dara nitori a ni idaniloju pe ijuboluwole ti o pada ni itọka *nikan* ti yoo tun pada si T.
        // Nọmba itọkasi wa ni idaniloju lati jẹ 1 ni aaye yii, ati pe a nilo `Rc<T>` funrararẹ lati jẹ `mut`, nitorinaa a pada tọka itọkasi ti o ṣee ṣe si ipin naa.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Igbiyanju lati sọ isalẹ `Rc<dyn Any>` si iru nja.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Yipada `RcBox<T>` kan pẹlu aaye ti o to fun iye ti inu ti o ṣee-ko ṣe iwọn nibiti iye ti ni ipilẹ ti a pese.
    ///
    /// Iṣẹ `mem_to_rcbox` ni a pe pẹlu ijuboluwo data ati pe o gbọdọ pada apilẹkọ kan (ti o ni agbara ti o sanra) fun `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Ṣe iṣiro ipilẹ nipa lilo ifilelẹ iye ti a fun.
        // Ni iṣaaju, a ṣe iṣiro akọkọ lori ikosile `&*(ptr as* const RcBox<T>)`, ṣugbọn eyi ṣẹda itọkasi ti ko tọ (wo #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Pin `RcBox<T>` kan pẹlu aaye ti o to fun iye ti inu ti o ṣee-ko ṣe iwọn nibiti iye ti ni ipilẹ ti a pese, dapada aṣiṣe kan ti ipin ba kuna.
    ///
    ///
    /// Iṣẹ `mem_to_rcbox` ni a pe pẹlu ijuboluwo data ati pe o gbọdọ pada apilẹkọ kan (ti o ni agbara ti o sanra) fun `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Ṣe iṣiro ipilẹ nipa lilo ifilelẹ iye ti a fun.
        // Ni iṣaaju, a ṣe iṣiro akọkọ lori ikosile `&*(ptr as* const RcBox<T>)`, ṣugbọn eyi ṣẹda itọkasi ti ko tọ (wo #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Pin fun ipilẹ.
        let ptr = allocate(layout)?;

        // Ni ipilẹṣẹ RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Pín ohun `RcBox<T>` pẹlu aaye ti o to fun iye ti inu ti ko ni iwọn
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Pin fun `RcBox<T>` nipa lilo iye ti a fun.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Daakọ iye bi awọn baiti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Gba ipinfunni laaye laisi sisọ awọn akoonu rẹ silẹ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Pin `RcBox<[T]>` kan pẹlu ipari ti a fifun.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Daakọ awọn eroja lati ori nkan sinu Rc tuntun ti a pin sita <\[T\]>
    ///
    /// Ailewu nitori olupe gbọdọ boya gba nini tabi di `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ṣe `Rc<[T]>` kan lati aṣetunṣe ti a mọ lati jẹ iwọn kan.
    ///
    /// Ihuwasi jẹ aisọye yẹ ki iwọn jẹ aṣiṣe.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Olutọju Panic lakoko ti o ṣe amọda awọn eroja T.
        // Ni iṣẹlẹ ti panic, awọn eroja ti a ti kọ sinu RcBox tuntun yoo wa silẹ, lẹhinna iranti ni ominira.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Atọka si akọkọ ano
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gbogbo ko o.Gbagbe oluso ki o ma ṣe gba RcBox tuntun laaye.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialization trait ti a lo fun `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Silẹ `Rc`.
    ///
    /// Eyi yoo dinku iye itọkasi itọkasi.
    /// Ti ka itọkasi itọkasi lagbara ba de odo odo lẹhinna awọn itọkasi miiran (ti o ba jẹ eyikeyi) ni [`Weak`], nitorinaa a jẹ `drop` iye inu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ko tẹ ohunkohun
    /// drop(foo2);   // Awọn titẹ "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // pa ohun ti o wa ninu run
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // yọ ijuboluwole "strong weak" ijuboluwole bayi pe a ti run awọn akoonu naa.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Ṣe ẹda oniye ti ijuboluwole `Rc`.
    ///
    /// Eyi ṣẹda ijuboluwo miiran si ipin kanna, jijẹ kika itọkasi lagbara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Ṣẹda titun kan `Rc<T>`, pẹlu awọn `Default` iye fun `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Gige lati gba amọja lori `Eq` botilẹjẹpe `Eq` ni ọna kan.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// A n ṣe amọja yii nibi, ati kii ṣe bi iṣapeye gbogbogbo diẹ sii lori `&T`, nitori yoo bibẹẹkọ yoo ṣafikun iye owo si gbogbo awọn iṣayẹwo idogba lori awọn agbapada.
/// A ro wipe `Rc`s ti wa ni lo lati fi tobi iye, ti o wa ni o lọra lati oniye, sugbon o tun eru lati ṣayẹwo fun Equality, nfa yi iye owo lati san si pa diẹ sii ni rọọrun.
///
/// O tun ṣee ṣe ki o ni awọn oniye `Rc` meji, ti o tọka si iye kanna, ju meji&T`s lọ.
///
/// A le ṣe eyi nikan nigbati `T: Eq` bi `PartialEq` kan le jẹ alainidena iyipada.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Equality fun meji `Rc`s.
    ///
    /// Meji `Rc`s dọgba ti awọn iye inu wọn ba dọgba, paapaa ti wọn ba wa ni fipamọ ni ipin ipin ọtọtọ.
    ///
    /// Ti `T` ba tun ṣe `Eq` (itumọ ifọkansi ti isọgba), awọn `Rc` meji ti o tọka si ipin kanna ni o dọgba nigbagbogbo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Aidogba fun meji `Rc`s.
    ///
    /// Meji `Rc`s jẹ aidogba ti awọn iye inu wọn ko ba dọgba.
    ///
    /// Ti `T` ba tun ṣe `Eq` (itumọ ifọkansi ti isọgba), awọn `Rc` meji ti o tọka si ipin kanna ko jẹ aidogba.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Afiwe apakan fun meji `Rc`s.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `partial_cmp()` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ifiwera kere si fun `Rc`s meji.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `<` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Kere ju tabi dogba si' afiwe fun meji 'Rc`s.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `<=` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Ifiwera titobi ju fun `Rc`s meji.
    ///
    /// A fiwe awọn meji nipa pipe `>` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'O tobi ju tabi dọgba si' afiwe fun meji 'Rc`s.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `>=` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Ifiwera fun meji 'Rc`s.
    ///
    /// Awọn mejeeji ni afiwe nipasẹ pipe `cmp()` lori awọn iye inu wọn.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Ṣe ipin ipin ti a ka-itọkasi kan ki o fọwọsi nipasẹ ṣiṣọn awọn ohun kan.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Pin ipin ege okun ti o ni itọkasi ati daakọ `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Pin ipin ege okun ti o ni itọkasi ati daakọ `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Gbe kan boxed ohun to titun kan, itọkasi kà, ipin.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Pin ipin kan ti a ka kika rẹ ki o gbe awọn ohun kan `v` sinu rẹ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Gba Vec laaye lati ṣe iranti iranti rẹ, ṣugbọn kii ṣe pa awọn akoonu rẹ run
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Gba eroja kọọkan ninu `Iterator` o si gba a sinu `Rc<[T]>` kan.
    ///
    /// # Awọn abuda iṣẹ
    ///
    /// ## Gbogbogbo ọrọ
    ///
    /// Ninu ọran gbogbogbo, gbigba sinu `Rc<[T]>` ni ṣiṣe nipasẹ gbigba akọkọ sinu `Vec<T>` kan.Iyẹn ni, nigba kikọ nkan wọnyi:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// eyi huwa bi ẹni pe a kọwe:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Eto akọkọ ti awọn ipin ṣẹlẹ nibi.
    ///     .into(); // Pipin keji fun `Rc<[T]>` ṣẹlẹ nibi.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Eyi yoo pin bi ọpọlọpọ awọn akoko bi o ṣe nilo fun kikọ `Vec<T>` ati lẹhinna o yoo pin lẹẹkan fun titan `Vec<T>` sinu `Rc<[T]>`.
    ///
    ///
    /// ## Iterators ti ipari ti a mọ
    ///
    /// Nigbati `Iterator` rẹ ba ṣe `TrustedLen` ati pe o jẹ iwọn gangan, ipin kan ni yoo ṣe fun `Rc<[T]>`.Fun apere:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // O kan ipin kan nikan ṣẹlẹ nibi.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specialization trait ti a lo fun gbigba sinu `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Eyi ni ọran fun aṣetunṣe `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Aabo: A nilo lati rii daju pe aṣetunṣe ni ipari deede ati pe a ni.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Ṣubu pada si imuse deede.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` jẹ ẹya ti [`Rc`] ti o mu itọkasi ti kii ṣe nini si ipin ti a ṣakoso.A ti pin ipin naa nipa pipe [`upgrade`] lori ijuboluwole `Weak`, eyiti o pada [`Aṣayan]]` <`[` Rc`]`<T>>
///
/// Niwọn igba ti itọkasi `Weak` ko ka si nini, kii yoo ṣe idiwọ iye ti o fipamọ sinu ipin naa silẹ, ati pe `Weak` funrararẹ ko ṣe awọn onigbọwọ nipa iye ti o tun wa.
/// Bayi o le da [`None`] pada nigbati [`igbesoke`] d.
/// Akiyesi sibẹsibẹ pe itọkasi `Weak`*ṣe* ṣe idiwọ ipin ipin funrararẹ (ile itaja atilẹyin) lati pin ni ipin.
///
/// Atọka `Weak` kan wulo fun titọju itọkasi igba diẹ si ipin ti a ṣakoso nipasẹ [`Rc`] laisi idilọwọ iye inu rẹ lati ju silẹ.
/// O tun lo lati ṣe idiwọ awọn itọkasi iyipo laarin awọn itọka [`Rc`], nitori awọn itọkasi nini ti ara ẹni kii yoo gba laaye boya [`Rc`] lọ silẹ.
/// Fun apẹẹrẹ, igi kan le ni awọn itọka [`Rc`] ti o lagbara lati awọn apa obi si awọn ọmọde, ati awọn atọka `Weak` lati ọdọ awọn ọmọ pada si awọn obi wọn.
///
/// Ọna aṣoju lati gba ijuboluwole `Weak` ni lati pe [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Eyi jẹ `NonNull` lati gba laaye iṣapeye iwọn ti iru yii ni awọn enum, ṣugbọn kii ṣe itọka to tọ.
    //
    // `Weak::new` ṣeto eyi si `usize::MAX` ki o ko nilo lati pin aaye lori okiti naa.
    // Iyẹn kii ṣe iye ti ijuboluwo gidi kan yoo ni nitori RcBox ni titete ni o kere ju 2.
    // Eyi ṣee ṣe nikan nigbati `T: Sized`;unsized `T` never dangle.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ṣe `Weak<T>` tuntun kan, laisi sọtọ eyikeyi iranti.
    /// Pipe [`upgrade`] lori iye ipadabọ nigbagbogbo fun [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Iru oluranlọwọ lati gba laaye wọle si awọn iṣiro itọkasi laisi ṣiṣe awọn idaniloju eyikeyi nipa aaye data.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Pada ijuboluwo aise si nkan `T` ti `Weak<T>` toka si.
    ///
    /// Awọn ijuboluwole wulo nikan ti o ba ti nibẹ ni o wa diẹ ninu awọn lagbara to jo.
    /// Atọka le jẹ purpili, aiṣedede tabi paapaa [`null`] bibẹẹkọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Awọn mejeeji tọka si ohun kanna
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Alagbara nibi n jẹ ki o wa laaye, nitorinaa a tun le wọle si nkan naa.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ṣugbọn kii ṣe diẹ sii.
    /// // A le ṣe weak.as_ptr(), ṣugbọn iraye si ijuboluwole yoo yorisi ihuwasi ti a ko ṣalaye.
    /// // assert_eq! ("hello", ailewu {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ti o ba ti ijuboluwole ti wa ni purpili, a pada awọn Sentinel taara.
            // Eyi ko le jẹ adirẹsi isanwo isanwo to wulo, bi isanwo isanwo ni o kere ju bi o ti ṣe deede bi RcBox (usize).
            ptr as *const T
        } else {
            // Aabo: ti is_dangling ba pada jẹ eke, lẹhinna ijuboluwole jẹ igbasilẹ.
            // O le jẹ ki isanwo sisan silẹ ni aaye yii, ati pe a ni lati ṣetọju imudaniloju, nitorinaa lo ifọwọyi ijuboluwole aise.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Gba `Weak<T>` run o si sọ di ijuboluwole aise.
    ///
    /// Eyi ṣe iyipada ijuboluwole alailera sinu ijuboluwole aise, lakoko ti o tọju ẹtọ ti nini itọkasi kan ti ko lagbara (iye ailagbara ko ni atunṣe nipasẹ iṣiṣẹ yii).
    /// O le yipada si `Weak<T>` pẹlu [`from_raw`].
    ///
    /// Awọn ihamọ kanna ti iraye si afojusun ti ijuboluwole bi pẹlu [`as_ptr`] lo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Awọn oluyipada ijuboluwole ti a ṣẹda tẹlẹ nipasẹ [`into_raw`] pada si `Weak<T>`.
    ///
    /// Eyi le ṣee lo lati ni itọkasi itọkasi lailewu (nipa pipe [`upgrade`] nigbamii) tabi lati pin ipin kaakiri ailera nipasẹ sisọ `Weak<T>` silẹ.
    ///
    /// O gba nini ti itọkasi alailagbara kan (pẹlu ayafi awọn atọka ti a ṣẹda nipasẹ [`new`], nitori iwọnyi ko ni ohunkohun; ọna naa tun n ṣiṣẹ lori wọn).
    ///
    /// # Safety
    ///
    /// Atọka gbọdọ ti ipilẹṣẹ lati [`into_raw`] ati pe o tun gbọdọ ni itọkasi itọkasi agbara rẹ.
    ///
    /// A gba ọ laaye fun kika to lagbara lati jẹ 0 ni akoko pipe eyi.
    /// Sibẹsibẹ, eyi gba nini ti itọkasi alailagbara kan ti o ni aṣoju lọwọlọwọ bi ijuboluwọn aise (iye ailagbara ko ni atunṣe nipasẹ iṣiṣẹ yii) ati nitorinaa o gbọdọ ṣe pọ pọ pẹlu ipe ti tẹlẹ si [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Decrement kẹhin ka ka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Wo Weak::as_ptr fun o tọ lori bi o ti jẹ ki ijuboluwole kikọ sii.

        let ptr = if is_dangling(ptr as *mut T) {
            // Eyi jẹ ailagbara purọ.
            ptr as *mut RcBox<T>
        } else {
            // Bibẹẹkọ, a ni idaniloju pe ijuboluwole wa lati Alailera ti ko ni wahala.
            // Aabo: data_offset jẹ ailewu lati pe, bi awọn itọkasi ptr gidi (eyiti o le lọ silẹ) T.
            let offset = unsafe { data_offset(ptr) };
            // Bayi, a yiyipada aiṣedeede lati gba gbogbo RcBox.
            // Aabo: ijuboluwo naa ti ipilẹṣẹ lati Alailagbara kan, nitorinaa aiṣedeede yii jẹ ailewu.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // Aabo: a ti gba atunyẹwo atilẹba Alailagbara akọkọ, nitorinaa o le ṣẹda Alailera naa.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Awọn igbiyanju lati ṣe igbesoke ijuboluwole `Weak` si [`Rc`] kan, idaduro fifipamọ iye inu ti o ba ṣaṣeyọri.
    ///
    ///
    /// Pada [`None`] ti iye ti inu ba ti lọ silẹ lati igba naa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Run gbogbo awọn itọka ti o lagbara.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Gba nọmba ti awọn itọka (`Rc`) lagbara ti o tọka si ipin yii.
    ///
    /// Ti o ba ṣẹda `self` nipa lilo [`Weak::new`], eyi yoo pada 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Gba nọmba awọn atọka `Weak` ti o tọka si ipin yii.
    ///
    /// Ti ko ba si awọn itọka to lagbara duro, eyi yoo pada si odo.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // iyokuro ptr alailagbara
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Pada `None` nigbati ijuboluwole n tan ati pe ko si ipin `RcBox`, (ie, nigbati a ṣẹda `Weak` yii nipasẹ `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // A ṣọra lati *kii ṣe* ṣẹda itọkasi kan ti o bo aaye "data", bi aaye le ṣe yipada ni igbakanna (fun apẹẹrẹ, ti `Rc` ti o kẹhin ba lọ silẹ, aaye data yoo ju silẹ ni aaye).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Pada `true` ti awọn `ailera` meji ba tọka si ipin kanna (ti o jọra si [`ptr::eq`]), tabi ti awọn mejeeji ko ba tọka si ipin kankan (nitori a ṣẹda wọn pẹlu `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Niwọn igba ti eyi ṣe afiwe awọn itọka o tumọ si pe `Weak::new()` yoo dọgba ara wọn, botilẹjẹpe wọn ko tọka si ipin kankan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ifiwera `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Ṣubu ijuboluwole `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ko tẹ ohunkohun
    /// drop(foo);        // Awọn titẹ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // iye ailagbara bẹrẹ ni 1, ati pe yoo lọ si odo nikan ti gbogbo awọn atọka to lagbara ba ti parẹ.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Ṣe ẹda oniye ti ijuboluwole `Weak` ti o tọka si ipin kanna.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ṣe `Weak<T>` tuntun kan, ipin iranti fun `T` laisi ipilẹṣẹ rẹ.
    /// Pipe [`upgrade`] lori iye ipadabọ nigbagbogbo fun [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: A ṣayẹwo_add nibi lati ba mem::forget ṣiṣẹ lailewu.Gegebi bi
// ti o ba jẹ mem::forget Rcs (tabi Weaks), kika-atunkọ le ṣan, ati lẹhinna o le gba ipin naa laaye lakoko awọn Rcs ti o tayọ (tabi Awọn Weaks) wa.
//
// A yọ kuro nitori eyi jẹ iru ipo ibajẹ ti a ko fiyesi nipa ohun ti o ṣẹlẹ-ko si eto gidi kan ti o yẹ ki o ni iriri eyi.
//
// Eyi yẹ ki o ni aifiyesi lori niwọn igba o ko nilo lati ṣe ẹda oniye pupọ wọnyi ni Rust ọpẹ si nini ati gbigbe-itumọ ọrọ.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // A fẹ lati ṣe iṣẹyun lori iṣan omi dipo ju silẹ iye naa.
        // Ika itọkasi kii yoo jẹ odo nigbati a pe eyi;
        // sibẹsibẹ, a fi iṣẹyun kan sii nibi lati tọka si LLVM ni bibẹkọ ti iṣapeye ti o padanu.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // A fẹ lati ṣe iṣẹyun lori iṣan omi dipo ju silẹ iye naa.
        // Ika itọkasi kii yoo jẹ odo nigbati a pe eyi;
        // sibẹsibẹ, a fi iṣẹyun kan sii nibi lati tọka si LLVM ni bibẹkọ ti iṣapeye ti o padanu.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Gba aiṣedeede laarin `RcBox` fun isanwo isanwo ni atokọ kan.
///
/// # Safety
///
/// Atọka gbọdọ tọka si (ati ni metadata to wulo fun) apeere ti o wulo tẹlẹ ti T, ṣugbọn a gba T laaye lati ju silẹ.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Ṣe deede iye ti a ko iwọn si opin RcBox naa.
    // Nitori RcBox jẹ repr(C), yoo ma jẹ aaye ti o kẹhin ninu iranti.
    // Aabo: nitori awọn iru unsized nikan ti o ṣee ṣe jẹ awọn ege, awọn nkan trait,
    // ati awọn oriṣi ita, ibeere aabo aabo titẹ sii lọwọlọwọ to lati ni itẹlọrun awọn ibeere ti align_of_val_raw;eyi jẹ alaye imuse ti ede ti o le ma gbarale ni ita ti std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}