/// Ṣẹda [`Vec`] kan ti o ni awọn ariyanjiyan naa.
///
/// `vec!` ngbanilaaye `Vec`s lati ṣalaye pẹlu iṣọpọ kanna bi awọn ọrọ idawọle.
/// Awọn ọna meji wa ti macro yii:
///
/// - Ṣẹda [`Vec`] kan ti o ni akojọ awọn eroja ti a fun:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Ṣẹda [`Vec`] lati eroja ati iwọn ti a fun:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Akiyesi pe laisi awọn ọrọ idayatọ sintasi yii ṣe atilẹyin gbogbo awọn eroja eyiti o ṣe [`Clone`] ati nọmba awọn eroja ko ni lati jẹ igbagbogbo.
///
/// Eyi yoo lo `clone` lati ṣe ẹda ẹda kan, nitorinaa o yẹ ki eniyan ṣọra nipa lilo eyi pẹlu awọn oriṣi ti o ni imuse `Clone` aiṣe deede.
/// Fun apẹẹrẹ, `vec![Rc::new(1);5] `yoo ṣẹda vector ti awọn itọkasi marun si iye odidi apoti ti o jọra, kii ṣe awọn itọkasi marun ti o tọka si awọn odidi apoti ti ominira.
///
///
/// Paapaa, ṣe akiyesi pe a gba `vec![expr; 0]` laaye, o si ṣe agbejade vector ti o ṣofo.
/// Eyi yoo tun ṣe ayẹwo `expr`, sibẹsibẹ, ati lẹsẹkẹsẹ sọ iye abajade silẹ, nitorinaa ṣe akiyesi awọn ipa ẹgbẹ.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): pẹlu cfg(test) ọna abuda `[T]::into_vec`, eyiti o nilo fun itumọ macro yii, ko si.
// Dipo lilo iṣẹ `slice::into_vec` eyiti o wa pẹlu cfg(test) NB nikan wo modulu slice::hack ni slice.rs fun alaye diẹ sii
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Ṣẹda `String` nipa lilo interpolation ti awọn ifihan asiko asiko.
///
/// Ariyanjiyan akọkọ ti `format!` gba ni okun ọna kika.Eyi gbọdọ jẹ gegebi okun.Agbara okun kika jẹ ninu "{}" ti o wa ninu.
///
/// Awọn afikun awọn ipele ti a kọja si `format!` rọpo `{}` s laarin okun kika ni aṣẹ ti a fun ayafi ti o ba lo awọn orukọ tabi ipo ipo;wo [`std::fmt`] fun alaye diẹ sii.
///
///
/// Lilo ti o wọpọ fun `format!` jẹ ifowosowopo ati idapọpọ awọn okun.
/// A lo apejọ kanna pẹlu awọn macros [`print!`] ati [`write!`], da lori ibi ti a pinnu ti okun naa.
///
/// Lati yipada iye kan si okun, lo ọna [`to_string`].Eyi yoo lo ọna kika [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ti ọna kika kika trait imuṣe aṣiṣe kan pada.
/// Eyi tọka imuse ti ko tọ lati igba `fmt::Write for String` ko da aṣiṣe kan pada funrararẹ.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Fi agbara mu ipade AST si ikosile lati mu awọn iwadii wa ni ipo apẹrẹ.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}