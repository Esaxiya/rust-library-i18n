#![stable(feature = "wake_trait", since = "1.51.0")]
//! Awọn oriṣi ati Traits fun ṣiṣẹ pẹlu awọn iṣẹ ṣiṣe asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Imuse ti titaji iṣẹ-ṣiṣe kan lori adaṣe kan.
///
/// trait yii ni a le lo lati ṣẹda [`Waker`] kan.
/// Olukọni kan le ṣalaye ifilọlẹ ti trait yii, ati lo iyẹn lati kọ Waker kan lati kọja si awọn iṣẹ ti a ṣe lori adaṣe naa.
///
/// trait yii jẹ ailewu-iranti ati yiyan ergonomic si kikọ [`RawWaker`] kan.
/// O ṣe atilẹyin apẹrẹ alaṣẹ ti o wọpọ ninu eyiti a lo data ti o lo lati ji iṣẹ-ṣiṣe kan ni [`Arc`] kan.
/// Diẹ ninu awọn alaṣẹ (paapaa awọn fun awọn ọna ifibọ) ko le lo API yii, eyiti o jẹ idi ti [`RawWaker`] wa bi yiyan fun awọn eto wọnyẹn.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Iṣẹ `block_on` ipilẹ ti o gba future kan ati ṣiṣe rẹ si ipari lori okun ti isiyi.
///
/// **Note:** Yi apẹẹrẹ iṣowo titunse fun ayedero.
/// Lati le ṣe idiwọ awọn titiipa, awọn imuṣẹ awọn ipele iṣelọpọ yoo tun nilo lati mu awọn ipe agbedemeji si `thread::unpark` bii awọn ẹbẹ itẹ-ẹiyẹ.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Olidide ti o ji okun lọwọlọwọ nigbati a pe.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ṣiṣe future kan si ipari lori okun ti o wa lọwọlọwọ.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin future ki o le di didari.
///     let mut fut = Box::pin(fut);
///
///     // Ṣẹda ipo tuntun lati firanṣẹ si future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Ṣiṣe future si ipari.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ji iṣẹ yii.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Ji iṣẹ yii laisi ji olukọ.
    ///
    /// Ti alaṣẹ kan ba ṣe atilẹyin ọna ti o din owo lati ji laisi jiji, o yẹ ki o fagilee ọna yii.
    /// Nipa aiyipada, o ṣe ere oniye [`Arc`] ati awọn ipe [`wake`] lori ẹda oniye.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // Aabo: Eyi jẹ ailewu nitori raw_waker kọle lailewu
        // RawWaker kan lati Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Iṣẹ aladani yii fun ṣiṣe RawWaker ni a lo, kuku ju
// ni fifọ eyi sinu `From<Arc<W>> for RawWaker` impl, lati rii daju pe aabo ti `From<Arc<W>> for Waker` ko dale lori fifiranṣẹ trait ti o tọ, dipo awọn iwuri mejeeji pe iṣẹ yii taara ati ni kedere.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Pikun kika kika ti aaki lati ṣe ẹda oniye rẹ.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Ji nipasẹ iye, gbigbe Arc sinu iṣẹ Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Ji nipa itọkasi, fi ipari si oluji ni ManuallyDrop lati yago fun fifisilẹ rẹ
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Idinku kika itọkasi ti Arc lori silẹ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}