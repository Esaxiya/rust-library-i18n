//! Awọn ipin Prelude
//!
//! Idi ti module yii ni lati jẹki awọn gbigbewọle wọle ti awọn nkan ti a lo ni igbagbogbo ti `alloc` crate nipa fifi ọja wọle si agbaye kan si oke awọn modulu:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;