//! A ti yipada nipasẹ UTF-8, okun dagba.
//!
//! Atokun yii ni iru [`String`], [`ToString`] trait fun iyipada si awọn okun, ati ọpọlọpọ awọn iru aṣiṣe ti o le ja si lati ṣiṣẹ pẹlu [`String`] s.
//!
//!
//! # Examples
//!
//! Awọn ọna lọpọlọpọ lo wa lati ṣẹda [`String`] tuntun lati inu ọrọ gangan:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! O le ṣẹda [`String`] tuntun lati ọkan ti o wa tẹlẹ nipa ṣiṣe pọ pẹlu
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ti o ba ni vector ti awọn baiti UTF-8 to wulo, o le ṣe [`String`] lati inu rẹ.O le ṣe iyipada naa paapaa.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // A mọ pe awọn baiti wọnyi wulo, nitorinaa a yoo lo `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// A ti yipada nipasẹ UTF-8, okun dagba.
///
/// Iru `String` jẹ iru okun ti o wọpọ julọ ti o ni nini lori awọn akoonu ti okun naa.O ni ibatan pẹkipẹki pẹlu ẹlẹgbẹ rẹ ti o yawo, atijo [`str`].
///
/// # Examples
///
/// O le ṣẹda `String` lati [a literal string][`str`] pẹlu [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// O le fi kun [`char`] kan si `String` pẹlu ọna [`push`], ki o fi apẹrẹ [`&str`] pẹlu ọna [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ti o ba ni vector ti awọn baiti UTF-8, o le ṣẹda `String` lati ọdọ rẹ pẹlu ọna [`from_utf8`]:
///
/// ```
/// // diẹ ninu awọn baiti, ni vector kan
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // A mọ pe awọn baiti wọnyi wulo, nitorinaa a yoo lo `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// String`s wulo nigbagbogbo UTF-8.Eyi ni awọn itumọ diẹ, akọkọ eyiti o jẹ pe ti o ba nilo okun ti kii ṣe UTF-8, ronu [`OsString`].O jẹ iru, ṣugbọn laisi idiwọ UTF-8.Idawọle keji ni pe o ko le ṣe atọka sinu `String` kan:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Atọka atọka ti pinnu lati jẹ iṣẹ ṣiṣe igbagbogbo, ṣugbọn aiyipada UTF-8 ko gba wa laaye lati ṣe eyi.Siwaju si, ko ṣalaye iru iru ohun ti atọka yẹ ki o pada: baiti kan, kodẹki kan, tabi iṣupọ grapheme.
/// Awọn ọna [`bytes`] ati [`chars`] da awọn iterators pada lori akọkọ meji, lẹsẹsẹ.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// Ṣiṣẹ String`s [`Deref`]` `<Target=str>`, ati nitorinaa jogun gbogbo awọn ọna [`str`] `.Ni afikun, eyi tumọ si pe o le kọja `String` si iṣẹ kan eyiti o gba [`&str`] nipa lilo XSPX ampersand:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Eyi yoo ṣẹda [`&str`] lati `String` ki o kọja ni. Iyipada yii jẹ ilamẹjọ pupọ, ati nitorinaa ni gbogbogbo, awọn iṣẹ yoo gba [`&str`] s bi awọn ariyanjiyan ayafi ti wọn ba nilo `String` fun idi pataki kan.
///
/// Ni awọn ọrọ kan Rust ko ni alaye ti o to lati ṣe iyipada yii, ti a mọ ni ipa mu [`Deref`].Ninu apẹẹrẹ atẹle atẹle gige okun [`&'a str`][`&str`] ṣe imuse trait `TraitExample`, ati pe iṣẹ `example_func` gba ohunkohun ti o ṣe imuse trait.
/// Ninu ọran yii Rust yoo nilo lati ṣe awọn iyipada meji ti o han gbangba, eyiti Rust ko ni awọn ọna lati ṣe.
/// Fun idi naa, apẹẹrẹ atẹle kii yoo ṣajọ.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Awọn aṣayan meji wa ti yoo ṣiṣẹ dipo.Ni igba akọkọ ti yoo jẹ lati yi laini `example_func(&example_string);` pada si `example_func(example_string.as_str());`, ni lilo ọna [`as_str()`] lati jade ni gige ege okun ti o ni okun naa.
/// Ọna keji yipada `example_func(&example_string);` si `example_func(&*example_string);`.
/// Ni ọran yii a ṣe igbasilẹ `String` kan si [`str`][`&str`], lẹhinna tọka [`str`][`&str`] pada si [`&str`].
/// Ọna keji jẹ idiomatic diẹ sii, sibẹsibẹ awọn mejeeji ṣiṣẹ lati ṣe iyipada ni gbangba kuku ju gbigbe ara le iyipada aiṣe-taara.
///
/// # Representation
///
/// A `String` jẹ awọn paati mẹta: ijuboluwo si diẹ ninu awọn baiti, gigun kan, ati agbara kan.Atọka n tọka si ifipamọ inu `String` nlo lati tọju data rẹ.Gigun ni nọmba awọn baiti ti o wa ni ipamọ lọwọlọwọ, ati agbara ni iwọn ifipamọ ni awọn baiti.
///
/// Bii iru eyi, ipari yoo ma din tabi dogba si agbara.
///
/// Ifipamọ yii nigbagbogbo wa ni fipamọ lori okiti.
///
/// O le wo awọn wọnyi pẹlu awọn ọna [`as_ptr`], [`len`], ati [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Ṣe imudojuiwọn eyi nigbati vec_into_raw_parts ti wa ni diduro.
/// // Ṣe idiwọ sisọ data Okun silẹ laifọwọyi
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // itan ni o ni mọkandinlogun baiti
/// assert_eq!(19, len);
///
/// // A le tun kọ okun kan jade kuro ninu ptr, yiya, ati agbara.
/// // Eyi ko ni ailewu nitori a jẹ iduro fun ṣiṣe idaniloju pe awọn paati wulo:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ti o ba ti a `String` ni o ni to agbara, fifi eroja to o yoo ko tun-allocate.Fun apẹẹrẹ, ro yi eto:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Eyi yoo jade awọn atẹle:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Ni akọkọ, a ko ni iranti iranti rara, ṣugbọn bi a ṣe fi ara mọ okun, o mu ki agbara rẹ pọ si deede.Ti a ba dipo lo ọna [`with_capacity`] lati ṣe ipin agbara to tọ ni ibẹrẹ:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// A pari pẹlu iṣelọpọ oriṣiriṣi:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Nibi, ko si ye lati pin iranti diẹ sii ninu lupu.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Iye aṣiṣe ti o ṣee ṣe nigbati o ba yipada `String` lati UTF-8 baiti vector.
///
/// Iru yii ni iru aṣiṣe fun ọna [`from_utf8`] lori [`String`].
/// A ṣe apẹrẹ ni iru ọna lati yago fun awọn ipo gidi ni pẹlẹpẹlẹ: ọna [`into_bytes`] yoo fun pada baiti vector ti a lo ninu igbiyanju iyipada.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Iru [`Utf8Error`] ti a pese nipasẹ [`std::str`] duro fun aṣiṣe ti o le waye nigbati o ba nyi nkan ti [`u8`] s pada si [`&str`] kan.
/// Ni ori yii, o jẹ afọwọṣe si `FromUtf8Error`, ati pe o le gba ọkan lati `FromUtf8Error` nipasẹ ọna [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Iye aṣiṣe ti o ṣee ṣe nigbati o ba yipada `String` kan lati bibẹ pẹlẹbẹ baiti UTF-16.
///
/// Iru yii ni iru aṣiṣe fun ọna [`from_utf16`] lori [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Ṣẹda `String` tuntun ti o ṣofo.
    ///
    /// Fun ni pe `String` ṣofo, eyi kii yoo fi ipinfunni akọkọ silẹ.Lakoko ti iyẹn tumọ si pe iṣiṣẹ akọkọ yii jẹ ilamẹjọ pupọ, o le fa ipin to pọ ju nigbamii nigbati o ba ṣafikun data.
    ///
    /// Ti o ba ni imọran iye data ti `String` yoo mu, ṣe akiyesi ọna [`with_capacity`] lati yago fun ipin-ipin pupọ.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Ṣẹda `String` tuntun ti o ṣofo pẹlu agbara kan pato.
    ///
    /// `String`s ni ifipamọ inu lati mu data wọn dani.
    /// Agbara naa ni gigun ti ifipamọ yẹn, ati pe a le beere pẹlu ọna [`capacity`].
    /// Ọna yii ṣẹda `String` ti o ṣofo, ṣugbọn ọkan pẹlu ifipamọ akọkọ ti o le mu awọn baiti `capacity`.
    /// Eleyi jẹ wulo nigba ti o le wa ni appending kan ti opo ti data si `String`, atehinwa awọn nọmba ti reallocations o nilo lati ṣe.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ti agbara ti a fun ni `0`, ko si ipin kankan ti yoo waye, ati pe ọna yii jẹ aami si ọna [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Okun naa ko ni awọn abọ, botilẹjẹpe o ni agbara fun diẹ sii
    /// assert_eq!(s.len(), 0);
    ///
    /// // Gbogbo wọn ni a ṣe laisi tito ipin ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ṣugbọn eyi le jẹ ki okun sọ di gidi
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): pẹlu cfg(test) ọna abuda `[T]::to_vec`, eyiti o nilo fun itumọ ọna yii, ko si.
    // Niwọn igba ti a ko beere ọna yii fun awọn idi idanwo, Emi yoo kan sọ ọ NB wo modulu slice::hack ni slice.rs fun alaye diẹ sii
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Iyipada vector ti awọn baiti si `String` kan.
    ///
    /// Okun ([`String`]) jẹ ti awọn baiti ([`u8`]), ati vector ti awọn baiti ([`Vec<u8>`]) jẹ ti awọn baiti, nitorinaa iṣẹ yii yipada laarin awọn meji.
    /// Kii ṣe gbogbo awọn ege baiti ni o wulo `String`s, sibẹsibẹ: `String` nilo pe o wulo UTF-8.
    /// `from_utf8()` awọn sọwedowo lati rii daju pe awọn baiti jẹ UTF-8 to wulo, ati lẹhinna ṣe iyipada.
    ///
    /// Ti o ba da ọ loju pe bibẹ pẹlẹbẹ naa jẹ UTF-8 ti o tọ, ati pe o ko fẹ lati fa ori oke ti ayẹwo iṣe, ẹya ti ko ni aabo ti iṣẹ yii wa, [`from_utf8_unchecked`], eyiti o ni ihuwasi kanna ṣugbọn fo ayẹwo naa.
    ///
    ///
    /// Ọna yii yoo ṣe akiyesi lati ma ṣe daakọ vector, fun ṣiṣe ṣiṣe.
    ///
    /// Ti o ba nilo a [`&str`] dipo ti a `String`, ro [`str::from_utf8`].
    ///
    /// Onidakeji ti ọna yii jẹ [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Pada si [`Err`] ti bibẹrẹ ko ba jẹ UTF-8 pẹlu apejuwe bii idi ti awọn baiti ti a pese ko jẹ UTF-8.vector ti o gbe wọle tun wa pẹlu.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti, ni vector kan
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // A mọ pe awọn baiti wọnyi wulo, nitorinaa a yoo lo `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Awọn baiti ti ko tọ:
    ///
    /// ```
    /// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Wo awọn iwe aṣẹ fun [`FromUtf8Error`] fun awọn alaye diẹ sii lori ohun ti o le ṣe pẹlu aṣiṣe yii.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Yi awọn ege ti awọn baiti kan pada si okun, pẹlu awọn ohun kikọ ti ko wulo.
    ///
    /// Awọn gbolohun ọrọ jẹ ti awọn baiti ([`u8`]), ati awọn ege ti awọn baiti ([`&[u8]`][byteslice]) jẹ ti awọn baiti, nitorinaa iṣẹ yii yipada laarin awọn meji.Kii ṣe gbogbo awọn ege baiti jẹ awọn okun to wulo, sibẹsibẹ: a nilo awọn okun lati jẹ UTF-8 to wulo.
    /// Lakoko iyipada yii, `from_utf8_lossy()` yoo rọpo eyikeyi awọn ọna UTF-8 ti ko wulo pẹlu [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], eyiti o dabi eleyi:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ti o ba ni igboya pe bibẹrẹ baiti jẹ UTF-8 to wulo, ati pe o ko fẹ lati fa ori oke ti iyipada, ẹya ti ko ni aabo ti iṣẹ yii wa, [`from_utf8_unchecked`], eyiti o ni ihuwasi kanna ṣugbọn fo awọn sọwedowo naa.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Iṣẹ yii pada [`Cow<'a, str>`] kan pada.Ti bibẹrẹ baiti wa jẹ UTF-8 ti ko wulo, lẹhinna a nilo lati fi awọn kikọ rirọpo sii, eyi ti yoo yi iwọn okun pada, ati nitorinaa, nilo `String` kan.
    /// Ṣugbọn ti o ba jẹ pe o wulo UTF-8, a ko nilo ipin tuntun.
    /// Iru iru ipadabọ yii gba wa laaye lati mu awọn ọran mejeeji.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti, ni vector kan
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Awọn baiti ti ko tọ:
    ///
    /// ```
    /// // diẹ ninu awọn baiti invalid
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Ṣiṣe iyipada vector `v` ti o ni UTF-16-ti a yipada sinu `String`, ti o pada [`Err`] ti `v` ba ni eyikeyi data ti ko wulo.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Eyi ko ṣe nipasẹ gbigba: : <Result<_, _>> () fun awọn idi iṣẹ.
        // FIXME: iṣẹ naa le jẹ irọrun lẹẹkansi nigbati #48994 ti wa ni pipade.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Ṣe iyipada ipin `v` ti a yipada si UTF-16-sinu `String`, ni rirọpo data ti ko wulo pẹlu [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Kii [`from_utf8_lossy`] eyiti o pada [`Cow<'a, str>`] kan, `from_utf16_lossy` pada `String` kan pada lati igba UTF-16 si iyipada UTF-8 nilo ipin iranti kan.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Decomposes `String` kan sinu awọn paati aise rẹ.
    ///
    /// Pada ijuboluwole aise si data ipilẹ, ipari ti okun (ni awọn baiti), ati agbara ti a fi sọtọ ti data (ni awọn baiti).
    /// Awọn wọnyi ni awọn ariyanjiyan kanna ni aṣẹ kanna bi awọn ariyanjiyan si [`from_raw_parts`].
    ///
    /// Lẹhin pipe iṣẹ yii, olupe naa ni ẹri fun iranti ti iṣakoso tẹlẹ nipasẹ `String`.
    /// Ọna kan ti o le ṣe eyi ni lati yi iyipada ijuboluwole gigun, gigun, ati agbara pada si `String` pẹlu iṣẹ [`from_raw_parts`], gbigba gbigba apanirun lati ṣe afọmọ.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ṣẹda `String` tuntun lati gigun kan, agbara, ati ijuboluwole.
    ///
    /// # Safety
    ///
    /// Eyi jẹ ailewu ti o ga julọ, nitori nọmba awọn alailera ti a ko ṣayẹwo:
    ///
    /// * Iranti ti o wa ni `buf` nilo lati ti pin tẹlẹ nipasẹ ipin kanna ti ile-ikawe boṣewa nlo, pẹlu tito nkan ti a beere fun deede 1.
    /// * `length` nilo lati kere tabi dọgba si `capacity`.
    /// * `capacity` nilo lati jẹ iye to peye.
    /// * Awọn baiti `length` akọkọ ni `buf` nilo lati jẹ UTF-8 to wulo.
    ///
    /// Riru awọn wọnyi le fa awọn iṣoro bii ibajẹ awọn ẹya data inu ti ipin.
    ///
    /// A ni gbigbe ohun-ini ti `buf` ni gbigbe si `String` eyiti o le lẹhinna ṣe ipinpo, tunto tabi yi awọn akoonu ti iranti ti o tọka si nipasẹ itọka naa ni ifẹ rẹ.
    /// Rii daju pe ko si ohun miiran ti o lo ijuboluwole lẹhin pipe iṣẹ yii.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Ṣe imudojuiwọn eyi nigbati vec_into_raw_parts ti wa ni diduro.
    ///     // Ṣe idiwọ sisọ data Okun silẹ laifọwọyi
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Iyipada vector ti awọn baiti si `String` laisi ṣayẹwo pe okun ni UTF-8 to wulo.
    ///
    /// Wo ẹya ailewu, [`from_utf8`], fun awọn alaye diẹ sii.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori ko ṣe ṣayẹwo pe awọn baiti ti o kọja si o jẹ UTF-8 to wulo.
    /// Ti o ba ṣẹ idiwọ yii, o le fa awọn ọran ailewu ti iranti pẹlu awọn olumulo future ti `String`, bi iyoku ile-ikawe boṣewa ṣe dawọle pe `Awọn okun jẹ wulo UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti, ni vector kan
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Iyipada `String` kan si baiti vector.
    ///
    /// Eyi jẹ `String`, nitorinaa a ko nilo lati daakọ awọn akoonu rẹ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Mu awọn ege okun ti o ni gbogbo `String` jade.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Iyipada `String` kan sinu gige gige okun iyipada.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Fi ohun elo okun ti a fifun fun pẹlẹpẹlẹ opin `String` yii.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Pada agbara `Okun` yii, ni awọn baiti.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Ṣe idaniloju pe agbara `Okun` yii ni o kere ju awọn baiti `additional` ti o tobi ju gigun rẹ lọ.
    ///
    /// Agbara naa le pọ si nipasẹ diẹ sii ju awọn baiti `additional` ti o ba yan, lati yago fun awọn ibi gbigbe loorekoore.
    ///
    ///
    /// Ti o ko ba fẹ ihuwasi "at least" yii, wo ọna [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Eyi le ma ṣe mu agbara pọ si gangan:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s bayi ni ipari ti 2 ati agbara ti 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Niwọn igba ti a ti ni agbara 8 afikun, pipe eyi ...
    /// s.reserve(8);
    ///
    /// // ... ko pọ si gaan.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Ṣe idaniloju pe agbara `Okun` yii jẹ awọn baiti `additional` ti o tobi ju gigun rẹ lọ.
    ///
    /// Ṣe akiyesi lilo ọna [`reserve`] ayafi ti o ba mọ daradara ju ipin lọ.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ti agbara tuntun ba bori `usize`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Eyi le ma ṣe mu agbara pọ si gangan:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s bayi ni ipari ti 2 ati agbara ti 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Niwọn igba ti a ti ni agbara 8 afikun, pipe eyi ...
    /// s.reserve_exact(8);
    ///
    /// // ... ko pọ si gaan.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Gbiyanju lati ṣura agbara fun o kere ju `additional` awọn eroja diẹ sii lati fi sii ni `String` ti a fun.
    /// Gbigba naa le ṣetọju aaye diẹ sii lati yago fun awọn ibi gbigbe loorekoore.
    /// Lẹhin pipe `reserve`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// # Errors
    ///
    /// Ti agbara ba ṣan, tabi olupilẹṣẹ ṣe ijabọ ikuna, lẹhinna aṣiṣe kan ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM ni agbedemeji iṣẹ eka wa
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Gbiyanju lati ṣura agbara to kere julọ fun gangan awọn eroja diẹ sii `additional` lati fi sii ninu `String` ti a fun.
    ///
    /// Lẹhin pipe `reserve_exact`, agbara yoo tobi ju tabi dọgba si `self.len() + additional`.
    /// Ko ṣe nkankan ti agbara ba ti to tẹlẹ.
    ///
    /// Ṣe akiyesi pe oluṣeto le fun ikojọpọ ni aaye diẹ sii ju ti o beere lọ.
    /// Nitorinaa, a ko le gbarale agbara lati jẹ pọọku ni deede.
    /// Fẹ `reserve` ti o ba nireti pe awọn ifibọ future.
    ///
    /// # Errors
    ///
    /// Ti agbara ba ṣan, tabi olupilẹṣẹ ṣe ijabọ ikuna, lẹhinna aṣiṣe kan ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Ṣetọju iranti, jade ti a ko ba le
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Bayi a mọ pe eyi ko le OOM ni agbedemeji iṣẹ eka wa
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Fọ agbara ti `String` yii lati baamu gigun rẹ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Fọ agbara ti `String` yii pẹlu adehun isalẹ.
    ///
    /// Agbara naa yoo wa ni o kere bi o tobi bi gigun ati iye ti a pese.
    ///
    ///
    /// Ti agbara lọwọlọwọ ba kere si opin isalẹ, eyi kii ṣe-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Ṣe ifilọlẹ [`char`] ti a fun ni ipari ti `String` yii.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Pada apọju baiti ti awọn akoonu `Okun` yii.
    ///
    /// Onidakeji ti ọna yii jẹ [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Kuru `String` yii si ipari ti a sọ.
    ///
    /// Ti `new_len` ba tobi ju ipari lọwọlọwọ lọwọlọwọ okun lọ, eyi ko ni ipa kankan.
    ///
    ///
    /// Akiyesi pe ọna yii ko ni ipa lori agbara ti a pin ti okun
    ///
    /// # Panics
    ///
    /// Panics ti `new_len` ko ba dubulẹ lori aala [`char`].
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Yọ ohun kikọ ti o kẹhin kuro ni ifipamọ okun ati da pada.
    ///
    /// Pada [`None`] ti `String` yii ba ṣofo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Yọ [`char`] kan lati `String` yii ni ipo baiti kan ati da pada.
    ///
    /// Eyi jẹ išišẹ *O*(*n*), bi o ṣe nilo didakọ gbogbo nkan ninu apo.
    ///
    /// # Panics
    ///
    /// Panics ti `idx` ba tobi ju tabi dogba si ipari `String`, tabi ti ko ba dubulẹ lori aala [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Yọ gbogbo awọn ere ti apẹẹrẹ `pat` ni `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// A yoo rii awọn ere-kere ati yọ kuro ni isomọ, nitorinaa ninu awọn ọran nibiti awọn apẹẹrẹ ba bori, apẹẹrẹ akọkọ nikan ni yoo yọ kuro:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // Aabo: ibẹrẹ ati ipari yoo wa lori awọn aala baiti utf8 fun
        // awọn awakọ Docs
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Ṣe idaduro awọn kikọ nikan ti asọtẹlẹ sọ tẹlẹ.
    ///
    /// Ni awọn ọrọ miiran, yọ gbogbo awọn ohun kikọ silẹ `c` bii `f(c)` ṣe pada `false`.
    /// Ọna yii n ṣiṣẹ ni aye, ṣe abẹwo si ohun kikọ kọọkan ni ẹẹkan ni aṣẹ atilẹba, ati tọju aṣẹ ti awọn kikọ idaduro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Ibere deede le wulo fun titele ipo ita, bii itọka kan.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Ntọka idx si ṣaja ti nbọ
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Awọn ifibọ ohun kikọ sinu `String` yii ni ipo baiti kan.
    ///
    /// Eyi jẹ išišẹ *O*(*n*) bi o ṣe nilo didakọ gbogbo nkan ninu apo.
    ///
    /// # Panics
    ///
    /// Panics ti `idx` ba tobi ju ipari `String`, tabi ti ko ba dubulẹ lori aala [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Awọn ifibọ gige okun sinu `String` yii ni ipo baiti kan.
    ///
    /// Eyi jẹ išišẹ *O*(*n*) bi o ṣe nilo didakọ gbogbo nkan ninu apo.
    ///
    /// # Panics
    ///
    /// Panics ti `idx` ba tobi ju ipari `String`, tabi ti ko ba dubulẹ lori aala [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Pada a mutable tọka si awọn awọn akoonu ti yi `String`.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori ko ṣe ṣayẹwo pe awọn baiti ti o kọja si o jẹ UTF-8 to wulo.
    /// Ti o ba ṣẹ idiwọ yii, o le fa awọn ọran ailewu ti iranti pẹlu awọn olumulo future ti `String`, bi iyoku ile-ikawe boṣewa ṣe dawọle pe `Awọn okun jẹ wulo UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Pada ipari gigun `String` yii, ni awọn baiti, kii ṣe [`char`] s tabi graphemes.
    /// Ni awọn ọrọ miiran, o le ma jẹ ohun ti eniyan ṣe akiyesi gigun okun.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Pada `true` ti `String` yii ba ni ipari ti odo, ati pe `false` bibẹẹkọ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Pin okun si meji ni itọka baiti ti a fun.
    ///
    /// Pada `String` tuntun ti a pin.
    /// `self` ni awọn baiti `[0, at)`, ati pe `String` ti o pada wa ni awọn baiti `[at, len)`.
    /// `at` gbọdọ wa lori ala ti aaye koodu UTF-8 kan.
    ///
    /// Ṣe akiyesi pe agbara ti `self` ko yipada.
    ///
    /// # Panics
    ///
    /// Panics ti `at` ko ba wa lori aala koodu koodu `UTF-8`, tabi ti o ba kọja aaye koodu ti o kẹhin ti okun naa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Truncates `String` yii, yọ gbogbo awọn akoonu kuro.
    ///
    /// Lakoko ti eyi tumọ si pe `String` yoo ni ipari ti odo, ko fi ọwọ kan agbara rẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Ṣẹda aṣetunṣe imugbẹ ti o yọ ibiti a ti sọ tẹlẹ ninu `String` ati mu `chars` ti o yọ kuro.
    ///
    ///
    /// Note: Ti yọ ibiti a ti yọ kuro paapaa ti a ko ba pa aṣetunṣe run titi de opin.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ tabi aaye ipari ko ba dubulẹ lori aala [`char`], tabi ti wọn ko ba ni opin.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Yọ ibiti o wa titi the lati okun
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ibiti o wa ni kikun mu okun kuro
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Aabo iranti
        //
        // Ẹya Okun ti Drain ko ni awọn ọran aabo iranti ti ẹya vector.
        // Awọn data jẹ awọn baiti pẹtẹlẹ.
        // Nitori yiyọ ibiti o ṣẹlẹ ni Drop, ti o ba jẹ pe aṣetunṣe Drain ti jo, yiyọ kuro kii yoo ṣẹlẹ.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Mu awọn awin nigbakan meji jade.
        // &mut Okun kii yoo ni iraye si titi aṣetunṣe yoo pari, ni Ju silẹ.
        let self_ptr = self as *mut _;
        // Aabo: `slice::range` ati `is_char_boundary` ṣe awọn sọwedowo awọn aala yẹ.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Yọ ibiti a ti sọ tẹlẹ ninu okun, ki o rọpo pẹlu okun ti a fun.
    /// Okun ti a fun ko nilo lati jẹ ipari kanna bi ibiti.
    ///
    /// # Panics
    ///
    /// Panics ti ibẹrẹ tabi aaye ipari ko ba dubulẹ lori aala [`char`], tabi ti wọn ko ba ni opin.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Rọpo ibiti o wa titi the lati okun
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Aabo iranti
        //
        // Rọpo_range ko ni awọn ọran aabo iranti ti Splice vector kan.
        // ti ẹya vector.Awọn data jẹ awọn baiti pẹtẹlẹ.

        // IKILO: Ṣiṣafihan oniyipada yii yoo jẹ unsound (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // IKILO: Ṣiṣafihan oniyipada yii yoo jẹ unsound (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Lilo `range` lẹẹkansi yoo jẹ ailorukọ (#81138) A ro pe awọn aala ti o jẹ iroyin nipasẹ `range` wa kanna, ṣugbọn imuse atako kan le yipada laarin awọn ipe
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Yi `String` yii pada sinu [`Box`] kan <<[[`str`] ``>.
    ///
    /// Eyi yoo ju eyikeyi agbara apọju silẹ.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Pada nkan ti awọn baiti [`u8`] ti a gbiyanju lati yipada si `String` kan.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Pada awọn baiti ti a gbiyanju lati yipada si `String` kan.
    ///
    /// Ọna yii ni a kọ daradara lati yago fun ipin.
    /// Yoo jẹ aṣiṣe naa, gbigbe awọn baiti jade, nitorina ẹda ti awọn baiti ko nilo lati ṣe.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Mu `Utf8Error` wa lati gba awọn alaye diẹ sii nipa ikuna iyipada.
    ///
    /// Iru [`Utf8Error`] ti a pese nipasẹ [`std::str`] duro fun aṣiṣe ti o le waye nigbati o ba nyi nkan ti [`u8`] s pada si [`&str`] kan.
    /// Ni ori yii, o jẹ afọwọṣe si `FromUtf8Error`.
    /// Wo iwe rẹ fun awọn alaye diẹ sii lori lilo rẹ.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // baiti akọkọ jẹ asan nibi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Nitori a n ṣe ṣiṣiṣẹ lori 'String`s, a le yago fun o kere ju ipin kan nipa gbigba okun akọkọ lati ọdọ aṣetọju ati fifi si gbogbo awọn okun atẹle.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Nitori a n ṣe sisẹ lori awọn CoW, a le (potentially) yago fun o kere ju ipin kan nipa gbigba nkan akọkọ ati fifi si gbogbo awọn nkan atẹle.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Iwuri irọrun ti awọn aṣoju si impl fun `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Ṣẹda ohun ṣofo `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Ṣiṣe awọn oniṣẹ `+` fun sisọpọ awọn okun meji.
///
/// Eyi jẹ `String` ni apa osi-ọwọ ati tun lo ifipamọ rẹ (dagba rẹ ti o ba jẹ dandan).
/// Eyi ni a ṣe lati yago fun ipin `String` tuntun ati didakọ gbogbo awọn akoonu lori gbogbo iṣẹ, eyiti yoo yorisi *O*(*n*^ 2) akoko ṣiṣiṣẹ nigbati o ba kọ okun *n*-byte nipasẹ isọdọkan tun.
///
///
/// Okun ti o wa ni apa ọtun jẹ yiya nikan;a daakọ awọn akoonu rẹ sinu `String` ti o pada.
///
/// # Examples
///
/// Concatenating meji `String`s gba akọkọ nipasẹ iye ati yawo ekeji:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ti wa ni gbigbe ati pe a ko le lo mọ nihin.
/// ```
///
/// Ti o ba fẹ tọju lilo `String` akọkọ, o le ṣe ẹda oniye rẹ ki o fi ara mọ ẹda oniye dipo:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` jẹ tun wulo nibi.
/// ```
///
/// Concatenating `&str` ege le ṣee ṣe nipa yiyipada akọkọ si `String` kan:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Ọlọnà awọn `+=` onišẹ fun appending to a `String`.
///
/// Eyi ni ihuwasi kanna bi ọna [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Orukọ inagijẹ fun [`Infallible`].
///
/// Inagijẹ yii wa fun ibaramu sẹhin, ati pe o le bajẹ nikẹhin.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait kan fun yiyipada iye kan si `String` kan.
///
/// trait yii ni aṣeṣe adaṣe fun eyikeyi iru eyiti o n ṣe imuse [`Display`] trait.
/// Bii eyi, `ToString` ko yẹ ki o wa ni imuse taara:
/// [`Display`] yẹ ki o wa ni imuse dipo, ati pe o gba imuse `ToString` fun ọfẹ.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Yi iye ti a fun pada si `String` kan.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Ninu imuse yii, ọna `to_string` panics ti imuse `Display` ba pada aṣiṣe kan.
/// Eyi tọka si imuse `Display` ti ko tọ nitori `fmt::Write for String` ko da aṣiṣe rara funrararẹ.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Itọsọna ti o wọpọ ni lati ma ṣe awọn iṣẹ jeneriki.
    // Sibẹsibẹ, yiyọ `#[inline]` kuro ni ọna yii fa awọn padasẹyin ti aifiyesi.
    // Wo <https://github.com/rust-lang/rust/pull/74852>, igbiyanju kẹhin lati gbiyanju lati yọ kuro.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Awọn iyipada `&mut str` kan sinu `String` kan.
    ///
    /// Abajade esi lori okiti.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: idanwo fa ni libstd, eyiti o fa awọn aṣiṣe nibi
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Yi awọn ege `str` apoti ti a fun pada si `String` kan.
    /// O ṣe akiyesi pe ohun-ini `str` jẹ ohun-ini.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Yi awọn `String` ti a fun pada si bibẹ pẹlẹbẹ `str` ti o ni.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Yipada ege okun sinu iyatọ Yiya.
    /// Ko si ipin okiti ti a ṣe, ati pe okun ko daakọ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Yi awọn okun pada si iyatọ Ti o ni.
    /// Ko si ipin okiti ti a ṣe, ati pe okun ko daakọ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Iyipada itọkasi Okun sinu iyatọ Yiya.
    /// Ko si ipin okiti ti a ṣe, ati pe okun ko daakọ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Yi awọn `String` ti a fun pada si vector `Vec` ti o ni awọn iye ti iru `u8`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Olutọju ṣiṣan fun `String`.
///
/// Eto yii ni a ṣẹda nipasẹ ọna [`drain`] lori [`String`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Yoo lo bi&'a mut Okun ni apanirun
    string: *mut String,
    /// Ibẹrẹ ti apakan lati yọkuro
    start: usize,
    /// Opin apakan lati yọkuro
    end: usize,
    /// Ibiti o ku lọwọlọwọ lati yọkuro
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Lo Vec::drain.
            // "Reaffirm" awọn sọwedowo awọn aala lati yago fun koodu panic ti o fi sii lẹẹkansi.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Pada okun ti o ku (iha) ti aṣetunṣe yii bi ege.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef impls ni isalẹ nigbati didaduro.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Ibanujẹ nigba didaduro `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>fun Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> fun Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}