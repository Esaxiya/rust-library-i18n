`core::arch` - Rust ká mojuto ìkàwé faaji-kan pato intrinsics
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modulu `core::arch` naa n ṣe awọn ojulowo ti o gbẹkẹle faaji (fun apẹẹrẹ SIMD).

# Usage 

`core::arch` ti o wa bi ara ti `libcore` ati awọn ti o ti wa ni tun-fi ranse nipa `libstd`.Fẹ lilo o nipasẹ `core::arch` tabi `std::arch` ju nipasẹ yi crate.
Awọn ẹya iduroṣinṣin nigbagbogbo wa ni Rust alẹ nipasẹ `feature(stdsimd)`.

Lilo `core::arch` nipasẹ crate yii nilo Rust alẹ, ati pe o le (ati ṣe) fọ nigbagbogbo.Awọn nikan igba ninu eyi ti o yẹ ki o ro nipa lilo o nipasẹ yi crate ni o wa:

* ti o ba nilo lati tun ṣajọ `core::arch` funrararẹ, fun apẹẹrẹ, pẹlu awọn ẹya-ara afojusun pato ti o ṣiṣẹ ti ko ṣiṣẹ fun `libcore`/`libstd`.
Note: ti o ba nilo lati tun ṣajọ rẹ fun ibi-afẹde ti kii ṣe deede, jọwọ fẹran lilo `xargo` ati tun-ṣajọ `libcore`/`libstd` bi o ti yẹ dipo lilo crate yii.
  
* lilo diẹ ninu awọn ẹya ara ẹrọ ti o le ko wa ani sile riru Rust ẹya ara ẹrọ.A gbiyanju lati pa awọn wọnyi lati kan kere.
Ti o ba nilo lati lo diẹ ninu awọn ẹya wọnyi, jọwọ ṣii oro kan ki a le fi wọn han ni alẹ Rust ati pe o le lo wọn lati ibẹ.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ti wa ni nipataki pin labẹ awọn ofin ti awọn mejeeji ni MIT-aṣẹ ati awọn Apache License (Version 2.0), pẹlu ipin bo nipa orisirisi BSD-bi-aṣẹ.

Wo Iwe-ašẹ-APACHE, ati iwe-ašẹ-MIT fun awọn alaye.

# Contribution

Ayafi ti o kedere ipinle bibẹkọ ti, eyikeyi ilowosi imomose silẹ fun ifisi ni `core_arch` nipa nyin, bi telẹ ni Apache-2.0 iwe-ašẹ, ki o si jẹ meji ni iwe-ašẹ bi loke, lai eyikeyi afikun awọn ofin tabi awọn ipo.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












