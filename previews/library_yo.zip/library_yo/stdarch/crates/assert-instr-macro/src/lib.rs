//! Imuse ti Makiro `#[assert_instr]`
//!
//! A lo Makiro yii nigba idanwo `stdarch` crate ati pe a lo lati ṣe awọn ọran idanwo lati sọ pe awọn iṣẹ lootọ ni awọn ilana ti a nireti pe ki wọn ni.
//!
//! Awọn ilana Makiro nibi ni jo o rọrun, o nìkan appends a `#[test]` iṣẹ si awọn atilẹba token san eyi ti asserts wipe awọn iṣẹ ara ni awọn ti o yẹ ẹkọ.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Muu assert_instr fun x86 fojusi compiled pẹlu avx sise, ti o le fa LLVM lati se ina ti o yatọ intrinsics ti awọn àwọn a ti wa ni igbeyewo fun.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // Ti awọn idanwo itọnisọna ba jẹ alaabo yago fun emitting yi dẹlẹ rara, kan da ohun atilẹba pada laisi ẹda wa.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // Awọn wọnyi ni orukọ ni o ni lati wa ni oto to fun wa lati ri ti o ni awọn disassembly nigbamii lori:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // Lo ABI lori Windows ti o kọja awọn iye SIMD ni awọn iforukọsilẹ, bii ohun ti o ṣẹlẹ lori Unix (Mo ro pe?) Ni aiyipada.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // Olupilẹṣẹ ni ipo iṣapeye nipasẹ aiyipada nṣiṣẹ igbasilẹ ti a pe ni "mergefunc" nibiti yoo dapọ awọn iṣẹ ti o jọra.
            // Ti jade diẹ ninu awọn ojulowo ṣe koodu kanna ati pe wọn ti ṣe pọ pọ, itumo pe ọkan kan fo si omiiran.
            // Yi messes soke wa se ayewo ti awọn disassembly ti yi iṣẹ ati awọn ti a ba ko kan tobi àìpẹ ti ti.
            //
            // Lati ṣe idiwọ kọja yii ati ṣe idiwọ awọn iṣẹ lati dapọ a ṣe agbekalẹ koodu kan ti o ni ireti pupọ ju ni awọn ofin ti codegen ṣugbọn bibẹẹkọ jẹ alailẹgbẹ lati ṣe idiwọ koodu lati ṣe pọ.
            //
            //
            // Ti yago fun eyi lori Wasm32 ni bayi nitori awọn iṣẹ wọnyi ko ni ilana ti o fọ awọn idanwo wa nitori pe ojulowo kọọkan dabi pe o pe awọn iṣẹ.
            // Wa jade awọn iṣẹ ni o wa ko iru to lati gba dapọ on wasm32 lonakona.
            // A tọpinpin kokoro yii ni rust-lang/rust#74320.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}