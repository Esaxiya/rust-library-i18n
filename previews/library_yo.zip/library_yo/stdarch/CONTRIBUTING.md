# Idasi si stdarch

The `stdarch` crate jẹ diẹ sii ju setan lati gba àfikún!Ni akọkọ iwọ yoo fẹ lati ṣayẹwo ibi ipamọ naa ki o rii daju pe awọn idanwo kọja fun ọ:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Nibiti `<your-target-arch>` jẹ meteta afojusun bi `rustup` ṣe lo, fun apẹẹrẹ `x86_x64-unknown-linux-gnu` (laisi eyikeyi `nightly-` ti tẹlẹ tabi iru).
Tun ranti wipe yi ipamọ nbeere nightly ikanni ti Rust!
Awọn idanwo ti o loke wa ni otitọ nilo rust alẹ lati jẹ aiyipada lori ẹrọ rẹ, lati ṣeto lilo `rustup default nightly` (ati `rustup default stable` lati pada).

Ti eyikeyi awọn igbesẹ loke ko ba ṣiṣẹ, [please let us know][new]!

Nigbamii ti o le [find an issue][issues] lati ṣe iranlọwọ lori, a ti yan diẹ pẹlu awọn aami [`help wanted`][help] ati [`impl-period`][impl] eyiti o le lo iranlọwọ diẹ paapaa. 
O le wa ni julọ nife ninu [#40][vendor], imulo gbogbo ataja intrinsics on x86.Ti oro ká ni diẹ ninu awọn ti o dara ifẹnule nipa ibi ti lati to bẹrẹ!

Ti o ba ni awọn ibeere gbogbogbo lero ọfẹ si [join us on gitter][gitter] ki o beere ni ayika!Free lero lati Pingi boya@BurntSushi tabi@alexcrichton pẹlu ibeere.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Bii o ṣe le kọ awọn apẹẹrẹ fun awọn ọrọ inu stdarch

Awọn ẹya diẹ wa ti o gbọdọ muu ṣiṣẹ fun ojulowo ti a fun lati ṣiṣẹ daradara ati apẹẹrẹ gbọdọ jẹ ṣiṣe nipasẹ `cargo test --doc` nikan nigbati ẹya ba ni atilẹyin nipasẹ Sipiyu.

Gẹgẹbi abajade, aiyipada `fn main` ti o jẹ ipilẹṣẹ nipasẹ `rustdoc` kii yoo ṣiṣẹ (ni ọpọlọpọ awọn ọran).
Ro nipa lilo awọn wọnyi bi a guide lati rii daju rẹ apẹẹrẹ iṣẹ bi o ti ṣe yẹ.

```rust
/// # // A nilo cfg_target_feature lati rii daju pe apẹẹrẹ nikan ni
/// # // ṣiṣe awọn nipa `cargo test --doc` nigbati awọn Sipiyu atilẹyin ẹya ara ẹrọ
/// # #![feature(cfg_target_feature)]
/// # // A nilo target_feature fun awọn ojulowo to iṣẹ
/// # #![feature(target_feature)]
/// #
/// # // rustdoc nipa aiyipada nlo `extern crate stdarch`, sugbon a nilo awọn
/// # // `#[macro_use]`
/// # # [Macro_use] extern crate stdarch;
/// #
/// # // Awọn ti gidi ifilelẹ ti awọn iṣẹ
/// # fn main() {
/// #     // Ṣiṣe eyi nikan ti `<target feature>` ba ni atilẹyin
/// #     ti cfg_feature_enabled! (""<target feature>"){
/// #         // Ṣẹda a `worker` iṣẹ ti yoo nikan wa ni ṣiṣe ba ti ni afojusun ẹya-ara
/// #         // ni atilẹyin ati ki o rii daju wipe `target_feature` wa ni sise fun nyin Osise
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         lewu fn worker() {
/// // Kọ apẹẹrẹ rẹ nibi.Ẹya-ara kan pato intrinsics yoo ṣiṣẹ nibi!Go egan!
///
/// #         }
///
/// #         ailewu { worker(); }
/// #     }
/// # }
```

Ti o ba ti diẹ ninu awọn ti awọn loke sintasi ko ni wo faramọ, awọn [Documentation as tests] apakan ti [Rust Book] apejuwe awọn `rustdoc` sintasi oyimbo daradara.
Bi nigbagbogbo, lero free to [join us on gitter][gitter] ki o si beere wa ti o ba ti o lu eyikeyi snags, ati o ṣeun fun ran lati mu awọn iwe ti `stdarch`!

# Awọn ilana Idanwo Yiyan

O ti wa ni gbogbo niyanju pe ki o lo `ci/run.sh` lati ṣiṣe awọn igbeyewo.
Sibẹsibẹ yi le ko sise fun nyin, eg ti o ba ti o ba wa lori Windows.

Ni ọran yẹn o le ṣubu pada si ṣiṣe `cargo +nightly test` ati `cargo +nightly test --release -p core_arch` fun idanwo irandiran koodu.
Akiyesi pe iwọnyi nilo irin-iṣẹ irinṣẹ alẹ lati fi sori ẹrọ ati fun `rustc` lati mọ nipa meteta afojusun rẹ ati Sipiyu rẹ.
Ni pato ti o nilo lati ṣeto awọn `TARGET` ayika ayípadà bi o ṣe fẹ fun `ci/run.sh`.
Ni afikun ti o nilo lati ṣeto `RUSTCFLAGS` (nilo awọn `C`) lati fihan afojusun awọn ẹya ara ẹrọ, eg `RUSTCFLAGS="-C -target-features=+avx2"`.
O tun le ṣeto `-C -target-cpu=native` ti o ba jẹ "just" ti ndagbasoke lodi si Sipiyu lọwọlọwọ rẹ.

Ki o kilo pe nigbati o ba lo awọn itọnisọna miiran, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], fun apẹẹrẹ
Awọn idanwo iran itọnisọna le kuna nitori apejọ naa lorukọ wọn ni oriṣiriṣi, fun apẹẹrẹ
o le ṣe ina `vaesenc` dipo awọn ilana `aesenc` pelu wọn huwa kanna.
Tun awọn ilana ṣiṣẹ kere igbeyewo ju yoo ni deede wa ni ṣe, ki ma wa ko le ya pe nigba ti o ba bajẹ fa-beere diẹ ninu awọn aṣiṣe le fi soke fun igbeyewo ko bo nibi.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






