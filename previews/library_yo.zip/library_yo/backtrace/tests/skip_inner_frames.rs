use backtrace::Backtrace;

// Idanwo yii n ṣiṣẹ nikan lori awọn iru ẹrọ eyiti o ni iṣẹ `symbol_address` iṣẹ fun awọn fireemu eyiti o ṣe ijabọ adirẹsi ibẹrẹ ti aami kan.
// Bi awọn kan abajade ti o ti n nikan sise lori kan diẹ iru ẹrọ.
//
const ENABLED: bool = cfg!(all(
    // Windows ko ti ni idanwo gaan, ati pe OSX ko ṣe atilẹyin wiwa wiwa fireemu ti o fi kun, nitorina mu eyi ṣiṣẹ
    //
    target_os = "linux",
    // Lori apa ti wiwa iṣẹ ikini n ṣe ipadabọ ip funrararẹ.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}