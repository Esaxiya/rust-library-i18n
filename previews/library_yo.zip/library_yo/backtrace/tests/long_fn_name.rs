use backtrace::Backtrace;

// 50-ohun kikọ module orukọ
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-ohun kikọ struct orukọ
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Long iṣẹ awọn orukọ gbọdọ wa ni truncated to (MAX_SYM_NAME, 1) ohun kikọ.
// Ṣiṣe idanwo yii nikan fun msvc, nitori gnu tẹ "<no info>" fun gbogbo awọn fireemu.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 repetitions ti struct orukọ, ki kikun oṣiṣẹ iṣẹ orukọ ni atleast 10 *(50 + 50)* 2=2000 ohun kikọ gun.
    //
    // O jẹ gangan gun nitori o tun pẹlu `::`, `<>` ati orukọ ti module lọwọlọwọ
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}