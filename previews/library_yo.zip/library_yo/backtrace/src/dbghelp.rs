//! Modulu kan lati ṣe iranlọwọ ni ṣiṣakoso awọn asopọ dbghelp lori Windows
//!
//! Awọn ẹhin sẹhin lori Windows (o kere ju fun MSVC) ni agbara pupọ nipasẹ `dbghelp.dll` ati ọpọlọpọ awọn iṣẹ ti o ni.
//! Awọn iṣẹ wọnyi ti ṣajọ lọwọlọwọ *ni agbara* dipo asopọ si `dbghelp.dll` ni iṣiro.
//! Eyi ni a ṣe lọwọlọwọ nipasẹ ile-ikawe boṣewa (ati pe o wa ni ilana ti o nilo nibẹ), ṣugbọn o jẹ igbiyanju lati ṣe iranlọwọ lati dinku awọn igbẹkẹle dll aimi ti ile-ikawe kan nitori awọn ẹhin jẹ igbagbogbo aṣayan ti o lẹwa.
//!
//! Ti a wi, `dbghelp.dll` fere nigbagbogbo ni ifijišẹ èyà on Windows.
//!
//! Akiyesi pe niwọn igba ti a n ṣajọpọ gbogbo atilẹyin yii ni agbara a ko le lo awọn asọye aise ni `winapi`, ṣugbọn kuku a nilo lati ṣalaye awọn iru ijuboluwo iṣẹ funrararẹ ati lo iyẹn.
//! A ko fẹ lati wa ninu iṣowo ti ẹda winapi pupọ, nitorinaa a ni ẹya Cargo `verify-winapi` eyiti o sọ pe gbogbo awọn abuda baamu awọn ti o wa ni winapi ati pe ẹya yii ti ṣiṣẹ lori CI.
//!
//! Lakotan, iwọ yoo ṣe akiyesi nibi pe dll fun `dbghelp.dll` ko ṣe gbejade, ati pe o jẹ imomose lọwọlọwọ.
//! Ero naa ni pe a le kaṣe kariaye ki o lo o laarin awọn ipe si API, yago fun loads/unloads ti o gbowolori.
//! Ti eyi ba jẹ iṣoro fun awọn aṣawari jijo tabi nkan bii pe a le rekọja afara nigbati a ba de sibẹ.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Ṣiṣẹ ni ayika `SymGetOptions` ati `SymSetOptions` ko wa ni winapi funrararẹ.
// Bibẹkọ ti a lo eyi nikan nigbati a ba ṣayẹwo awọn oriṣi ilọpo meji si winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ko telẹ ni winapi sibẹsibẹ
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Eyi ni asọye ni winapi, ṣugbọn ko tọ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ko telẹ ni winapi sibẹsibẹ
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// A lo Makiro yii lati ṣalaye ẹya `Dbghelp` eyiti inu wa ninu gbogbo awọn itọka iṣẹ ti a le gbe.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL ti kojọpọ fun `dbghelp.dll`
            dll: HMODULE,

            // Atọka iṣẹ kọọkan fun iṣẹ kọọkan ti a le lo
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ni ibẹrẹ a ko ti kojọpọ DLL naa
            dll: 0 as *mut _,
            // Ni ibẹrẹ gbogbo awọn iṣẹ ti ṣeto si odo lati sọ pe wọn nilo lati kojọpọ ni agbara.
            //
            $($name: 0,)*
        };

        // Irọrun irorun fun iru iṣẹ kọọkan.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Awọn igbiyanju lati ṣii `dbghelp.dll`.
            /// Pada aṣeyọri ti o ba ṣiṣẹ tabi aṣiṣe ti `LoadLibraryW` ba kuna.
            ///
            /// Panics ti o ba ti ṣawe ikawe tẹlẹ.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Iṣẹ fun ọna kọọkan ti a fẹ lati lo.
            // Nigbati a ba pe ni yoo ka ijuboluwo iṣẹ ti o kaṣe tabi fifuye rẹ ki o pada si iye ti kojọpọ.
            // Awọn ẹrù ti ni idaniloju lati ṣaṣeyọri.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Aṣoju irọrun lati lo awọn titiipa afọmọ lati tọka awọn iṣẹ dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialize gbogbo support pataki lati wọle si `dbghelp` API iṣẹ lati yi crate.
///
///
/// Akiyesi pe iṣẹ yii jẹ **ailewu**, o ni inu ni amuṣiṣẹpọ tirẹ.
/// Tun akiyesi pe o jẹ ailewu lati pe yi iṣẹ ọpọ igba recursively.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Akọkọ ohun ti a nilo lati se ni lati muu iṣẹ yi.Eyi ni a le pe ni igbakanna lati awọn okun miiran tabi ni ifasẹyin laarin okun kan.
        // Akiyesi pe o jẹ ẹtan ju iyẹn nitori nitori ohun ti a nlo nibi, `dbghelp`,*tun* nilo lati muuṣiṣẹpọ pẹlu gbogbo awọn olupe miiran si `dbghelp` ninu ilana yii.
        //
        // Ni igbagbogbo ko si pe ọpọlọpọ awọn ipe si `dbghelp` laarin ilana kanna ati pe a le rii daju lailewu pe awa nikan ni o n wọle si.
        // Sibẹsibẹ, sibẹsibẹ, olumulo akọkọ akọkọ ti a ni lati ṣe aibalẹ nipa eyiti o jẹ ironically ara wa, ṣugbọn ni ile-ikawe ti o ṣe deede.
        // The Rust boṣewa ìkàwé da lori yi crate fun backtrace support, ki o si yi crate tun wa lori crates.io.
        // Eyi tumọ si pe ti ile-ikawe boṣewa ba n tẹ sẹhin ẹhin panic o le ni ere-ije pẹlu crate yii ti o nbo lati crates.io, ti o fa awọn ifa seg.
        //
        // Lati ṣe iranlọwọ lati yanju iṣoro amuṣiṣẹpọ yii a lo ọgbọn-pato Windows kan nibi (o jẹ, lẹhinna, ihamọ Windows kan pato nipa amuṣiṣẹpọ).
        // A ṣẹda a *igba-agbegbe* ti a npè ni mutex lati dabobo yi ipe.
        // Ero ti o wa nibi ni pe ile-ikawe boṣewa ati crate yii ko ni lati pin awọn API ipele Rust lati muuṣiṣẹpọ nibi ṣugbọn o le dipo ṣiṣẹ lẹhin awọn oju iṣẹlẹ lati rii daju pe wọn n muuṣiṣẹpọ pẹlu ara wọn.
        //
        // Iyẹn ọna nigba ti a pe iṣẹ yii nipasẹ ile-ikawe boṣewa tabi nipasẹ crates.io a le rii daju pe a ti gba mutex kanna.
        //
        // Ki gbogbo awọn ti o ni lati so pe akọkọ ohun ti a se nibi ni a atomically ṣẹda a `HANDLE` ti o jẹ a npè ni mutex on Windows.
        // A muṣiṣẹpọ diẹ pẹlu awọn okun miiran ti n pin iṣẹ yii ni pataki ati rii daju pe mimu kan ṣoṣo ni a ṣẹda fun apẹẹrẹ ti iṣẹ yii.
        // Akiyesi pe mimu ko ni pipade ni kete ti o ti fipamọ ni agbaye.
        //
        // Lẹhin ti a ti sọ kosi lọ titiipa a nìkan gba o, ki o si wa `Init` mu a onitohun jade yoo jẹ lodidi fun sisọ awọn ti o bajẹ-.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Bayi pe gbogbo wa ni muuṣiṣẹpọ lailewu, jẹ ki a bẹrẹ si bẹrẹ ṣiṣe ohun gbogbo.
        // Ni akọkọ a nilo lati rii daju pe `dbghelp.dll` ti wa ni kosi kojọpọ ninu ilana yii.
        // A ṣe eyi ni agbara lati yago fun igbẹkẹle aimi.
        // Eyi ti ṣe itan-akọọlẹ lati ṣiṣẹ ni ayika awọn ọran sisopọ awọn isokuso ati pe a pinnu ni ṣiṣe awọn binaries diẹ gbigbe diẹ nitori eyi jẹ pupọ ni iwulo ifilọlẹ kan.
        //
        //
        // Ni kete ti a ti ṣii `dbghelp.dll` a nilo lati pe diẹ ninu awọn iṣẹ ipilẹṣẹ ninu rẹ, ati pe alaye diẹ sii ni isalẹ.
        // A ṣe eyi ni ẹẹkan, botilẹjẹpe, nitorinaa a ti ni iwe orin agbaye kan ti o tọka boya a ti pari sibẹsibẹ tabi rara.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Rii daju pe a ṣeto asia `SYMOPT_DEFERRED_LOADS`, nitori ni ibamu si awọn iwe ti ara ẹni MSVC nipa eyi: "This is the fastest, most efficient way to use the symbol handler.", nitorinaa jẹ ki a ṣe iyẹn!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Ni otitọ bẹrẹ awọn aami pẹlu MSVC.Ṣe akiyesi pe eyi le kuna, ṣugbọn a foju rẹ.
        // Ko si pupọ ti iṣẹ iṣaaju fun eyi fun ọkọọkan, ṣugbọn LLVM fipa inu dabi ẹnipe o foju kọ iye ti ipadabọ nibi ati ọkan ninu awọn ile-ikawe imototo ni LLVM tẹwe ikilọ ẹru kan ti eyi ba kuna ṣugbọn kọkọ kọ o ni igba pipẹ.
        //
        //
        // Ọran kan eyi ti o wa pupọ fun Rust ni pe ile-ikawe boṣewa ati crate yii lori crates.io mejeeji fẹ lati dije fun `SymInitializeW`.
        // Ile-ikawe boṣewa ti itan fẹ lati bẹrẹ lẹhinna afọmọ julọ julọ akoko, ṣugbọn nisisiyi pe o nlo crate yii o tumọ si pe ẹnikan yoo wa si ipilẹṣẹ akọkọ ati ekeji yoo gba ipilẹṣẹ yẹn.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}