//! Platform ti o gbẹkẹle omiran.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Aṣoju ominira pẹpẹ kan ti okun kan.
/// Nigbati ṣiṣẹ pẹlu `std` ṣiṣẹ o ti wa ni niyanju lati awọn ile itaja wewewe ọna fun pese awọn iyipada to `std` omiran.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Ige kan, ni igbagbogbo ti a pese lori awọn iru ẹrọ Unix.
    Bytes(&'a [u8]),
    /// Wide awọn gbolohun ọrọ ojo melo lati Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Awọn adanu Lossy yipada si `Cow<str>` kan, yoo pin ti `Bytes` ko ba wulo UTF-8 tabi ti `BytesOrWideString` jẹ `Wide`.
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Pese a `Path` oniduro ti `BytesOrWideString`.
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}