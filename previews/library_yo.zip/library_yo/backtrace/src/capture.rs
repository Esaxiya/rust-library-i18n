use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Aṣoju ti ohun-ini ati ipadasẹhin ti ara ẹni.
///
/// Eto yii le ṣee lo lati mu ẹhin sẹhin ni ọpọlọpọ awọn aaye ninu eto kan ati lẹhinna lo lati ṣayẹwo ohun ti ẹhin wa ni akoko yẹn.
///
///
/// `Backtrace` ṣe atilẹyin titẹ-lẹwa ti awọn ẹhin sẹhin nipasẹ imuse `Debug` rẹ.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Awọn fireemu nibi ti wa ni atokọ lati oke-si-isalẹ ti akopọ naa
    frames: Vec<BacktraceFrame>,
    // Awọn Ìwé a gbagbo ni gangan ibere ti awọn backtrace, omitting awọn fireemu bi `Backtrace::new` ati `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Ya ẹya ti fireemu kan ni ẹhin ẹhin.
///
/// Iru yii ni a pada pada bi atokọ kan lati `Backtrace::frames` ati pe o ṣe afihan fireemu akopọ kan ni ẹhin ẹhin ti o gba.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Sile version of a aami ni a backtrace.
///
/// Iru yii ni a pada bi atokọ lati `BacktraceFrame::symbols` ati ṣe aṣoju metadata fun aami kan ninu ẹhin ẹhin.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Gba ẹhin sẹhin ni ibi ipe ti iṣẹ yii, dapada aṣoju ti ohun-ini kan.
    ///
    /// Iṣẹ yii wulo fun aṣoju aṣoju ẹhin bi nkan ni Rust.Iye ti o pada yii ni a le firanṣẹ kọja awọn okun ati tẹjade ni ibomiiran, ati idi ti iye yii ni lati wa ni ara ẹni patapata.
    ///
    /// Akiyesi pe lori diẹ ninu awọn iru ẹrọ gbigba ipadasẹhin ni kikun ati ipinnu o le jẹ gbowolori pupọ julọ.
    /// Ti iye owo ba pọ ju fun ohun elo rẹ o ni iṣeduro lati dipo lilo `Backtrace::new_unresolved()` eyiti o yago fun igbesẹ ipinnu aami (eyiti o gba igbagbogbo julọ) ati gbigba gbigba firanṣẹ si ọjọ ti o tẹle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // fẹ lati rii daju pe fireemu kan wa nibi lati yọkuro
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Iru si `new` ayafi pe eyi ko yanju eyikeyi awọn aami, eyi nirọrun gba ẹhin sẹhin bi atokọ awọn adirẹsi.
    ///
    /// Ni akoko nigbamii a le pe iṣẹ `resolve` lati yanju awọn ami ẹhin ẹhin yii sinu awọn orukọ ti o ṣee ka.
    /// Iṣẹ yii wa nitori ilana ipinnu le ma gba iye akoko pataki lakoko ti eyikeyi ẹhin le nikan ni titẹ sita.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ko si awọn orukọ aami
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // awọn orukọ aami bayi wa
    /// ```
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    ///
    #[inline(never)] // fẹ lati rii daju pe fireemu kan wa nibi lati yọkuro
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Pada awọn fireemu pada lati igba ti o ti gba ẹhin ẹhin yii.
    ///
    /// Ni igba akọkọ ti titẹsi ti yi bibẹ jẹ seese awọn iṣẹ `Backtrace::new`, ati awọn ti o kẹhin fireemu jẹ seese nkankan nipa bi yi o tẹle tabi awọn ifilelẹ ti awọn iṣẹ bere.
    ///
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Ti a ba ṣẹda ẹhin yii lati `new_unresolved` lẹhinna iṣẹ yii yoo yanju gbogbo awọn adirẹsi ni ẹhin si awọn orukọ aami wọn.
    ///
    ///
    /// Ti ẹhin yii ba ti ni iṣaaju tabi ti ṣẹda nipasẹ `new`, iṣẹ yii ko ṣe nkankan.
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Kanna bi `Frame::ip`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Kanna bi `Frame::symbol_address`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Kanna bi `Frame::module_base_address`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Pada atokọ awọn aami ti fireemu yii baamu.
    ///
    /// Ni deede aami kan wa fun fireemu, ṣugbọn nigbamiran ti nọmba awọn iṣẹ ba wa ni atokọ sinu fireemu kan lẹhinna awọn aami pupọ yoo pada.
    /// Aami akọkọ ti a ṣe akojọ ni "innermost function", lakoko ti aami ti o kẹhin jẹ ita ti ita (olupe to kẹhin).
    ///
    /// Akiyesi pe ti o ba ti yi fireemu wá lati ẹya unresolved backtrace ki o si yi yoo pada ohun ṣofo akojọ.
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Kanna bi `Symbol::name`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Kanna bi `Symbol::addr`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Kanna bi `Symbol::filename`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Kanna bi `Symbol::lineno`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Kanna bi `Symbol::colno`
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Nigbati awọn ọna titẹ sita a gbiyanju lati yọ cwd kuro ti o ba wa, bibẹkọ ti a kan tẹ ọna naa bi-jẹ.
        // Akiyesi pe a tun ṣe eyi nikan fun ọna kika kukuru, nitori ti o ba ti kun o aigbekele a fẹ lati tẹ ohun gbogbo.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}