//! Igbimọ aami apẹrẹ nipa lilo `dbghelp.dll` lori Windows, lo nikan fun MSVC
//!
//! Igbimọ aami apẹẹrẹ, bii pẹlu awọn ẹhin ẹhin, nlo alaye ti kojọpọ ni agbara lati `dbghelp.dll`.
//! (wo `src/dbghelp.rs` fun alaye nipa idi ti o fi kojọpọ ni agbara).
//!
//! API yii yan igbimọ ipinnu ipinnu rẹ da lori fireemu ti a pese tabi alaye ti a ni ni ọwọ.
//! Ti a ba fun fireemu kan lati `StackWalkEx` lẹhinna a lo awọn API iru lati ṣe agbekalẹ alaye to pe nipa awọn iṣẹ ti a ṣe alaye.
//! Bibẹẹkọ ti gbogbo ohun ti a ni ba jẹ adirẹsi tabi fireemu akopọ agbalagba lati `StackWalk64` a lo awọn API agbalagba fun aami.
//!
//! Atilẹyin ti o dara wa ninu module yii, ṣugbọn ipin to dara julọ ninu rẹ n yi pada sẹhin ati siwaju laarin awọn oriṣi Windows ati awọn iru Rust.
//!
//! Fun apẹẹrẹ awọn ami wa si wa bi awọn okun gbooro eyiti a lẹhinna yipada si awọn okun utf-8 ti a ba le ṣe.
//!
//!
//!
//!

#![allow(bad_style)]

use super::super::{backtrace::StackFrame, dbghelp, windows::*};
use super::{BytesOrWideString, ResolveWhat, SymbolName};
use core::char;
use core::ffi::c_void;
use core::marker;
use core::mem;
use core::slice;

// Fi OsString pamọ sori std ki a le pese orukọ aami ati orukọ faili.
pub struct Symbol<'a> {
    name: *const [u8],
    addr: *mut c_void,
    line: Option<u32>,
    filename: Option<*const [u16]>,
    #[cfg(feature = "std")]
    _filename_cache: Option<::std::ffi::OsString>,
    #[cfg(not(feature = "std"))]
    _filename_cache: (),
    _marker: marker::PhantomData<&'a i32>,
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        Some(SymbolName::new(unsafe { &*self.name }))
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        Some(self.addr as *mut _)
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename
            .map(|slice| unsafe { BytesOrWideString::Wide(&*slice) })
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }

    pub fn lineno(&self) -> Option<u32> {
        self.line
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        self._filename_cache.as_ref().map(Path::new)
    }
}

#[repr(C, align(8))]
struct Aligned8<T>(T);

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    // Rii daju pe awọn aami ilana yii jẹ ipilẹṣẹ
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // o dara...
    };

    match what {
        ResolveWhat::Address(_) => resolve_without_inline(&dbghelp, what.address_or_ip(), cb),
        ResolveWhat::Frame(frame) => match &frame.inner.stack_frame {
            StackFrame::New(frame) => resolve_with_inline(&dbghelp, frame, cb),
            StackFrame::Old(_) => resolve_without_inline(&dbghelp, frame.ip(), cb),
        },
    }
}

unsafe fn resolve_with_inline(
    dbghelp: &dbghelp::Init,
    frame: &STACKFRAME_EX,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| {
            dbghelp.SymFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                &mut 0,
                info,
            )
        },
        |line| {
            dbghelp.SymGetLineFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                0,
                &mut 0,
                line,
            )
        },
        cb,
    )
}

unsafe fn resolve_without_inline(
    dbghelp: &dbghelp::Init,
    addr: *mut c_void,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| dbghelp.SymFromAddrW()(GetCurrentProcess(), addr as DWORD64, &mut 0, info),
        |line| dbghelp.SymGetLineFromAddrW64()(GetCurrentProcess(), addr as DWORD64, &mut 0, line),
        cb,
    )
}

unsafe fn do_resolve(
    sym_from_addr: impl FnOnce(*mut SYMBOL_INFOW) -> BOOL,
    get_line_from_addr: impl FnOnce(&mut IMAGEHLP_LINEW64) -> BOOL,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    const SIZE: usize = 2 * MAX_SYM_NAME + mem::size_of::<SYMBOL_INFOW>();
    let mut data = Aligned8([0u8; SIZE]);
    let data = &mut data.0;
    let info = &mut *(data.as_mut_ptr() as *mut SYMBOL_INFOW);
    info.MaxNameLen = MAX_SYM_NAME as ULONG;
    // awọn struct iwọn ni C.
    // iye naa yatọ si `size_of::<SYMBOL_INFOW>() - MAX_SYM_NAME + 1` (==81) nitori tito eto.
    //
    info.SizeOfStruct = 88;

    if sym_from_addr(info) != TRUE {
        return;
    }

    // Ti orukọ aami ba tobi ju MaxNameLen lọ, SymFromAddrW yoo fun ifipamọ awọn ohun kikọ (MaxNameLen, 1) ki o ṣeto NameLen si iye gidi.
    //
    //
    let name_len = ::core::cmp::min(info.NameLen as usize, info.MaxNameLen as usize - 1);
    let name_ptr = info.Name.as_ptr() as *const u16;
    let name = slice::from_raw_parts(name_ptr, name_len);

    // Reencode aami utf-16 si utf-8 nitorinaa a le lo `SymbolName::new` bii gbogbo awọn iru ẹrọ miiran
    //
    let mut name_len = 0;
    let mut name_buffer = [0; 256];
    {
        let mut remaining = &mut name_buffer[..];
        for c in char::decode_utf16(name.iter().cloned()) {
            let c = c.unwrap_or(char::REPLACEMENT_CHARACTER);
            let len = c.len_utf8();
            if len < remaining.len() {
                c.encode_utf8(remaining);
                let tmp = remaining;
                remaining = &mut tmp[len..];
                name_len += len;
            } else {
                break;
            }
        }
    }
    let name = &name_buffer[..name_len] as *const [u8];

    let mut line = mem::zeroed::<IMAGEHLP_LINEW64>();
    line.SizeOfStruct = mem::size_of::<IMAGEHLP_LINEW64>() as DWORD;

    let mut filename = None;
    let mut lineno = None;
    if get_line_from_addr(&mut line) == TRUE {
        lineno = Some(line.LineNumber as u32);

        let base = line.FileName;
        let mut len = 0;
        while *base.offset(len) != 0 {
            len += 1;
        }

        let len = len as usize;

        filename = Some(slice::from_raw_parts(base, len) as *const [u16]);
    }

    cb(&super::Symbol {
        inner: Symbol {
            name,
            addr: info.Address as *mut _,
            line: lineno,
            filename,
            _filename_cache: cache(filename),
            _marker: marker::PhantomData,
        },
    })
}

#[cfg(feature = "std")]
unsafe fn cache(filename: Option<*const [u16]>) -> Option<::std::ffi::OsString> {
    use std::os::windows::ffi::OsStringExt;
    filename.map(|f| ::std::ffi::OsString::from_wide(&*f))
}

#[cfg(not(feature = "std"))]
unsafe fn cache(_filename: Option<*const [u16]>) {}

pub unsafe fn clear_symbol_cache() {}