// nikan lo lori Linux ni bayi, nitorinaa gba koodu oku ni ibomiiran
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// A o rọrun arena allocator fun baiti buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Pin awọn saarin ti iwọn pàtó kan ati ki o pada tọka iyipada si rẹ.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // Aabo: Eyi ni iṣẹ kan nikan ti o kọ iyipada kan
        // tọka si `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // Aabo: a ko yọ awọn eroja kuro lati `self.buffers`, nitorinaa itọkasi kan
        // si data inu eyikeyi ifipamọ yoo gbe niwọn igba ti `self` ṣe.
        &mut buffers[i]
    }
}