//! Support fun symbolication lilo awọn `gimli` crate on crates.io
//!
//! Eyi ni imuse aami aiyipada fun Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Igbesi aye aimi jẹ irọ lati gige ni ayika aini atilẹyin fun awọn agbara ifọkasi ara ẹni.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Yi pada si 'awọn igbesi aye aimi nitori awọn aami yẹ ki o ya `map` ati `stash` nikan ati pe a n tọju wọn ni isalẹ.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Fun ikojọpọ awọn ile-ikawe abinibi lori Windows, wo diẹ ninu ijiroro lori rust-lang/rust#71060 fun ọpọlọpọ awọn imọran nibi.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Awọn ikawe MinGW lọwọlọwọ ko ṣe atilẹyin ASLR (rust-lang/rust#16514), ṣugbọn awọn DLL tun le gbe ni ayika ni aaye adirẹsi.
            // O han wipe adirẹsi ni yokokoro info wa ni gbogbo bi-o ba ti yi ìkàwé ti a ti kojọpọ ni awọn oniwe-"image base", ti o jẹ oko ninu awọn oniwe-COFF faili afori.
            // Niwọn bi eyi ti jẹ pe debuginfo ṣe atokọ a ṣe itupalẹ tabili aami ati awọn adirẹsi itaja bi ẹni pe a kojọpọ ikawe ni "image base" naa.
            //
            // Ile-ikawe ko le gbe ni "image base", sibẹsibẹ.
            // (Aigbekele nkankan miran le wa ni rù nibẹ?) Eleyi jẹ ibi ti awọn `bias` oko wa sinu play, ati awọn ti a nilo lati ro ero jade ni iye ti `bias` nibi.Laanu botilẹjẹpe ko ṣalaye bi o ṣe le gba eyi lati modulu ti kojọpọ.
            // Ohun ti a ni, sibẹsibẹ, ni adirẹsi fifuye gangan (`modBaseAddr`).
            //
            // Bi diẹ ti ẹda-jade fun bayi a ṣe didara faili naa, ka alaye akọle faili, lẹhinna ju silẹ mmap naa.Eyi jẹ egbin nitori a le tun ṣii mmap nigbamii, ṣugbọn eyi yẹ ki o ṣiṣẹ daradara to fun bayi.
            //
            // Ni kete ti a ba ni `image_base` (ipo fifuye ti o fẹ) ati `base_addr` (ipo fifuye gangan) a le fọwọsi `bias` (iyatọ laarin gangan ati ohun ti o fẹ) ati lẹhinna adirẹsi ti a sọ ti apakan kọọkan ni `image_base` nitori iyẹn ni faili naa sọ.
            //
            //
            // Fun bayi o han pe laisi ELF/MachO a le ṣe pẹlu apakan kan fun ile-ikawe, ni lilo `modBaseSize` bi iwọn gbogbo.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS lo ọna kika faili Mach-O ati lo awọn API pato-DYLD lati ṣajọ atokọ ti awọn ile-ikawe abinibi ti o jẹ apakan ohun elo naa.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Gba orukọ ile-ikawe yii eyiti o baamu si ọna ibiti o ti le gbe ẹrù pẹlu.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Fifuye akọsori aworan ti ile-ikawe yii ki o fi aṣoju ranṣẹ si `object` lati ṣe atunyẹwo gbogbo awọn aṣẹ fifuye ki a le mọ gbogbo awọn abala ti o kan nibi.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ṣe imukuro lori awọn apa ati forukọsilẹ awọn agbegbe ti a mọ fun awọn apa ti a rii.
            // Afikun ohun ti o gba alaye ija ọrọ àáyá fun processing nigbamii, wo comments ni isalẹ.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Pinnu "slide" fun ile-ikawe yii eyiti o pari ni aiṣododo ti a lo lati mọ ibiti a gbe awọn ohun iranti si.
            // Eyi jẹ diẹ ninu iṣiroye ajeji ṣugbọn o jẹ abajade ti igbiyanju awọn nkan diẹ ninu egan ati rii ohun ti o duro.
            //
            // Ero gbogbogbo ni pe `bias` pẹlu apakan `stated_virtual_memory_address` apakan kan yoo wa nibiti o wa ni aaye adirẹsi gangan ti apakan naa wa.
            // Awọn miiran ohun ti a gbekele lori o tilẹ jẹ pe a gidi adirẹsi iyokuro awọn `bias` ni awọn Ìwé lati wo soke ni awọn aami tabili ati debuginfo.
            //
            // O wa ni jade, botilẹjẹpe, pe fun awọn ile-ikawe ti kojọpọ eto awọn iṣiro wọnyi ko tọ.Fun awọn alaṣẹ abinibi, sibẹsibẹ, o han pe o tọ.
            // Gbígbé ọgbọn kan lati orisun LLDB o ni casing pataki fun apakan `__TEXT` akọkọ ti o kojọpọ lati aiṣedeede faili 0 pẹlu iwọn nonzero.
            // Fun idi eyikeyi ti eyi ba wa bayi o han lati tumọ si pe tabili aami jẹ ibatan si o kan ifaworanhan vmaddr fun ile-ikawe naa.
            // Ti o ba jẹ *kii ṣe* bayi lẹhinna tabili aami jẹ ibatan si ifaworanhan vmaddr pẹlu adirẹsi ti a sọ ipin naa.
            //
            // Lati mu ipo yii ba ti a ko *rii* apakan ọrọ kan ni odo aiṣedeede faili lẹhinna a mu ikorira pọ si nipasẹ adirẹsi awọn apakan apakan akọkọ ati dinku gbogbo awọn adirẹsi ti o sọ pẹlu iye yẹn naa.
            //
            // Iyẹn ọna tabili aami jẹ nigbagbogbo han ibatan si iye aibikita ile-ikawe.
            // Eleyi han lati ni eto esi fun ntoka nipasẹ awọn aami tabili.
            //
            // Ni otitọ Emi ko rii daju patapata boya eyi jẹ ẹtọ tabi ti nkan miiran ba wa ti o yẹ ki o tọka bi o ṣe le ṣe eyi.
            // Fun bayi tilẹ yi dabi lati ṣiṣẹ daradara to (?) ati awọn ti a gbodo ma ni anfani lati tweak yi lori akoko ti o ba wulo.
            //
            // Fun alaye diẹ sii wo #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Miiran Unix (fun apẹẹrẹ
        // Linux) awọn iru ẹrọ lo ELF bi ọna kika faili ohun ati ni igbagbogbo ṣe API ti a pe ni `dl_iterate_phdr` lati gbe awọn ikawe abinibi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` yẹ ki o jẹ awọn itọka to wulo.
        // `vec` yẹ ki o jẹ itọka to wulo si `std::Vec` kan.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ko ni natively ni atilẹyin yokokoro info, ṣugbọn awọn Kọ eto yoo gbe yokokoro info ni ona `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Ohun gbogbo miiran yẹ ki o lo ELF, ṣugbọn ko mọ bi o ṣe le ṣajọ awọn ile-ikawe abinibi.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Gbogbo awọn ile ikawe ti a mọ ti a ti kojọpọ.
    libraries: Vec<Library>,

    /// Mappings kaṣe ibi ti a ti ojuṣe parsed arara alaye.
    ///
    /// Atokọ yii ni agbara ti o wa titi fun gbogbo igbesoke rẹ eyiti ko pọ si.
    /// Ẹya `usize` ti bata kọọkan jẹ itọka si `libraries` loke nibiti `usize::max_value()` ṣe aṣoju ipaniyan lọwọlọwọ.
    ///
    /// `Mapping` jẹ ibamu alaye dwarf ti o ni ibamu.
    ///
    /// Akiyesi pe eyi jẹ ipilẹ kaṣe LRU ati pe a yoo yi awọn nkan pada ni ayika bi a ṣe ṣe apẹẹrẹ awọn adirẹsi.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Awọn ipin ti ile-ikawe yii ti kojọpọ sinu iranti, ati ibiti wọn ti kojọpọ.
    segments: Vec<LibrarySegment>,
    /// "bias" ti ile-ikawe yii, ni igbagbogbo ibiti o ti kojọpọ sinu iranti.
    /// Yi ti wa ni afikun si kọọkan apa ká so adirẹsi lati gba awọn gangan foju iranti adirẹsi ti awọn apa wa ni ti kojọpọ sinu.
    /// Ni afikun iyọkuro yii ti yọ kuro lati awọn adirẹsi iranti foju gidi si itọka si debuginfo ati tabili aami.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Adirẹsi ti a sọ ti apakan yii ninu faili ohunkan.
    /// Eyi kii ṣe ibi ti apakan ti kojọpọ, ṣugbọn kuku adirẹsi yii pẹlu ile-ikawe ti o ni `bias` ni ibiti o wa.
    ///
    stated_virtual_memory_address: usize,
    /// Iwọn ti apakan ths ni iranti.
    len: usize,
}

// ailewu nitori eyi nilo lati muuṣiṣẹpọ ni ita
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ailewu nitori eyi nilo lati muuṣiṣẹpọ ni ita
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // A gan kekere, irorun LRU kaṣe fun yokokoro info mappings.
        //
        // Oṣuwọn to buruju yẹ ki o ga gidigidi, nitori akopọ aṣoju ko kọja laarin ọpọlọpọ awọn ile ikawe ti a pin.
        //
        // Awọn ẹya `addr2line::Context` jẹ gbowolori pupọ lati ṣẹda.
        // Iye owo rẹ nireti lati ni amọti nipasẹ awọn ibeere `locate` atẹle, eyiti o mu ki awọn ẹya ti a kọ nigba kikọ `addr2line: : Context`s lati gba awọn iyara iyara.
        //
        // Ti a ko ba ni kaṣe yii, amortization yẹn kii yoo ṣẹlẹ, ati pe awọn ami atẹhin aami yoo jẹ ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Ni akọkọ, ṣe idanwo ti `lib` yii ni eyikeyi apakan ti o ni `addr` (mimu gbigbe sipo).Ti ayẹwo yii ba kọja lẹhinna a le tẹsiwaju ni isalẹ ki o tumọ itumọ adirẹsi gangan.
                //
                // Akiyesi pe a nlo `wrapping_add` nibi lati yago fun awọn iṣayẹwo ṣiṣan.O ti rii ninu egan pe iṣiro irẹjẹ SVMA + ṣaju.
                // O dabi ẹni pe o jẹ ohun ajeji ti yoo ṣẹlẹ ṣugbọn ko si iye nla ti a le ṣe nipa rẹ miiran ju boya o kan foju awọn apa wọnyẹn nitori wọn le tọka si aaye.
                //
                // Eyi ni akọkọ wa ni rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Bayi wipe a ti mo `lib` ni `addr`, a le aiṣedeede pẹlu awọn irẹjẹ lati wa awọn so virutal iranti adirẹsi.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: lẹhin ti ipo ti ipo yii pari laisi ipadabọ ni kutukutu
        // lati aṣiṣe kan, titẹsi kaṣe fun ọna yii wa ni itọka 0.

        if let Some(idx) = idx {
            // Nigbati aworan agbaye ba wa ni kaṣe tẹlẹ, gbe e si iwaju.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Nigbati awọn aworan ti wa ni ko si ni awọn kaṣe, ṣẹda titun kan aworan agbaye, fi o sinu awọn iwaju ti awọn kaṣe, ki o si evict awọn Atijọ kaṣe titẹsi o ba wulo.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // maṣe jo igbesi aye `'static`, rii daju pe o ti di si ara wa nikan
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Fa awọn s'aiye ti `sym` to `'static` niwon a ti wa ni laanu a beere lati nibi, sugbon o ti n ony lailai lọ jade bi a itọkasi ki ko tọka si o yẹ ki o wa taku kọja yi fireemu lonakona.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Lakotan, gba aworan agbaye ti a fi pamọ tabi ṣẹda aworan agbaye tuntun fun faili yii, ki o ṣe ayẹwo alaye DWARF lati wa file/line/name fun adirẹsi yii.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// A ni anfani lati wa alaye fireemu fun aami yi, ati pe fireemu `addr2line` ni inu ni gbogbo alaye nitty gritty.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ko le wa alaye n ṣatunṣe aṣiṣe, ṣugbọn a rii ni tabili aami ti elf ti a le mu ṣiṣẹ.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}