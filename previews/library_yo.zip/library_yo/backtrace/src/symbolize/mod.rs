use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Yanjú ohun adirẹsi si aami kan, ran awọn aami si awọn pàtó bíbo.
///
/// Iṣẹ yii yoo wa adirẹsi ti a fun ni awọn agbegbe bii tabili aami agbegbe, tabili aami aami agbara, tabi alaye yokokoro DWARF (da lori imuse ti a muu ṣiṣẹ) lati wa awọn aami lati fun.
///
///
/// A le ma pe ifipamọ ti o ko ba le ṣe ipinnu, ati pe tun le pe ni diẹ ju ẹẹkan lọ ninu ọran ti awọn iṣẹ ti a ṣe ilana.
///
/// Aami yielded soju fun awọn ipaniyan ni pàtó kan `addr`, pada file/line orisii fun awọn ti o adirẹsi (ti o ba wa).
///
/// Akọsilẹ ti o ba ti o ba ni a `Frame` ki o si ti o ti n niyanju lati lo `resolve_frame` iṣẹ dipo ti yi ọkan.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
/// # Panics
///
/// Iṣẹ yii gbìyànjú lati ma ṣe panic rara, ṣugbọn ti `cb` ba pese panics lẹhinna diẹ ninu awọn iru ẹrọ yoo fi agbara mu panic ilọpo meji lati pa ilana naa.
/// Diẹ ninu awọn iru ẹrọ lo ile-ikawe C eyiti o lo awọn ifaseyin ipe inu eyiti ko le ṣalaye nipasẹ, nitorinaa ijaya lati `cb` le ṣe ifilọlẹ ilana ilana.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // nikan wo fireemu oke
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Yanju fireemu imudani tẹlẹ si aami kan, gbigbe aami si pipade ti a sọ tẹlẹ.
///
/// Functin yii n ṣe iṣẹ kanna bi `resolve` ayafi pe o gba `Frame` bi ariyanjiyan dipo adirẹsi.
/// Eyi le gba diẹ ninu awọn imuṣẹ pẹpẹ ti sẹhin lati pese alaye aami to peye tabi alaye nipa awọn fireemu inline fun apẹẹrẹ.
///
/// O ni iṣeduro lati lo eyi ti o ba le.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
/// # Panics
///
/// Iṣẹ yii gbìyànjú lati ma ṣe panic rara, ṣugbọn ti `cb` ba pese panics lẹhinna diẹ ninu awọn iru ẹrọ yoo fi agbara mu panic ilọpo meji lati pa ilana naa.
/// Diẹ ninu awọn iru ẹrọ lo ile-ikawe C eyiti o lo awọn ifaseyin ipe inu eyiti ko le ṣalaye nipasẹ, nitorinaa ijaya lati `cb` le ṣe ifilọlẹ ilana ilana.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // nikan wo fireemu oke
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Awọn iye IP lati awọn fireemu akopọ jẹ deede (always?) itọnisọna *lẹhin* ipe ti o wa kakiri akopọ gangan.
// Ti ṣe apejuwe eyi lori fa nọmba filename/line lati jẹ ọkan niwaju ati boya sinu ofo ti o ba sunmọ opin iṣẹ naa.
//
// Eyi han si ipilẹ nigbagbogbo jẹ ọran lori gbogbo awọn iru ẹrọ, nitorinaa a yọ ọkan kuro lati ip ti o yanju lati yanju rẹ si itọnisọna ipe ti tẹlẹ dipo itọnisọna ti o pada si.
//
//
// Apere a ko ni ṣe eyi.
// Bi o ṣe yẹ a yoo nilo awọn olupe ti awọn `resolve` API ni ibi lati ṣe pẹlu ọwọ -1 ati akọọlẹ pe wọn fẹ alaye ipo fun itọnisọna *iṣaaju*, kii ṣe lọwọlọwọ.
// Ni idaniloju a yoo tun ṣafihan lori `Frame` ti a ba jẹ gaan adirẹsi ti ẹkọ atẹle tabi lọwọlọwọ.
//
// Fun bayi botilẹjẹpe eyi jẹ aibikita onakan lẹwa nitorina a kan yọkuro inu ọkan nigbagbogbo.
// Awọn alabara yẹ ki o tẹsiwaju ṣiṣẹ ati gbigba awọn esi to dara julọ, nitorinaa o yẹ ki a dara to.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Kanna bi `resolve`, ailewu nikan bi ko ṣe amuṣiṣẹpọ.
///
/// Iṣẹ yii ko ni awọn onigbọwọ amuṣiṣẹpọ ṣugbọn o wa nigbati ẹya `std` ti crate yii ko kojọ.
/// Wo iṣẹ `resolve` fun iwe ati awọn apẹẹrẹ diẹ sii.
///
/// # Panics
///
/// Wo alaye lori `resolve` fun awọn ikoko lori ẹru `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Kanna bi `resolve_frame`, ailewu nikan bi ko ṣe amuṣiṣẹpọ.
///
/// Iṣẹ yii ko ni awọn onigbọwọ amuṣiṣẹpọ ṣugbọn o wa nigbati ẹya `std` ti crate yii ko kojọ.
/// Wo iṣẹ `resolve_frame` fun iwe ati awọn apẹẹrẹ diẹ sii.
///
/// # Panics
///
/// Wo alaye lori `resolve_frame` fun awọn ikoko lori ẹru `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait kan ti o nsoju ipinnu aami kan ninu faili kan.
///
/// Eleyi trait ti wa ni yielded bi a trait ohun si bíbo fi fun awọn `backtrace::resolve` iṣẹ, ati awọn ti o ti wa ni fere sowo bi o ti ká aimọ ti imuse jẹ sile o.
///
///
/// A aami le fun contextual alaye nipa iṣẹ kan, fun apẹẹrẹ awọn orukọ, filename, laini nọmba, kongẹ adirẹsi, bbl
/// Kii ṣe gbogbo alaye nigbagbogbo wa ni aami kan, sibẹsibẹ, nitorinaa gbogbo awọn ọna pada `Option` kan pada.
///
///
pub struct Symbol {
    // TODO: o nilo lati wa ni titẹ s`aiye yii nikẹhin si `Symbol`,
    // ṣugbọn iyẹn jẹ ayipada fifọ lọwọlọwọ.
    // Fun bayi eyi jẹ ailewu nitori pe `Symbol` nikan ni a fi jade nigbagbogbo nipasẹ itọkasi ati pe ko le jẹ cloned.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Pada orukọ iṣẹ yii.
    ///
    /// A le lo ilana ti o pada lati beere ọpọlọpọ awọn ohun-ini nipa orukọ aami:
    ///
    ///
    /// * Imuṣẹ `Display` yoo tẹ aami ti o ti parẹ jade.
    /// * Awọn aise `str` iye ti awọn aami le wa ni wọle (ti o ba ká wulo utf-8).
    /// * Awọn baiti aise fun orukọ aami le wọle si.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Pada adirẹsi ibẹrẹ ti iṣẹ yii.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Pada orukọ aise aise rẹ gẹgẹ bi ege kan.
    /// Eyi jẹ iwulo akọkọ fun awọn agbegbe `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Pada nọmba ọwọn fun ibiti aami yii n ṣiṣẹ lọwọlọwọ.
    ///
    /// Gimli nikan ni o pese iye kan lọwọlọwọ ati paapaa lẹhinna ti `filename` ba pada `Some`, ati nitorinaa lẹhinna jẹ koko-ọrọ si awọn ikilọ iru.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Pada nọmba laini fun ibiti aami yii n ṣiṣẹ lọwọlọwọ.
    ///
    /// Iye ipadabọ yii jẹ deede `Some` ti `filename` ba pada `Some`, ati nitorinaa o jẹ koko-ọrọ si awọn ikilọ ti o jọra.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Pada orukọ faili si ibi ti a ti ṣalaye iṣẹ yii.
    ///
    /// Eyi wa lọwọlọwọ nikan nigbati lilo libbacktrace tabi gimli (fun apẹẹrẹ
    /// unix awọn iru ẹrọ miiran) ati nigbati a alakomeji ti wa ni compiled pẹlu debuginfo.
    /// Ti bẹẹkọ ti awọn ipo wọnyi ba pade lẹhinna eyi yoo ṣeese pada `None`.
    ///
    /// # Awọn ẹya ti a beere
    ///
    /// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Boya aami C + ti o ni itupalẹ, ti itupalẹ aami mangled bi Rust kuna.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Rii daju lati tọju iwọn-odo yii, ki ẹya `cpp_demangle` ko ni idiyele nigbati o ba ni alaabo.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Apo-iwe ti o wa ni ayika orukọ aami lati pese awọn iraye si ergonomic si orukọ iparun, awọn baiti aise, okun aise, ati bẹbẹ lọ.
///
// Gba koodu oku fun nigbati ẹya `cpp_demangle` ko ṣiṣẹ.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Ṣẹda titun kan aami orukọ lati aise amuye baiti.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Pada orukọ aami (mangled) aise bi `str` ti aami naa ba wulo utf-8.
    ///
    /// Lo imuse `Display` ti o ba fẹ ẹya apanirun.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Pada orukọ aise aami bi atokọ ti awọn baiti
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Eyi le tẹjade ti aami apanirun ko ba wulo ni otitọ, nitorinaa mu aṣiṣe nibi ni oore ọfẹ nipa kii ṣe ikede rẹ ni ita.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Igbiyanju lati tun gba ibi ipamọ iranti ti o lo lati ṣe afihan awọn adirẹsi.
///
/// Yi ọna ti yoo gbiyanju lati tu eyikeyi agbaye data ẹya ti o ti bibẹkọ ti a ti kashi agbaye tabi ni awọn o tẹle eyi ti ojo melo soju parsed arara alaye tabi iru.
///
///
/// # Caveats
///
/// Lakoko ti iṣẹ yii wa nigbagbogbo kii ṣe ohunkohun ni otitọ lori awọn imuṣẹ lọpọlọpọ.
/// Awọn ile ikawe bii dbghelp tabi libbacktrace ko pese awọn ohun elo lati ṣe ipinlẹ ipin ati ṣakoso iranti ti a pin.
/// Fun bayi ẹya `gimli-symbolize` ti crate yii jẹ ẹya nikan nibiti iṣẹ yii ni ipa kankan.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}