//! Symbolication nwon.Mirza lilo awọn arara-Ìbòmọlẹ koodu ni libbacktrace.
//!
//! Ikawe ikawe libbacktrace C, eyiti a pin kakiri pẹlu gcc, ṣe atilẹyin kii ṣe ipilẹṣẹ ẹhin nikan (eyiti a ko lo gangan) ṣugbọn tun ṣe afihan ẹhin ati mimu alaye yokokoro arara nipa awọn nkan bii awọn fireemu ti a ṣe ilana ati kini.
//!
//!
//! Eyi jẹ idiju idiwọn nitori ọpọlọpọ ọpọlọpọ awọn ifiyesi nibi, ṣugbọn imọran ipilẹ ni:
//!
//! * Ni akọkọ a pe `backtrace_syminfo`.Eyi n gba alaye aami lati ori tabili aami agbara ti a ba le.
//! * Nigbamii ti a pe `backtrace_pcinfo`.Eyi yoo ṣe itupalẹ awọn tabili debuginfo ti wọn ba wa ati gba wa laaye lati gba alaye pada nipa awọn fireemu inline, awọn orukọ faili, awọn nọmba laini, ati bẹbẹ lọ.
//!
//! Ẹtan pupọ lo wa nipa gbigba awọn tabili dwarf sinu libbacktrace, ṣugbọn ni ireti pe kii ṣe opin agbaye ati pe o ṣalaye to nigba kika ni isalẹ.
//!
//! Eyi ni imọran aami aiyipada fun ti kii ṣe MSVC ati awọn iru ẹrọ ti kii ṣe OSX.Ni libstd tilẹ yi ni aiyipada nwon.Mirza fun OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Ti o ba ṣee ṣe fẹ orukọ `function` eyiti o wa lati debuginfo ati pe o le jẹ deede deede fun awọn fireemu laini fun apẹẹrẹ.
                // Ti iyẹn ko ba wa botilẹjẹpe o pada sẹhin si orukọ tabili aami ti a sọ ni `symname`.
                //
                // Akiyesi pe nigbakan `function` le ni itara diẹ ti o pe deede, fun apẹẹrẹ ni atokọ bi `try<i32,closure>` kii ṣe ti `std::panicking::try::do_call`.
                //
                // O ti n ko gan ko idi, ṣugbọn ìwò awọn `function` orukọ dabi diẹ deede.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ṣe ohunkohun fun bayi
}

/// Tẹ ti awọn `data` ijuboluwole koja sinu `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ni kete ti a pe ipe ipe yii lati `backtrace_syminfo` nigbati a ba bẹrẹ ipinnu a lọ siwaju lati pe `backtrace_pcinfo`.
    // Iṣẹ `backtrace_pcinfo` naa yoo kan si alaye n ṣatunṣe aṣiṣe ati igbidanwo tto lati ṣe awọn ohun bii imularada alaye file/line ati awọn fireemu atokọ.
    // Ṣe akiyesi botilẹjẹpe `backtrace_pcinfo` le kuna tabi ko ṣe pupọ ti ko ba si alaye yokokoro, nitorinaa ti iyẹn ba ṣẹlẹ a ni idaniloju lati pe ipadabọ pẹlu o kere ju aami kan lati `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Iru ijuboluwole `data` kọja sinu `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace ṣe atilẹyin ṣiṣẹda ipinlẹ kan, ṣugbọn ko ṣe atilẹyin fun iparun ipinlẹ kan.
// Mo tikalararẹ gba eyi lati tumọ si pe ipinlẹ tumọ si lati ṣẹda ati lẹhinna wa laaye lailai.
//
// Emi yoo nifẹ lati forukọsilẹ olutọju at_exit() eyiti o wẹ ipo yii mọ, ṣugbọn libbacktrace ko pese ọna lati ṣe bẹ.
//
// Pẹlu awọn idiwọ wọnyi, iṣẹ yii ni ipin kaṣe iṣiro ti o ni iṣiro ni igba akọkọ ti a beere eyi.
//
// Ranti pe titele gbogbo nkan ṣẹlẹ ni iṣọn (titiipa agbaye kan).
//
// Akiyesi aini iṣiṣẹpọ nibi jẹ nitori ibeere ti `resolve` ti muuṣiṣẹpọ ni ita.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Maṣe lo awọn agbara ailewu ti libbacktrace nitori a n pe ni igbagbogbo ni ọna amuṣiṣẹpọ.
        //
        0,
        error_cb,
        ptr::null_mut(), // ko si afikun data
    );

    return STATE;

    // Akiyesi pe fun libbacktrace lati ṣiṣẹ ni gbogbo o nilo lati wa alaye yokokoro DWARF fun ṣiṣe lọwọlọwọ.Nigbagbogbo o ṣe bẹ nipasẹ nọmba awọn ilana pẹlu, ṣugbọn kii ṣe opin si:
    //
    // * /proc/self/exe lori awọn iru ẹrọ ti o ni atilẹyin
    // * Orukọ faili naa kọja ni kedere nigbati o ba n ṣẹda ipinle
    //
    // Awọn libbacktrace ìkàwé jẹ ńlá kan wad ti C koodu.Eyi tumọ si pe o ti ni awọn ailagbara ailewu iranti, paapaa nigbati o ba n mu debuginfo ti ko dara.
    // Libstd ti lọ sinu ọpọlọpọ awọn itan wọnyi.
    //
    // Ti a ba lo /proc/self/exe lẹhinna a le foju foju wo awọn wọnyi bi a ṣe ro pe libbacktrace jẹ "mostly correct" ati bibẹkọ ti ko ṣe awọn ohun ajeji pẹlu Alaye aṣiṣe aṣiṣe arara "attempted to be correct".
    //
    //
    // Ti a ba kọja ni orukọ faili kan, sibẹsibẹ, lẹhinna o ṣee ṣe lori diẹ ninu awọn iru ẹrọ (bii BSDs) nibiti oṣere irira kan le fa ki a fi faili alainidena si ipo yẹn.
    // Eyi tumọ si pe ti a ba sọ fun libbacktrace nipa orukọ faili kan o le jẹ lilo faili lainidii kan, o ṣee ṣe ki o fa awọn aiṣedede.
    // Ti a ko ba sọ fun libbacktrace ohunkohun botilẹjẹpe kii yoo ṣe ohunkohun lori awọn iru ẹrọ ti ko ṣe atilẹyin awọn ọna bi /proc/self/exe!
    //
    // Fun gbogbo ohun ti a gbiyanju bi o ti ṣee ṣe lati *maṣe* kọja ni orukọ faili kan, ṣugbọn a gbọdọ lori awọn iru ẹrọ ti ko ṣe atilẹyin /proc/self/exe rara.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Akiyesi pe ni pipe a yoo lo `std::env::current_exe`, ṣugbọn a ko le beere `std` nibi.
            //
            // Lo `_NSGetExecutablePath` lati ṣaja ọna ṣiṣe lọwọlọwọ si agbegbe aimi (eyiti eyiti o ba kere pupọ kan fi silẹ).
            //
            //
            // Akiyesi pe a ni igbẹkẹle libbacktrace nibi lati ma ku lori awọn oluṣe ibajẹ, ṣugbọn o daju ṣe ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ni ipo ṣiṣi awọn faili nibiti lẹhin ti o ti ṣii ko le paarẹ.
            // Iyẹn ni gbogbogbo ohun ti a fẹ nihin nitori a fẹ lati rii daju pe oluṣe wa ko ni iyipada kuro labẹ wa lẹhin ti a fi fun si libbacktrace, ni ireti idena agbara lati kọja ni data lainidii sinu libbacktrace (eyiti o le jẹ aṣiṣe).
            //
            //
            // Fun pe a ṣe diẹ ninu ijó nibi lati gbiyanju lati gba iru titiipa kan lori aworan ti ara wa:
            //
            // * Gba mu mu si lọwọlọwọ ilana, fifuye orukọ faili rẹ.
            // * Ṣii faili kan si orukọ faili naa pẹlu awọn asia ti o tọ.
            // * Gbee si awọn ti isiyi ilana ká filename, ṣiṣe awọn daju o ni kanna
            //
            // Ti iyẹn ba kọja gbogbo wa ni imọran ti ṣii faili faili ilana wa nitootọ ati pe a ni idaniloju pe kii yoo yipada.FWIW kan ìdìpọ yi ti ni dakọ lati libstd itan, ki ni yi mi ti o dara ju itumọ ti ohun ti a ti ṣẹlẹ.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Eleyi ngbe ni aimi iranti ki a le pada ..
                static mut BUF: [i8; N] = [0; N];
                // ... eyi si ngbe lori akopọ nitori o jẹ igba diẹ
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // momọ jo `handle` nibi nitori nini ṣiṣi yẹn yẹ ki o tọju titiipa wa lori orukọ faili yii.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // A fẹ lati da nkan ti o pari-nul pada, nitorinaa ti ohun gbogbo ba kun ati pe o dọgba lapapọ gigun lẹhinna ṣe deede iyẹn si ikuna.
                //
                //
                // Bibẹẹkọ nigbati o ba pada ṣaṣeyọri rii daju pe baiti nul wa ninu ege.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // awọn aṣiṣe backtrace ti gba lọwọlọwọ labẹ rogi
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Pe `backtrace_syminfo` API eyiti (lati kika koodu naa) yẹ ki o pe `syminfo_cb` ni ẹẹkan (tabi kuna pẹlu aṣiṣe aigbekele).
    // Lẹhinna a mu diẹ sii laarin `syminfo_cb`.
    //
    // Akiyesi pe a ṣe eyi nitori `syminfo` yoo kan si tabili aami, wiwa awọn orukọ aami paapaa ti ko ba si alaye atunyẹwo ninu alakomeji.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}