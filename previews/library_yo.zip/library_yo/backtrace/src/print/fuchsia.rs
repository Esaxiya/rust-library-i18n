use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr gba ipe ti yoo gba ijuboluwole dl_phdr_info fun gbogbo DSO ti o ti sopọ mọ si ilana naa.
    // dl_iterate_phdr tun ṣe idaniloju pe ọna asopọ ti o ni agbara ti wa ni titiipa lati ibẹrẹ si ipari ti aṣetunṣe.
    // Ti ipe ipadabọ ba pada si iye ti kii-odo, aṣetunṣe ti pari ni kutukutu.
    // 'data' yoo kọja bi ariyanjiyan kẹta si ipe lori ipe kọọkan.
    // 'size' n fun ni iwọn dl_phdr_info naa.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// A nilo lati ṣe itupalẹ ID idanimọ ati diẹ ninu awọn akọsori akọsori eto eyiti o tumọ si pe a nilo nkan diẹ lati inu alaye ELF naa.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Bayi a ni lati tun, bit fun bit, awọn be ti dl_phdr_info iru lo nipa fuchsia ká lọwọlọwọ ìmúdàgba linker.
// Chromium tun ni aala ABI yii bakanna bipadpad.
// Ni iṣẹlẹ a fẹ lati gbe awọn ọran wọnyi lati lo wiwa elf ṣugbọn a nilo lati pese eyi ni SDK ati pe a ko ti ṣe.
//
// Nitorinaa awa (ati awọn) ti di pẹlu nini lilo ọna yii eyiti o ni asopọ pọ pẹlu fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // A ko ni ọna lati mọ ti ṣayẹwo boya e_phoff ati e_phnum wulo.
    // libc yẹ ki o rii daju eyi fun wa sibẹsibẹ nitorinaa o ni aabo lati ṣe ege kan nibi.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr duro fun akọsori eto ELF 64-bit ELI kan ninu igbekalẹ faaji ibi-afẹde.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr duro fun akọle eto ELF to wulo ati awọn akoonu rẹ.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // A ko ni ọna ti ṣayẹwo ti p_addr tabi p_memsz ba wulo.
    // Fucsia's libc ṣe atunyẹwo awọn akọsilẹ ni akọkọ sibẹsibẹ nitorinaa nipa jijẹ nibi awọn akọle wọnyi gbọdọ jẹ deede.
    //
    // AkọsilẹIter ko nilo data ipilẹ lati wulo ṣugbọn o nilo awọn idiwọn lati wulo.
    // A gbekele wipe libc ti ensured pe yi ni irú fun wa nibi.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Iru akọsilẹ fun awọn ID kọ.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr duro ohun ti Elf akọsilẹ akọsori ni endianness ti awọn afojusun.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Akiyesi duro fun akọsilẹ ELF (akọsori + awọn akoonu).
// A fi orukọ naa silẹ bi ege u8 nitori kii ṣe igbagbogbo a fopin si ati pe rust jẹ ki o rọrun to lati ṣayẹwo pe awọn baiti baamu lọnakọna.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// AkọsilẹIter n jẹ ki o ṣe itọju lailewu lori apakan akọsilẹ kan.
// O pari ni kete ti aṣiṣe waye tabi ko si awọn akọsilẹ diẹ sii.
// Ti o ba da lori data ti ko wulo, yoo ṣiṣẹ bi ẹnipe a ko rii awọn akọsilẹ.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // O jẹ aiṣe iyipada iṣẹ ti ijuboluwole ati iwọn ti a fun tọka ibiti o fẹsẹmulẹ ti awọn baiti ti gbogbo wọn le ka.
    // Awọn akoonu ti awọn baiti wọnyi le jẹ ohunkohun ṣugbọn ibiti o gbọdọ jẹ deede fun eyi lati ni aabo.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to ṣe deede 'x' si titọ 'to'-baiti ti o ro pe 'to' jẹ agbara ti 2.
// Eyi tẹle atẹle apẹẹrẹ ni C/C ++ ELF koodu itupalẹ nibiti (x + si, 1)&-to ti lo.
// Rust ko jẹ ki o jẹ ki o lo lilo nitorina ni mo ṣe lo
// 2 ká-iranlowo iyipada lati tun ṣe iyẹn.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 n gba awọn baiti nọmba lati ege (ti o ba wa bayi) ati afikun ohun ti o rii daju pe bibẹ pẹpẹ ti wa ni deede ṣe deede.
// Ti nọmba boya awọn baiti ti o beere ba tobi ju tabi bibẹrẹ ko le ṣe atunto lẹhinna nitori ko to awọn baiti to ku ti o wa tẹlẹ, Ko si ẹnikan ti o pada ati pe ege naa ko yipada.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Iṣẹ yii ko ni awọn alaigbagbọ gidi olupe gbọdọ gbe atilẹyin miiran ju boya pe 'bytes' yẹ ki o wa ni deede fun iṣẹ (ati lori diẹ ninu awọn ayaworan ti o tọ).
// Awọn iye ni awọn aaye Elf_Nhdr le jẹ ọrọ isọkusọ ṣugbọn iṣẹ yii ṣe idaniloju ko si iru nkan bẹẹ.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Eyi jẹ ailewu niwọn igba ti aaye to wa ati pe a kan jẹrisi pe ninu alaye ti o ba wa loke nitorinaa eyi ko gbọdọ jẹ ailewu.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Akiyesi pe sice_of: :<Elf_Nhdr>() nigbagbogbo ṣe deede 4-baiti.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Ṣayẹwo boya a ti de opin.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // A transmute jade ohun nhdr sugbon a fara ro awọn Abajade struct.
        // A ko ni igbẹkẹle awọn orukọ tabi descsz ati pe a ko ṣe awọn ipinnu ailewu ti o da lori iru.
        //
        // Nitorinaa paapaa ti a ba jade kuro ni idoti pipe o yẹ ki a tun ni aabo.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Tọkasi pe apakan kan ni ṣiṣe.
const PERM_X: u32 = 0b00000001;
/// Tọkasi pe apakan kan jẹ kikọ.
const PERM_W: u32 = 0b00000010;
/// Tọkasi wipe a apa ni ṣeékà.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Ṣe aṣoju apa ELF ni asiko asiko.
struct Segment {
    /// Yoo fun adirẹsi foju akoko asiko ti awọn akoonu ti apakan yii.
    addr: usize,
    /// Yoo fun iwọn iranti ti awọn akoonu ti apakan yii.
    size: usize,
    /// Yoo fun adirẹsi foju modulu ti apakan yii pẹlu faili ELF.
    mod_rel_addr: usize,
    /// Fun awọn igbanilaaye ti a rii ninu faili ELF.
    /// Awọn igbanilaaye wọnyi kii ṣe dandan awọn igbanilaaye ti o wa ni asiko asiko sibẹsibẹ.
    flags: Perm,
}

/// Jẹ ki ọkan ṣe itọju lori Awọn apa lati DSO kan.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Ṣe aṣoju ELF DSO (Ohunkan Pipin Dynamic).
/// Iru iru yii tọka data ti a fipamọ sinu DSO gangan dipo ṣiṣe ẹda tirẹ.
struct Dso<'a> {
    /// Ọna asopọ agbara n fun wa ni orukọ nigbagbogbo, paapaa ti orukọ naa ba ṣofo.
    /// Ninu ọran ti a ṣiṣẹ akọkọ orukọ yii yoo ṣofo.
    /// Ni ọran ti ohun ti o pin o yoo jẹ orukọ ọmọ (wo DT_SONAME).
    name: &'a str,
    /// Lori Fuchsia o fẹrẹ pe gbogbo awọn alakomeji ni awọn ID idanimọ ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// Ko si ọna lati ṣe afiwe alaye DSO pẹlu faili ELF gidi kan lẹhinna ti ko ba si build_id nitorinaa a nilo pe gbogbo DSO ni ọkan nibi.
    ///
    /// DSO ko laisi kọ_id ti wa ni foju.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Pada aṣetunṣe lori Awọn ipin ninu DSO yii.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Awọn aṣiṣe wọnyi ṣe koodu awọn ọrọ ti o dide lakoko ti o n ṣe alaye alaye nipa DSO kọọkan.
///
enum Error {
    /// Orukọ aṣiṣe tumọ si pe aṣiṣe kan waye lakoko yiyipada okun ara C sinu okun rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError tumọ si pe a ko ri ID kọ.
    /// Eyi le jẹ boya nitori pe DSO ko ni ID idanimọ tabi nitori apakan ti o ni ID ti o kọ ko ni ibajẹ.
    ///
    BuildIDError,
}

/// Awọn ipe boya 'dso' tabi 'error' fun DSO kọọkan ti sopọ mọ sinu ilana nipasẹ ọna asopọ agbara.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter kan ti yoo ni ọkan ninu awọn ọna jijẹ ti a pe ni DSO foreach.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ṣe idaniloju pe info.name yoo tọka si ipo to wulo.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Iṣẹ yii tẹ aami ifami aami Fuchsia fun gbogbo alaye ti o wa ninu DSO kan.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}