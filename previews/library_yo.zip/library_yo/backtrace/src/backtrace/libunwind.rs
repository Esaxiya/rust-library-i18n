//! Atilẹyin sẹhin nipa lilo awọn API libunwind/gcc_s/etc.
//!
//! Atokun yii ni agbara lati tu silẹ akopọ nipa lilo awọn API ara-ara libunwind.
//! Akiyesi pe gbogbo opo awọn imuse wa ti API ti o dabi libunwind, ati pe eyi kan n gbiyanju lati wa ni ibamu pẹlu ọpọlọpọ ninu gbogbo wọn ni ẹẹkan dipo gbigba.
//!
//!
//! API libunwind jẹ agbara nipasẹ `_Unwind_Backtrace` ati pe o wa ni iṣe igbẹkẹle pupọ ni sisẹ ipadasẹhin kan.
//! Ko ṣe kedere patapata bi o ṣe ṣe (awọn itọka fireemu? Eh_frame info? Mejeeji?) Ṣugbọn o dabi pe o ṣiṣẹ!
//!
//! Pupọ ti eka ti module yii n ṣakoso awọn iyatọ oriṣiriṣi pẹpẹ kọja awọn imuṣẹ libunwind.
//! Bibẹkọ ti eyi jẹ ọna taara taara Rust abuda si awọn API libunwind.
//!
//! Eyi ni aiṣe aifọwọyi API fun gbogbo awọn iru ẹrọ ti kii ṣe Windows lọwọlọwọ.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// Pẹlu itọka libunwind aise o yẹ ki o jẹ iraye si nikan ni ọna kika kika kika, nitorinaa `Sync` ni.
// Nigbati a ba n ranṣẹ si awọn okun miiran nipasẹ `Clone` a yipada nigbagbogbo si ẹya ti ko ni idaduro awọn itọka inu, nitorinaa o yẹ ki a jẹ `Send` pẹlu.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // O dabi pe lori OSX `_Unwind_FindEnclosingFunction` da ijuboluwole kan pada si ... nkan ti koyewa.
        // Dajudaju kii ṣe nigbagbogbo iṣẹ iwọle fun idi eyikeyi.
        // Ko ṣe alaye ni kikun si mi ohun ti n lọ nibi, nitorinaa ṣe ireti eyi fun bayi ati pe nigbagbogbo pada ip.
        //
        // Akiyesi pe a ti foju idanwo `skip_inner_frames.rs` lori OSX nitori gbolohun ọrọ yii, ati pe ti o ba ṣe atunṣe eyi idanwo naa ninu ilana le ṣee ṣiṣẹ lori OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Yọọ wiwo ile-ikawe ti a lo fun awọn ẹhin
///
/// Akiyesi pe a gba koodu ti o ku laaye nitori pe awọn abuda nikan ni iOS ko lo gbogbo wọn ṣugbọn o ṣafikun awọn atunto ti o ni pato pẹpẹ diẹ ti ba koodu jẹ pupọ
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // lo nipasẹ ARM EABI nikan
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // Ko si abinibi_Unwind_Backtrace lori iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // wa lati GCC 4.2.0, yẹ ki o wa ni itanran fun idi wa
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Iṣẹ yii jẹ aṣiṣe aṣiṣe: dipo ki o gba Adirẹsi Canonical Frame fireemu yii (aka SP olupe ti o pe) o pada SP yii.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x nlo iye CFA ti o ni abosi, nitorinaa a nilo lati lo_Unwind_GetGR lati gba iforukọsilẹ ijuboluwole (%r15) dipo gbigbekele_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Lori android ati apa, iṣẹ `_Unwind_GetIP` ati opo awọn miiran jẹ macros, nitorinaa a ṣalaye awọn iṣẹ ti o ni imugboroosi ti awọn makrosi naa.
    //
    //
    // TODO: ọna asopọ si faili akọle ti o ṣalaye awọn macro wọnyi, ti o ba le rii.
    // (Mo, fitzgen, ko le wa faili akọsori pe diẹ ninu awọn amugbooro macro wọnyi ni akọkọ ya lati.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 ni ijuboluwole akopọ lori apa.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Iṣẹ yii ko si tẹlẹ lori Android tabi ARM/Linux, nitorinaa sọ di a-ṣe-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}