use core::ffi::c_void;
use core::fmt;

/// Ṣe ayewo akopọ ipe lọwọlọwọ, kọja gbogbo awọn fireemu ti nṣiṣe lọwọ sinu pipade ti a pese lati ṣe iṣiro kakiri akopọ kan.
///
/// Iṣẹ yii jẹ iṣẹ-ṣiṣe ti ile-ikawe yii ni iṣiro awọn ọna akopọ fun eto kan.Tilekun ti a fun ni `cb` jẹ awọn iṣẹlẹ ikore ti `Frame` eyiti o ṣe aṣoju alaye nipa fireemu ipe yẹn lori akopọ naa.
/// Bíbo ti ni awọn fireemu ti a fun ni ọna ti isalẹ (ti a pe ni awọn iṣẹ laipẹ akọkọ).
///
/// Iye ipadabọ ti pipade jẹ itọkasi ti boya ẹhin yẹ ki o tẹsiwaju.Iye ipadabọ ti `false` yoo fopin si ẹhin ati pada lẹsẹkẹsẹ.
///
/// Ni kete ti a ti ra `Frame` o ṣee ṣe ki o fẹ pe `backtrace::resolve` lati yipada `ip` (ijuboluwole itọnisọna) tabi adirẹsi aami si `Symbol` nipasẹ eyiti orukọ ati/tabi orukọ filen/laini le kọ.
///
///
/// Akiyesi pe eyi jẹ iṣẹ ipele kekere ti o jo ati pe ti o ba fẹ, fun apẹẹrẹ, mu ẹhin ẹhin lati ṣe ayewo nigbamii, lẹhinna iru `Backtrace` le jẹ deede diẹ sii.
///
/// # Awọn ẹya ti a beere
///
/// Iṣẹ yii nilo ẹya `std` ti `backtrace` crate lati muu ṣiṣẹ, ati pe ẹya `std` ti ṣiṣẹ nipasẹ aiyipada.
///
/// # Panics
///
/// Iṣẹ yii gbìyànjú lati ma ṣe panic rara, ṣugbọn ti `cb` ba pese panics lẹhinna diẹ ninu awọn iru ẹrọ yoo fi agbara mu panic ilọpo meji lati pa ilana naa.
/// Diẹ ninu awọn iru ẹrọ lo ile-ikawe C eyiti o lo awọn ifaseyin ipe inu eyiti ko le ṣalaye nipasẹ, nitorinaa ijaya lati `cb` le ṣe ifilọlẹ ilana ilana.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // tẹsiwaju sẹhin
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Kanna bi `trace`, ailewu nikan bi ko ṣe amuṣiṣẹpọ.
///
/// Iṣẹ yii ko ni awọn onigbọwọ amuṣiṣẹpọ ṣugbọn o wa nigbati ẹya `std` ti crate yii ko kojọ.
/// Wo iṣẹ `trace` fun iwe ati awọn apẹẹrẹ diẹ sii.
///
/// # Panics
///
/// Wo alaye lori `trace` fun awọn ikoko lori ẹru `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait kan ti o nsoju fireemu ọkan ti ẹhin, ti fun ni iṣẹ `trace` ti crate yii.
///
/// Tilekun iṣẹ wiwa ni yoo jẹ awọn fireemu ti a fun, ati pe fireemu ti fẹrẹ ranṣẹ bi a ṣe ko mọ imuse ipilẹ nigbagbogbo titi asiko asiko.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Pada ijuboluwole itọnisọna lọwọlọwọ ti fireemu yii.
    ///
    /// Eyi jẹ deede itọnisọna atẹle lati ṣe ni fireemu, ṣugbọn kii ṣe gbogbo awọn imuṣẹ ṣe atokọ eyi pẹlu deede 100% (ṣugbọn o sunmọ ni gbogbogbo sunmọ).
    ///
    ///
    /// A ṣe iṣeduro lati kọja iye yii si `backtrace::resolve` lati yi i pada si orukọ aami kan.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Pada ijuboluwole lọwọlọwọ ti fireemu yii.
    ///
    /// Ninu ọran pe ẹhin kan ko le bọsipọ ijuboluwo akopọ fun fireemu yii, ijuboluwo asan ti pada.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Pada adirẹsi adirẹsi ibẹrẹ ti fireemu iṣẹ yii.
    ///
    /// Eyi yoo gbiyanju lati pada si ijuboluwole itọnisọna ti o pada nipasẹ `ip` si ibẹrẹ iṣẹ naa, da pada iye yẹn.
    ///
    /// Ni awọn ọrọ miiran, sibẹsibẹ, awọn ẹhin ẹhin yoo kan pada `ip` lati iṣẹ yii.
    ///
    /// Iye ti o pada le ṣee lo nigbakan ti `backtrace::resolve` ba kuna lori `ip` ti a fun loke.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Pada adirẹsi ipilẹ ti module naa ti fireemu jẹ ti.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Eyi nilo lati wa ni akọkọ, lati rii daju pe Miri gba iṣaaju lori pẹpẹ alejo
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // nikan lo ninu aami dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}