# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Ile-ikawe kan fun gbigba awọn ipadasẹhin ni asiko asiko fun Rust.
Ile-ikawe yii ni ifọkansi lati jẹki atilẹyin ti ile-ikawe boṣewa nipa pipese wiwo siseto lati ṣiṣẹ pẹlu, ṣugbọn o tun ṣe atilẹyin ni irọrun irọrun titẹ sẹhin lọwọlọwọ bi libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Lati jiroro ni mu ẹhin sẹhin ki o mu idaduro pẹlu rẹ titi di akoko nigbamii, o le lo iru `Backtrace` ipele-oke.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ti o ba jẹ pe, sibẹsibẹ, o fẹ lati ni iraye si aise si iṣẹ ṣiṣe kakiri gangan, o le lo awọn iṣẹ `trace` ati `resolve` taara.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Yanju ijuboluwole itọnisọna yii si orukọ aami kan
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // tẹsiwaju lati lọ si fireemu atẹle
    });
}
```

# License

Iṣẹ yii ni iwe-aṣẹ labẹ boya ti

 * Iwe-aṣẹ Apache, Ẹya 2.0, ([LICENSE-APACHE](LICENSE-APACHE) tabi http://www.apache.org/licenses/LICENSE-2.0)
 * Iwe-aṣẹ MIT ([LICENSE-MIT](LICENSE-MIT) tabi http://opensource.org/licenses/MIT)

ni aṣayan rẹ.

### Contribution

Ayafi ti o ba sọ ni gbangba bibẹẹkọ, eyikeyi ilowosi ti a fi ranse pẹlu imomose fun ifisi ninu backtrace-rs nipasẹ rẹ, bi a ti ṣalaye ninu iwe-aṣẹ Apache-2.0, yoo ni iwe-aṣẹ meji bi loke, laisi awọn ofin tabi ipo afikun eyikeyi.







