# The `rustc-std-workspace-core` crate

Eleyi crate ni a shim ati ki o sofo crate eyi ti nìkan da lori `libcore` ati reexports gbogbo awọn ti awọn oniwe-akoonu ti.
The crate ni awọn crux ti ifiagbara awọn boṣewa ìkàwé to dale lori crates lati crates.io

Crates lori crates.io pe ile-ikawe boṣewa dale lori iwulo lati dale lori `rustc-std-workspace-core` crate lati crates.io, eyiti o ṣofo.

A lo `[patch]` lati yi danu o si yi crate ni yi ibi ipamọ.
Gẹgẹbi abajade, crates lori crates.io yoo fa igbẹkẹle edge si `libcore`, ẹya ti a ṣalaye ninu ibi ipamọ yii.
Ti o yẹ ki fa gbogbo awọn durode egbegbe lati rii daju Cargo duro crates ni ifijišẹ!

Akọsilẹ ti crates on crates.io nilo lati dale lori yi crate pẹlu awọn orukọ `core` fun ohun gbogbo to ise ti tọ.Lati ṣe ki nwọn ki o le lo:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Nipasẹ awọn lilo ti awọn `package` bọtini awọn crate ti wa ni lorukọmii si `core`, afipamo o yoo wo bi

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

nigbati Cargo kepe akopọ, ni itẹlọrun itọsọna `extern crate core` ti ko dara ti abẹrẹ nipasẹ akopọ naa.




