#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` gba implementor ti a ṣiṣe executor lati ṣẹda a [`Waker`] eyi ti o pese ti adani wakeup ihuwasi.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// O oriširiši kan ti a ti data ijuboluwole ati ki o kan [virtual function pointer table (vtable)][vtable] ti customizes ihuwasi ti awọn `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Atọka data kan, eyiti o le lo lati tọju data lainidii bi o ti beere fun alaṣẹ naa.
    /// Eyi le jẹ apẹẹrẹ
    /// ijuboluwo ti iru-paarẹ si `Arc` ti o ni nkan ṣe pẹlu iṣẹ-ṣiṣe naa.
    /// Iye ti yi oko olubwon kọja si gbogbo awọn iṣẹ ti o wa ni apa ti awọn vtable bi akọkọ paramita.
    ///
    data: *const (),
    /// Tabili ijuboluwole iṣẹ ti o ṣe ihuwasi ihuwasi ti oluji yii.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Ṣẹda titun kan `RawWaker` lati pese `data` ijuboluwole ati `vtable`.
    ///
    /// The `data` ijuboluwole a le lo lati fi lainidii data bi beere nipa awọn executor.Eleyi le je eg
    /// ijuboluwo ti iru-paarẹ si `Arc` ti o ni nkan ṣe pẹlu iṣẹ-ṣiṣe naa.
    /// Iye ijuboluwole yii yoo kọja si gbogbo awọn iṣẹ ti o jẹ apakan ti `vtable` bi ipilẹṣẹ akọkọ.
    ///
    /// `vtable` ṣe aṣa ihuwasi ti `Waker` eyiti o ṣẹda lati `RawWaker` kan.
    /// Fun iṣẹ kọọkan lori `Waker`, iṣẹ ti o ni nkan ninu `vtable` ti ipilẹ `RawWaker` yoo pe.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// A foju iṣẹ ijuboluwole tabili (vtable) ti o so awọn ihuwasi ti a [`RawWaker`].
///
/// Awọn ijuboluwole kọja si gbogbo awọn iṣẹ inu awọn vtable ni awọn `data` ijuboluwole lati enclosing [`RawWaker`] ohun na.
///
/// Awọn iṣẹ inu yi struct ti wa ni nikan ti a ti pinnu lati wa ni a npe lori `data` ijuboluwole ti a daradara ti won ko [`RawWaker`] ohun lati inu awọn [`RawWaker`] imuse.
/// Pipe ọkan ninu awọn iṣẹ ti o wa ninu lilo eyikeyi ijuboluwole `data` miiran yoo fa ihuwasi aisọye.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// A yoo pe iṣẹ yii nigbati [`RawWaker`] ba di cloned, fun apẹẹrẹ nigbati [`Waker`] ninu eyiti [`RawWaker`] ti wa ni fipamọ di oniye.
    ///
    /// Imuse iṣẹ yii gbọdọ ni idaduro gbogbo awọn orisun ti o nilo fun apẹẹrẹ afikun ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    /// Pipe `wake` lori abajade [`RawWaker`] yẹ ki o ja si jiji ti iṣẹ kanna ti yoo ti ji nipasẹ [`RawWaker`] atilẹba.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Iṣẹ yi yoo wa ni a npe ni nigba ti `wake` ni a npe ni lori [`Waker`].
    /// O gbọdọ ji iṣẹ ṣiṣe ti o ni nkan ṣe pẹlu [`RawWaker`] yii.
    ///
    /// Imuse iṣẹ yii gbọdọ rii daju lati tu eyikeyi awọn orisun ti o ni nkan ṣe pẹlu apẹẹrẹ yii ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Iṣẹ yi yoo wa ni a npe ni nigba ti `wake_by_ref` ni a npe ni lori [`Waker`].
    /// O gbọdọ ji iṣẹ ṣiṣe ti o ni nkan ṣe pẹlu [`RawWaker`] yii.
    ///
    /// Iṣẹ yii jọra si `wake`, ṣugbọn ko gbọdọ jẹ ijuboluwole data ti a pese.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Iṣẹ yi olubwon ti a npe ni nigbati a [`RawWaker`] olubwon silẹ.
    ///
    /// Imuse iṣẹ yii gbọdọ rii daju lati tu eyikeyi awọn orisun ti o ni nkan ṣe pẹlu apẹẹrẹ yii ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Ṣẹda titun kan `RawWakerVTable` lati pese `clone`, `wake`, `wake_by_ref`, ati `drop` iṣẹ.
    ///
    /// # `clone`
    ///
    /// A yoo pe iṣẹ yii nigbati [`RawWaker`] ba di cloned, fun apẹẹrẹ nigbati [`Waker`] ninu eyiti [`RawWaker`] ti wa ni fipamọ di oniye.
    ///
    /// Imuse iṣẹ yii gbọdọ ni idaduro gbogbo awọn orisun ti o nilo fun apẹẹrẹ afikun ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    /// Pipe `wake` lori abajade [`RawWaker`] yẹ ki o ja si jiji ti iṣẹ kanna ti yoo ti ji nipasẹ [`RawWaker`] atilẹba.
    ///
    /// # `wake`
    ///
    /// Iṣẹ yi yoo wa ni a npe ni nigba ti `wake` ni a npe ni lori [`Waker`].
    /// O gbọdọ ji iṣẹ ṣiṣe ti o ni nkan ṣe pẹlu [`RawWaker`] yii.
    ///
    /// Imuse iṣẹ yii gbọdọ rii daju lati tu eyikeyi awọn orisun ti o ni nkan ṣe pẹlu apẹẹrẹ yii ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Iṣẹ yi yoo wa ni a npe ni nigba ti `wake_by_ref` ni a npe ni lori [`Waker`].
    /// O gbọdọ ji iṣẹ ṣiṣe ti o ni nkan ṣe pẹlu [`RawWaker`] yii.
    ///
    /// Iṣẹ yii jọra si `wake`, ṣugbọn ko gbọdọ jẹ ijuboluwole data ti a pese.
    ///
    /// # `drop`
    ///
    /// Iṣẹ yi olubwon ti a npe ni nigbati a [`RawWaker`] olubwon silẹ.
    ///
    /// Imuse iṣẹ yii gbọdọ rii daju lati tu eyikeyi awọn orisun ti o ni nkan ṣe pẹlu apẹẹrẹ yii ti [`RawWaker`] ati iṣẹ ṣiṣe ti o jọmọ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// The `Context` ti ẹya gbígbé-ṣiṣe.
///
/// Lọwọlọwọ, `Context` nikan n ṣiṣẹ lati pese iraye si `&Waker` eyiti o le lo lati ji iṣẹ ṣiṣe lọwọlọwọ.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Rii daju pe a jẹ future-ẹri lodi si awọn iyipada iyatọ nipa mimu igbesi aye mu ni ailagbara (awọn igbesi aye ipo ariyanjiyan jẹ ilodi si lakoko ti awọn igbesi aye ipo-pada jẹ covariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Ṣẹda titun kan `Context` lati kan `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Pada itọkasi kan si `Waker` fun iṣẹ ṣiṣe lọwọlọwọ.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` jẹ mimu fun jiji iṣẹ-ṣiṣe kan nipa fifiranṣẹ olusẹṣẹ rẹ pe o ti ṣetan lati ṣiṣe.
///
/// Mu yii mu encapsulates apeere [`RawWaker`] kan, eyiti o ṣalaye ihuwasi jiji-kan pato ti oluṣe.
///
///
/// Awọn ohun elo [`Clone`], [`Send`], ati [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Ji soke awọn iṣẹ-ṣiṣe ni nkan ṣe pẹlu yi `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Ipe jiji gangan jẹ aṣoju nipasẹ ipe iṣẹ foju kan si imuse eyiti o ṣalaye nipasẹ alaṣẹ.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Maṣe pe `drop`-olukọ yoo jẹun nipasẹ `wake`.
        crate::mem::forget(self);

        // Aabo: Eyi jẹ ailewu nitori `Waker::from_raw` nikan ni ọna
        // lati ṣe ipilẹṣẹ `wake` ati `data` nilo olumulo lati gba pe adehun ti `RawWaker` ti ni atilẹyin.
        //
        unsafe { (wake)(data) };
    }

    /// Ji iṣẹ ṣiṣe ti o ni nkan ṣe pẹlu `Waker` yii laisi jijẹ `Waker`.
    ///
    /// Eyi jọra si `wake`, ṣugbọn o le ni irọrun diẹ ni ọran nibiti ohun-ini `Waker` wa.
    /// Ọna yii yẹ ki o ni ayanfẹ si pipe `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Ipe jiji gangan jẹ aṣoju nipasẹ ipe iṣẹ foju kan si imuse eyiti o ṣalaye nipasẹ alaṣẹ.
        //

        // Aabo: wo `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Pada `true` ti `Waker` yii ati `Waker` miiran ti ji iṣẹ kanna.
    ///
    /// Iṣẹ yi ṣiṣẹ lori a ti o dara ju-akitiyan igba, ati ki o le pada eke paapa nigbati awọn `Waker`s yoo ji kanna-ṣiṣe.
    /// Sibẹsibẹ, ti o ba ti yi iṣẹ pada `true`, o ti wa ni ẹri wipe awọn `Waker`s yoo ji kanna-ṣiṣe.
    ///
    /// Iṣẹ yii ni lilo akọkọ fun awọn idi ti o dara ju.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Ṣẹda titun kan `Waker` lati [`RawWaker`].
    ///
    /// Awọn ihuwasi ti awọn pada `Waker` ti wa ni aisọye ti o ba ti guide telẹ ni [`RawWaker`] 's ati [`RawWakerVTable`]' s iwe ti a ko ti ọwọ.
    ///
    /// Nitorina ọna yii ko ni ailewu.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // Aabo: Eyi jẹ ailewu nitori `Waker::from_raw` nikan ni ọna
            // lati ṣe ipilẹṣẹ `clone` ati `data` nilo olumulo lati gba pe adehun ti [`RawWaker`] ti ni atilẹyin.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // Aabo: Eyi jẹ ailewu nitori `Waker::from_raw` nikan ni ọna
        // to initialize `drop` ati `data` nilo awọn olumulo lati gba pe awọn guide ti `RawWaker` ti wa ni ọwọ.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}