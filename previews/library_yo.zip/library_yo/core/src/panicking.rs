//! Atilẹyin Panic fun libcore
//!
//! Ikawe ikawe ko le ṣalaye ẹru, ṣugbọn o *kede* ẹru.
//! Eyi tumọ si pe awọn iṣẹ inu libcore ni a gba laaye si panic, ṣugbọn lati wulo iwulo crate ti o wa ni oke gbọdọ ṣalaye ẹru fun libcore lati lo.
//! Ni wiwo lọwọlọwọ fun ẹru ni:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Itumọ yii ngbanilaaye fun ẹru pẹlu eyikeyi ifiranṣẹ gbogbogbo, ṣugbọn ko gba laaye fun ikuna pẹlu iye `Box<Any>` kan.
//! (`PanicInfo` kan ni a `&(dyn Any + Send)`, fun eyi ti a fọwọsi ni a ni idinwon iye ni `PanicInfo: : internal_constructor`.) Awọn idi fun eyi ni wipe libcore ko ba gba laaye lati allocate.
//!
//!
//! Atokun yii ni awọn iṣẹ ẹru miiran diẹ, ṣugbọn iwọnyi jẹ awọn ohun elo lang ti o nilo fun alakojo.Gbogbo panics ti wa ni igbadun nipasẹ iṣẹ kan yii.
//! A polongo aami gangan nipasẹ ẹda `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Imuse ipilẹ ti libro's `panic!` macro nigbati ko lo kika kan.
#[cold]
// maṣe laini laini ayafi ti panic_immediate_abort lati yago fun fifọ koodu ni awọn aaye ipe bi o ti ṣeeṣe
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nilo nipasẹ codegen fun panic lori iṣan-omi ati awọn ifopinsi `Assert` MIR miiran
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Lo Arguments::new_v1 dipo kika_args! ("{}", Expr) lati dinku iwọn ni iwọn agbara.
    // Awọn ọna kika_args!macro lo Str's Display trait lati kọ expr, eyiti o pe Formatter::pad, eyiti o gbọdọ gba iyọkuro okun ati fifẹ (botilẹjẹpe ko si ọkan ti o lo nibi).
    //
    // Lilo Arguments::new_v1 le gba alapọpọ laaye lati fi Formatter::pad silẹ lati alakomeji ti o wu, fifipamọ to awọn kilobytes diẹ.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // nilo fun const-akojopo panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nilo nipasẹ codegen fun panic lori wiwọle OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Imuse ipilẹ ti libro's `panic!` macro nigbati o ba n lo kika.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // AKIYESI Iṣẹ yii ko kọja aala FFI;o jẹ ipe Rust-to-Rust ti o ni ipinnu si iṣẹ `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // Aabo: `panic_impl` ti ṣalaye ni koodu Rust ailewu ati nitorinaa ailewu lati pe.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Iṣẹ inu fun `assert_eq!` ati awọn macros `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}