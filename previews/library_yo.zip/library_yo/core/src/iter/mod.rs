//! Composable ita aṣetunṣe.
//!
//! Ti o ba ti sọ ri ara rẹ pẹlu a gbigba ti awọn diẹ ninu awọn irú, o si nilo lati ṣe ohun išišẹ lori awọn eroja ti wi gbigba, o yoo ni kiakia ṣiṣe awọn sinu 'iterators'.
//! Iterators ti wa ni darale lo ninu idiomatic Rust koodu, ki o ká tọ di faramọ pẹlu wọn.
//!
//! Ṣaaju ki o to ṣalaye diẹ sii, jẹ ki a sọrọ nipa bawo ni a ṣe ṣeto module yii:
//!
//! # Organization
//!
//! Eleyi module ti wa ni ibebe ṣeto nipasẹ Iru:
//!
//! * [Traits] ni o wa ni mojuto ìka: awọn wọnyi traits setumo ohun ti Iru iterators tẹlẹ ati ohun ti o le se pẹlu wọn.Awọn ọna ti awọn wọnyi traits wa ni tọ o nri diẹ ninu awọn afikun iwadi akoko sinu.
//! * [Functions] pese diẹ ninu awọn wulo ona lati ṣẹda diẹ ninu awọn ipilẹ iterators.
//! * [Structs] jẹ igbagbogbo awọn oriṣi ipadabọ ti awọn ọna pupọ lori traits module yii.O yoo maa fẹ lati wo ni awọn ọna ti o ṣẹda awọn `struct`, dipo ju awọn `struct` ara.
//! Fun diẹ apejuwe awọn nipa idi ti, wo '[imulo awon Iterator](#imulo-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! O n niyen!Jẹ ká iwo sinu iterators.
//!
//! # Iterator
//!
//! Okan ati ọkàn ti yi module ni awọn [`Iterator`] trait.Awọn mojuto ti [`Iterator`] wulẹ bi yi:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Onitumọ kan ni ọna kan, [`next`], eyiti o pe nigbati o pe, pada `[Aṣayan`] kan `<Item>`.
//! [`next`] yoo pada [`Some(Item)`] bi gun bi nibẹ ni o wa eroja, ati ni kete ti nwọn ti sọ gbogbo a ti ti re, yoo pada `None` to fihan pe aṣetunṣe wa ni ti pari.
//! Olumulo iterators le yan lati tun bẹrẹ aṣetunṣe, nitorinaa pipe [`next`] lẹẹkansii le tabi ko le bẹrẹ pada pada [`Some(Item)`] lẹẹkansii ni aaye kan (fun apẹẹrẹ, wo [`TryIter`]).
//!
//!
//! [`Iterator`] 's ni kikun definition pẹlu nọmba kan ti miiran awọn ọna bi daradara, sugbon ti won ti wa ni aiyipada awọn ọna, itumọ ti lori oke ti [`next`], ati ki o gba wọn fun free.
//!
//! Iterators ni o wa tun composable, ati awọn ti o ká wọpọ to pq wọn jọ lati se eka sii iwa ti processing.Wo awọn [Adapters](#adapters) apakan ni isalẹ fun alaye diẹ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Awọn mẹta iwa ti aṣetunṣe
//!
//! Awọn ọna ti o wọpọ mẹta lo wa eyiti o le ṣẹda awọn onitumọ lati ikojọpọ kan:
//!
//! * `iter()`, eyi ti iterates lori `&T`.
//! * `iter_mut()`, eyi ti iterates lori `&mut T`.
//! * `into_iter()`, eyi ti iterates lori `T`.
//!
//! Orisirisi awọn nkan ninu ile-ikawe boṣewa le ṣe imisi ọkan tabi diẹ sii ninu awọn mẹta, nibiti o ba yẹ.
//!
//! # Ṣiṣe Iterator
//!
//! Ṣiṣẹda ohun iterator ti ara rẹ je meji awọn igbesẹ: ṣiṣẹda a `struct` lati mu awọn iterator ká ipinle, ati ki o si nse [`Iterator`] fun awọn ti o `struct`.
//! Eyi ni idi ti ọpọlọpọ `struct`s wa ninu modulu yii: ọkan wa fun aṣetunṣe kọọkan ati adapter aṣetunṣe.
//!
//! Jẹ ká ṣe ohun iterator ti a npè ni `Counter` eyi ti o ni ère lati `1` to `5`:
//!
//! ```
//! // Ni akọkọ, ipilẹ:
//!
//! /// Atunṣe eyiti o ka lati ọkan si marun
//! struct Counter {
//!     count: usize,
//! }
//!
//! // a fẹ wa ka lati bẹrẹ ni ọkan, ki jẹ ki ká fi kan new() ọna lati iranlọwọ.
//! // Eleyi jẹ ko muna pataki, sugbon ni rọrun.
//! // Akọsilẹ ti a bẹrẹ `count` ni odo, a yoo ri idi ni `next()`'s imuse ni isalẹ.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ki o si, a se `Iterator` fun wa `Counter`:
//!
//! impl Iterator for Counter {
//!     // a yoo ka pẹlu lilo
//!     type Item = usize;
//!
//!     // next() jẹ ọna ti a beere nikan
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Increment wa ka.Eleyi jẹ idi ti a bere ni odo.
//!         self.count += 1;
//!
//!         // Ṣayẹwo lati rii boya a ti pari kika tabi rara.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ati bayi a le lo o!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Pipe [`next`] ọna yi n ni irọrun.Rust ni o ni a múu eyi ti o le pe [`next`] lori rẹ iterator, titi ti o Gigun `None`.Jẹ ki a lọ si iyẹn ni atẹle.
//!
//! Tun akiyesi pe `Iterator` pese a aiyipada imuse ti awọn ọna bi `nth` ati `fold` eyi ti pe `next` fipa.
//! Sugbon, o tun ṣee ṣe lati kọ kan aṣa imuse ti awọn ọna bi `nth` ati `fold` o ba ti ẹya iterator le oniṣiro wọn daradara siwaju sii lai pipe `next`.
//!
//! # `for` losiwajulosehin ati `IntoIterator`
//!
//! Rust ká `for` lupu sintasi ni kosi gaari fun iterators.Eyi ni apẹẹrẹ ipilẹ ti `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Eleyi yoo tẹ sita awọn nọmba ọkan nipasẹ marun, kọọkan lori ara wọn ila.Ṣugbọn o yoo se akiyesi nkankan nibi: a ko ti a npe ni ohunkohun lori wa vector lati gbe awọn ohun iterator.Kini o funni?
//!
//! Nibẹ ni a trait ni boṣewa ìkàwé fun jijere nkankan sinu ohun iterator: [`IntoIterator`].
//! Eleyi trait ni o ni ọkan ọna, [`into_iter`], eyi ti awọn ti awọn ohun imulo [`IntoIterator`] sinu ohun iterator.
//! Jẹ ki ká ya kan wo ni ti `for` lupu lẹẹkansi, ati ohun ti awọn alakojo awọn ti o si:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sugars yi sinu:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! First, a pe `into_iter()` lori iye.Lẹhinna, a baamu lori aṣetunṣe ti o pada, pipe [`next`] siwaju ati siwaju titi a o fi rii `None` kan.
//! Ni aaye yẹn, a `break` jade kuro ninu lupu, ati pe a ti ṣe atunṣe.
//!
//! Nibẹ ni ọkan diẹ abele bit nibi: awọn boṣewa ìkàwé ni ohun awon imuse ti [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ni gbolohun miran, gbogbo [`Iterator`] s se [`IntoIterator`], nipa kan pada ara wọn.Eyi tumọ si awọn ohun meji:
//!
//! 1. Ti o ba kikọ ohun [`Iterator`], o le lo o pẹlu kan `for` lupu.
//! 2. Ti o ba ṣiṣẹda kan gbigba, imulo [`IntoIterator`] fun o yoo gba rẹ gbigba lati ṣee lo pẹlu awọn `for` lupu.
//!
//! # Iterating nipasẹ itọkasi
//!
//! Niwon [`into_iter()`] gba `self` nipa iye, lilo a `for` lupu to iterate lori kan gbigba agbara ti gbigba.Nigbagbogbo, o le fẹ lati ṣe igbasilẹ akopọ kan laisi jijẹ rẹ.
//! Ọpọlọpọ awọn collections pese ọna ti o pese iterators lori jo, Conventionally ti a npe ni `iter()` ati `iter_mut()` lẹsẹsẹ:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ti wa ni ṣi ohun ini nipasẹ iṣẹ yi.
//! ```
//!
//! Ti o ba ti a gbigba iru `C` pese `iter()`, ni o maa tun alailewu `IntoIterator` fun `&C`, pẹlu ohun imuse ti o kan ipe `iter()`.
//! Bakan naa, gbigba `C` ti o pese `iter_mut()` gbogbo awọn imuse `IntoIterator` fun `&mut C` nipasẹ sisọ si `iter_mut()`.Eleyi kí a rọrun shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // kanna bi `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // kanna bi `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Lakoko ti o ti ọpọlọpọ awọn collections nse `iter()`, ko gbogbo nse `iter_mut()`.
//! Fun apẹẹrẹ, mutating awọn bọtini ti a [`HashSet<T>`] tabi [`HashMap<K, V>`] le fi awọn gbigba sinu ohun aisedede ipinle ti o ba awọn bọtini Hashes ayipada, ki awọn wọnyi collections nikan nse `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Awọn iṣẹ ti o ya ohun [`Iterator`] ki o si pada miran [`Iterator`] ti wa ni igba ti a npe 'iterator alamuuṣẹ', bi nwọn ba a fọọmu ti awọn 'ohun ti nmu badọgba
//! pattern'.
//!
//! Wọpọ iterator alamuuṣẹ ni [`map`], [`take`], ati [`filter`].
//! Fun diẹ sii, wo awọn iwe aṣẹ wọn.
//!
//! Ti o ba ti ohun iterator ohun ti nmu badọgba panics, awọn iterator yoo si wa ni ohun lalaïkomogba ti (sugbon iranti ailewu) ipinle.
//! Yi ipinle ni tun ko ni ẹri lati duro kanna kọja awọn ẹya ti Rust, ki o yẹ ki o yago fun gbigbe ara lori awọn gangan iye pada nipa ohun iterator eyi ti isoretinu.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (ati iterator [adapters](#adapters)) ni o wa *ọlẹ*. Eleyi ọna ti o kan ṣiṣẹda ohun iterator ko ni _do_ kan gbogbo pupo. Ko si ohun ti gan ṣẹlẹ titi ti o pe [`next`].
//! Eleyi ni ma kan orisun ti iporuru nigba ti ṣiṣẹda ohun iterator daada fun awọn oniwe-ẹgbẹ ipa.
//! Fun apẹẹrẹ, awọn [`map`] ọna ipe a bíbo lori kọọkan ano ti o iterates lori:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Eleyi yoo ko sita eyikeyi iye, bi a ti nikan da ohun iterator, dipo ju lilo o.Awọn alakojo yoo kilo fun wa nipa yi ni irú ti ihuwasi:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Awọn idiomatic ona lati kọ kan [`map`] fun awọn oniwe-ẹgbẹ igbelaruge ni lati lo a `for` lupu tabi pe awọn [`for_each`] ọna:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Miiran wọpọ ọna lati akojopo ohun iterator ni lati lo [`collect`] ọna lati gbe awọn titun kan gbigba.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterators ko ni lati wa ni lopin.Bi apẹẹrẹ, ohun-ìmọ-pari ibiti o jẹ ẹya ailopin iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! O jẹ wọpọ lati lo adapter aṣetunṣe [`take`] lati yi ohun aṣetọju ailopin pada si ọkan ti o ni opin:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Eleyi yoo tẹ sita awọn nọmba `0` nipasẹ `4`, kọọkan lori ara wọn ila.
//!
//! Bear ni lokan pe awọn ọna on ailopin iterators, ani awon ti fun eyi ti a esi le ti wa ni pinnu mathematiki ni adópin akoko, ko le fopin si.
//! Ni pataki, awọn ọna bii [`min`], eyiti o jẹ pe ọrọ gbogbogbo nilo lilọ kakiri gbogbo nkan ninu aṣetọju, o ṣee ṣe ki o ma pada ni aṣeyọri fun eyikeyi awọn alamọtọ ailopin.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Iyen o!Ohun ailopin lupu!
//! // `ones.min()` fa lilu ailopin, nitorinaa a ko ni de aaye yii!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;