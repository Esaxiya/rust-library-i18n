use crate::iter::{FusedIterator, TrustedLen};

/// Ṣẹda ohun iterator ti o egbin ohun ano gangan ẹẹkan.
///
/// Yi ti ni commonly lo lati mu kan nikan iye sinu kan [`chain()`] ti miiran iru aṣetunṣe.
/// Boya ti o ni ohun iterator ti eeni fere ohun gbogbo, ṣugbọn ti o nilo ohun afikun pataki nla.
/// Boya o ni iṣẹ kan ti o ṣiṣẹ lori iterators, ṣugbọn o nikan nilo lati lọwọ ọkan iye.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::iter;
///
/// // ọkan ni loneliest nọmba
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ọkan kan, iyẹn ni gbogbo ohun ti a gba
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining pọ pẹlu miiran iterator.
/// Jẹ ká sọ pé a fẹ lati iterate lori kọọkan faili ti awọn `.foo` liana, sugbon tun kan iṣeto ni faili,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // a nilo lati se iyipada lati ẹya iterator ti DirEntry-s si ohun iterator ti PathBufs, ki a lo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // bayi, wa iterator kan fun wa konfigi faili
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // pq awọn meji iterators jọ sinu ọkan ńlá iterator
/// let files = dirs.chain(config);
///
/// // yi yoo fun wa gbogbo awọn ti awọn faili ni .foo bi daradara bi .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// An iterator ti o egbin ohun ano gangan ẹẹkan.
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`once()`].Ri awọn oniwe iwe fun diẹ ẹ sii.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}