use crate::iter::{FusedIterator, TrustedLen};

/// Ṣẹda titun kan iterator ti o endlessly ntun kan nikan ano.
///
/// The `repeat()` iṣẹ ntun kan nikan iye lori ati lori lẹẹkansi.
///
/// Ailopin iterators bi `repeat()` ti wa ni igba lo pẹlu awọn alamuuṣẹ bi [`Iterator::take()`], ni ibere lati ṣe wọn lopin.
///
/// Ti o ba ti ni ano iru ti awọn iterator o nilo ko ni se `Clone`, tabi ti o ba ti o ko ba fẹ lati pa awọn tun ano ni iranti, o le dipo lo awọn [`repeat_with()`] iṣẹ.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::iter;
///
/// // awọn nọmba mẹrin 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, ṣi mẹrin
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Lọ han pẹlu [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ti o kẹhin apẹẹrẹ wà ju ọpọlọpọ awọn mẹrẹrin rìn.Jẹ ki ká nikan ni mẹrin mẹrẹrin rìn.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ati bayi a ba ṣe
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// An iterator ti ntun ohun ano endlessly.
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`repeat()`].Wo awọn iwe rẹ fun diẹ sii.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}