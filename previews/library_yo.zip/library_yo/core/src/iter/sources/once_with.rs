use crate::iter::{FusedIterator, TrustedLen};

/// Ṣẹda ohun iterator ti o lazily gbogbo a iye gangan ni kete ti nipa invoking awọn ti pese bíbo.
///
/// Yi ti ni commonly lo lati mu kan nikan iye monomono sinu kan [`chain()`] ti miiran iru aṣetunṣe.
/// Boya ti o ni ohun iterator ti eeni fere ohun gbogbo, ṣugbọn ti o nilo ohun afikun pataki nla.
/// Boya o ni iṣẹ kan ti o ṣiṣẹ lori iterators, ṣugbọn o nikan nilo lati lọwọ ọkan iye.
///
/// Ko [`once()`], iṣẹ yi yoo lazily ina awọn iye lori ìbéèrè.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::iter;
///
/// // ọkan ni loneliest nọmba
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ọkan kan, iyẹn ni gbogbo ohun ti a gba
/// assert_eq!(None, one.next());
/// ```
///
/// Chaining pọ pẹlu miiran iterator.
/// Jẹ ká sọ pé a fẹ lati iterate lori kọọkan faili ti awọn `.foo` liana, sugbon tun kan iṣeto ni faili,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // a nilo lati se iyipada lati ẹya iterator ti DirEntry-s si ohun iterator ti PathBufs, ki a lo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // bayi, wa iterator kan fun wa konfigi faili
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // pq awọn meji iterators jọ sinu ọkan ńlá iterator
/// let files = dirs.chain(config);
///
/// // yi yoo fun wa gbogbo awọn ti awọn faili ni .foo bi daradara bi .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// An iterator ti o egbin kan nikan ano ti Iru `A` nipa a to ti pese bíbo `F: FnOnce() -> A`.
///
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`once_with()`].
/// Wo iwe rẹ fun diẹ sii.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}