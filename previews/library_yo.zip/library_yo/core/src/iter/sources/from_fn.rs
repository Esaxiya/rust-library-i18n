use crate::fmt;

/// Ṣẹda titun kan iterator ibi ti kọọkan aṣetunṣe ipe ni pese bíbo `F: FnMut() -> Option<T>`.
///
/// Eleyi gba ṣiṣẹda a aṣa iterator pẹlu eyikeyi ihuwasi lai lilo awọn diẹ verbose sintasi ti ṣiṣẹda a ifiṣootọ type ati imulo awọn [`Iterator`] trait fun o.
///
/// Akiyesi pe aṣetunṣe `FromFn` ko ṣe awọn imọran nipa ihuwasi ti pipade naa, nitorinaa ni ilodisi ko ṣe imuse [`FusedIterator`], tabi yiyọ [`Iterator::size_hint()`] kuro lati aiyipada `(0, None)` rẹ.
///
///
/// Tilekun le lo awọn imudani ati agbegbe rẹ lati tọpinpin ipinle kọja awọn iterations.Ti o da lori bi awọn iterator ti lo, yi le beere seto awọn [`move`] Koko lori bíbo.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Jẹ ká tun-se awọn counter iterator lati [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Increment wa ka.Eleyi jẹ idi ti a bere ni odo.
///     count += 1;
///
///     // Ṣayẹwo lati rii boya a ti pari kika tabi rara.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// An iterator ibi ti kọọkan aṣetunṣe ipe ni pese bíbo `F: FnMut() -> Option<T>`.
///
/// Eleyi `struct` ni da nipasẹ awọn [`iter::from_fn()`] iṣẹ.
/// Wo iwe rẹ fun diẹ sii.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}