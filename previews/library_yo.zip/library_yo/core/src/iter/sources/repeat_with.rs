use crate::iter::{FusedIterator, TrustedLen};

/// Ṣẹda titun kan iterator ti ntun eroja ti Iru `A` endlessly nipa a to ti pese bíbo, awọn repeater, `F: FnMut() -> A`.
///
/// The `repeat_with()` iṣẹ ipe ni repeater lori ati lori lẹẹkansi.
///
/// Ailopin iterators bi `repeat_with()` ti wa ni igba lo pẹlu awọn alamuuṣẹ bi [`Iterator::take()`], ni ibere lati ṣe wọn lopin.
///
/// Ti o ba ti ni ano iru ti awọn iterator ti o nilo ọlọnà [`Clone`], ati awọn ti o jẹ dara lati pa awọn orisun ano ni iranti, o yẹ ki o dipo lo awọn [`repeat()`] iṣẹ.
///
///
/// An iterator yi ni `repeat_with()` ni ko kan [`DoubleEndedIterator`].
/// Ti o ba nilo `repeat_with()` lati pada a [`DoubleEndedIterator`], jọwọ ṣii a GitHub oro nse lilo rẹ nla.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::iter;
///
/// // jẹ ki ká ro ti a ni diẹ ninu awọn iye ti a iru ti o ni ko `Clone` tabi eyi ti ko ba fẹ lati ni ni iranti kan sibẹsibẹ nitori ti o jẹ gbowolori:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // iye kan pato lailai:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Lilo iyipada ati ipari ipari:
///
/// ```rust
/// use std::iter;
///
/// // Lati odo si agbara kẹta ti meji:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ati bayi a ba ṣe
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Atunṣe kan ti o ntun awọn eroja ti iru `A` ailopin nipa lilo `F: FnMut() -> A` pipade ti a pese.
///
///
/// Eleyi `struct` ni da nipasẹ awọn [`repeat_with()`] iṣẹ.
/// Wo iwe rẹ fun diẹ sii.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}