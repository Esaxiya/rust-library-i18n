use crate::{fmt, iter::FusedIterator};

/// Ṣẹda titun kan iterator ibi ti kọọkan ti o tele ohun kan ti wa se isiro da lori awọn opin ọkan.
///
/// Olutọju bẹrẹ pẹlu nkan akọkọ ti a fun (ti o ba jẹ eyikeyi) ati pe pipade `FnMut(&T) -> Option<T>` ti a fun lati ṣe iṣiro alabojuto ohun kọọkan.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Ti o ba ti yi iṣẹ pada `impl Iterator<Item=T>` o le wa ni orisun lori `unfold` ati ki o ko nilo a ifiṣootọ iru.
    //
    // Sibẹsibẹ nini kan ti a npè ni `Successors<T, F>` iru faye gba o lati wa ni `Clone` nigbati `T` ati `F` ni o wa.
    Successors { next: first, succ }
}

/// An titun iterator ibi ti kọọkan ti o tele ohun kan ti wa se isiro da lori awọn opin ọkan.
///
/// Eleyi `struct` ni da nipasẹ awọn [`iter::successors()`] iṣẹ.
/// Wo iwe rẹ fun diẹ sii.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}