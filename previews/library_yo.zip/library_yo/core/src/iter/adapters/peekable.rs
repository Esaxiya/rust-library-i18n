use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// An iterator pẹlu kan `peek()` ti o pada ohun iyan tọka si awọn tókàn ano.
///
///
/// `struct` yii ni a ṣẹda nipasẹ ọna [`peekable`] lori [`Iterator`].
/// Wo iwe rẹ fun diẹ sii.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Ranti iye yoju kan, paapaa ti ko ba si.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable gbọdọ ranti ti o ba ti a Kò ti a ti ri ninu awọn `.peek()` ọna.
// O idaniloju wipe `.peek();.peek();` tabi `.peek();.next();` nikan mura awọn amuye iterator ni julọ ẹẹkan.
// Eleyi ko nipa ara ṣe awọn iterator dapo.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Pada a tọka si awọn next() iye lai imutesiwaju iterator.
    ///
    /// Bi [`next`], ti o ba ti wa ni kan iye, o ti wa ni ti a we ni a `Some(T)`.
    /// Ṣugbọn ti o ba ti aṣetunṣe jẹ lori, `None` ti wa ni pada.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Nitori `peek()` pada a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, nibẹ le jẹ kan o ṣee iruju ipo ibi ti awọn pada iye ni a ė itọkasi.
    /// O ti le ri yi ipa ninu awọn apeere ni isalẹ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() jẹ ki a wò sinu future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Awọn iterator ko ni advance paapa ti o ba ti a `peek` ọpọ igba
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Lẹhin ti awọn iterator wa ni ti pari, ki ni `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Pada a mutable tọka si next() iye lai imutesiwaju iterator.
    ///
    /// Bi [`next`], ti o ba ti wa ni kan iye, o ti wa ni ti a we ni a `Some(T)`.
    /// Ṣugbọn ti o ba ti aṣetunṣe jẹ lori, `None` ti wa ni pada.
    ///
    /// Nitori `peek_mut()` pada a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, nibẹ le jẹ kan o ṣee iruju ipo ibi ti awọn pada iye ni a ė itọkasi.
    /// O ti le ri yi ipa ninu awọn apeere ni isalẹ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Bi pẹlu `peek()`, a le ri sinu awọn future lai imutesiwaju iterator.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Yoju sinu iterator ki o si ṣeto awọn iye sile awọn mutable itọkasi.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Awọn iye ti a fi ni farahàn bi awọn iterator tẹsiwaju.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Run ki o si pada nigbamii ti iye yi iterator ti o ba ti a majemu jẹ otitọ.
    /// Ti o ba ti `func` ba pada `true` fun nigbamii ti iye yi iterator, run ati ki o pada o.
    /// Tabi ki, pada `None`.
    /// # Examples
    /// Run a nọmba ti o ba ti o ni dogba si 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Ohun akọkọ ti aṣetunṣe jẹ 0;jẹ ẹ run.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Nigbamii ti ohun kan pada ni bayi 1, ki `consume` yoo pada `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` fi iye ti awọn nigbamii ti ohun kan ti o ba ti o je ko dogba si `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Run eyikeyi nọmba kere ju 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Je gbogbo awọn nọmba to kere ju 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Nigbamii ti iye pada ni yio je 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Niwon a npe ni `self.next()`, a run `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Run ki o si pada nigbamii ti ohun kan ti o ba jẹ dogba si `expected`.
    /// # Example
    /// Run a nọmba ti o ba ti o ni dogba si 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Ohun akọkọ ti aṣetunṣe jẹ 0;jẹ ẹ run.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Nigbamii ti ohun kan pada ni bayi 1, ki `consume` yoo pada `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` fi iye ti awọn nigbamii ti ohun kan ti o ba ti o je ko dogba si `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // Aabo: lewu iṣẹ firanšẹ siwaju si lewu iṣẹ pẹlu kanna ibeere
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}