use crate::ops::{ControlFlow, Try};

/// An iterator anfani lati ikore eroja lati mejeji pari.
///
/// Nkankan ti o ṣe `DoubleEndedIterator` ni agbara afikun ọkan lori nkan ti o ṣe [`Iterator`]: agbara lati tun gba `Awọn ohun kan lati ẹhin, ati iwaju.
///
///
/// O ti wa ni pataki lati akọsilẹ ti awọn mejeeji pada ati siwaju ise lori kanna ibiti o, ki o si se ko agbelebu: aṣetunṣe jẹ lori, nigbati nwọn pade ni aarin.
///
/// Ni a iru njagun si [`Iterator`] bèèrè, ni kete ti a `DoubleEndedIterator` pada [`None`] lati kan [`next_back()`], pipe o lẹẹkansi le tabi ko le lailai pada [`Some`] lẹẹkansi.
/// [`next()`] ati [`next_back()`] ni o wa interchangeable fun idi eyi.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Yọ awọn ati awọn padà ohun ano lati opin ti awọn iterator.
    ///
    /// Pada `None` nigba ti nibẹ ni o wa ko si siwaju sii eroja.
    ///
    /// The [trait-level] docs ni alaye diẹ.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Awọn eroja yielded nipa `DoubleEndedIterator` ká ọna le yato lati awọn àwọn yielded nipa [`Iterator`] 's ọna:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Mura awọn iterator lati pada nipa `n` eroja.
    ///
    /// `advance_back_by` ni awọn ọna version of [`advance_by`].Yi ọna ti yoo eagerly foju `n` eroja ti o bere lati pada nipa pipe [`next_back`] soke si `n` igba titi [`None`] ti wa ni konge.
    ///
    /// `advance_back_by(n)` yoo pada [`Ok(())`] ti o ba ti iterator ni ifijišẹ mura nipa `n` eroja, tabi [`Err(k)`] ti o ba ti [`None`] ti wa ni konge, ibi ti `k` ni awọn nọmba ti eroja awọn iterator ni to ti ni ilọsiwaju nipa ṣaaju ki o to nṣiṣẹ jade ti eroja (ie
    /// awọn ipari ti awọn iterator).
    /// Ṣe akiyesi pe `k` nigbagbogbo kere ju `n`.
    ///
    /// Pipe `advance_back_by(0)` ko jẹ eyikeyi awọn eroja ati nigbagbogbo pada [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // nikan `&3` ti a skipped
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Padà awọn `n`th ano lati opin ti awọn iterator.
    ///
    /// Eleyi jẹ pataki ni ifasilẹ awọn version of [`Iterator::nth()`].
    /// Botilẹjẹpe bii ọpọlọpọ awọn iṣẹ ṣiṣe itọka, kika naa bẹrẹ lati odo, nitorinaa `nth_back(0)` pada iye akọkọ lati opin, `nth_back(1)` keji, ati bẹbẹ lọ.
    ///
    ///
    /// Akiyesi pe gbogbo awọn eroja laarin awọn opin ati awọn pada ano yoo wa ni run, pẹlu awọn pada ano.
    /// Eleyi tun ọna ti pipe `nth_back(0)` ọpọ igba lori kanna iterator yoo pada o yatọ si eroja.
    ///
    /// `nth_back()` yoo pada [`None`] ti o ba ti `n` jẹ tobi ju tabi dogba si awọn ipari ti awọn iterator.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Pipe `nth_back()` ọpọ igba ko ni dapada sẹhin awọn iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Pada `None` ti o ba ti nibẹ ni o wa kere ju `n + 1` eroja:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Eleyi jẹ awọn ọna ti ikede [`Iterator::try_fold()`]: o gba eroja ti o bere lati pada ti awọn iterator.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Nitori ti o kukuru-circuited, awọn ti o ku eroja ni o si tun wa nipasẹ awọn iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator ọna ti o din kuro ni iterator ká eroja to kan nikan, ik iye, ti o bere lati pada.
    ///
    /// Eleyi jẹ awọn ọna ti ikede [`Iterator::fold()`]: o gba eroja ti o bere lati pada ti awọn iterator.
    ///
    /// `rfold()` gba awọn ariyanjiyan meji: iye ibẹrẹ, ati bíbo pẹlu awọn ariyanjiyan meji: 'accumulator' kan, ati eroja kan.
    /// Awọn bíbo pada ni iye ti awọn accumulator yẹ ki o ni fun awọn nigbamii ti aṣetunṣe.
    ///
    /// Awọn ni ibẹrẹ iye ni iye awọn accumulator yoo ni lori akọkọ ipe.
    ///
    /// Lẹhin ti a to yi bíbo si gbogbo ano ti awọn iterator, `rfold()` ba pada awọn accumulator.
    ///
    /// Iṣẹ yii nigbakan ni a pe ni 'reduce' tabi 'inject'.
    ///
    /// Agbo jẹ iwulo nigbakugba ti o ba ni ikojọpọ nkan kan, ti o fẹ ṣe agbejade iye kan lati inu rẹ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kaye gbogbo awọn ti awọn eroja ti a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Apẹẹrẹ yii kọ okun kan, bẹrẹ pẹlu iye akọkọ ati tẹsiwaju pẹlu eroja kọọkan lati ẹhin titi de iwaju:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Awọrọojulówo fun awọn ẹya ano ti ohun iterator lati pada ti o satisfies a predicate.
    ///
    /// `rfind()` gba a bíbo ti o pada `true` tabi `false`.
    /// O kan yi bíbo si kọọkan ano ti awọn iterator, ti o bere ni opin, ati ti o ba ti eyikeyi ninu wọn pada `true`, ki o si `rfind()` pada [`Some(element)`].
    /// Ti o ba ti gbogbo wọn pada `false`, o pada [`None`].
    ///
    /// `rfind()` ni kukuru-batiri ni;ninu awọn ọrọ miiran, o yoo da processing bi ni kete bi awọn bíbo pada `true`.
    ///
    /// Nitori `rfind()` gba a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, yi nyorisi si a ṣee iruju ipo ibi ti awọn ariyanjiyan ni a ė itọkasi.
    ///
    /// O ti le ri yi ipa ninu awọn apeere isalẹ, pẹlu `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Idekun ni akọkọ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}