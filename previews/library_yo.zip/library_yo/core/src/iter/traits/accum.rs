use crate::iter;
use crate::num::Wrapping;

/// Trait lati soju orisi ti o le wa da nipa summing soke ohun iterator.
///
/// Eleyi trait ti lo lati se awọn [`sum()`] ọna on iterators.
/// Orisi ti o se awọn trait le ti wa ni ti ipilẹṣẹ nipasẹ awọn [`sum()`] ọna.
/// Bi [`FromIterator`] yi trait yẹ ki o ṣọwọn wa ni a npe taara ati ki o dipo interacted pẹlu nipasẹ [`Iterator::sum()`].
///
///
/// [`sum()`]: Sum::sum
/// [`FromIterator`]: iter::FromIterator
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Sum<A = Self>: Sized {
    /// Ọna eyiti o gba ohun aṣetunṣe ati ipilẹṣẹ `Self` lati awọn eroja nipasẹ "summing up" awọn ohun kan.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn sum<I: Iterator<Item = A>>(iter: I) -> Self;
}

/// Trait lati ṣe aṣoju awọn oriṣi ti o le ṣẹda nipasẹ awọn eroja isodipupo ti aṣetunṣe.
///
/// Eleyi trait ti lo lati se awọn [`product()`] ọna on iterators.
/// Orisi ti o se awọn trait le ti wa ni ti ipilẹṣẹ nipasẹ awọn [`product()`] ọna.
/// Bi [`FromIterator`] yi trait yẹ ki o ṣọwọn wa ni a npe taara ati ki o dipo interacted pẹlu nipasẹ [`Iterator::product()`].
///
///
/// [`product()`]: Product::product
/// [`FromIterator`]: iter::FromIterator
///
#[stable(feature = "iter_arith_traits", since = "1.12.0")]
pub trait Product<A = Self>: Sized {
    /// Ọna eyi ti o gba ohun iterator ati gbogbo `Self` lati awọn eroja nipa isodipupo awọn ohun kan.
    ///
    #[stable(feature = "iter_arith_traits", since = "1.12.0")]
    fn product<I: Iterator<Item = A>>(iter: I) -> Self;
}

macro_rules! integer_sum_product {
    (@impls $zero:expr, $one:expr, #[$attr:meta], $($a:ty)*) => ($(
        #[$attr]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[$attr]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $zero,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[$attr]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    $one,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*);
    ($($a:ty)*) => (
        integer_sum_product!(@impls 0, 1,
                #[stable(feature = "iter_arith_traits", since = "1.12.0")],
                $($a)*);
        integer_sum_product!(@impls Wrapping(0), Wrapping(1),
                #[stable(feature = "wrapping_iter_arith", since = "1.14.0")],
                $(Wrapping<$a>)*);
    );
}

macro_rules! float_sum_product {
    ($($a:ident)*) => ($(
        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Sum for $a {
            fn sum<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl Product for $a {
            fn product<I: Iterator<Item=Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Sum<&'a $a> for $a {
            fn sum<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    0.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a + b,
                )
            }
        }

        #[stable(feature = "iter_arith_traits", since = "1.12.0")]
        impl<'a> Product<&'a $a> for $a {
            fn product<I: Iterator<Item=&'a Self>>(iter: I) -> Self {
                iter.fold(
                    1.0,
                    #[rustc_inherit_overflow_checks]
                    |a, b| a * b,
                )
            }
        }
    )*)
}

integer_sum_product! { i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize }
float_sum_product! { f32 f64 }

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Sum<Result<U, E>> for Result<T, E>
where
    T: Sum<U>,
{
    /// Gba kọọkan ano ni [`Iterator`]: ti o ba jẹ ẹya [`Err`], ko si si siwaju eroja ti wa ni ya, ati awọn [`Err`] ti wa ni pada.
    /// Yẹ ki o ko [`Err`] šẹlẹ, kaye gbogbo awọn eroja ti wa ni pada.
    ///
    /// # Examples
    ///
    /// Eyi ṣe akopọ gbogbo odidi odidi kan ninu vector, kọ kikoye ti o ba ni alabapade nkan odi:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<i32, &'static str> = v.iter().map(|&x: &i32|
    ///     if x < 0 { Err("Negative element found") }
    ///     else { Ok(x) }
    /// ).sum();
    /// assert_eq!(res, Ok(3));
    /// ```
    ///
    ///
    fn sum<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.sum())
    }
}

#[stable(feature = "iter_arith_traits_result", since = "1.16.0")]
impl<T, U, E> Product<Result<U, E>> for Result<T, E>
where
    T: Product<U>,
{
    /// Gba kọọkan ano ni [`Iterator`]: ti o ba jẹ ẹya [`Err`], ko si si siwaju eroja ti wa ni ya, ati awọn [`Err`] ti wa ni pada.
    /// Yẹ ki o ko [`Err`] šẹlẹ, awọn ọja ti gbogbo eroja ti wa ni pada.
    ///
    fn product<I>(iter: I) -> Result<T, E>
    where
        I: Iterator<Item = Result<U, E>>,
    {
        iter::process_results(iter, |i| i.product())
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Sum<Option<U>> for Option<T>
where
    T: Sum<U>,
{
    /// Gba kọọkan ano ni [`Iterator`]: ti o ba jẹ a [`None`], ko si si siwaju eroja ti wa ni ya, ati awọn [`None`] ti wa ni pada.
    /// Ti ko ba si [`None`] waye, apapọ gbogbo awọn eroja ti pada.
    ///
    /// # Examples
    ///
    /// Yi akopọ soke ni ipo ti awọn ohun kikọ silẹ 'a' ni a vector ti awọn gbolohun ọrọ, ti o ba a ọrọ ko ni kikọ 'a' ni isẹ pada `None`:
    ///
    ///
    /// ```
    /// let words = vec!["have", "a", "great", "day"];
    /// let total: Option<usize> = words.iter().map(|w| w.find('a')).sum();
    /// assert_eq!(total, Some(5));
    /// ```
    ///
    fn sum<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).sum::<Result<_, _>>().ok()
    }
}

#[stable(feature = "iter_arith_traits_option", since = "1.37.0")]
impl<T, U> Product<Option<U>> for Option<T>
where
    T: Product<U>,
{
    /// Gba kọọkan ano ni [`Iterator`]: ti o ba jẹ a [`None`], ko si si siwaju eroja ti wa ni ya, ati awọn [`None`] ti wa ni pada.
    /// Ko yẹ ki [`None`] waye, ọja ti gbogbo awọn eroja ti da pada.
    ///
    fn product<I>(iter: I) -> Option<T>
    where
        I: Iterator<Item = Option<U>>,
    {
        iter.map(|x| x.ok_or(())).product::<Result<_, _>>().ok()
    }
}