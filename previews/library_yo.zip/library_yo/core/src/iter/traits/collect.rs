/// Iyipada lati ẹya [`Iterator`].
///
/// Nipa imulo `FromIterator` fun a iru, ti o setumo bi o ti yoo wa ni da lati ẹya iterator.
/// Eyi jẹ wọpọ fun awọn iru eyiti o ṣe apejuwe akopọ iru kan.
///
/// [`FromIterator::from_iter()`] ti wa ni ipe ti a pe ni gbangba, ati pe o lo dipo ọna [`Iterator::collect()`].
///
/// Wo [`Iterator::collect()`]'s iwe fun diẹ apeere.
///
/// Wo eleyi na: [`IntoIterator`].
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Lilo [`Iterator::collect()`] to implicitly lo `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Ṣiṣe `FromIterator` fun iru rẹ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // A ayẹwo gbigba, o ni o kan a wrapper lori Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Jẹ ká fi fun o diẹ ninu awọn ọna ki a le ṣẹda kan ki o si fi ohun si o.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a o si ṣe LatiIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Bayi a le ṣe kan titun iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... ki o si ṣe MyCollection jade ti o
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // gba iṣẹ ju!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Ṣẹda a iye lati ẹya iterator.
    ///
    /// Wo [module-level documentation] fun diẹ sii.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Iyipada sinu [`Iterator`] kan.
///
/// Nipa ṣiṣe `IntoIterator` fun iru kan, o ṣalaye bi o ṣe le yipada si aṣetunṣe.
/// Eyi jẹ wọpọ fun awọn iru eyiti o ṣe apejuwe akopọ iru kan.
///
/// Ọkan anfaani ti imulo `IntoIterator` ni pe rẹ iru yio [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Wo eleyi na: [`FromIterator`].
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Imulo `IntoIterator` fun iru:
///
/// ```
/// // A ayẹwo gbigba, o ni o kan a wrapper lori Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Jẹ ká fi fun o diẹ ninu awọn ọna ki a le ṣẹda kan ki o si fi ohun si o.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ati pe a yoo ṣe IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Bayi a le ṣe ikojọpọ tuntun kan ...
/// let mut c = MyCollection::new();
///
/// // ... fi diẹ ninu awọn nkan na si o ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ati ki o si tan o sinu ohun Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// O ti wa ni wọpọ lati lo `IntoIterator` bi a trait bound.Eleyi gba awọn input gbigba iru to ayipada, ki gun bi o ti jẹ ṣi ohun iterator.
/// Awọn afikun awọn aala le ṣe pàtó nipasẹ ihamọ lori
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Awọn iru ti awọn eroja ni iterated lori.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Eyi ti o ni irú ti iterator ti wa ni a titan yi sinu?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Ṣẹda ohun iterator lati kan iye.
    ///
    /// Wo [module-level documentation] fun diẹ sii.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Fa a gbigba pẹlu awọn awọn akoonu ti ẹya iterator.
///
/// Iterators gbe awọn kan lẹsẹsẹ ti iye, ati collections le tun ti wa ni ro ti bi a jara ti iye.
/// The `Extend` trait afara yi o gboro, gbigba o lati fa a gbigba nipa pẹlu awọn awọn akoonu ti ti ti iterator.
/// Nigba ti extending a gbigba pẹlu ẹya tẹlẹ ti wa tẹlẹ bọtini, ti o titẹsi ti ni imudojuiwọn tabi, ninu ọran ti collections ti o laye ọpọ awọn titẹ sii pẹlu dogba awọn bọtini, ti titẹsi sii.
///
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// // O le fa a Okun pẹlu diẹ ninu awọn jo:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Imulo awon `Extend`:
///
/// ```
/// // A ayẹwo gbigba, o ni o kan a wrapper lori Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Jẹ ká fi fun o diẹ ninu awọn ọna ki a le ṣẹda kan ki o si fi ohun si o.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // niwon MyCollection ni o ni akojọ kan ti i32s, a se fa fun i32
/// impl Extend<i32> for MyCollection {
///
///     // Eleyi jẹ a bit rọrun pẹlu awọn nja iru Ibuwọlu: a le pe fa lori ohunkohun ti o le ti wa ni tan-sinu ohun Iterator eyi ti yoo fun wa i32s.
///     // Nitori a nilo awọn i32 lati fi sinu MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Awọn imuse jẹ gidigidi qna: lupu nipasẹ awọn iterator, ati add() kọọkan ano to ara wa.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // jẹ ki a faagun gbigba wa pẹlu awọn nọmba mẹta diẹ sii
/// c.extend(vec![1, 2, 3]);
///
/// // a ti ṣafikun awọn eroja wọnyi si opin
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Faagun a gbigba pẹlu awọn awọn akoonu ti ohun iterator.
    ///
    /// Bi yi ni awọn nikan beere ọna fun yi trait, awọn [trait-level] docs ni awọn alaye diẹ.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // O le fa a Okun pẹlu diẹ ninu awọn jo:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Faagun a gbigba pẹlu gangan ọkan ano.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Ni ẹtọ agbara ni a gbigba fun awọn ti fi fun nọmba ti afikun eroja.
    ///
    /// Imuse aiyipada ko ṣe nkankan.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}