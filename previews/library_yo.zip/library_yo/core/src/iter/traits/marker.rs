/// An iterator ti nigbagbogbo tẹsiwaju lati ikore `None` nigba ti re.
///
/// Pipe tókàn on a dapo iterator ti o ti pada `None` ni kete ti wa ni ẹri lati pada [`None`] lẹẹkansi.
/// Eleyi trait yẹ ki o wa muse nipa gbogbo iterators ti huwa ọna yi nitori ti o faye gba silẹ [`Iterator::fuse()`].
///
///
/// Note: Ni gbogbogbo, o yẹ ki o ko lo `FusedIterator` ni jeneriki igboro ti o ba nilo a dapo iterator.
/// Dipo, o yẹ ki o kan pe [`Iterator::fuse()`] lori iterator.
/// Ti o ba ti iterator ni tẹlẹ dapo, awọn afikun [`Fuse`] wrapper ni yio je kan ko si-op pẹlu ko si išẹ gbamabinu.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// An iterator ti Ijabọ ohun deede ipari lilo size_hint.
///
/// Awọn iterator Ijabọ a iwọn ofiri ibi ti o ti jẹ boya gangan (kekere dè jẹ dogba si oke owun), tabi oke dè ni [`None`].
///
/// Oke férémù gbọdọ nikan je [`None`] ti o ba ti gangan iterator ipari ni o tobi ju [`usize::MAX`].
/// Ni ọran yẹn, owun isalẹ gbọdọ jẹ [`usize::MAX`], ti o mu ki [`Iterator::size_hint()`] ti `(usize::MAX, None)` wa.
///
/// Awọn iterator gbọdọ gbe awọn gangan awọn nọmba ti eroja ti o royin tabi diverge ṣaaju ki o to nínàgà awọn opin.
///
/// # Safety
///
/// Eleyi trait gbọdọ nikan wa ni muse nigbati awọn guide ti wa ni ọwọ.
/// Awọn onibara ti yi trait gbọdọ ayewo [`Iterator::size_hint()`]’s oke dè.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// An iterator pe nigba ti nso ohun kan ti yoo ti ya ni o kere kan ano lati awọn oniwe-abele [`SourceIter`].
///
/// Pipe eyikeyi ọna ti mura awọn iterator, eg
/// [`next()`] tabi [`try_fold()`], onigbọwọ ti fun kọọkan igbese ni o kere ọkan iye ti awọn iterator ká amuye orisun ti a ti gbe jade ati awọn esi ti awọn iterator pq le wa ni fi sii ni awọn oniwe-ibi, a ro igbekale inira ti awọn orisun gba iru ohun sii.
///
/// Ninu awọn ọrọ miiran yi trait tọkasi wipe ohun iterator opo le wa ni gba ni ibi.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}