/// An iterator ti o mo awọn oniwe-gangan ipari.
///
/// Ọpọlọpọ awọn [`Iterator`] s ko mo bi ọpọlọpọ awọn igba ti won yoo iterate, ṣugbọn diẹ ṣe.
/// Ti aṣetunṣe kan ba mọ iye igba ti o le ṣe atunṣe, pese iraye si alaye yẹn le wulo.
/// Fun apẹẹrẹ, ti o ba ti o ba fẹ lati iterate arinsehin, kan ti o dara ibere ni lati mọ ibi ti awọn opin ni.
///
/// Nigba ti nse ohun `ExactSizeIterator`, o gbọdọ tun se [`Iterator`].
/// Nigbati ṣe bẹ, awọn imuse ti [`Iterator::size_hint`]*gbọdọ* pada awọn gangan iwọn ti awọn iterator.
///
/// Ọna [`len`] ni imuse aiyipada, nitorinaa o yẹ ki o ma ṣe imuse.
/// Sibẹsibẹ, o le ni anfani lati pese kan diẹ performant imuse ju awọn aiyipada, ki ifa o ninu apere yi mu ki ori.
///
///
/// Akiyesi pe trait yii jẹ trait ti o ni aabo ati pe bii kii ṣe *kii ṣe* ati * ko le ṣe idaniloju pe ipari gigun ti o tọ.
/// Yi ọna ti o `unsafe` koodu **kò gbọdọ** gbekele lori titunse ti [`Iterator::size_hint`].
/// Awọn riru ati lewu [`TrustedLen`](super::marker::TrustedLen) trait yoo yi afikun lopolopo.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// // a adópin ibiti mo gangan bi o ọpọlọpọ igba ti o yoo iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ninu [module-level docs], a ṣe agbekalẹ [`Iterator`] kan, `Counter`.
/// Jẹ ki ká se `ExactSizeIterator` fun o bi daradara:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // A le awọn iṣọrọ ṣe iṣiro awọn ti o ku nọmba ti iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ati bayi a le lo o!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Pada awọn gangan ipari ti awọn iterator.
    ///
    /// Awọn imuse idaniloju wipe iterator yoo pada gangan `len()` siwaju sii ni igba a [`Some(T)`] iye, ṣaaju ki o to pada [`None`].
    ///
    /// Yi ọna ti o ni awọn kan aiyipada imuse, ki o maa n ko yẹ ki o se o taara.
    /// Sugbon, bi o ti le pese kan siwaju sii daradara imuse, o le ṣe bẹ.
    /// Wo awọn [trait-level] docs fun ohun apẹẹrẹ.
    ///
    /// Iṣẹ yi ni o ni kanna aabo onigbọwọ bi awọn [`Iterator::size_hint`] iṣẹ.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // a adópin ibiti mo gangan bi o ọpọlọpọ igba ti o yoo iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Yi itenumo jẹ aṣeju igbeja, sugbon o sọwedowo awọn ko baramu
        // ẹri nipa awọn trait.
        // Ti o ba ti yi trait wà rust-ti abẹnu, a le lo debug_assert !;assert_eq!yoo ṣayẹwo gbogbo Rust olumulo awọn imuṣẹ ju.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Pada `true` ti aṣetunṣe ba ṣofo.
    ///
    /// Yi ọna ti o ni awọn kan aiyipada imuse lilo [`ExactSizeIterator::len()`], ki o ko ba nilo lati se ti o ara rẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}