// foju-tidy-filelength Yi faili fere ti iyasọtọ oriširiši awọn definition ti `Iterator`.
// A ko le pin ti o sinu ọpọ awọn faili.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Ohun ni wiwo fun awọn olugbagbọ pẹlu iterators.
///
/// Eleyi jẹ akọkọ iterator trait.
/// Fun diẹ sii nipa imọran ti awọn olutọtọ lapapọ, jọwọ wo [module-level documentation].
/// Ni pato, o le fẹ lati mọ bi o lati [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Awọn iru ti awọn eroja ni iterated lori.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Awọn ilọsiwaju ti aṣetunṣe ati pada iye atẹle.
    ///
    /// Pada [`None`] nigba ti aṣetunṣe wa ni ti pari.
    /// Awọn imuṣẹ iterator kọọkan le yan lati tun bẹrẹ aṣetunṣe, nitorinaa pipe `next()` lẹẹkansii le tabi ko le bẹrẹ pada pada [`Some(Item)`] lẹẹkansii ni aaye kan.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A ipe si next() pada nigbamii ti iye ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ati ki o si Kò ni kete ti o ni lori.
    /// assert_eq!(None, iter.next());
    ///
    /// // Die ipe le tabi ko le pada `None`.Nibi, nwọn si nigbagbogbo yoo.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Pada awọn aala lori ipari gigun ti aṣetunṣe.
    ///
    /// Pataki, `size_hint()` pada a tuple ibi ti awọn akọkọ ano ni isalẹ dè, ati awọn keji ano ni oke dè.
    ///
    /// Idaji keji ti awọn tuple o ti wa ni pada jẹ ẹya [`Option`] '<`[`usize`]'> '.
    /// A [`None`] nibi ọna ti o boya nibẹ ni ko si mọ oke dè, tabi oke dè jẹ o tobi ju [`usize`].
    ///
    /// # Awọn akọsilẹ imuse
    ///
    /// O ti wa ni ko nipa wipe ohun iterator imuse egbin awọn polongo nọmba ti eroja.A buggy iterator le so kere ju ni kekere owun tabi diẹ ẹ sii ju awọn oke ni owun ti eroja.
    ///
    /// `size_hint()` ti wa ni nipataki ti a ti pinnu lati wa ni lo fun optimizations bi reserving aaye fun awọn eroja ti awọn iterator, sugbon gbọdọ wa ko le gbẹkẹle to eg, fo kọja àla sọwedowo ni lewu koodu.
    /// Ohun ti ko tọ imuse ti `size_hint()` yẹ ki o ko ja si iranti ailewu lile.
    ///
    /// Ti o wi, awọn imuse yẹ ki o pese kan ti o tọ idiyelé rẹ, nitori bibẹkọ ti o yoo jẹ kan ti o ṣẹ ti awọn trait ká Ilana.
    ///
    /// Imuse aiyipada pada `(0,` [`Ko si ọkan]]` `` eyiti o tọ fun eyikeyi aṣetunṣe.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Apẹẹrẹ ti o nira sii:
    ///
    /// ```
    /// // Awọn ani awọn nọmba lati odo to mẹwa.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // A le ṣe itita lati odo si igba mẹwa.
    /// // Mọ pe o ká marun gangan yoo ko ni le ṣee ṣe lai pipa filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Jẹ ká fi marun siwaju sii awọn nọmba pẹlu chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // bayi mejeji igboro ti wa ni pọ nipa marun
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Pada `None` fun ohun oke ni owun:
    ///
    /// ```
    /// // ohun ailopin iterator ti ko si oke dè ati awọn ti o pọju ti ṣee ṣe kekere férémù
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Agbara awọn iterator, kika awọn nọmba ti iterations ati awọn pada o.
    ///
    /// Ọna yii yoo pe [`next`] leralera titi [`None`] yoo fi pade, da pada nọmba awọn igba ti o rii [`Some`].
    /// Akọsilẹ ti [`next`] ti to wa ni a npe ni o kere lẹẹkan paapa ti o ba iterator ko ni ni eyikeyi eroja.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # kún Ihuwasi
    ///
    /// Awọn ọna ti wo ni ko si ṣọ lodi si overflows, ki kika eroja ti ẹya iterator pẹlu diẹ ẹ sii ju [`usize::MAX`] eroja boya fun wa ti ko tọ si esi tabi panics.
    ///
    /// Ti o ba ti yokokoro assertions wa ni sise, a panic ni ẹri.
    ///
    /// # Panics
    ///
    /// Iṣẹ yi ipá panic ti o ba ti iterator ni ju [`usize::MAX`] eroja.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Agbara awọn iterator, pada awọn ti o kẹhin ano.
    ///
    /// Yi ọna ti yoo akojopo awọn iterator titi ti o ba pada [`None`].
    /// Lakoko ti o ṣe bẹ, o tọju abala eroja lọwọlọwọ.
    /// Lẹhin ti [`None`] ti wa ni pada, `last()` yoo ki o si pada awọn ti o kẹhin ano ti o ri.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Mura awọn iterator nipa `n` eroja.
    ///
    /// Yi ọna ti yoo eagerly foju `n` eroja nipa pipe [`next`] soke si `n` igba titi [`None`] ti wa ni konge.
    ///
    /// `advance_by(n)` yoo pada [`Ok(())`][Ok] ti o ba ti iterator ni ifijišẹ mura nipa `n` eroja, tabi [`Err(k)`][Err] ti o ba ti [`None`] ti wa ni konge, ibi ti `k` ni awọn nọmba ti eroja awọn iterator ni to ti ni ilọsiwaju nipa ṣaaju ki o to nṣiṣẹ jade ti eroja (ie
    /// awọn ipari ti awọn iterator).
    /// Ṣe akiyesi pe `k` nigbagbogbo kere ju `n`.
    ///
    /// Pipe `advance_by(0)` ko ni run eyikeyi eroja ati nigbagbogbo pada [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // nikan `&4` ti foo
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Padà awọn `n`th ano ti awọn iterator.
    ///
    /// Bi ọpọlọpọ awọn titọka mosi, awọn ti ka bẹrẹ lati odo, ki `nth(0)` pada akọkọ iye, `nth(1)` ekeji, ati bẹ lori.
    ///
    /// Akọsilẹ ti gbogbo opin eroja, bi daradara bi awọn pada ano, yoo wa ni run lati iterator.
    /// Ti o ọna ti awọn opin eroja yoo wa ni asonu, ati ki o tun awọn ti o pipe `nth(0)` ọpọ igba lori kanna iterator yoo pada o yatọ si eroja.
    ///
    ///
    /// `nth()` yoo pada [`None`] ti o ba ti `n` jẹ tobi ju tabi dogba si awọn ipari ti awọn iterator.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Pipe `nth()` ọpọ igba ko ni dapada sẹhin awọn iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Pada `None` ti o ba ti nibẹ ni o wa kere ju `n + 1` eroja:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Ṣẹda ohun iterator ti o bere ni kanna ojuami, ṣugbọn sokale nipasẹ awọn fun iye ni kọọkan aṣetunṣe.
    ///
    /// Akọsilẹ 1: Ni igba akọkọ ti ano ti awọn iterator yoo ma wa ni pada, lai ti awọn igbese fun.
    ///
    /// Akọsilẹ 2: Awọn akoko ni eyi ti bikita eroja ti wa ni fa ti ko ba wa titi.
    /// `StepBy` huwa bi awọn ọkọọkan `next(), nth(step-1), nth(step-1),…`, sugbon jẹ tun free lati huwa bi awọn ọkọọkan
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Ọna wo ni o le lo fun iyipada kan fun awọn idi iṣẹ.
    /// Awọn keji ọna ti yoo advance awọn iterator sẹyìn ati ki o le run siwaju sii awọn ohun kan.
    ///
    /// `advance_n_and_return_first` ni ni deede ti:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Awọn ọna ti yoo panic ti o ba ti fi fun igbese ni `0`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Gba meji iterators ati ki o ṣẹda titun kan iterator lori mejeeji ni ọkọọkan.
    ///
    /// `chain()` yoo pada titun kan iterator eyi ti yoo akọkọ iterate lori iye lati akọkọ iterator ati ki o si lori iye lati keji iterator.
    ///
    /// Ni gbolohun miran, ti o ojúewé meji iterators jọ, ni a pq.🔗
    ///
    /// [`once`] ti wa ni lilo nigbagbogbo lati ṣe deede iye kan sinu pq ti awọn iru aṣetọju miiran.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Niwon awọn ariyanjiyan to `chain()` nlo [`IntoIterator`], a le ṣe ohunkohun ti o le ti wa ni iyipada sinu ohun [`Iterator`], ko o kan an [`Iterator`] ara.
    /// Fun apẹẹrẹ, awọn ege (`&[T]`) se [`IntoIterator`], ati ki o le wa ni koja to `chain()` taara:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ti o ba ṣiṣẹ pẹlu Windows API, o le fẹ lati yipada [`OsStr`] si `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips soke' meji iterators sinu kan nikan iterator ti orisii.
    ///
    /// `zip()` padà a titun iterator ti yoo iterate lori meji miiran iterators, pada a tuple ibi ti awọn akọkọ ano ba wa ni lati akọkọ iterator, ati awọn keji ano ba wa ni lati keji iterator.
    ///
    ///
    /// Ni gbolohun miran, o zips meji iterators jọ, sinu kan nikan kan.
    ///
    /// Ti boya aṣetunṣe ba pada [`None`], [`next`] lati ọdọ olufun ti a firanṣẹ yoo pada [`None`] pada.
    /// Ti o ba ti akọkọ iterator pada [`None`], `zip` yoo kuru iyika o si `next` yoo ko wa ni a npe lori keji iterator.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Niwon awọn ariyanjiyan to `zip()` nlo [`IntoIterator`], a le ṣe ohunkohun ti o le ti wa ni iyipada sinu ohun [`Iterator`], ko o kan an [`Iterator`] ara.
    /// Fun apẹẹrẹ, awọn ege (`&[T]`) se [`IntoIterator`], ati ki o le wa ni koja to `zip()` taara:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ti wa ni igba lo lati ZIP ohun ailopin iterator to a adópin kan.
    /// Eleyi ṣiṣẹ nitori awọn adópin iterator yoo bajẹ pada [`None`], opin awọn idalẹnu.Zipping pẹlu `(0..)` le wo a pupo bi [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Ṣẹda titun kan iterator eyi ti ibiti a daakọ ti `separator` laarin awọn ẹgbẹ awọn ohun ti awọn atilẹba iterator.
    ///
    /// Ni irú `separator` ko ni se [`Clone`] tabi aini lati wa ni se isiro ni gbogbo igba ti, lo [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Akọkọ ano lati `a`.
    /// assert_eq!(a.next(), Some(&100)); // The separator.
    /// assert_eq!(a.next(), Some(&1));   // Nigbamii ti ano lati `a`.
    /// assert_eq!(a.next(), Some(&100)); // The separator.
    /// assert_eq!(a.next(), Some(&2));   // Awọn ti o kẹhin ano lati `a`.
    /// assert_eq!(a.next(), None);       // Awọn iterator jẹ ti pari.
    /// ```
    ///
    /// `intersperse` le jẹ gidigidi wulo lati da ohun iterator ká ohun nipa lilo a wọpọ ano:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Ṣẹda titun kan iterator eyi ti ibiti ohun kan ti ipilẹṣẹ nipa `separator` laarin awọn ẹgbẹ awọn ohun ti awọn atilẹba iterator.
    ///
    /// Awọn bíbo yoo wa ni a npe ni gangan ni kete ti kọọkan akoko ohun kan ti wa ni gbe laarin awọn meji nitosi awọn ohun kan lati awọn abele iterator;
    /// pataki, awọn bíbo ni a npe ni ti o ba ti amuye iterator Egbin ni kere ju meji awọn ohun kan ati lẹhin ti o kẹhin ohun kan ti wa ni yielded.
    ///
    ///
    /// Ti o ba ti iterator ká ohun kan ọlọnà [`Clone`], o le jẹ rọrun lati lo [`intersperse`].
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Ni igba akọkọ ti ano lati `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Nigbamii ti ano lati `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // The separator.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Awọn ti o kẹhin ano lati lati `v`.
    /// assert_eq!(it.next(), None);               // Awọn iterator jẹ ti pari.
    /// ```
    ///
    /// `intersperse_with` le ṣee lo ni awọn ipo ibiti o nilo ki ipinya ṣe iṣiro:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Awọn bíbo mutably borrows awọn oniwe-o tọ lati se ina ohun kan.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Gba a bíbo ati ki o ṣẹda ohun iterator eyi ti awọn ipe ti o bíbo lori kọọkan ano.
    ///
    /// `map()` iyipada kan iterator sinu miiran, nipa ọna ti awọn oniwe-ariyanjiyan:
    /// nkan ti o n se [`FnMut`].O fun wa titun kan iterator eyi ti awọn ipe yi bíbo lori kọọkan ano ti awọn atilẹba iterator.
    ///
    /// Ti o ba ti o ba wa ni o dara ni lerongba ni orisi, o le ro ti `map()` bi yi:
    /// Ti o ba ti o ba ni ohun iterator ti yoo fun o eroja ti diẹ ninu awọn iru `A`, ati awọn ti o fẹ ohun iterator ti diẹ ninu awọn miiran Iru `B`, o le lo `map()`, ran a bíbo ti o gba ohun `A` ati ki o pada a `B`.
    ///
    ///
    /// `map()` ni conceptually iru si a [`for`] lupu.Sibẹsibẹ, bi `map()` ni ọlẹ, o ti wa ni ti o dara ju lo nigba ti o ba tẹlẹ ṣiṣẹ pẹlu awọn miiran iterators.
    /// Ti o ba ti o ba ṣe diẹ ninu awọn too ti looping fun a ẹgbẹ ipa, ti o ti n ka diẹ idiomatic lati lo [`for`] ju `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ti o ba ti o ba ṣe diẹ ninu awọn too ti ẹgbẹ ipa, fẹ [`for`] to `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ma ṣe ṣe yi:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // o yoo ko paapaa ṣiṣẹ, bi o ti jẹ ọlẹ.Rust yoo kilo o nipa yi.
    ///
    /// // Dipo, lo fun:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Awọn ipe a bíbo lori kọọkan ano ti ohun iterator.
    ///
    /// Eyi jẹ deede si lilo lupu [`for`] lori aṣetunṣe, botilẹjẹpe `break` ati `continue` ko ṣee ṣe lati pipade kan.
    /// O ni gbogbo siwaju sii idiomatic lati lo kan `for` lupu, ṣugbọn `for_each` le jẹ diẹ legible nigbati processing awọn ohun ni opin ti gun iterator dè.
    ///
    /// Ni awọn ọrọ miiran `for_each` tun le yara ju lupu kan, nitori yoo lo aṣetunṣe inu lori awọn alamuuṣẹ bi `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Fun iru kekere kan apẹẹrẹ, a `for` lupu le jẹ regede, ṣugbọn `for_each` le jẹ preferable lati tọju kan ti iṣẹ ara pẹlu gun iterators:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Ṣẹda ohun iterator eyi ti o nlo a bíbo lati mọ ti o ba ti ohun ano yẹ ki o wa yielded.
    ///
    /// Fi fun ohun ano awọn bíbo gbọdọ pada `true` tabi `false`.Olutọju ti o pada yoo fun awọn eroja nikan fun eyiti pipade ba pada di otitọ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nitori awọn bíbo koja to `filter()` gba a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, yi nyorisi si a ṣee iruju ipo, ibi ti awọn iru ti awọn bíbo ni a ė itọkasi:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // nilo meji * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// O ká wọpọ to dipo lo destructuring lori ariyanjiyan to bọ kuro ọkan:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // mejeeji&ati ki o *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// tabi awọn mejeeji:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // meji &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ti awọn fẹlẹfẹlẹ wọnyi.
    ///
    /// Ṣe akiyesi pe `iter.filter(f).next()` jẹ deede si `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Ṣẹda ohun iterator pe mejeji Ajọ ati awọn maapu.
    ///
    /// Awọn pada iterator egbin nikan ni `value`s fun eyi ti awọn pese bíbo pada `Some(value)`.
    ///
    /// `filter_map` le ti wa ni lo lati ṣe ẹwọn [`filter`] ati [`map`] diẹ ni ßoki.
    /// Awọn apẹẹrẹ ni isalẹ fihan bi a `map().filter().map()` le ti wa ni kuru to kan nikan ipe to `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eyi ni kanna apẹẹrẹ, ṣugbọn pẹlu [`filter`] ati [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Ṣẹda ohun iterator eyi ti yoo fun awọn ti isiyi aṣetunṣe ka bi daradara bi awọn nigbamii ti iye.
    ///
    /// Awọn iterator pada Egbin ni orisii `(i, val)`, ibi ti `i` ni isiyi Ìwé ti aṣetunṣe ati `val` ni iye pada nipa awọn iterator.
    ///
    ///
    /// `enumerate()` ntọju awọn oniwe-ka bi a [`usize`].
    /// Ti o ba ti o ba fẹ lati ka nipa kan ti o yatọ won odidi, awọn [`zip`] iṣẹ pese iru iṣẹ.
    ///
    /// # kún Ihuwasi
    ///
    /// Awọn ọna ti wo ni ko si ṣọ lodi si overflows, ki enumerating diẹ ẹ sii ju [`usize::MAX`] eroja boya fun wa ti ko tọ si esi tabi panics.
    /// Ti o ba ti yokokoro assertions wa ni sise, a panic ni ẹri.
    ///
    /// # Panics
    ///
    /// Awọn pada iterator le panic ti o ba ti to-o wa ni-pada Ìwé yoo bò a [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Ṣẹda ohun iterator eyi ti o le lo [`peek`] to wo ni nigbamii ti ano ti awọn iterator lai gba o.
    ///
    /// Ṣe afikun ọna [`peek`] kan si aṣetunṣe.Ri awọn oniwe iwe fun alaye siwaju sii.
    ///
    /// Akiyesi pe onitumọ itosi tun ti ni ilọsiwaju nigbati a pe [`peek`] fun igba akọkọ: Lati le gba nkan ti o tẹle, a pe [`next`] lori aṣetunṣe ti o wa labẹ rẹ, nitorinaa eyikeyi awọn ipa ẹgbẹ (ie
    ///
    /// ohunkohun miiran ju adijọ nigbamii ti iye) ti [`next`] ọna ti yoo waye.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() jẹ ki a wò sinu future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // a le peek() ọpọ igba, awọn iterator kò advance
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // lẹhin ti awọn iterator wa ni ti pari, ki ni peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Ṣẹda ohun iterator ti [`skip`] s eroja da lori a predicate.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` gba a bíbo bi ohun ariyanjiyan.O yoo pe yi bíbo lori kọọkan ano ti awọn iterator, ati ki o foju eroja titi ti o ba pada `false`.
    ///
    /// Lẹhin ti `false` ti wa ni pada, `skip_while()`'s job jẹ lori, ati awọn iyokù ti awọn eroja ti wa ni yielded.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nitori awọn bíbo koja to `skip_while()` gba a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, yi nyorisi si a ṣee iruju ipo, ibi ti awọn iru ti awọn bíbo ariyanjiyan ni a ė itọkasi:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // nilo meji * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idekun lẹhin ti ohun ni ibẹrẹ `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // nigba ti yi yoo ti eke, niwon a tẹlẹ ni a eke, skip_while() ti wa ni ko lo eyikeyi diẹ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ṣẹda ohun iterator ti Egbin ni eroja da lori a predicate.
    ///
    /// `take_while()` gba a bíbo bi ohun ariyanjiyan.O yoo pe yi bíbo lori kọọkan ano ti awọn iterator, ati ikore eroja nigba ti o ba pada `true`.
    ///
    /// Lẹhin ti `false` ti wa ni pada, `take_while()`'s job jẹ lori, ati awọn iyokù ti awọn eroja ti wa ni bikita.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nitori pipade ti o kọja si `take_while()` gba itọkasi kan, ati pe ọpọlọpọ awọn olupilẹṣẹ itita lori awọn itọkasi, eyi yori si ipo airoju ti o ṣee ṣe, nibiti iru pipade naa jẹ itọkasi meji:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // nilo meji * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idekun lẹhin ti ohun ni ibẹrẹ `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // A ni diẹ eroja ti o wa ni din ju odo, sugbon niwon a tẹlẹ ni a eke, take_while() ti wa ni ko lo eyikeyi diẹ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nitori `take_while()` nilo lati wo ni iye ninu ibere lati ri ti o ba ti o yẹ ki o wa to tabi ko, gba iterators yoo ri pe o ti wa ni kuro:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `3` ko si ohun to nibẹ, nitori ti o ti run ni ibere lati ri ti o ba ti aṣetunṣe yẹ ki o da, sugbon a ko gbe pada sinu iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Ṣẹda ohun iterator pe mejeji Egbin ni eroja da lori a predicate ati awọn maapu.
    ///
    /// `map_while()` mu bíbo bi ariyanjiyan.
    /// O yoo pe yi bíbo lori kọọkan ano ti awọn iterator, ati ikore eroja nigba ti o ba pada [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Eyi ni kanna apẹẹrẹ, ṣugbọn pẹlu [`take_while`] ati [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Idekun lẹhin ti ohun ni ibẹrẹ [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // A ni diẹ eroja eyi ti o le ipele ti ni u32 (4, 5), sugbon `map_while` pada `None` fun `-3` (bi awọn `predicate` pada `None`) ati `collect` ma duro ni akọkọ `None` konge.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Nitori `map_while()` nilo lati wo ni iye ninu ibere lati ri ti o ba ti o yẹ ki o wa to tabi ko, gba iterators yoo ri pe o ti wa ni kuro:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `-3` ko si ohun to nibẹ, nitori ti o ti run ni ibere lati ri ti o ba ti aṣetunṣe yẹ ki o da, sugbon a ko gbe pada sinu iterator.
    ///
    /// Akọsilẹ ti ko [`take_while`] yi iterator ni **ko** dapo.
    /// O ti wa ni tun ko pato ohun ti yi iterator padà lẹhin akọkọ [`None`] ti wa ni pada.
    /// Ti o ba nilo dapo iterator, lo [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Ṣẹda ohun iterator ti skips akọkọ `n` eroja.
    ///
    /// Lẹhin ti nwọn ti a ti run, awọn iyokù ti awọn eroja ti wa ni yielded.
    /// Dipo ki o bori ọna yii taara, dipo yiyọ ọna `nth`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Ṣẹda ohun iterator ti o egbin awọn oniwe-akọkọ `n` eroja.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ti wa ni igba lo pẹlu ohun ailopin iterator, lati ṣe awọn ti o han:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ti o ba ti kere ju `n` eroja wa o si wa, `take` yoo se idinwo ara si awọn iwọn ti awọn amuye iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// An iterator ohun ti nmu badọgba iru si [`fold`] ti o Oun ni ti abẹnu ipinle ati fun titun kan iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` gba meji ariyanjiyan: ohun ni ibẹrẹ iye ti awọn irugbin awọn ti abẹnu ipinle, ati ki o kan bíbo pẹlu meji ariyanjiyan, akọkọ jije a mutable tọka si awọn ti abẹnu ipinle ati awọn keji ohun iterator ano.
    ///
    /// Awọn bíbo le fi to awọn ti abẹnu ipinle to pin ipinle laarin iterations.
    ///
    /// Lori aṣetunṣe, awọn bíbo yoo loo si kọọkan ano ti awọn iterator ati awọn pada iye lati bíbo, ohun [`Option`], ti wa ni yielded nipasẹ awọn iterator.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // kọọkan aṣetunṣe, a yoo isodipupo ipinle nipasẹ awọn ano
    ///     *state = *state * x;
    ///
    ///     // ki o si, a yoo so awọn isododi ti ipinle
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Ṣẹda ohun iterator ti o ṣiṣẹ bi map, ṣugbọn flattens iteeye be.
    ///
    /// The [`map`] ohun ti nmu badọgba jẹ gidigidi wulo, sugbon nikan nigbati awọn bíbo ariyanjiyan fun wa iye.
    /// Ti o ba ti o fun wa ohun iterator dipo, nibẹ ni ohun afikun Layer ti indirection.
    /// `flat_map()` yoo yọ yi afikun Layer lori awọn oniwe-ara.
    ///
    /// O le ro ti `flat_map(f)` bi awọn atunmọ deede ti [`map`] Pingi, ati ki o [`flatten`] jorinmọrin bi ni `map(f).flatten()`.
    ///
    /// Ọna miiran ti ironu nipa `flat_map()`: Bíbo `[maapu]] da ohun kan pada fun eroja kọọkan, ati pe `flat_map()`'s pipade pada oluṣe kan fun eroja kọọkan.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pada ohun iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ṣẹda ohun iterator ti flattens iteeye be.
    ///
    /// Eleyi jẹ wulo nigba ti o ba ni ohun iterator ti iterators tabi iterator ti ohun ti o le wa ni tan-sinu iterators ati awọn ti o fẹ lati yọ ọkan ipele ti indirection.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Aworan agbaye ati ki o si pẹrẹsẹ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pada ohun iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// O tun le tun kọ eyi ni awọn ofin ti [`flat_map()`], eyiti o dara julọ ninu ọran yii nitori pe o ṣafihan ero diẹ sii ni kedere:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pada ohun iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening nikan yọ ipele kan ti itẹ-ẹiyẹ ni akoko kan:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Nibi ti a ba ri pe `flatten()` ko ni ṣe kan "deep" flatten.
    /// Dipo, ipele kan ti itẹ-ẹiyẹ nikan ni a yọ kuro.Ti o ni, ti o ba `flatten()` a onisẹpo mẹta orun, ni esi yio je meji-onisẹpo ati ki o ko ọkan-onisẹpo.
    /// Lati gba a ọkan-onisẹpo be, o ni lati `flatten()` lẹẹkansi.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Ṣẹda ohun iterator eyi ti o dopin lẹhin ti akọkọ [`None`].
    ///
    /// Lẹhin aṣetunṣe kan pada [`None`], awọn ipe future le tabi ko le fun [`Some(T)`] lẹẹkansii.
    /// `fuse()` adapts ohun iterator, aridaju pe lẹhin a [`None`] ti ni a fun, o yoo ma pada [`None`] lailai.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // ohun iterator eyi ti alternates laarin Diẹ ninu awọn ati Kò
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ti o ba jẹ paapaa, Some(i32), miiran Ko si
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // a le rii oluṣe wa ti n lọ siwaju ati siwaju
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // sibẹsibẹ, ni kete ti a fiusi o ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // o yoo ma pada `None` lẹhin igba akọkọ.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Se nkankan pẹlu kọọkan ano ti ohun iterator, ran awọn iye lori.
    ///
    /// Nigbati o ba nlo awọn onigbọwọ, iwọ yoo nigbagbogbo pq ọpọlọpọ awọn ti wọn papọ.
    /// Lakoko ti o n ṣiṣẹ lori iru koodu, o le fẹ lati ṣayẹwo ohun ti n ṣẹlẹ ni awọn oriṣiriṣi awọn ẹya ninu opo gigun ti epo.Lati ṣe eyi, fi sii ipe si `inspect()`.
    ///
    /// O wọpọ julọ fun `inspect()` lati ṣee lo bi ohun elo n ṣatunṣe aṣiṣe ju lati wa ninu koodu ipari rẹ, ṣugbọn awọn ohun elo le rii pe o wulo ni awọn ipo kan nigbati awọn aṣiṣe nilo lati buwolu wọle ṣaaju ki o to danu.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // yi iterator ọkọọkan jẹ eka.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // jẹ ki a ṣafikun diẹ ninu awọn ipe inspect() lati ṣe iwadii ohun ti n ṣẹlẹ
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Eleyi yoo sita:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Wíwọlé aṣiṣe ṣaaju ki o to discarding wọn:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Eleyi yoo sita:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Borrows ohun iterator, dipo ju gba o.
    ///
    /// Eleyi jẹ wulo lati gba a to iterator alamuuṣẹ nigba ti ṣi idaduro nini ti awọn atilẹba iterator.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ti o ba ti a gbiyanju lati lo ipa lẹẹkansi, o yoo ko sise.
    /// // Awọn wọnyi ila yoo fun "aṣiṣe: lilo ti gbe iye: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // jẹ ki ká gbiyanju ti o lẹẹkansi
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // dipo, a fi ni a .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // bayi eyi dara:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Yipada aṣetunṣe sinu gbigba kan.
    ///
    /// `collect()` le mu ohunkohun dani, ki o yi i pada si ikojọpọ ti o baamu.
    /// Eyi jẹ ọkan ninu awọn ọna ti o lagbara diẹ sii ni ile-ikawe boṣewa, ti a lo ni ọpọlọpọ awọn àrà.
    ///
    /// Julọ ipilẹ Àpẹẹrẹ ninu eyi ti `collect()` o ti lo ni lati tan ọkan gbigba sinu miiran.
    /// O gba ikojọpọ kan, pe [`iter`] lori rẹ, ṣe akojọpọ awọn iyipada, ati lẹhinna `collect()` ni ipari.
    ///
    /// `collect()` tun le ṣẹda instances ti orisi ti wa ni ko aṣoju collections.
    /// Fun apẹẹrẹ, a [`String`] le ti wa ni itumọ ti lati [`char`] s, ati awọn ẹya iterator ti [`Result<T, E>`][`Result`] awọn ohun le wa ni gba sinu `Result<Collection<T>, E>`.
    ///
    /// Wo awọn apeere ni isalẹ fun diẹ ẹ sii.
    ///
    /// Nitori `collect()` jẹ ki gbogbogbo, o le fa awọn iṣoro pẹlu iru mu ero jade.
    /// Bi iru, `collect()` jẹ ọkan ninu awọn diẹ igba ti o yoo ri awọn sintasi affectionately mọ bi awọn 'turbofish': `::<>`.
    /// Eyi iranlọwọ fun awọn mu ero jade alugoridimu ni oye pataki ti o gbigba ti o ba gbiyanju lati gba sinu.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Akọsilẹ ti a nilo ni `: Vec<i32>` lori osi-ọwọ ẹgbẹ.Eleyi jẹ nitori a le gba sinu, fun apẹẹrẹ, a [`VecDeque<T>`] dipo:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Lilo awọn 'turbofish' dipo ti annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Nitori `collect()` nikan ni abojuto nipa ohun ti o n kojọpọ sinu, o tun le lo itọkasi iru apakan, `_`, pẹlu turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Lilo `collect()` lati ṣe kan [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ti o ba ni akojọ kan ti [`abajade<T, E>`][`Result`] s, o le lo `collect()` lati ri ti o ba ti eyikeyi ninu wọn ti kuna:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // yoo fun wa ni akọkọ ni aṣiṣe
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // yoo fun wa awọn akojọ ti awọn idahun
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Agbara ohun iterator, ṣiṣẹda meji collections lati o.
    ///
    /// Asọtẹlẹ ti o kọja si `partition()` le pada `true`, tabi `false`.
    /// `partition()` da bata pada, gbogbo awọn eroja ti o da `true` pada fun, ati gbogbo awọn eroja ti o da `false` pada fun.
    ///
    ///
    /// Wo tun [`is_partitioned()`] ati [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Reorders awọn eroja ti yi iterator *ni-ibi* gẹgẹ bi awọn ti fi fun predicate, iru awọn ti gbogbo awọn ti pada `true` ßaaju gbogbo awọn ti pada `false`.
    ///
    /// Padà awọn nọmba ti `true` eroja ri.
    ///
    /// Awọn ojulumo ibere ti partitioned ohun ti ko ba muduro.
    ///
    /// Wo tun [`is_partitioned()`] ati [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Ipin ni-ibi laarin awọn evens ati awọn aidọgba
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: o yẹ ki a dààmú nipa awọn ka ikún?Nikan ni ona lati ni diẹ ẹ sii ju
        // `usize::MAX` mutable jo ni pẹlu ZSTs, eyi ti o wa ni ko wulo to ipin ...

        // Awọn wọnyi bíbo "factory" awọn iṣẹ tẹlẹ lati yago fun genericity ni `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Leralera ri akọkọ `false` ki o si siwopu o pẹlu awọn ti o kẹhin `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Sọwedowo ti o ba ti awọn eroja ti yi iterator ti wa ni partitioned gẹgẹ bi awọn ti fi fun predicate, iru awọn ti gbogbo awọn ti pada `true` ßaaju gbogbo awọn ti pada `false`.
    ///
    ///
    /// Wo tun [`partition()`] ati [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Boya gbogbo awọn ohun kan dán `true`, tabi akọkọ funwon duro ni `false` ati awọn ti a ṣayẹwo ti wa ni o wa ti ko si siwaju sii `true` awọn ohun lẹhin ti.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// An iterator ọna ti o kan iṣẹ kan bi gun bi o pada ni ifijišẹ, producing a nikan, ik iye.
    ///
    /// `try_fold()` gba awọn ariyanjiyan meji: iye ibẹrẹ, ati bíbo pẹlu awọn ariyanjiyan meji: 'accumulator' kan, ati eroja kan.
    /// Iboju naa boya pada ni aṣeyọri, pẹlu iye ti akopọ yẹ ki o ni fun aṣetunṣe atẹle, tabi o pada ikuna, pẹlu iye aṣiṣe ti o tan kaakiri olupe lẹsẹkẹsẹ (short-circuiting).
    ///
    ///
    /// Awọn ni ibẹrẹ iye ni iye awọn accumulator yoo ni lori akọkọ ipe.Ti lilo kọlọfin ba ṣaṣeyọri si gbogbo nkan ti aṣetunṣe, `try_fold()` pada ikojọpọ ikẹhin bi aṣeyọri.
    ///
    /// Agbo jẹ iwulo nigbakugba ti o ba ni ikojọpọ nkan kan, ti o fẹ ṣe agbejade iye kan lati inu rẹ.
    ///
    /// # Akiyesi si Awọn Oluṣe
    ///
    /// Orisirisi awọn ti awọn miiran (forward) ọna ni aiyipada awọn imuṣẹ ni awọn ofin ti yi ọkan, ki gbiyanju lati se yi kedere ti o ba ti o le se nkan ti o dara ju awọn aiyipada `for` lupu imuse.
    ///
    /// Ni pato, gbiyanju lati ni yi ipe `try_fold()` lori awọn ti abẹnu awọn ẹya ara lati eyi ti yi iterator wa ni kq.
    /// Ti o ba ti ọpọ awọn ipe wa ni ti nilo, awọn `?` oniṣẹ le jẹ rọrun fun chaining awọn accumulator iye pẹlú, ṣugbọn kiyesara eyikeyi invariants ti nilo lati wa ni ọwọ ṣaaju ki o to awon tete padà.
    /// Eleyi jẹ a `&mut self` ọna, ki aṣetunṣe nilo lati wa ni resumable lẹhin ti kọlu ohun ašiše nibi.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // apao ti a ṣayẹwo ti gbogbo awọn eroja ti orun naa
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Iwọn yii pọ ju nigbati o nfi nkan 100 kun
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Nitori ti o kukuru-circuited, awọn ti o ku eroja ni o si tun wa nipasẹ awọn iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// An iterator ọna ti o kan a fallible iṣẹ lati kọọkan ohun kan ninu awọn iterator, idekun ni akọkọ ni aṣiṣe ati ki o pada ti o aṣiṣe.
    ///
    ///
    /// Eyi tun le ronu bi fọọmu isubu ti [`for_each()`] tabi bi ẹya alailowaya ti [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // O kukuru-circuited, ki awọn ti o ku awọn ohun ni o wa si tun ni awọn iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Agbo gbogbo ano sinu ohun accumulator nipa a to ohun isẹ, pada ik esi.
    ///
    /// `fold()` gba awọn ariyanjiyan meji: iye ibẹrẹ, ati bíbo pẹlu awọn ariyanjiyan meji: 'accumulator' kan, ati eroja kan.
    /// Awọn bíbo pada ni iye ti awọn accumulator yẹ ki o ni fun awọn nigbamii ti aṣetunṣe.
    ///
    /// Awọn ni ibẹrẹ iye ni iye awọn accumulator yoo ni lori akọkọ ipe.
    ///
    /// Lẹhin ti o lo ifilọlẹ yii si gbogbo nkan ti aṣetunṣe, `fold()` pada ikojọpọ pada.
    ///
    /// Iṣẹ yii nigbakan ni a pe ni 'reduce' tabi 'inject'.
    ///
    /// Agbo jẹ iwulo nigbakugba ti o ba ni ikojọpọ nkan kan, ti o fẹ ṣe agbejade iye kan lati inu rẹ.
    ///
    /// Note: `fold()`, ati iru awọn ọna ti o traverse gbogbo iterator, le ko fopin fun ailopin iterators, ani on traits fun eyi ti a abajade jẹ determinable ni adópin akoko.
    ///
    /// Note: [`reduce()`] a le lo lati lo akọkọ ano bi awọn ni ibẹrẹ iye, ti o ba ti accumulator iru ati ohun type jẹ kanna.
    ///
    /// # Akiyesi si Awọn Oluṣe
    ///
    /// Orisirisi awọn ti awọn miiran (forward) ọna ni aiyipada awọn imuṣẹ ni awọn ofin ti yi ọkan, ki gbiyanju lati se yi kedere ti o ba ti o le se nkan ti o dara ju awọn aiyipada `for` lupu imuse.
    ///
    ///
    /// Ni pato, gbiyanju lati ni yi ipe `fold()` lori awọn ti abẹnu awọn ẹya ara lati eyi ti yi iterator wa ni kq.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kaye gbogbo awọn ti awọn eroja ti awọn orun
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Jẹ ká rin nipasẹ kọọkan igbese ti awọn aṣetunṣe nibi:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ki o si bẹ, wa ase esi, `6`.
    ///
    /// O ká wọpọ fun awon eniyan ti o ti ni ko lo iterators a pupo lati lo kan `for` lupu pẹlu kan akojọ ti awọn ohun lati kọ soke kan esi.Awọn wọnyi le yipada si `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // fun lupu:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // nwọn ba kanna
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Din awọn eroja to kan nikan ọkan, nipa leralera to a atehinwa isẹ.
    ///
    /// Ti aṣetunṣe ba ṣofo, pada [`None`];bibẹkọ ti, ba pada awọn esi ti awọn idinku.
    ///
    /// Fun iterators pẹlu ni o kere kan ano, yi jẹ kanna bi [`fold()`] pẹlu awọn akọkọ ano ti awọn iterator bi awọn ni ibẹrẹ iye, kika gbogbo ọwọ ano sinu o.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Wa awọn ti o pọju iye:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Igbeyewo ti o ba ti gbogbo ano ti awọn iterator ibaamu a predicate.
    ///
    /// `all()` gba pipade ti o pada `true` tabi `false`.O kan yi bíbo si kọọkan ano ti awọn iterator, ati ti o ba ti gbogbo wọn pada `true`, ki o si ki wo `all()`.
    /// Ti o ba ti eyikeyi ninu wọn o pada `false`, o pada `false`.
    ///
    /// `all()` jẹ iyika kukuru;ni awọn ọrọ miiran, yoo da iṣẹ ṣiṣe duro ni kete ti o rii `false` kan, ni fifun pe bii ohunkohun miiran ti o ṣẹlẹ, abajade yoo tun jẹ `false`.
    ///
    ///
    /// Ohun ṣofo iterator pada `true`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Idekun ni akọkọ `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Igbeyewo ba ti eyikeyi ano ti awọn iterator ibaamu a predicate.
    ///
    /// `any()` gba pipade ti o pada `true` tabi `false`.O kan ifilọlẹ yii si eroja kọọkan ti aṣetunṣe, ati pe ti eyikeyi ninu wọn ba pada `true`, lẹhinna `any()` tun ṣe.
    /// Ti gbogbo wọn ba pada `false`, o pada `false` pada.
    ///
    /// `any()` jẹ iyika kukuru;ninu awọn ọrọ miiran, o yoo da processing bi ni kete bi o ti ri a `true`, fun wipe ko si ohun ti miran ṣẹlẹ, awọn esi yio tun je `true`.
    ///
    ///
    /// Ohun ṣofo iterator pada `false`.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Idekun ni akọkọ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Awọrọojulówo fun awọn ẹya ano ti ohun iterator ti satisfies a predicate.
    ///
    /// `find()` gba a bíbo ti o pada `true` tabi `false`.
    /// O kan yi bíbo si kọọkan ano ti awọn iterator, ati ti o ba ti eyikeyi ninu wọn pada `true`, ki o si `find()` pada [`Some(element)`].
    /// Ti o ba ti gbogbo wọn pada `false`, o pada [`None`].
    ///
    /// `find()` ni kukuru-batiri ni;ninu awọn ọrọ miiran, o yoo da processing bi ni kete bi awọn bíbo pada `true`.
    ///
    /// Nitori `find()` gba a itọkasi, ati ọpọlọpọ awọn iterators iterate lori jo, yi nyorisi si a ṣee iruju ipo ibi ti awọn ariyanjiyan ni a ė itọkasi.
    ///
    /// O ti le ri yi ipa ninu awọn apeere isalẹ, pẹlu `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Idekun ni akọkọ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Akiyesi pe `iter.find(f)` ni deede lati `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Ṣiṣẹ iṣẹ si awọn eroja ti aṣetunṣe ati dapada abajade akọkọ ti kii ṣe ẹnikan.
    ///
    ///
    /// `iter.find_map(f)` ni deede lati `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Kan iṣẹ si awọn eroja ti iterator ati ki o pada si awọn akọkọ otito esi tabi awọn akọkọ ni aṣiṣe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Awọrọojulówo fun ohun ano ni ohun iterator, pada awọn oniwe-Ìwé.
    ///
    /// `position()` gba a bíbo ti o pada `true` tabi `false`.
    /// O kan yi bíbo si kọọkan ano ti awọn iterator, ati ti o ba ti ọkan ninu wọn ba pada `true`, ki o si `position()` pada [`Some(index)`].
    /// Ti o ba ti gbogbo awọn ti wọn pada `false`, o pada [`None`].
    ///
    /// `position()` ni kukuru-batiri ni;ninu awọn ọrọ miiran, o yoo da processing bi ni kete bi o ti ri a `true`.
    ///
    /// # kún Ihuwasi
    ///
    /// Awọn ọna ti wo ni ko si ṣọ lodi si overflows, ki o ba wa ni o wa siwaju sii ju [`usize::MAX`] ti kii-tuntun eroja, o boya fun wa ti ko tọ si esi tabi panics.
    ///
    /// Ti o ba ti yokokoro assertions wa ni sise, a panic ni ẹri.
    ///
    /// # Panics
    ///
    /// Iṣẹ yi ṣile panic ti o ba ti iterator ni ju `usize::MAX` ti kii-tuntun eroja.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Idekun ni akọkọ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Awọn pada Ìwé da lori iterator ipinle
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Awọrọojulówo fun ohun ano ni ohun iterator lati ọtun, pada awọn oniwe-Ìwé.
    ///
    /// `rposition()` gba a bíbo ti o pada `true` tabi `false`.
    /// O kan yi bíbo si kọọkan ano ti awọn iterator, ti o bere lati opin, ati ti o ba ti ọkan ninu wọn ba pada `true`, ki o si `rposition()` pada [`Some(index)`].
    ///
    /// Ti o ba ti gbogbo awọn ti wọn pada `false`, o pada [`None`].
    ///
    /// `rposition()` ni kukuru-batiri ni;ninu awọn ọrọ miiran, o yoo da processing bi ni kete bi o ti ri a `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Idekun ni akọkọ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // a tun le lo `iter`, nitori awọn eroja diẹ sii wa.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Ko si iwulo fun ṣayẹwo apọju nibi, nitori `ExactSizeIterator` tumọ si pe nọmba awọn eroja baamu sinu `usize` kan.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Pada ni o pọju ano ti ohun iterator.
    ///
    /// Ti o ba ti orisirisi awọn eroja ni o wa se o pọju, awọn ti o kẹhin ano ti wa ni pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Pada kere ano ti ohun iterator.
    ///
    /// Ti awọn eroja pupọ ba kere ju, a ti da ano akọkọ pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Padà ni ano ti yoo fun awọn ti o pọju iye lati pàtó kan iṣẹ.
    ///
    ///
    /// Ti o ba ti orisirisi awọn eroja ni o wa se o pọju, awọn ti o kẹhin ano ti wa ni pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Pada ano ti o fun ni iye ti o pọ julọ pẹlu ọwọ si iṣẹ afiwera ti a ṣalaye.
    ///
    ///
    /// Ti o ba ti orisirisi awọn eroja ni o wa se o pọju, awọn ti o kẹhin ano ti wa ni pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Pada ano ti o fun ni iye ti o kere julọ lati iṣẹ ti a ṣalaye.
    ///
    ///
    /// Ti awọn eroja pupọ ba kere ju, a ti da ano akọkọ pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Padà ni ano ti yoo fun awọn kere iye pẹlu ọwọ si awọn pàtó lafiwe iṣẹ.
    ///
    ///
    /// Ti awọn eroja pupọ ba kere ju, a ti da ano akọkọ pada.
    /// Ti o ba ti iterator jẹ sofo, [`None`] ti wa ni pada.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Reverses ohun iterator ká itọsọna.
    ///
    /// Nigbagbogbo, awọn olutọtọ n lọ lati apa osi si otun.
    /// Lẹhin lilo `rev()`, ohun iterator yio dipo iterate lati ọtun si osi.
    ///
    /// Eleyi jẹ ṣee ṣe nikan ti o ba ti iterator ni o ni ohun opin, ki `rev()` nikan ṣiṣẹ lori [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Awọn ohun iterator ti orisii sinu kan bata ti awọn apoti.
    ///
    /// `unzip()` agbara ohun gbogbo iterator ti orisii, producing meji collections: ọkan lati osi eroja ti awọn orisii, ati ọkan lati ọtun eroja.
    ///
    ///
    /// Iṣẹ yi ni, ni diẹ ninu awọn ori, ni idakeji ti [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Ṣẹda ohun iterator eyi ti idaako gbogbo awọn ti awọn oniwe-eroja.
    ///
    /// Eleyi jẹ wulo nigba ti o ba ni ohun iterator lori `&T`, ṣugbọn o nilo ohun iterator lori `T`.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // dakọ jẹ kanna bi .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Ṣẹda ohun iterator eyi ti [`clone`] s gbogbo awọn ti awọn oniwe-eroja.
    ///
    /// Eleyi jẹ wulo nigba ti o ba ni ohun iterator lori `&T`, ṣugbọn o nilo ohun iterator lori `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned jẹ kanna bi .map(|&x| x), fun odidi
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ntun ohun iterator endlessly.
    ///
    /// Dipo diduro ni [`None`], aṣetunṣe yoo dipo bẹrẹ lẹẹkansi, lati ibẹrẹ.Lẹhin ti iterating lẹẹkansi, o yoo bẹrẹ ni ibẹrẹ lẹẹkansi.Ati lẹẹkansi.
    /// Ati lẹẹkansi.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Akopọ awọn eroja ti ẹya iterator.
    ///
    /// Gba eroja kọọkan, ṣe afikun wọn papọ, o si da abajade pada.
    ///
    /// Ohun ṣofo iterator pada awọn odo iye ti awọn iru.
    ///
    /// # Panics
    ///
    /// Nigba ti pipe `sum()` ati ki o kan atijo odidi iru ti wa ni a pada, yi ọna ti yoo panic ti o ba ti iṣiro overflows ati yokokoro assertions ti wa ni sise.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates lori gbogbo iterator, isodipupo gbogbo awọn eroja
    ///
    /// Ohun aṣetunṣe ofo pada iye ọkan ti iru.
    ///
    /// # Panics
    ///
    /// Nigbati o ba n pe `product()` ati iru nomba odidi atijo kan ti n dapada, ọna yoo jẹ panic ti iṣiro ba kun ati awọn ifọkasi aṣiṣe aṣiṣe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ṣe afiwe awọn eroja ti [`Iterator`] yii pẹlu awọn miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ṣe afiwe awọn eroja ti [`Iterator`] yii pẹlu awọn ti omiiran pẹlu ọwọ si iṣẹ lafiwe pàtó.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ṣe afiwe awọn eroja ti [`Iterator`] yii pẹlu awọn miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ṣe afiwe awọn eroja ti [`Iterator`] yii pẹlu awọn ti omiiran pẹlu ọwọ si iṣẹ lafiwe pàtó.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa dogba si awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa dogba si awon ti awọn miran pẹlu ọwọ si awọn pàtó Equality iṣẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa unequal si awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa [lexicographically](Ord#lexicographical-comparison) kere ju awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa [lexicographically](Ord#lexicographical-comparison) kere tabi dogba si awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa [lexicographically](Ord#lexicographical-comparison) ti o tobi ju awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Ipinnu ti o ba awọn eroja ti yi [`Iterator`] ni o wa [lexicographically](Ord#lexicographical-comparison) tobi ju tabi dogba si awon ti miiran.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Sọwedowo ti o ba ti awọn eroja ti yi iterator ti wa ni lẹsẹsẹ.
    ///
    /// Iyẹn ni pe, fun eroja kọọkan `a` ati eroja atẹle rẹ `b`, `a <= b` gbọdọ mu.Ti o ba ti iterator egbin gangan odo tabi ọkan ano, `true` ti wa ni pada.
    ///
    /// Akọsilẹ wipe ti o ba `Self::Item` jẹ nikan `PartialOrd`, sugbon ko `Ord`, awọn loke definition tumo si pe yi iṣẹ padà `false` o ba ti eyikeyi meji itẹlera ohun ni o wa ko afiwera.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Awọn sọwedowo ti awọn eroja ti aṣetọju yii ba ti to lẹsẹsẹ nipa lilo iṣẹ afiwewe ti a fun.
    ///
    /// Dipo ti lilo `PartialOrd::partial_cmp`, iṣẹ yi nlo awọn ti fi fun `compare` iṣẹ lati mọ awọn bere fun ti awọn meji eroja.
    /// Yato si lati pe, o ni deede to [`is_sorted`];wo iwe rẹ fun alaye diẹ sii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Sọwedowo ti o ba ti awọn eroja ti yi iterator ti wa ni lẹsẹsẹ ni lilo awọn ti fi fun bọtini isediwon iṣẹ.
    ///
    /// Dipo ti wé awọn iterator ká eroja taara, iṣẹ yi safiwe awọn bọtini ti awọn eroja, bi ṣiṣe nipasẹ `f`.
    /// Yato si lati pe, o ni deede to [`is_sorted`];wo iwe rẹ fun alaye diẹ sii.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Wo [TrustedRandomAccess]
    // Awọn dani orukọ jẹ lati yago fun orukọ collisions ni ọna ti o ga ri #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}