//! impl shaha {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Aami koodu to ga julọ ti `char` le ni.
    ///
    /// A `char` ni a [Unicode Scalar Value], eyi ti ọna ti o jẹ a [Code Point], sugbon nikan eyi laarin kan ibiti o.
    /// `MAX` jẹ aami koodu to ga julọ ti o jẹ [Unicode Scalar Value] to wulo.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` A lo () ni Unicode lati ṣe aṣoju aṣiṣe aṣiṣe.
    ///
    /// O le waye, fun apẹẹrẹ, nigba fifunni awọn baiti UTF-8 ti ko dara si [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Ẹya ti [Unicode](http://www.unicode.org/) pe awọn ẹya Unicode ti awọn ọna `char` ati `str` da lori.
    ///
    /// Awọn ẹya tuntun ti Unicode ni a tu ni igbagbogbo ati lẹhinna gbogbo awọn ọna ninu ile-ikawe boṣewa ti o da lori Unicode ti wa ni imudojuiwọn.
    /// Nitorinaa ihuwasi ti diẹ ninu awọn ọna `char` ati `str` ati iye ti awọn ayipada igbagbogbo yii lori akoko.
    /// Eleyi jẹ *ko* ka lati wa ni a bibu ayipada.
    ///
    /// Eto nọmba nọmba ti wa ni alaye ni [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Ṣẹda ohun iterator lori awọn UTF-16 ti yipada koodu ojuami ninu `iter`, pada unpaired surrogates bi `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// A o le gba decoder adanu kan nipasẹ rirọpo awọn esi `Err` pẹlu iwa rirọpo:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Awọn iyipada `u32` kan si `char` kan.
    ///
    /// Akiyesi pe gbogbo awọn `char`s wulo`[`u32`] s, ati pe o le sọ si ọkan pẹlu
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sibẹsibẹ, yiyipada kii ṣe otitọ: kii ṣe gbogbo ẹtọ [`u32`] s ni o wulo`char`s.
    /// `from_u32()` yoo pada `None` ti o ba ti input ni ko kan wulo iye fun a `char`.
    ///
    /// Fun ẹya ti ko ni aabo ti iṣẹ yii eyiti o kọ awọn sọwedowo wọnyi, wo [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Pada si `None` nigbati igbewọle ko jẹ `char` to wulo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Awọn a `u32` to a `char`, iko Wiwulo.
    ///
    /// Akiyesi pe gbogbo awọn `char`s wulo`[`u32`] s, ati pe o le sọ si ọkan pẹlu
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sibẹsibẹ, yiyipada kii ṣe otitọ: kii ṣe gbogbo ẹtọ [`u32`] s ni o wulo`char`s.
    /// `from_u32_unchecked()` yoo foju yi, ati fi afọju sọ si `char`, o ṣee ṣe ṣiṣẹda ọkan ti ko wulo.
    ///
    ///
    /// # Safety
    ///
    /// Iṣẹ yi jẹ lewu, bi o ti le òrùka invalid `char` iye.
    ///
    /// Fun ẹya ailewu ti iṣẹ yii, wo iṣẹ [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // Aabo: A gbọdọ ṣe adehun adehun aabo nipasẹ olupe naa.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Awọn a nomba ni fun root to a `char`.
    ///
    /// 'radix' kan nibi ni a tun pe ni 'base'.
    /// A root ti meji tọkasi a alakomeji nọmba, a root mẹwa, eleemewa, ati root of mẹrindilogun, hexadecimal, lati fun diẹ ninu awọn wọpọ síi.
    ///
    /// Lainidii radices wa ni atilẹyin.
    ///
    /// `from_digit()` yoo pada `None` ti o ba ti input ni ko kan nomba ni fun root.
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti fi fun a root tobi ju 36.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Eleemewa 11 jẹ kan nikan nọmba ni mimọ 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Pada si `None` nigbati igbewọle kii ṣe nọmba kan:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ran kan ti o tobi root, nfa a panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Sọwedowo ti o ba ti a `char` ni a nomba ni fun root.
    ///
    /// 'radix' kan nibi ni a tun pe ni 'base'.
    /// A root ti meji tọkasi a alakomeji nọmba, a root mẹwa, eleemewa, ati root of mẹrindilogun, hexadecimal, lati fun diẹ ninu awọn wọpọ síi.
    ///
    /// Lainidii radices wa ni atilẹyin.
    ///
    /// Akawe si [`is_numeric()`], yi iṣẹ nikan mọ awọn ohun kikọ `0-9`, `a-z` ati `A-Z`.
    ///
    /// 'Digit' ti wa ni telẹ lati wa ni nikan awọn wọnyi ohun kikọ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Fun kan diẹ okeerẹ oye ti 'digit', wo [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti fi fun a root tobi ju 36.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ran kan ti o tobi root, nfa a panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Awọn a `char` to a nomba ni fun root.
    ///
    /// 'radix' kan nibi ni a tun pe ni 'base'.
    /// A root ti meji tọkasi a alakomeji nọmba, a root mẹwa, eleemewa, ati root of mẹrindilogun, hexadecimal, lati fun diẹ ninu awọn wọpọ síi.
    ///
    /// Lainidii radices wa ni atilẹyin.
    ///
    /// 'Digit' ti wa ni telẹ lati wa ni nikan awọn wọnyi ohun kikọ:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Pada `None` ti `char` ko ba tọka si nọmba kan ninu radix ti a fun.
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti fi fun a root tobi ju 36.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ran a ti kii-nọmba esi ni ikuna:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ran kan ti o tobi root, nfa a panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // koodu naa pin si ibi lati mu iyara ipaniyan ṣiṣẹ fun awọn ọran nibiti `radix` jẹ ibakan ati 10 tabi kere si
        //
        let val = if likely(radix <= 10) {
            // Ti kii ba ṣe nọmba kan, nọmba ti o tobi ju radix yoo ṣẹda.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Padà ohun iterator ti o egbin awọn hexadecimal Unicode ona abayo kan ti a ti ohun kikọ silẹ bi `char`s.
    ///
    /// Eyi yoo sa fun awọn kikọ pẹlu sintasi Rust ti fọọmu `\u{NNNNNN}` nibiti `NNNNNN` jẹ aṣoju oniduro hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // tabi-jorinmọrin 1 idaniloju wipe fun c==0 awọn koodu computes ti ọkan nọmba yẹ ki o wa ni tejede ati (ti o jẹ kanna) avoids awọn (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // atọka ti nọmba hex pataki julọ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Ohun o gbooro sii version of `escape_debug` ti o optionally o fayegba escaping Afikun Grapheme codepoints.
    /// Eyi n gba wa laaye lati ṣe agbekalẹ awọn ohun kikọ bi awọn ami aiṣododo dara julọ nigbati wọn ba wa ni ibẹrẹ okun kan.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Pada aṣetunṣe kan ti o mu koodu abayọ gangan ti ohun kikọ silẹ bi `char`s.
    ///
    /// Eyi yoo sa fun awọn ohun kikọ ti o jọra si awọn imuṣẹ `Debug` ti `str` tabi `char`.
    ///
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Pada aṣetunṣe kan ti o mu koodu abayọ gangan ti ohun kikọ silẹ bi `char`s.
    ///
    /// Awọn aiyipada ni yàn pẹlu kan irẹjẹ si producing literals ti o wa ni ofin ni orisirisi kan ti ede, pẹlu C++ 11 ati iru C-ebi ede.
    /// Awọn gangan ofin ni o wa:
    ///
    /// * Tab ti salọ bi `\t`.
    /// * Ipadabọ gbigbe ti salọ bi `\r`.
    /// * Line kikọ sii ti wa ni sá bi `\n`.
    /// * Ẹyọ ẹyọ kan sa asala bi `\'`.
    /// * Double quote ti wa ni sa bi `\"`.
    /// * Backslash ti salọ bi `\\`.
    /// * Eyikeyi ti ohun kikọ silẹ ni 'tẹjade ASCII' ibiti o `0x20` .. `0x7e` jumo ti ko ba sá asalà.
    /// * Gbogbo awọn ohun kikọ miiran ni a fun ni awọn igbala Unicode hexadecimal;ri [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Pada nọmba awọn baiti yii `char` yoo nilo ti o ba yipada ni UTF-8.
    ///
    /// Ti nọmba ti awọn baiti jẹ nigbagbogbo laarin 1 ati 4, jumo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Iru `&str` ṣe onigbọwọ pe awọn akoonu rẹ jẹ UTF-8, ati nitorinaa a le ṣe afiwe ipari ti yoo gba ti aaye koodu kọọkan ba ni aṣoju bi `char` la ni `&str` funrararẹ:
    ///
    ///
    /// ```
    /// // bi jo
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // mejeeji le ṣe aṣoju bi awọn baiti mẹta
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // bi &str kan, awọn meji wọnyi ni koodu inu ni UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // a le ri pe ti won gba mefa baiti lapapọ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... gẹgẹ bi &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Pada awọn nọmba ti 16-bit koodu sipo yi `char` yoo nilo ti o ba ti ti yipada ni UTF-16.
    ///
    ///
    /// Wo iwe fun [`len_utf8()`] fun alaye diẹ sii ti imọran yii.
    /// Iṣẹ yii jẹ digi kan, ṣugbọn fun UTF-16 dipo UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ṣe koodu ohun kikọ yii bi UTF-8 sinu ifipamọ baiti ti a pese, ati lẹhinna da atunyẹwo ti ifipamọ ti o ni ohun kikọ koodu iwọle pada.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti ifipamọ ko ba tobi to.
    /// Aṣayan ti ipari mẹrin jẹ tobi to lati fi koodu eyikeyi `char` sii.
    ///
    /// # Examples
    ///
    /// Ninu awọn apẹẹrẹ mejeeji wọnyi, 'ß' gba awọn baiti meji lati fi koodu sii.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A saarin ti o ni ju kekere:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // Aabo: `char` kii ṣe aropo, nitorinaa eyi wulo UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ṣe koodu ohun kikọ yii bi UTF-16 sinu ifipamọ `u16` ti a pese, ati lẹhinna da atunyẹwo ti ifipamọ ti o ni ohun kikọ koodu iwọle sii.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti ifipamọ ko ba tobi to.
    /// Aṣayan ti ipari 2 tobi to lati fi koodu eyikeyi `char` sii.
    ///
    /// # Examples
    ///
    /// Ninu awọn apeere wọnyi, '𝕊' gba meji `u16` lati ṣe koodu.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// A saarin ti o ni ju kekere:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Pada `true` ti `char` yii ba ni ohun-ini `Alphabetic`.
    ///
    /// `Alphabetic` ti ṣe apejuwe ni Abala 4 (Awọn ohun-ini ohun kikọ) ti [Unicode Standard] ati pe o ṣe apejuwe ninu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ifẹ ni ọpọlọpọ awọn nkan, ṣugbọn kii ṣe abidi
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Padà `true` o ba ti yi `char` ni o ni awọn `Lowercase` ohun ini.
    ///
    /// `Lowercase` ti ṣe apejuwe ni Abala 4 (Awọn ohun-ini ohun kikọ) ti [Unicode Standard] ati pe o ṣe apejuwe ninu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Awọn orisirisi Chinese iwe afọwọkọ ati aami ifamisi ko ni irú, ki o si bẹ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Padà `true` o ba ti yi `char` ni o ni awọn `Uppercase` ohun ini.
    ///
    /// `Uppercase` ti ṣe apejuwe ni Abala 4 (Awọn ohun-ini ohun kikọ) ti [Unicode Standard] ati pe o ṣe apejuwe ninu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Awọn orisirisi Chinese iwe afọwọkọ ati aami ifamisi ko ni irú, ki o si bẹ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Pada `true` ti `char` yii ba ni ohun-ini `White_Space`.
    ///
    /// `White_Space` ti wa ni pato ninu [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // aaye ti kii ṣe fifọ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Pada `true` ti `char` yii ba ni itẹlọrun boya [`is_alphabetic()`] tabi [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Padà `true` o ba ti yi `char` ni o ni gbogbo ẹka fun Iṣakoso koodu.
    ///
    /// Awọn koodu iṣakoso (awọn aaye koodu pẹlu ẹka gbogbogbo ti `Cc`) ni a ṣapejuwe ni Abala 4 (Awọn ohun-ini Awọn ohun kikọ) ti [Unicode Standard] ati pe a sọ ni [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // U + 009C, okun TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Pada `true` ti `char` yii ba ni ohun-ini `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ti ṣe apejuwe ninu [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ati pe o ṣe apejuwe ninu [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Pada `true` ti `char` yii ba ni ọkan ninu awọn ẹka gbogbogbo fun awọn nọmba.
    ///
    /// Awọn ẹka gbogbogbo fun awọn nọmba (`Nd` fun awọn nomba eleemewa, `Nl` fun awọn ohun kikọ nọmba bi lẹta, ati `No` fun awọn ohun kikọ nọmba miiran) ni a ṣe apejuwe ninu [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Pada aṣetunṣe kan ti o mu maapu kekere ti `char` yii bi ọkan tabi diẹ sii
    /// `char`s.
    ///
    /// Ti `char` yii ko ba ni aworan agbaye kekere, aṣetunṣe n mu `char` kanna wa.
    ///
    /// Ti `char` yii ba ni maapu kekere kekere kan-si-ọkan ti a fun nipasẹ [Unicode Character Database][ucd] [`UnicodeData.txt`], aṣetunṣe n fun ni `char` naa.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ti o ba ti yi `char` nilo pataki ti riro (eg ọpọ 'char`s) awọn iterator egbin awọn`char` (s) fun nipasẹ [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Iṣiṣẹ yii n ṣe aworan agbaye ti ko ni idiyele laisi tailoring.Ti o ni, awọn iyipada ni ominira ti o tọ ati ede.
    ///
    /// Ninu [Unicode Standard], Abala 4 (Awọn ohun-ini Awọn ohun kikọ) jiroro lori aworan agbaye ni apapọ ati Abala 3 (Conformance) jiroro algorithm aiyipada fun iyipada ọran.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Nigbakan abajade jẹ ẹya diẹ sii ju ọkan lọ:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ohun kikọ ti ko ni awọn mejeeji uppercase ati lowercase lọkan padà sí ara wọn.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Padà ohun iterator ti o egbin awọn uppercase aworan agbaye ti yi `char` bi ọkan tabi diẹ ẹ sii
    /// `char`s.
    ///
    /// Ti `char` yii ko ba ni aworan agbaye ti oke, aṣetunṣe n mu `char` kanna wa.
    ///
    /// Ti o ba ti yi `char` ni a ọkan-to-ọkan uppercase aworan fun nipasẹ awọn [Unicode Character Database][ucd] [`UnicodeData.txt`], awọn iterator Egbin ni ti `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Ti o ba ti yi `char` nilo pataki ti riro (eg ọpọ 'char`s) awọn iterator egbin awọn`char` (s) fun nipasẹ [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Iṣiṣẹ yii n ṣe aworan agbaye ti ko ni idiyele laisi tailoring.Ti o ni, awọn iyipada ni ominira ti o tọ ati ede.
    ///
    /// Ninu [Unicode Standard], Abala 4 (Awọn ohun-ini Awọn ohun kikọ) jiroro lori aworan agbaye ni apapọ ati Abala 3 (Conformance) jiroro algorithm aiyipada fun iyipada ọran.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Nigbakan abajade jẹ ẹya diẹ sii ju ọkan lọ:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ohun kikọ ti ko ni awọn mejeeji uppercase ati lowercase lọkan padà sí ara wọn.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Akọsilẹ on aṣàmúlò
    ///
    /// Ni Tọki, deede ti 'i' ni Latin ni awọn fọọmu marun dipo meji:
    ///
    /// * 'Dotless': Emi/ı, nigbakan kọ ï
    /// * 'Dotted': İ/i
    ///
    /// Akiyesi pe awọn lowercase ti sami 'i' jẹ kanna bi awọn Latin.Nitorina:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Iye ti `upper_i` nibi gbekele lori awọn ede ti awọn ọrọ sii: ti o ba ti a ba ni `en-US`, o yẹ ki o wa `"I"`, ṣugbọn ti o ba ti a ba ni `tr_TR`, o yẹ ki o wa `"İ"`.
    /// `to_uppercase()` ko ya yi sinu iroyin, ati ki:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// Oun ni kọja ede.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Awọn ayẹwo ti iye ba wa laarin ibiti ASCII wa.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Ṣe ẹda ti iye ni deede ASCII ọran nla rẹ.
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati ṣe agbepo iye ni ipo, lo [`make_ascii_uppercase()`].
    ///
    /// To uppercase ASCII ohun kikọ ni afikun si ti kii-ASCII ohun kikọ, lo [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ṣe ẹda ti iye ni deede ASCII ọran kekere rẹ.
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati kekere iye ni ipo, lo [`make_ascii_lowercase()`].
    ///
    /// To lowercase ASCII ohun kikọ ni afikun si ti kii-ASCII ohun kikọ, lo [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Awọn iṣayẹwo pe awọn iye meji jẹ ibaamu-ailoju-ọran ọran ASCII.
    ///
    /// Ni ibamu si `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Yi iru yii pada si ASCII ọran ọran oke rẹ ni ipo.
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati da iye tuntun ti oke pada laisi iyipada eyi ti o wa, lo [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Awọn yi iru si awọn oniwe-ASCII kekere deede ni-ibi.
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati pada titun kan lowercased iye lai iyipada awọn ti wa tẹlẹ ọkan, lo [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Awọn iṣayẹwo ti iye naa jẹ ohun kikọ labidi ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', tabi
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Awọn ayẹwo ti iye naa jẹ ohun kikọ ASCII ti o tobi ju:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Awọn iṣayẹwo boya iye jẹ ẹya kekere ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Awọn iṣayẹwo ti iye ba jẹ ihuwasi alphanumeric ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', tabi
    /// - U + 0061 'a' ..=U + 007A 'z', tabi
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Sọwedowo ti o ba ti iye jẹ ẹya ASCII eleemewa nọmba:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Sọwedowo ti o ba ti iye jẹ ẹya ASCII hexadecimal nọmba:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', tabi
    /// - U + 0041 'A' ..=U + 0046 'F', tabi
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Awọn iṣayẹwo ti iye naa jẹ ohun kikọ silẹ kikọ ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, tabi
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, tabi
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, tabi
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Awọn iṣayẹwo ti iye naa jẹ ohun kikọ ayaworan ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Awọn iṣayẹwo ti iye naa jẹ ohun kikọ aaye funfun funfun ASCII:
    /// U + 0020 aaye, U + 0009 petele taabu, U + 000A LINE FEED, U + 000C kq FEED, tabi U + 000D gbigbe PADA.
    ///
    /// Rust nlo XWX Infra Standard ti WhatWG.Nibẹ ni o wa ọpọlọpọ awọn miiran itumo ni jakejado lilo.
    /// Fun apeere, [the POSIX locale][pct] pẹlu U + 000B VERTICAL TAB ati gbogbo awọn ohun kikọ ti o wa loke, ṣugbọn - lati alaye kanna kanna-[ofin aiyipada fun "field splitting" ni Bourne shell][bfs] ṣe akiyesi *nikan* aaye, HORIZONTAL TAB, ati ILA ILA bi aye funfun.
    ///
    ///
    /// Ti o ba ti wa ni kikọ a eto ti yoo ilana tẹlẹ faili kika, ṣayẹwo ohun ti kika ká definition ti whitespace ni ṣaaju ki o to lilo yi iṣẹ.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Awọn iṣayẹwo ti iye naa jẹ ohun kikọ iṣakoso ASCII:
    /// U + 0000 NUL ..=U + 001F kuro separator, tabi U + 007F pa.
    /// Akọsilẹ wipe ọpọlọpọ awọn ASCII whitespace kikọ ni o wa Iṣakoso ohun kikọ, ṣugbọn aaye jẹ ko.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ṣe koodu iye u32 aise kan bi UTF-8 sinu ifipamọ baiti ti a pese, ati lẹhinna da atunyẹwo ti ifipamọ ti o ni ohun kikọ koodu iwọle pada.
///
///
/// Ko `char::encode_utf8`, yi ọna ti o tun n kapa codepoints ni surrogate ibiti o.
/// (Ṣiṣẹda `char` ni ibiti o wa ni ipo igbasilẹ ni UB.) Abajade jẹ [generalized UTF-8] to wulo ṣugbọn ko wulo UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ti ifipamọ ko ba tobi to.
/// Aṣayan ti ipari mẹrin jẹ tobi to lati fi koodu eyikeyi `char` sii.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Ṣe koodu iye u32 aise kan bi UTF-16 sinu ifipamọ `u16` ti a pese, ati lẹhinna da atunyẹwo ti ifipamọ ti o ni ohun kikọ silẹ ti o ni koodu sii.
///
///
/// Kii `char::encode_utf16`, ọna yii tun n kapa awọn akọwe koodu ni ibiti a ti gbero.
/// (Ṣiṣẹda `char` ni ibiti o wa ni ipo ni UB.)
///
/// # Panics
///
/// Panics ti ifipamọ ko ba tobi to.
/// Aṣayan ti ipari 2 tobi to lati fi koodu eyikeyi `char` sii.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // Aabo: kọọkan apa sọwedowo boya nibẹ ni o wa to die-die lati kọ sinu
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ṣubu nipasẹ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Awọn ọkọ ofurufu ti o ni afikun fọ si awọn aṣoju.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}