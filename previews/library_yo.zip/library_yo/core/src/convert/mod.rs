//! Traits fun awọn iyipada laarin awọn omiran.
//!
//! traits ninu modulu yii pese ọna lati yipada lati oriṣi kan si oriṣi miiran.
//! Kọọkan trait n ṣiṣẹ idi miiran:
//!
//! - Ṣiṣe [`AsRef`] trait fun awọn iyipada itọkasi-si-itọkasi olowo poku
//! - Se awọn [`AsMut`] trait fun poku mutable-to-mutable awọn iyipada
//! - Ṣiṣe [`From`] trait fun gbigba awọn iyipada iye-si-iye
//! - Se awọn [`Into`] trait fun n gba iye-to-iye awọn iyipada to orisi ita ti isiyi crate
//! - The [`TryFrom`] ati [`TryInto`] traits huwa bi [`From`] ati [`Into`], ṣugbọn yẹ ki o wa muse nigbati awọn iyipada le kuna.
//!
//! traits ninu module yii ni igbagbogbo lo bi trait bounds fun awọn iṣẹ jeneriki bii pe si awọn ariyanjiyan ti awọn oriṣi pupọ ni atilẹyin.Wo akọsilẹ ti kọọkan trait fun apeere.
//!
//! Bi awọn kan ìkàwé onkowe, o yẹ ki o ma fẹ imulo [`From<T>`][`From`] tabi [`TryFrom<T>`][`TryFrom`] dipo ju [`Into<U>`][`Into`] tabi [`TryInto<U>`][`TryInto`], bi [`From`] ati [`TryFrom`] pese o tobi ni irọrun ki o si pese deede [`Into`] tabi [`TryInto`] imuṣẹ fun free, o ṣeun si kan ibora imuse ninu awọn boṣewa ìkàwé.
//! Nigbati o ba n fojusi ikede kan ṣaaju Rust 1.41, o le jẹ pataki lati ṣe [`Into`] tabi [`TryInto`] taara nigbati o ba yipada si iru kan ni ita crate lọwọlọwọ.
//!
//! # Awọn imuse jeneriki
//!
//! - [`AsRef`] ati [`AsMut`] auto-dereference ti o ba ti ni akojọpọ type jẹ itọkasi kan
//! - [`From`]`<U>fun T` tumo si [`Into`]`</u><T><U>fun U`</u>
//! - [`TryFrom`]`<U>fun T` tumọ si [`TryInto`]`</u><T><U>fun U`</u>
//! - [`From`] ati [`Into`] ni o wa sihin, eyi ti ọna ti gbogbo awọn orisi le `into` ara wọn ki o `from` ara wọn
//!
//! Wo kọọkan trait fun lilo apeere.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Iṣẹ idanimọ naa.
///
/// Awọn nkan meji ṣe pataki lati ṣe akiyesi nipa iṣẹ yii:
///
/// - O ti wa ni ko nigbagbogbo deede si a bíbo bi `|x| x`, niwon awọn bíbo le coerce `x` sinu kan yatọ si oriṣi.
///
/// - O gbe igbewọle `x` kọja si iṣẹ naa.
///
/// Lakoko ti o le dabi ajeji lati ni iṣẹ kan ti o pada sẹhin ifunni, awọn lilo diẹ ti o nifẹ wa.
///
///
/// # Examples
///
/// Lilo `identity` lati ṣe ohunkohun ni ọkọọkan ti awọn miiran, ti o nifẹ si, awọn iṣẹ:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Jẹ ká dibọn wipe fifi ọkan jẹ ẹya awon iṣẹ.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Lilo `identity` bi a "do nothing" mimọ nla ni a àídájú:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ṣe awọn nkan ti o nifẹ si diẹ sii ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Lilo `identity` lati pa awọn `Some` aba ti ẹya iterator ti `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Lo lati se a poku tọka-to-itọkasi iyipada.
///
/// trait yii jọra si [`AsMut`] eyiti o lo fun iyipada laarin awọn itọkasi tọka.
/// Ti o ba nilo lati ṣe iyipada iye owo o dara lati ṣe [`From`] pẹlu iru `&T` tabi kọ iṣẹ aṣa.
///
/// `AsRef` ni Ibuwọlu kanna bii [`Borrow`], ṣugbọn [`Borrow`] yatọ si ni awọn aaye diẹ:
///
/// - Ko `AsRef`, [`Borrow`] ni o ni kan ibora impl fun eyikeyi `T`, ati ki o le wa ni lo lati gba boya a itọkasi tabi a iye.
/// - [`Borrow`] tun nilo pe [`Hash`], [`Eq`] ati [`Ord`] fun iye yiya jẹ deede si awọn ti iye ti o ni.
/// Fun idi eyi, ti o ba fẹ yawo nikan aaye kan ti ọna kan ti o le ṣe `AsRef`, ṣugbọn kii ṣe [`Borrow`].
///
/// **Note: trait yii ko gbọdọ kuna **.Ti iyipada ba le kuna, lo ọna ifiṣootọ eyiti o pada [`Option<T>`] tabi [`Result<T, E>`] kan.
///
/// # Awọn imuse jeneriki
///
/// - `AsRef` idojukọ-dereferences ti o ba ti ni akojọpọ type jẹ itọkasi kan tabi a mutable itọkasi (eg: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Nipa lilo trait bounds a le gba awọn ariyanjiyan ti o yatọ si orisi bi gun bi ti won le wa ni iyipada si awọn pàtó kan iru `T`.
///
/// Fun apẹẹrẹ: Nipa ṣiṣẹda a jeneriki iṣẹ ti o gba ohun `AsRef<str>` a han ti a fẹ lati gba gbogbo jo ti o le wa ni iyipada si [`&str`] bi ohun ariyanjiyan.
/// Niwon mejeji [`String`] ati [`&str`] se `AsRef<str>` a le gba mejeeji bi input ariyanjiyan.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Ṣe iyipada naa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ti a lo lati ṣe iyipada itọkasi iyipada-si-mutable olowo poku.
///
/// trait yii jọra si [`AsRef`] ṣugbọn o lo fun yiyi pada laarin awọn itọka iyipada.
/// Ti o ba nilo lati se a leri iyipada ti o jẹ dara lati se [`From`] pẹlu iru `&mut T` tabi kọ a aṣa iṣẹ.
///
/// **Note: trait yii ko gbọdọ kuna **.Ti iyipada ba le kuna, lo ọna ifiṣootọ eyiti o pada [`Option<T>`] tabi [`Result<T, E>`] kan.
///
/// # Awọn imuse jeneriki
///
/// - `AsMut` awọn iforukọsilẹ-aifọwọyi ti iru inu ba jẹ itọkasi iyipada (fun apẹẹrẹ: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Lilo `AsMut` bi trait bound fun iṣẹ jeneriki a le gba gbogbo awọn itọkasi iyipada ti o le yipada si iru `&mut T`.
/// Nitori [`Box<T>`] awọn ohun elo `AsMut<T>` a le kọ `add_one` iṣẹ kan ti o mu gbogbo awọn ariyanjiyan ti o le yipada si `&mut u64`.
/// Nitori [`Box<T>`] ṣe imuse `AsMut<T>`, `add_one` gba awọn ariyanjiyan ti iru `&mut Box<u64>` daradara:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Ṣe iyipada naa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Iyipada iye-si-iye ti o jẹ iye titẹ sii.Idakeji ti [`From`].
///
/// Ẹnikan yẹ ki o yago fun imuse [`Into`] ki o ṣe imuse [`From`] dipo.
/// Ṣiṣe [`From`] ṣiṣẹ laifọwọyi fun ọkan pẹlu imuse ti [`Into`] ọpẹ si imuse ibora ni ile-ikawe boṣewa.
///
/// Fẹ lilo [`Into`] lori [`From`] nigba ti seto trait bounds on a jeneriki iṣẹ lati rii daju wipe orisi ti o nikan se [`Into`] le ṣee lo bi daradara.
///
/// **Note: Eleyi trait kò gbọdọ ba kuna **.Ti o ba ti awọn iyipada le kuna, lo [`TryInto`].
///
/// # Awọn imuse jeneriki
///
/// - [`From`]`<T>fun U` tumo si `Into<U> for T`
/// - [`Into`] ni yi sihin, eyi ti o tumo si wipe `Into<T> for T` ni muse
///
/// # Ṣiṣe [`Into`] fun awọn iyipada si awọn iru ita ni awọn ẹya atijọ ti Rust
///
/// Šaaju si Rust 1.41, ti o ba nlo iru je ko apakan ti isiyi crate ki o si ko le se [`From`] taara.
/// Fun apẹẹrẹ, mu koodu yii:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Eyi yoo kuna lati ṣajọ ninu awọn ẹya agbalagba ti ede naa nitori awọn ofin alainibaba ti Rust lo lati jẹ iwuwo diẹ diẹ.
/// Lati kọja eyi, o le ṣe [`Into`] taara:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// O ṣe pataki lati ni oye pe [`Into`] ko pese imuse [`From`] (bii [`From`] ṣe pẹlu [`Into`]).
/// Nitorina, o yẹ ki o ma gbiyanju lati se [`From`] ati ki o si kuna pada si [`Into`] ti o ba ti [`From`] ko le wa ni muse.
///
/// # Examples
///
/// [`String`] awọn ipilẹṣẹ [`Into`]`<`[`Vec`] `<` [`u8`]` >> >>:
///
/// Lati ṣalaye pe a fẹ iṣẹ jeneriki lati mu gbogbo awọn ariyanjiyan ti o le yipada si iru `T` kan pato, a le lo trait bound ti [`Into`]`<T>`.
///
/// Fun apẹẹrẹ: Awọn iṣẹ `is_hello` gba gbogbo ariyanjiyan ti o le wa ni iyipada sinu kan [`Vec`] '<`[`u8`]'> '.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Ṣe iyipada naa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Ti a lo lati ṣe awọn iyipada iye-si-iye lakoko ti o n gba iye titẹ sii.O jẹ pasipaaro ti [`Into`].
///
/// Ẹnikan yẹ ki o nigbagbogbo fẹran imuse `From` lori [`Into`] nitori ṣiṣe `From` laifọwọyi n pese ọkan pẹlu imuse ti [`Into`] ọpẹ si imuse ibora ni ile-ikawe boṣewa.
///
///
/// Ṣe imuse [`Into`] nikan nigbati o fojusi ẹya kan ṣaaju Rust 1.41 ati yiyipada si oriṣi ni ita crate lọwọlọwọ.
/// `From` ko ni anfani lati ṣe iru awọn iyipada wọnyi ni awọn ẹya iṣaaju nitori awọn ofin alainibaba ti Rust.
/// Wo [`Into`] fun awọn alaye diẹ sii.
///
/// Fẹ lilo [`Into`] lori lilo `From` nigba ti seto trait bounds on a jeneriki iṣẹ.
/// Ọna yi, orisi ti taara se [`Into`] le ṣee lo bi awọn ariyanjiyan bi daradara.
///
/// `From` tun wulo pupọ nigba ṣiṣe mimu aṣiṣe.Nigba ti ko kan iṣẹ ti o jẹ o lagbara ti aise, awọn pada iru yoo gbogbo wa ni ti awọn fọọmu `Result<T, E>`.
/// `From` trait simplifies mimu aṣiṣe nipa gbigba iṣẹ lati pada iru aṣiṣe kan ti o fa awọn oriṣi ọpọ awọn aṣiṣe.Wo awọn "Examples" apakan ati [the book][book] fun alaye diẹ.
///
/// **Note: trait yii ko gbọdọ kuna **.Ti o ba ti awọn iyipada le kuna, lo [`TryFrom`].
///
/// # Awọn imuse jeneriki
///
/// - `From<T> for U` tumọ si [`Into`]`<U>fun T`</u>
/// - `From` jẹ ifaseyin, eyiti o tumọ si pe `From<T> for T` ti wa ni imuse
///
/// # Examples
///
/// [`String`] ṣe `From<&str>`:
///
/// Iyipada ti o fojuhan lati `&str` kan si Okun ti ṣe bi atẹle:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Lakoko ti o ti sise ni aṣiṣe mimu ti o ni igba wulo lati se `From` fun ara rẹ aṣiṣe iru.
/// Nipa yiyipada awọn iru aṣiṣe aṣiṣe si iru aṣiṣe aṣa tiwa ti o ṣe iru iru aṣiṣe aṣiṣe, a le da iru aṣiṣe kan pada laisi pipadanu alaye lori idi ti o wa.
/// Oniṣẹ '?' yipada laifọwọyi iru aṣiṣe aṣiṣe ti o wa si iru aṣiṣe aṣa wa nipa pipe `Into<CliError>::into` eyiti o pese laifọwọyi nigbati o n ṣe `From`.
/// Awọn alakojo ki o si infers eyi ti imuse ti `Into` yẹ ki o wa lo.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Ṣe iyipada naa.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ohun igbidanwo iyipada ti o agbara `self`, eyi ti o le tabi ko le jẹ gbowolori.
///
/// Library onkọwe yẹ ki o maa n ko taara se yi trait, ṣugbọn o yẹ ki o fẹ imulo awọn [`TryFrom`] trait, eyi ti nfun o tobi ni irọrun ati ki o pese ẹya deede `TryInto` imuse fun free, o ṣeun si kan ibora imuse ninu awọn boṣewa ìkàwé.
/// Fun alaye diẹ sii lori eyi, wo awọn iwe fun [`Into`].
///
/// # Ṣiṣe `TryInto`
///
/// Eleyi je iya kanna awọn ihamọ ati ero bi imulo [`Into`], wo nibẹ fun awọn alaye.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Awọn iru pada ninu awọn iṣẹlẹ ti a iyipada aṣiṣe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ṣe iyipada naa.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Awọn iyipada irufẹ ti o rọrun ati ailewu ti o le kuna ni ọna idari labẹ awọn ayidayida kan.O jẹ pasipaaro ti [`TryInto`].
///
/// Eyi wulo nigba ti o ba n ṣe iyipada iru kan ti o le ṣaṣeyọri ni aṣeyọri ṣugbọn o le tun nilo mimu pataki.
/// Fun apẹẹrẹ, nibẹ ni ko si ona lati se iyipada ohun [`i64`] sinu ohun [`i32`] lilo awọn [`From`] trait, nitori ohun [`i64`] le ni a iye wipe ohun [`i32`] ko le ašoju ati ki awọn iyipada yoo padanu data.
///
/// Eyi le ṣee ṣe nipasẹ dida [`i64`] si [`i32`] kan (pataki fifun ni modulo [`i32::MAX`] iye ti ``i64`]) tabi nipa ipadabọ [`i32::MAX`], tabi nipasẹ ọna miiran.
/// The [`From`] trait ti wa ni a ti pinnu fun pipe awọn iyipada, ki awọn `TryFrom` trait fun awọn komputa nigbati a iru iyipada ti o le lọ buburu ki o si jẹ wọn pinnu bi o lati mu awọn ti o.
///
/// # Awọn imuse jeneriki
///
/// - `TryFrom<T> for U` tumọ si [`TryInto`]`<U>fun T`</u>
/// - [`try_from`] jẹ ifaseyin, eyiti o tumọ si pe `TryFrom<T> for T` ti wa ni imuse ati pe ko le kuna-iru `Error` ti o ni nkan fun pipe `T::try_from()` lori iye ti iru `T` jẹ [`Infallible`].
/// Nigba ti o ti [`!`] iru ti wa ni diduro [`Infallible`] ati [`!`] yoo jẹ deede.
///
/// `TryFrom<T>` le ti wa ni muse bi wọnyi:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Bi a ti salaye, [`i32`] ọlọnà `TryFrom <` [`i64`] '>':
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Ni ipalọlọ ge awọn `big_number`, o nilo wiwa ati mimu idinku lẹhin otitọ.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Pada aṣiṣe nitori `big_number` tobi pupọ lati baamu ni `i32` kan.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Awọn ipadabọ `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Awọn iru pada ninu awọn iṣẹlẹ ti a iyipada aṣiṣe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Ṣe iyipada naa.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// AGBARA IMPLS
////////////////////////////////////////////////////////////////////////////////

// Bi gbe lori&amupu;
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Bi awọn gbigbe lori &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ropo awọn loke impls fun&/&mut pẹlu awọn wọnyi diẹ gbogboogbo ọkan:
// // Bi awọn gbigbe lori Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Won> AsRef <U>fun D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut gbe soke lori &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ropo awọn loke impl fun &mut pẹlu awọn wọnyi diẹ gbogboogbo ọkan:
// // AsMut gbe soke lori DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Won> AsMut <U>fun D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Lati awọn imọran sinu
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Lati (ati bayi Sinu) jẹ ifaseyin
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **iduroṣinṣin akọsilẹ:** Yi impl ko ni ko sibẹsibẹ tẹlẹ, sugbon a wa "reserving space" lati fi o ni future.
/// Wo [rust-lang/rust#64715][#64715] fun awọn alaye.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ṣe atunṣe opo-ọrọ dipo.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom tumo si TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// JẹỌrọỌlọrun tí iyipada ni o wa semantically deede si fallible awọn iyipada pẹlu ohun uninhabited aṣiṣe iru.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// CONPLRET IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ÀWỌN NOT NO K NO S NO ÀÌS.
////////////////////////////////////////////////////////////////////////////////

/// Awọn aṣiṣe Iru fun awọn aṣiṣe ti o le kò ṣẹlẹ.
///
/// Niwon yi enum ni o ni ko iyatọ, a iye ti yi iru le ko kosi tẹlẹ.
/// Yi le jẹ wulo fun awọn jeneriki APIs ti o lo [`Result`] ki o si parameterize awọn aṣiṣe iru, to fihan pe awọn abajade jẹ nigbagbogbo [`Ok`].
///
/// Fun apẹẹrẹ, awọn [`TryFrom`] trait (iyipada ti padà a [`Result`]) ni o ni kan ibora imuse fun gbogbo awọn orisi ibi ti a ọna [`Into`] imuse wa.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ibamu Future
///
/// Enum yii ni ipa kanna bi [the `!`“never”type][never], eyiti o jẹ riru ni ẹya Rust yii.
/// Nigba ti `!` ti wa ni diduro, a gbero lati ṣe `Infallible` a iru inagijẹ si o:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Ati ni ipari bajẹ `Infallible`.
///
/// Sibẹsibẹ o wa ni ọkan irú ibi ti `!` sintasi le ṣee lo ki o to `!` ti wa ni diduro bi awọn kan ni kikun-fledged Iru: ninu awọn ipo ti a iṣẹ ká pada iru.
/// Ni pato, o ṣee ṣe awọn imuṣẹ fun awọn oriṣi ijuboluwo iṣẹ oriṣiriṣi meji:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Pẹlu `Infallible` jije ohun enum, yi koodu ti wa ni wulo.
/// Sibẹsibẹ nigbati `Infallible` di ohun inagijẹ fun awọn never type, awọn meji `impl`s yoo bẹrẹ si ni lqkan ati nitorina yoo wa ni disallowed nipasẹ awọn ede ká trait eeto ofin.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}