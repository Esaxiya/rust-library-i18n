#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Igbesi jẹmọ si ajeji iṣẹ ni wiwo (FFI) bindings.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Deede to C ká `void` iru nigba ti lo bi awọn kan [pointer].
///
/// Ni lodi, `*const c_void` ni deede lati C ká `const void*` ati `*mut c_void` ni deede lati C ká `void*`.
/// Ti o wi, yi ni *ko* kanna bi C ká `void` pada iru, eyi ti o jẹ Rust ká `()` iru.
///
/// Lati awoṣe ifẹnule lati akomo orisi ni FFI, titi `extern type` ti wa ni diduro, o ti wa ni niyanju lati lo a newtype wrapper ni ayika ohun ṣofo baiti orun.
///
/// Wo awọn [Nomicon] fun awọn alaye.
///
/// Ọkan le lo `std::os::raw::c_void` ti o ba ti nwọn fẹ lati se atileyin atijọ Rust alakojo si isalẹ lati 1.1.0.
/// Lẹhin Rust 1.30.0, o ti tun gbe ọja okeere nipasẹ itumọ yii.
/// Fun alaye diẹ, jọwọ ka [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, fun LLVM lati da awọn ofo ni ijuboluwole iru ati nipa itẹsiwaju awọn iṣẹ bi malloc(), a nilo lati ni o ni ipoduduro bi i8 * ni LLVM bitcode.
// Enum ti a lo nibi ṣe idaniloju eyi ati idilọwọ ilokulo iru "raw" nipasẹ nini awọn iyatọ aladani nikan.
// A nilo awọn iyatọ meji, nitori apejọ ṣaroye nipa ẹda repr bibẹkọ ati pe a nilo o kere ju iyatọ kan bii bibẹẹkọ ti enum naa ko ni gbe ati pe o kere ju ifasilẹ iru awọn itọkasi bẹ yoo jẹ UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Ipilẹ imuse ti a `va_list`.
// Orukọ naa ni WIP, ni lilo `VaListImpl` fun bayi.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Ko baramu lori `'f`, ki kọọkan `VaListImpl<'f>` ohun ti wa ni ti so si ekun ti awọn iṣẹ ti o ti n telẹ ni
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Abi imuse ti a `va_list`.
/// Wo awọn [AArch64 Procedure Call Standard] fun alaye diẹ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Abi imuse ti a `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Abi imuse ti a `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Apo fun `va_list` kan
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Iyipada `VaListImpl` kan si `VaList` ti o jẹ ibaramu alakomeji pẹlu C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Iyipada `VaListImpl` kan si `VaList` ti o jẹ ibaramu alakomeji pẹlu C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// The VaArgSafe trait nilo lati wa ni lo ni gbangba atọkun, sibẹsibẹ, awọn trait ara ko gbodo wa ni laaye lati ṣee lo ni ita yi module.
// Gbigba awọn olumulo lati se awọn trait fun titun kan Iru (nitorina gbigba awọn va_arg ojulowo lati wa ni lo lori titun kan type) jẹ seese lati fa aisọye ihuwasi.
//
// FIXME(dlrobertson): Ni ibere lati lo VaArgSafe trait ni a gbangba ni wiwo sugbon tun rii daju o ko le ṣee lo ni bomi, awọn trait nilo lati wa ni gbangba laarin a ikọkọ module.
// Lọgan ti RFC 2145 ti a ti muse wo sinu imudarasi yi.
//
//
//
//
mod sealed_trait {
    /// Trait eyi ti o fayegba laaye orisi to ṣee lo pẹlu [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Advance si awọn tókàn arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Idaako ti `va_list` ni ti isiyi.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // Aabo: awọn olupe gbọdọ opagun aabo guide fun `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // Aabo: a kọ si awọn `MaybeUninit`, bayi o ti wa ni initialized ati `assume_init` ni ofin
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: eyi yẹ ki o pe `va_end`, ṣugbọn ko si ọna mimọ si
        // ẹri ti o `drop` nigbagbogbo olubwon inlined sinu awọn oniwe-olupe ti, ki awọn `va_end` yoo gba taara ti a npe ni lati kanna iṣẹ bi awọn ti o baamu `va_copy`.
        // `man va_end` ipinle ti o C nilo yi, ati LLVM besikale telẹ awọn C oro ijora, ki a nilo lati rii daju pe `va_end` wa ni nigbagbogbo ti a npe ni lati kanna iṣẹ bi `va_copy`.
        //
        // Fun alaye sii, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Eyi n ṣiṣẹ fun bayi, nitori `va_end` jẹ a-op lori gbogbo awọn ifojusi LLVM lọwọlọwọ.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Pa arglist `ap` run lẹhin ibẹrẹ pẹlu `va_start` tabi `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Idaako ti isiyi ipo ti arglist `src` si arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Gbe ariyanjiyan ti iru `T` lati `va_list` `ap` ati alekun ariyanjiyan `ap` tọka si.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}