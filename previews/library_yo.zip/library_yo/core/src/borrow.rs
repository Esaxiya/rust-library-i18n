//! Modulu kan fun ṣiṣẹ pẹlu data ti a yawo.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait fun data yiya.
///
/// Ni Rust, o jẹ wọpọ lati pese o yatọ si awọn atungbejade ti a iru fun o yatọ lilo igba.
/// Fun apeere, ipo ibi ipamọ ati iṣakoso fun iye kan le yan ni pataki bi o yẹ fun lilo kan pato nipasẹ awọn oriṣi ijuboluwole bi [`Box<T>`] tabi [`Rc<T>`].
/// Ni ikọja awọn ohun elo jeneriki wọnyi ti o le ṣee lo pẹlu eyikeyi iru, diẹ ninu awọn oriṣi n pese awọn oju eeyan ti n pese iṣẹ ṣiṣe ti o le ni agbara.
/// Apẹẹrẹ fun iru iru bẹẹ ni [`String`] eyiti o ṣe afikun agbara lati fa okun si [`str`] ipilẹ.
/// Eyi nilo fifi alaye afikun sii kobojumu fun ọna ti o rọrun, okun ti ko le yipada.
///
/// Awọn iru wọnyi n pese iraye si data ipilẹ nipasẹ awọn itọkasi si iru data yẹn.Wọn ti wa ni wi lati wa ni 'ya bi' ti iru.
/// Fun apẹẹrẹ, a [`Box<T>`] le ti wa ni ya bi `T` nigba ti a [`String`] le ti wa ni ya bi `str`.
///
/// Orisi han pe won le wa ni ya bi diẹ ninu awọn Iru `T` nipa imulo `Borrow<T>`, pese a tọka si a `T` ni trait ká [`borrow`] ọna.Iru kan ni ominira lati yawo bi ọpọlọpọ awọn oriṣi oriṣiriṣi.
/// Ti o ba ti o gbé wù u lati mutably yawo bi iru-gbigba awọn amuye data to wa ni títúnṣe, o le afikun ohun ti se [`BorrowMut<T>`].
///
/// Siwaju sii, nigbati o ba n pese awọn imuse fun afikun traits, o nilo lati gbero boya wọn yẹ ki o huwa bakanna si awọn ti iru ipilẹ nitori abajade iṣe bii aṣoju ti iru ipilẹ.
/// Generic koodu ojo melo lo `Borrow<T>` nigba ti o gbekele lori awọn aami ihuwasi ti awọn wọnyi afikun trait imuṣẹ.
/// Awọn wọnyi traits yoo seese han bi afikun trait bounds.
///
/// Ni pato `Eq`, `Ord` ati `Hash` gbọdọ jẹ deede fun awọn iye ti a ya ati awọn ohun-ini: `x.borrow() == y.borrow()` yẹ ki o fun abajade kanna bi `x == y`.
///
/// Ti koodu jeneriki jo nilo lati ṣiṣẹ fun gbogbo awọn oriṣi ti o le pese itọkasi si iru `T` ti o jọmọ, o dara nigbagbogbo lati lo [`AsRef<T>`] bi awọn oriṣi diẹ ṣe le ṣe imuse lailewu.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Gẹgẹbi ikojọpọ data, [`HashMap<K, V>`] ni awọn bọtini ati iye mejeeji.Ti o ba ti awọn bọtini ká gangan data ti wa ni ti a we ni a ìṣàkóso iru ti diẹ ninu awọn irú, o yẹ ki, sibẹsibẹ, si tun je ṣee ṣe lati wa fun awọn a iye nipa lilo a tọka si awọn bọtini ile data.
/// Fun apẹẹrẹ, ti o ba ti awọn bọtini ni a okun, ki o si ti wa ni seese ti o ti fipamọ pẹlu awọn elile map bi a [`String`], nigba ti o yẹ ki o wa ṣee ṣe lati wa nipa lilo a [`&str`][`str`].
/// Bayi, `insert` nilo lati ṣiṣẹ lori a `String` nigba ti `get` nilo lati wa ni anfani lati lo a `&str`.
///
/// Diẹ ni irọrun, awọn ẹya ti o baamu ti `HashMap<K, V>` dabi eleyi:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // awọn aaye ti own
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Gbogbo elile map jẹ jeneriki lori bọtini kan iru `K`.Nitori awọn bọtini ti wa ni ti o ti fipamọ pẹlu awọn elile map, yi iru ni o ni lati ara awọn bọtini ile data.
/// Nigbati o ba fi sii iye-iye bọtini kan, a fun ni maapu bẹ iru `K` ati pe o nilo lati wa garawa elile ti o tọ ati ṣayẹwo ti bọtini ba ti wa tẹlẹ ti o da lori `K` naa.Nitorinaa o nilo `K: Hash + Eq`.
///
/// Nigbati o ba n wa iye kan ninu maapu naa, sibẹsibẹ, nini lati pese itọkasi kan si `K` bi bọtini lati wa yoo nilo lati ṣẹda iru iye ti o ni nigbagbogbo.
/// Fun awọn bọtini okun, eyi yoo tumọ si pe o nilo lati ṣẹda iye `String` kan fun wiwa fun awọn ọran nibiti `str` nikan wa.
///
/// Dipo, ọna `get` jẹ jeneriki lori iru data bọtini ipilẹ, ti a pe ni `Q` ninu ibuwọlu ọna loke.O sọ wipe `K` borrows bi a `Q` nipa nilo ti `K: Borrow<Q>`.
/// Nipa afikun ohun to nilo `Q: Hash + Eq`, o ifihan agbara awọn ibeere ti o `K` ati `Q` ni awọn imuṣẹ ti awọn `Hash` ati `Eq` traits ti o gbe awọn aami esi.
///
/// Imuse ti `get` gbarale ni pataki lori awọn imuse kanna ti `Hash` nipa ṣiṣe ipinnu garawa eli bọtini nipasẹ pipe `Hash::hash` lori iye `Q` botilẹjẹpe o fi bọtini sii ti o da lori iye elile ti a ka lati iye `K`.
///
///
/// Gẹgẹbi abajade, maapu elile fọ bi `K` kan ti n murasilẹ iye `Q` ṣe agbejade elile ti o yatọ si `Q`.Fun apeere, fojuinu pe o ni iru kan ti o fi ipari si okun ṣugbọn ṣe afiwe awọn lẹta ASCII ti o foju foju wo ọran wọn:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Nitori awọn iye ti o dọgba meji nilo lati gbe iye elile kanna, imuse ti `Hash` nilo lati foju ọran ASCII, paapaa:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Njẹ `CaseInsensitiveString` le ṣe `Borrow<str>`?Dajudaju o le pese itọkasi si bibẹ pẹlẹbẹ nipasẹ okun ti o ni.
/// Ṣugbọn nitori imuse `Hash` rẹ yatọ, o huwa yatọ si `str` ati nitorinaa ko gbọdọ, ni otitọ, ṣe `Borrow<str>`.
/// Ti o ba fẹ lati gba awọn miiran laaye lati wọle si `str` ipilẹ, o le ṣe iyẹn nipasẹ `AsRef<str>` eyiti ko gbe eyikeyi awọn ibeere afikun.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Aiṣe gba awin lati iye ohun-ini kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait fun gbigbe data yiyatọ.
///
/// Bi awọn kan Companion to [`Borrow<T>`] yi trait faye gba a iru lati yawo bi ohun amuye Iru nipa pese a mutable itọkasi.
/// Wo [`Borrow<T>`] fun alaye diẹ sii lori yiya bi oriṣi miiran.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutably borrows lati ẹya ini iye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}