//! Iṣatunṣe Rust ti ilana alugoridimu Grisu3 ti a ṣalaye ninu "Awọn Nipasẹ Awọn nọmba Nisẹ Lẹsẹkẹsẹ Ni kiakia ati Ni deede pẹlu Awọn alamọpọ" [^ 1]
//! O nlo nipa 1KB ti tabili ṣaju, ati ni ọna, o yara pupọ fun ọpọlọpọ awọn igbewọle.
//!
//! [^1]: Florian Loitsch.2010. Titẹ sita awọn nọmba ojuami lilefoofo ni kiakia ati
//!   parí pẹlu odidi.SIGPLAN Ko.45, 6 (Okudu 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// wo awọn asọye ni `format_shortest_opt` fun ọgbọn ọgbọn.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* emi, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Ti a fun ni `x > 0`, pada `(k, 10^k)` bii `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Imuse ipo kuru ju fun Grisu.
///
/// O pada `None` nigbati o yoo da aṣoju ainidena pada bibẹẹkọ.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // a nilo o kere ju awọn idinku mẹta ti afikun konge

    // bẹrẹ pẹlu awọn iye ti o ṣe deede pẹlu olutaja ti a pin
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // wa eyikeyi `cached = 10^minusk` bii `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // niwon `plus` ti ṣe deede, eyi tumọ si `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // fun awọn aṣayan wa ti `ALPHA` ati `GAMMA`, eyi fi `plus * cached` sinu `[4, 2^32)`.
    //
    // o han ni o wuni lati mu iwọn `GAMMA - ALPHA` pọ si, nitorinaa a ko nilo ọpọlọpọ awọn agbara kaṣe ti 10, ṣugbọn awọn imọran diẹ wa:
    //
    //
    // 1. a fẹ lati tọju `floor(plus * cached)` laarin `u32` nitori o nilo pipin idiyele.
    //    (eyi kii ṣe yago fun gaan, a nilo iyoku fun idiyele ti deede.)
    // 2.
    // iyoku `floor(plus * cached)` leralera ni isodipupo nipasẹ 10, ati pe ko yẹ ki o bori.
    //
    // akọkọ n fun `64 + GAMMA <= 32`, lakoko ti keji fun `10 * 2^-ALPHA <= 2^64`;
    // -60 ati -32 jẹ ibiti o pọ julọ pẹlu ihamọ yii, ati pe V8 tun lo wọn.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // asekale fps.eyi n fun aṣiṣe ti o pọ julọ ti 1 ulp (ti a fihan lati Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-sakani gangan ti iyokuro
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ọgbẹ | 1 ulp || 1 ọgbẹ | 1 ulp || 1 ọgbẹ | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // loke `minus`, `v` ati `plus` jẹ *isunmọ* isunmọ (aṣiṣe <1 ulp).
    // nitori a ko mọ pe aṣiṣe jẹ rere tabi odi, a lo awọn isunmọ meji ti o wa ni aaye bakanna ati ni aṣiṣe ti o pọ julọ ti awọn ọgbẹ 2.
    //
    // awọn "unsafe region" jẹ a lawọ aarin eyi ti a wa lakoko ina.
    // "safe region" jẹ aarin igbasilẹ ti a gba nikan.
    // a bẹrẹ pẹlu repr ti o tọ laarin agbegbe ti ko ni aabo, ati gbiyanju lati wa repr ti o sunmọ si `v` eyiti o tun wa laarin agbegbe ailewu.
    // ti a ko ba le ṣe, a fi silẹ.
    //
    let plus1 = plus.f + 1;
    // jẹ ki plus0 = plus.f, 1;//nikan fun alaye jẹ ki minus0 = minus.f + 1;//nikan fun alaye
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // pín olutayo

    // pin `plus1` sinu awọn ẹya ara ati ida.
    // awọn ẹya ara ẹrọ jẹ onigbọwọ lati baamu ni u32, nitori awọn iṣeduro agbara ti a fi pamọ awọn `plus < 2^32` ati deede `plus.f` jẹ nigbagbogbo kere ju `2^64 - 2^4` nitori ibeere to pe deede.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ṣe iṣiro `10^max_kappa` ti o tobi julọ ko ju `plus1` (nitorinaa `plus1 < 10^(max_kappa+1)`).
    // eyi jẹ opin oke ti `kappa` ni isalẹ.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Theorem 6.2: ti `k` ba jẹ odidi odidi nla St.
    // `0 <= y mod 10^k <= y - x`,              lẹhinna `V = floor(y / 10^k) * 10^k` wa ni `[x, y]` ati ọkan ninu awọn aṣoju kukuru (pẹlu nọmba to kere julọ ti awọn nọmba to ṣe pataki) ni ibiti o wa.
    //
    //
    // wa ipari `kappa` nọmba laarin `(minus1, plus1)` bi fun Theorem 6.2.
    // A le gba Akọọlẹ 6.2 lati ṣe iyasọtọ `x` nipasẹ nilo `y mod 10^k < y - x` dipo.
    // (fun apẹẹrẹ, `x` =32000, `y` =32777; `kappa` =2 niwon `y mod 10 ^ 3=777 <y, x=777`.) alugoridimu naa gbarale apakan ijerisi igbamiiran lati ṣe iyasọtọ `y`.
    //
    let delta1 = plus1 - minus1;
    // jẹ ki delta1int=(delta1>> e) bi lilo;//nikan fun alaye
    let delta1frac = delta1 & ((1 << e) - 1);

    // ṣe awọn ẹya ara ẹrọ, lakoko ti o n ṣayẹwo fun deede ni igbesẹ kọọkan.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // awọn nọmba sibẹsibẹ lati ṣe
    loop {
        // a ni nigbagbogbo ni o kere ju nọmba kan lati ṣe, bi awọn ailorukọ `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (o tẹle pe `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // pin `remainder` nipasẹ `10^kappa`.awọn mejeeji ni iwọn nipasẹ `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; a ti rii `kappa` to pe.
            let ten_kappa = (ten_kappa as u64) << e; // asekale 10 ^ kappa pada si olutapa ti a pin
            return round_and_weed(
                // Aabo: a ṣe ipilẹ iranti yẹn loke.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // fọ lupu nigbati a ba ti ṣe gbogbo awọn nọmba papọ.
        // nọmba gangan ti awọn nọmba jẹ `max_kappa + 1` bi `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // pada invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ṣe awọn ipin ida, lakoko ti o n ṣayẹwo fun deede ni igbesẹ kọọkan.
    // ni akoko yii a gbẹkẹle awọn isodipupo tun, bi pipin yoo padanu konge.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // Nọmba ti o tẹle yẹ ki o jẹ pataki bi a ti ni idanwo pe ṣaaju kikan awọn alailẹgbẹ, nibi ti `m = max_kappa + 1` (#ti awọn nọmba ni apakan apakan):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ko ni bori, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // pin `remainder` nipasẹ `10^kappa`.
        // awọn mejeeji ni iwọn nipasẹ `2^e / 10^kappa`, nitorinaa igbehin jẹ eyiti a ko mọ nibi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // onipin ti ko boju mu
            return round_and_weed(
                // Aabo: a ṣe ipilẹ iranti yẹn loke.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // pada invariants
        kappa -= 1;
        remainder = r;
    }

    // a ti ṣe ipilẹṣẹ gbogbo awọn nọmba to ṣe pataki ti `plus1`, ṣugbọn ko daadaa boya o jẹ eyi ti o dara julọ.
    // fun apẹẹrẹ, ti `minus1` jẹ 3.14153 ... ati `plus1` jẹ 3.14158 ..., aṣoju 5 ti o kuru ju oriṣiriṣi wa lati 3.14154 si 3.14158 ṣugbọn awa nikan ni ọkan ti o tobi julọ.
    // a ni lati dinku ni nọmba ti o kẹhin ati ṣayẹwo boya eyi ni repr ti o dara julọ.
    // ọpọlọpọ awọn oludije 9 wa (..1 si ..9), nitorinaa eyi yara yara.(Ipele "rounding")
    //
    // awọn iṣayẹwo iṣẹ naa ti "optimal" repr yii ba wa laarin awọn sakani ulp, ati pẹlu, o ṣee ṣe pe "second-to-optimal" repr le jẹ ti aipe ni otitọ nitori aṣiṣe yiyi.
    // ni awọn ọran mejeeji eyi pada `None`.
    // (Ipele "weeding")
    //
    // gbogbo awọn ariyanjiyan nibi ni o ni iwọn nipasẹ iye ti o wọpọ (ṣugbọn aibikita) `k`, nitorinaa:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (Ki o si tun, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ati tun, `threshold > plus1v` lati awọn ailorukọ tẹlẹ)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ṣe awọn isunmọ meji si `v` (gangan `plus1 - v`) laarin awọn ọgbẹ 1.5.
        // aṣoju ti o yẹ ki o jẹ aṣoju ti o sunmọ julọ si awọn mejeeji.
        //
        // nibi `plus1 - v` ti lo niwon awọn iṣiro ti ṣe pẹlu ọwọ si `plus1` lati yago fun overflow/underflow (nitorinaa awọn orukọ ti o dabi ẹnipe a yipada).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // dinku nọmba ti o kẹhin ki o da duro ni aṣoju to sunmọ `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // a ṣiṣẹ pẹlu awọn nọmba to sunmọ `w(n)`, eyiti o jẹ ni ibẹrẹ dogba si `plus1 - plus1 % 10^kappa`.lẹhin ṣiṣe lupu ara `n` igba, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // a ṣeto `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (nitorinaa `iyoku= plus1w(0)`) lati jẹ ki awọn sọwedowo rọrun.
            // ṣe akiyesi pe `plus1w(n)` nigbagbogbo npo sii.
            //
            // a ni awọn ipo mẹta lati fopin si.eyikeyi ninu wọn yoo jẹ ki lupu ko le tẹsiwaju, ṣugbọn lẹhinna a ni o kere ju aṣoju oniduro kan ti a mọ lati sunmọ `v + 1 ulp` bakanna.
            // a yoo tọka wọn bi TC1 nipasẹ TC3 fun kukuru.
            //
            // TC1: `w(n) <= v + 1 ulp`, ie, eyi ni repr ti o kẹhin ti o le jẹ ọkan ti o sunmọ julọ.
            // eyi jẹ deede si `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ni idapo pelu TC2 (eyiti o ṣayẹwo ti o ba jẹ `w(n+1)` is valid), eyi ṣe idilọwọ iṣan-omi ti o ṣee ṣe lori iṣiro ti `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ie, repr ti o tẹle ni pato ko yika si `v`.
            // eyi jẹ deede si `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ẹgbẹ ọwọ osi le ṣan, ṣugbọn a mọ `threshold > plus1v`, nitorinaa ti TC1 ba jẹ eke, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ati pe a le ṣe idanwo lailewu ti `threshold - plus1w(n) < 10^kappa` dipo.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ie, repr atẹle ni
            // ko si sunmọ `v + 1 ulp` ju repr lọwọlọwọ.
            // fi fun `z(n) = plus1v_up - plus1w(n)`, eyi di `abs(z(n)) <= abs(z(n+1))`.lẹẹkansi ro pe TC1 jẹ eke, a ni `z(n) > 0`.a ni awọn ọran meji lati ronu:
            //
            // - nigbati `z(n+1) >= 0`: TC3 di `z(n) <= z(n+1)`.
            // bi `plus1w(n)` ṣe npo si, `z(n)` yẹ ki o dinku ati pe eyi jẹ eke ni gbangba.
            // - nigbati `z(n+1) < 0`:
            //   - TC3a: ipilẹṣẹ jẹ `plus1v_up < plus1w(n) + 10^kappa`.ro pe TC2 jẹ eke, `threshold >= plus1w(n) + 10^kappa` nitorinaa ko le bori.
            //   - TC3b: TC3 di `z(n) <= -z(n+1)`, ie, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 ti a ko yẹ fun `plus1v_up > plus1w(n)`, nitorinaa ko le ṣan tabi ṣiṣan nigbati o ba ni idapo pẹlu TC3a.
            //
            // Nitori naa, o yẹ ki a da nigba `TC1 || TC2 || (TC3a && TC3b)`.atẹle ni o dọgba si onidakeji, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr ti o kuru ju ko le pari pẹlu `0`
                plus1w += ten_kappa;
            }
        }

        // ṣayẹwo ti aṣoju yii tun jẹ aṣoju to sunmọ `v - 1 ulp`.
        //
        // eyi jẹ iru kanna si awọn ipo ifopinsi fun `v + 1 ulp`, pẹlu gbogbo `plus1v_up` rọpo nipasẹ `plus1v_down` dipo.
        // itupalẹ aponsedanu dogba di.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // bayi a ni aṣoju to sunmọ si `v` laarin `plus1` ati `minus1`.
        // eyi jẹ ominira pupọ, botilẹjẹpe, nitorinaa a kọ eyikeyi `w(n)` kii ṣe laarin `plus0` ati `minus0`, ie, `plus1 - plus1w(n) <= minus0` tabi `plus1 - plus1w(n) >= plus0`.
        // a lo awọn otitọ ti `threshold = plus1 - minus1` ati `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Imuse ipo ti o kuru ju fun Grisu pẹlu Dragon fallback.
///
/// Eyi yẹ ki o lo fun ọpọlọpọ awọn ọran.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // Aabo: Oluyawo awin ko ni oye to lati jẹ ki a lo `buf`
    // ni branch keji, nitorinaa a fọ igbesi aye nibi.
    // Ṣugbọn a tun lo `buf` nikan ti `format_shortest_opt` ba pada `None` nitorinaa o dara.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Imuṣe ipo deede ati ti o wa titi fun Grisu.
///
/// O pada `None` nigbati o yoo da aṣoju ainidena pada bibẹẹkọ.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // a nilo o kere ju awọn idinku mẹta ti afikun konge
    assert!(!buf.is_empty());

    // ṣe deede ati iwọn `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // pin `v` sinu awọn ẹya ara ati ida.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // mejeeji `v` atijọ ati `v` tuntun (ti iwọn nipasẹ `10^-k`) ni aṣiṣe ti <1 ulp (Theorem 5.1).
    // nitori a ko mọ pe aṣiṣe jẹ rere tabi odi, a lo awọn isunmọ meji ti o wa ni aaye bakanna ati ni aṣiṣe ti o pọ julọ ti ọgbẹ 2 (kanna si ọran to kuru ju).
    //
    //
    // ibi-afẹde naa ni lati wa tito lẹsẹsẹ yika ti awọn nọmba ti o wọpọ si `v - 1 ulp` ati `v + 1 ulp` mejeeji, nitorinaa a ni igboya pupọ julọ.
    // ti eyi ko ba ṣee ṣe, a ko mọ eyi ti o jẹ iṣelọpọ to tọ fun `v`, nitorinaa a fi silẹ ki a pada sẹhin.
    //
    // `err` ti ṣalaye bi `1 ulp * 2^e` nibi (kanna si ulp ni `vfrac`), ati pe a yoo ṣe iwọn rẹ nigbakugba ti `v` ba ni iwọn.
    //
    //
    //
    let mut err = 1;

    // ṣe iṣiro `10^max_kappa` ti o tobi julọ ko ju `v` (nitorinaa `v < 10^(max_kappa+1)`).
    // eyi jẹ opin oke ti `kappa` ni isalẹ.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ti a ba n ṣiṣẹ pẹlu aropin nọmba oni-nọmba to kẹhin, a nilo lati kuru ifipamọ ṣaaju ṣiṣe atunṣe gangan lati yago fun iyipo meji.
    //
    // ṣe akiyesi pe a ni lati mu ki ifipamọ naa tobi sii nigba ti ikojọpọ ba ṣẹlẹ!
    let len = if exp <= limit {
        // oops, a ko le ṣe agbejade *nọmba kan*.
        // eyi ṣee ṣe nigbati, sọ, a ni nkan bi 9.5 ati pe o ti yika si 10.
        //
        // ni opo a le pe `possibly_round` lẹsẹkẹsẹ pẹlu ifipamọ ti o ṣofo, ṣugbọn wiwọn `max_ten_kappa << e` nipasẹ 10 le ja si ṣiṣan.
        //
        // nitorinaa a wa ni alaini nibi ati faagun iwọn aṣiṣe nipasẹ ifosiwewe ti 10.
        // eyi yoo mu alekun odi oṣuwọn pọ si, ṣugbọn pupọ pupọ,*pupọ* die-die;
        // o le ṣe akiyesi ni akiyesi nikan nigbati mantissa tobi ju awọn idinku 60 lọ.
        //
        // Aabo: `len=0`, nitorinaa ọranyan ti ipilẹṣẹ iranti yii jẹ ohun ti ko ṣe pataki.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // mu awọn ẹya ara ẹrọ jẹ.
    // aṣiṣe naa jẹ ida patapata, nitorinaa a ko nilo lati ṣayẹwo rẹ ni apakan yii.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // awọn nọmba sibẹsibẹ lati ṣe
    loop {
        // nigbagbogbo a ni o kere ju nọmba kan lati fun awọn alailera:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (o tẹle pe `remainder = vint % 10^(kappa+1)`)
        //
        //

        // pin `remainder` nipasẹ `10^kappa`.awọn mejeeji ni iwọn nipasẹ `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // saarin ti kun?ṣiṣe igbasilẹ yika pẹlu iyoku.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // Aabo: a ti ṣe ipilẹṣẹ `len` ọpọlọpọ awọn baiti.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // fọ lupu nigbati a ba ti ṣe gbogbo awọn nọmba papọ.
        // nọmba gangan ti awọn nọmba jẹ `max_kappa + 1` bi `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // pada invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ṣe awọn ipin ida.
    //
    // ni opo a le tẹsiwaju si nọmba to kẹhin ti o wa ati ṣayẹwo fun deede.
    // laanu a n ṣiṣẹ pẹlu awọn odidi iye to ni opin, nitorinaa a nilo ami-ami diẹ lati ṣawari ṣiṣan omi.
    // V8 lo `remainder > err`, eyiti o di eke nigbati akọkọ awọn nọmba pataki `i` ti `v - 1 ulp` ati `v` yatọ.
    // sibẹsibẹ eyi kọ ọpọlọpọ pupọ bibẹkọ ti titẹsi to wulo.
    //
    // niwọn igba ti igbamiiran ti o ni iwari iṣan omi ti o tọ, dipo a lo ami-ami ti o nira:
    // a tẹsiwaju digba `err` ti kọja `10^kappa / 2`, nitorina ibiti o wa laarin `v - 1 ulp` ati `v + 1 ulp` ni pato ni awọn aṣoju onipin meji tabi diẹ sii.
    //
    // eyi jẹ kanna si awọn afiwe meji akọkọ lati `possibly_round`, fun itọkasi.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // awọn alailẹgbẹ, nibiti `m = max_kappa + 1` (#ti awọn nọmba ni apakan apakan):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ko ni bori, `2^e * 10 < 2^64`
        err *= 10; // ko ni bori, `err * 10 < 2^e * 5 < 2^64`

        // pin `remainder` nipasẹ `10^kappa`.
        // awọn mejeeji ni iwọn nipasẹ `2^e / 10^kappa`, nitorinaa igbehin jẹ eyiti a ko mọ nibi.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // saarin ti kun?ṣiṣe igbasilẹ yika pẹlu iyoku.
        if i == len {
            // Aabo: a ti ṣe ipilẹṣẹ `len` ọpọlọpọ awọn baiti.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // pada invariants
        remainder = r;
    }

    // iṣiro siwaju sii ko wulo (`possibly_round` ni pato kuna), nitorinaa a fi silẹ.
    return None;

    // a ti ṣe ipilẹṣẹ gbogbo awọn nọmba ti a beere ti `v`, eyiti o yẹ ki o jẹ bakanna si awọn nọmba to baamu ti `v - 1 ulp`.
    // bayi a ṣayẹwo boya aṣoju alailẹgbẹ wa ti o pin nipasẹ `v - 1 ulp` ati `v + 1 ulp`;eyi le jẹ bakanna si awọn nọmba ti ipilẹṣẹ, tabi si ẹya ti o yika-ti awọn nọmba wọnyẹn.
    //
    // ti ibiti ibiti o ni awọn aṣoju pupọ ti gigun kanna, a ko le rii daju pe o yẹ ki o pada `None` dipo.
    //
    // gbogbo awọn ariyanjiyan nibi ni o ni iwọn nipasẹ iye ti o wọpọ (ṣugbọn aibikita) `k`, nitorinaa:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // Aabo: akọkọ baiti `len` ti `buf` gbọdọ jẹ ipilẹṣẹ.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ọgbẹ | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (fun itọkasi, laini aami aami tọka iye deede fun awọn aṣoju ti o ṣee ṣe ni nọmba ti a fun ni nọmba.)
        //
        //
        // aṣiṣe tobi pupọ pe o kere ju awọn aṣoju mẹta ti o ṣeeṣe laarin `v - 1 ulp` ati `v + 1 ulp`.
        // a ko le pinnu eyi ti o tọ.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ọgbẹ | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ni otitọ, 1/2 ulp ti to lati ṣafihan awọn aṣoju meji ti o ṣeeṣe.
        // (ranti pe a nilo aṣoju alailẹgbẹ fun `v - 1 ulp` ati `v + 1 ulp`.) eyi kii yoo bori, bi `ulp < ten_kappa` lati ayẹwo akọkọ.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ọgbẹ | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ti `v + 1 ulp` ba sunmọ si oniduro ti o yika (eyiti o wa ni `buf` tẹlẹ), lẹhinna a le pada lailewu.
        // ṣe akiyesi pe `v - 1 ulp`*le* jẹ kere si aṣoju lọwọlọwọ, ṣugbọn bi `1 ulp < 10^kappa / 2`, ipo yii ti to:
        // aaye laarin `v - 1 ulp` ati aṣoju lọwọlọwọ ko le kọja `10^kappa / 2`.
        //
        // majemu dogba si `remainder + ulp < 10^kappa / 2`.
        // nitori eyi le ni irọrun ṣaju, ṣayẹwo akọkọ ti `remainder < 10^kappa / 2` ba.
        // a ti rii daju tẹlẹ pe `ulp < 10^kappa / 2`, nitorinaa bi `10^kappa` ko ṣe bori lẹhin gbogbo, ayẹwo keji dara.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // Aabo: olupe wa ti ṣe iranti iranti naa.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------iyoku------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ọgbẹ | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // lori awọn ọwọ miiran, ti `v - 1 ulp` ba sunmọ si aṣoju ti o yika, o yẹ ki a yika ki o pada.
        // fun idi kanna a ko nilo lati ṣayẹwo `v + 1 ulp`.
        //
        // majemu dogba si `remainder - ulp >= 10^kappa / 2`.
        // lẹẹkansi a kọkọ ṣayẹwo boya `remainder > ulp` (ṣe akiyesi pe eyi kii ṣe `remainder >= ulp`, bi `10^kappa` kii ṣe odo rara).
        //
        // tun ṣe akiyesi pe `remainder - ulp <= 10^kappa`, nitorinaa ayẹwo keji ko bori.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // Aabo: olupe wa gbọdọ ti bẹrẹ iranti yẹn.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // nikan ṣafikun nọmba oni-nọmba nigba ti a ti beere deede ti o wa titi.
                // a tun nilo lati ṣayẹwo pe, ti ifipamọ atilẹba ba ṣofo, a le ṣafikun nọmba afikun nigbati `exp == limit` (ọran edge) ba wa.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // Aabo: awa ati olupe wa ti ṣe iranti iranti naa.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // bibẹkọ ti a wa ni iparun (ie, diẹ ninu awọn iye laarin `v - 1 ulp` ati `v + 1 ulp` n yika ati pe awọn miiran n ṣajọ) ati fifun.
        //
        None
    }
}

/// Imuse ipo deede ati ti o wa titi fun Grisu pẹlu Dragonbackback.
///
/// Eyi yẹ ki o lo fun ọpọlọpọ awọn ọran.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // Aabo: Oluyawo awin ko ni oye to lati jẹ ki a lo `buf`
    // ni branch keji, nitorinaa a fọ igbesi aye nibi.
    // Ṣugbọn a tun lo `buf` nikan ti `format_exact_opt` ba pada `None` nitorinaa o dara.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}