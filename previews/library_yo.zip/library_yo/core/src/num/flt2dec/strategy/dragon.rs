//! O fẹrẹ to taara (ṣugbọn iṣapeye diẹ) Rust itumọ ti Nọmba 3 ti `Awọn titẹ sita Awọn nọmba Nisọ ni kiakia ati ni deede` [^ 1].
//!
//!
//! [^1]: Burger, RG ati Dybvig, RK 1996. Titẹ sita awọn nọmba oju-omi
//!   ni kiakia ati parí.SIGPLAN Ko.31, 5 (Oṣu Karun. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// awọn iṣiro oniṣiro tẹlẹ ti 'Digit`s fun 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// lilo nikan nigbati `x < 16 * scale`;`scaleN` yẹ ki o jẹ `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Imuse ipo kuru ju fun Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // nọmba `v` si ọna kika ni a mọ lati jẹ:
    // - dogba si `mant * 2^exp`;
    // - ti ṣaju nipasẹ `(mant - 2 *minus)* 2^exp` ni oriṣi atilẹba;ati
    // - atẹle nipa `(mant + 2 *plus)* 2^exp` ni iru atilẹba.
    //
    // o han ni, `minus` ati `plus` ko le jẹ odo.(fun awọn ailopin, a lo awọn iye ti ita-ibiti.) tun a gba pe o kere ju nọmba kan ti wa ni ipilẹṣẹ, ie, `mant` ko le jẹ odo paapaa.
    //
    // eyi tun tumọ si pe eyikeyi nọmba laarin `low = (mant - minus)*2^exp` ati `high = (mant + plus)* 2^exp` yoo ṣe maapu si nọmba ojuami lilefoofo yii gangan, pẹlu awọn igboro ti o wa nigbati mantissa atilẹba paapaa (paapaa, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` jẹ `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // siro `k_0` lati awọn igbewọle atilẹba ti o ni itẹlọrun `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ihamọ `k` ti o ni itẹlọrun `10^(k-1) < high <= 10^k` ti ni iṣiro nigbamii.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // yi `{mant, plus, minus} * 2^exp` pada si fọọmu ida ki:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // pin `mant` nipasẹ `10^k`.bayi `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // atunse nigbati `mant + plus > scale` (tabi `>=`).
    // a ko ṣe atunṣe `scale` ni otitọ, nitori a le foju isodipupo akọkọ dipo.
    // bayi `scale < mant + plus <= scale * 10` ati pe a ti ṣetan lati ṣe ina awọn nọmba.
    //
    // ṣe akiyesi pe `d[0]`*le* jẹ odo, nigbati `scale - plus < mant < scale`.
    // ninu ọran yii ipo-yika (`up` ni isalẹ) yoo fa lẹsẹkẹsẹ.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // deede si wiwọn `scale` nipasẹ 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // kaṣe `(2, 4, 8) * scale` fun iran nọmba.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // awọn alaigbagbọ, nibiti `d[0..n-1]` jẹ awọn nọmba ti ipilẹṣẹ bẹ bẹ:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (bayi `mant / scale < 10`) nibiti `d[i..j]` jẹ ọna kukuru fun `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // ṣẹda nọmba kan: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // eyi jẹ apejuwe ti o rọrun ti algorithm ti a ti yipada.
        // ọpọlọpọ awọn itọsẹ agbedemeji ati awọn ariyanjiyan pipe ni a yọ kuro fun irọrun.
        //
        // bẹrẹ pẹlu awọn aiṣe iyipada, bi a ti ṣe imudojuiwọn `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ro pe `d[0..n-1]` ni aṣoju kukuru laarin `low` ati `high`, ie, `d[0..n-1]` ṣe itẹlọrun mejeji ti atẹle ṣugbọn `d[0..n-2]` ko ṣe:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: awọn nọmba yika si `v`);ati
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (nọmba to kẹhin jẹ ti o tọ).
        //
        // majemu keji jẹ simplifies si `2 * mant <= scale`.
        // lohun awọn alailẹgbẹ ni awọn ofin ti `mant`, `low` ati `high` ṣe agbejade ẹya ti o rọrun julọ ti ipo akọkọ: `-plus < mant < minus`.
        // lati `-plus < 0 <= mant`, a ni aṣoju to kuru ju ti o tọ nigba `mant < minus` ati `2 * mant <= scale`.
        // (ti tẹlẹ di `mant <= minus` nigbati atilẹba mantissa jẹ paapaa.)
        //
        // nigbati ekeji ko ba mu (`2 * mant> scale`), a nilo lati mu nọmba ti o kẹhin pọ si.
        // eyi to fun mimu-pada sipo ipo yẹn: a ti mọ tẹlẹ pe iran nọmba ṣe onigbọwọ `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // ninu ọran yii, ipo akọkọ di `-plus < mant - scale < minus`.
        // niwon `mant < scale` lẹhin iran, a ni `scale < mant + plus`.
        // (lẹẹkansi, eyi di `scale <= mant + plus` nigbati atilẹba mantissa jẹ paapaa.)
        //
        // Ni soki:
        // - da duro ati yika `down` (tọju awọn nọmba bi o ti ri) nigbati `mant < minus` (tabi `<=`).
        // - da duro ati yika `up` (mu nọmba to kẹhin) nigbati `scale < mant + plus` (tabi `<=`).
        // - tẹsiwaju npese bibẹkọ.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // a ni aṣoju kukuru, tẹsiwaju si iyipo

        // da pada awọn alailera.
        // eyi jẹ ki algorithm fopin si nigbagbogbo: `minus` ati `plus` nigbagbogbo npo si, ṣugbọn `mant` ti ge modulo `scale` ati `scale` ti wa ni tito.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ikotan n ṣẹlẹ nigbati i) nikan ni ipo yiyi ti fa, tabi ii) awọn ipo mejeeji ni o fa ati di fifọ awọn ayanfẹ yika.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ti ikotan ba yi gigun pada, olutapa yẹ ki o tun yipada.
        // o dabi pe ipo yii nira pupọ lati ni itẹlọrun (o ṣee ṣe ko ṣeeṣe), ṣugbọn a kan wa ni ailewu ati ni ibamu nibi.
        //
        // Aabo: a ṣe ipilẹ iranti yẹn loke.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // Aabo: a ṣe ipilẹ iranti yẹn loke.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Imuṣẹ ipo deede ati ti o wa titi fun Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // siro `k_0` lati awọn igbewọle atilẹba ti o ni itẹlọrun `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // pin `mant` nipasẹ `10^k`.bayi `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup nigbati `mant + plus >= scale`, nibo `plus / scale = 10^-buf.len() / 2`.
    // lati le tọju bignum titobi iwọn, a lo `mant + floor(plus) >= scale` gangan.
    // a ko ṣe atunṣe `scale` ni otitọ, nitori a le foju isodipupo akọkọ dipo.
    // lẹẹkansi pẹlu alugoridimu ti o kuru ju, `d[0]` le jẹ odo ṣugbọn yoo yika ni ipari.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // deede si wiwọn `scale` nipasẹ 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ti a ba n ṣiṣẹ pẹlu aropin nọmba oni-nọmba to kẹhin, a nilo lati kuru ifipamọ ṣaaju ṣiṣe atunṣe gangan lati yago fun iyipo meji.
    //
    // ṣe akiyesi pe a ni lati mu ki ifipamọ naa tobi sii nigba ti ikojọpọ ba ṣẹlẹ!
    let mut len = if k < limit {
        // oops, a ko le ṣe agbejade *nọmba kan*.
        // eyi ṣee ṣe nigbati, sọ, a ni nkan bi 9.5 ati pe o ti yika si 10.
        // a pada saarin ti o ṣofo, pẹlu imukuro ti ọran ikotan-nigbamii ti o waye nigbati `k == limit` ati pe o ni lati ṣe nọmba kan gangan.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // kaṣe `(2, 4, 8) * scale` fun iran nọmba.
        // (eyi le jẹ gbowolori, nitorinaa ko ṣe iṣiro wọn nigbati ibi ipamọ ba ṣofo.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // atẹle awọn nọmba ni gbogbo awọn odo, a da duro nibi maṣe *ma* gbiyanju lati ṣe iyipo!dipo, kun awọn nọmba to ku.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // Aabo: a ṣe ipilẹ iranti yẹn loke.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // kikojọpọ ti a ba da duro ni arin awọn nọmba ti awọn nọmba wọnyi ba jẹ deede 5000 ..., ṣayẹwo nọmba ti tẹlẹ ki o gbiyanju lati yika si ani (ie, yago fun ikasi nigba ti nomba iṣaaju naa jẹ paapaa).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // Aabo: `buf[len-1]` ti wa ni ipilẹṣẹ.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ti ikotan ba yi gigun pada, olutapa yẹ ki o tun yipada.
        // ṣugbọn a ti beere nọmba ti o wa titi ti awọn nọmba, nitorinaa maṣe paarọ ifipamọ naa ...
        // Aabo: a ṣe ipilẹ iranti yẹn loke.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ayafi ti a ba ti beere deede ti o wa titi dipo.
            // a tun nilo lati ṣayẹwo pe, ti ifipamọ atilẹba ba ṣofo, a le ṣafikun nọmba afikun nigbati `k == limit` (ọran edge) ba wa.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // Aabo: a ṣe ipilẹ iranti yẹn loke.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}