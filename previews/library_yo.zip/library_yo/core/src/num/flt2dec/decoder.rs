//! Ṣe ipinnu iye-lilefoofo loju omi si awọn apakan kọọkan ati awọn sakani aṣiṣe.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Ti pinnu iye ti a ko wole si, iru eleyi:
///
/// - Iye atilẹba dogba si `mant * 2^exp`.
///
/// - Nọmba eyikeyi lati `(mant - minus)*2^exp` si `(mant + plus)* 2^exp` yoo yika si iye atilẹba.
/// Ibiti o wa pẹlu gbogbo nikan nigbati `inclusive` jẹ `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Iwọn mantissa.
    pub mant: u64,
    /// Iwọn aṣiṣe kekere.
    pub minus: u64,
    /// Iwọn aṣiṣe oke.
    pub plus: u64,
    /// Apakan ti a pin ni ipilẹ 2.
    pub exp: i16,
    /// Otitọ nigbati ibiti aṣiṣe ba wa pẹlu.
    ///
    /// Ni IEEE 754, eyi jẹ otitọ nigbati mantissa atilẹba paapaa.
    pub inclusive: bool,
}

/// Ti ṣe ipinnu iye ti a ko wole.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Awọn ailopin, boya rere tabi odi.
    Infinite,
    /// Odo, boya rere tabi odi.
    Zero,
    /// Awọn nọmba ti o pari pẹlu awọn aaye ti a ti pinnu ni ilọsiwaju.
    Finite(Decoded),
}

/// Iru oriṣi omi lilefoofo eyiti o le jẹ `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Iyatọ to dara julọ ti iwuwasi deede.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Pada ami kan (otitọ nigbati o jẹ odi) ati iye `FullDecoded` lati inu nọmba ojuami ti nfofo.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // awọn aladugbo: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode nigbagbogbo ṣe itọju olutapa, nitorinaa mantissa ti ni iwọn fun awọn abẹ-kekere.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // awọn aladugbo: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ibiti maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // awọn aladugbo: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}