//! Awọn oriṣi aṣiṣe fun iyipada si awọn oriṣi akopọ.

use crate::convert::Infallible;
use crate::fmt;

/// Iru aṣiṣe naa pada nigbati iyipada iru ẹya ti o ṣayẹwo ti kuna.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Baramu dipo ki o fi ipa mu lati rii daju pe koodu bi `From<Infallible> for TryFromIntError` loke yoo ma ṣiṣẹ nigbati `Infallible` di inagijẹ si `!`.
        //
        //
        match never {}
    }
}

/// Aṣiṣe eyi ti o le pada nigbati o ba n ṣatunṣe odidi kan.
///
/// A lo aṣiṣe yii bi iru aṣiṣe fun awọn iṣẹ `from_str_radix()` lori awọn oriṣi odidi atijo, bii [`i8::from_str_radix`].
///
/// # Owun to le fa
///
/// Laarin awọn idi miiran, `ParseIntError` le ṣee jabọ nitori ṣiwaju tabi tẹle aaye funfun ni okun okun fun apẹẹrẹ, nigbati o gba lati titẹwọle boṣewa.
///
/// Lilo ọna [`str::trim()`] ṣe idaniloju pe ko si aaye funfun kan ti o ku ṣaaju sisọ.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum lati tọju awọn oriṣiriṣi awọn aṣiṣe ti o le fa fifọ nọmba odidi kan lati kuna.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Iye ti n ṣatunwo ti ṣofo.
    ///
    /// Laarin awọn idi miiran, iyatọ yii ni yoo kọ nigba sisọ okun ti o ṣofo.
    Empty,
    /// Ni nomba ailopin ninu ọrọ rẹ.
    ///
    /// Laarin awọn idi miiran, iyatọ yii ni yoo kọ nigba sisọ okun ti o ni char ti kii ṣe ASCII.
    ///
    /// Iyatọ yii tun ti kọ nigbati `+` tabi `-` ti wa ni ipo aiṣedeede laarin okun boya funrararẹ tabi ni aarin nọmba kan.
    ///
    ///
    InvalidDigit,
    /// Ipọpọ tobi ju lati fipamọ ni oriṣi nọmba odidi.
    PosOverflow,
    /// Integer ti kere ju lati fipamọ ni iru odidi odidi.
    NegOverflow,
    /// Iye je Zero
    ///
    /// Iyatọ yii yoo jade ni okun nigbati okun ifọmọ ni iye ti odo, eyiti yoo jẹ arufin fun awọn oriṣi ti kii-odo.
    ///
    Zero,
}

impl ParseIntError {
    /// Awọn abajade ohun ti o fa alaye ti sisọ odidi odidi kan kuna.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}