//! Iyipada awọn okun eleemewa sinu awọn nọmba ojuami alakomeji lilefoofo IEEE 754.
//!
//! # Alaye iṣoro
//!
//! A fun wa ni okun eleemewa bii `12.34e56`.
//! Okun yii ni (`12`) odidi, ida (`34`), ati awọn ẹya (`56`) olutapa.Gbogbo awọn apakan jẹ aṣayan ati tumọ bi odo nigbati o nsọnu.
//!
//! A wa nọmba nọmba IEEE 754 lilefoofo ti o sunmọ si iye gangan ti okun eleemewa.
//! O ti wa ni mimọ pe ọpọlọpọ awọn okun eleemewa ko ni awọn aṣoju ipari ni ipilẹ meji, nitorinaa a yika si awọn ẹya 0.5 ni aaye to kẹhin (ni awọn ọrọ miiran, bakanna bi o ti ṣee).
//! Awọn ibatan, awọn iye eleemewa gangan ọna idaji laarin awọn fifa itẹlera meji, ni a yanju pẹlu igbimọ idaji-si-ani, ti a tun mọ ni iyipo ti banki.
//!
//! Tialesealaini lati sọ, eyi jẹ ohun lile, mejeeji ni awọn ofin ti idiju imuse ati ni awọn ofin ti awọn iyipo Sipiyu ti o ya.
//!
//! # Implementation
//!
//! Ni akọkọ, a foju awọn ami.Tabi dipo, a yọ kuro ni ibẹrẹ pupọ ti ilana iyipada ati tun-fi sii ni ipari pupọ.
//! Eyi jẹ deede ni gbogbo awọn iṣẹlẹ edge nitori awọn floats IEEE jẹ iṣedogba ni ayika odo, aifiyesi ọkan kan yiyọ bit akọkọ.
//!
//! Lẹhinna a yọ aaye eleemewa kuro nipasẹ ṣiṣatunṣe olutaja: Ni imọran, `12.34e56` yipada si `1234e54`, eyiti a ṣe apejuwe pẹlu odidi odidi `f = 1234` ati odidi `e = 54` kan.
//! Aṣoju `(f, e)` ni a lo nipasẹ fere gbogbo koodu ti o kọja ipele itusilẹ.
//!
//! Lẹhinna a gbiyanju ẹwọn gigun ti ilọsiwaju siwaju sii gbogbogbo ati awọn ọran pataki ti o gbowolori nipa lilo awọn odidi ti o jẹ iwọn ẹrọ ati kekere, awọn nọmba aaye ti o ṣan loju omi ti o wa titi (`f32`/`f64` akọkọ, lẹhinna iru pẹlu 64 pataki pataki, `Fp`).
//!
//! Nigbati gbogbo awọn wọnyi ba kuna, a jẹ ọta ibọn naa ki a lọ si alugoridimu ti o rọrun ṣugbọn ti o lọra pupọ ti o ni iširo `f * 10^e` ni kikun ati ṣiṣe wiwa aiyipada fun isunmọ to dara julọ.
//!
//! Ni akọkọ, module yii ati awọn ọmọ rẹ ṣe awọn alugoridimu ti a sapejuwe ninu:
//! "How to Read Floating Point Numbers Accurately" nipasẹ William D.
//! Clinger, wa lori ayelujara: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Ni afikun, awọn iṣẹ oluranlọwọ lọpọlọpọ lo wa ti a lo ninu iwe ṣugbọn ko si ni Rust (tabi o kere ju ni ipilẹ).
//! Ẹya wa jẹ afikun ohun idiju nipasẹ iwulo lati mu iṣan-omi ati ṣiṣan silẹ ati ifẹ lati mu awọn nọmba alailẹgbẹ.
//! Bellerophon ati Alugoridimu R ni wahala pẹlu ṣiṣan, awọn abuku kekere, ati ṣiṣan omi.
//! A yipada laipẹ si Alugoridimu M (pẹlu awọn iyipada ti a ṣalaye ni apakan 8 ti iwe naa) daradara ṣaaju ki awọn igbewọle wọle si agbegbe pataki.
//!
//! Apa miiran ti o nilo ifojusi ni `RawFloat` trait nipasẹ eyiti o fẹrẹ jẹ pe gbogbo awọn iṣẹ ni a fi aṣẹ ṣe.Ẹnikan le ronu pe o to lati ṣe itupalẹ si `f64` ki o sọ abajade si `f32`.
//! Laanu eyi kii ṣe agbaye ti a n gbe, ati pe eyi ko ni nkankan lati ṣe pẹlu lilo ipilẹ meji tabi idaji-si-ani iyipo.
//!
//! Ro fun apẹẹrẹ awọn oriṣi meji `d2` ati `d4` ti o nsoju iru eleemewa pẹlu awọn nomba eleemewa meji ati awọn nomba eleemewa mẹrin kọọkan ati mu "0.01499" bi titẹ sii.Jẹ ki a lo ikotan-idaji.
//! Lilọ taara si awọn nomba eleemewa meji n fun `0.01`, ṣugbọn ti a ba yika si awọn nọmba mẹrin akọkọ, a gba `0.0150`, eyiti o yika lẹhinna si `0.02`.
//! Ilana kanna kan si awọn iṣiṣẹ miiran bakanna, ti o ba fẹ deede 0.5 ULP o nilo lati ṣe *ohun gbogbo* ni pipe ni kikun ati yika *ni ẹẹkan, ni ipari*, nipa gbigbero gbogbo awọn gige gige ni ẹẹkan.
//!
//! FIXME: Botilẹjẹpe awọn ẹda koodu kan ṣe pataki, boya awọn apakan ti koodu le ṣee dapọ ni ayika iru pe koodu ti o kere si ni ẹda.
//! Awọn ẹya nla ti awọn alugoridimu jẹ ominira ti iru ọkọ oju omi lati gbejade, tabi nikan nilo iraye si awọn aduro diẹ, eyiti o le kọja bi awọn ipilẹ.
//!
//! # Other
//!
//! Iyipada yẹ ki o *ko* panic.
//! Awọn itẹnumọ wa ati panics ti o fojuhan ninu koodu, ṣugbọn wọn ko gbọdọ jẹ ki o ṣiṣẹ ki o ṣiṣẹ nikan bi awọn sọwedowo mimọ ti inu.Eyikeyi panics yẹ ki o ka kokoro.
//!
//! Awọn idanwo sipo wa ṣugbọn wọn ko kunju aiṣe deede ni idaniloju titọ, wọn nikan bo ipin kekere ti awọn aṣiṣe ti o ṣeeṣe.
//! Awọn idanwo sanlalu diẹ sii wa ni itọsọna `src/etc/test-float-parse` bi iwe afọwọkọ Python.
//!
//! Akiyesi lori ṣiṣan odidi odidi: Ọpọlọpọ awọn apakan ti faili yii ṣe iṣiro pẹlu oniduro eleemewa `e`.
//! Ni akọkọ, a yipada aaye nomba eleemewa ni ayika: Ṣaaju nomba eleemewa akọkọ, lẹhin nomba eleemewa to kẹhin, ati bẹbẹ lọ.Eyi le ṣan silẹ ti o ba ṣe aibikita.
//! A gbẹkẹle igbẹkẹle atunyẹwo lati fun awọn onitẹ kekere kekere nikan ni ọwọ, nibiti "sufficient" tumọ si "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! A gba awọn olutayo nla julọ, ṣugbọn a ko ṣe iṣiro pẹlu wọn, wọn yipada lẹsẹkẹsẹ si {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Awọn meji wọnyi ni awọn idanwo tiwọn.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Yi awọn okun pada ni ipilẹ 10 si leefofo loju omi.
            /// Gba agbasọ eleemewa yiyan.
            ///
            /// Iṣẹ yii gba awọn okun bii
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', tabi deede, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', tabi, ni deede, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Asiwaju ati itọpa aaye funfun jẹ aṣoju aṣiṣe kan.
            ///
            /// # Grammar
            ///
            /// Gbogbo awọn okun ti o faramọ ilo-ọrọ [EBNF] atẹle yii yoo mu ki a pada [`Ok`] pada:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Awọn idun ti a mọ
            ///
            /// Ni diẹ ninu awọn ipo, diẹ ninu awọn okun ti o yẹ ki o ṣẹda leefofo to wulo dipo pada aṣiṣe kan.
            /// Wo [issue #31407] fun awọn alaye.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Okun kan
            ///
            /// # Pada iye
            ///
            /// `Err(ParseFloatError)` ti okun ko ba ṣe aṣoju nọmba to wulo.
            /// Bibẹẹkọ, `Ok(n)` nibiti `n` jẹ nọmba nọmba ti lilefoofo ti `src` ṣe aṣoju.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Aṣiṣe eyi ti o le pada nigbati o ba ṣafọ omi kan.
///
/// A lo aṣiṣe yii bi iru aṣiṣe fun imuse [`FromStr`] fun [`f32`] ati [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Pin okun eleemewa kan si ami ati iyoku, laisi ṣayẹwo tabi fọwọsi isinmi.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Ti okun ba jẹ asan, a ko lo ami naa, nitorinaa a ko nilo lati ṣe afọwọsi nihin.
        _ => (Sign::Positive, s),
    }
}

/// Yi awọn okun eleemewa kan pada si nọmba aaye ti lilefoofo.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Iṣe iṣẹ akọkọ fun iyipada eleemewa-si-float: Ṣeto gbogbo iṣaaju ati ṣayẹwo iru algorithm yẹ ki o ṣe iyipada gangan.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift jade ni nomba eleemewa.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 ni opin si awọn gige 1280, eyiti o tumọ si nipa awọn nomba eleemewa 385.
    // Ti a ba kọja eyi, a yoo jamba, nitorinaa a ṣe aṣiṣe ṣaaju ki o to sunmọ (laarin 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Bayi olutaja dajudaju ni ibamu ni 16 bit, eyiti o lo jakejado awọn alugoridimu akọkọ.
    let e = e as i16;
    // FIXME Awọn aala wọnyi jẹ kuku Konsafetifu.
    // Itupalẹ iṣọra diẹ sii ti awọn ipo ikuna ti Bellerophon le gba laaye lilo rẹ ni awọn ọran diẹ sii fun iyara pupọ.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Gẹgẹbi a ti kọ, eyi n mu ki o dara julọ (wo #27130, botilẹjẹpe o tọka si ẹya atijọ ti koodu naa).
// `inline(always)` jẹ iṣẹ-ṣiṣe fun eyi.
// Awọn aaye ipe meji nikan ni o wa lapapọ ati pe ko jẹ ki iwọn koodu buru si.

/// Rirọ awọn odo nibiti o ti ṣee ṣe, paapaa nigbati eyi nilo iyipada olutaja
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Ige awọn odo wọnyi ko yi ohunkohun pada ṣugbọn o le jẹ ki ọna iyara (<awọn nọmba 15) jẹki.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Ṣe simplify awọn nọmba fọọmu 0.0 ... x ati x ... 0.0, n ṣatunṣe olutawe ni ibamu.
    // Eyi le ma jẹ igbagbogbo win (o ṣee ṣe awọn nọmba diẹ sii kuro ni ọna yara), ṣugbọn o jẹ ki awọn ẹya miiran rọrun ni pataki (paapaa, isunmọ titobi iye naa).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Pada ọna asopọ oke-idọti ti iyara-lori iwọn (log10) ti iye ti o tobi julọ ti Alugoridimu R ati Alugoridimu M yoo ṣe iṣiro lakoko ti n ṣiṣẹ lori nomba eleemewa ti a fifun.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // A ko nilo lati ṣe aniyan pupọ julọ nipa ṣiṣan nibi ọpẹ si trivial_cases() ati parser, eyiti o ṣe àlẹmọ awọn igbewọle ti o ga julọ julọ fun wa.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Ninu ọran e>=0, awọn alugoridimu mejeeji ṣe iṣiro nipa `f * 10^e`.
        // Alugoridimu R tẹsiwaju lati ṣe diẹ ninu awọn iṣiro idiju pẹlu eyi ṣugbọn a le foju iyẹn fun opin oke nitori pe o tun dinku ida tẹlẹ, nitorinaa a ni ifiṣura lọpọlọpọ nibẹ.
        //
        f_len + (e as u64)
    } else {
        // Ti e <0, Alugoridimu R ṣe ni aijọju ohun kanna, ṣugbọn Alugoridimu M yatọ:
        // O gbiyanju lati wa nọmba rere kan k bii `f << k / 10^e` jẹ pataki laini-ibiti o wa.
        // Eyi yoo ja si nipa `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Iwọle kan ti o fa eyi jẹ 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Ṣe afẹri ṣiṣan ṣiṣan ati ṣiṣan ṣiṣan laisi ani nwa awọn nomba eleemewa.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Awọn odo wa ṣugbọn wọn ti ya nipasẹ simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Eyi jẹ isunmọ robi ti ceil(log10(the real value)).
    // A ko nilo lati ṣe aniyan pupọ pupọ nipa ṣiṣan nihin nitori gigun titẹsi jẹ aami (o kere ju akawe si 2 ^ 64) ati pe parser ti ṣakoso awọn alatako ti iye idiwọn tobi ju 10 ^ 18 (eyiti o tun jẹ 10 ^ 19 kukuru ti 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}