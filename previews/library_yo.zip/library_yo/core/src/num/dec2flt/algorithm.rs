//! Awọn orisirisi aligoridimu lati iwe.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nọmba ti pataki ati awọn idinku ninu Fp
const P: u32 = 64;

// A kan tọju isunmọ ti o dara julọ fun * gbogbo awọn olutayo, nitorinaa oniyipada "h" ati awọn ipo ti o jọmọ le jẹyọ.
// Eyi ṣe iṣẹ ṣiṣe fun awọn kilobytes tọkọtaya ti aaye.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Ni ọpọlọpọ awọn ayaworan, awọn iṣẹ aaye lilefoofo ni iwọn bit ti o fojuhan, nitorinaa konge ti iširo ti pinnu lori ipilẹ iṣẹ-ṣiṣe kan.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Lori x86, x87 FPU ti lo fun awọn iṣẹ leefofo ti awọn ifaagun SSE/SSE2 ko ba si.
// x87 FPU n ṣiṣẹ pẹlu awọn ipin 80 ti konge nipasẹ aiyipada, eyi ti o tumọ si pe awọn iṣẹ yoo yika si awọn idinku 80 ti o mu ki iyipo ilọpo meji ṣẹlẹ nigbati awọn idiyele ba ni aṣoju nikẹhin bi
//
// 32/64 bit leefofo iye.Lati bori eyi, ọrọ iṣakoso FPU le ṣee ṣeto ki a le ṣe awọn iṣiro ni titọ to fẹ.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Eto kan ti a lo lati tọju iye atilẹba ti ọrọ iṣakoso FPU, ki o le pada sipo nigbati eto naa ba lọ silẹ.
    ///
    ///
    /// x87 FPU jẹ iforukọsilẹ awọn idinku 16 kan ti awọn aaye rẹ jẹ atẹle:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Iwe naa fun gbogbo awọn aaye wa ni Afowoyi Olumulo Olùgbéejáde Software Architectures IA-32 (Iwọn didun 1).
    ///
    /// Aaye nikan ti o ṣe pataki fun koodu atẹle ni PC, Iṣakoso konge.
    /// Aaye yii pinnu ipinnu ti awọn iṣẹ ti FPU ṣe.
    /// O le ṣeto si:
    ///  - 0b00, konge ẹyọkan ie, 32-bit
    ///  - 0b10, išedede ilọpo meji ie, 64-bit
    ///  - 0b11, ijuwe gigun ti o gbooro ie, 80-bit (ipo aiyipada) Iye 0b01 ti wa ni ipamọ ati pe ko yẹ ki o lo.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // Aabo: Ilana ti `fldcw` ti wa ni ayewo lati ni anfani lati ṣiṣẹ ni deede pẹlu
        // eyikeyi `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: A nlo sintasi ATT lati ṣe atilẹyin LLVM 8 ati LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Ṣeto aaye ijuwe ti FPU si `T` o si da `FPUControlWord` kan pada.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Ṣe iṣiro iye fun aaye Iṣakoso Precision ti o yẹ fun `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 die-die
            8 => 0x0200, // 64 die-die
            _ => 0x0300, // aiyipada, 80 die-die
        };

        // Gba iye atilẹba ti ọrọ iṣakoso lati mu pada pada nigbamii, nigbati ọna `FPUControlWord` ba lọ silẹ Aabo: a ti ṣayẹwo iwe ilana `fnstcw` lati le ṣiṣẹ ni deede pẹlu eyikeyi `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: A nlo sintasi ATT lati ṣe atilẹyin LLVM 8 ati LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Ṣeto ọrọ iṣakoso si iṣedede ti o fẹ.
        // Eyi ni aṣeyọri nipasẹ iboju-boju kuro ni titọ atijọ (awọn iṣẹju 8 ati 9, 0x300) ati rirọpo pẹlu asia iširo to peye loke.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Ọna iyara ti Bellerophon nipa lilo awọn odidi titobi ẹrọ ati fifa omi.
///
/// Eyi ni a fa jade sinu iṣẹ lọtọ nitorinaa o le ṣe igbiyanju ṣaaju ṣiṣe bignum kan.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // A ṣe afiwe iye deede si MAX_SIG nitosi ipari, eyi jẹ iyara kan, ijusile olowo poku (ati tun sọ iyoku koodu kuro lati ṣàníyàn nipa ṣiṣan omi).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Ọna ti o yara ni pataki da lori iṣiro ti o yika si nọmba ti o tọ ti awọn idinku laisi eyikeyi iyipo agbedemeji.
    // Lori x86 (laisi SSE tabi SSE2) eyi nilo deede ti akopọ x87 FPU lati yipada ki o taara yika si bit 64/32.
    // Iṣẹ `set_precision` n ṣetọju ti ṣeto iṣedede lori awọn ayaworan ile eyiti o nilo iṣeto rẹ nipa yiyipada ipo kariaye (bii ọrọ iṣakoso ti x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ọran e <0 ko le ṣe pọ si branch miiran.
    // Awọn agbara odi ni abajade ipin apakan tun ni alakomeji, eyiti o yika, eyiti o fa awọn aṣiṣe gidi (ati lẹẹkọọkan ohun pataki!) Ni abajade ikẹhin.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Alugoridimu Bellerophon jẹ koodu aibikita lare nipasẹ onínọmbà nomba ti ko ṣe pataki.
///
/// O yika `f` si leefofo pẹlu itumọ 64 diẹ ati pe o pọ si nipasẹ isunmọ ti o dara julọ ti `10^e` (ni ọna kika oju omi kanna).Eyi nigbagbogbo to lati gba abajade to pe.
/// Sibẹsibẹ, nigbati abajade ba sunmọ to agbedemeji laarin awọn lilefoofo (ordinary) ti o wa nitosi, aṣiṣe iyipo apopọ lati isodipupo isunmọ meji tumọ si abajade le ti wa ni pipa nipasẹ awọn idinku diẹ.
/// Nigbati eyi ba ṣẹlẹ, Alugoridimu iyipo R n ṣatunṣe awọn nkan.
///
/// Wa00-wavy wavy ti wa ni kongẹ nipasẹ iṣiro nọmba ninu iwe naa.
/// Ninu awọn ọrọ ti Clinger:
///
/// > Slop, ti a fihan ni awọn sipo ti o kere pupọ ti o kere julọ, jẹ alailẹgbẹ idapọ fun aṣiṣe naa
/// > ti kojọpọ lakoko iṣiro ojuami aaye lilefoofo ti isunmọ si f * 10 ^ e.(Slop jẹ
/// > kii ṣe adehun fun aṣiṣe otitọ, ṣugbọn ṣe idiwọn iyatọ laarin isunmọ z ati
/// > isunmọ ti o dara julọ ti o ṣee ṣe ti o lo awọn ipin p ti pataki.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Awọn ọran abs(e) <log5(2^N) wa ni fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Njẹ oke naa tobi to lati ṣe iyatọ nigbati o ba n yika si awọn idinku n?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Alugoridimu ṣiṣiṣẹ ti o mu ki isunmọ aaye lilefoofo ti `f * 10^e`.
///
/// Ilọkuro kọọkan n gba ọkan kuro ni aaye to sunmọ, eyiti o dajudaju o gba pipẹ pupọ lati ṣopọ ti `z0` paapaa jẹ kekere ni pipa.
/// Ni Oriire, nigba lilo bi isubu fun Bellerophon, isunmọ ibẹrẹ jẹ pipa nipasẹ o pọju ULP kan.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Wa awọn nọmba odidi `x`, `y` bii `x / y` jẹ `(f *10^e) / (m* 2^k)` gangan.
        // Eyi kii ṣe yago fun ṣiṣe pẹlu awọn ami ti `e` ati `k` nikan, a tun yọkuro agbara ti o wọpọ meji si `10^e` ati `2^k` lati jẹ ki awọn nọmba naa kere.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Eyi ni a kọ ni irọrun diẹ nitori awọn ami-akọọlẹ wa ko ṣe atilẹyin awọn nọmba odi, nitorinaa a lo iye iye + alaye iforukọsilẹ.
        // Isodipupo pelu m_digits ko le bori.
        // Ti `x` tabi `y` ba tobi to ti a nilo lati ṣe aniyan nipa ṣiṣan, lẹhinna wọn tun tobi to pe `make_ratio` ti dinku ida nipasẹ ifosiwewe ti 2 ^ 64 tabi diẹ sii.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ko nilo x eyikeyi diẹ sii, fipamọ clone() kan.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Tun nilo y, ṣe ẹda kan.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Ti a fun ni `x = f` ati `y = m` nibiti `f` ṣe ṣe aṣoju awọn nomba eleemewa titẹ sii bi iṣe deede ati `m` jẹ pataki ti isunmọ aaye oju omi, ṣe ipin `x / y` dogba si `(f *10^e) / (m* 2^k)`, o ṣee ṣe dinku nipasẹ agbara ti awọn mejeeji ni o wọpọ.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ayafi pe a dinku ida nipasẹ agbara diẹ ninu awọn meji.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Eyi ko le ṣan nitori o nilo `e` rere ati odi `k`, eyiti o le ṣẹlẹ nikan fun awọn iye ti o sunmọ 1 pupọ, eyiti o tumọ si pe `e` ati `k` yoo jẹ aami kekere.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Eyi ko le bori boya, wo loke.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), tun dinku nipasẹ agbara apapọ ti meji.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Ni idaniloju, Alugoridimu M jẹ ọna ti o rọrun julọ lati ṣe iyipada eleemewa si leefofo kan.
///
/// A ṣe agbekalẹ ipin kan ti o dọgba si `f * 10^e`, lẹhinna sisọ si awọn agbara ti meji titi yoo fi funni ni iwulo lilefoofo to wulo.
/// Olupilẹṣẹ alakomeji `k` ni nọmba awọn igba ti a pọ nọmba tabi iyeida nipasẹ meji, ie, ni gbogbo igba `f *10^e` jẹ deede `(u / v)* 2^k`.
/// Nigbati a ba ti rii pataki, a nilo lati yika nikan nipa ṣiṣayẹwo iyokuro pipin, eyiti o ṣe ni awọn iṣẹ oluranlọwọ siwaju si isalẹ.
///
///
/// Alugoridimu yii jẹ o lọra pupọ, paapaa pẹlu iṣapeye ti a ṣalaye ninu `quick_start()`.
/// Sibẹsibẹ, o jẹ rọọrun julọ ti awọn alugoridimu lati ṣe deede fun iṣan-omi, ṣiṣan, ati awọn abajade alailẹgbẹ.
/// Imuse yii gba nigba ti Bellerophon ati Alugoridimu R ti bori.
/// Wiwa ṣiṣan omi ati ṣiṣan omi jẹ rọrun: Iwọn naa ko tun jẹ pataki larin-ibiti, sibẹsibẹ a ti de olutapa minimum/maximum.
/// Ninu ọran ṣiṣanju, a kan pada ailopin.
///
/// Mimu ṣiṣan omi labẹ ati awọn subnormals jẹ ti ẹtan.
/// Iṣoro nla kan ni pe, pẹlu olutaja to kere julọ, ipin naa le tun tobi pupọ fun pataki.
/// Wo underflow() fun awọn alaye.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ti o ṣee ṣe dara julọ: ṣakopọ big_to_fp ki a le ṣe deede ti fp_to_float(big_to_fp(u)) nibi, nikan laisi iyipo meji.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // A ni lati duro ni olutaja to kere julọ, ti a ba duro de `k < T::MIN_EXP_INT`, lẹhinna a yoo wa ni pipa nipasẹ ifosiwewe meji.
            // Laanu eyi tumọ si pe a ni lati ṣe pataki-ṣe idajọ awọn nọmba deede pẹlu olutaja to kere julọ.
            // FIXME wa agbekalẹ ẹlẹwa diẹ sii, ṣugbọn ṣiṣe idanwo `tiny-pow10` lati rii daju pe o tọ ni otitọ!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Foo lori ọpọlọpọ awọn aṣetunṣe Alugoridimu M nipa ṣayẹwo gigun gigun.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Gigun bit jẹ iṣiro ti ipilẹ logarithm meji, ati log(u / v) = log(u), log(v).
    // Iṣiro naa ti wa ni pipa nipasẹ o pọju 1, ṣugbọn nigbagbogbo iṣiro-labẹ, nitorinaa aṣiṣe lori log(u) ati log(v) jẹ ami ami kanna ati fagilee (ti awọn mejeeji ba tobi).
    // Nitorinaa aṣiṣe fun log(u / v) jẹ pupọ julọ bakanna.
    // Ipilẹ ibi-afẹde jẹ ọkan nibiti u/v wa ninu pataki ibiti o wa.Nitorinaa ipo ifopinsi wa jẹ log2(u / v) jẹ pataki ati awọn idinku, plus/minus ọkan.
    // FIXME Nwa ni bit keji le ṣe ilọsiwaju iṣiro naa ki o yago fun diẹ ninu awọn ipin diẹ sii.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow tabi subnormal.Fi silẹ si iṣẹ akọkọ.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Apọju.Fi silẹ si iṣẹ akọkọ.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ipin kii ṣe pataki ni ibiti o wa pẹlu agbasọ ti o kere julọ, nitorinaa a nilo lati yika awọn idinku to pọ julọ ati ṣatunṣe olutaja ni ibamu.
    // Iye gidi ni bayi dabi eleyi:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(ni ipoduduro nipasẹ rem)
    //
    // Nitorinaa, nigbati awọn iyipo ti o yika jẹ!= 0.5 ULP, wọn pinnu iyipo funrarawọn.
    // Nigbati wọn ba dọgba ati pe iyoku kii ṣe odo, iye naa tun nilo lati yika.
    // Nikan nigbati awọn idinku ti o yika jẹ 1/2 ati pe iyoku jẹ odo, a ni ipo idaji-si-paapaa.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Arin-si-ani deede, obfuscated nipasẹ nini yika ti o da lori iyoku pipin kan.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}