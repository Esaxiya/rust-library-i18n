//! Ṣe afọwọsi ati jijo okun eleemewa ti fọọmu naa:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ni awọn ọrọ miiran, iṣiro sita-ọrọ oju-omi boṣewa, pẹlu awọn imukuro meji: Ko si ami, ko si si mimu ti "inf" ati "NaN".Awọn wọnyi ni o ṣakoso nipasẹ iṣẹ iwakọ (super::dec2flt).
//!
//! Biotilẹjẹpe riri awọn igbewọle ti o wulo jẹ irọrun rọrun, module yii tun ni lati kọ awọn ainiye ainiye awọn iyatọ, rara panic, ati ṣe awọn iṣayẹwo lọpọlọpọ ti awọn modulu miiran gbekele kii ṣe panic (tabi ṣiṣan) ni titan.
//!
//! Lati mu ki ọrọ buru, gbogbo nkan ti o ṣẹlẹ ni ẹyọkan kọja lori kikọ sii.
//! Nitorinaa, ṣọra nigbati o ba n ṣatunṣe ohunkohun, ati ṣayẹwo-lẹẹmeeji pẹlu awọn modulu miiran.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Awọn ẹya ti o nifẹ si okun eleemewa kan.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Olutapa eleemewa, onigbọwọ lati ni kere ju awọn nomba eleemewa 18.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Awọn iṣayẹwo ti okun ifawọle jẹ nọmba ojuami ti nfomi loju omi ti o ba jẹ bẹẹ, wa apakan ti o jẹ apakan, apakan ida, ati alatako ninu rẹ.
/// Ko mu awọn ami.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Ko si awọn nọmba ṣaaju 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // A nilo o kere ju nọmba kan ṣaaju tabi lẹhin aaye.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Tọpa ijekuje lẹhin apakan ida
            }
        }
        _ => Invalid, // Tọpa pata lẹhin okun nọmba akọkọ
    }
}

/// Carves kuro nomba eleemewa titi de ohun kikọ ti kii ṣe nọmba akọkọ.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Iyọkuro Alabo ati ṣayẹwo aṣiṣe.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Tracking ijekuje lẹhin ti olutayo
    }
    if number.is_empty() {
        return Invalid; // Ṣofo olutayo
    }
    // Ni aaye yii, dajudaju a ni okun to wulo ti awọn nọmba.O le gun ju lati fi sinu `i64` kan, ṣugbọn ti o ba tobi pupọ, titẹ sii jẹ esan tabi ailopin.
    // Niwọn igba ti odo kọọkan ninu nomba nomba eleemewa n ṣatunṣe olutaja nipasẹ +/-1, ni exp=10 the 18 igbewọle yoo ni lati jẹ 17 exabyte (!) ti awọn odo lati sunmọ paapaa latọna jijin lati sunmọ opin.
    //
    // Eyi kii ṣe ọran lilo gangan ti a nilo lati ṣaajo si.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}