//! Awọn iṣẹ anfani fun awọn bignums ti ko ni oye pupọ lati yipada si awọn ọna.

// FIXME Orukọ module yii jẹ aibanujẹ diẹ, nitori awọn modulu miiran tun gbe `core::num` wọle.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Idanwo boya yiyọ gbogbo awọn idinku ti ko ṣe pataki ju `ones_place` ṣafihan aṣiṣe ibatan kan kere, dogba, tabi tobi ju 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ti gbogbo awọn idinku ti o ku ba jẹ odo, o jẹ= 0.5 ULP, bibẹkọ ti> 0.5 Ti ko ba si awọn idinku diẹ sii (half_bit==0), isalẹ tun tọ Dọgba ni deede.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Yipada okun ASCII kan ti o ni awọn nomba eleemewa nikan si `u64` kan.
///
/// Ko ṣe awọn sọwedowo fun ṣiṣan tabi awọn ohun kikọ ti ko wulo, nitorinaa ti olupe naa ko ba ṣọra, abajade jẹ iro ati pe o le panic (botilẹjẹpe kii yoo jẹ `unsafe`).
/// Ni afikun, awọn okun ofo ni a tọju bi odo.
/// Iṣẹ yii wa nitori
///
/// 1. lilo `FromStr` lori `&[u8]` nilo `from_utf8_unchecked`, eyiti o buru, ati
/// 2. sisẹ awọn abajade ti `integral.parse()` ati `fractional.parse()` pọ sii ju idiju lọ ju gbogbo iṣẹ yii lọ.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Iyipada okun ti awọn nọmba ASCII sinu bignum kan.
///
/// Bii `from_str_unchecked`, iṣẹ yii gbarale parser lati yọ jade awọn nọmba ti kii ṣe nọmba.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Ṣi i bignum sinu odidi odidi 64 kan.Panics ti nọmba naa ba tobi ju.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Fa jade a ibiti o ti die-die.

/// Atọka 0 jẹ ohun ti o ṣe pataki ti o kere ju ati pe ibiti o wa ni sisi idaji bi o ṣe deede.
/// Panics ti o ba beere lati fa awọn idinku diẹ sii ju ti o baamu si iru ipadabọ.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}