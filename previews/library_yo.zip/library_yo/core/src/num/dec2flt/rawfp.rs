//! Bit fiddling lori rere IEEE 754 floats.Awọn nọmba odi ko si ati pe ko nilo lati ṣe mu.
//! Awọn nọmba aaye lilefoofo deede ni aṣoju oniduro bi (frac, exp) bii pe iye jẹ 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) nibiti N jẹ nọmba awọn idinku.
//!
//! Subnormals jẹ oriṣiriṣi oriṣiriṣi ati ajeji, ṣugbọn ilana kanna kan.
//!
//! Nibi, sibẹsibẹ, a ṣe aṣoju wọn bi (sig, k) pẹlu f rere, bii pe iye jẹ f *
//! 2 <sup>e</sup> .Yato si ṣiṣe "hidden bit" fojuhan, eyi ṣe ayipada olutapa nipasẹ iyipada ti a pe ni mantissa.
//!
//! Fi ọna miiran sii, deede a ti kọ awọn floats bi (1) ṣugbọn nibi wọn ti kọ wọn bi (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! A pe (1) ni aṣoju ida **ati (2) ni aṣoju isopọ**.
//!
//! Ọpọlọpọ awọn iṣẹ inu module yii nikan mu awọn nọmba deede.Awọn ipa ọna dec2flt ni ilodisi gba ọna ti o lọra ti o tọ ni gbogbo agbaye (Alugoridimu M) fun awọn nọmba ti o kere pupọ ati pupọ.
//! Alugoridimu yẹn nilo next_float() nikan eyiti o mu awọn subnormals ati awọn odo.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Oluranlọwọ trait lati yago fun ẹda ẹda ni ipilẹ gbogbo koodu iyipada fun `f32` ati `f64`.
///
/// Wo asọye doc ti modulu obi fun idi ti eyi fi ṣe pataki.
///
/// Yẹ ki o **ko lailai** ṣe imuse fun awọn oriṣi miiran tabi ṣee lo ni ita modulu dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Iru ti `to_bits` ati `from_bits` lo.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Ṣe transmutation aise si odidi.
    fn to_bits(self) -> Self::Bits;

    /// Ṣe transmutation aise lati odidi kan.
    fn from_bits(v: Self::Bits) -> Self;

    /// Pada ẹka ti nọmba yii ṣubu sinu.
    fn classify(self) -> FpCategory;

    /// Pada mantissa, olutayo ati ami bi odidi.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Awọn ipinnu awọn leefofo loju omi.
    fn unpack(self) -> Unpacked;

    /// Awọn adarọ lati nọmba odidi kekere ti o le ṣe aṣoju gangan.
    /// Panic ti odidi ko ba ṣe aṣoju, koodu miiran ti o wa ninu module yii rii daju pe ko jẹ ki iyẹn ṣẹlẹ.
    fn from_int(x: u64) -> Self;

    /// Gba iye 10 <sup>e</sup> lati ori tabili ti a ṣaju tẹlẹ.
    /// Panics fun `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ohun ti orukọ naa sọ.
    /// O rọrun lati ṣe koodu lile ju jijini awọn ojulowo ati nireti ireti LLVM nigbagbogbo ṣe pọ rẹ.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Aṣoju Konsafetifu kan lori awọn nomba eleemewa ti awọn igbewọle ti ko le ṣe agbejade tabi odo tabi
    /// subnormals.O ṣee ṣe pe agbasọ eleemewa ti iye deede to pọ julọ, nitorinaa orukọ naa.
    const MAX_NORMAL_DIGITS: usize;

    /// Nigbati nomba eleemewa ti o se pataki julo ni iye aye ti o tobi ju eyi lo, o daju pe nomba na yika si ailopin.
    ///
    const INF_CUTOFF: i64;

    /// Nigbati nomba eleemewa ti o se pataki julo ni iye aye ti o kere si eyi, nọmba naa ni o yika yika si odo.
    ///
    const ZERO_CUTOFF: i64;

    /// Nọmba awọn idinku ninu olutayo.
    const EXP_BITS: u8;

    /// Nọmba awọn idinku ninu pataki,*pẹlu* bit ti o farapamọ.
    const SIG_BITS: u8;

    /// Nọmba awọn idinku ninu pataki, * laisi ifipamọ bit ti o farasin.
    const EXPLICIT_SIG_BITS: u8;

    /// Olupolowo ofin ti o pọ julọ ni aṣoju ida.
    const MAX_EXP: i16;

    /// Alatako ofin ti o kere julọ ni aṣoju ida, laisi awọn subnormals.
    const MIN_EXP: i16;

    /// `MAX_EXP` fun aṣoju oniduro, ie, pẹlu iyipada ti a lo.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ti yipada (ie, pẹlu aiṣedeede aiṣedeede)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` fun aṣoju oniduro, ie, pẹlu iyipada ti a lo.
    const MIN_EXP_INT: i16;

    /// Iwọn pataki iwuwasi ti o pọ julọ ni aṣoju oniduro.
    const MAX_SIG: u64;

    /// Iwọn iwuwasi ti o kere julọ ni aṣoju oniduro.
    const MIN_SIG: u64;
}

// Ni ọpọlọpọ iṣẹ-ṣiṣe fun #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Pada mantissa, olutayo ati ami bi odidi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Iyatọ ti onipindoje + iyipada mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe jẹ ṣiyemeji boya awọn iyipo `as` ni deede lori gbogbo awọn iru ẹrọ.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Pada mantissa, olutayo ati ami bi odidi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Iyatọ ti onipindoje + iyipada mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe jẹ ṣiyemeji boya awọn iyipo `as` ni deede lori gbogbo awọn iru ẹrọ.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Yi awọn `Fp` pada si iru ẹrọ ti leefofo loju omi ti o sunmọ julọ.
/// Ko mu awọn abajade alailẹgbẹ.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f jẹ bit 64, nitorinaa xe ni iyipada mantissa ti 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Yika pataki 64-bit si awọn idinku T::SIG_BITS pẹlu idaji-si-ani.
/// Ko mu apanirun apanirun.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Satunṣe ayipada mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Ni idakeji ti `RawFloat::unpack()` fun awọn nọmba to ṣe deede.
/// Panics ti o ba jẹ pe pataki tabi olutayo ko wulo fun awọn nọmba to ṣe deede.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Yọ nkan ti o farapamọ kuro
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Ṣatunṣe olutaja fun irẹjẹ onipata ati iyipada mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Fi ami kekere silẹ ni 0 ("+"), awọn nọmba wa jẹ gbogbo rere
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ṣe agbekalẹ alailẹgbẹ kan.A gba mantissa ti 0 laaye ati kọ odo.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Olufunni ti a yipada ni 0, ami ami jẹ 0, nitorinaa a ni lati tun tumọ awọn ege naa.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Isunmọ bignum pẹlu Fp kan.Awọn iyipo laarin 0.5 ULP pẹlu idaji-si-ani.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // A ge gbogbo awọn idinku ṣaaju si itọka `start`, ie, a ni iyipada ọtun ni agbara nipasẹ iye ti `start`, nitorinaa eyi tun jẹ olutaja ti a nilo.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Yika (half-to-even) da lori awọn idinku gige.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Wa nọmba nọmba lilefoofo ti o tobi ju ariyanjiyan lọ.
/// Ko mu awọn subnormals, odo, tabi alatako ṣiṣanwọle.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Wa nọmba nọmba ti lilefoofo ti o tobi ju ariyanjiyan lọ.
// Iṣẹ yii jẹ saturating, ie, next_float(inf) ==inf.
// Ko dabi koodu ti o pọ julọ ninu module yii, iṣẹ yii n mu odo, awọn abọ-akọọlẹ, ati ailopin.
// Sibẹsibẹ, bii gbogbo koodu miiran nibi, ko ṣe pẹlu NaN ati awọn nọmba odi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Eyi dabi pe o dara pupọ lati jẹ otitọ, ṣugbọn o ṣiṣẹ.
        // 0.0 ti wa ni koodu bi ọrọ gbogbo-odo.Awọn ohun alumọni ni 0x000m ... m nibiti m jẹ mantissa.
        // Ni pataki, alailẹgbẹ ti o kere julọ jẹ 0x0 ... 01 ati eyiti o tobi julọ ni 0x000F ... F.
        // Nọmba deede ti o kere julọ jẹ 0x0010 ... 0, nitorinaa ọran igun yii tun ṣiṣẹ.
        // Ti ilosoke naa ba ṣan kun mantissa, gbigbe diẹ yoo pọ si olutapa bi a ṣe fẹ, ati pe awọn iyọ mantissa naa di odo.
        // Nitori apejọ bit ti o farasin, eyi paapaa jẹ gangan ohun ti a fẹ!
        // Lakotan, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}