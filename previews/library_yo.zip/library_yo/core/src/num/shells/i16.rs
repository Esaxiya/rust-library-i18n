//! Awọn adaduro fun iru nọmba odidi ti o fowo si 16-bit.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Koodu tuntun yẹ ki o lo awọn adaduro ti o ni nkan taara lori oriṣi atijo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }