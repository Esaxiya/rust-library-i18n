//! Awọn adaduro fun iru nọmba odidi ti a ko wole si 32-bit.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! Koodu tuntun yẹ ki o lo awọn adaduro ti o ni nkan taara lori oriṣi atijo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }