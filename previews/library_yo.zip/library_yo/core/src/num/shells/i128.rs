//! Awọn adaduro fun iru nọmba odidi ti o fowo si 128-bit.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Koodu tuntun yẹ ki o lo awọn adaduro ti o ni nkan taara lori oriṣi atijo.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }