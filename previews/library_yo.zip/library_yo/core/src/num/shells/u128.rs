//! Awọn adaduro fun iru nọmba odidi ti a ko wọle si 128-bit.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Koodu tuntun yẹ ki o lo awọn adaduro ti o ni nkan taara lori oriṣi atijo.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }