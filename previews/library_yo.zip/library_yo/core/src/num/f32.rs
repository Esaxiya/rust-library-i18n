//! Awọn adaduro ni pato si iru aaye lilefoofo `f32` nikan.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Ti pese awọn nọmba to ṣe pataki nipa iṣeṣiro ni modulu iha-`consts`.
//!
//! Fun awọn adaduro ti a ṣalaye taara ni module yii (bii iyatọ si awọn ti a ṣalaye ninu modulu `consts`), koodu tuntun yẹ ki o dipo lo awọn adarọ ibatan ti o ṣalaye taara lori iru `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Awọn radix tabi ipilẹ ti aṣoju inu ti `f32`.
/// Lo [`f32::RADIX`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ọna ti a pinnu
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Nọmba awọn nọmba pataki ni ipilẹ 2.
/// Lo [`f32::MANTISSA_DIGITS`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ọna ti a pinnu
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Nọmba isunmọ ti awọn nọmba pataki ni ipilẹ 10.
/// Lo [`f32::DIGITS`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ọna ti a pinnu
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] iye fun `f32`.
/// Lo [`f32::EPSILON`] dipo.
///
/// Eyi ni iyatọ laarin `1.0` ati nọmba oniduro ti o tobi ti o tẹle.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ọna ti a pinnu
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Iwọn `f32` ti o kere julọ.
/// Lo [`f32::MIN`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ọna ti a pinnu
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Iyatọ ti o kere julọ deede `f32` iye.
/// Lo [`f32::MIN_POSITIVE`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ọna ti a pinnu
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Iye `f32` ti o pari ti o tobi julọ.
/// Lo [`f32::MAX`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ọna ti a pinnu
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Ọkan tobi ju agbara ti o ṣeeṣe ti o ṣeeṣe ti o ṣeeṣe ti olutapa 2.
/// Lo [`f32::MIN_EXP`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ọna ti a pinnu
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// O pọju ti ṣee ṣe agbara ti 2 olutayo.
/// Lo [`f32::MAX_EXP`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ọna ti a pinnu
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Agbara to ṣeeṣe ti o kere ju ti olutaja 10.
/// Lo [`f32::MIN_10_EXP`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ọna ti a pinnu
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// O pọju agbara ti o ṣeeṣe ti olutaja 10.
/// Lo [`f32::MAX_10_EXP`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ọna ti a pinnu
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Kii Nọmba (NaN) kan.
/// Lo [`f32::NAN`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ọna ti a pinnu
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Lo [`f32::INFINITY`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ọna ti a pinnu
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Ailopin ailopin (−∞).
/// Lo [`f32::NEG_INFINITY`] dipo.
///
/// # Examples
///
/// ```rust
/// // deprecated ọna
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ọna ti a pinnu
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Ipilẹ awọn iṣiro mathematiki.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: rọpo pẹlu awọn iṣiro mathematiki lati cmath.

    /// (π) nigbagbogbo ti Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Awọn ni kikun Circle ibakan (τ)
    ///
    /// Dogba si 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Nọmba Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Awọn radix tabi ipilẹ ti aṣoju inu ti `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Nọmba awọn nọmba pataki ni ipilẹ 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Nọmba isunmọ ti awọn nọmba pataki ni ipilẹ 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] iye fun `f32`.
    ///
    /// Eyi ni iyatọ laarin `1.0` ati nọmba oniduro ti o tobi ti o tẹle.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Iwọn `f32` ti o kere julọ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Iyatọ ti o kere julọ deede `f32` iye.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Iye `f32` ti o pari ti o tobi julọ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Ọkan tobi ju agbara ti o ṣeeṣe ti o ṣeeṣe ti o ṣeeṣe ti olutapa 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// O pọju ti ṣee ṣe agbara ti 2 olutayo.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Agbara to ṣeeṣe ti o kere ju ti olutaja 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// O pọju agbara ti o ṣeeṣe ti olutaja 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Kii Nọmba (NaN) kan.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Ailopin ailopin (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Pada `true` ti iye yii jẹ `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` ko si ni gbangba ni libcore nitori awọn ifiyesi nipa gbigbe, nitorinaa imuse yii jẹ fun lilo ikọkọ ni inu.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Pada `true` ti iye yii jẹ ailopin ailopin tabi ailopin odi, ati `false` bibẹẹkọ.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Pada `true` ti nọmba yii ko ba jẹ ailopin tabi `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ko si ye lati mu NaN lọtọ: ti ara ẹni ba jẹ NaN, ifiwera ko jẹ otitọ, gangan bi o ṣe fẹ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Pada `true` ti nọmba naa ba jẹ [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Awọn iye laarin `0` ati `min` jẹ Alailẹgbẹ.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Pada `true` ti nọmba naa ko ba jẹ odo, ailopin, [subnormal], tabi `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Awọn iye laarin `0` ati `min` jẹ Alailẹgbẹ.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Pada ẹka aaye lilefoofo ti nọmba naa.
    /// Ti ohun-ini kan nikan yoo ni idanwo, o jẹ gbogbo iyara lati lo asọtẹlẹ kan pato dipo.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Pada `true` ti `self` ba ni ami idaniloju kan, pẹlu `+0.0`, `NaN`s pẹlu ami ami rere ati ailopin rere.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Pada `true` ti `self` ba ni ami odi, pẹlu `-0.0`, `NaN` pẹlu ami ami odi ati ailopin odi.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 sọ pe: isSignMinus(x) jẹ otitọ ti o ba jẹ pe nikan ti x ba ni ami odi.
        // isSignMinus kan si awọn odo ati awọn NaN daradara.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Gba iyipo (inverse) ti nọmba kan, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Awọn iyipada radians si awọn iwọn.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Lo ibakan fun pipe to dara julọ.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Awọn iyipada awọn iwọn si radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Pada awọn ti o pọju ti awọn nọmba meji.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ti ọkan ninu awọn ariyanjiyan ba jẹ NaN, lẹhinna ariyanjiyan miiran ti pada.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Pada awọn kere ti awọn nọmba meji naa.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ti ọkan ninu awọn ariyanjiyan ba jẹ NaN, lẹhinna ariyanjiyan miiran ti pada.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Awọn iyipo si odo ati awọn iyipada si eyikeyi iru nọmba odidi atijo, ni ro pe iye naa ni opin ati pe o baamu ni iru iru naa.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Iye naa gbọdọ:
    ///
    /// * Ko jẹ `NaN`
    /// * Ko jẹ ailopin
    /// * Jẹ aṣoju ni iru ipadabọ `Int`, lẹhin ti o ti pa apakan ida rẹ kuro
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Gbigbe gbigbe aise si `u32`.
    ///
    /// Eyi jẹ aami kanna si `transmute::<f32, u32>(self)` lori gbogbo awọn iru ẹrọ.
    ///
    /// Wo `from_bits` fun diẹ ninu ijiroro ti gbigbe ti iṣẹ yii (o fẹrẹ to awọn ọran kankan).
    ///
    /// Akiyesi pe iṣẹ yii yatọ si simẹnti `as`, eyiti o gbiyanju lati tọju iye *nomba*, ati kii ṣe iye bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() kii ṣe simẹnti!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // Aabo: `u32` jẹ datatype afọwọsi pẹtẹlẹ nitorinaa a le ṣe transmute rẹ nigbagbogbo
        unsafe { mem::transmute(self) }
    }

    /// Gbigbe gbigbe aise lati `u32`.
    ///
    /// Eyi jẹ aami kanna si `transmute::<u32, f32>(v)` lori gbogbo awọn iru ẹrọ.
    /// O wa ni jade pe eyi jẹ iyalẹnu ti iyalẹnu, fun awọn idi meji:
    ///
    /// * Awọn floats ati Ints ni endianness kanna lori gbogbo awọn iru ẹrọ ti o ni atilẹyin.
    /// * IEEE-754 n ṣalaye ni titọ ṣoki ifilelẹ ti awọn floats.
    ///
    /// Sibẹsibẹ akiyesi kan wa: ṣaaju si ẹya 2008 ti IEEE-754, bawo ni a ṣe le tumọ itumọ ami ifihan NaN ko ṣe pato.
    /// Ọpọlọpọ awọn iru ẹrọ (paapaa x86 ati ARM) mu itumọ ti o ṣe deede ni ipari ni ọdun 2008, ṣugbọn diẹ ninu ko ṣe (paapaa MIPS).
    /// Bi abajade, gbogbo awọn NaNs ifihan agbara lori MIPS jẹ awọn NaN ti o dakẹ lori x86, ati ni idakeji.
    ///
    /// Dipo ki o gbiyanju lati tọju iru ẹrọ agbelebu-ness ifihan agbara, imuse yii ṣe ojurere lati tọju awọn gige gangan.
    /// Eyi tumọ si pe eyikeyi awọn isanwo isanwo ti o yipada ni awọn NaN yoo ni ipamọ paapaa ti abajade ọna yii ba firanṣẹ lori nẹtiwọọki lati ẹrọ x86 kan si MIPS kan.
    ///
    ///
    /// Ti awọn abajade ọna yii ba ni ifọwọyi nikan nipasẹ faaji kanna ti o ṣe wọn, lẹhinna ko si ibakcdun gbigbe.
    ///
    /// Ti igbewọle ko ba jẹ NaN, lẹhinna ko si ibakcdun gbigbe.
    ///
    /// Ti o ko ba bikita nipa ifihan agbara (o ṣeeṣe pupọ), lẹhinna ko si ibakcdun gbigbe.
    ///
    /// Akiyesi pe iṣẹ yii yatọ si simẹnti `as`, eyiti o gbiyanju lati tọju iye *nomba*, ati kii ṣe iye bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // Aabo: `u32` jẹ datatype pẹtẹlẹ pẹtẹlẹ nitorinaa a le ṣe transmute nigbagbogbo lati ọdọ rẹ
        // O wa ni awọn ọran aabo pẹlu sNaN ti bori!Ẹkun!
        unsafe { mem::transmute(v) }
    }

    /// Pada aṣoju iranti ti nọmba ojuami yi lilefoofo bi idapọ baiti ni aṣẹ baiti nla-endian (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Pada aṣoju iranti ti nọmba nọmba yi lilefoofo bi ipilẹ baiti ni aṣẹ baiti diẹ-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Pada aṣoju iranti ti nọmba nomba yi lilefoofo bi ipilẹ baiti ni aṣẹ baiti abinibi.
    ///
    /// Bii a ti lo endianness abinibi ti pẹpẹ ti a fojusi, koodu gbigbe ni o yẹ ki o lo [`to_be_bytes`] tabi [`to_le_bytes`], bi o ti yẹ, dipo.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Pada aṣoju iranti ti nọmba nomba yi lilefoofo bi ipilẹ baiti ni aṣẹ baiti abinibi.
    ///
    ///
    /// [`to_ne_bytes`] yẹ ki o ni ayanfẹ lori eyi nigbakugba ti o ba ṣeeṣe.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // Aabo: `f32` jẹ datatype afọwọsi pẹtẹlẹ nitorinaa a le ṣe transmute rẹ nigbagbogbo
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Ṣẹda iye oju omi ti o ṣan loju omi lati aṣoju rẹ bi ipilẹ baiti ni endian nla.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Ṣẹda iye oju omi lilefoofo lati aṣoju rẹ bi ipilẹ baiti ni kekere endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Ṣẹda iye oju omi ti o ṣan loju omi lati aṣoju rẹ bi ipilẹ baiti ni endian abinibi.
    ///
    /// Bii a ti lo endianness abinibi ti pẹpẹ ti a fojusi, koodu gbigbe ṣee ṣe fẹ lati lo [`from_be_bytes`] tabi [`from_le_bytes`], bi o ṣe yẹ dipo.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Pada aṣẹ kan laarin ara ẹni ati awọn iye miiran.
    /// Kii ifiwera apakan bošewa laarin awọn nọmba aaye lilefoofo, afiwe yii nigbagbogbo n ṣe aṣẹ ni ibamu ni ibamu si asọtẹlẹ lapapọOrder bi a ti ṣalaye ninu IEEE 754 (atunyẹwo 2008) boṣewa aaye lilefoofo.
    /// Awọn iye ti paṣẹ ni atẹle atẹle:
    /// - NaN idakẹjẹ odi
    /// - NaN ifihan agbara odi
    /// - Ailopin ailopin
    /// - Awọn nọmba odi
    /// - Awọn nọmba alailẹgbẹ odi
    /// - Odi odi
    /// - Odo rere
    /// - Awọn nọmba alailẹgbẹ rere
    /// - Awọn nọmba ti o daju
    /// - Ailopin ti o daju
    /// - NaN ifihan agbara to dara
    /// - Na ni idakẹjẹ ti o dara
    ///
    /// Ṣe akiyesi pe iṣẹ yii ko gba nigbagbogbo pẹlu awọn imuse [`PartialOrd`] ati [`PartialEq`] ti `f32`.Ni pataki, wọn ṣe akiyesi odi ati asan odo bi dogba, lakoko ti `total_cmp` ko ṣe.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Ni ọran ti awọn odi, yiyọ gbogbo awọn idinku ayafi ami naa lati ṣaṣeyọri akọkọ iru bi awọn odidi iranlowo meji
        //
        // Kini idi ti iṣẹ yii?IEEE 754 floats ni awọn aaye mẹta:
        // Wole bit, olutayo ati mantissa.Eto ti olutaja ati awọn aaye mantissa lapapọ ni ohun-ini pe aṣẹ bitwise wọn jẹ deede si titobi nọmba nibiti a ti ṣalaye titobi naa.
        // Iwọn naa ko ṣe deede asọye lori awọn iye Na, ṣugbọn IEEE 754 lapapọOrder n ṣalaye awọn iye NaN tun lati tẹle aṣẹ kekere.Eyi nyorisi aṣẹ ti a ṣalaye ninu asọye doc.
        // Sibẹsibẹ, aṣoju ti titobi jẹ kanna fun awọn nọmba odi ati awọn rere-nikan ami ami diẹ yatọ.
        // Lati ṣe afiwe awọn floats ni irọrun bi awọn nomba odidi ti a fowo si, a nilo lati yiyọ olutaja ati awọn idinku mantissa ni ọran ti awọn nọmba odi.
        // A yipada daradara awọn nọmba si fọọmu "two's complement".
        //
        // Lati ṣe yiyi pada, a ṣe iboju-boju kan ati XOR si i.
        // A ṣe iṣiro iṣiro iboju "all-ones except for the sign bit" kan lati awọn iye ti a fowo si ni odi: ami yiyi ọtun-faagun odidi, nitorinaa a "fill" boju pẹlu awọn ami ami ami, ati lẹhinna yipada si aiṣowo-ọwọ lati Titari diẹ diẹ si odo.
        //
        // Lori awọn iye ti o dara, iboju-boju jẹ gbogbo awọn odo, nitorinaa kii ṣe op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Ni ihamọ iye kan si aarin kan ayafi ti o jẹ NaN.
    ///
    /// Pada `max` ti `self` ba tobi ju `max`, ati `min` ti `self` ba kere si `min`.
    /// Bibẹkọ ti yi pada `self`.
    ///
    /// Akiyesi pe iṣẹ yii pada NaN ti iye akọkọ jẹ NaN bakanna.
    ///
    /// # Panics
    ///
    /// Panics ti `min > max`, `min` jẹ NaN, tabi `max` jẹ NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}