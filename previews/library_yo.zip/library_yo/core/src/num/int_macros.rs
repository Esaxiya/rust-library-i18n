macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Iye to kere julọ ti o le ṣe aṣoju nipasẹ iru nọmba odidi yii.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Iye ti o tobi julọ ti o le ṣe aṣoju nipasẹ iru nomba odidi yii.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Iwọn iru nomba odidi yi ninu awọn die-die.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Yi awọn ege gige okun pada ni ipilẹ ti a fun si odidi.
        ///
        /// O ti ṣe yẹ ki okun naa jẹ ami aṣayan `+` tabi `-` aṣayan ti atẹle awọn nọmba.
        /// Asiwaju ati itọpa aaye funfun jẹ aṣoju aṣiṣe kan.
        /// Awọn nọmba jẹ ipin kan ti awọn ohun kikọ wọnyi, da lori `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Iṣẹ yii panics ti `radix` ko ba si ni ibiti o wa lati 2 si 36.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Pada nọmba awọn ọkan ninu aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Pada nọmba ti awọn odo ni aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Pada nọmba ti awọn odo ṣiwaju ninu aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Pada nọmba ti awọn odo ti n tẹle ni aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Pada nọmba awọn aṣaaju ninu aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Pada nọmba ti awọn ti o tẹle ninu aṣoju alakomeji ti `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Yipada awọn idinku si apa osi nipasẹ iye pàtó kan, `n`, n murasilẹ awọn idinku gige si opin odidi odidi.
        ///
        ///
        /// Jọwọ ṣe akiyesi eyi kii ṣe iṣiṣẹ kanna bii oniṣẹ yiyi `<<`!
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Yipada awọn idinku si apa ọtun nipasẹ iye pàtó kan, `n`, n murasilẹ awọn idinku gige si ibẹrẹ ti odidi odidi.
        ///
        ///
        /// Jọwọ ṣe akiyesi eyi kii ṣe iṣiṣẹ kanna bii oniṣẹ yiyi `>>`!
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Yiyipada baiti aṣẹ odidi.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// jẹ ki m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Yiyipada aṣẹ awọn idinku ninu odidi.
        /// Ohun ti o ṣe pataki ti o kere julọ di bit ti o ṣe pataki julọ, ẹẹkeji ti o kere ju-pataki di bit ti o ṣe pataki julọ julọ, ati bẹbẹ lọ
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// jẹ ki m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Iyipada odidi odidi kan lati endian nla si endianness ti afojusun naa.
        ///
        /// Lori nla endian eyi kii ṣe op-op.Lori endian kekere awọn baiti ti wa ni rọpo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ti o ba ti cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } miiran {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Iyipada odidi odidi kan lati endian kekere si endianness ti afojusun naa.
        ///
        /// Lori endian kekere eyi kii ṣe op.Lori nla endian awọn baiti ti wa ni swapped.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ti o ba ti cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } miiran {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Yi awọn `self` pada si endian nla lati ibigbogbo ibi-afẹde naa.
        ///
        /// Lori nla endian eyi kii ṣe op-op.Lori endian kekere awọn baiti ti wa ni rọpo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ti o ba ti cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } miiran { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // tabi kii ṣe?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Yi awọn `self` pada si endian diẹ lati ibigbogbo ibi-afẹde naa.
        ///
        /// Lori endian kekere eyi kii ṣe op.Lori nla endian awọn baiti ti wa ni swapped.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ti o ba ti cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } miiran { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Ṣayẹwo odidi afikun.
        /// Oniṣiro `self + rhs`, pada `None` ti o ba ti overflow lodo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Afikun nọmba odidi.Awọn iṣiro `self + rhs`, ti o ro pe iṣanju ko le waye.
        /// Eyi ni abajade ihuwasi ti a ko ṣalaye nigbati
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Iyokuro odidi odidi.
        /// Oniṣiro `self - rhs`, pada `None` ti o ba ti overflow lodo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Iyokuro odidi odidi ti a ko ṣayẹwo.Oniṣiro `self - rhs`, ti o ro pe iṣanju ko le waye.
        /// Eyi ni abajade ihuwasi ti a ko ṣalaye nigbati
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Isodipupo nomba odidi.
        /// Oniṣiro `self * rhs`, pada `None` ti o ba ti overflow lodo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Isodipupo nomba odidi ti a ko ṣayẹwo.Oniṣiro `self * rhs`, ti o ro pe iṣanju ko le waye.
        /// Eyi ni abajade ihuwasi ti a ko ṣalaye nigbati
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Pinpin odidi odidi.
        /// Oniṣiro `self / rhs`, pada `None` ti `rhs == 0` tabi awọn abajade pipin ni ṣiṣan.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // Aabo: div nipasẹ odo ati nipasẹ INT_MIN ti ṣayẹwo ni oke
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Ṣayẹwo pipin Euclidean.
        /// Oniṣiro `self.div_euclid(rhs)`, pada `None` ti `rhs == 0` tabi awọn abajade pipin ni iṣanju.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Ajẹku odidi ti a ṣayẹwo.
        /// Oniṣiro `self % rhs`, pada `None` ti `rhs == 0` tabi awọn abajade pipin ni ṣiṣan.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // Aabo: div nipasẹ odo ati nipasẹ INT_MIN ti ṣayẹwo ni oke
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Ṣayẹwo iyokuro Euclidean.
        /// Oniṣiro `self.rem_euclid(rhs)`, pada `None` ti `rhs == 0` tabi awọn abajade pipin ni iṣanju.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Idoju ti a ṣayẹwo.
        /// Oniṣiro `-self`, pada `None` ti o ba ti `self == MIN`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ṣayẹwo iyipada ni apa osi.
        /// Awọn iṣiro `self << rhs`, pada `None` ti `rhs` ba tobi tabi dọgba pẹlu nọmba awọn idinku ni `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ṣayẹwo naficula ọtun.
        /// Awọn iṣiro `self >> rhs`, pada `None` ti `rhs` ba tobi tabi dọgba pẹlu nọmba awọn idinku ni `self`.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ṣayẹwo iye iye.
        /// Oniṣiro `self.abs()`, pada `None` ti o ba ti `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Ṣayẹwo exponentiation.
        /// Oniṣiro `self.pow(exp)`, pada `None` ti o ba ti overflow lodo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // niwon exp!=0, nikẹhin exp gbọdọ jẹ 1.
            // Ṣe pẹlu iwọn ikẹhin ti olutaja lọtọ, nitori fifipada ipilẹ lẹhinna ko ṣe pataki o le fa iṣan-omi ti ko ni iwulo.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Afikun nọmba odidi.
        /// Oniṣiro `self + rhs`, saturatiwọn ni awọn aala nọmba dipo ti iṣanju.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Iyokuro odidi odidi.
        /// Oniṣiro `self - rhs`, saturatiwọn ni awọn aala nọmba dipo ti iṣanju.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Imuju nomba odidi.
        /// Oniṣiro `-self`, pada `MAX` ti o ba ti `self == MIN` dipo ti àkúnwọsílẹ.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Itura iye to pe.
        /// Oniṣiro `self.abs()`, pada `MAX` ti o ba ti `self == MIN` dipo ti àkúnwọsílẹ.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Isodipupo nomba odidi.
        /// Oniṣiro `self * rhs`, saturatiwọn ni awọn aala nọmba dipo ti iṣanju.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Imukuro iṣiro odidi.
        /// Oniṣiro `self.pow(exp)`, saturatiwọn ni awọn aala nọmba dipo ti iṣanju.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Wíwọ (modular) afikun.
        /// Oniṣiro `self + rhs`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Yiyọ (modular) iyokuro.
        /// Oniṣiro `self - rhs`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Wíwọ (modular) isodipupo.
        /// Oniṣiro `self * rhs`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Wíwọ (modular) pipin.Oniṣiro `self / rhs`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Ọran kan ṣoṣo nibiti iru murasilẹ le waye ni nigbati ẹnikan pin `MIN / -1` lori iru ibuwọlu kan (nibiti `MIN` jẹ iye ti o kere julọ ti ko dara fun iru);eyi jẹ deede si `-MIN`, iye rere ti o tobi pupọ lati ṣe aṣoju ninu iru.
        /// Ni iru ọran bẹ, iṣẹ yii pada `MIN` funrararẹ.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Wíwọ Euclidean pipin.
        /// Oniṣiro `self.div_euclid(rhs)`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Wíwọ yoo waye nikan ni `MIN / -1` lori iru ibuwọlu kan (nibiti `MIN` jẹ iye ti o kere julọ ti ko dara fun iru).
        /// Eyi jẹ deede si `-MIN`, iye rere ti o tobi pupọ lati ṣe aṣoju ninu iru.
        /// Ni ọran yii, ọna yii pada `MIN` funrararẹ.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Wíwọ (modular) ku.Oniṣiro `self % rhs`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Iru ipari-yika ko ṣẹlẹ gangan ni iṣiro;awọn ohun elo imuse jẹ ki `x % y` ko wulo fun `MIN / -1` lori iru ibuwọlu kan (nibiti `MIN` jẹ iye ti o kere ju odi).
        ///
        /// Ni iru ọran bẹẹ, iṣẹ yii pada `0`.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Wíwọ Euclidean aloku.Oniṣiro `self.rem_euclid(rhs)`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Wíwọ yoo waye nikan ni `MIN % -1` lori iru ibuwọlu kan (nibiti `MIN` jẹ iye ti o kere julọ ti ko dara fun iru).
        /// Ni idi eyi, ọna yii pada 0.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Wíwọ (modular) odi.Oniṣiro `-self`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Ọran kan ṣoṣo nibiti iru murasilẹ le waye ni nigbati ẹnikan ba tako `MIN` lori iru ibuwọlu kan (nibiti `MIN` jẹ iye ti o kere julọ ti ko dara fun iru);eyi jẹ iye ti o dara ti o tobi pupọ lati ṣe aṣoju ninu iru.
        /// Ni iru ọran bẹ, iṣẹ yii pada `MIN` funrararẹ.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-ọfẹ yipada-osi-osi;mu egbin `self << mask(rhs)` wa, nibiti `mask` ṣe yọ eyikeyi awọn aṣẹ aṣẹ giga ti `rhs` ti yoo fa ki iṣipopada kọja iwọn iyara iru.
        ///
        /// Akiyesi pe eyi kii ṣe * kii ṣe kanna bii iyipo-apa osi;awọn RHS ti yiyi murasilẹ-apa osi ti ni ihamọ si ibiti o ti iru, kuku ju awọn idinku ti o jade kuro ni LHS ti o pada si opin keji.
        ///
        /// Awọn oriṣi odidi atijọ gbogbo ṣe iṣẹ [`rotate_left`](Self::rotate_left) kan, eyiti o le jẹ ohun ti o fẹ dipo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // Aabo: iparada nipasẹ bitsize ti iru ṣe idaniloju pe a ko yipada
            // ti aala
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-ọfẹ ṣiṣiparọ yiyi-sọtun;mu egbin `self >> mask(rhs)` wa, nibiti `mask` ṣe yọ eyikeyi awọn aṣẹ aṣẹ giga ti `rhs` ti yoo fa ki iṣipopada kọja iwọn iyara iru.
        ///
        /// Akiyesi pe eyi kii ṣe * kii ṣe kanna bii iyipo-ọtun;awọn RHS ti iyipo yiyi-ọtun ti ni ihamọ si ibiti o ti iru, kuku ju awọn idinku ti o jade kuro ni LHS ti o pada si opin keji.
        ///
        /// Awọn oriṣi odidi atijọ gbogbo ṣe iṣẹ [`rotate_right`](Self::rotate_right) kan, eyiti o le jẹ ohun ti o fẹ dipo.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // Aabo: iparada nipasẹ bitsize ti iru ṣe idaniloju pe a ko yipada
            // ti aala
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Murasilẹ (modular) ifise iye.Oniṣiro `self.abs()`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// Ọran kan ṣoṣo nibiti iru murasilẹ le waye jẹ nigbati ẹnikan ba gba iye idiye ti iye ti o kere julọ ti odi fun iru;eyi jẹ iye ti o dara ti o tobi pupọ lati ṣe aṣoju ninu iru.
        /// Ni iru ọran bẹ, iṣẹ yii pada `MIN` funrararẹ.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Ṣe iṣiro iye to pe ti `self` laisi eyikeyi ipari tabi ijaya.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Wíwọ (modular) exponentiation.
        /// Oniṣiro `self.pow(exp)`, murasilẹ ni ayika ni aala ti awọn iru.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // niwon exp!=0, nikẹhin exp gbọdọ jẹ 1.
            // Ṣe pẹlu iwọn ikẹhin ti olutaja lọtọ, nitori fifipada ipilẹ lẹhinna ko ṣe pataki o le fa iṣan-omi ti ko ni iwulo.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Ṣe iṣiro `self` + `rhs`
        ///
        /// Pada tuple ti afikun pọ pẹlu boolean ti n tọka boya apasọ iṣiro yoo waye.
        /// Ti iṣan omi ba ti ṣẹlẹ lẹhinna iye ti a we naa yoo pada.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ṣe iṣiro `self`, `rhs`
        ///
        /// Pada tuple ti iyokuro pọ pẹlu boolean ti n tọka boya ṣiṣan iṣiro yoo waye.
        /// Ti iṣan omi ba ti ṣẹlẹ lẹhinna iye ti a we naa yoo pada.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ṣe iṣiro isodipupo ti `self` ati `rhs`.
        ///
        /// Pada tuple ti isodipupo pọ pẹlu boolean ti n tọka boya ṣiṣan iṣiro yoo waye.
        /// Ti iṣan omi ba ti ṣẹlẹ lẹhinna iye ti a we naa yoo pada.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, otitọ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ṣe iṣiro olupin nigba ti o pin `self` pẹlu `rhs`.
        ///
        /// Pada tuple ti oluṣapẹẹrẹ pẹlu boolean ti n tọka boya ṣiṣọnju iṣiro yoo waye.
        /// Ti iṣan omi yoo waye lẹhinna a ti da ara ẹni pada.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Ṣe iṣiro ipin ti pipin Euclidean `self.div_euclid(rhs)`.
        ///
        /// Pada tuple ti oluṣapẹẹrẹ pẹlu boolean ti n tọka boya ṣiṣọnju iṣiro yoo waye.
        /// Ti iṣan omi yoo waye lẹhinna `self` ti pada.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Ṣe iṣiro iyoku nigba ti a pin `self` nipasẹ `rhs`.
        ///
        /// Pada tuple ti iyoku lẹhin ti o pin pẹlu iwe boolean kan ti o tọka boya ṣiṣọnju iṣiro yoo waye.
        /// Ti iṣan omi yoo waye lẹhinna 0 ti da pada.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Iyoku EuclideanṢe iṣiro `self.rem_euclid(rhs)`.
        ///
        /// Pada tuple ti iyoku lẹhin ti o pin pẹlu iwe boolean kan ti o tọka boya ṣiṣọnju iṣiro yoo waye.
        /// Ti iṣan omi yoo waye lẹhinna 0 ti da pada.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negates ara ẹni, àkúnwọsílẹ ti eyi ba dogba si iye to kere julọ.
        ///
        /// Pada tuple ti ẹya ti ara ẹni ti ara ẹni papọ pẹlu boolean ti n tọka boya ṣiṣan kan ṣẹlẹ.
        /// Ti `self` ba jẹ iye ti o kere julọ (fun apẹẹrẹ, `i32::MIN` fun awọn iye ti iru `i32`), lẹhinna iye to kere julọ yoo pada wa lẹẹkansii ati pe `true` yoo da pada fun iṣan-omi ti n ṣẹlẹ.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Awọn ayipada ara ẹni ti o fi silẹ nipasẹ awọn idinku `rhs`.
        ///
        /// Pada tuple ti ẹya ti a yipada ti ara ẹni pẹlu iwe kan ti n tọka boya iye iyipada ti tobi ju tabi dogba si nọmba awọn idinku.
        /// Ti iye iyipada ba tobi ju, lẹhinna iye ti wa ni iboju-boju (N-1) nibiti N jẹ nọmba awọn idinku, ati pe iye lẹhinna ni a lo lati ṣe iyipada naa.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, otitọ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Awọn iyipo ara ẹni ni ẹtọ nipasẹ awọn idinku `rhs`.
        ///
        /// Pada tuple ti ẹya ti a yipada ti ara ẹni pẹlu iwe kan ti n tọka boya iye iyipada ti tobi ju tabi dogba si nọmba awọn idinku.
        /// Ti iye iyipada ba tobi ju, lẹhinna iye ti wa ni iboju-boju (N-1) nibiti N jẹ nọmba awọn idinku, ati pe iye lẹhinna ni a lo lati ṣe iyipada naa.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, otitọ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ṣe iṣiro iye idiyele ti `self`.
        ///
        /// Pada tuple ti ẹya pipe ti ara ẹni pẹlu boolean ti o nfihan boya iṣan omi kan ṣẹlẹ.
        /// Ti ararẹ ba jẹ iye ti o kere julọ
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// lẹhinna iye ti o kere julọ yoo pada lẹẹkansi ati otitọ yoo da pada fun iṣan-omi ti n ṣẹlẹ.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Ṣe igbega ara ẹni si agbara ti `exp`, ni lilo fifẹ nipasẹ fifẹ.
        ///
        /// Pada tuple ti ifaagun pẹlu bool kan ti o tọka boya iṣan omi kan ṣẹlẹ.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, otitọ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Ibokuro aaye fun titoju awọn abajade ti overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // niwon exp!=0, nikẹhin exp gbọdọ jẹ 1.
            // Ṣe pẹlu iwọn ikẹhin ti olutaja lọtọ, nitori fifipada ipilẹ lẹhinna ko ṣe pataki o le fa iṣan-omi ti ko ni iwulo.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Ṣe igbega ara ẹni si agbara ti `exp`, ni lilo fifẹ nipasẹ fifẹ.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // niwon exp!=0, nikẹhin exp gbọdọ jẹ 1.
            // Ṣe pẹlu iwọn ikẹhin ti olutaja lọtọ, nitori fifipada ipilẹ lẹhinna ko ṣe pataki o le fa iṣan-omi ti ko ni iwulo.
            //
            //
            acc * base
        }

        /// Ṣe iṣiro ipin ti ipin Euclidean ti `self` nipasẹ `rhs`.
        ///
        /// Eyi ṣe iṣiro odidi `n` bii `self = n * rhs + self.rem_euclid(rhs)`, pẹlu `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Ni awọn ọrọ miiran, abajade jẹ `self / rhs` yika si odidi `n` bii `self >= n * rhs`.
        /// Ti `self > 0`, eyi jẹ dọgba si yika si odo (aiyipada ni Rust);
        /// ti o ba jẹ `self < 0`, eyi jẹ dọgba si yika si ọna +/-ailopin.
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0 tabi awọn abajade pipin ni ṣiṣan.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// jẹ ki b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Ṣe iṣiro iyokuro ainipẹkun ti o kere ju ti `self (mod rhs)`.
        ///
        /// Eyi ni a ṣe bi ẹni pe nipasẹ algorithm pipin Euclidean-fi fun `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, ati `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Iṣẹ yii yoo jẹ panic ti `rhs` jẹ 0 tabi awọn abajade pipin ni ṣiṣan.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// jẹ ki b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Ṣe iṣiro iye idiyele ti `self`.
        ///
        /// # Ihuwasi aponsedanu
        ///
        /// Idi iye ti
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ko le ṣe aṣoju bi
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ati igbiyanju lati ṣe iṣiro rẹ yoo fa iṣan-omi.
        /// Eyi tumọ si pe koodu ni ipo n ṣatunṣe aṣiṣe yoo ṣe okunfa panic lori ọran yii ati koodu iṣapeye yoo pada
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// laisi panic kan.
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Akiyesi pe#[opopo] ti o wa loke tumọ si pe awọn atunmọ iṣanju ti iyokuro dale lori crate ti a ṣe atokọ sinu.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Pada nọmba ti o nsoju ami ti `self`.
        ///
        ///  - `0` ti nomba na ba je odo
        ///  - `1` ti nọmba naa ba jẹ rere
        ///  - `-1` ti nọmba naa ba jẹ odi
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Pada `true` ti `self` ba jẹ rere ati `false` ti nọmba naa ba jẹ odo tabi odi.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Pada `true` ti `self` ba jẹ odi ati `false` ti nọmba naa ba jẹ odo tabi rere.
        ///
        ///
        /// # Examples
        ///
        /// Ipilẹ lilo:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Da aṣoju oniduro ti odidi yii pada bi ipilẹ baiti ni aṣẹ baiti nla-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Da aṣoju aṣoju ti odidi yii pada bi ipilẹ baiti ni aṣẹ baiti diẹ-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Pada aṣoju iranti ti nomba odidi yii bi titobi baiti ni aṣẹ baiti abinibi.
        ///
        /// Bii a ti lo endianness abinibi ti pẹpẹ ti a fojusi, koodu gbigbe ni o yẹ ki o lo [`to_be_bytes`] tabi [`to_le_bytes`], bi o ti yẹ, dipo.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     awọn baiti, ti o ba jẹ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } miiran {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // Aabo: ohun orin nitori pe awọn odidi jẹ alaye data atijọ nitoripe a le nigbagbogbo
        // ṣe iyipada wọn si awọn ipilẹ ti awọn baiti
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // Aabo: awọn odidi jẹ awọn data data atijọ ti o rọrun nitori a le ṣe transmute wọn nigbagbogbo si
            // awọn ipilẹ ti awọn baiti
            unsafe { mem::transmute(self) }
        }

        /// Pada aṣoju iranti ti nomba odidi yii bi titobi baiti ni aṣẹ baiti abinibi.
        ///
        ///
        /// [`to_ne_bytes`] yẹ ki o ni ayanfẹ lori eyi nigbakugba ti o ba ṣeeṣe.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// jẹ ki awọn baiti= num.as_ne_bytes();
        /// assert_eq!(
        ///     awọn baiti, ti o ba jẹ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } miiran {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // Aabo: awọn odidi jẹ awọn data data atijọ ti o rọrun nitori a le ṣe transmute wọn nigbagbogbo si
            // awọn ipilẹ ti awọn baiti
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Ṣẹda iye odidi kan lati aṣoju rẹ bi ipilẹ baiti ni endian nla.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// lo std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * igbewọle=isinmi;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Ṣẹda iye odidi lati inu aṣoju rẹ bi ipilẹ baiti ni kekere endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// lo std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * igbewọle=isinmi;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Ṣẹda ohun odidi iye lati awọn oniwe-iranti oniduro bi a baiti orun ni abinibi endianness.
        ///
        /// Bii a ti lo endianness abinibi ti pẹpẹ ti a fojusi, koodu gbigbe ṣee ṣe fẹ lati lo [`from_be_bytes`] tabi [`from_le_bytes`], bi o ṣe yẹ dipo.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } miiran {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// lo std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * igbewọle=isinmi;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // Aabo: ohun orin nitori pe awọn odidi jẹ alaye data atijọ nitoripe a le nigbagbogbo
        // transmute si wọn
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // Aabo: awọn nomba odidi jẹ awọn datatypes atijọ ti o rọrun nitori a le ṣe transmute nigbagbogbo si wọn
            unsafe { mem::transmute(bytes) }
        }

        /// Koodu tuntun yẹ ki o fẹ lati lo
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Pada iye ti o kere julọ ti o le ṣe aṣoju nipasẹ iru nomba odidi yii.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Koodu tuntun yẹ ki o fẹ lati lo
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Pada iye ti o tobi julọ ti o le ni aṣoju nipasẹ iru nọmba odidi yii.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}