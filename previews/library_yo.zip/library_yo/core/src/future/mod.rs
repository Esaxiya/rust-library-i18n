#![stable(feature = "futures_api", since = "1.36.0")]

//! Gbígbé síi.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Iru iru yii nilo nitori:
///
/// a) Generators ko le se `for<'a, 'b> Generator<&'a mut Context<'b>>`, ki a nilo lati ṣe kan aise ijuboluwole (wo <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Aise ifẹnule ati `NonNull` wa ni ko `Send` tabi `Sync`, ki yoo ṣe gbogbo nikan future non-Send/Sync bi daradara, ati awọn ti a ko ba fẹ pe.
///
/// O tun simplifies awọn HIR sokale ti `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Ipari a monomono ni a future.
///
/// Iṣẹ yi pada a `GenFuture` labe, ṣugbọn hides o ni `impl Trait` lati fun dara aṣiṣe awọn ifiranṣẹ (`impl Future` dipo ju `GenFuture<[closure.....]>`).
///
// Eyi ni `const` lati yago fun awọn aṣiṣe afikun lẹhin ti a bọsipọ lati `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // A gbekele lori o daju wipe async/await futures ni o wa laiyẹsẹ ni ibere lati ṣẹda ara-referential borrows ni amuye monomono.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // Aabo: Ailewu nitori a jẹ !Unpin + !Drop, ati pe eyi jẹ asọtẹlẹ aaye kan.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Pa si monomono, titan `&mut Context` sinu kan `NonNull` aise ijuboluwole.
            // The `.await` sokale yoo kuro lailewu lé wipe pada si a `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // Aabo: awọn olupe gbọdọ lopolopo ti `cx.0` ni a wulo ijuboluwole
    // ti o mu gbogbo awọn ibeere fun a mutable itọkasi.
    unsafe { &mut *cx.0.as_ptr().cast() }
}