#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future duro ohun ti gbígbé iṣiro.
///
/// future jẹ iye ti o le ma ti pari iširo sibẹsibẹ.
/// Yi ni irú ti "asynchronous value" mu ki o ṣee ṣe fun a tẹle lati tẹsiwaju ṣe wulo iṣẹ nigba ti o duro fun iye to di wa.
///
///
/// # Ọna `poll`
///
/// Ọna pataki ti future, `poll`,*awọn igbiyanju* lati yanju future sinu iye ipari.
/// Ọna yii ko ṣe idiwọ ti iye ko ba ṣetan.
/// Dipo, awọn ti isiyi iṣẹ-ṣiṣe ni se eto lati wa ni woken soke nigba ti o ni ṣee ṣe lati ṣe siwaju itesiwaju nipa `poll`ing lẹẹkansi.
/// The `context` koja si awọn `poll` ọna ti o le pese a [`Waker`], ti o jẹ a mu awọn fun titaji soke awọn ti isiyi-ṣiṣe.
///
/// Nigba lilo future, o ni gbogbo yoo ko pe `poll` taara, sugbon dipo `.await` iye.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Awọn iru ti iye yi ni on Ipari.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Gbiyanju lati yanju future to a ik iye, fiforukọṣilẹ awọn ti isiyi-ṣiṣe fun wakeup ti o ba ti iye ni ko sibẹsibẹ wa.
    ///
    /// # Pada iye
    ///
    /// Iṣẹ yi padà:
    ///
    /// - [`Poll::Pending`] ti o ba ti future ni ko setan sibẹsibẹ
    /// - [`Poll::Ready(val)`] pẹlu awọn esi `val` ti yi future ti o ba ti pari ni ifijišẹ.
    ///
    /// Lọgan ti a future ti pari, ibara ko yẹ `poll` o lẹẹkansi.
    ///
    /// Nigba ti a future ni ko setan sibẹsibẹ, `poll` pada `Poll::Pending` ati oja a oniye ti awọn [`Waker`] dakọ lati isiyi [`Context`].
    /// Eleyi [`Waker`] wa ni ki o woken ni kete ti awọn future le ṣe itesiwaju.
    /// Fun apẹẹrẹ, future kan ti n duro de iho kan lati di kika yoo pe `.clone()` lori [`Waker`] ki o tọju rẹ.
    /// Nigba ti a ifihan ti de ni bomi o nfihan pe awọn iho ti wa ni ṣeékà, [`Waker::wake`] ni a npe ni ati awọn iho future ká iṣẹ-ṣiṣe ti wa ni awoken.
    /// Lọgan ti a ṣiṣe ti a ti woken soke, o yẹ ki o gbiyanju lati `poll` awọn future lẹẹkansi, eyi ti o le tabi ko le gbe awọn kan ik iye.
    ///
    /// Akọsilẹ ti lori ọpọ awọn ipe to `poll`, nikan ni [`Waker`] lati awọn [`Context`] si kọja si awọn julọ to šẹšẹ ipe yẹ ki o wa se eto lati gba a wakeup.
    ///
    /// # isise abuda
    ///
    /// Futures nikan ni o wa *inert*;nwọn gbọdọ jẹ *actively*`poll`ed lati ṣe ilọsiwaju, afipamo pe kọọkan akoko ti isiyi-ṣiṣe ti wa ni woken soke, o yẹ ki o actively re-`poll` ni isunmọtosi ni futures ti o si tun ni o ni ohun anfani ni.
    ///
    /// A ko pe iṣẹ `poll` leralera ni lupu ti o muna-dipo, o yẹ ki o pe nikan nigbati future tọkasi pe o ti ṣetan lati ṣe ilọsiwaju (nipa pipe `wake()`).
    /// Ti o ba ti o ba faramọ pẹlu awọn `poll(2)` tabi `select(2)` syscalls on Unix o ká tọ kiyesi futures ojo melo ṣe *ko* jiya kanna isoro ti "all wakeups must poll all events";ti won wa ni siwaju sii bi `epoll(4)`.
    ///
    /// An imuse ti `poll` yẹ ki o du lati pada kiakia, ki o yẹ ki o ko dènà.Pada pada ni kiakia ṣe idiwọ titiipa awọn okun tabi awọn lulu iṣẹlẹ.
    /// Ti o ba ti wa ni mo wa niwaju ti akoko ti a ipe to `poll` le mu soke mu igba die, awọn iṣẹ yẹ ki o wa offloaded to a tẹle pool (tabi nkankan iru) lati rii daju wipe `poll` le pada ni kiakia.
    ///
    /// # Panics
    ///
    /// Lọgan ti future kan ti pari (pada `Ready` lati `poll`), pipe pipe ọna `poll` rẹ lẹẹkansii le panic, ṣe idiwọ lailai, tabi fa iru awọn iṣoro miiran;awọn `Future` trait ibiti ko si ibeere lori awọn ipa ti iru ipe kan.
    /// Sibẹsibẹ, bi awọn `poll` ọna ti wa ni ko ni samisi `unsafe`, Rust ká ibùgbé ofin waye: ipe kò gbọdọ fa aisọye iwa (iranti ibaje, ti ko tọ lilo ti `unsafe` iṣẹ, tabi awọn bi), lai ti awọn future ká ipinle.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}