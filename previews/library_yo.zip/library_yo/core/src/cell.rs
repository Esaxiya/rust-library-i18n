//! Shareable mutable awọn apoti.
//!
//! Rust iranti aabo wa ni da lori ofin yi: Fun ohun `T`, o jẹ ṣee ṣe nikan lati ni ọkan ninu awọn wọnyi:
//!
//! - Nini orisirisi aileyipada jo (`&T`) si ohun (tun mo bi **aliasing**).
//! - Nini itọkasi iyipada kan (`&mut T`) si nkan naa (ti a tun mọ ni **mutability**).
//!
//! Eyi ni ipa nipasẹ akopọ Rust.Sibẹsibẹ, awọn ipo wa nibiti ofin yii ko ni irọrun to.Nigba miran o ti wa ni ti a beere lati ni ọpọ jo si ohun ati ki o sibe mutate o.
//!
//! Awọn apoti iyipada ti o le pin lati wa laaye lati gba iyipada ni ọna idari, paapaa niwaju inagijẹ.Mejeeji [`Cell<T>`] ati [`RefCell<T>`] gba laaye ṣiṣe eyi ni ọna ti o tẹle ara kan.
//! Sibẹsibẹ, bẹni `Cell<T>` tabi `RefCell<T>` ko ni ailewu okun (wọn ko ṣe imuse [`Sync`]).
//! Ti o ba nilo lati se aliasing ati iyipada laarin awọn ọpọ awon ti o ti ṣee ṣe lati lo [`Mutex<T>`], [`RwLock<T>`] tabi [`atomic`] omiran.
//!
//! Awọn iye ti awọn iru `Cell<T>` ati `RefCell<T>` le jẹ iyipada nipasẹ awọn itọkasi ti a pin (ie
//! iru `&T` ti o wọpọ), lakoko ti ọpọlọpọ awọn oriṣi Rust le nikan ni iyipada nipasẹ awọn itọkasi oto (`&mut T`)
//! A sọ pe `Cell<T>` ati `RefCell<T>` pese `iyipada ara inu`, ni idakeji pẹlu awọn iru Rust aṣoju ti o ṣe afihan `iyipada ti a jogun`.
//!
//! Cell orisi wá ni meji eroja: `Cell<T>` ati `RefCell<T>`.`Cell<T>` ṣe imukuro iyipada inu nipasẹ gbigbe awọn iye inu ati jade ninu `Cell<T>`.
//! Lati lo jo dipo ti iye, ọkan gbọdọ lo awọn `RefCell<T>` iru, ra a Kọ titiipa ṣaaju ki o to mutating.`Cell<T>` pese awọn ọna lati gba ki o si yi awọn ti isiyi inu ilohunsoke iye:
//!
//!  - Fun orisi ti se [`Copy`], awọn [`get`](Cell::get) ọna retrieves awọn ti isiyi inu ilohunsoke iye.
//!  - Fun awọn oriṣi ti o ṣe [`Default`], ọna [`take`](Cell::take) rọpo iye inu ti isiyi pẹlu [`Default::default()`] ati da iye ti o rọpo pada.
//!  - Fun gbogbo awọn oriṣi, ọna [`replace`](Cell::replace) rọpo iye inu ti isiyi ati pada iye ti o rọpo ati ọna [`into_inner`](Cell::into_inner) jẹ `Cell<T>` run ati pada iye inu.
//!  Ni afikun, ọna [`set`](Cell::set) rọpo iye inu, sisọ iye ti o rọpo silẹ.
//!
//! `RefCell<T>` nlo Rust ká lifetimes lati se 'ìmúdàgba yiya', a ilana nipa eyiti ọkan le beere ibùgbé, iyasoto, mutable wiwọle si ni akojọpọ iye.
//! Borrows fun `RefCell<T>`A tọpinpin 'ni asiko asiko', laisi awọn oriṣi itọkasi abinibi ti Rust eyiti o tọpinpin ni iṣiro, ni akoko sakojo.
//! Nitori `RefCell<T>` borrows ni o wa ìmúdàgba o jẹ ṣee ṣe lati gbiyanju lati yawo a iye ti o ti wa tẹlẹ mutably ya;nigbati eyi ba ṣẹlẹ o jẹ abajade ni okun panic.
//!
//! # Nigbati o ba yan iyipada inu
//!
//! Iyipada ti a jogun ti o wọpọ julọ, nibiti ẹnikan gbọdọ ni iraye si alailẹgbẹ lati yi iye kan pada, jẹ ọkan ninu awọn eroja ede pataki ti o jẹ ki Rust le ṣaro ni iyanju nipa titọka itọka, didena awọn idun jamba ni iṣiro.
//! Nitori eyi, o fẹ iyipada, ati iyipada ti inu jẹ nkan ti ibi-isinmi ti o kẹhin.
//! Niwọn igba ti awọn oriṣi sẹẹli jẹ ki iyipada wa nibiti yoo jẹ ki a ko gba laaye botilẹjẹpe, awọn aye wa nigba ti iyipada inu le yẹ, tabi paapaa *gbọdọ* ṣee lo,
//!
//! * Ni lenu mutability 'inside' ti nkankan aileyipada
//! * Imuse alaye ti logically-aileyipada ọna.
//! * Mutating awọn imuṣẹ ti [`Clone`].
//!
//! ## Ni lenu mutability 'inside' ti nkankan aileyipada
//!
//! Ọpọlọpọ awọn pín smart ijuboluwole omiran, pẹlu [`Rc<T>`] ati [`Arc<T>`], pese apoti ti o le wa cloned ki o si pín laarin awọn ọpọ ẹni.
//! Nitori awọn iye ti o wa ninu rẹ le jẹ aliasi isodipupo, wọn le yawo nikan pẹlu `&`, kii ṣe `&mut`.
//! Lai ẹyin o yoo jẹ soro lati mutate data inu ti awọn wọnyi smati awọn ifẹnule ni gbogbo.
//!
//! O wọpọ pupọ lẹhinna lati fi `RefCell<T>` sinu awọn oriṣi ijuboluwo pin lati tun ṣe iyipada iyipada:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Ṣẹda bulọọki tuntun lati ṣe opin opin ti yiya agbara
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Akọsilẹ ti o ba ti a ti ko jẹ ki awọn ti tẹlẹ wín, ti awọn kaṣe ti kuna jade ti dopin ki o si awọn tetele wín, yoo fa a ìmúdàgba o tẹle panic.
//!     //
//!     // Eyi ni eewu akọkọ ti lilo `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Akiyesi pe apẹẹrẹ yii nlo `Rc<T>` kii ṣe `Arc<T>`.RefCell<T>s wa fun awọn oju iṣẹlẹ eyọkan.Ro nipa lilo [`RwLock<T>`] tabi [`Mutex<T>`] ba ti o ba nilo pín mutability ni a ti ọpọlọpọ-asapo ipo.
//!
//! ## Awọn alaye imuse ti awọn ọna ti aiṣe-ogbon
//!
//! Lẹẹkọọkan o le jẹ wuni lati ma ṣe fi han ni API kan pe iyipada wa ti n ṣẹlẹ "under the hood".
//! Eyi le jẹ nitori logically ni isẹ ti wa ni aileyipada, ṣugbọn eg, caching ologun imuse lati ṣe iyipada;tabi nitori o gbọdọ lo iyipada lati ṣe ọna trait eyiti o ṣalaye ni akọkọ lati mu `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Iṣiro ti o gbowolori lọ si ibi
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutating awọn imuṣẹ ti `Clone`
//!
//! Eyi jẹ ọrọ pataki kan, ṣugbọn wọpọ, ọran ti iṣaaju: iyipada ifipamọ fun awọn iṣẹ ti o han lati jẹ aiyipada.
//! Ọna [`clone`](Clone::clone) ni a nireti lati ma yi iye orisun pada, ati pe o kede lati mu `&self`, kii ṣe `&mut self`.
//! Nitorinaa, eyikeyi iyipada ti o ṣẹlẹ ni ọna `clone` gbọdọ lo awọn oriṣi sẹẹli.
//! Fun apẹẹrẹ, [`Rc<T>`] ṣetọju awọn iṣiro itọkasi rẹ laarin `Cell<T>` kan.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Ipo iranti iyipada.
///
/// # Examples
///
/// Ninu apẹẹrẹ yii, o le rii pe `Cell<T>` n jẹ ki iyipada ninu inu eto ti ko le yipada.
/// Ni gbolohun miran, ti o kí "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // Aṣiṣe: `my_struct` jẹ iyipada
/// // my_struct.regular_field =titun_iye;
///
/// // Awọn iṣẹ: botilẹjẹpe `my_struct` ko ni iyipada, `special_field` jẹ `Cell` kan,
/// // eyiti o le jẹ iyipada nigbagbogbo
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Wo [module-level documentation](self) fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Ṣẹda `Cell<T>` kan, pẹlu iye `Default` fun T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Ṣẹda `Cell` tuntun ti o ni iye ti a fun.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Ṣeto iye ti o wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Swaps awọn iye ti awọn meji ẹyin.
    /// Iyato pẹlu `std::mem::swap` ni pe iṣẹ yii ko nilo itọkasi `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // Aabo: Eleyi le je eewu ti o ba ti a npe ni lati lọtọ awon, sugbon `Cell`
        // jẹ `!Sync` nitorinaa eyi kii yoo ṣẹlẹ.
        // Eleyi tun yoo ko sọ itilẹyin ti awọn ifẹnule niwon `Cell` mu ki daju nkan miran yoo wa ni ntokasi si boya ti awọn wọnyi `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Rọpo ti o wa ninu iye pẹlu `val`, ati ki o pada atijọ ti o wa ninu iye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // Aabo: Eyi le fa awọn meya data ti a ba pe lati okun ti o yatọ,
        // ṣugbọn `Cell` jẹ `!Sync` nitorinaa eyi kii yoo ṣẹlẹ.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Ṣi iye naa kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Pada ẹda ti iye ti o wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // Aabo: Eyi le fa awọn meya data ti a ba pe lati okun ti o yatọ,
        // ṣugbọn `Cell` jẹ `!Sync` nitorinaa eyi kii yoo ṣẹlẹ.
        unsafe { *self.value.get() }
    }

    /// Mu awọn ti o wa ninu iye nipa lilo iṣẹ kan ati ki o pada titun iye.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Pada ijuboluwole ainiti si data ipilẹ ninu sẹẹli yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Pada itọkasi iyipada kan si data ipilẹ.
    ///
    /// Yi ipe borrows `Cell` mutably (ni sakojo-akoko) eyi ti onigbọwọ wipe a gbà nikan ni itọkasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Pada `&Cell<T>` kan lati `&mut T` kan
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // Aabo: `&mut` ṣe idaniloju iraye si alailẹgbẹ.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Gba iye ti awọn cell, nlọ `Default::default()` ni awọn oniwe-ibi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Pada `&[Cell<T>]` kan lati `&Cell<[T]>` kan
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // Aabo: `Cell<T>` ni ipilẹ iranti kanna bii `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Ipo iranti ti o le yipada pẹlu awọn ofin awin daadaa ṣayẹwo
///
/// Wo [module-level documentation](self) fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Aṣiṣe ti a pada nipasẹ [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Aṣiṣe ti a pada nipasẹ [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Awọn iye to dara duro fun nọmba `Ref` ti nṣiṣe lọwọ.Awọn iye odi ṣe aṣoju nọmba ti `RefMut` ti nṣiṣe lọwọ.
// Pupọ `RefMut`s le ṣiṣẹ nikan ni akoko kan ti wọn ba tọka si iyatọ, awọn ẹya ti ko ni iparọ ti `RefCell` kan (fun apẹẹrẹ, awọn sakani oriṣiriṣi oriṣiriṣi).
//
// `Ref` ati `RefMut` jẹ awọn ọrọ mejeeji ni iwọn, ati nitorinaa o ṣee ṣe ko ni to `Ref`s tabi`RefMut`s ninu aye lati bori idaji ti ibiti `usize`.
// Bayi, a `BorrowFlag` yio jasi ko kún tabi underflow.
// Sibẹsibẹ, eyi kii ṣe onigbọwọ, bi eto aarun kan le ṣe leralera ṣẹda ati lẹhinna mem::forget `Ref`s tabi`RefMut`s.
// Nitorinaa, gbogbo koodu gbọdọ ṣayẹwo ni gbangba fun ṣiṣan omi ati ṣiṣan silẹ lati yago fun ailewu, tabi o kere ju huwa ni deede ninu iṣẹlẹ ti ṣiṣan tabi ṣiṣan omi ṣẹlẹ (fun apẹẹrẹ, wo BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Ṣẹda `RefCell` tuntun ti o ni `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Je `RefCell`, n pada iye ti a we.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Niwon yi iṣẹ gba `self` (awọn `RefCell`) nipa iye, awọn alakojo statically verifies ti o wa ni Lọwọlọwọ kò ya.
        //
        self.value.into_inner()
    }

    /// Rọpo iye ti a we pẹlu tuntun kan, n da iye atijọ pada, laisi ibaṣe boya ọkan.
    ///
    ///
    /// Iṣẹ yii baamu si [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics ti iye ba ya lọwọlọwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Rọpo we iye pẹlu titun kan se isiro lati `f`, pada atijọ iye, lai deinitializing boya ọkan.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti iye ba ya lọwọlọwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Swaps iye ti a we ti `self` pẹlu iye ti a we ti `other`, laisi deinitializing boya ọkan.
    ///
    ///
    /// Iṣẹ yii baamu si [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Ailopin le ya iye ti a we.
    ///
    /// Yiya na titi di igba ti awọn ọna `Ref` ti o pada pada.
    /// Ọpọ aileyipada borrows le wa ni ya jade ni akoko kanna.
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti iye ti wa ni Lọwọlọwọ mutably ya.
    /// Fun kan ti kii-panicking iyatọ, lo [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Ohun apẹẹrẹ ti panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Aiṣepe ya iye ti a we, ti o da aṣiṣe ti o ba jẹ pe iye lọwọlọwọ yawo ni alayipada.
    ///
    ///
    /// Yiya na titi di igba ti awọn ọna `Ref` ti o pada pada.
    /// Ọpọ aileyipada borrows le wa ni ya jade ni akoko kanna.
    ///
    /// Eyi ni iyatọ ti ko ni ẹru ti [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // Aabo: `BorrowRef` ṣe idaniloju pe iraye ailopin nikan wa
            // si iye lakoko yiya.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably borrows awọn ti a we iye.
    ///
    /// Awọn wín, na titi ti pada `RefMut` tabi gbogbo `RefMut`s yo lati o jade dopin.
    ///
    /// Iye ko le wa ni ya nigba ti yi wín, ti nṣiṣe lọwọ.
    ///
    /// # Panics
    ///
    /// Panics ti iye ba ya lọwọlọwọ.
    /// Fun iyatọ ti ko ni ẹru, lo [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Ohun apẹẹrẹ ti panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutably borrows awọn ti a we iye, pada ohun ašiše ti o ba ti iye ti wa ni Lọwọlọwọ ya.
    ///
    ///
    /// Awọn wín, na titi ti pada `RefMut` tabi gbogbo `RefMut`s yo lati o jade dopin.
    /// Iye ko le wa ni ya nigba ti yi wín, ti nṣiṣe lọwọ.
    ///
    /// Eyi ni iyatọ ti ko ni ẹru ti [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // Aabo: `BorrowRef` ṣe onigbọwọ iraye alailẹgbẹ.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Pada ijuboluwole ainiti si data ipilẹ ninu sẹẹli yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Pada itọkasi iyipada kan si data ipilẹ.
    ///
    /// Yi ipe borrows `RefCell` mutably (ni sakojo-akoko) ki nibẹ ni ko si nilo fun ìmúdàgba sọwedowo.
    ///
    /// Sibẹsibẹ ṣọra: ọna yii nireti pe `self` lati jẹ iyipada, eyiti o jẹ gbogbo kii ṣe ọran nigba lilo `RefCell` kan.
    ///
    /// Ya kan wo ni [`borrow_mut`] ọna dipo ti o ba ti `self` ni ko mutable.
    ///
    /// Bakannaa, jọwọ jẹ mọ ti yi ọna ti o jẹ nikan fun awọn pataki ayidayida ati ki o jẹ maa n ko ohun ti o fẹ.
    /// Ni ọran ti iyemeji, lo [`borrow_mut`] dipo.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Mu awọn ipa ti ti jo ẹṣọ lori wín, ipinle ti `RefCell`.
    ///
    /// Ipe yii jọra si [`get_mut`] ṣugbọn amọja diẹ sii.
    /// O ya `RefCell` ni adaṣe lati rii daju pe ko si awọn awin kankan ati lẹhinna tunto ipasẹ titele ipinpin awọn yiyalo tunto.
    /// Eleyi jẹ ti o yẹ ti o ba ti diẹ ninu awọn `Ref` tabi `RefMut` borrows ti a ti jo.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Aiṣepe ya iye ti a we, ti o da aṣiṣe ti o ba jẹ pe iye lọwọlọwọ yawo ni alayipada.
    ///
    /// # Safety
    ///
    /// Kii `RefCell::borrow`, ọna yii ko ni aabo nitori ko pada `Ref` kan, nitorinaa fi asia awin silẹ laiṣe.
    /// Ni idaniloju yawo `RefCell` lakoko ti itọkasi ti o pada nipasẹ ọna yii wa laaye jẹ ihuwasi ti a ko ṣalaye.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // AABO: A ṣayẹwo pe ko si ẹnikan ti o nkọ kikọ ni bayi, ṣugbọn o jẹ
            // ojuse olupe lati rii daju pe ko si ẹnikan ti o kọwe titi itọkasi ti o pada ko si ni lilo.
            // Paapaa, `self.value.get()` tọka si iye ti `self` jẹ ati nitorinaa o jẹ ẹri lati wulo fun igbesi aye ti `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Gba awọn we iye, nlọ `Default::default()` ni awọn oniwe-ibi.
    ///
    /// # Panics
    ///
    /// Panics ti iye ba ya lọwọlọwọ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ti o ba ti iye ti wa ni Lọwọlọwọ mutably ya.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Ṣẹda a `RefCell<T>`, pẹlu awọn `Default` iye fun T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ti iye ninu boya `RefCell` ba ya lọwọlọwọ.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Alekun yiya le ja si iye ti kii ṣe kika (<=0) ni awọn iṣẹlẹ wọnyi:
            // 1. O jẹ <0, ie awọn awin kikọ wa, nitorinaa a ko le gba laaye ka iwe kika nitori awọn ofin aliali itọkasi Rust
            // 2.
            // O jẹ isize::MAX (iye ti o ga julọ ti awọn iwe kika) ati pe o ti ṣan sinu isize::MIN (iye ti o pọ julọ ti awọn awin kikọ) nitorinaa a ko le gba yiya kika ni afikun nitori isize ko le ṣe aṣoju ọpọlọpọ awọn yiya kika (eyi le ṣẹlẹ nikan ti Iwọ mem::forget diẹ sii ju iye igbagbogbo kekere ti `Ref`s, eyiti kii ṣe iṣe ti o dara)
            //
            //
            //
            //
            None
        } else {
            // Alekun yiya le ja si iye kika (> 0) ni awọn iṣẹlẹ wọnyi:
            // 1. O jẹ=0, ie kii ṣe ya ya, ati pe a n gba yiya kika akọkọ
            // 2. O jẹ> 0 ati <isize::MAX, ie
            // awọn awin kika wa, ati isize tobi to lati ṣe aṣoju nini yiya kika diẹ sii
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Niwon yi Ref wa, a mọ awọn wín, flag ni a kika wín,.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Ṣe idiwọ counter ti yawo lati ṣan sinu yiya kikọ.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Murasilẹ itọkasi ti a yawo si iye kan ninu apoti `RefCell` kan.
/// A wrapper Iru fun ohun immutably ya iye lati kan `RefCell<T>`.
///
/// Wo [module-level documentation](self) fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Awọn ẹda kan `Ref`.
    ///
    /// `RefCell` ti wa ni yiya tẹlẹ laileto, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `Ref::clone(...)`.
    /// Ṣiṣe `Clone` kan tabi ọna kan yoo dabaru pẹlu lilo ibigbogbo ti `r.borrow().clone()` lati ṣe ẹda oniye awọn akoonu ti `RefCell` kan.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Ṣe `Ref` tuntun fun paati ti data ti a yawo.
    ///
    /// `RefCell` ti wa ni yiya tẹlẹ laileto, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `Ref::map(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Ṣe `Ref` tuntun fun paati aṣayan ti data ti a yawo.
    /// Awọn atilẹba oluso ti wa ni pada bi ohun `Err(..)` ti o ba ti bíbo pada `None`.
    ///
    /// `RefCell` ti wa ni yiya tẹlẹ laileto, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `Ref::filter_map(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Pin `Ref` kan si ọpọ `Ref`s fun oriṣiriṣi awọn paati ti data ti a yawo.
    ///
    /// `RefCell` ti wa ni yiya tẹlẹ laileto, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `Ref::map_split(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Lọkan padà sinu a tọka si awọn abele data.
    ///
    /// Awọn abele `RefCell` ko le wa ni mutably ya lati lẹẹkansi ati ki yoo ma han tẹlẹ immutably ya.
    ///
    /// O ti wa ni ko kan ti o dara agutan lati jo diẹ ẹ sii ju kan ibakan nọmba ti jo.
    /// `RefCell` le ṣee yiyalo lailewu ti o ba jẹ pe nọmba to kere ju ti n jo ti ṣẹlẹ lapapọ.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `Ref::leak(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Nipa igbagbe Ref yii a rii daju pe counter awin ni RefCell ko le pada si UNUSED laarin igbesi aye `'b`.
        // Tuntunto ipo titele itọkasi yoo nilo itọkasi alailẹgbẹ si RefCell ti a yawo.
        // Ko si awọn itọkasi atunto siwaju si siwaju sii ti a le ṣẹda lati sẹẹli atilẹba.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Ṣe `RefMut` tuntun fun paati ti data ti a yawo, fun apẹẹrẹ, iyatọ enum kan.
    ///
    /// `RefCell` ti wa ni mutably ya tẹlẹ, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `RefMut::map(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fix awin-ṣayẹwo
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Ṣe `RefMut` tuntun fun paati aṣayan ti data ti a yawo.
    /// Awọn atilẹba oluso ti wa ni pada bi ohun `Err(..)` ti o ba ti bíbo pada `None`.
    ///
    /// `RefCell` ti wa ni mutably ya tẹlẹ, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `RefMut::filter_map(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fix awin-ṣayẹwo
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // Aabo: iṣẹ Oun ni pẹlẹpẹlẹ ohun iyasoto itọkasi fun awọn ti iye
        // ti awọn oniwe-ipe nipa `orig`, ati awọn ijuboluwole jẹ nikan de-rannileti inu ti awọn iṣẹ ipe kò gbigba awọn iyasoto tọka si sa.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // Aabo: kanna bi loke.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Pin a `RefMut` sinu ọpọ `RefMut`s fun yatọ si irinše ti awọn ya data.
    ///
    /// `RefCell` ti o wa ni ipilẹ yoo wa ni ya lopolopo ni adaṣe titi ti awọn mejeeji yoo pada `RefMut`s ti ko le kọja.
    ///
    /// `RefCell` ti wa ni mutably ya tẹlẹ, nitorinaa eyi ko le kuna.
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `RefMut::map_split(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Iyipada sinu itọkasi iyipada si data ipilẹ.
    ///
    /// Awọn abele `RefCell` ko le wa ni ya lati lẹẹkansi ati yoo ma han tẹlẹ mutably ya, ṣiṣe awọn pada tọka awọn nikan lati awọn inu ilohunsoke.
    ///
    ///
    /// Eyi jẹ iṣẹ ti o ni nkan ti o nilo lati lo bi `RefMut::leak(...)`.
    /// A ọna ti yoo dabaru pẹlu awọn ọna ti kanna orukọ lori awọn awọn akoonu ti a `RefCell` lo nipasẹ `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Nipa forgetting yi BorrowRefMut a rii daju wipe awọn wín, counter ni RefCell ko le lọ pada si ISINMI laarin awọn s'aiye `'b`.
        // Tuntunto ipo titele itọkasi yoo nilo itọkasi alailẹgbẹ si RefCell ti a yawo.
        // Ko si siwaju jo le ti wa ni da lati atilẹba cell laarin ti s'aiye, ṣiṣe awọn ti isiyi wín, awọn nikan itọkasi fun awọn ti o ku s'aiye.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Kii BorrowRefMut::clone, a pe tuntun lati ṣẹda ibẹrẹ
        // itọkasi iyipada, ati nitorinaa ko gbọdọ jẹ awọn itọkasi to wa tẹlẹ.
        // Bayi, nigba ti oniye increments awọn mutable refcount, nibi ti a kedere nikan gba lọ lati ISINMI to ISINMI, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Awọn ere ibewo kan `BorrowRefMut`.
    //
    // Eyi wulo nikan ti a ba lo `BorrowRefMut` kọọkan lati tọka itọka iyipada si iyatọ kan, ibiti a ko le kọja ti ohun atilẹba.
    //
    // Eyi ko si ni ẹda oniye ki koodu naa ko pe ni taara.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Ṣe idiwọ kika awin lati ṣiṣan.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Iru ohun elo ti a fi ipari mu fun iye ti yawo mutably lati `RefCell<T>` kan.
///
/// Wo [module-level documentation](self) fun diẹ sii.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Atijọ ohun akọkọ fun iyipada inu ni Rust.
///
/// Ti o ba ni itọkasi `&T`, lẹhinna ni deede ni Rust akopọ n ṣe awọn iṣapeye ti o da lori imọ pe `&T` tọka si data ti ko le yipada.Mutating ti data, fun apẹẹrẹ nipasẹ ohun inagijẹ tabi nipa transmuting ohun `&T` sinu ohun `&mut T`, ti wa ni kà aisọye ihuwasi.
/// `UnsafeCell<T>` kuro-kuro ninu iṣeduro ailopin fun `&T`: itọkasi itọkasi pinpin `&UnsafeCell<T>` le tọka si data ti n yipada.Eleyi ni a npe ni "interior mutability".
///
/// Gbogbo awọn oriṣi miiran ti o gba iyipada ti inu, bii `Cell<T>` ati `RefCell<T>`, lo inu lati lo `UnsafeCell` lati fi ipari data wọn.
///
/// Akọsilẹ ti o nikan aileyipada lopolopo fun pín jo ti wa ni fowo nipasẹ `UnsafeCell`.Onigbọwọ alailẹgbẹ fun awọn itọkasi iyipada le ko kan.Ko si *ọna* ti ofin lati gba alilorukọ `&mut`, paapaa pẹlu `UnsafeCell<T>`.
///
/// The `UnsafeCell` API ara jẹ tekinikali irorun: [`.get()`] yoo fun ọ a aise ijuboluwole `*mut T` si awọn oniwe-akoonu ti.O ti wa ni soke si _you_ bi awọn ti afoyemọ onise lati lo ti aise ijuboluwole o ti tọ.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Awọn ofin aliali Rust tootọ jẹ diẹ ni ṣiṣan, ṣugbọn awọn aaye akọkọ kii ṣe ariyanjiyan:
///
/// - Ti o ba ṣẹda kan ailewu itọkasi pẹlu s'aiye `'a` (boya a `&T` tabi `&mut T` itọkasi) ti o ni wiwọle nipa ailewu koodu (fun apẹẹrẹ, nitori ti o pada o), ki o si kò gbọdọ wọle si awọn data ni eyikeyi ọna ti o ntako ti itọkasi fun awọn ku ti `'a`.
/// Fun apẹẹrẹ, eyi tumọ si pe ti o ba mu `*mut T` lati `UnsafeCell<T>` kan ti o sọ ọ si `&T`, lẹhinna data ninu `T` gbọdọ wa ni aiyipada (modulo eyikeyi data `UnsafeCell` ti o wa laarin `T`, dajudaju) titi di igba igbesi aye itọkasi yẹn yoo pari.
/// Bakan naa, ti o ba ṣẹda itọkasi `&mut T` kan ti o ti tu silẹ si koodu ailewu, lẹhinna o ko gbọdọ wọle si data laarin `UnsafeCell` titi itọkasi yẹn yoo fi pari.
///
/// - Ni gbogbo igba, o gbọdọ yago fun awọn ije data.Ti o ba ti ọpọ awon ni wiwọle si awọn kanna `UnsafeCell`, ki o si eyikeyi Levin gbọdọ ni a to dara ṣẹlẹ-ṣaaju ki o to relation si gbogbo awọn miiran accesses (tabi lilo atomics).
///
/// Lati ran pẹlu to dara oniru, awọn wọnyi iṣẹlẹ ti wa ni kedere polongo ofin fun nikan-asapo koodu:
///
/// 1. Itọkasi `&T` kan ni a le tu silẹ si koodu ailewu ati nibẹ o le wa pẹlu awọn itọkasi `&T` miiran, ṣugbọn kii ṣe pẹlu `&mut T` kan
///
/// 2. A `&mut T` itọkasi le wa ni tu si ailewu koodu pese bẹni miiran `&mut T` tabi `&T` àjọ-tẹlẹ pẹlu o.A `&mut T` gbọdọ ma wa ni oto.
///
/// Akọsilẹ ti npada mutating awọn awọn akoonu ti ẹya `&UnsafeCell<T>` (ani nigba ti miiran `&UnsafeCell<T>` jo inagijẹ alagbeka) jẹ ok (ti a pese ti o lagabara awọn loke invariants diẹ ninu awọn miiran ọna), o jẹ ṣi aisọye iwa to ni ọpọ `&mut UnsafeCell<T>` aliases.
/// Ti o ni, `UnsafeCell` ni a wrapper še lati ni pataki kan ibaraenisepo pẹlu _shared_ accesses (_i.e._, nipasẹ ohun `&UnsafeCell<_>` itọkasi);ko si idan ohunkohun nigbati o ba n ba _exclusive_ accesses (_e.g._ ṣiṣẹ, nipasẹ `&mut UnsafeCell<_>` kan): bakanna sẹẹli tabi iye ti a fi we le jẹ aliali fun iye akoko ti yiya `&mut` yẹn.
///
/// Eyi ni a showcased nipasẹ awọn [`.get_mut()`] accessor, ti o jẹ a _safe_ getter ti o egbin a `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Eyi ni àpẹẹrẹ showcasing bi o si fun õrun mutate awọn awọn akoonu ti ẹya `UnsafeCell<_>` pelu nibẹ ni jije ọpọ jo aliasing awọn cell:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Gba ọpọ/nigbakanna/pín jo si kanna `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // Aabo: laarin yi dopin nibẹ ni o wa ko si miiran to jo si `x` ká akoonu ti,
///     // nitorinaa tiwa jẹ adaṣe daradara.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- wín,-+
///     *p1_exclusive += 27; // |
/// } // <---------- ko le kọja aaye yii -------------------+
///
/// unsafe {
///     // Aabo: laarin yi dopin eniti o retí lati ni iyasoto wiwọle si `x` ká akoonu ti,
///     // nitorinaa a le ni awọn iraye pipin lọpọlọpọ ni nigbakanna.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Apẹẹrẹ atẹle n ṣe afihan otitọ pe iraye si iyasoto si `UnsafeCell<T>` tumọ si iraye si iyasoto si `T` rẹ:
///
/// ```rust
/// #![forbid(unsafe_code)] // pẹlu awọn iraye si iyasoto,
///                         // `UnsafeCell` jẹ ohun elo ti ko ni opiti sihin, nitorinaa ko nilo fun `unsafe` nibi.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Gba itọkasi iyasọtọ ti a ṣajọ-akoko-ṣayẹwo si `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Pẹlu itọkasi iyasoto, a le ṣe iyipada awọn akoonu fun ọfẹ.
/// *p_unique.get_mut() = 0;
/// // Tabi, ni deede:
/// x = UnsafeCell::new(0);
///
/// // Nigbati a ba ni iye, a le jade awọn akoonu naa ni ọfẹ.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Oro titun kan apeere ti `UnsafeCell` eyi ti yoo fi ipari si awọn pàtó kan iye.
    ///
    ///
    /// Gbogbo iraye si iye ti inu nipasẹ awọn ọna jẹ `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Ṣi iye naa kuro.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Gba ijuboluwole iyipada si iye ti a we.
    ///
    /// Eyi le sọ si ijuboluwo iru eyikeyi.
    /// Rii daju wipe awọn wiwọle jẹ oto (ko si ti nṣiṣe lọwọ jo, mutable tabi ko) nigbati simẹnti to `&mut T`, ati rii daju wipe nibẹ ni o wa ti ko si iyipada tabi mutable aliases ti lọ lori nigba ti simẹnti to `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // A le o kan lé awọn ijuboluwole lati `UnsafeCell<T>` to `T` nitori ti #[repr(transparent)].
        // Eyi lo ipo pataki ti libstd, ko si iṣeduro fun koodu olumulo pe eyi yoo ṣiṣẹ ni awọn ẹya future ti akopọ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Pada itọkasi iyipada kan si data ipilẹ.
    ///
    /// Ipe yii ya `UnsafeCell` ni adaṣe (ni sakojo-akoko) eyiti o ṣe onigbọwọ pe a ni itọkasi nikan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Gba ijuboluwole iyipada si iye ti a we.
    /// Awọn iyato to [`get`] ni wipe yi iṣẹ gba a aise ijuboluwole, eyi ti o jẹ wulo lati yago fun awọn ẹda ti ibùgbé jo.
    ///
    /// Abajade le ṣee sọ si ijuboluwo iru eyikeyi.
    /// Rii daju pe iraye si jẹ alailẹgbẹ (ko si awọn itọkasi ti nṣiṣe lọwọ, yiyi pada tabi rara) nigbati o n sọ si `&mut T`, ati rii daju pe ko si awọn iyipada tabi awọn aliasi iyipada ti n lọ nigba sisọ si `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Ibẹrẹ pẹlẹpẹlẹ ti `UnsafeCell` nilo `raw_get`, bi pipe `get` yoo nilo ṣiṣẹda itọkasi kan si data ainiti oye:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // A le o kan lé awọn ijuboluwole lati `UnsafeCell<T>` to `T` nitori ti #[repr(transparent)].
        // Eyi lo ipo pataki ti libstd, ko si iṣeduro fun koodu olumulo pe eyi yoo ṣiṣẹ ni awọn ẹya future ti akopọ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Ṣẹda `UnsafeCell` kan, pẹlu iye `Default` fun T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}