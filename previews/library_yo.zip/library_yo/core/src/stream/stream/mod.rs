use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Ni wiwo fun awọn olugbagbọ pẹlu awọn onigbọwọ asynchronous.
///
/// Eyi ni ṣiṣan akọkọ trait.
/// Fun diẹ sii nipa imọran ti awọn ṣiṣan ni gbogbogbo, jọwọ wo [module-level documentation].
/// Ni pataki, o le fẹ lati mọ bi a ṣe le [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Iru awọn ohun ti o mu jade nipasẹ ṣiṣan naa.
    type Item;

    /// Gbiyanju lati fa jade nigbamii ti iye yi san, fiforukọṣilẹ awọn ti isiyi-ṣiṣe fun wakeup ti o ba ti iye jẹ ko sibẹsibẹ wa, ki o si pada `None` ti o ba ti san ni ti re.
    ///
    /// # Pada iye
    ///
    /// Nibẹ ni o wa ni ọpọlọpọ awọn ti ṣee ṣe pada iye, kọọkan afihan a pato san ipinle:
    ///
    /// - `Poll::Pending` tumọ si pe iye atẹle ti ṣiṣan yii ko ṣetan sibẹsibẹ.Awọn imuse yoo rii daju pe iṣẹ-ṣiṣe lọwọlọwọ yoo wa ni iwifunni nigbati iye atẹle le ṣetan.
    ///
    /// - `Poll::Ready(Some(val))` tumọ si pe ṣiṣan naa ti ṣe agbejade iye kan, `val`, ati pe o le ṣe awọn iye siwaju si lori awọn ipe `poll_next` atẹle.
    ///
    /// - `Poll::Ready(None)` ọna ti awọn san ti fopin si, ati `poll_next` ko yẹ ki o wa ni invoked lẹẹkansi.
    ///
    /// # Panics
    ///
    /// Lọgan ti a san ti pari (pada `Ready(None)` from `poll_next`), pipe awọn oniwe-`poll_next` ọna lẹẹkansi le panic, dènà lailai, tabi fa miiran iru isoro; awọn `Stream` trait ibiti ko si ibeere lori awọn ipa ti iru ipe kan.
    ///
    /// Sibẹsibẹ, bi ọna `poll_next` ko ṣe samisi `unsafe`, awọn ofin deede ti Rust lo: awọn ipe ko gbọdọ fa ihuwasi aisọye (ibajẹ iranti, lilo ti ko tọ ti awọn iṣẹ `unsafe`, tabi iru), laibikita ipo ṣiṣan naa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Pada awọn aala lori ipari gigun ti ṣiṣan naa.
    ///
    /// Pataki, `size_hint()` pada a tuple ibi ti awọn akọkọ ano ni isalẹ dè, ati awọn keji ano ni oke dè.
    ///
    /// Idaji keji ti awọn tuple o ti wa ni pada jẹ ẹya [`Option`] '<`[`usize`]'> '.
    /// A [`None`] nibi ọna ti o boya nibẹ ni ko si mọ oke dè, tabi oke dè jẹ o tobi ju [`usize`].
    ///
    /// # Awọn akọsilẹ imuse
    ///
    /// O ti wa ni ko nipa pe a san imuse egbin awọn polongo nọmba ti eroja.Omi iṣan omi kan ti o ni ọkọ ayọkẹlẹ le fun ni kere ju ala isalẹ tabi diẹ sii ju opin awọn eroja lọ.
    ///
    /// `size_hint()` ti wa ni ipinnu akọkọ lati ṣee lo fun awọn imudarasi bii aaye ifipamọ fun awọn eroja ti ṣiṣan naa, ṣugbọn ko gbọdọ ni igbẹkẹle si apẹẹrẹ, fi awọn sọwedowo aala silẹ ni koodu ti ko ni aabo.
    /// Ohun ti ko tọ imuse ti `size_hint()` yẹ ki o ko ja si iranti ailewu lile.
    ///
    /// Ti o wi, awọn imuse yẹ ki o pese kan ti o tọ idiyelé rẹ, nitori bibẹkọ ti o yoo jẹ kan ti o ṣẹ ti awọn trait ká Ilana.
    ///
    /// Awọn aiyipada imuse padà '(0, [`None`]') 'eyi ti o jẹ ti o tọ fun eyikeyi odò.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}