//! Iparapọ asynchronous Composable.
//!
//! Ti futures jẹ awọn iye asynchronous, lẹhinna awọn ṣiṣan jẹ aṣetunṣe asynchronous.
//! Ti o ba ti rii ara rẹ pẹlu akojọpọ asynchronous ti diẹ ninu iru, ati pe o nilo lati ṣe iṣiṣẹ kan lori awọn eroja ti gbigba ti a sọ, iwọ yoo yara yara sinu 'streams'.
//! Odò ti wa ni darale lo ninu idiomatic gbígbé Rust koodu, ki o ká tọ di faramọ pẹlu wọn.
//!
//! Ṣaaju ki o to ṣalaye diẹ sii, jẹ ki a sọrọ nipa bawo ni a ṣe ṣeto module yii:
//!
//! # Organization
//!
//! Eleyi module ti wa ni ibebe ṣeto nipasẹ Iru:
//!
//! * [Traits] ni o wa ni mojuto ìka: awọn wọnyi traits setumo ohun ti Iru odò tẹlẹ ati ohun ti o le se pẹlu wọn.Awọn ọna ti traits wọnyi tọ lati fi diẹ ninu akoko ikẹkọ diẹ sii sinu.
//! * Awọn iṣẹ pese diẹ ninu awọn ọna iranlọwọ lati ṣẹda diẹ ninu awọn ṣiṣan ipilẹ.
//! * Awọn opo jẹ igbagbogbo awọn iru ipadabọ ti awọn ọna pupọ lori traits module yii.Iwọ yoo maa fẹ lati wo ọna ti o ṣẹda `struct`, dipo `struct` funrararẹ.
//! Fun alaye diẹ sii nipa idi ti, wo '[Ṣiṣe ṣiṣan Ṣiṣẹ](#imuṣẹ-ṣiṣan)'.
//!
//! [Traits]: #traits
//!
//! O n niyen!Jẹ ká iwo sinu ṣiṣan.
//!
//! # Stream
//!
//! Okan ati ẹmi ti module yii ni [`Stream`] trait.Mojuto ti [`Stream`] dabi eleyi:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Kii `Iterator`, `Stream` ṣe iyatọ laarin ọna [`poll_next`] eyiti o lo nigbati o n ṣe imuse `Stream`, ati ọna (to-be-implemented) `next` eyiti o lo nigba lilo ṣiṣan kan.
//!
//! Awọn alabara ti `Stream` nikan nilo lati ronu `next`, eyiti nigbati a pe, pada future eyiti o mu `Option<Stream::Item>` wa.
//!
//! future ti o pada nipasẹ `next` yoo fun `Some(Item)` niwọn igba ti awọn eroja wa, ati ni kete ti gbogbo wọn ba ti rẹ wọn, yoo mu `None` jade lati fihan pe aṣetunṣe ti pari.
//! Ti o ba ti a ba nduro lori nkankan gbígbé to pari, awọn future yoo duro titi ti san ti šetan lati ikore lẹẹkansi.
//!
//! Awọn ṣiṣan ara ẹni kọọkan le yan lati tun bẹrẹ aṣetunṣe, nitorinaa pipe `next` lẹẹkansii le tabi ko le fun ni ni `Some(Item)` lẹẹkansii ni aaye kan.
//!
//! [`Stream`] 's ni kikun definition pẹlu nọmba kan ti miiran awọn ọna bi daradara, sugbon ti won ti wa ni aiyipada awọn ọna, itumọ ti lori oke ti [`poll_next`], ati ki o gba wọn fun free.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Ṣiṣe ṣiṣan
//!
//! Ṣiṣẹda kan san ti ara rẹ je meji awọn igbesẹ: ṣiṣẹda a `struct` lati mu awọn san ká ipinle, ati ki o si nse [`Stream`] fun awọn ti o `struct`.
//!
//! Jẹ ki a ṣe ṣiṣan kan ti a npè ni `Counter` eyiti o ka lati `1` si `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Ni akọkọ, ipilẹ:
//!
//! /// Omi eyiti o ka lati ọkan si marun
//! struct Counter {
//!     count: usize,
//! }
//!
//! // a fẹ wa ka lati bẹrẹ ni ọkan, ki jẹ ki ká fi kan new() ọna lati iranlọwọ.
//! // Eleyi jẹ ko muna pataki, sugbon ni rọrun.
//! // Akiyesi pe a bẹrẹ `count` ni odo, a yoo rii idi ti imuse `poll_next()`'s ni isalẹ.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Lẹhinna, a ṣe `Stream` fun `Counter` wa:
//!
//! impl Stream for Counter {
//!     // a yoo ka pẹlu lilo
//!     type Item = usize;
//!
//!     // poll_next() jẹ ọna ti a beere nikan
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Increment wa ka.Eleyi jẹ idi ti a bere ni odo.
//!         self.count += 1;
//!
//!         // Ṣayẹwo lati rii boya a ti pari kika tabi rara.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Awọn ṣiṣan jẹ *ọlẹ*.Eyi tumọ si pe ṣiṣeda ṣiṣan kan kii ṣe _do_ odidi pupọ.Ko si ohun ti o ṣẹlẹ gaan titi iwọ o fi pe `next`.
//! Eyi jẹ igba miiran orisun iruju nigbati o ba ṣẹda ṣiṣan nikan fun awọn ipa ẹgbẹ rẹ.
//! Awọn alakojo yoo kilo fun wa nipa yi ni irú ti ihuwasi:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;