//! Awọn iru atomiki
//!
//! Awọn iru Atomiki pese ibaraẹnisọrọ atijọ ti iranti-iranti laarin awọn okun, ati pe o jẹ awọn bulọọki ile ti awọn iru igbakan miiran.
//!
//! Atokun yii n ṣalaye awọn ẹya atomiki ti nọmba ti a yan ti awọn iru atijo, pẹlu [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], abbl.
//! Atomic orisi bayi mosi pe, nigba ti lo o ti tọ, Muu awọn imudojuiwọn laarin awon.
//!
//! Ọna kọọkan gba [`Ordering`] eyiti o ṣe aṣoju agbara ti idena iranti fun iṣẹ naa.Awọn wọnyi ni orderings ni o wa kanna bi awọn [C++20 atomic orderings][1].Fun alaye siwaju sii wo awọn [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Awọn oniye Atomiki jẹ ailewu lati pin laarin awọn okun (wọn ṣe [`Sync`]) ṣugbọn wọn ko funrararẹ pese ilana fun pinpin ati tẹle [threading model](../../../std/thread/index.html#the-threading-model) ti Rust.
//!
//! Ọna ti o wọpọ julọ lati pin oniyipada atomiki ni lati fi sii sinu [`Arc`][arc] (itọka atokasi atomiki-ka-pin pin).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Awọn iru Atomiki le wa ni fipamọ ni awọn oniyipada aimi, ti ipilẹṣẹ nipa lilo awọn olupilẹṣẹ igbagbogbo bi [`AtomicBool::new`].Atomic statics ti wa ni igba ti a lo fun ọlẹ agbaye initialization.
//!
//! # Portability
//!
//! Gbogbo awọn iru atomiki ninu modulu yii jẹ ẹri lati jẹ [lock-free] ti wọn ba wa.Eleyi tumo si won ko ba ko fipa gba a agbaye mutex.Awọn iru Atomiki ati awọn iṣiṣẹ ko ṣe onigbọwọ lati jẹ ominira-iduro.
//! Eyi tumọ si pe awọn iṣẹ bii `fetch_or` le ṣee ṣe imuse pẹlu ọna kika-ati-swap.
//!
//! Atomic mosi le wa ni muse ni ẹkọ Layer pẹlu tobi-iwọn atomics.Fun apẹẹrẹ diẹ ninu awọn iru ẹrọ lo awọn itọnisọna atomiki 4-baiti lati ṣe `AtomicI8`.
//! Akọsilẹ ti yi emulation yẹ ki o ko ni ohun ikolu lori titunse ti koodu, o ni o kan nkankan lati wa ni mọ ti.
//!
//! Awọn iru atomiki inu module yii le ma wa lori gbogbo awọn iru ẹrọ.Awọn atomiki orisi nibi ni o wa gbogbo eroja to wa ni, sibẹsibẹ, ati ki o le gbogbo wa ni gbarale lori wa tẹlẹ.Diẹ ninu awọn imukuro akiyesi ni:
//!
//! * PowerPC ati awọn iru ẹrọ MIPS pẹlu awọn itọka 32-bit ko ni awọn iru `AtomicU64` tabi `AtomicI64`.
//! * ARM awọn iru ẹrọ bii `armv5te` ti kii ṣe fun Linux nikan pese awọn iṣẹ `load` ati `store`, ati pe ko ṣe atilẹyin Awọn iṣẹ Afiwe ati Swap (CAS), bii `swap`, `fetch_add`, abbl.
//! Ni afikun lori Linux, awọn iṣẹ CAS wọnyi ni imuse nipasẹ [operating system support], eyiti o le wa pẹlu ijiya iṣẹ kan.
//! * ARM fojusi pẹlu `thumbv6m` nikan pese `load` ati `store` mosi, ki o si ma ko ni atilẹyin Afiwe ati siwopu (CAS) mosi, gẹgẹ bi awọn `swap`, `fetch_add`, bbl
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Ṣe akiyesi pe awọn iru ẹrọ future le ṣafikun ti o tun ko ni atilẹyin fun diẹ ninu awọn iṣẹ atomiki.Koodu to ṣee gbe pọ julọ yoo fẹ lati ṣọra nipa iru awọn iru atomiki ti a lo.
//! `AtomicUsize` ati `AtomicIsize` o wa ni gbogbo awọn julọ to šee, sugbon ani ki o si ti won ba ko wa nibi gbogbo.
//! Fun itọkasi, awọn `std` ìkàwé nbeere ijuboluwole-won atomics, biotilejepe `core` wo ni ko.
//!
//! Lọwọlọwọ o nilo lati lo `#[cfg(target_arch)]` nipataki lati ṣajọ ipo ni koodu pẹlu atomiki.Nibẹ jẹ ẹya riru `#[cfg(target_has_atomic)]` bi daradara eyi ti o le wa ni diduro ni future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Ayika ti o rọrun:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Duro fun okun miiran lati tu titiipa silẹ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Tọju ka kariaye ti awọn okun laaye:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Iru boolean eyiti o le pin lailewu laarin awọn okun.
///
/// Iru yii ni aṣoju aṣoju ninu kanna bi [`bool`] kan.
///
/// **Akiyesi**: Iru yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn ẹru atomiki ati awọn ile itaja ti `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Ṣẹda `AtomicBool` ti ipilẹṣẹ si `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Firanṣẹ ti wa ni implicitly muse fun AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Iru ijuboluwo ele ti o le pin lailewu larin awon.
///
/// Yi iru ni o ni kanna ni-iranti oniduro bi a `*mut T`.
///
/// **Akiyesi**: Iru yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn ẹru atomiki ati awọn ile itaja ti awọn atọka.
/// Iwọn rẹ da lori iwọn ijuboluwo afojusun.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Ṣẹda a asan `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Awọn ibere iranti Atomiki
///
/// Awọn aṣẹ Memory ṣalaye ọna awọn iṣẹ atomiki ṣe imuṣiṣẹpọ iranti.
/// Ninu awọn oniwe-weakest [`Ordering::Relaxed`], nikan ni iranti taara ọwọ kan nipa awọn isẹ ti wa ni šišẹpọ.
/// Lori awọn miiran ọwọ, a itaja-fifuye bata ti [`Ordering::SeqCst`] mosi muu iranti miiran nigba ti afikun ohun toju a lapapọ ibere ti iru mosi kọja gbogbo awon.
///
///
/// Rust ká iranti orderings ni o wa [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Fun alaye diẹ sii wo [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ko si bere inira, nikan atomiki mosi.
    ///
    /// Awọn ibamu si [`memory_order_relaxed`] ni C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Nigba ti pelu pẹlu a itaja, gbogbo awọn ti tẹlẹ mosi di paṣẹ ṣaaju ki o to eyikeyi fifuye yi iye pẹlu [`Acquire`] (tabi okun) bere fun.
    ///
    /// Ni pato, gbogbo awọn ti tẹlẹ Levin di si han si gbogbo awọn awon ti o ṣe ohun [`Acquire`] (tabi okun) fifuye ti yi.
    ///
    /// Ṣe akiyesi pe lilo pipaṣẹ yii fun iṣẹ kan ti o dapọ awọn ẹrù ati awọn ile itaja n tọka si iṣẹ fifuye [`Relaxed`]!
    ///
    /// Bibere yii wulo nikan fun awọn iṣẹ ti o le ṣe ile itaja kan.
    ///
    /// Awọn ibamu si [`memory_order_release`] ni C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Nigbati a ba pọ pẹlu ẹrù kan, ti o ba kọ iye ti kojọpọ nipasẹ iṣẹ itaja pẹlu aṣẹ [`Release`] (tabi ti o lagbara sii), lẹhinna gbogbo awọn iṣẹ atẹle yoo di aṣẹ lẹhin ile itaja yẹn.
    /// Ni pataki, gbogbo awọn ẹru atẹle yoo rii data ti a kọ ṣaaju itaja.
    ///
    /// Akiyesi pe lilo yi bere fun ohun isẹ ti daapọ èyà ati oja nyorisi si a [`Relaxed`] itaja isẹ!
    ///
    /// Bibere yii wulo nikan fun awọn iṣẹ ti o le ṣe fifuye kan.
    ///
    /// Awọn ibamu si [`memory_order_acquire`] ni C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ni o ni awọn ipa ti awọn mejeeji [`Acquire`] ati [`Release`] pọ:
    /// Fun awọn ẹru o nlo bibere [`Acquire`].Fun awọn ile itaja o nlo aṣẹ [`Release`].
    ///
    /// Ṣe akiyesi pe ninu ọran ti `compare_and_swap`, o ṣee ṣe pe iṣẹ ṣiṣe dopin ko ṣe eyikeyi itaja ati nitorinaa o ni aṣẹ [`Acquire`] kan.
    ///
    /// Sibẹsibẹ, `AcqRel` kii yoo ṣe awọn iraye si [`Relaxed`].
    ///
    /// Bibere yii wulo nikan fun awọn iṣẹ ṣiṣe ti o ṣopọ awọn ẹru ati awọn ile itaja mejeeji.
    ///
    /// Awọn ibamu si [`memory_order_acq_rel`] ni C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Bi [`Acquire`]/[`Release`]/[`AcqRel`](fun fifuye, fipamọ, ati fifuye-with-itaja mosi, lẹsẹsẹ) pẹlu awọn afikun lopolopo pe gbogbo awon ri gbogbo sequentially dédé mosi ni kanna ibere .
    ///
    ///
    /// Awọn ibamu si [`memory_order_seq_cst`] ni C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// An [`AtomicBool`] ti ipilẹṣẹ si `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Ṣẹda `AtomicBool` tuntun kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Pada itọkasi iyipada si [`bool`] ipilẹ.
    ///
    /// Eyi jẹ ailewu nitori pe awọn onigbọwọ itọkasi iyipada le ṣe idaniloju pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // Aabo: awọn mutable itọkasi onigbọwọ oto nini.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Gba iraye si atomiki si `&mut bool` kan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // Aabo: itọkasi iyipada le ṣe onigbọwọ nini nini alailẹgbẹ, ati
        // titete ti `bool` ati `Self` jẹ 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Je atomiki ati mu iye to wa ninu pada.
    ///
    /// Eyi jẹ ailewu nitori fifin `self` nipasẹ awọn iṣeduro iye pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Fifuye iye kan lati bool.
    ///
    /// `load` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
    /// Awọn iye ti o le jẹ [`SeqCst`], [`Acquire`] ati [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti `order` ni [`Release`] tabi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // Aabo: eyikeyi awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki ati aise
        // ijuboluwole ti o kọja jẹ wulo nitori a gba lati itọkasi kan.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Ṣe tọju iye kan sinu bool.
    ///
    /// `store` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
    /// Awọn iye ti o le jẹ [`SeqCst`], [`Release`] ati [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ti `order` jẹ [`Acquire`] tabi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // Aabo: eyikeyi awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki ati aise
        // ijuboluwole ti o kọja jẹ wulo nitori a gba lati itọkasi kan.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Ṣe tọju iye kan sinu bool, n pada iye ti tẹlẹ pada.
    ///
    /// `swap` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Oja a iye sinu [`bool`] ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Awọn pada iye jẹ nigbagbogbo awọn ti tẹlẹ iye.Ti o ba dọgba si `current`, lẹhinna iye ti ni imudojuiwọn.
    ///
    /// `compare_and_swap` tun gba ariyanjiyan [`Ordering`] eyiti o ṣe apejuwe aṣẹ iranti ti išišẹ yii.
    /// Akiyesi wipe ani nigba lilo [`AcqRel`], ni isẹ le kuna ati ki o nibi kan ṣe ohun `Acquire` fifuye, sugbon ko ni `Release` oro ijora.
    /// Lilo [`Acquire`] jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`] ti o ba ṣẹlẹ, ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Iṣipo to `compare_exchange` ati `compare_exchange_weak`
    ///
    /// `compare_and_swap` jẹ deede si `compare_exchange` pẹlu aworan agbaye wọnyi fun awọn aṣẹ iranti:
    ///
    /// Akọbẹrẹ |aseyori |Ikuna
    /// -------- | ------- | -------
    /// Itura |ni ihuwasi |Ni ihuwasi gba |gba |Gba Tu |Tu |Itura AcqRel |AcqRel |Gba SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ti gba laaye lati kuna laiparu paapaa nigbati afiwe ba ṣaṣeyọri, eyiti o fun laaye akopọ lati ṣe agbekalẹ koodu apejọ to dara julọ nigbati a ba lo afiwe ati swap ninu lupu kan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Oja a iye sinu [`bool`] ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
    /// Lori aseyori yi ni ẹri lati wa ni dogba si `current`.
    ///
    /// `compare_exchange` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
    /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
    /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
    ///
    /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Oja a iye sinu [`bool`] ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Kii [`AtomicBool::compare_exchange`], a gba iṣẹ yii laaye lati kọlu ikuna paapaa nigbati afiwe ba ṣaṣeyọri, eyiti o le ja si koodu ti o munadoko diẹ ninu awọn iru ẹrọ kan.
    ///
    /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
    ///
    /// `compare_exchange_weak` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
    /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
    /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
    /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Mogbonwa "and" pẹlu kan Bolianu iye.
    ///
    /// Ṣe a mogbonwa "and" isẹ lori lọwọlọwọ iye ati awọn ariyanjiyan `val`, ati tosaaju titun iye si awọn esi.
    ///
    /// Pada iye ti tẹlẹ.
    ///
    /// `fetch_and` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Mogbonwa "nand" pẹlu kan Bolianu iye.
    ///
    /// Ṣe a mogbonwa "nand" isẹ lori lọwọlọwọ iye ati awọn ariyanjiyan `val`, ati tosaaju titun iye si awọn esi.
    ///
    /// Pada iye ti tẹlẹ.
    ///
    /// `fetch_nand` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // A ko le lo atomic_nand nibi nitori o le ja si ni bool pẹlu iye ti ko wulo.
        // Eleyi ṣẹlẹ nitori awọn atomiki isẹ ti wa ni ṣe pẹlu ohun 8-bit odidi fipa, eyi ti yoo ṣeto awọn oke 7 die-die.
        //
        // Nitorinaa a kan lo fetch_xor tabi swap dipo.
        if val {
            // ! (X&otitọ)== !x A gbọdọ invert awọn bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (X&eke)==otitọ A gbọdọ ṣeto awọn bool to otitọ.
            //
            self.swap(true, order)
        }
    }

    /// Aṣa "or" pẹlu iye boolean.
    ///
    /// Ṣe a mogbonwa "or" isẹ lori lọwọlọwọ iye ati awọn ariyanjiyan `val`, ati tosaaju titun iye si awọn esi.
    ///
    /// Pada iye ti tẹlẹ.
    ///
    /// `fetch_or` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Aṣa "xor" pẹlu iye boolean.
    ///
    /// Ṣe iṣẹ "xor" ti o ni oye lori iye lọwọlọwọ ati ariyanjiyan `val`, ati ṣeto iye tuntun si abajade.
    ///
    /// Pada iye ti tẹlẹ.
    ///
    /// `fetch_xor` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Pada ijuboluwole iyipada si [`bool`] ti o wa.
    ///
    /// Ṣiṣe awọn kika ti kii ṣe atomiki ati kikọ lori odidi odidi le jẹ ije data kan.
    /// Ọna yii wulo julọ fun FFI, nibiti ibuwọlu iṣẹ le lo `*mut bool` dipo `&AtomicBool`.
    ///
    /// Pada ohun `*mut` ijuboluwole lati kan pín tọka si yi atomiki jẹ ailewu nitori awọn atomiki orisi ṣiṣẹ pẹlu awọn inu ilohunsoke mutability.
    /// Gbogbo awọn iyipada ti atomiki kan yi iye pada nipasẹ itọkasi ti a pin, ati pe o le ṣe bẹ lailewu niwọn igba ti wọn ba lo awọn iṣẹ atomiki.
    /// Lilo eyikeyi ti ijuboluwo ihuwa ti a pada pada nilo idena `unsafe` ati pe o tun ni lati ṣe ihamọ ihamọ kanna: awọn iṣẹ lori rẹ gbọdọ jẹ atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Fetches awọn iye, ati ki o kan iṣẹ kan si o pe padà ohun iyan titun iye.Pada `Result` kan ti `Ok(previous_value)` ti iṣẹ naa ba pada `Some(_)`, `Err(previous_value)` miiran.
    ///
    /// Note: Eyi le pe iṣẹ ni awọn igba pupọ ti iye ba ti yipada lati awọn okun miiran ni asiko yii, niwọn igba ti iṣẹ naa ba pada `Some(_)`, ṣugbọn iṣẹ naa yoo ti lo ni ẹẹkan si iye ti o fipamọ.
    ///
    ///
    /// `fetch_update` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// Ni igba akọkọ ti o ṣalaye aṣẹ ti o nilo fun nigbati iṣẹ ṣiṣe ni aṣeyọri nikẹhin lakoko ti keji ṣe apejuwe aṣẹ ti o nilo fun awọn ẹru.
    /// Iwọnyi ṣe deede si aṣeyọri ati awọn aṣẹ ikuna ti [`AtomicBool::compare_exchange`] lẹsẹsẹ.
    ///
    /// Lilo [`Acquire`] bi titoṣẹ aṣeyọri jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe fifuye aṣeyọri ikẹhin [`Relaxed`].
    /// The (failed) fifuye bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa nikan lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Ṣẹda `AtomicPtr` tuntun kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Pada tọka iyipada kan si itọka atokọ.
    ///
    /// Eyi jẹ ailewu nitori pe awọn onigbọwọ itọkasi iyipada le ṣe idaniloju pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Gba atomiki wiwọle si a ijuboluwole.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - awọn mutable itọkasi onigbọwọ oto nini.
        //  - titete ti `*mut T` ati `Self` jẹ kanna lori gbogbo awọn iru ẹrọ ti o ni atilẹyin nipasẹ rust, bi a ti rii daju loke.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Je atomiki ati mu iye to wa ninu pada.
    ///
    /// Eyi jẹ ailewu nitori fifin `self` nipasẹ awọn iṣeduro iye pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Awọn ẹrù iye kan lati ijuboluwole.
    ///
    /// `load` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
    /// Awọn iye ti o le jẹ [`SeqCst`], [`Acquire`] ati [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti `order` ni [`Release`] tabi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Awọn ile itaja tọka si ijuboluwole kan.
    ///
    /// `store` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
    /// Awọn iye ti o le jẹ [`SeqCst`], [`Release`] ati [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ti `order` jẹ [`Acquire`] tabi [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Awọn ile itaja tọka si ijuboluwole kan, n da iye ti tẹlẹ pada.
    ///
    /// `swap` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
    /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    ///
    /// **Note:** Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori awọn itọka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Tọjú a iye sinu ijuboluwole ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Awọn pada iye jẹ nigbagbogbo awọn ti tẹlẹ iye.Ti o ba dọgba si `current`, lẹhinna iye ti ni imudojuiwọn.
    ///
    /// `compare_and_swap` tun gba ariyanjiyan [`Ordering`] eyiti o ṣe apejuwe aṣẹ iranti ti išišẹ yii.
    /// Akiyesi wipe ani nigba lilo [`AcqRel`], ni isẹ le kuna ati ki o nibi kan ṣe ohun `Acquire` fifuye, sugbon ko ni `Release` oro ijora.
    /// Lilo [`Acquire`] jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`] ti o ba ṣẹlẹ, ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
    ///
    /// **Note:** Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori awọn itọka.
    ///
    /// # Iṣipo to `compare_exchange` ati `compare_exchange_weak`
    ///
    /// `compare_and_swap` jẹ deede si `compare_exchange` pẹlu aworan agbaye wọnyi fun awọn aṣẹ iranti:
    ///
    /// Akọbẹrẹ |aseyori |Ikuna
    /// -------- | ------- | -------
    /// Itura |ni ihuwasi |Ni ihuwasi gba |gba |Gba Tu |Tu |Itura AcqRel |AcqRel |Gba SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ti gba laaye lati kuna laiparu paapaa nigbati afiwe ba ṣaṣeyọri, eyiti o fun laaye akopọ lati ṣe agbekalẹ koodu apejọ to dara julọ nigbati a ba lo afiwe ati swap ninu lupu kan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Tọjú a iye sinu ijuboluwole ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
    /// Lori aseyori yi ni ẹri lati wa ni dogba si `current`.
    ///
    /// `compare_exchange` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
    /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
    /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
    ///
    /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori awọn itọka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Tọjú a iye sinu ijuboluwole ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
    ///
    /// Ko [`AtomicPtr::compare_exchange`], iṣẹ yi ni laaye lati spuriously kuna paapa nigbati awọn lafiwe si yege, eyi ti o le ja si ni siwaju sii daradara koodu lori diẹ ninu awọn iru ẹrọ.
    ///
    /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
    ///
    /// `compare_exchange_weak` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
    /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
    /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
    /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori awọn itọka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // Aabo: Akọkọ-ọrọ yii jẹ ailewu nitori pe o ṣiṣẹ lori itọka aise kan
        // ṣugbọn a mọ daju pe ijuboluwole wulo (a kan gba lati `UnsafeCell` ti a ni nipa itọkasi) ati iṣẹ atomiki funrararẹ gba wa laaye lati paarọ awọn akoonu `UnsafeCell` lailewu.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Fetches awọn iye, ati ki o kan iṣẹ kan si o pe padà ohun iyan titun iye.Pada `Result` kan ti `Ok(previous_value)` ti iṣẹ naa ba pada `Some(_)`, `Err(previous_value)` miiran.
    ///
    /// Note: Eyi le pe iṣẹ ni awọn igba pupọ ti iye ba ti yipada lati awọn okun miiran ni asiko yii, niwọn igba ti iṣẹ naa ba pada `Some(_)`, ṣugbọn iṣẹ naa yoo ti lo ni ẹẹkan si iye ti o fipamọ.
    ///
    ///
    /// `fetch_update` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
    /// Ni igba akọkọ ti o ṣalaye aṣẹ ti o nilo fun nigbati iṣẹ ṣiṣe ni aṣeyọri nikẹhin lakoko ti keji ṣe apejuwe aṣẹ ti o nilo fun awọn ẹru.
    /// Awọn wọnyi ni dede si aseyori ati ikuna orderings ti [`AtomicPtr::compare_exchange`] lẹsẹsẹ.
    ///
    /// Lilo [`Acquire`] bi titoṣẹ aṣeyọri jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe fifuye aṣeyọri ikẹhin [`Relaxed`].
    /// The (failed) fifuye bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
    ///
    /// **Note:** Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori awọn itọka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Iyipada `bool` kan sinu `AtomicBool` kan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Makiro yii pari ni lilo ko lo lori diẹ ninu awọn ayaworan ile.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Iru odidi odidi eyiti o le pin lailewu laarin awọn okun.
        ///
        /// Iru yii ni aṣoju aṣoju ninu kanna bi iru nomba odidi ti o wa, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Fun diẹ sii nipa awọn iyatọ laarin awọn iru atomiki ati awọn iru atomiki ti kii ṣe atomiki gẹgẹbi alaye nipa gbigbe iru eyi, jọwọ wo [module-level documentation].
        ///
        ///
        /// **Note:** Iru yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn ẹru atomiki ati awọn ile itaja ti [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// An atomiki odidi initialized to `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Firanṣẹ ti wa ni imulẹ ni aito.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Ṣẹda titun kan atomiki odidi.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Pada a mutable tọka si amuye odidi.
            ///
            /// Eyi jẹ ailewu nitori pe awọn onigbọwọ itọkasi iyipada le ṣe idaniloju pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// jẹ ki mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (diẹ ninu_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - awọn mutable itọkasi onigbọwọ oto nini.
                //  - titete ti `$int_type` ati `Self` jẹ kanna, bi ileri nipasẹ $cfg_align ati ṣayẹwo ni oke.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Je atomiki ati mu iye to wa ninu pada.
            ///
            /// Eyi jẹ ailewu nitori fifin `self` nipasẹ awọn iṣeduro iye pe ko si awọn okun miiran ti n wọle ni igbakanna data atomiki.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Awọn ẹrù iye kan lati odidi atomiki.
            ///
            /// `load` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
            /// Awọn iye ti o le jẹ [`SeqCst`], [`Acquire`] ati [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ti o ba ti `order` ni [`Release`] tabi [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Ṣe tọju iye kan sinu odidi atomiki.
            ///
            /// `store` gba ariyanjiyan [`Ordering`] eyiti o ṣapejuwe aṣẹ iranti ti išišẹ yii.
            ///  Awọn iye ti o le jẹ [`SeqCst`], [`Release`] ati [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ti `order` jẹ [`Acquire`] tabi [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Ṣe tọju iye kan sinu odidi atomiki, n da iye ti tẹlẹ pada.
            ///
            /// `swap` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Tọjú a iye sinu atomiki odidi ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
            ///
            /// Awọn pada iye jẹ nigbagbogbo awọn ti tẹlẹ iye.Ti o ba dọgba si `current`, lẹhinna iye ti ni imudojuiwọn.
            ///
            /// `compare_and_swap` tun gba ariyanjiyan [`Ordering`] eyiti o ṣe apejuwe aṣẹ iranti ti išišẹ yii.
            /// Akiyesi wipe ani nigba lilo [`AcqRel`], ni isẹ le kuna ati ki o nibi kan ṣe ohun `Acquire` fifuye, sugbon ko ni `Release` oro ijora.
            ///
            /// Lilo [`Acquire`] jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`] ti o ba ṣẹlẹ, ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Iṣipo to `compare_exchange` ati `compare_exchange_weak`
            ///
            /// `compare_and_swap` jẹ deede si `compare_exchange` pẹlu aworan agbaye wọnyi fun awọn aṣẹ iranti:
            ///
            /// Akọbẹrẹ |aseyori |Ikuna
            /// -------- | ------- | -------
            /// Itura |ni ihuwasi |Ni ihuwasi gba |gba |Gba Tu |Tu |Itura AcqRel |AcqRel |Gba SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ti gba laaye lati kuna laiparu paapaa nigbati afiwe ba ṣaṣeyọri, eyiti o fun laaye akopọ lati ṣe agbekalẹ koodu apejọ to dara julọ nigbati a ba lo afiwe ati swap ninu lupu kan.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Tọjú a iye sinu atomiki odidi ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
            ///
            /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
            /// Lori aseyori yi ni ẹri lati wa ni dogba si `current`.
            ///
            /// `compare_exchange` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
            /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
            /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
            /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
            ///
            /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Tọjú a iye sinu atomiki odidi ti o ba ti isiyi iye jẹ kanna bi awọn `current` iye.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// iṣẹ yii ni a gba laaye lati spuriously kuna paapaa nigbati iṣeduro ba ṣaṣeyọri, eyiti o le ja si koodu ti o munadoko diẹ sii lori diẹ ninu awọn iru ẹrọ.
            /// Iye ipadabọ jẹ abajade ti o tọka boya a ti kọ iye tuntun ati ti o ni iye iṣaaju.
            ///
            /// `compare_exchange_weak` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
            /// `success` ṣe apejuwe aṣẹ ti a beere fun iṣẹ ṣiṣe kika-atunkọ-kikọ ti o waye ti iṣeduro pẹlu `current` ṣaṣeyọri.
            /// `failure` ṣe apejuwe aṣẹ ti a beere fun iṣẹ fifuye ti o waye nigbati afiwe ba kuna.
            /// Lilo [`Acquire`] bi aseyori bere mu ki awọn itaja apa kan yi isẹ [`Relaxed`], ati lilo [`Release`] mu ki awọn aseyori fifuye [`Relaxed`].
            ///
            /// Awọn ikuna bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// jẹ ki mut atijọ= val.load(Ordering::Relaxed);
            /// lupu {jẹ ki titun=atijọ * 2;
            ///     baramu val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
            ///
            /// Iṣiṣẹ yii yika ni ayika iṣanju.
            ///
            /// `fetch_add` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Awọn iyokuro lati iye lọwọlọwọ, n pada iye ti tẹlẹ.
            ///
            /// Iṣiṣẹ yii yika ni ayika iṣanju.
            ///
            /// `fetch_sub` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" pẹlu iye lọwọlọwọ.
            ///
            /// Ṣe iṣẹ "and" kekere kan lori iye lọwọlọwọ ati ariyanjiyan `val`, ati ṣeto iye tuntun si abajade.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_and` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" pẹlu iye lọwọlọwọ.
            ///
            /// Ṣe a bitwise "nand" isẹ lori lọwọlọwọ iye ati awọn ariyanjiyan `val`, ati tosaaju titun iye si awọn esi.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_nand` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" pẹlu awọn ti isiyi iye.
            ///
            /// Ṣe iṣẹ "or" kekere kan lori iye lọwọlọwọ ati ariyanjiyan `val`, ati ṣeto iye tuntun si abajade.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_or` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" pẹlu iye lọwọlọwọ.
            ///
            /// Ṣe a bitwise "xor" isẹ lori lọwọlọwọ iye ati awọn ariyanjiyan `val`, ati tosaaju titun iye si awọn esi.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_xor` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Fetches awọn iye, ati ki o kan iṣẹ kan si o pe padà ohun iyan titun iye.Pada `Result` kan ti `Ok(previous_value)` ti iṣẹ naa ba pada `Some(_)`, `Err(previous_value)` miiran.
            ///
            /// Note: Eyi le pe iṣẹ ni awọn igba pupọ ti iye ba ti yipada lati awọn okun miiran ni asiko yii, niwọn igba ti iṣẹ naa ba pada `Some(_)`, ṣugbọn iṣẹ naa yoo ti lo ni ẹẹkan si iye ti o fipamọ.
            ///
            ///
            /// `fetch_update` gba awọn ariyanjiyan [`Ordering`] meji lati ṣapejuwe bibere iranti iṣẹ yii.
            /// Ni igba akọkọ ti o ṣalaye aṣẹ ti o nilo fun nigbati iṣẹ ṣiṣe ni aṣeyọri nikẹhin lakoko ti keji ṣe apejuwe aṣẹ ti o nilo fun awọn ẹru.Iwọnyi ṣe deede si awọn aṣẹ aṣeyọri ati ikuna ti
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Lilo [`Acquire`] bi titoṣẹ aṣeyọri jẹ ki ile itaja jẹ apakan iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe fifuye aṣeyọri ikẹhin [`Relaxed`].
            /// The (failed) fifuye bere le nikan je [`SeqCst`], [`Acquire`] tabi [`Relaxed`] ati ki o gbọdọ jẹ deede si tabi alailagbara ju awọn aseyori bere fun.
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Bibere: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Bibere: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// O pọju pẹlu awọn ti isiyi iye.
            ///
            /// Wa o pọju ti iye lọwọlọwọ ati ariyanjiyan `val`, ati ṣeto iye tuntun si abajade.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_max` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// jẹ ki ọti=42;
            /// jẹ ki max_foo=foo.fetch_max (igi, Ordering::SeqCst).max(bar);
            /// assert! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Kere pẹlu iye lọwọlọwọ.
            ///
            /// Wa o kere ju ti iye lọwọlọwọ ati ariyanjiyan `val`, ati ṣeto iye tuntun si abajade.
            ///
            /// Pada iye ti tẹlẹ.
            ///
            /// `fetch_min` gba ohun [`Ordering`] ariyanjiyan ti o apejuwe awọn iranti bere fun ti yi isẹ.Gbogbo awọn ipo bibere ṣee ṣe.
            /// Akiyesi pe lilo [`Acquire`] ṣe apakan ile itaja ti iṣẹ yii [`Relaxed`], ati lilo [`Release`] ṣe apakan ẹrù [`Relaxed`].
            ///
            ///
            /// **Akiyesi**: Ọna yii wa lori awọn iru ẹrọ ti o ṣe atilẹyin awọn iṣẹ atomiki lori
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// jẹ ki igi=12;
            /// jẹ ki min_foo=foo.fetch_min (igi, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // Aabo: Awọn meya data ni idilọwọ nipasẹ awọn ipilẹ atomiki.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Pada ijuboluwole iyipada si odidi odidi.
            ///
            /// Ṣiṣe awọn kika ti kii ṣe atomiki ati kikọ lori odidi odidi le jẹ ije data kan.
            /// Ọna yii wulo julọ fun FFI, nibiti ibuwọlu iṣẹ le lo
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Pada ohun `*mut` ijuboluwole lati kan pín tọka si yi atomiki jẹ ailewu nitori awọn atomiki orisi ṣiṣẹ pẹlu awọn inu ilohunsoke mutability.
            /// Gbogbo awọn iyipada ti atomiki kan yi iye pada nipasẹ itọkasi ti a pin, ati pe o le ṣe bẹ lailewu niwọn igba ti wọn ba lo awọn iṣẹ atomiki.
            /// Lilo eyikeyi ti ijuboluwo ihuwa ti a pada pada nilo idena `unsafe` ati pe o tun ni lati ṣe ihamọ ihamọ kanna: awọn iṣẹ lori rẹ gbọdọ jẹ atomiki.
            ///
            ///
            /// # Examples
            ///
            /// `` `Foju (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ita "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // Aabo: Ailewu niwọn igba ti `my_atomic_op` jẹ atomiki.
            /// ailewu
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Pada awọn ti tẹlẹ iye (bi __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Pada iye ti tẹlẹ (bii __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// pada iye max (afiwe ti a fowo si)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// pada iye min (afiwe ti a fowo si)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// pada iye max (afiwe ti a ko fiwe si)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// pada iye min (afiwe ti a ko fiwe si)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // Aabo: awọn olupe gbọdọ opagun aabo guide fun `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ogiri atomu.
///
/// Ti o da lori aṣẹ ti a ṣalaye, odi kan ṣe idiwọ akopọ ati Sipiyu lati ṣe atunṣe awọn oriṣi awọn iṣẹ iṣiṣẹ iranti ni ayika rẹ.
/// Ti o ṣẹda ṣiṣẹpọdọkan-pẹlu ibasepo laarin o ati ki o atomiki mosi tabi awọn fences ni awọn awon.
///
/// A odi 'A' eyiti o ni (o kere ju) [`Release`] ti o bere fun awọn itumọ ọrọ, n muṣiṣẹpọ pẹlu odi 'B' pẹlu (o kere ju) awọn itumọ ọrọ [`Acquire`], ti o ba jẹ pe ti awọn iṣẹ X ati Y wa tẹlẹ, awọn mejeeji n ṣiṣẹ lori diẹ nkan atomiki 'M' bii pe A ti ṣe atẹle ṣaaju X, Y ti muuṣiṣẹpọ ṣaaju B ati Y ṣe akiyesi iyipada si M.
/// Eleyi pese a ṣẹlẹ-ṣaaju ki o to gbára laarin A o si B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomic mosi pẹlu [`Release`] tabi [`Acquire`] oro ijora tun le mušišẹpọ pẹlu a odi.
///
/// Odi kan ti o ni aṣẹ [`SeqCst`], ni afikun si nini awọn itumọ ọrọ [`Acquire`] ati [`Release`] mejeeji, ṣe alabapade ninu aṣẹ eto kariaye ti awọn iṣẹ [`SeqCst`] miiran ati/tabi awọn odi.
///
/// Gba awọn ibere [`Acquire`], [`Release`], [`AcqRel`] ati [`SeqCst`].
///
/// # Panics
///
/// Panics ti `order` jẹ [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Atijọ iyasoto iyasilẹ ti o da lori spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Duro titi di iye atijọ ni `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Odi yii n muṣiṣẹpọ-pẹlu itaja ni `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // Aabo: Lilo odi atomiki jẹ ailewu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// A odipo iranti odi.
///
/// `compiler_fence` ko ni emit eyikeyi ẹrọ koodu, ṣugbọn restricts awọn iru ti iranti re-ibere awọn alakojo ti wa ni laaye lati ṣe.Pataki, ti o da lori awọn ti fi fun [`Ordering`] oro ijora, awọn alakojo le wa ni disallowed lati gbigbe Say tabi Levin kuro niwaju tabi lẹhin ti awọn ipe si awọn miiran apa ti awọn ipe to `compiler_fence`.Akiyesi pe o ṣe **kii ṣe** ṣe idiwọ *hardware* lati ṣe iru atunṣe bẹ.
///
/// Eleyi jẹ ko kan isoro ni kan nikan-asapo, ipaniyan ti o tọ, sugbon nigba ti miiran awon le yipada iranti ni akoko kanna, ni okun amuṣiṣẹpọ primitives bi [`fence`] ti wa ni ti beere fun.
///
/// Tun-paṣẹ ti o ni idiwọ nipasẹ awọn itọsọ bibere oriṣiriṣi ni:
///
///  - pẹlu [`SeqCst`], ko si atunṣe-aṣẹ ti awọn kika ati kikọ kọja aaye yii ni a gba laaye.
///  - pẹlu [`Release`], awọn kika kika ati kikọ ko le ṣee gbe sẹyin atẹle awọn atẹle.
///  - pẹlu [`Acquire`], awọn kika atẹle ati kikọ ko le ṣee gbe siwaju awọn kika ti o ṣaju.
///  - pẹlu [`AcqRel`], awọn ofin mejeeji ti o wa loke ni a fi ipa mu.
///
/// `compiler_fence` jẹ gbogbogbo wulo nikan fun idilọwọ okun kan lati ije *pẹlu ara rẹ*.Iyẹn ni pe, ti okun ti a fun ba n ṣe nkan kan ti koodu, ati pe lẹhinna o ni idilọwọ, ti o bẹrẹ ṣiṣe koodu ni ibomiiran (lakoko ti o wa ni iru kanna, ati ni imọran tun wa ni ori kanna).Ni ibile eto, yi le nikan waye nigbati a ifihan agbara ohun imudani ti wa ni aami.
/// Ninu koodu ipele kekere diẹ sii, iru awọn ipo le tun dide nigbati o ba n mu awọn idilọwọ, nigbati o ba n ṣe awọn okun alawọ pẹlu imisi-tẹlẹ, ati bẹbẹ lọ.
/// A gba awọn onkawe iyanilenu niyanju lati ka ijiroro ekuro Linux ti [memory barriers].
///
/// # Panics
///
/// Panics ti `order` jẹ [`Relaxed`].
///
/// # Examples
///
/// Laisi `compiler_fence`, awọn `assert_eq!` ni wọnyi koodu ti wa ni *ko* ẹri lati se aseyori, pelu ohun gbogbo ṣẹlẹ ni kan nikan o tẹle.
/// Lati rii idi, ranti pe akopọ jẹ ominira lati paarọ awọn ile itaja si `IMPORTANT_VARIABLE` ati `IS_READ` nitori wọn jẹ `Ordering::Relaxed`.Ti o ba ṣe, ti o si pe oluṣowo ifihan ni kete lẹhin ti a ti mu imudojuiwọn `IS_READY`, lẹhinna oluṣakoso ifihan yoo rii `IS_READY=1`, ṣugbọn `IMPORTANT_VARIABLE=0`.
/// Lilo awọn atunṣe `compiler_fence` ipo yii.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ṣe idiwọ kikọ tẹlẹ lati gbe kọja aaye yii
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // Aabo: Lilo odi atomiki jẹ ailewu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Awọn ifihan agbara ti onise ẹrọ pe o wa ninu iṣu-alayipo iduro-duro ("titiipa iyipo").
///
/// Iṣẹ yii ti dinku ni ojurere ti [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}