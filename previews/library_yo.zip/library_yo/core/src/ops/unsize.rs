use crate::marker::Unsize;

/// Trait ti o tọka pe eyi ni ijuboluwole tabi apo-iwe fun ọkan, nibiti a le ṣe ṣiṣere lori ijuboluwole.
///
/// Wo [DST coercion RFC][dst-coerce] ati [the nomicon entry on coercion][nomicon-coerce] fun awọn alaye diẹ sii.
///
/// Fun awọn oriṣi ijuboluwole ti inu, awọn itọka si `T` yoo fi ipa mu si awọn itọka si `U` ti `T: Unsize<U>` ba jẹ nipa yiyipada lati inu itọka tẹẹrẹ si itọka ti o sanra.
///
/// Fun awọn iru aṣa, ifipabani nihin nibi n ṣiṣẹ nipa fifin `Foo<T>` si `Foo<U>` ti a pese impl ti `CoerceUnsized<Foo<U>> for Foo<T>` wa.
/// Iru ifilọlẹ bẹẹ ni a le kọ nikan ti `Foo<T>` ba ni aaye kan ti kii ṣe Phantomdata nikan ti o ni `T`.
/// Ti iru aaye yẹn ba jẹ `Bar<T>`, imuse ti `CoerceUnsized<Bar<U>> for Bar<T>` gbọdọ wa.
/// Ifipa mu yoo ṣiṣẹ nipasẹ fifin aaye `Bar<T>` sinu `Bar<U>` ati kikun awọn iyoku awọn aaye lati `Foo<T>` lati ṣẹda `Foo<U>`.
/// Eyi yoo lu lilu daradara si aaye ijuboluwole ati fi agbara mu iyẹn.
///
/// Ni gbogbogbo, fun awọn itọka ọlọgbọn iwọ yoo ṣe imuse `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, pẹlu aṣayan `?Sized` ti o so lori `T` funrararẹ.
/// Fun awọn iru aṣọ wiwọ ti o fi sii taara `T` bii `Cell<T>` ati `RefCell<T>`, o le ṣe taara `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Eyi yoo jẹ ki awọn ipa ti awọn iru bii `Cell<Box<T>>` ṣiṣẹ.
///
/// [`Unsize`][unsize] ti lo lati samisi awọn oriṣi eyiti o le fi agbara mu si awọn DST ti o ba wa lẹhin awọn itọka.O ti wa ni imuse ni adaṣe nipasẹ akopọ.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Eyi ni a lo fun aabo ohun, lati ṣayẹwo pe iru olugba ọna kan le firanṣẹ lori.
///
/// Apeere apẹẹrẹ ti trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}