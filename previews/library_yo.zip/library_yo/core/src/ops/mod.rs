//! Awọn oniṣẹ ti o le gbe lori.
//!
//! Ṣiṣe awọn traits wọnyi gba ọ laaye lati ṣe apọju awọn oniṣẹ kan.
//!
//! Diẹ ninu awọn traits wọnyi ni a gbe wọle nipasẹ prelude, nitorinaa wọn wa ni gbogbo eto Rust.Awọn oniṣẹ nikan ti o ni atilẹyin nipasẹ traits le jẹ apọju.
//! Fun apẹẹrẹ, oniṣe afikun (`+`) le ti wa ni fifuye nipasẹ [`Add`] trait, ṣugbọn nitori oniṣẹ iṣẹ iyansilẹ (`=`) ko ni atilẹyin trait, ko si ọna ti fifuye awọn itumọ ọrọ rẹ.
//! Ni afikun, module yii ko pese ilana eyikeyi lati ṣẹda awọn oniṣẹ tuntun.
//! Ti o ba nilo ikojọpọ tabi alaiṣẹ alaiṣẹ tabi awọn oniṣẹ aṣa, o yẹ ki o wo si awọn macros tabi awọn afikun akopọ lati faagun sintasi Rust.
//!
//! Awọn imuse ti oluṣe traits yẹ ki o jẹ iyanilẹnu ni awọn ipo wọn, ni iranti awọn itumọ wọn deede ati [operator precedence].
//! Fun apẹẹrẹ, nigbati o ba n ṣe imuse [`Mul`], iṣẹ naa yẹ ki o ni irufẹ si isodipupo (ati pin awọn ohun-ini ti a nireti bi isopọpọ).
//!
//! Akiyesi pe awọn oniṣẹ kukuru `&&` ati `||`, ie, wọn nikan ṣe ayẹwo operand keji wọn ti o ba ṣe alabapin si abajade naa.Niwọn igba ti ihuwasi yii ko ṣe mu lagabara nipasẹ traits, `&&` ati `||` ko ni atilẹyin bi awọn oniṣẹ ti o le gbe lori.
//!
//! Ọpọlọpọ awọn oniṣẹ n mu awọn operand wọn nipasẹ iye.Ninu awọn ipo ti kii ṣe jeniki ti o ni awọn oriṣi ti a ṣe sinu, eyi kii ṣe iṣoro nigbagbogbo.
//! Sibẹsibẹ, lilo awọn oniṣẹ wọnyi ni koodu jeneriki, nilo ifojusi diẹ ti o ba ni lati tun lo awọn iye ni ilodi si jẹ ki awọn oṣiṣẹ jẹ wọn.Aṣayan kan ni lati lẹẹkọọkan lo [`clone`].
//! Aṣayan miiran ni lati gbẹkẹle awọn oriṣi ti o wa pẹlu pipese awọn imuse awọn oniṣẹ fun awọn itọkasi.
//! Fun apẹẹrẹ, fun iru-olumulo ti a ṣalaye olumulo `T` eyiti o yẹ ki o ṣe atilẹyin afikun, o ṣee ṣe imọran ti o dara lati ni mejeeji `T` ati `&T` ṣe imuse traits [`Add<T>`][`Add`] ati [`Add<&T>`][`Add`] ki a le kọ koodu jeneriki laisi iṣelọpọ oniye.
//!
//!
//! # Examples
//!
//! Apẹẹrẹ yii ṣẹda ipilẹ `Point` ti o ṣe [`Add`] ati [`Sub`], ati lẹhinna ṣe afihan fifi kun ati iyokuro `Point`s meji.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Wo iwe fun trait kọọkan fun imuse apẹẹrẹ.
//!
//! The [`Fn`], [`FnMut`], ati [`FnOnce`] traits ti wa ni muse nipa orisi ti o le wa invoked bi iṣẹ.Akiyesi pe [`Fn`] gba `&self`, [`FnMut`] gba `&mut self` ati [`FnOnce`] gba `self`.
//! Iwọnyi ṣe deede si awọn ọna mẹta ti a le pe ni apeere kan: ipe-nipasẹ-itọkasi, itọkasi-nipasẹ-mutable-itọkasi, ati iye-ipe.
//! Lilo ti o wọpọ julọ ti traits wọnyi ni lati ṣe bi awọn aala si awọn iṣẹ ipele giga ti o mu awọn iṣẹ tabi awọn pipade bi awọn ariyanjiyan.
//!
//! Mu [`Fn`] kan bi paramita kan:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Mu [`FnMut`] kan bi paramita kan:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Mu [`FnOnce`] kan bi paramita kan:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` run awọn oniyipada ti o gba, nitorinaa ko le ṣe ṣiṣe ju ẹẹkan lọ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Igbidanwo lati pe `func()` lẹẹkansii yoo jabọ aṣiṣe `use of moved value` fun `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ko le tun pe ni aaye yii
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;