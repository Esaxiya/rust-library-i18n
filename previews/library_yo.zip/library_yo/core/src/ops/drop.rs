/// Koodu aṣa laarin apanirun.
///
/// Nigbati iye ko ba nilo mọ, Rust yoo ṣiṣẹ "destructor" kan lori iye yẹn.
/// Ọna ti o wọpọ julọ ti a ko nilo iye kan mọ ni nigbati o ba kọja ni aaye.Awọn apanirun le tun ṣiṣẹ ni awọn ayidayida miiran, ṣugbọn a yoo ni idojukọ lori aaye fun awọn apẹẹrẹ nibi.
/// Lati kọ ẹkọ nipa diẹ ninu awọn ọran miiran, jọwọ wo apakan [the reference] lori awọn apanirun.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Apanirun yii ni awọn paati meji:
/// - Ipe si `Drop::drop` fun iye yẹn, ti `Drop` trait pataki yii ba jẹ imuse fun iru rẹ.
/// - "drop glue" ti ipilẹṣẹ laifọwọyi eyiti o pe awọn apanirun ti gbogbo awọn aaye ti iye yii.
///
/// Bii Rust ṣe n pe awọn apanirun laifọwọyi ti gbogbo awọn aaye ti o wa ninu rẹ, o ko ni lati ṣe `Drop` ni ọpọlọpọ awọn ọran.
/// Ṣugbọn awọn ọran kan wa nibiti o ti wulo, fun apẹẹrẹ fun awọn iru eyiti o ṣakoso taara orisun kan taara.
/// Oro naa le jẹ iranti, o le jẹ apejuwe faili, o le jẹ iho netiwọki kan.
/// Ni kete ti iye ti iru yẹn ko ba ni lo mọ, o yẹ ki "clean up" orisun rẹ nipasẹ didasilẹ iranti tabi pipade faili tabi iho.
/// Eyi ni iṣẹ apanirun, ati nitorinaa iṣẹ ti `Drop::drop`.
///
/// ## Examples
///
/// Lati wo awọn iparun ni iṣe, jẹ ki a wo eto atẹle:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust yoo kọkọ pe `Drop::drop` fun `_x` ati lẹhinna fun `_x.one` ati `_x.two`, itumo pe ṣiṣe eyi yoo tẹ
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Paapa ti a ba yọ imuse ti `Drop` fun `HasTwoDrop`, awọn apanirun ti awọn aaye rẹ tun pe.
/// Eyi yoo ja si
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## O ko le pe `Drop::drop` funrararẹ
///
/// Nitori a lo `Drop::drop` lati sọ iye di mimọ, o le jẹ eewu lati lo iye yii lẹhin ti a ti pe ọna naa.
/// Bii `Drop::drop` ko gba nini ti titẹ sii rẹ, Rust ṣe idiwọ ilokulo nipa ko gba ọ laaye lati pe `Drop::drop` taara.
///
/// Ni awọn ọrọ miiran, ti o ba gbiyanju lati fi han gbangba pe `Drop::drop` ni apẹẹrẹ ti o wa loke, iwọ yoo ni aṣiṣe onkọwe kan.
///
/// Ti o ba fẹ ni kedere pe apanirun ti iye kan, [`mem::drop`] le ṣee lo dipo.
///
/// [`mem::drop`]: drop
///
/// ## Ṣiṣe silẹ
///
/// Ewo ninu `HasDrop` meji wa akọkọ, botilẹjẹpe?Fun awọn ofin, o jẹ aṣẹ kanna ti wọn kede: akọkọ `one`, lẹhinna `two`.
/// Ti o ba fẹ gbiyanju eyi funrararẹ, o le yipada `HasDrop` loke lati ni diẹ ninu data ninu, bii odidi odidi kan, lẹhinna lo ni `println!` inu `Drop`.
/// Ihuwasi yii jẹ ẹri nipasẹ ede.
///
/// Ko dabi fun awọn idiwọn, awọn oniyipada agbegbe ti lọ silẹ ni aṣẹ yiyipada:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Eyi yoo tẹjade
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Jọwọ wo [the reference] fun awọn ofin ni kikun.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ati `Drop` jẹ iyasoto
///
/// O ko le ṣe awọn [`Copy`] ati `Drop` mejeeji lori iru kanna.Awọn oriṣi ti o jẹ `Copy` ṣe adaṣe lọna pipe nipasẹ akopọ, ṣiṣe ni o nira pupọ lati ṣe asọtẹlẹ nigbawo, ati bii igbagbogbo yoo pa awọn apanirun.
///
/// Bii iru eyi, awọn oriṣi wọnyi ko le ni awọn apanirun.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ṣiṣẹ apanirun fun iru yii.
    ///
    /// Ọna yii ni a pe ni aiṣedede nigbati iye ba jade ni agbegbe, ati pe a ko le pe ni gbangba (eyi ni aṣiṣe alakojo [E0040]).
    /// Sibẹsibẹ, iṣẹ [`mem::drop`] ni prelude le ṣee lo lati pe ariyanjiyan ti imuse `Drop`.
    ///
    /// Nigbati a ba pe ọna yii, `self` ko iti pin ni ipin.
    /// Iyẹn nikan ṣẹlẹ lẹhin ọna ti pari.
    /// Ti eyi ko ba jẹ ọran naa, `self` yoo jẹ itọkasi itọkasi.
    ///
    /// # Panics
    ///
    /// Fun ni pe [`panic!`] kan yoo pe `drop` bi o ṣe n ṣii, eyikeyi [`panic!`] ninu imuse `drop` yoo ṣee ṣe oyun.
    ///
    /// Akiyesi pe paapaa ti panics yii, a ka iye naa lati ju silẹ;
    /// o ko gbodo fa ki a pe `drop` lẹẹkansii.
    /// Eyi ni deede ṣakoso nipasẹ adapọ, ṣugbọn nigba lilo koodu ti ko ni aabo, o le waye nigbakan lairotẹlẹ, ni pataki nigba lilo [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}