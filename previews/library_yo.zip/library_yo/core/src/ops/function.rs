/// Ẹya ti oniṣẹ ipe ti o gba olugba ti ko le yipada.
///
/// A le pe Awọn apẹẹrẹ ti `Fn` leralera laisi ipo iyipada.
///
/// *trait (`Fn`) yii kii ṣe lati dapo pẹlu [function pointers] (`fn`).*
///
/// `Fn` ti wa ni imuse ni adaṣe nipasẹ awọn pipade eyi ti o gba awọn itọkasi ailopin si awọn oniyipada ti o gba tabi ko mu ohunkohun rara, bii (safe) [function pointers] (pẹlu diẹ ninu awọn itaniji, wo iwe wọn fun awọn alaye diẹ sii).
///
/// Ni afikun, fun eyikeyi iru `F` ti o ṣe `Fn`, `&F` ṣe awọn `Fn`, paapaa.
///
/// Niwọn igba ti [`FnMut`] ati [`FnOnce`] jẹ awọn supertraits ti `Fn`, eyikeyi apeere ti `Fn` le ṣee lo bi paramita kan nibiti o ti nireti [`FnMut`] tabi [`FnOnce`].
///
/// Lo `Fn` gege bi adehun nigbati o ba fẹ gba paramita ti iru iṣẹ bii o nilo lati pe ni igbakan ati laisi ipo iyipada (fun apẹẹrẹ, nigbati o ba n pe nigbakanna).
/// Ti o ko ba nilo iru awọn ibeere to muna, lo [`FnMut`] tabi [`FnOnce`] bi awọn aala.
///
/// Wo [chapter on closures in *The Rust Programming Language*][book] fun alaye diẹ sii lori koko yii.
///
/// Paapaa ti akọsilẹ ni sintasi pataki fun `Fn` traits (fun apẹẹrẹ
/// `Fn(usize, bool) -> losi)).Awọn ti o nifẹ si awọn alaye imọ-ẹrọ ti eyi le tọka si [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Pipe bíbo
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Lilo a paramita `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ki regex le gbẹkẹle `&str: !FnMut` naa
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Ṣe iṣẹ ipe.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Ẹya ti oniṣẹ ipe ti o gba olugba iyipada.
///
/// A le pe Awọn apẹẹrẹ ti `FnMut` leralera o le yipada si ipo.
///
/// `FnMut` ti wa ni imuse ni adaṣe nipasẹ awọn pipade eyiti o mu awọn itọka iyipada si awọn oniyipada ti o gba, bii gbogbo awọn oriṣi ti o ṣe [`Fn`], fun apẹẹrẹ, (safe) [function pointers] (nitori `FnMut` jẹ supertrait ti [`Fn`]).
/// Ni afikun, fun eyikeyi iru `F` ti o ṣe `FnMut`, `&mut F` ṣe awọn `FnMut`, paapaa.
///
/// Niwọn igba ti [`FnOnce`] jẹ supertrait ti `FnMut`, eyikeyi apeere ti `FnMut` le ṣee lo nibiti o ti nireti [`FnOnce`], ati pe [`Fn`] jẹ iyokuro ti `FnMut`, eyikeyi apẹẹrẹ ti [`Fn`] le ṣee lo nibiti o ti nireti `FnMut`
///
/// Lo `FnMut` gege bi adehun nigbati o ba fẹ gba iwọn ti iru iṣẹ ati pe o nilo lati pe leralera, lakoko gbigba laaye lati yi ipo pada.
/// Ti o ko ba fẹ awọn paramita to mutate ipinle, lo [`Fn`] bi a férémù;ti o ko ba nilo lati pe ni igbagbogbo, lo [`FnOnce`].
///
/// Wo [chapter on closures in *The Rust Programming Language*][book] fun alaye diẹ sii lori koko yii.
///
/// Paapaa ti akọsilẹ ni sintasi pataki fun `Fn` traits (fun apẹẹrẹ
/// `Fn(usize, bool) -> losi)).Awọn ti o nifẹ si awọn alaye imọ-ẹrọ ti eyi le tọka si [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Pipe pipade mimu mutably
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Lilo a paramita `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ki regex le gbẹkẹle `&str: !FnMut` naa
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Ṣe iṣẹ ipe.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Ẹya ti oniṣẹ ipe ti o gba olugba iye-iye kan.
///
/// Awọn apeere ti `FnOnce` ni a le pe, ṣugbọn o le ma jẹ le ṣee ṣa ni igba pupọ.Nitori eyi, ti o ba jẹ pe ohun kan ṣoṣo ti a mọ nipa iru kan ni pe o ṣe awọn `FnOnce`, o le pe ni ẹẹkan.
///
/// `FnOnce` ti wa ni imuse ni adaṣe nipasẹ awọn pipade ti o le jẹ awọn oniyipada ti o gba, bii gbogbo awọn oriṣi ti o ṣe [`FnMut`], fun apẹẹrẹ, (safe) [function pointers] (nitori `FnOnce` jẹ supertrait ti [`FnMut`]).
///
///
/// Niwọn igba ti [`Fn`] ati [`FnMut`] jẹ iyokuro ti `FnOnce`, eyikeyi apeere ti [`Fn`] tabi [`FnMut`] le ṣee lo nibiti o ti nireti `FnOnce` kan.
///
/// Lo `FnOnce` gege bi adehun nigbati o ba fẹ gba paramita kan ti iru iṣẹ bii o nilo lati pe ni ẹẹkan.
/// Ti o ba nilo lati pe paramita leralera, lo [`FnMut`] bi adehun;ti o ba tun nilo rẹ lati ma ṣe yi ipo pada, lo [`Fn`].
///
/// Wo [chapter on closures in *The Rust Programming Language*][book] fun alaye diẹ sii lori koko yii.
///
/// Paapaa ti akọsilẹ ni sintasi pataki fun `Fn` traits (fun apẹẹrẹ
/// `Fn(usize, bool) -> losi)).Awọn ti o nifẹ si awọn alaye imọ-ẹrọ ti eyi le tọka si [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Lilo a paramita `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` run awọn oniyipada ti o gba, nitorinaa ko le ṣe ṣiṣe ju ẹẹkan lọ.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Igbidanwo lati pe `func()` lẹẹkansii yoo jabọ aṣiṣe `use of moved value` fun `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ko le tun pe ni aaye yii
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ki regex le gbẹkẹle `&str: !FnMut` naa
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Iru ti o pada lẹhin ti a ti lo olupe ipe.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Ṣe iṣẹ ipe.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}