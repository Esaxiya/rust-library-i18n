/// Ti a lo fun awọn iṣẹ imukuro ailopin, bii `*v`.
///
/// Ni afikun si lilo fun awọn iṣẹ ifagile fifin pẹlu oniṣẹ (unary) `*` ni awọn ipo ti ko le yipada, `Deref` tun lo ni aiṣe-taara nipasẹ akopọ ni ọpọlọpọ awọn ayidayida.
/// Ilana yii ni a pe ni ['`Deref` coercion'][more].
/// Ninu awọn ipo ti o le yipada, [`DerefMut`] ti lo.
///
/// Ṣiṣe `Deref` fun awọn itọka ọlọgbọn jẹ ki iraye si data lẹhin wọn rọrun, eyiti o jẹ idi ti wọn fi ṣe `Deref`.
/// Ni apa keji, awọn ofin nipa `Deref` ati [`DerefMut`] ti ṣe apẹrẹ ni pataki lati gba awọn atọka ọlọgbọn.
/// Nitori eyi,**`Deref` yẹ ki o ṣe imuse nikan fun awọn itọka ọlọgbọn** lati yago fun iporuru.
///
/// Fun awọn idi kanna,**trait yii ko yẹ ki o kuna**.Ikuna lakoko ifasilẹ iwe le jẹ airoju pupọ nigbati `Deref` ba pe ni pipe.
///
/// # Siwaju sii lori ifiagbara `Deref`
///
/// Ti `T` ba ṣe `Deref<Target = U>`, ati pe `x` jẹ iye ti iru `T`, lẹhinna:
///
/// * Ninu awọn ipo ti ko le yipada, `*x` (nibiti `T` kii ṣe itọkasi tabi ijuboluwo aise) jẹ deede si `* Deref::deref(&x)`.
/// * Awọn idiyele ti iru `&T` ni a fi agbara mu si awọn iye ti iru `&U`
/// * `T` laibikita n ṣe gbogbo awọn ọna (immutable) ti iru `U`.
///
/// Fun awọn alaye diẹ sii, ṣabẹwo si [the chapter in *The Rust Programming Language*][book] ati awọn abala itọkasi lori [the dereference operator][ref-deref-op], [method resolution] ati [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ṣiṣeto pẹlu aaye kan ṣoṣo eyiti o jẹ iraye si nipasẹ gbigbasilẹ eto naa.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Iru abajade lẹhin igbasilẹ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferences iye.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Ti a lo fun awọn iṣẹ ifagile mutable, bii `*v = 1;`.
///
/// Ni afikun si lilo fun awọn iṣẹ ifagilee fifin pẹlu oniṣẹ (unary) `*` ni awọn ipo iyipada, `DerefMut` tun lo lọna pipe nipasẹ akopọ ni ọpọlọpọ awọn ayidayida.
/// Ilana yii ni a pe ni ['`Deref` coercion'][more].
/// Ninu awọn ipo ti ko le yipada, a ti lo [`Deref`].
///
/// Ṣiṣe `DerefMut` fun awọn itọka ọlọgbọn mu ki iyipada data lẹhin wọn rọrun, eyiti o jẹ idi ti wọn fi ṣe `DerefMut`.
/// Ni apa keji, awọn ofin nipa [`Deref`] ati `DerefMut` ti ṣe apẹrẹ ni pataki lati gba awọn atọka ọlọgbọn.
/// Nitori eyi,**`DerefMut` yẹ ki o ṣe imuse nikan fun awọn itọka ọlọgbọn** lati yago fun iporuru.
///
/// Fun awọn idi kanna,**trait yii ko yẹ ki o kuna**.Ikuna lakoko ifasilẹ iwe le jẹ airoju pupọ nigbati `DerefMut` ba pe ni pipe.
///
/// # Siwaju sii lori ifiagbara `Deref`
///
/// Ti `T` ba ṣe `DerefMut<Target = U>`, ati pe `x` jẹ iye ti iru `T`, lẹhinna:
///
/// * Ninu awọn ọrọ ti o le yipada, `*x` (nibiti `T` kii ṣe itọkasi tabi ijuboluwo aise) jẹ deede si `* DerefMut::deref_mut(&mut x)`.
/// * Awọn idiyele ti iru `&mut T` ni a fi agbara mu si awọn iye ti iru `&mut U`
/// * `T` laibikita n ṣe gbogbo awọn ọna (mutable) ti iru `U`.
///
/// Fun awọn alaye diẹ sii, ṣabẹwo si [the chapter in *The Rust Programming Language*][book] ati awọn abala itọkasi lori [the dereference operator][ref-deref-op], [method resolution] ati [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Ṣiṣeto kan pẹlu aaye kan ṣoṣo eyiti o jẹ iyipada nipasẹ gbigbasilẹ eto naa.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ni idasi awọn iforukọsilẹ iye naa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// O tọka pe a le lo ọna kan bi olugba ọna, laisi ẹya `arbitrary_self_types`.
///
/// Eyi ni a ṣe nipasẹ awọn iru ijuboluwole stdlib bii `Box<T>`, `Rc<T>`, `&T`, ati `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}