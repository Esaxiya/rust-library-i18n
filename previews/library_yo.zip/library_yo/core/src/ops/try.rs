/// A trait fun sisọ ihuwasi ti oniṣẹ `?`.
///
/// Iru iru imuṣe `Try` jẹ ọkan ti o ni ọna aṣẹ-aṣẹ lati wo o ni awọn ofin ti dichotomy success/failure kan.
/// trait yii ngbanilaaye yiyọ awọn aṣeyọri wọnyẹn tabi awọn iye ikuna wọnyẹn lati apẹẹrẹ ti o wa tẹlẹ ati ṣiṣẹda apeere tuntun lati aṣeyọri tabi iye ikuna.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Iru iye yii nigba ti a wo bi aṣeyọri.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Iru iye yii nigbati a wo bi o ti kuna.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Waye oluṣe "?".Pada ti `Ok(t)` tumọ si pe ipaniyan yẹ ki o tẹsiwaju deede, ati abajade ti `?` ni iye `t`.
    /// Ipadabọ ti `Err(e)` tumọ si pe ipaniyan yẹ ki branch si `catch` ti n pa mọ inu, tabi pada lati iṣẹ naa.
    ///
    /// Ti a ba da abajade `Err(e)` pada, iye `e` yoo jẹ "wrapped" ni iru ipadabọ ti ibiti o ti n ṣafikun (eyiti o gbọdọ funrararẹ ṣe `Try`).
    ///
    /// Ni pataki, a ti da iye `X::from_error(From::from(e))` pada, nibiti `X` jẹ iru ipadabọ ti iṣẹ iwọle.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Fi ipari iye aṣiṣe kan lati kọ abajade akopọ.
    /// Fun apẹẹrẹ, `Result::Err(x)` ati `Result::from_error(x)` jẹ deede.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Fi ipari iye DARA lati kọ abajade idapọ.
    /// Fun apẹẹrẹ, `Result::Ok(x)` ati `Result::from_ok(x)` jẹ deede.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}