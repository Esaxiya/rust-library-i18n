#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Fẹ si boya `$crate::panic::panic_2015` tabi `$crate::panic::panic_2021` o da lori awọn àtúnse ti awọn olupe ti.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Asserts wipe meji expressions wa ni dogba si kọọkan miiran (lilo [`PartialEq`]).
///
/// On panic, yi Makiro yoo tẹ sita awọn iye ti awọn expressions pẹlu wọn yokokoro atungbejade.
///
///
/// Bi [`assert!`], yi Makiro ni o ni a keji fọọmu, ibi ti a aṣa panic ifiranṣẹ le ti wa ni pese.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Awọn reborrows ni isalẹ wa ni intentional.
                    // Lai wọn, awọn akopọ Iho fun awọn wín, ti wa ni initialized koda ki o to awọn iye ti wa ni akawe, yori si a ti ṣe akiyesi o lọra si isalẹ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Awọn reborrows ni isalẹ wa ni intentional.
                    // Lai wọn, awọn akopọ Iho fun awọn wín, ti wa ni initialized koda ki o to awọn iye ti wa ni akawe, yori si a ti ṣe akiyesi o lọra si isalẹ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Asserts wipe meji expressions o wa ko dogba si kọọkan miiran (lilo [`PartialEq`]).
///
/// On panic, yi Makiro yoo tẹ sita awọn iye ti awọn expressions pẹlu wọn yokokoro atungbejade.
///
///
/// Bi [`assert!`], yi Makiro ni o ni a keji fọọmu, ibi ti a aṣa panic ifiranṣẹ le ti wa ni pese.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Awọn reborrows ni isalẹ wa ni intentional.
                    // Lai wọn, awọn akopọ Iho fun awọn wín, ti wa ni initialized koda ki o to awọn iye ti wa ni akawe, yori si a ti ṣe akiyesi o lọra si isalẹ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Awọn reborrows ni isalẹ wa ni intentional.
                    // Lai wọn, awọn akopọ Iho fun awọn wín, ti wa ni initialized koda ki o to awọn iye ti wa ni akawe, yori si a ti ṣe akiyesi o lọra si isalẹ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Ṣe idaniloju pe ikosile boole jẹ `true` ni asiko asiko.
///
/// Eleyi yoo ikepè [`panic!`] Makiro ti o ba ti pese ikosile ko le wa ni akojopo to `true` ni asiko isise.
///
/// Bi [`assert!`], yi Makiro tun ni o ni a keji ti ikede, ni ibi ti a aṣa panic ifiranṣẹ le ti wa ni pese.
///
/// # Uses
///
/// Kii [`assert!`], awọn alaye `debug_assert!` nikan ni a ṣiṣẹ ni awọn ile ti ko ni iṣapeye nipasẹ aiyipada.
/// An ise Kọ yoo ko ṣiṣẹ `debug_assert!` gbólóhùn ayafi ti `-C debug-assertions` wa ni koja si awọn alakojo.
/// Eleyi mu ki `debug_assert!` wulo fun awọn sọwedowo ti o wa ni ju gbowolori lati wa ni bayi ni a Tu Kọ ṣugbọn o le jẹ wulo nigba idagbasoke.
/// Awọn esi ti jù `debug_assert!` ti wa ni nigbagbogbo tẹ ẹnikeji.
///
/// An a sisoô itenumo faye gba a eto ni ohun aisedede ipinle lati pa yen, eyi ti o le ni airotẹlẹ gaju ṣugbọn ko ni agbekale unsafety bi gun bi yi nikan ṣẹlẹ ni ailewu koodu.
///
/// Iye owo iṣẹ ti awọn idaniloju, sibẹsibẹ, kii ṣe iwọn ni apapọ.
/// Rirọpo [`assert!`] pẹlu `debug_assert!` wa ni bayi nikan ni iwuri lẹhin nipasẹ aworan, ati diẹ ṣe pataki, nikan ni ailewu koodu!
///
/// # Examples
///
/// ```
/// // awọn panic ifiranṣẹ fun awọn wọnyi assertions ni awọn stringified iye ti awọn ikosile fun.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // a irorun iṣẹ
/// debug_assert!(some_expensive_computation());
///
/// // sọ pẹlu kan aṣa ifiranṣẹ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Asserts wipe meji expressions wa ni dogba si kọọkan miiran.
///
/// On panic, yi Makiro yoo tẹ sita awọn iye ti awọn expressions pẹlu wọn yokokoro atungbejade.
///
/// Ko [`assert_eq!`], `debug_assert_eq!` gbólóhùn ti wa ni nikan sise ni ti kii iṣapeye duro nipa aiyipada.
/// An ise Kọ yoo ko ṣiṣẹ `debug_assert_eq!` gbólóhùn ayafi ti `-C debug-assertions` wa ni koja si awọn alakojo.
/// Eleyi mu ki `debug_assert_eq!` wulo fun awọn sọwedowo ti o wa ni ju gbowolori lati wa ni bayi ni a Tu Kọ ṣugbọn o le jẹ wulo nigba idagbasoke.
///
/// Awọn esi ti jù `debug_assert_eq!` ti wa ni nigbagbogbo tẹ ẹnikeji.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ṣe idaniloju pe awọn ifihan meji ko dọgba si ara wọn.
///
/// On panic, yi Makiro yoo tẹ sita awọn iye ti awọn expressions pẹlu wọn yokokoro atungbejade.
///
/// Ko [`assert_ne!`], `debug_assert_ne!` gbólóhùn ti wa ni nikan sise ni ti kii iṣapeye duro nipa aiyipada.
/// An ise Kọ yoo ko ṣiṣẹ `debug_assert_ne!` gbólóhùn ayafi ti `-C debug-assertions` wa ni koja si awọn alakojo.
/// Eleyi mu ki `debug_assert_ne!` wulo fun awọn sọwedowo ti o wa ni ju gbowolori lati wa ni bayi ni a Tu Kọ ṣugbọn o le jẹ wulo nigba idagbasoke.
///
/// Awọn esi ti jù `debug_assert_ne!` ti wa ni nigbagbogbo tẹ ẹnikeji.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Padà boya awọn fun ikosile ibaamu eyikeyi ninu awọn fun elo.
///
/// Bi ni a `match` ikosile, awọn Àpẹẹrẹ le ti wa ni optionally atẹle nipa `if` ati ki o kan ẹṣọ ikosile ti o ni wiwọle si awọn orukọ alaa nipa awọn Àpẹẹrẹ.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps a abajade tabi propagates awọn oniwe-ašiše.
///
/// The `?` onišẹ ti a fi kun lati ropo `try!` ati ki o yẹ ki o wa lo dipo.
/// Pẹlupẹlu, `try` ni a wa ni ipamọ ọrọ ni Rust 2018, ki o ba ti o gbọdọ lo o, o yoo nilo lati lo awọn [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ibaamu awọn ti fi fun [`Result`].Ni irú ti awọn `Ok` iyatọ, awọn ikosile ni o ni iye ti awọn we iye.
///
/// Ni ọran ti iyatọ `Err`, o gba aṣiṣe inu.`try!` ki o si performs iyipada nipa lilo `From`.
/// Eleyi pese laifọwọyi iyipada laarin specialized aṣiṣe ati diẹ gbogboogbo eyi.
/// Aṣiṣe ti o wa ni lẹhinna pada lẹsẹkẹsẹ.
///
/// Nitori ipadabọ kutukutu, `try!` le ṣee lo ni awọn iṣẹ ti o pada [`Result`] pada.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Ọna ti o fẹ julọ ti Awọn aṣiṣe ti n pada kiakia
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Ọna iṣaaju ti Awọn aṣiṣe ti n pada kiakia
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Eleyi jẹ deede si:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Kọ data kika sinu ibi ipamọ.
///
/// Eleyi Makiro gba a 'writer', a kika okun, ati akojọ kan ti ariyanjiyan.
/// Ariyanjiyan yoo wa ni akoonu ni ibamu si awọn pàtó kan kika okun ati awọn esi ti yoo wa ni koja si awọn onkqwe.
/// Onkọwe le jẹ iye eyikeyi pẹlu ọna `write_fmt`;gbogbo yi wa lati ẹya imuse ti boya awọn [`fmt::Write`] tabi awọn [`io::Write`] trait.
/// Awọn Makiro padà ohunkohun ti `write_fmt` ọna padà;commonly a [`fmt::Result`], tabi awọn ẹya [`io::Result`].
///
/// Wo [`std::fmt`] fun alaye siwaju sii lori awọn kika okun sintasi.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// A module le gbe awọn mejeeji `std::fmt::Write` ati `std::io::Write` ati ipe `write!` on ohun imulo boya, bi ohun ko ojo melo se mejeeji.
///
/// Sibẹsibẹ, awọn module gbọdọ gbe awọn traits tóótun ki orukọ wọn se ko rogbodiyan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // nlo fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // nlo io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Yi Makiro le ṣee lo ni `no_std` setups bi daradara.
/// Ninu iṣeto `no_std` o ni iduro fun awọn alaye imuse ti awọn paati.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Kọ akoonu data sinu kan saarin, pẹlu kan newline appended.
///
/// Lori gbogbo awọn iru ẹrọ, awọn newline ni awọn LINE FEED ti ohun kikọ silẹ (`\n`/`U+000A`) nikan (ko si afikun gbigbe PADA (`\r`/`U+000D`).
///
/// Fun alaye diẹ, wo [`write!`].Fun alaye lori sintasi okun kika, wo [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// A module le gbe awọn mejeeji `std::fmt::Write` ati `std::io::Write` ati ipe `write!` on ohun imulo boya, bi ohun ko ojo melo se mejeeji.
/// Sibẹsibẹ, awọn module gbọdọ gbe awọn traits tóótun ki orukọ wọn se ko rogbodiyan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // nlo fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // nlo io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Tọkasi ọdọ rẹ koodu.
///
/// Eleyi jẹ wulo eyikeyi akoko ti awọn alakojo ko le mọ pe diẹ ninu awọn koodu ti wa ni ọdọ rẹ.Fun apere:
///
/// * Awọn apá ti o baamu pẹlu awọn ipo aabo.
/// * Losiwajulosehin ti o gbalaye fopin si.
/// * Iterators ti o gbalaye fopin si.
///
/// Ti ipinnu ti koodu naa ko ba de ọdọ rẹ jẹ aṣiṣe, eto naa pari lẹsẹkẹsẹ pẹlu [`panic!`] kan.
///
/// Awọn lewu counterpart ti yi Makiro ni awọn [`unreachable_unchecked`] iṣẹ, eyi ti yoo fa aisọye ihuwasi ti o ba ti awọn koodu ti wa ni ami.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Eleyi ife nigbagbogbo [`panic!`].
///
/// # Examples
///
/// Awọn apa baramu:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // sakojo aṣiṣe ti o ba ti commented jade
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ọkan ninu awọn talika awọn imuṣẹ ti x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Tọkasi unimplemented koodu nipa panicking pẹlu ifiranṣẹ kan ti "not implemented".
///
/// Eleyi gba koodu rẹ to iru-ayẹwo, ti o jẹ wulo ti o ba ti wa ni prototyping tabi imulo awon kan trait ti o nbeere ọpọ awọn ọna eyi ti o se ko ètò ti lilo gbogbo awọn ti.
///
/// Iyatọ laarin `unimplemented!` ati [`todo!`] ni pe lakoko ti `todo!` n ṣalaye aniyan ti imuse iṣẹ-ṣiṣe nigbamii ati ifiranṣẹ naa jẹ "not yet implemented", `unimplemented!` ko ṣe iru awọn ẹtọ bẹ.
/// Awọn oniwe-ifiranṣẹ ti wa ni "not implemented".
/// Paapaa diẹ ninu awọn IDE yoo samisi `todo!` S.
///
/// # Panics
///
/// Eleyi ife nigbagbogbo [`panic!`] nitori `unimplemented!` jẹ o kan kan shorthand fun `panic!` pẹlu kan ti o wa titi, ifiranṣẹ kan.
///
/// Bii `panic!`, macro yii ni fọọmu keji fun iṣafihan awọn iye aṣa.
///
/// # Examples
///
/// Sọ pe a ni trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// A fẹ lati se `Foo` fun 'MyStruct', ṣugbọn fun diẹ ninu awọn idi ti o nikan ki asopọ ori lati se awọn `bar()` iṣẹ.
/// `baz()` ati `qux()` yoo si tun nilo lati wa ni telẹ ninu wa imuse ti `Foo`, sugbon a le lo `unimplemented!` ni won itumo lati gba wa koodu lati sakojo.
///
/// A si tun fẹ lati ni wa eto Duro yen ti o ba ti unimplemented ọna ti wa ni ami.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // O mu ki ko si ori lati `baz` a `MyStruct`, ki a ni ko si kannaa nibi ni gbogbo.
/////
///         // Eleyi yoo han "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // A ni diẹ ninu kannaa nibi, a le fi ifiranṣẹ kan ranṣẹ si unimplemented!lati han wa omission.
///         // Eleyi yoo han: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// N tọka koodu ti ko pari.
///
/// Yi le jẹ wulo ti o ba ti wa ni prototyping ki o si wa ni o kan nwa lati ni koodu rẹ typecheck.
///
/// Awọn iyato laarin [`unimplemented!`] ati `todo!` ni pe nigba ti `todo!` conveys ohun Idi ti nse awọn iṣẹ-nigbamii ati awọn ifiranṣẹ ti wa ni "not yet implemented", `unimplemented!` mu ki ko si iru nperare.
/// Awọn oniwe-ifiranṣẹ ti wa ni "not implemented".
/// Paapaa diẹ ninu awọn IDE yoo samisi `todo!` S.
///
/// # Panics
///
/// Eleyi ife nigbagbogbo [`panic!`].
///
/// # Examples
///
/// Eyi ni àpẹẹrẹ ti awọn ni-itesiwaju koodu.A ni a trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// A fẹ lati se `Foo` on ọkan ninu awọn wa orisi, sugbon a tun fẹ lati ise lori kan `bar()` akọkọ.Ni ibere fun wa koodu lati sakojo, a nilo lati se `baz()`, ki a le lo `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // imuse lọ nibi
///     }
///
///     fn baz(&self) {
///         // jẹ ki ká ko dààmú nipa imulo baz() fun bayi
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // a ti wa ni ko ani lilo baz(), ki ni yi itanran.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Itumo ti-itumọ ti ni macros.
///
/// Pupọ julọ awọn ohun-ini macro (iduroṣinṣin, hihan, ati bẹbẹ lọ) ni a gba lati koodu orisun nibi, pẹlu imukuro awọn iṣẹ imugboroosi ti o nyi awọn igbewọle macro pada si awọn abajade, awọn iṣẹ naa ni a pese nipasẹ akopọ.
///
///
pub(crate) mod builtin {

    /// Okunfa akopo to ba kuna pẹlu awọn ti fi fun aṣiṣe ifiranṣẹ nigbati konge.
    ///
    /// Yi Makiro yẹ ki o wa lo nigbati a crate nlo a àídájú akopo nwon.Mirza lati pese dara aṣiṣe awọn ifiranṣẹ fun aito awọn ipo.
    ///
    /// O ni alakojo-ipele fọọmu ti [`panic!`], ṣugbọn ipele ohun ašiše nigba *akopo* dipo ju ni *asiko isise*.
    ///
    /// # Examples
    ///
    /// Awọn apẹẹrẹ meji bẹ jẹ awọn macros ati awọn agbegbe `#[cfg]`.
    ///
    /// Emit dara alakojo aṣiṣe ti o ba ti a Makiro wa ni koja invalid síi.
    /// Lai ik branch, awọn alakojo yoo si tun emit ohun ašiše, ṣugbọn awọn ašiše ká ifiranṣẹ yoo ko darukọ awọn meji wulo síi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emit alakojo aṣiṣe ti o ba ti ọkan ninu awọn nọmba kan ti awọn ẹya ara ẹrọ ni ko wa.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Oro sile fun awọn miiran okun-piparẹ macros.
    ///
    /// Yi Makiro iṣẹ nipa gbigbe kan piparẹ okun gegebi o ni awọn `{}` fun kọọkan afikun ariyanjiyan koja.
    /// `format_args!` ngbaradi awọn iṣiro afikun lati rii daju pe iṣelọpọ le tumọ bi okun ati ki o ṣe awọn ariyanjiyan le iru awọn iru kan.
    /// Eyikeyi iye ti ọlọnà awọn [`Display`] trait le ti wa ni kọja to `format_args!`, bi le eyikeyi [`Debug`] imuse wa ni koja si a `{:?}` laarin awọn akoonu okun.
    ///
    ///
    /// Eleyi Makiro fun wa kan iye ti iru [`fmt::Arguments`].Yi le wa ni koja si awọn macros laarin [`std::fmt`] fun sise wulo redirection.
    /// Gbogbo awọn miiran akoonu macros ([`kika! '], [`write!`], [`println!`], ati be be) ti wa ni proxied nipasẹ yi ọkan.
    /// `format_args!`, laisi awọn macros ti o ni ariwo, yago fun awọn ipin okiti.
    ///
    /// O le lo awọn [`fmt::Arguments`] iye ti `format_args!` pada ni `Debug` ati `Display` àrà bi ri ni isalẹ.
    /// Apẹẹrẹ tun fihan pe ọna kika `Debug` ati `Display` si ohun kanna: okun kika kika interpolated ni `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Fun alaye diẹ sii, wo awọn iwe ni [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Kanna bi `format_args`, sugbon afikun kan newline ni opin.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspects ohun ayika ayípadà ni sakojo akoko.
    ///
    /// Eleyi Makiro yoo faagun si iye ti awọn ti a npè ni ayika ayípadà ni sakojo akoko, ti nso ohun ikosile ti iru `&'static str`.
    ///
    ///
    /// Ti o ba ti awọn ayika ayípadà ni ko telẹ, ki o si a akopo aṣiṣe yoo wa ni emitted.
    /// Lati ko emit a sakojo aṣiṣe, lo [`option_env!`] Makiro dipo.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// O le ṣe akanṣe ifiranṣẹ aṣiṣe nipa gbigbe okun kan bi paramita keji:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ti o ba ti `documentation` ayika ayípadà ni ko telẹ, o yoo si gba awọn wọnyi aṣiṣe:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Optionally inspects ohun ayika ayípadà ni sakojo akoko.
    ///
    /// Ti o ba ti a npè ni ayika ayípadà jẹ bayi ni sakojo akoko, yi yoo faagun sinu ohun ikosile ti Iru `Option<&'static str>` ti iye ni `Some` ti awọn iye ti awọn ayika ayípadà.
    /// Ti o ba ti awọn ayika ayípadà ni ko bayi, ki o si yi yoo faagun to `None`.
    /// Wo [`Option<T>`][Option] fun alaye siwaju sii lori yi iru.
    ///
    /// A sakojo akoko aṣiṣe ti wa ni ko emitted nigba lilo yi Makiro laibikita boya awọn ayika ayípadà jẹ bayi tabi ko.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates identifiers sinu ọkan idamo.
    ///
    /// Eleyi Makiro gba eyikeyi nọmba ti koma-niya identifiers, ati concatenates gbogbo wọn sinu ọkan, ti nso ohun ikosile ti o jẹ titun kan idamo.
    /// Akiyesi pe o tenilorun mu ki o iru awọn ti yi Makiro ko le Yaworan agbegbe oniyipada.
    /// Bakannaa, bi awọn kan Ofin apapọ, macros ti wa ni nikan laaye ni ohun kan, gbólóhùn tabi ikosile si ipo.
    /// Ti ọna nigba ti o ba le lo yi Makiro fun ifilo si tẹlẹ oniyipada, awọn iṣẹ tabi modulu ati be be lo, o ko ba le setumo titun kan pẹlu o.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_asters! (tuntun, igbadun, orukọ) { }//ko ṣee lo ni ọna yii!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates litireso sinu aimi aimi ege.
    ///
    /// Eleyi Makiro gba eyikeyi nọmba ti koma-niya literals, ti nso ohun ikosile ti Iru `&'static str` eyi ti o duro gbogbo awọn ti awọn literals fi ransẹ osi-to-ọtun.
    ///
    ///
    /// Odidi ati lilefoofo ojuami literals ti wa ni stringified ni ibere lati wa ni ransẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gbooro si ila nọmba ti o ti invoked.
    ///
    /// Pẹlu [`column!`] ati [`file!`], wọnyi macros pese ṣatunṣe alaye fun Difelopa nipa awọn ipo laarin awọn orisun.
    ///
    /// Awọn ti fẹ ikosile ni o ni iru `u32` ati ki o jẹ 1-orisun, ki awọn akọkọ ila ni kọọkan faili evaluates to 1, awọn keji to 2, bbl
    /// Eleyi jẹ ibamu pẹlu aṣiṣe awọn ifiranṣẹ nipa wọpọ compilers tabi gbajumo olootu.
    /// Laini ti a da pada jẹ *kii ṣe dandan* laini ti ẹbẹ `line!` funrararẹ, ṣugbọn kuku ẹbẹ macro akọkọ ti o yori si epe ti macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Gbooro si nọmba ọwọn ni eyiti wọn pe.
    ///
    /// Pẹlu [`line!`] ati [`file!`], wọnyi macros pese ṣatunṣe alaye fun Difelopa nipa awọn ipo laarin awọn orisun.
    ///
    /// Awọn ti fẹ ikosile ni o ni iru `u32` ati ki o jẹ 1-orisun, ki awọn igba akọkọ ti iwe ni kọọkan ila evaluates to 1, awọn keji to 2, bbl
    /// Eleyi jẹ ibamu pẹlu aṣiṣe awọn ifiranṣẹ nipa wọpọ compilers tabi gbajumo olootu.
    /// Ọwọn ti o pada ko *kii ṣe dandan* laini ti ẹbẹ `column!` funrararẹ, ṣugbọn kuku ẹbẹ macro akọkọ ti o yori si epe ti macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Gbooro to awọn faili orukọ ninu eyi ti o ti invoked.
    ///
    /// Pẹlu [`line!`] ati [`column!`], wọnyi macros pese ṣatunṣe alaye fun Difelopa nipa awọn ipo laarin awọn orisun.
    ///
    /// Awọn ti fẹ ikosile ni o ni tẹ `&'static str`, ati awọn pada faili ni ko ni epe ti awọn `file!` Makiro ara, sugbon dipo akọkọ Makiro epe yori soke si epe ti awọn `file!` Makiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies awọn oniwe-ariyanjiyan.
    ///
    /// Makiro yii yoo fun ikosile iru `&'static str` eyiti o jẹ okun ti gbogbo tokens ti o kọja si macro naa.
    /// Ko si awọn ihamọ ti wa ni ao gbe lori sintasi ti awọn Makiro epe ara.
    ///
    /// Akiyesi pe awọn ti fẹ esi ti awọn input tokens le yi ni future.O yẹ ki o wa ni ṣọra o ba ti o gbekele ni o wu.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Pẹlu a UTF-8 ti yipada faili bi a okun.
    ///
    /// Faili naa wa ni ibatan si faili lọwọlọwọ (bakanna si bi a ṣe rii awọn modulu).
    /// Awọn ti pese ona ti ijẹ ni kan Syeed-kan pato ọna ni sakojo akoko.
    /// Nítorí náà, fun apẹẹrẹ, ohun epe pẹlu kan Windows ona ti o ni awọn backslashes `\` yoo ko sakojo ti tọ on Unix.
    ///
    ///
    /// Eleyi Makiro yoo so ohun ikosile ti Iru `&'static str` eyi ti o jẹ awọn awọn akoonu ti awọn faili.
    ///
    /// # Examples
    ///
    /// Ro nibẹ ni o wa meji awọn faili ni kanna liana pẹlu awọn wọnyi ni awọn akoonu ti:
    ///
    /// Faili 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' ati ki o nṣiṣẹ awọn Abajade alakomeji yoo sita "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Pẹlu a file bi a tọka si a baiti orun.
    ///
    /// Faili naa wa ni ibatan si faili lọwọlọwọ (bakanna si bi a ṣe rii awọn modulu).
    /// Awọn ti pese ona ti ijẹ ni kan Syeed-kan pato ọna ni sakojo akoko.
    /// Nítorí náà, fun apẹẹrẹ, ohun epe pẹlu kan Windows ona ti o ni awọn backslashes `\` yoo ko sakojo ti tọ on Unix.
    ///
    ///
    /// Makiro yii yoo fun ikosile iru `&'static [u8; N]` eyiti o jẹ awọn akoonu ti faili naa.
    ///
    /// # Examples
    ///
    /// Ro nibẹ ni o wa meji awọn faili ni kanna liana pẹlu awọn wọnyi ni awọn akoonu ti:
    ///
    /// Faili 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' ati ki o nṣiṣẹ awọn Abajade alakomeji yoo sita "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gbooro si kan okun ti o duro awọn ti isiyi module ona.
    ///
    /// Awọn ti isiyi module ona le ti wa ni ro ti bi awọn logalomomoise ti modulu yori pada soke si awọn crate root.
    /// Ni igba akọkọ ti ẹyaapakankan fun awọn ọna pada ni awọn orukọ ninu awọn crate Lọwọlọwọ ni compiled.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluates Bolianu awọn akojọpọ ti iṣeto ni awọn asia ni sakojo-akoko.
    ///
    /// Ni afikun si ẹda `#[cfg]`, a pese macro yii lati gba laaye igbelewọn ọrọ boolean ti awọn asia iṣeto.
    /// Eleyi nigbagbogbo nyorisi si kere duplicated koodu.
    ///
    /// Awọn sintasi fun lati yi Makiro jẹ kanna sintasi bi awọn [`cfg`] ro.
    ///
    /// `cfg!`, ko `#[cfg]`, ko ni yọ eyikeyi koodu ati ki o nikan evaluates to otitọ tabi èké.
    /// Fun apẹẹrẹ, gbogbo awọn ohun amorindun ni ohun if/else ikosile nilo lati wa ni wulo nigba ti `cfg!` ti lo fun awọn majemu, laiwo ti ohun ti `cfg!` ti wa ni iṣiro.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parses a file bi ohun ikosile tabi ohun kan gẹgẹ bi awọn ti o tọ.
    ///
    /// Awọn faili ti wa ni be ojulumo si awọn ti isiyi faili (bakanna si bi modulu ti wa ni ri).Awọn ti pese ona ti ijẹ ni kan Syeed-kan pato ọna ni sakojo akoko.
    /// Nítorí náà, fun apẹẹrẹ, ohun epe pẹlu kan Windows ona ti o ni awọn backslashes `\` yoo ko sakojo ti tọ on Unix.
    ///
    /// Lilo yi Makiro ni igba kan buburu agutan, nitori ti o ba ti faili ti wa ni parsed bi ohun ikosile, o ti wa ni lilọ si ti wa ni gbe ni awọn agbegbe koodu unhygienically.
    /// Eleyi le ja si ni oniyipada tabi awọn iṣẹ jije ti o yatọ lati ohun ti awọn faili ti ṣe yẹ ti o ba ti nibẹ ni o wa oniyipada tabi awọn iṣẹ ti o ni kanna orukọ ninu atojọ faili.
    ///
    ///
    /// # Examples
    ///
    /// Ro nibẹ ni o wa meji awọn faili ni kanna liana pẹlu awọn wọnyi ni awọn akoonu ti:
    ///
    /// Faili 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Faili 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Compiling 'main.rs' ati ki o nṣiṣẹ awọn Abajade alakomeji yoo sita "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ṣe idaniloju pe ikosile boole jẹ `true` ni asiko asiko.
    ///
    /// Eleyi yoo ikepè [`panic!`] Makiro ti o ba ti pese ikosile ko le wa ni akojopo to `true` ni asiko isise.
    ///
    /// # Uses
    ///
    /// Assertions ti wa ni nigbagbogbo ẹnikeji ninu mejeji yokokoro ati Tu duro, ati ki o ko ba le wa ni alaabo.
    /// Wo [`debug_assert!`] fun awọn idaniloju ti ko ṣiṣẹ ni itusilẹ kọ nipasẹ aiyipada.
    ///
    /// Lewu koodu le gbekele lori `assert!` lati mu lagabara ṣiṣe-akoko invariants ti, ti o ba ru le ja si unsafety.
    ///
    /// Miiran lilo-igba ti `assert!` pẹlú igbeyewo ati igbesele run-akoko invariants ni ailewu koodu (ti o ṣẹ ko le ja si ni unsafety).
    ///
    ///
    /// # aṣa Messages
    ///
    /// Eleyi Makiro ni o ni a keji fọọmu, ibi ti a aṣa panic ifiranṣẹ le ti wa ni pese pẹlu tabi laisi ariyanjiyan fun piparẹ.
    /// Wo [`std::fmt`] fun sintasi fun yi fọọmu.
    /// Expressions lo bi kika ariyanjiyan yoo nikan wa ni akojopo ti o ba ti itenumo kuna.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // awọn panic ifiranṣẹ fun awọn wọnyi assertions ni awọn stringified iye ti awọn ikosile fun.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // a irorun iṣẹ
    ///
    /// assert!(some_computation());
    ///
    /// // sọ pẹlu kan aṣa ifiranṣẹ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Apejọ opopo.
    ///
    /// Ka [unstable book] fun lilo naa.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Apejọ opopo LLVM-ara.
    ///
    /// Ka [unstable book] fun lilo naa.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Module-ipele opopo ijọ.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Tẹ jade koja tokens sinu boṣewa o wu.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kí tabi disables wiwa iṣẹ ti a lo fun ṣatunṣe miiran macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Ro Makiro lo lati waye nianfani macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Ro Makiro loo si iṣẹ kan lati tan o sinu kan kuro igbeyewo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Ṣe apẹrẹ macro ti a lo si iṣẹ kan lati yi i pada sinu idanwo ala.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// An imuse apejuwe ti awọn `#[test]` ati `#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Ro Makiro loo si a aimi lati forukọsilẹ ti o bi a agbaye allocator.
    ///
    /// Wo tun [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ntọju awọn ohun kan ti o ti n loo si ti o ba ti koja ona ni wiwọle, o si yọ awọn ti o bibẹkọ ti.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Gbooro gbogbo `#[cfg]` ati `#[cfg_attr]` eroja ninu awọn koodu ajeku ti o ti n loo si.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Riru imuse apejuwe ti awọn `rustc` alakojo, ma ṣe lo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Riru imuse apejuwe ti awọn `rustc` alakojo, ma ṣe lo.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}