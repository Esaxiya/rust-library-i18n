Panics awọn ti isiyi o tẹle.

Eleyi gba a eto lati fopin si lẹsẹkẹsẹ ki o si pese esi si awọn olupe ti awọn eto.
`panic!` yẹ ki o wa lo nigbati a eto Gigun ohun unrecoverable ipinle.

Eleyi Makiro ni pipe ọna lati assert awọn ipo ni apẹẹrẹ koodu ati ni igbeyewo.
`panic!` ti wa ni pẹkipẹki ti so pẹlu awọn `unwrap` ọna ti awọn mejeeji [`Option`][ounwrap] ati [`Result`][runwrap] enums.
Mejeeji awọn imuṣẹ pe `panic!` nigba ti won ti wa ni ṣeto si [`None`] tabi [`Err`] aba.

Nigba lilo `panic!()` o le pato kan okun payload, ti o ni itumọ ti lilo awọn [`format!`] sintasi.
Ti o payload ni lo nigba ti gigun ogun awọn panic sinu pipe Rust o tẹle ara, nfa o tẹle to panic o šee igbọkanle.

Awọn ihuwasi ti awọn aiyipada `std` hook, ie
koodu ti n ṣiṣẹ taara lẹhin ti a pe panic, ni lati tẹjade isanwo ifiranṣẹ si `stderr` pẹlu alaye file/line/column ti ipe `panic!()`.

O le idojuk panic hook lilo [`std::panic::set_hook()`].
Ninu hook kan panic le wọle si bi `&dyn Any + Send`, eyiti o ni boya `&str` tabi `String` fun awọn igbepe `panic!()` deede.
To panic pẹlu kan iye ti awọn miran miiran Iru, [`panic_any`] le ṣee lo.

[`Result`] enum ni igba kan ti o dara ojutu fun bọlọwọ lati aṣiṣe ju lilo awọn `panic!` Makiro.
O yẹ ki o lo macro yii lati yago fun ilọsiwaju nipa lilo awọn iye ti ko tọ, gẹgẹbi lati awọn orisun ita.
Alaye ti o ni alaye nipa mimu aṣiṣe ni a rii ni [book].

Wo macro [`compile_error!`] tun, fun igbega awọn aṣiṣe lakoko ikojọpọ.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Imuse lọwọlọwọ

Ti o ba ti awọn ifilelẹ ti awọn tẹle panics o yoo fopin si gbogbo awon ati ki o mu rẹ eto pẹlu koodu `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





