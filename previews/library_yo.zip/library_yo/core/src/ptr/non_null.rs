use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ṣugbọn ti kii-odo ati covariant.
///
/// Eyi nigbagbogbo jẹ ohun ti o tọ lati lo nigbati o ba kọ awọn ẹya data ni lilo awọn itọka aise, ṣugbọn nikẹhin o lewu pupọ lati lo nitori awọn ohun-ini afikun rẹ.Ti o ko ba da ọ loju boya o yẹ ki o lo `NonNull<T>`, kan lo `*mut T`!
///
/// Kii `*mut T`, ijuboluwole nigbagbogbo gbọdọ jẹ asan, paapaa ti ijuboluwole ko ba kọkọ silẹ.Eyi jẹ ki awọn enum le lo iye eewọ ti a ko leewọ bi eleyameya-`Option<NonNull<T>>` ni iwọn kanna bi `* mut T`.
/// Sibẹsibẹ ijuboluwole tun le fẹlẹ ti ko ba jẹ akọsilẹ.
///
/// Kii `*mut T`, a yan `NonNull<T>` lati jẹ ibaramu lori `T`.Eyi jẹ ki o ṣee ṣe lati lo `NonNull<T>` nigbati o ba kọ awọn oriṣi isomọ, ṣugbọn ṣafihan eewu ti aibikita ti o ba lo ninu oriṣi ti ko yẹ ki o jẹ covariant.
/// (Aṣayan idakeji ni a ṣe fun `*mut T` botilẹjẹpe ni imọ-ẹrọ imọ-ẹrọ unsoundness le ṣẹlẹ nikan nipasẹ pipe awọn iṣẹ ti ko ni aabo.)
///
/// Covariance jẹ deede fun awọn imukuro ailewu to dara julọ, gẹgẹbi `Box`, `Rc`, `Arc`, `Vec`, ati `LinkedList`.Eyi ni ọran nitori wọn pese API ti gbogbo eniyan ti o tẹle deede awọn ofin iyipada XOR pipin ti Rust.
///
/// Ti iru rẹ ko ba le jẹ alafia lailewu, o gbọdọ rii daju pe o ni diẹ ninu aaye afikun lati pese ailagbara.Nigbagbogbo aaye yii yoo jẹ iru [`PhantomData`] bi `PhantomData<Cell<T>>` tabi `PhantomData<&'a mut T>`.
///
/// Ṣe akiyesi pe `NonNull<T>` ni apẹẹrẹ `From` fun `&T`.Sibẹsibẹ, eyi ko yi otitọ pada pe iyipada nipasẹ (ijuboluwole ti o wa lati a) itọkasi ti a pin jẹ ihuwasi ti a ko ṣalaye ayafi ti iyipada ba waye ninu [`UnsafeCell<T>`] kan.Kanna n lọ fun ṣiṣẹda itọkasi iyipada kan lati itọkasi kan ti o pin.
///
/// Nigbati o ba lo apeere `From` yii laisi `UnsafeCell<T>`, o jẹ ojuṣe rẹ lati rii daju pe a ko pe `as_mut` rara, ati pe `as_ptr` ko lo rara fun iyipada.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` awọn itọka kii ṣe `Send` nitori data ti wọn tọka le jẹ aliali.
// NB, yi impl ni kobojumu, ṣugbọn yẹ ki o pese dara aṣiṣe awọn ifiranṣẹ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ifẹnule ni o wa ko `Sync` nitori awọn data ti won itọkasi le wa ni aliased.
// NB, yi impl ni kobojumu, ṣugbọn yẹ ki o pese dara aṣiṣe awọn ifiranṣẹ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Ṣẹda `NonNull` tuntun ti o fẹsẹmulẹ, ṣugbọn o ni ibamu daradara.
    ///
    /// Eyi jẹ iwulo fun ipilẹṣẹ awọn iru eyiti o fi ipinlẹ laisọ, bi `Vec::new` ṣe.
    ///
    /// Ṣe akiyesi pe iye ijuboluwole le ṣe aṣoju aṣoju to tọ si `T` kan, eyiti o tumọ si pe eyi ko gbọdọ ṣee lo bi iye sentinel "not yet initialized".
    /// Awọn oriṣi ti o fi ipinlẹ lainidi gbọdọ tọpinpin ipilẹṣẹ nipasẹ awọn ọna miiran.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // Aabo: mem::align_of() n pada lilo lilo ti kii-odo eyiti o jẹ lẹhinna casted
        // si a * mut T.
        // Nitorinaa, `ptr` kii ṣe asan ati pe a bọwọ fun awọn ipo fun pipe new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Pada a jo jo si iye.Ni idakeji si [`as_ref`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// Fun ẹlẹgbẹ iyipada le wo [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi kan.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Pada a jo jo si iye.Ni idakeji si [`as_mut`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// Fun ẹlẹgbẹ ti o pin wo [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iraye si (ka tabi kọ) nipasẹ itọka miiran.
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi kan.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Ṣẹda `NonNull` tuntun kan.
    ///
    /// # Safety
    ///
    /// `ptr` gbọdọ jẹ ti kii-asan.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Aabo: olupe gbọdọ ni idaniloju pe `ptr` kii ṣe asan.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ṣẹda `NonNull` tuntun ti `ptr` kii ṣe asan.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Aabo: A ti ṣayẹwo ẹni ti o tọka si ko si jẹ asan
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ṣe iṣẹ kanna bii [`std::ptr::from_raw_parts`], ayafi pe a ti pada ijuboluwole `NonNull`, ni idakeji si ijuboluwole `*const` aise.
    ///
    ///
    /// Wo iwe ti [`std::ptr::from_raw_parts`] fun awọn alaye diẹ sii.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // Aabo: Abajade ti `ptr::from::raw_parts_mut` kii ṣe asan nitori `data_address` jẹ.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompose ijuboluwo (o ṣee ṣe jakejado) sinu jẹ adirẹsi ati awọn paati metadata.
    ///
    /// Atọka le ti wa ni atunkọ nigbamii pẹlu [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Gba ohun ijuboluwole `*mut` ijuboluwole.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Pada itọkasi pín si iye.Ti iye naa le jẹ aibikita, a gbọdọ lo [`as_uninit_ref`] dipo.
    ///
    /// Fun ẹlẹgbẹ iyipada le wo [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * Atọka gbọdọ tọka si apeere ti ipilẹṣẹ ti `T`.
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    /// (Apakan nipa ṣiṣe ipilẹṣẹ ko tii pinnu ni kikun, ṣugbọn titi di igba, ọna ailewu nikan ni lati rii daju pe wọn ti bẹrẹ ni otitọ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi kan.
        unsafe { &*self.as_ptr() }
    }

    /// Pada a oto itọkasi iye.Ti iye naa le jẹ aibikita, a gbọdọ lo [`as_uninit_mut`] dipo.
    ///
    /// Fun ẹlẹgbẹ ti o pin wo [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * Atọka gbọdọ tọka si apeere ti ipilẹṣẹ ti `T`.
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iraye si (ka tabi kọ) nipasẹ itọka miiran.
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    /// (Apakan nipa ṣiṣe ipilẹṣẹ ko tii pinnu ni kikun, ṣugbọn titi di igba, ọna ailewu nikan ni lati rii daju pe wọn ti bẹrẹ ni otitọ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi iyipada.
        unsafe { &mut *self.as_ptr() }
    }

    /// Awọn adarọ si ijuboluwole ti oriṣi miiran.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // Aabo: `self` jẹ ijuboluwole `NonNull` eyiti o jẹ dandan kii ṣe asan
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Ṣẹda gige aise ti ko ni asan lati itọka tẹẹrẹ ati gigun kan.
    ///
    /// Ariyanjiyan `len` ni nọmba awọn eroja **, kii ṣe nọmba awọn baiti.
    ///
    /// Iṣẹ yii jẹ ailewu, ṣugbọn fifagilee iye ipadabọ ko ni aabo.
    /// Wo iwe ti [`slice::from_raw_parts`] fun awọn ibeere aabo ege.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ṣẹda ijuboluwole bibẹrẹ nigbati o bẹrẹ pẹlu ijuboluwo si eroja akọkọ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Akiyesi pe apẹẹrẹ yii n ṣe afihan lasan ni lilo ọna yii, ṣugbọn `jẹ ki bibẹ= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // Aabo: `data` jẹ ijuboluwole `NonNull` eyiti o jẹ dandan kii ṣe asan
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Pada ipari gigun ege alai-asan.
    ///
    /// Iye ti a pada ni nọmba ti awọn eroja **, kii ṣe nọmba awọn baiti.
    ///
    /// Iṣẹ yii jẹ ailewu, paapaa nigbati a ko le ṣe ipin ege alai-asan ti ko wulo si ipin nitori pe ijuboluwole ko ni adirẹsi to wulo.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Pada ijuboluwo ti kii ṣe asan si ifipamọ nkan ti o ge.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // Aabo: A mọ pe `self` kii ṣe asan.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Pada a aise ijuboluwole si bibẹ saarin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Pada itọkasi ti a pin si ege kan ti o ṣee ṣe awọn iye ainitutu.Ni idakeji si [`as_ref`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// Fun ẹlẹgbẹ iyipada le wo [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Atọka gbọdọ jẹ [valid] fun awọn kika fun `ptr.len() * mem::size_of::<T>()` ọpọlọpọ awọn baiti, ati pe o gbọdọ wa ni deedee ni deede.Eyi tumọ si ni pataki:
    ///
    ///     * Gbogbo ibiti iranti ti bibẹ pẹlẹbẹ yii gbọdọ wa ninu ohun ti a fi sọtọ kan!
    ///       Awọn ege ko le gun kọja ọpọlọpọ awọn nkan ti a pin.
    ///
    ///     * Atọka gbọdọ wa ni deede paapaa fun awọn ege gigun-odo.
    ///     Idi kan fun eyi ni pe awọn iṣapeye ifilelẹ enum le gbarale awọn itọkasi (pẹlu awọn ege ti gigun eyikeyi) ni tito lẹtọ ati aiṣe-asan lati ṣe iyatọ wọn si data miiran.
    ///
    ///     Ti o le gba a ijuboluwole ti o jẹ nkan elo bi `data` fun odo-ipari ege lilo [`NonNull::dangling()`].
    ///
    /// * Iwọn lapapọ `ptr.len() * mem::size_of::<T>()` ti gige naa ko gbọdọ tobi ju `isize::MAX`.
    ///   Wo iwe aabo ti [`pointer::offset`].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// Wo tun [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Pada itọkasi alailẹgbẹ si bibẹ pẹlẹbẹ ti awọn iye ti ko ṣee ṣe alaye.Ni idakeji si [`as_mut`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// Fun ẹlẹgbẹ ti o pin wo [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Nigbati o ba pe ọna yii, o ni lati rii daju pe gbogbo nkan wọnyi jẹ otitọ:
    ///
    /// * Awọn ijuboluwole gbọdọ jẹ [valid] fun Say ati ki o Levin fun `ptr.len() * mem::size_of::<T>()` ọpọlọpọ awọn baiti, ati awọn ti o gbọdọ wa ni daradara deedee.Eyi tumọ si ni pataki:
    ///
    ///     * Gbogbo ibiti iranti ti bibẹ pẹlẹbẹ yii gbọdọ wa ninu ohun ti a fi sọtọ kan!
    ///       Awọn ege ko le gun kọja ọpọlọpọ awọn nkan ti a pin.
    ///
    ///     * Atọka gbọdọ wa ni deede paapaa fun awọn ege gigun-odo.
    ///     Idi kan fun eyi ni pe awọn iṣapeye ifilelẹ enum le gbarale awọn itọkasi (pẹlu awọn ege ti gigun eyikeyi) ni tito lẹtọ ati aiṣe-asan lati ṣe iyatọ wọn si data miiran.
    ///
    ///     Ti o le gba a ijuboluwole ti o jẹ nkan elo bi `data` fun odo-ipari ege lilo [`NonNull::dangling()`].
    ///
    /// * Iwọn lapapọ `ptr.len() * mem::size_of::<T>()` ti gige naa ko gbọdọ tobi ju `isize::MAX`.
    ///   Wo iwe aabo ti [`pointer::offset`].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iraye si (ka tabi kọ) nipasẹ itọka miiran.
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// Wo tun [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Eyi jẹ ailewu bi `memory` ṣe wulo fun awọn kika ati kikọ fun `memory.len()` ọpọlọpọ awọn baiti.
    /// // Akiyesi pe a ko gba laaye pipe `memory.as_mut()` nibi nitori akoonu le jẹ alaimọ.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Pada a aise ijuboluwole to ohun ano tabi subslice, lai ṣe igboro yiyewo.
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro tabi nigbati `self` ko ṣe igbasilẹ ni *[ihuwasi ti a ko ṣalaye]* paapaa ti a ko lo ijuboluwo ti o jẹ abajade.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // Aabo: olupe naa ni idaniloju pe `self` jẹ igbasilẹ ati `index` ni awọn igboro.
        // Gẹgẹbi abajade, ijuboluwole ijuboluwole ko le jẹ NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // Aabo: O ijuboluwole Aami kan ko le jẹ asan, nitorinaa awọn ipo fun
        // new_unchecked() ti wa ni bọwọ.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Aabo: Itọkasi iyipada kan ko le jẹ asan.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // Aabo: Itọkasi kan ko le jẹ asan, nitorinaa awọn ipo fun
        // new_unchecked() ti wa ni bọwọ.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}