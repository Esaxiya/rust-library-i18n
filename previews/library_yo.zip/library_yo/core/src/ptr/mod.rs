//! Pẹlu ọwọ ṣakoso iṣakoso iranti nipasẹ awọn itọka aise.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ọpọlọpọ awọn iṣẹ inu module yii gba awọn itọka aise bi awọn ariyanjiyan ki o ka lati tabi kọ si wọn.Fun eyi lati ni aabo, awọn atọka wọnyi gbọdọ jẹ *wulo*.
//! Boya a ijuboluwole jẹ wulo da lori awọn isẹ ti o ti lo fun (ka tabi Kọ), ati iye ti iranti ti o ti wa ni wọle (ie, bi o ọpọlọpọ awọn baiti ni o wa read/written).
//! Pupọ awọn iṣẹ lo `*mut T` ati `* const T` lati ni iraye si iye kan ṣoṣo, ninu eyiti ọran naa iwe naa ko iwọn naa ati lakaye pe o jẹ awọn baiti `size_of::<T>()`.
//!
//! Awọn ofin to peye fun ododo ko ṣe ipinnu sibẹsibẹ.Awọn iṣeduro ti a pese ni aaye yii jẹ iwonba pupọ:
//!
//! * Ijuboluwole [null] jẹ *ko ṣe deede*, koda fun awọn iraye si ti [size zero][zst].
//! * Fun ijuboluwole lati wulo, o jẹ dandan, ṣugbọn kii ṣe nigbagbogbo to, pe ijuboluwole jẹ *kikọ silẹ*: ibiti iranti ti iwọn ti a fifun ti o bẹrẹ ni ijuboluwole gbọdọ jẹ gbogbo laarin awọn aala ohunkan ti a pin sẹhin.
//!
//! Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
//! * Paapaa fun awọn iṣiṣẹ ti [size zero][zst], ijuboluwole ko gbọdọ tọka si iranti ti a pin, ie, ipin ipinpo mu ki awọn itọka di asan paapaa fun awọn iṣẹ iwọn odo.
//! Sibẹsibẹ, sisọ eyikeyi odidi ti kii-odo *gegebi* si ijuboluwole jẹ deede fun awọn iraye si iwọn odo, paapaa ti iranti diẹ ba ṣẹlẹ lati wa ni adirẹsi yẹn ti o si ni ipinfunni.
//! Eyi baamu si kikọ olupilẹṣẹ tirẹ: fifun awọn ohun ti o jẹ iwọn odo ko nira pupọ.
//! Ọna igbasilẹ lati gba ijuboluwole ti o wulo fun awọn iraye si iwọn odo jẹ [`NonNull::dangling`].
//! * Gbogbo awọn accesses nipasẹ ošišẹ ti awọn iṣẹ ni yi module ni o wa *ti kii-atomiki* ni ori ti [atomic operations] lo lati muu laarin awon.
//! Eyi tumọ si pe o jẹ ihuwasi ti a ko ṣalaye lati ṣe awọn iraye si nigbakan meji si ipo kanna lati oriṣiriṣi awọn okun ayafi ti awọn iraye si awọn mejeeji ka lati iranti nikan.
//! Ṣe akiyesi pe eyi pẹlu [`read_volatile`] ati [`write_volatile`] ni gbangba: Awọn iraye si Ayika ko le ṣee lo fun amuṣiṣẹpọ aarin-tẹlera.
//! * Abajade ti sisọ itọka si ijuboluwole kan wulo fun igba ti ohun ti o wa labẹ rẹ ba wa laaye ati pe ko si itọkasi (awọn itọka aise nikan) lati wọle si iranti kanna.
//!
//! Awọn axioms wọnyi, pẹlu lilo ṣọra ti [`offset`] fun iṣiro ijuboluwole, to lati ṣe deede awọn ohun to wulo ni imuse ni koodu ti ko ni aabo.
//! Awọn iṣeduro ti o lagbara ni yoo pese nikẹhin, bi a ti pinnu awọn ofin [aliasing].
//! Fun alaye diẹ sii, wo [book] bakanna bi apakan ninu itọkasi ti a sọtọ si [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Awọn atọka aise ti o wulo bi a ti ṣalaye loke ko ṣe deede to deede (nibiti a ti ṣalaye titete "proper" nipasẹ oriṣi pointee, ie, `*const T` gbọdọ wa ni deede si `mem::align_of::<T>()`).
//! Sibẹsibẹ, ọpọlọpọ awọn iṣẹ nilo awọn ariyanjiyan wọn lati wa ni deede deedee, ati pe yoo sọ ni gbangba ni ibeere yii ninu iwe aṣẹ wọn.
//! Awọn imukuro akiyesi si eyi ni [`read_unaligned`] ati [`write_unaligned`].
//!
//! Nigbati iṣẹ kan nilo titete to tọ, o ṣe bẹ paapaa ti iraye si ni iwọn 0, ie, paapaa ti iranti ko ba fọwọ kan.Wo lilo [`NonNull::dangling`] ni iru awọn ọran bẹẹ.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ṣiṣẹ apanirun naa (ti eyikeyi ba) ti itọkasi-si iye.
///
/// Eyi jẹ deede si pipe pipe [`ptr::read`] ati yiyọ abajade, ṣugbọn ni awọn anfani wọnyi:
///
/// * O ti wa ni *beere* lati lo `drop_in_place` lati ju unsized orisi bi trait nkan, nitori nwọn ko le wa ni ka jade pẹlẹpẹlẹ awọn akopọ ati ki o lọ silẹ deede.
///
/// * O jẹ ọrẹ si olufun lati ṣe eyi lori [`ptr::read`] nigbati o ba sọkalẹ iranti ti a fi ọwọ ṣe pẹlu ọwọ (fun apẹẹrẹ, ninu awọn imuse ti `Box`/`Rc`/`Vec`), bi akopọ ko nilo lati fi idi rẹ mulẹ pe o dun lati gbe ẹda naa.
///
///
/// * O le ṣee lo lati ju data [pinned] silẹ nigbati `T` kii ṣe `repr(packed)` (data ti a pinni ko gbọdọ gbe ṣaaju ki o to silẹ).
///
/// Awọn iye aiṣedeede ko le ju silẹ ni aaye, wọn gbọdọ daakọ si ipo ti o baamu ni akọkọ lilo [`ptr::read_unaligned`].Fun aba ti structs, yi Gbe ti wa ni ṣe laifọwọyi nipasẹ awọn alakojo.
/// Eyi tumọ si awọn aaye ti awọn idiwọn ti kojọpọ ko silẹ ni aaye.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `to_drop` gbọdọ jẹ [valid] fun awọn kika mejeeji ati kikọ.
///
/// * `to_drop` gbọdọ wa ni daradara deedee.
///
/// * Iye `to_drop` tọka si gbọdọ jẹ deede fun fifisilẹ, eyiti o le tumọ si pe o gbọdọ ṣe atilẹyin awọn aiṣe afikun, eyi jẹ igbẹkẹle iru.
///
/// Ni afikun, ti `T` kii ṣe [`Copy`], lilo titọka si iye lẹhin pipe `drop_in_place` le fa ihuwasi aisọye.Akiyesi pe `*to_drop = foo` ka bi lilo nitori pe yoo fa ki iye silẹ lẹẹkansi.
/// [`write()`] le ṣee lo lati tun kọ data laisi nfa ki o silẹ.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pẹlu ọwọ yọ ohun ti o kẹhin kuro lati vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Gba itọka aise si eroja ti o kẹhin ni `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Kuru `v` lati yago fun ohun ti o kẹhin lati ju silẹ.
///     // A ṣe ni akọkọ, lati yago fun awọn ọran ti `drop_in_place` ba wa ni isalẹ panics.
///     v.set_len(1);
///     // Laisi ipe `drop_in_place`, ohun ti o kẹhin kii yoo sọ silẹ, ati iranti ti o ṣakoso yoo jo.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Rii daju pe ohun ti o kẹhin silẹ.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Akiyesi wipe alakojo performs yi da laifọwọyi nigbati sisọ awọn aba ti structs, ie, o ko maa n ni lati dààmú nipa iru awon oran ayafi ti o pe `drop_in_place` ọwọ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koodu nibi ko ni ọrọ, yi ti ni rọpo nipasẹ awọn gidi ju pọ nipasẹ awọn alakojo.
    //

    // Aabo: wo asọye loke
    unsafe { drop_in_place(to_drop) }
}

/// Ṣẹda ijuboluwo alaiṣẹ asan.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Ṣẹda ijuboluwo ihuwa iyipada ti ko ni iyipada.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Afowoyi ti nilo lati yago fun asopọ `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Afowoyi ti nilo lati yago fun asopọ `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Fọọmu apẹrẹ aise lati ijuboluwole ati gigun kan.
///
/// Ariyanjiyan `len` ni nọmba awọn eroja **, kii ṣe nọmba awọn baiti.
///
/// Iṣẹ yii jẹ ailewu, ṣugbọn lilo gangan iye ipadabọ ko ni aabo.
/// Wo iwe ti [`slice::from_raw_parts`] fun awọn ibeere aabo ege.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ṣẹda ijuboluwole bibẹrẹ nigbati o bẹrẹ pẹlu ijuboluwo si eroja akọkọ
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // Aabo: Wiwọle si iye lati ajọṣepọ `Repr` jẹ ailewu nitori * const [T]
        //
        // ati FatPtr ni awọn ipilẹ iranti kanna.std nikan le ṣe iṣeduro yii.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Ṣe iṣẹ kanna bii [`slice_from_raw_parts`], ayafi pe a ti da nkan gige iyipada aise pada, ni ilodi si ege ege ti ko ni iyipada.
///
///
/// Wo iwe ti [`slice_from_raw_parts`] fun awọn alaye diẹ sii.
///
/// Iṣẹ yii jẹ ailewu, ṣugbọn lilo gangan iye ipadabọ ko ni aabo.
/// Wo iwe ti [`slice::from_raw_parts_mut`] fun awọn ibeere aabo ege.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // fi iye kan si itọka ninu gige
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // Aabo: Wiwọle si iye lati ajọṣepọ `Repr` jẹ ailewu nitori * mut [T]
        // ati FatPtr ni awọn ipilẹ iranti kanna
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Swaps awọn iye ni awọn ipo iyipada meji ti iru kanna, laisi iparun boya.
///
/// Ṣugbọn fun awọn imukuro meji wọnyi, iṣẹ yii jẹ deede semantically si [`mem::swap`]:
///
///
/// * O ṣiṣẹ lori awọn itọka aise dipo awọn itọkasi.
/// Nigbati awọn itọkasi ba wa, o yẹ ki [`mem::swap`] fẹ.
///
/// * Awọn iye tọka-si awọn iye meji le ni lqkan.
/// Ti awọn iye naa ba ṣe lulẹ, lẹhinna agbegbe ti iranti ti `x` yoo ṣee lo.
/// Eyi jẹ afihan ni apẹẹrẹ keji ni isalẹ.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * Mejeeji `x` ati `y` gbọdọ jẹ [valid] fun awọn kika mejeeji ati kikọ.
///
/// * Mejeeji `x` ati `y` gbọdọ wa ni deede.
///
/// Akiyesi pe paapaa ti `T` ni iwọn `0`, awọn itọka gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Swapping awọn agbegbe ti kii ṣe agbekọja meji:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // eyi ni `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // eyi ni `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Swapping awọn agbegbe agbekọja meji:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // eyi ni `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // eyi ni `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Awọn atọka `1..3` ti bibẹ pẹlẹbẹ laarin `x` ati `y`.
///     // Awọn abajade ti o ni oye yoo jẹ fun wọn jẹ `[2, 3]`, nitorina awọn atọka `0..3` jẹ `[1, 2, 3]` (ti o baamu `y` ṣaaju `swap`);tabi fun wọn lati jẹ `[0, 1]` ki awọn atọka `1..4` jẹ `[0, 1, 2]` (ti o baamu `x` ṣaaju `swap` naa).
/////
///     // Itumọ yii jẹ asọye lati ṣe yiyan igbehin.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Fun ara wa diẹ ninu aaye fifun lati ṣiṣẹ pẹlu.
    // A ko ni lati ṣàníyàn nipa awọn sil drops: `MaybeUninit` ko ṣe nkankan nigbati o silẹ.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Ṣe Aabo swap: olupe naa gbọdọ ṣe onigbọwọ pe `x` ati `y` wulo fun kikọ ati titọ deede.
    // `tmp` ko le ṣe agbekọja boya `x` tabi `y` nitori pe `tmp` kan ti pin sita lori akopọ bi nkan ti o ya sọtọ.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ati `y` le ni lqkan
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Awọn baiti Swaps `count * size_of::<T>()` laarin awọn agbegbe meji ti iranti ti o bẹrẹ ni `x` ati `y`.
/// Awọn agbegbe meji ko gbọdọ *ṣe* ni lqkan.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * Mejeeji `x` ati `y` gbọdọ jẹ [valid] fun awọn kika mejeeji ati kikọ ti kika *
///   size_of: :<T>() `awọn baiti
///
/// * Mejeeji `x` ati `y` gbọdọ wa ni deede.
///
/// * Ekun ti iranti ti o bẹrẹ ni `x` pẹlu iwọn ti `ka *
///   size_of: :<T>() `awọn baiti ko gbọdọ *ko* ni lqkan pẹlu agbegbe iranti ti o bẹrẹ ni `y` pẹlu iwọn kanna.
///
/// Akọsilẹ ti paapa ti o ba fe ni dakọ iwọn (`ka * size_of: :<T>() ') Ni `0`, awọn ifẹnule gbọdọ jẹ ti kii-NULL ati ki o daradara deedee.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // Aabo: awọn olupe gbọdọ ẹri wipe `x` ati `y` ni o wa
    // wulo fun kikọ ati deede deedee.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Fun orisi kere ju awọn Àkọsílẹ ti o dara ju ni isalẹ, o kan siwopu taara lati yago fun pessimizing codegen.
    //
    if mem::size_of::<T>() < 32 {
        // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe `x` ati `y` wulo
        // fun kikọ, deede deedee, ati aiṣe-agbekọja.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Ọna ti o wa nibi ni lati lo simd lati paarọ x&y daradara.
    // Idanwo fihan pe yiyipada boya awọn baiti 32 tabi awọn baiti 64 ni akoko kan jẹ daradara julọ fun awọn onise Intel Haswell E.
    // LLVM ni anfani diẹ sii lati mu dara ti a ba fun apẹrẹ kan #[repr(simd)], paapaa ti a ko ba lo ipilẹ yii ni taara.
    //
    //
    // FIXME repr(simd) fọ lori emscripten ati redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop nipasẹ x&y, didakọ wọn `Block` ni akoko kan Olufunni yẹ ki o ṣii lupu ni kikun fun ọpọlọpọ awọn oriṣi NB
    // A ko le lo kan fun lupu bi `range` impl awọn ipe `mem::swap` recursively
    //
    let mut i = 0;
    while i + block_size <= len {
        // Ṣẹda diẹ ninu iranti ti a ko ni oye bi aaye ibere Ni sisọ `t` nibi yago fun titopọ akopọ nigbati iyipo yii ko lo
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // Aabo: Bii `i < len`, ati pe olupe naa gbọdọ ṣe onigbọwọ pe `x` ati `y` wulo
        // fun `len` baiti, `x + i` ati `y + i` gbọdọ jẹ wulo adirẹsi, eyi ti o mu aabo guide fun `add`.
        //
        // Pẹlupẹlu, olupe naa gbọdọ ṣe onigbọwọ pe `x` ati `y` wulo fun kikọ, ṣe deedee deede, ati aiṣe apọju, eyiti o mu adehun aabo fun `copy_nonoverlapping` ṣẹ.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Siparọ bulọọki awọn baiti ti x&y, ni lilo t bi ifipamọ igba diẹ Eyi yẹ ki o wa ni iṣapeye sinu awọn iṣẹ SIMD daradara nibiti o wa
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Yi awọn baiti ti o ku ku
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // Aabo: ri ti tẹlẹ aabo ọrọìwòye.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Rare `src` sinu `dst` ti o tọka, n pada iye `dst` ti tẹlẹ.
///
/// Ko si iye silẹ.
///
/// Iṣẹ yii jẹ deede semantically si [`mem::replace`] ayafi pe o ṣiṣẹ lori awọn itọka aise dipo awọn itọkasi.
/// Nigbati awọn itọkasi ba wa, o yẹ ki [`mem::replace`] fẹ.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `dst` gbọdọ jẹ [valid] fun awọn kika mejeeji ati kikọ.
///
/// * `dst` gbọdọ wa ni daradara deedee.
///
/// * `dst` gbọdọ tọka si iye ibẹrẹ akọkọ ti iru `T`.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` yoo ni ipa kanna laisi nilo bulọọki ti ko ni aabo.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // Aabo: olupe gbọdọ ni idaniloju pe `dst` wulo lati jẹ
    // sọ si itọkasi iyipada (wulo fun kikọ, ṣe deede, ti ipilẹṣẹ), ati pe ko le ṣe atunṣe `src` nitori `dst` gbọdọ tọka si ohun ti a pin sọtọ.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ko le ni lqkan
    }
    src
}

/// Ka iye lati `src` laisi gbigbe.Eyi fi iranti silẹ ni `src` aiyipada.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `src` gbọdọ jẹ [valid] fun awọn kika.
///
/// * `src` gbọdọ wa ni deede deedee.Lo [`read_unaligned`] ti eyi ko ba jẹ ọran naa.
///
/// * `src` gbọdọ tọka si iye ibẹrẹ akọkọ ti iru `T`.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Pẹlu ọwọ ṣe [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ṣẹda ẹda bitwise ti iye ni `a` ni `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ti njade ni aaye yii (boya nipa ipadabọ gbangba tabi nipa pipe iṣẹ kan eyiti panics) yoo fa ki iye silẹ ni `tmp` silẹ silẹ lakoko ti iye kanna tun tọka nipasẹ `a`.
///         // Eyi le fa ihuwasi aisọye ti `T` kii ṣe `Copy`.
/////
/////
///
///         // Ṣẹda ẹda bitwise ti iye ni `b` ni `a`.
///         // Eyi jẹ ailewu nitori awọn itọkasi iyipada ko le pe inagijẹ.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Gẹgẹbi loke, jijade nibi le fa ihuwasi ti a ko ṣalaye nitori iye kanna ni a tọka nipasẹ `a` ati `b`.
/////
///
///         // Gbe `tmp` sinu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ti gbe (`write` gba ohun-ini ti ariyanjiyan keji rẹ), nitorinaa ko si ohunkan ti o da silẹ laibikita nibi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ohun-ini ti Iye Ti o pada
///
/// `read` ṣẹda ẹda bitwise ti `T`, laibikita boya `T` jẹ [`Copy`].
/// Ti `T` kii ṣe [`Copy`], lilo mejeeji iye ti o pada ati iye ni `*src` le ṣẹ aabo iranti.
/// Akiyesi pe fifun si `*src` ka bi lilo nitori pe yoo gbiyanju lati sọ iye silẹ ni `* src`.
///
/// [`write()`] le ṣee lo lati tun kọ data laisi nfa ki o silẹ.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` bayi tọka si iranti ipilẹ kanna bi `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Fifiranṣẹ si `s2` fa ki iye atilẹba rẹ silẹ.
///     // Ni ikọja aaye yii, `s` ko gbọdọ lo mọ, bi iranti ipilẹ ti ni ominira.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Fifiranṣẹ si `s` yoo fa ki iye atijọ ti wa silẹ lẹẹkansi, ti o mu ki ihuwasi ti ko ṣalaye.
/////
///     // s= String::from("bar");//Aṣiṣe
///
///     // `ptr::write` le ṣee lo lati tun kọ iye kan laisi fifisilẹ rẹ.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe `src` wulo fun awọn kika.
    // `src` ko le ni lqkan `tmp` nitori `tmp` kan soto lori akopọ bi nkan ti a ya soto.
    //
    //
    // Pẹlupẹlu, niwon a kan kọ iye to wulo sinu `tmp`, o jẹ ẹri lati ni ipilẹṣẹ daradara.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Ka iye lati `src` laisi gbigbe.Eyi fi iranti silẹ ni `src` aiyipada.
///
/// Kii [`read`], `read_unaligned` n ṣiṣẹ pẹlu awọn itọka ti ko ṣe deede.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `src` gbọdọ jẹ [valid] fun awọn kika.
///
/// * `src` gbọdọ tọka si iye ibẹrẹ akọkọ ti iru `T`.
///
/// Bii [`read`], `read_unaligned` ṣẹda ẹda bitwise ti `T`, laibikita boya `T` jẹ [`Copy`].
/// Ti `T` ko ba jẹ [`Copy`], ni lilo mejeeji iye ti o pada ati iye ni `*src` le [violate memory safety][read-ownership].
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Lori awọn structs `packed`
///
/// Lọwọlọwọ ko ṣee ṣe lati ṣẹda awọn itọka aise si awọn aaye aiṣedede ti eto ti o ṣajọ.
///
/// Igbidanwo lati ṣẹda ijuboluwo to aise si aaye igbekalẹ `unaligned` pẹlu ikosile bii `&packed.unaligned as *const FieldType` ṣẹda a itọkasi agbedemeji agbedemeji ṣaaju ki o to yi i pada si ijuboluwole aise.
///
/// Wipe itọkasi yii jẹ fun igba diẹ ati lẹsẹkẹsẹ simẹnti jẹ aibikita bi akopọ nigbagbogbo n nireti awọn itọkasi lati wa ni deede.
/// Bii abajade, lilo `&packed.unaligned as *const FieldType` fa lẹsẹkẹsẹ* ihuwasi ti a ko ṣalaye * ninu eto rẹ.
///
/// Apẹẹrẹ ti kini lati ma ṣe ati bii eyi ṣe ni ibatan si `read_unaligned` ni:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Nibi a gbidanwo lati mu adirẹsi ti odidi odidi 32-eyiti ko ni deede.
///     let unaligned =
///         // Itọkasi itọkasi aiṣedede fun igba diẹ ni a ṣẹda nibi eyiti o mu abajade ihuwasi ti a ko ṣalaye laibikita boya a lo itọkasi naa tabi rara.
/////
///         &packed.unaligned
///         // Simẹnti si ijuboluwole airi ko ṣe iranlọwọ;aṣiṣe tẹlẹ ti ṣẹlẹ.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Wọle si awọn aaye aiṣedede taara pẹlu eg `packed.unaligned` jẹ ailewu sibẹsibẹ.
///
///
///
///
///
///
// FIXME: Ṣe imudojuiwọn awọn docs ti o da lori abajade ti RFC #2582 ati awọn ọrẹ.
/// # Examples
///
/// Ka iye lilo lilo kan lati ibi ifasita baiti kan:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe `src` wulo fun awọn kika.
    // `src` ko le ni lqkan `tmp` nitori `tmp` kan soto lori akopọ bi nkan ti a ya soto.
    //
    //
    // Pẹlupẹlu, niwon a kan kọ iye to wulo sinu `tmp`, o jẹ ẹri lati ni ipilẹṣẹ daradara.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Ṣe atunkọ ipo iranti kan pẹlu iye ti a fun laisi kika tabi ju silẹ iye atijọ.
///
/// `write` ko sọ awọn akoonu ti `dst` silẹ.
/// Eyi jẹ ailewu, ṣugbọn o le jo awọn ipin tabi awọn orisun, nitorinaa o yẹ ki a ṣọra ki a ma kọ nkan ti o yẹ ki o silẹ silẹ.
///
///
/// Ni afikun, kii ṣe ju `src` silẹ.Ni ipilẹṣẹ, a gbe `src` sinu ipo ti o tọka si nipasẹ `dst`.
///
/// Eyi jẹ deede fun ipilẹṣẹ iranti ainitumọ, tabi atunkọ iranti ti o ti jẹ [`read`] tẹlẹ lati.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `dst` gbọdọ jẹ [valid] fun kikọ.
///
/// * `dst` gbọdọ wa ni deede deedee.Lo [`write_unaligned`] ti eyi ko ba jẹ ọran naa.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Pẹlu ọwọ ṣe [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ṣẹda ẹda bitwise ti iye ni `a` ni `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ti njade ni aaye yii (boya nipa ipadabọ gbangba tabi nipa pipe iṣẹ kan eyiti panics) yoo fa ki iye silẹ ni `tmp` silẹ silẹ lakoko ti iye kanna tun tọka nipasẹ `a`.
///         // Eyi le fa ihuwasi aisọye ti `T` kii ṣe `Copy`.
/////
/////
///
///         // Ṣẹda ẹda bitwise ti iye ni `b` ni `a`.
///         // Eyi jẹ ailewu nitori awọn itọkasi iyipada ko le pe inagijẹ.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Gẹgẹbi loke, jijade nibi le fa ihuwasi ti a ko ṣalaye nitori iye kanna ni a tọka nipasẹ `a` ati `b`.
/////
///
///         // Gbe `tmp` sinu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ti gbe (`write` gba ohun-ini ti ariyanjiyan keji rẹ), nitorinaa ko si ohunkan ti o da silẹ laibikita nibi.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // A n pe awọn ojulowo taara lati yago fun awọn ipe iṣẹ ninu koodu ti ipilẹṣẹ bi `intrinsics::copy_nonoverlapping` jẹ iṣẹ ipari.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // Aabo: awọn olupe gbọdọ ẹri wipe `dst` ni wulo fun Levin.
    // `dst` ko le ṣe atunṣe `src` nitori olupe naa ni iraye si iyipada si `dst` lakoko ti `src` jẹ ohun-ini nipasẹ iṣẹ yii.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Ṣe atunkọ ipo iranti kan pẹlu iye ti a fun laisi kika tabi ju silẹ iye atijọ.
///
/// Kii [`write()`], ijuboluwole le jẹ aiṣedeede.
///
/// `write_unaligned` ko ni ju awọn awọn akoonu ti `dst`.Eyi jẹ ailewu, ṣugbọn o le jo awọn ipin tabi awọn orisun, nitorinaa o yẹ ki a ṣọra ki a ma kọ nkan ti o yẹ ki o silẹ silẹ.
///
/// Ni afikun, kii ṣe ju `src` silẹ.Ni ipilẹṣẹ, a gbe `src` sinu ipo ti o tọka si nipasẹ `dst`.
///
/// Eleyi jẹ yẹ fun initializing uninitialized iranti, tabi overwriting iranti ti o ti tẹlẹ a ti ka pẹlu [`read_unaligned`].
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `dst` gbọdọ jẹ [valid] fun kikọ.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL.
///
/// [valid]: self#safety
///
/// ## Lori awọn structs `packed`
///
/// Lọwọlọwọ ko ṣee ṣe lati ṣẹda awọn itọka aise si awọn aaye aiṣedede ti eto ti o ṣajọ.
///
/// Igbidanwo lati ṣẹda ijuboluwo to aise si aaye igbekalẹ `unaligned` pẹlu ikosile bii `&packed.unaligned as *const FieldType` ṣẹda a itọkasi agbedemeji agbedemeji ṣaaju ki o to yi i pada si ijuboluwole aise.
///
/// Wipe itọkasi yii jẹ fun igba diẹ ati lẹsẹkẹsẹ simẹnti jẹ aibikita bi akopọ nigbagbogbo n nireti awọn itọkasi lati wa ni deede.
/// Bii abajade, lilo `&packed.unaligned as *const FieldType` fa lẹsẹkẹsẹ* ihuwasi ti a ko ṣalaye * ninu eto rẹ.
///
/// Apẹẹrẹ ti kini lati ma ṣe ati bii eyi ṣe ni ibatan si `write_unaligned` ni:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Nibi a gbidanwo lati mu adirẹsi ti odidi odidi 32-eyiti ko ni deede.
///     let unaligned =
///         // Itọkasi itọkasi aiṣedede fun igba diẹ ni a ṣẹda nibi eyiti o mu abajade ihuwasi ti a ko ṣalaye laibikita boya a lo itọkasi naa tabi rara.
/////
///         &mut packed.unaligned
///         // Simẹnti si ijuboluwole airi ko ṣe iranlọwọ;aṣiṣe tẹlẹ ti ṣẹlẹ.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Wọle si awọn aaye aiṣedede taara pẹlu eg `packed.unaligned` jẹ ailewu sibẹsibẹ.
///
///
///
///
///
///
///
///
///
// FIXME: Ṣe imudojuiwọn awọn docs ti o da lori abajade ti RFC #2582 ati awọn ọrẹ.
/// # Examples
///
/// Kọ iye lilo kan si ifipamọ baiti kan:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // Aabo: awọn olupe gbọdọ ẹri wipe `dst` ni wulo fun Levin.
    // `dst` ko le ṣe atunṣe `src` nitori olupe naa ni iraye si iyipada si `dst` lakoko ti `src` jẹ ohun-ini nipasẹ iṣẹ yii.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // A n pe ojulowo taara lati yago fun awọn ipe iṣẹ ninu koodu ti ipilẹṣẹ.
        intrinsics::forget(src);
    }
}

/// Ṣe kika iyipada ti iye lati `src` laisi gbigbe.Eyi fi iranti silẹ ni `src` aiyipada.
///
/// Awọn iṣipopada iyipada ni a pinnu lati ṣiṣẹ lori iranti I/O, ati pe o jẹ ẹri lati ma ṣe ṣe atilẹyin tabi tunto nipasẹ alakojo kọja awọn iṣẹ ailagbara miiran.
///
/// # Notes
///
/// Rust ko ni Lọwọlọwọ ni a rigorously ati formally telẹ iranti awoṣe, ki awọn kongẹ oro ijora ti awọn ohun ti "volatile" tumo si nibi jẹ koko ọrọ si ayipada lori akoko.
/// Ti o sọ pe, awọn itumọ-ọrọ yoo fẹrẹ pari nigbagbogbo lẹwa iru si [C11's definition of volatile][c11].
///
/// Olupilẹṣẹ ko yẹ ki o yipada aṣẹ ibatan tabi nọmba ti awọn iṣẹ iranti ailagbara.
/// Sibẹsibẹ, awọn iṣiṣẹ iranti iyipada lori awọn iru iwọn odo (fun apẹẹrẹ, ti o ba kọja iru iwọn-odo si `read_volatile`) jẹ ṣiṣan ati pe o le foju.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `src` gbọdọ jẹ [valid] fun awọn kika.
///
/// * `src` gbọdọ wa ni daradara deedee.
///
/// * `src` gbọdọ tọka si iye ibẹrẹ akọkọ ti iru `T`.
///
/// Bii [`read`], `read_volatile` ṣẹda ẹda bitwise ti `T`, laibikita boya `T` jẹ [`Copy`].
/// Ti `T` ko ba jẹ [`Copy`], ni lilo mejeeji iye ti o pada ati iye ni `*src` le [violate memory safety][read-ownership].
/// Sibẹsibẹ, titoju awọn oriṣi ti kii-[`Daakọ]] ni iranti ailagbara fẹrẹ jẹ aṣiṣe.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Gẹgẹ bi ninu C, boya iṣiṣẹ kan jẹ iyipada ko ni ipa kankan lori awọn ibeere ti o ni iraye si igbakanna lati awọn okun lọpọlọpọ.Awọn irapada iyipada yipada huwa deede bi awọn irawọle ti kii ṣe atomiki ni iyi yẹn.
///
/// Ni pataki, ije kan laarin `read_volatile` ati eyikeyi iṣẹ kikọ si ipo kanna jẹ ihuwasi ti a ko ṣalaye.
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ko panicking lati pa codegen ikolu kere.
        abort();
    }
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Ṣe kikọ iyipada kan ti ipo iranti pẹlu iye ti a fun laisi kika tabi ju silẹ iye atijọ.
///
/// Awọn iṣipopada iyipada ni a pinnu lati ṣiṣẹ lori iranti I/O, ati pe o jẹ ẹri lati ma ṣe ṣe atilẹyin tabi tunto nipasẹ alakojo kọja awọn iṣẹ ailagbara miiran.
///
/// `write_volatile` ko ni ju awọn awọn akoonu ti `dst`.Eyi jẹ ailewu, ṣugbọn o le jo awọn ipin tabi awọn orisun, nitorinaa o yẹ ki a ṣọra ki a ma kọ nkan ti o yẹ ki o silẹ silẹ.
///
/// Ni afikun, kii ṣe ju `src` silẹ.Ni ipilẹṣẹ, a gbe `src` sinu ipo ti o tọka si nipasẹ `dst`.
///
/// # Notes
///
/// Rust ko ni Lọwọlọwọ ni a rigorously ati formally telẹ iranti awoṣe, ki awọn kongẹ oro ijora ti awọn ohun ti "volatile" tumo si nibi jẹ koko ọrọ si ayipada lori akoko.
/// Ti o sọ pe, awọn itumọ-ọrọ yoo fẹrẹ pari nigbagbogbo lẹwa iru si [C11's definition of volatile][c11].
///
/// Olupilẹṣẹ ko yẹ ki o yipada aṣẹ ibatan tabi nọmba ti awọn iṣẹ iranti ailagbara.
/// Sibẹsibẹ, awọn iṣiṣẹ iranti iyipada lori awọn iru iwọn odo (fun apẹẹrẹ, ti o ba kọja iru iwọn-odo si `write_volatile`) jẹ ṣiṣan ati pe o le foju.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `dst` gbọdọ jẹ [valid] fun kikọ.
///
/// * `dst` gbọdọ wa ni daradara deedee.
///
/// Akiyesi pe paapaa ti `T` ba ni iwọn `0`, ijuboluwole gbọdọ jẹ ti kii ṣe NULL ati pe o wa ni deede.
///
/// [valid]: self#safety
///
/// Gẹgẹ bi ninu C, boya iṣiṣẹ kan jẹ iyipada ko ni ipa kankan lori awọn ibeere ti o ni iraye si igbakanna lati awọn okun lọpọlọpọ.Awọn irapada iyipada yipada huwa deede bi awọn irawọle ti kii ṣe atomiki ni iyi yẹn.
///
/// Ni pataki, ije kan laarin `write_volatile` ati eyikeyi iṣẹ miiran (kika tabi kikọ) lori ipo kanna jẹ ihuwasi ti a ko ṣalaye.
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ko panicking lati pa codegen ikolu kere.
        abort();
    }
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Parapọ ijuboluwole `p`.
///
/// Ṣe iṣiro aiṣedeede (ni awọn ofin ti awọn eroja ti `stride` stride) ti o ni lati lo si ijuboluwole `p` ki ijuboluwole `p` yoo ni ibamu si `a`.
///
/// Note: Ifilọlẹ yii ti ni ibamu daradara lati ma ṣe panic.O jẹ UB fun eyi si panic.
/// Iyipada gidi nikan ti o le ṣe nihin ni iyipada ti `INV_TABLE_MOD_16` ati awọn adaduro ti o ni nkan.
///
/// Ti a ba lailai pinnu lati ṣe awọn ti o ṣee ṣe lati pe awọn ojulowo pẹlu `a` ti o ni ko kan agbara-ti-meji, o yoo jasi jẹ diẹ amoye to kan ayipada si a rọrun imuse kuku ju gbiyanju lati mu yi lati gba pe ayipada.
///
///
/// Ibeere eyikeyi lọ si@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Lilo taara ti awọn nkan inu wọnyi ṣe alekun codegen ni ipele opt-=<=
    // 1, nibiti awọn ẹya ọna ti awọn iṣẹ wọnyi ko ṣe ilana.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Ṣe iṣiro oniduro apọju iwọn apọju ti modulu `x` modulo `m`.
    ///
    /// Imuse yii jẹ adaṣe fun `align_offset` ati pe o ni awọn iṣaaju tito tẹlẹ:
    ///
    /// * `m` jẹ agbara-ti-meji;
    /// * `x < m`; (ti o ba jẹ `x ≥ m`, kọja ni `x % m` dipo)
    ///
    /// Imuṣẹ ti iṣẹ yii kii ṣe panic.Lailai.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabili apọjuwọn apọju tabili modulo 2⁴=16.
        ///
        /// Akiyesi, pe tabili yii ko ni awọn iye nibiti idakeji ko si (ie, fun `0⁻¹ mod 16`, `2⁻¹ mod 16`, ati bẹbẹ lọ)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo fun eyiti a ti pinnu `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // Aabo: A nilo `m` lati jẹ agbara-meji, nitorinaa kii ṣe odo.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // A sọ "up" ni lilo agbekalẹ wọnyi:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) y xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // titi 2²ⁿ ≥ m.Lẹhinna a le dinku si `m` ti a fẹ nipa gbigbe abajade `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) moodi n
                //
                // Akiyesi, pe a lo awọn iṣẹ fifọ ni imomose nibi-agbekalẹ atilẹba lo fun apẹẹrẹ, iyokuro `mod n`.
                // O ti wa ni o šee igbọkanle itanran lati ṣe wọn `mod usize::MAX` dipo, nitori ti a ya awọn esi `mod n` ni opin lonakona.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // Aabo: `a` jẹ agbara-meji, nitorinaa kii ṣe odo.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` ọran le ṣe iṣiro diẹ sii ni irọrun nipasẹ `-p (mod a)`, ṣugbọn ṣiṣe bẹ ṣe idiwọ agbara LLVM lati yan awọn itọnisọna bi `lea`.Dipo ti a oniṣiro
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // eyi ti o sepin mosi ni ayika fifuye-ara, ṣugbọn pessimizing `and` to fun LLVM lati wa ni anfani lati lo awọn orisirisi optimizations ti o mo nipa.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Tẹlẹ deedee.Bẹẹni!
        return 0;
    } else if stride == 0 {
        // Ti ijuboluwo naa ko ba ṣe deede, ati pe eroja naa jẹ iwọn odo, lẹhinna ko si iye awọn eroja ti yoo ṣe deede ijuboluwo naa.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // Aabo: a jẹ agbara-ti-meji nitorinaa kii-odo.igbesẹ==0 ọran ti ni ọwọ loke.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // Aabo: gcdpow ni asopọ oke ti o jẹ julọ nọmba ti awọn idinku ninu lilo kan.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // Aabo: gcd nigbagbogbo tobi tabi dọgba si 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch yii n ṣalaye fun idogba idapọ ila-atẹle wọnyi:
        //
        // ` p + so = 0 mod a `
        //
        // `p` eyi ni iye ijuboluwole, `s`, igbesẹ ti `T`, aiṣedeede `o` ni `T`s, ati `a`, tito nkan ti a beere.
        //
        // Pẹlu `g = gcd(a, s)`, ati awọn loke majemu asserting wipe `p` jẹ tun pelu `g`, a le yan `a' = a/g`, `s' = s/g`, `p' = p/g`, ki o si yi di deede lati:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Igba akọkọ ni "the relative alignment of `p` to `a`" (pin nipasẹ `g`), ọrọ keji ni "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (tun pin nipasẹ `g`).
        //
        // Pipin nipasẹ `g` jẹ pataki lati ṣe idakeji daradara ti o ba jẹ pe `a` ati `s` kii ṣe alabaṣiṣẹpọ.
        //
        // Pẹlupẹlu, abajade ti a ṣe nipasẹ ojutu yii kii ṣe "minimal", nitorinaa o ṣe pataki lati mu abajade `o mod lcm(s, a)`.A le rọpo `lcm(s, a)` pẹlu `a'` kan nikan.
        //
        //
        //
        //
        //

        // Aabo: `gcdpow` ni asopọ oke ko tobi ju nọmba ti atẹle 0-die ni `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // Aabo: `a2` kii ṣe odo.Ṣiṣẹ `a` nipasẹ `gcdpow` ko le yiyọ eyikeyi ninu awọn idinku ti a ṣeto
        // ni `a` (eyiti o ni deede ọkan).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // Aabo: `gcdpow` ni asopọ oke ko tobi ju nọmba ti atẹle 0-die ni `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // Aabo: `gcdpow` ni asopọ oke ko tobi ju nọmba ti titele 0-bit wọle
        // `a`.
        // Siwaju si, iyokuro ko le bori, nitori `a2 = a >> gcdpow` yoo ma tobi ju `(p % a) >> gcdpow` lọ nigbagbogbo.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // Aabo: `a2` jẹ agbara-ti-meji, bi a ti fihan loke.`s2` jẹ muna kere ju `a2`
        // nitori `(s % a) >> gcdpow` jẹ muna kere ju `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ko le ṣe deede rara.
    usize::MAX
}

/// Ṣe afiwe awọn itọka aise fun imudogba.
///
/// Eyi jẹ kanna bii lilo oniṣẹ `==`, ṣugbọn apọju kekere:
/// awọn ariyanjiyan ni lati jẹ awọn itọka aise `*const T`, kii ṣe ohunkohun ti o ṣe imuse `PartialEq`.
///
/// Eyi le ṣee lo lati ṣe afiwe awọn itọkasi `&T` (eyiti o fi agbara mu si `*const T` lainidii) nipasẹ adirẹsi wọn dipo ki o ṣe afiwe awọn iye ti wọn tọka si (eyiti o jẹ pe imuse `PartialEq for &T` ṣe).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// A tun ṣe afiwe awọn ege nipasẹ ipari wọn (awọn itọka ọra):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// A tun ṣe afiwe Traits nipasẹ imuse wọn:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Awọn itọka ni awọn adirẹsi dogba.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Awọn ohun ni awọn adirẹsi ti o dọgba, ṣugbọn `Trait` ni awọn imuṣe oriṣiriṣi.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Iyipada itọkasi si awọn afiwe `*const u8` kan nipasẹ adirẹsi.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash a ijuboluwole ijuboluwole.
///
/// Eleyi le ṣee lo lati elile a `&T` itọkasi (eyi ti coerces to `*const T` implicitly) nipa awọn oniwe-adirẹsi dipo ju awọn iye ti o ojuami si (eyi ti o jẹ ohun ti `Hash for &T` imuse wo ni).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Awọn iwuri fun awọn itọka iṣẹ
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: A beere simẹnti agbedemeji bi lilo fun AVR
                // ki aaye adirẹsi ti ijuboluwo iṣẹ orisun ti wa ni fipamọ ni ijuboluwole iṣẹ ikẹhin.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: A beere simẹnti agbedemeji bi lilo fun AVR
                // ki aaye adirẹsi ti ijuboluwo iṣẹ orisun ti wa ni fipamọ ni ijuboluwole iṣẹ ikẹhin.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ko si awọn iṣẹ iyatọ pẹlu awọn ipilẹ 0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Ṣẹda ijuboluwo aise `const` si ibi kan, laisi ṣiṣẹda itọkasi agbedemeji.
///
/// Ṣiṣẹda a itọkasi pẹlu `&`/`&mut` ti wa ni nikan laaye ti o ba ti ijuboluwole ti wa ni daradara deedee ati ojuami si initialized data.
/// Fun igba ibi ti awon ibeere ko si mu, aise ifẹnule yẹ ki o wa lo dipo.
/// Bibẹẹkọ, `&expr as *const _` ṣẹda itọkasi ṣaaju sisọ si atokọ aise, ati pe itọkasi naa wa labẹ awọn ofin kanna bi gbogbo awọn itọkasi miiran.
///
/// Makiro yii le ṣẹda a ijuboluwole *laisi* ṣiṣẹda itọkasi ni akọkọ.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` yoo ṣẹda itọkasi ti a ko fiwe si, ati nitorinaa jẹ Ihuwasi ti a ko Ṣalaye!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Ṣẹda ijuboluwo aise `mut` si ibi kan, laisi ṣiṣẹda itọkasi agbedemeji.
///
/// Ṣiṣẹda a itọkasi pẹlu `&`/`&mut` ti wa ni nikan laaye ti o ba ti ijuboluwole ti wa ni daradara deedee ati ojuami si initialized data.
/// Fun igba ibi ti awon ibeere ko si mu, aise ifẹnule yẹ ki o wa lo dipo.
/// Bibẹẹkọ, `&mut expr as *mut _` ṣẹda itọkasi ṣaaju sisọ si atokọ aise, ati pe itọkasi naa wa labẹ awọn ofin kanna bi gbogbo awọn itọkasi miiran.
///
/// Makiro yii le ṣẹda a ijuboluwole *laisi* ṣiṣẹda itọkasi ni akọkọ.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` yoo ṣẹda itọkasi ti a ko fiwe si, ati nitorinaa jẹ Ihuwasi ti a ko Ṣalaye!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` awọn ipa didakọ aaye dipo ṣiṣẹda itọkasi kan.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}