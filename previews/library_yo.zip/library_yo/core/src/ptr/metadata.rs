#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Pese iru metadata ijuboluwole ti eyikeyi itọkasi-lati tẹ.
///
/// # Atoka metadata
///
/// Awọn oriṣi ijuboluwole Raw ati awọn oriṣi itọkasi ni Rust ni a le ronu bi ti awọn ẹya meji ṣe:
/// ijuboluwo data ti o ni adirẹsi iranti iye, ati diẹ ninu awọn metadata sii.
///
/// Fun awọn iru iwọn iṣiro (ti o ṣe imuse `Sized` traits) bakanna fun awọn iru `extern`, a sọ pe awọn itọka `tinrin`: metadata jẹ iwọn-odo ati iru rẹ ni `()`.
///
///
/// Awọn atọka si [dynamically-sized types][dst] ni a sọ pe `fife` tabi `ọra`, wọn ni metadata ti kii ṣe odo:
///
/// * Fun awọn idiwọn ti aaye to kẹhin jẹ DST, metadata jẹ metadata fun aaye to kẹhin
/// * Fun iru `str`, metadata ni ipari ninu awọn baiti bi `usize`
/// * Fun awọn iru ege bii `[T]`, metadata ni ipari ninu awọn ohun kan bi `usize`
/// * Fun awọn nkan trait bii `dyn SomeTrait`, metadata jẹ [`DynMetadata<Self>`][DynMetadata] (fun apẹẹrẹ `DynMetadata<dyn SomeTrait>`)
///
/// Ninu future, ede Rust le jere iru awọn iru tuntun ti o ni oriṣiriṣi metadata ijuboluwole.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait naa
///
/// Ojuami ti trait yii jẹ iru nkan ti o ni nkan `Metadata` rẹ, eyiti o jẹ `()` tabi `usize` tabi `DynMetadata<_>` bi a ti salaye rẹ loke.
/// O ti wa ni imuse adaṣe fun gbogbo iru.
/// O le ni idaniloju lati wa ni imuse ni ọna kika jeneriki, paapaa laisi adehun ti o baamu.
///
/// # Usage
///
/// Awọn itọka aise le jẹ ibajẹ sinu adirẹsi data ati awọn paati metadata pẹlu ọna [`to_raw_parts`] wọn.
///
/// Ni omiiran, metadata nikan ni a le fa jade pẹlu iṣẹ [`metadata`].
/// A itọkasi o le wa ni koja to [`metadata`] ati implicitly agbara.
///
/// O le tọka si ijuboluwole (possibly-wide) lati adirẹsi rẹ ati metadata pẹlu [`from_raw_parts`] tabi [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Iru fun metadata ninu awọn itọka ati awọn itọkasi si `Self`.
    #[lang = "metadata_type"]
    // NOTE: Jeki trait bounds ni `static_assert_expected_bounds_for_metadata`
    //
    // ni `library/core/src/ptr/metadata.rs` ni amuṣiṣẹpọ pẹlu awọn ti o wa nibi:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Awọn itọka si awọn oriṣi imuṣe inagijẹ trait yii jẹ `tinrin`.
///
/// Eyi pẹlu awọn iru iṣiro-Sized` ati awọn iru `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: maṣe fidi eyi mulẹ ṣaaju ki awọn orukọ inagijẹ trait duro dada ninu ede naa?
pub trait Thin = Pointee<Metadata = ()>;

/// Jade paati metadata ti ijuboluwole kan.
///
/// Awọn iye ti iru `*mut T`, `&T`, tabi `&mut T` le kọja taara si iṣẹ yii bi wọn ṣe fi ipa mu ni ifiagbara si `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // Aabo: Wiwọle si iye lati ajọṣepọ `PtrRepr` jẹ ailewu nitori * const T
    // ati PtrComponents<T>ni awọn ipalemo iranti kanna.
    // std nikan le ṣe iṣeduro yii.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Fọọmu apẹrẹ ijuboluwole (possibly-wide) kan lati adirẹsi data ati metadata.
///
/// Iṣẹ yii jẹ ailewu ṣugbọn ijuboluwole ti o pada ko jẹ ailewu ailewu si ifasilẹ.
/// Fun awọn ege, wo iwe ti [`slice::from_raw_parts`] fun awọn ibeere aabo.
/// Fun awọn nkan trait, metadata gbọdọ wa lati ọdọ ijuboluwole kan si iru ere ere ti o wa ni ipilẹ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // Aabo: Wiwọle si iye lati ajọṣepọ `PtrRepr` jẹ ailewu nitori * const T
    // ati PtrComponents<T>ni awọn ipalemo iranti kanna.
    // std nikan le ṣe iṣeduro yii.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ṣe iṣẹ kanna bi [`from_raw_parts`], ayafi pe a ti da ijuboluwole `*mut` aise pada, ni idakeji si ijuboluwole `* const` aise.
///
///
/// Wo iwe ti [`from_raw_parts`] fun awọn alaye diẹ sii.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // Aabo: Wiwọle si iye lati ajọṣepọ `PtrRepr` jẹ ailewu nitori * const T
    // ati PtrComponents<T>ni awọn ipalemo iranti kanna.
    // std nikan le ṣe iṣeduro yii.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Afowoyi ti nilo lati yago fun asopọ `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Afowoyi ti nilo lati yago fun asopọ `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata fun iru nkan ohun `Dyn = dyn SomeTrait` trait.
///
/// O jẹ ijuboluwole si vtable (tabili ipe foju) ti o ṣe aṣoju gbogbo alaye ti o yẹ lati ṣe afọwọyi iru iru nja ti o fipamọ sinu ohun trait.
/// Vtable paapaa ti o ni:
///
/// * iru iwọn
/// * titete iru
/// * ijuboluwo si iru `drop_in_place` impl (le jẹ a-op fun data-atijọ-pẹtẹlẹ)
/// * awọn itọka si gbogbo awọn ọna fun imuse iru ti trait
///
/// Akiyesi pe awọn mẹta akọkọ jẹ pataki nitori wọn ṣe pataki lati fi ipin, ju silẹ, ati pin ipin eyikeyi ohun trait.
///
/// O ṣee ṣe lati lorukọ eto yii pẹlu irufẹ iru ti kii ṣe nkan `dyn` trait (fun apẹẹrẹ `DynMetadata<u64>`) ṣugbọn kii ṣe lati gba iye ti o ni itumọ ti igbekalẹ naa.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Awọn ìpele ti o wọpọ ti gbogbo awọn vtables.O tẹle pẹlu awọn itọka iṣẹ fun awọn ọna trait.
///
/// Awọn alaye imuse aladani ti `DynMetadata::size_of` ati bẹbẹ lọ
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Pada iwọn iru ti o ni nkan ṣe pẹlu vtable yii.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Pada titete iru ti o ni nkan ṣe pẹlu vtable yii.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Pada iwọn ati titete pọ bi `Layout` kan
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // Aabo: akopọ naa gbejade vtable yii fun iru Rust nja eyiti
        // ni a mọ lati ni ipilẹ to wulo.Ilana kanna bi ni `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Awọn iwuri afọwọyi nilo lati yago fun awọn opin `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}