use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Pada `true` ti o ba ti ijuboluwole asan.
    ///
    /// Akiyesi pe awọn oriṣi ti ko ni iwọn ni ọpọlọpọ awọn itọka asan, bi a ti ṣe akiyesi ijuboluwo data aise, kii ṣe gigun wọn, vtable, ati bẹbẹ lọ.
    /// Nitorinaa, awọn itọka meji ti o jẹ asan le tun ko ṣe afiwe dogba si ara wọn.
    ///
    /// ## Ihuwasi nigba const imọ
    ///
    /// Nigbati a ba lo iṣẹ yii lakoko igbelewọn idiwọn, o le pada `false` fun awọn itọka ti o wa ni asan ni asiko asiko.
    /// Ni pataki, nigbati ijuboluwole si diẹ ninu iranti ba jẹ aiṣedeede ju awọn opin rẹ lọ ni iru ọna ti ijuboluwole ti o jẹ asan, iṣẹ naa yoo tun da `false` pada.
    ///
    /// Ko si ọna fun CTFE lati mọ ipo pipe ti iranti yẹn, nitorinaa a ko le sọ boya itọka naa ko wulo tabi rara.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Ṣe afiwe nipasẹ simẹnti kan si itọka tinrin, nitorinaa awọn itọka ọra n ṣe akiyesi apakan "data" wọn nikan fun asan-ness.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Awọn adarọ si ijuboluwole ti oriṣi miiran.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Decompose ijuboluwo (o ṣee ṣe jakejado) sinu jẹ adirẹsi ati awọn paati metadata.
    ///
    /// Atọka le ti wa ni atunkọ nigbamii pẹlu [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Pada `None` ti ijuboluwo naa ba jẹ asan, tabi bẹẹkọ pada tọka ipin kan si iye ti a we ni `Some`.Ti iye naa le jẹ aibikita, a gbọdọ lo [`as_uninit_ref`] dipo.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Nigbati o ba n pe ọna yii, o ni lati rii daju pe *boya* ijuboluwole jẹ NULL *tabi* gbogbo awọn atẹle jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * Atọka gbọdọ tọka si apeere ti ipilẹṣẹ ti `T`.
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    /// (Apakan nipa ṣiṣe ipilẹṣẹ ko tii pinnu ni kikun, ṣugbọn titi di igba, ọna ailewu nikan ni lati rii daju pe wọn ti bẹrẹ ni otitọ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Ẹya ti ko ṣayẹwo
    ///
    /// Ti o ba ni idaniloju pe ijuboluwole ko le jẹ asan rara o si n wa iru `as_ref_unchecked` kan ti o da `&T` pada dipo `Option<&T>`, mọ pe o le fi orukọ ijuboluwo silẹ taara.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe `self` wulo
        // fun itọkasi ti ko ba jẹ asan.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Pada `None` ti ijuboluwo naa ba jẹ asan, tabi bẹẹkọ pada tọka ipin kan si iye ti a we ni `Some`.
    /// Ni idakeji si [`as_ref`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Nigbati o ba n pe ọna yii, o ni lati rii daju pe *boya* ijuboluwole jẹ NULL *tabi* gbogbo awọn atẹle jẹ otitọ:
    ///
    /// * Atọka gbọdọ wa ni deede ṣe deede.
    ///
    /// * O gbọdọ jẹ "dereferencable" ni ori ti a ṣalaye ninu [the module documentation].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi kan.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ṣe iṣiro aiṣedeede lati ọdọ ijuboluwole kan.
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ti o ba ru eyikeyi awọn ipo wọnyi, abajade jẹ Ihuwasi Ainidi:
    ///
    /// * Mejeeji ijuboluwole ati abajade ti o wa gbọdọ jẹ boya ni awọn aala tabi baiti kan ti o kọja opin ohun ti a pin kanna.
    /// Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// * Iṣiro iṣiro,**ni awọn baiti**, ko le bori `isize` kan.
    ///
    /// * Ifiweranṣẹ ti o wa ni awọn aala ko le gbekele "wrapping around" aaye adirẹsi naa.Iyẹn ni, apao aiṣedeede ailopin,**ninu awọn baiti** gbọdọ baamu ni lilo kan.
    ///
    /// Olupilẹṣẹ ati iwe-ikawe boṣewa ni gbogbogbo gbiyanju lati rii daju pe awọn ipin ko de iwọn nibiti aiṣedeede jẹ ibakcdun kan.
    /// Fun apeere, `Vec` ati `Box` rii daju pe wọn ko pin diẹ sii ju awọn baiti `isize::MAX`, nitorinaa `vec.as_ptr().add(vec.len())` jẹ ailewu nigbagbogbo.
    ///
    /// Pupọ awọn iru ẹrọ ni ipilẹ ko le paapaa kọ iru ipin bẹẹ.
    /// Fun apeere, ko si pẹpẹ 64-bit ti a mọ ti o le ṣe ibeere fun <sup>awọn</sup> baiti 2 <sup>63</sup> nitori awọn idiwọn tabili oju-iwe tabi pipin aaye adirẹsi.
    /// Sibẹsibẹ, diẹ ninu awọn iru ẹrọ 32-bit ati 16-bit le ni ifijišẹ ṣiṣẹ ibeere fun diẹ ẹ sii ju awọn baiti `isize::MAX` pẹlu awọn ohun bii Ifaagun Adirẹsi Ti ara.
    ///
    /// Bii eleyi, iranti ti o gba taara lati awọn olupilẹṣẹ tabi awọn faili ti o ya aworan iranti *le* tobi ju lati mu pẹlu iṣẹ yii.
    ///
    /// Ṣe akiyesi lilo [`wrapping_offset`] dipo ti awọn idiwọ wọnyi nira lati ni itẹlọrun.
    /// Anfani kan ti ọna yii ni pe o jẹ ki awọn iṣapeye akopọ ibinu diẹ sii.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Ṣe iṣiro aiṣedeede lati ijuboluwole nipa lilo iṣiro ṣiṣi.
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii funrararẹ jẹ ailewu nigbagbogbo, ṣugbọn lilo itọka abajade ko ṣe.
    ///
    /// Abajade ijuboluwole wa ni asopọ si nkan ti a pin sọtọ kanna ti `self` tọka si.
    /// O le *ma ṣe* lo lati wọle si nkan ti a pin sọtọ.Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// Ni awọn ọrọ miiran, `let z = x.wrapping_offset((y as isize) - (x as isize))` ko ṣe * ko ṣe `z` bakanna bi `y` paapaa ti a ba ro pe `T` ni iwọn `1` ati pe ko si iṣan-omi: `z` tun wa ni asopọ si nkan ti `x` ti wa ni asopọ si, ati fifa silẹ o jẹ Ihuwasi Ainidii ayafi ti `x` ati `y` ojuami sinu nkan ti a fi soto kanna.
    ///
    /// Ti a ṣe afiwe si [`offset`], ọna yii da duro ni idaduro ibeere ti gbigbe laarin nkan ti a pin sọtọ: [`offset`] jẹ Ihuwasi ti a ko Ni Itumọ lẹsẹkẹsẹ nigbati o nkoja awọn aala ohun;`wrapping_offset` ṣe agbekalẹ ijuboluwole ṣugbọn ṣi tun tọka si Ihuwasi ti a ko Ni Itumọ ti o ba jẹ pe a ti kọ ijuboluwole silẹ nigbati o ba kọja awọn aala ohun ti o ni asopọ.
    /// [`offset`] le ṣe iṣapeye dara julọ ati nitorinaa o dara julọ ninu koodu ti o ni ifọkansi iṣẹ.
    ///
    /// Ayẹwo ti o pẹ nikan ka iye ti ijuboluwole ti a ti kọ silẹ, kii ṣe awọn iye agbedemeji ti a lo lakoko iṣiro ti abajade ikẹhin.
    /// Fun apẹẹrẹ, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` jẹ nigbagbogbo kanna bi `x`.Ni awọn ọrọ miiran, fifi ohun ti a pin silẹ ati lẹhinna titẹ sii ni nigbamii ni a gba laaye.
    ///
    /// Ti o ba nilo lati kọja awọn aala ohun, sọ ijuboluwo si odidi ati ṣe iṣiro nibẹ.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // Iterate ni lilo ijuboluwole ijuwọn ni awọn alekun ti awọn eroja meji
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Yi lupu tẹ jade "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // Aabo: ojulowo `arith_offset` ko ni awọn ohun-ini ṣaaju lati pe.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Ṣe iṣiro aaye laarin awọn itọka meji.Iye ti o pada wa ninu awọn ẹya T: aaye ti o wa ninu awọn baiti ti pin nipasẹ `mem::size_of::<T>()`.
    ///
    /// Iṣẹ yii jẹ iyipada ti [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ti o ba ru eyikeyi awọn ipo wọnyi, abajade jẹ Ihuwasi Ainidi:
    ///
    /// * Mejeeji ibẹrẹ ati ijuboluwole miiran gbọdọ jẹ boya ni awọn aala tabi baiti kan ti o ti kọja opin ohun ti a pin kanna.
    /// Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// * Awọn itọka mejeeji gbọdọ jẹ *ti a gba lati* ijuboluwole si nkan kanna.
    ///   (Wo isalẹ fun apẹẹrẹ.)
    ///
    /// * Aaye laarin awọn itọka, ni awọn baiti, gbọdọ jẹ ọpọ gangan ti iwọn ti `T`.
    ///
    /// * Aaye laarin awọn itọka,**ni awọn baiti**, ko le bori `isize` kan.
    ///
    /// * Ijinna kikopa ninu igboro ko le gbekele lori "wrapping around" awọn adirẹsi aaye.
    ///
    /// Awọn oriṣi Rust ko tobi ju `isize::MAX` ati awọn ipinfunni Rust ko fi ipari si aaye adirẹsi, nitorinaa awọn itọka meji laarin iye kan ti eyikeyi iru Rust iru `T` yoo ma ni itẹlọrun awọn ipo meji to kẹhin.
    ///
    /// Ikawe ikawe boṣewa tun ni gbogbogbo ni idaniloju pe awọn ipin ko de iwọn nibiti aiṣedeede jẹ ibakcdun kan.
    /// Fun apẹẹrẹ, `Vec` ati `Box` rii daju nwọn kò allocate diẹ ẹ sii ju `isize::MAX` baiti, ki `ptr_into_vec.offset_from(vec.as_ptr())` nigbagbogbo satisfies awọn ti o kẹhin meji awọn ipo.
    ///
    /// Pupọ awọn iru ẹrọ ni ipilẹ ko le paapaa kọ iru ipin nla kan.
    /// Fun apeere, ko si pẹpẹ 64-bit ti a mọ ti o le ṣe ibeere fun <sup>awọn</sup> baiti 2 <sup>63</sup> nitori awọn idiwọn tabili oju-iwe tabi pipin aaye adirẹsi.
    /// Sibẹsibẹ, diẹ ninu awọn iru ẹrọ 32-bit ati 16-bit le ni ifijišẹ ṣiṣẹ ibeere fun diẹ ẹ sii ju awọn baiti `isize::MAX` pẹlu awọn ohun bii Ifaagun Adirẹsi Ti ara.
    /// Bii eleyi, iranti ti o gba taara lati awọn olupilẹṣẹ tabi awọn faili ti o ya aworan iranti *le* tobi ju lati mu pẹlu iṣẹ yii.
    /// (Akiyesi pe [`offset`] ati [`add`] tun ni aropin kanna ati nitorinaa ko le ṣee lo lori iru awọn ipin nla bẹ boya.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Iṣẹ yii panics ti `T` jẹ Iru Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Lilo ti ko tọ*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Ṣe ptr2_other miiran jẹ "alias" ti ptr2, ṣugbọn o gba lati ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Niwọn igba ti ptr2_other ati ptr2 ti wa lati inu awọn itọka si awọn oriṣiriṣi awọn nkan, iširo aiṣedeede wọn jẹ ihuwasi ti a ko ṣalaye, botilẹjẹpe wọn tọka si adirẹsi kanna!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ihuwasi ti a ko ṣalaye
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Pada boya awọn itọka meji jẹ onigbọwọ lati dogba.
    ///
    /// Ni asiko asiko iṣẹ yii huwa bi `self == other`.
    /// Sibẹsibẹ, ni diẹ ninu awọn ipo (fun apẹẹrẹ, ṣajọ-akoko igbelewọn), kii ṣe ṣee ṣe nigbagbogbo lati pinnu isọgba ti awọn itọka meji, nitorinaa iṣẹ yii le da pada `false` fun awọn atokọ ti yoo wa ni deede ni deede.
    ///
    /// Ṣugbọn nigbati o ba pada `true`, awọn atokọ jẹ ẹri lati dogba.
    ///
    /// Iṣẹ yii jẹ digi ti [`guaranteed_ne`], ṣugbọn kii ṣe iyatọ rẹ.Nibẹ ni o wa ijuboluwole afiwera fun eyi ti awọn mejeeji iṣẹ pada `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Iye ipadabọ le yipada da lori ẹya apejọ ati koodu ti ko ni aabo le ma gbarale abajade iṣẹ yii fun didara.
    /// A daba pe ki o lo iṣẹ yii nikan fun awọn iṣapeye iṣẹ nibiti awọn iye ipadabọ `false` ti o nipọn nipasẹ iṣẹ yii ko ni ipa lori abajade, ṣugbọn iṣe nikan.
    /// Awọn abajade ti lilo ọna yii lati ṣe asiko asiko ati ṣajọ-akoko koodu ihuwasi oriṣiriṣi ni a ko ti ṣawari.
    /// Ko yẹ ki a lo ọna yii lati ṣafihan iru awọn iyatọ bẹ, ati pe o yẹ ki o tun ṣe iduroṣinṣin ṣaaju ki a ni oye ti o dara julọ nipa ọrọ yii.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Pada boya awọn itọka meji jẹ onigbọwọ lati jẹ aidogba.
    ///
    /// Ni asiko asiko iṣẹ yii huwa bi `self != other`.
    /// Sibẹsibẹ, ni diẹ ninu awọn ipo (fun apẹẹrẹ, ṣajọ-akoko igbelewọn), ko ṣee ṣe nigbagbogbo lati pinnu aidogba ti awọn itọka meji, nitorinaa iṣẹ yii le da pada `false` fun awọn atokọ ti o wa ni otitọ ni deede.
    ///
    /// Ṣugbọn nigbati o ba pada `true`, awọn atọka jẹ ẹri lati jẹ aidogba.
    ///
    /// Iṣẹ yii jẹ digi ti [`guaranteed_eq`], ṣugbọn kii ṣe iyatọ rẹ.Awọn afiwe ijuboluwo wa fun eyiti awọn iṣẹ mejeeji pada `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Iye ipadabọ le yipada da lori ẹya apejọ ati koodu ti ko ni aabo le ma gbarale abajade iṣẹ yii fun didara.
    /// A daba pe ki o lo iṣẹ yii nikan fun awọn iṣapeye iṣẹ nibiti awọn iye ipadabọ `false` ti o nipọn nipasẹ iṣẹ yii ko ni ipa lori abajade, ṣugbọn iṣe nikan.
    /// Awọn abajade ti lilo ọna yii lati ṣe asiko asiko ati ṣajọ-akoko koodu ihuwasi oriṣiriṣi ni a ko ti ṣawari.
    /// Ko yẹ ki a lo ọna yii lati ṣafihan iru awọn iyatọ bẹ, ati pe o yẹ ki o tun ṣe iduroṣinṣin ṣaaju ki a ni oye ti o dara julọ nipa ọrọ yii.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Ṣe iṣiro aiṣedeede lati ijuboluwole kan (wewewe fun `.offset(count as isize)`).
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ti o ba ru eyikeyi awọn ipo wọnyi, abajade jẹ Ihuwasi Ainidi:
    ///
    /// * Mejeeji ijuboluwole ati abajade ti o wa gbọdọ jẹ boya ni awọn aala tabi baiti kan ti o kọja opin ohun ti a pin kanna.
    /// Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// * Iṣiro iṣiro,**ni awọn baiti**, ko le bori `isize` kan.
    ///
    /// * Ifiweranṣẹ ti o wa ni awọn aala ko le gbekele "wrapping around" aaye adirẹsi naa.Iyẹn ni, apao ailopin-išedede gbọdọ baamu ni `usize` kan.
    ///
    /// Olupilẹṣẹ ati iwe-ikawe boṣewa ni gbogbogbo gbiyanju lati rii daju pe awọn ipin ko de iwọn nibiti aiṣedeede jẹ ibakcdun kan.
    /// Fun apeere, `Vec` ati `Box` rii daju pe wọn ko pin diẹ sii ju awọn baiti `isize::MAX`, nitorinaa `vec.as_ptr().add(vec.len())` jẹ ailewu nigbagbogbo.
    ///
    /// Pupọ awọn iru ẹrọ ni ipilẹ ko le paapaa kọ iru ipin bẹẹ.
    /// Fun apeere, ko si pẹpẹ 64-bit ti a mọ ti o le ṣe ibeere fun <sup>awọn</sup> baiti 2 <sup>63</sup> nitori awọn idiwọn tabili oju-iwe tabi pipin aaye adirẹsi.
    /// Sibẹsibẹ, diẹ ninu awọn iru ẹrọ 32-bit ati 16-bit le ni ifijišẹ ṣiṣẹ ibeere fun diẹ ẹ sii ju awọn baiti `isize::MAX` pẹlu awọn ohun bii Ifaagun Adirẹsi Ti ara.
    ///
    /// Bii eleyi, iranti ti o gba taara lati awọn olupilẹṣẹ tabi awọn faili ti o ya aworan iranti *le* tobi ju lati mu pẹlu iṣẹ yii.
    ///
    /// Ṣe akiyesi lilo [`wrapping_add`] dipo ti awọn idiwọ wọnyi nira lati ni itẹlọrun.
    /// Anfani kan ti ọna yii ni pe o jẹ ki awọn iṣapeye akopọ ibinu diẹ sii.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ṣe iṣiro aiṣedeede lati ijuboluwole (wewewe fun `.offset ((kika bi isize).wrapping_neg())`)).
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Ti o ba ru eyikeyi awọn ipo wọnyi, abajade jẹ Ihuwasi Ainidi:
    ///
    /// * Mejeeji ijuboluwole ati abajade ti o wa gbọdọ jẹ boya ni awọn aala tabi baiti kan ti o kọja opin ohun ti a pin kanna.
    /// Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// * Iṣiro iširo ko le kọja awọn baiti `isize::MAX` **.
    ///
    /// * Ifiweranṣẹ ti o wa ni awọn aala ko le gbekele "wrapping around" aaye adirẹsi naa.Iyẹn ni, apao ailopin-išedede gbọdọ baamu ni lilo kan.
    ///
    /// Olupilẹṣẹ ati iwe-ikawe boṣewa ni gbogbogbo gbiyanju lati rii daju pe awọn ipin ko de iwọn nibiti aiṣedeede jẹ ibakcdun kan.
    /// Fun apeere, `Vec` ati `Box` rii daju pe wọn ko pin diẹ sii ju awọn baiti `isize::MAX`, nitorinaa `vec.as_ptr().add(vec.len()).sub(vec.len())` jẹ ailewu nigbagbogbo.
    ///
    /// Pupọ awọn iru ẹrọ ni ipilẹ ko le paapaa kọ iru ipin bẹẹ.
    /// Fun apeere, ko si pẹpẹ 64-bit ti a mọ ti o le ṣe ibeere fun <sup>awọn</sup> baiti 2 <sup>63</sup> nitori awọn idiwọn tabili oju-iwe tabi pipin aaye adirẹsi.
    /// Sibẹsibẹ, diẹ ninu awọn iru ẹrọ 32-bit ati 16-bit le ni ifijišẹ ṣiṣẹ ibeere fun diẹ ẹ sii ju awọn baiti `isize::MAX` pẹlu awọn ohun bii Ifaagun Adirẹsi Ti ara.
    ///
    /// Bii eleyi, iranti ti o gba taara lati awọn olupilẹṣẹ tabi awọn faili ti o ya aworan iranti *le* tobi ju lati mu pẹlu iṣẹ yii.
    ///
    /// Ṣe akiyesi lilo [`wrapping_sub`] dipo ti awọn idiwọ wọnyi nira lati ni itẹlọrun.
    /// Anfani kan ti ọna yii ni pe o jẹ ki awọn iṣapeye akopọ ibinu diẹ sii.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ṣe iṣiro aiṣedeede lati ijuboluwole nipa lilo iṣiro ṣiṣi.
    /// (wewewe fun `.wrapping_offset(count as isize)`)
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii funrararẹ jẹ ailewu nigbagbogbo, ṣugbọn lilo itọka abajade ko ṣe.
    ///
    /// Abajade ijuboluwole wa ni asopọ si nkan ti a pin sọtọ kanna ti `self` tọka si.
    /// O le *ma ṣe* lo lati wọle si nkan ti a pin sọtọ.Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// Ni gbolohun miran, `let z = x.wrapping_add((y as usize) - (x as usize))` wo ni *ko* Rii `z` kanna bi `y` paapa ti o ba ti a ro `T` ni o ni iwọn `1` ati nibẹ ni ko kún: `z` wa ni ṣi so si awọn ohun `x` ti wa ni so si, ati ki o dereferencing o jẹ aisọye Ihuwasi ayafi ti `x` ati `y` ojuami sinu nkan ti a fi soto kanna.
    ///
    /// Ti a ṣe afiwe si [`add`], ọna yii da duro ni idaduro ibeere ti gbigbe laarin nkan ti a pin sọtọ: [`add`] jẹ Ihuwasi ti a ko Ni Itumọ lẹsẹkẹsẹ nigbati o nkoja awọn aala ohun;`wrapping_add` ṣe agbekalẹ ijuboluwole ṣugbọn ṣi tun tọka si Ihuwasi ti a ko Ni Itumọ ti o ba jẹ pe a ti kọ ijuboluwole silẹ nigbati o ba kọja awọn aala ohun ti o ni asopọ si.
    /// [`add`] le ṣe iṣapeye dara julọ ati nitorinaa o dara julọ ninu koodu ti o ni ifọkansi iṣẹ.
    ///
    /// Ayẹwo ti o pẹ nikan ka iye ti ijuboluwole ti a ti kọ silẹ, kii ṣe awọn iye agbedemeji ti a lo lakoko iṣiro ti abajade ikẹhin.
    /// Fun apẹẹrẹ, `x.wrapping_add(o).wrapping_sub(o)` jẹ nigbagbogbo kanna bi `x`.Ni awọn ọrọ miiran, fifi ohun ti a pin silẹ ati lẹhinna titẹ sii ni nigbamii ni a gba laaye.
    ///
    /// Ti o ba nilo lati kọja awọn aala ohun, sọ ijuboluwo si odidi ati ṣe iṣiro nibẹ.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // Iterate ni lilo ijuboluwole ijuwọn ni awọn alekun ti awọn eroja meji
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Yi lupu tẹ jade "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ṣe iṣiro aiṣedeede lati ijuboluwole nipa lilo iṣiro ṣiṣi.
    /// (wewewe fun `.wrapping_offset ((kika bi isize).wrapping_neg())`))
    ///
    /// `count` wa ni awọn ẹya T;fun apẹẹrẹ, `count` kan ti 3 duro fun aiṣoki ijuboluwo ti awọn baiti `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii funrararẹ jẹ ailewu nigbagbogbo, ṣugbọn lilo itọka abajade ko ṣe.
    ///
    /// Abajade ijuboluwole wa ni asopọ si nkan ti a pin sọtọ kanna ti `self` tọka si.
    /// O le *ma ṣe* lo lati wọle si nkan ti a pin sọtọ.Akiyesi pe ni Rust, gbogbo oniyipada (stack-allocated) ni a ṣe akiyesi nkan ti a pin sọtọ.
    ///
    /// Ni awọn ọrọ miiran, `let z = x.wrapping_sub((x as usize) - (y as usize))` ko ṣe * ko ṣe `z` bakanna bi `y` paapaa ti a ba ro pe `T` ni iwọn `1` ati pe ko si iṣan-omi: `z` tun wa ni asopọ si nkan ti `x` ti wa ni asopọ si, ati fifa silẹ o jẹ Ihuwasi Ainidii ayafi ti `x` ati `y` ojuami sinu nkan ti a fi soto kanna.
    ///
    /// Ti a ṣe afiwe si [`sub`], ọna yii da duro ni idaduro ibeere ti gbigbe laarin nkan ti a pin sọtọ: [`sub`] jẹ Ihuwasi ti a ko Ni Itumọ lẹsẹkẹsẹ nigbati o nkoja awọn aala ohun;`wrapping_sub` ṣe agbekalẹ ijuboluwole ṣugbọn ṣi tun tọka si Ihuwasi ti a ko Ni Itumọ ti o ba jẹ pe a ti kọ ijuboluwole silẹ nigbati o ba kọja awọn aala ohun ti o ni asopọ si.
    /// [`sub`] le ṣe iṣapeye dara julọ ati nitorinaa o dara julọ ninu koodu ti o ni ifọkansi iṣẹ.
    ///
    /// Ayẹwo ti o pẹ nikan ka iye ti ijuboluwole ti a ti kọ silẹ, kii ṣe awọn iye agbedemeji ti a lo lakoko iṣiro ti abajade ikẹhin.
    /// Fun apẹẹrẹ, `x.wrapping_add(o).wrapping_sub(o)` jẹ nigbagbogbo kanna bi `x`.Ni awọn ọrọ miiran, fifi ohun ti a pin silẹ ati lẹhinna titẹ sii ni nigbamii ni a gba laaye.
    ///
    /// Ti o ba nilo lati kọja awọn aala ohun, sọ ijuboluwo si odidi ati ṣe iṣiro nibẹ.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// // Iterate ni lilo ijuboluwole ijuwọn ni awọn alekun ti awọn eroja meji (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Yi lupu tẹ jade "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Kn awọn ijuboluwole iye to `ptr`.
    ///
    /// Ni ọran `self` jẹ ijuboluwole (fat) si oriṣi ti ko ni iwọn, iṣiṣẹ yii yoo ni ipa lori apakan ijuboluwo nikan, lakoko ti o jẹ pe awọn atọka (thin) si awọn oriṣi iwọn, eyi ni ipa kanna bi iṣẹ ṣiṣe ti o rọrun.
    ///
    /// Atọka ti o ni abajade yoo ni ifihan ti `val`, ie, fun itọka ọra, iṣiṣẹ yii jẹ bakanna bi ṣiṣẹda itọka ọra tuntun pẹlu iye ijuboluwole data ti `val` ṣugbọn metadata ti `self`.
    ///
    ///
    /// # Examples
    ///
    /// Iṣẹ yii jẹ iwulo ni akọkọ fun gbigba iyọọda itọka baiti-ọlọgbọn lori awọn itọka ọra ti o lagbara:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // yoo tẹ "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // Aabo: Ni ọran ti ijuboluwole tẹẹrẹ, awọn iṣẹ yii jẹ aami kanna
        // si iṣẹ iyansilẹ ti o rọrun.
        // Ni ọran ti ijuboluwo ti ọra, pẹlu imuse iṣeto iṣeto ọra ti isiyi, aaye akọkọ ti iru ijuboluwole nigbagbogbo jẹ ijuboluwo data, eyiti a pin sọtọ bakanna.
        //
        unsafe { *thin = val };
        self
    }

    /// Ka iye lati `self` laisi gbigbe.
    /// Eyi fi iranti silẹ ni `self` aiyipada.
    ///
    /// Wo [`ptr::read`] fun awọn ifiyesi aabo ati awọn apẹẹrẹ.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `read`.
        unsafe { read(self) }
    }

    /// Ṣe kika iyipada ti iye lati `self` laisi gbigbe.Eyi fi iranti silẹ ni `self` aiyipada.
    ///
    /// Awọn iṣipopada iyipada ni a pinnu lati ṣiṣẹ lori iranti I/O, ati pe o jẹ ẹri lati ma ṣe ṣe atilẹyin tabi tunto nipasẹ alakojo kọja awọn iṣẹ ailagbara miiran.
    ///
    ///
    /// Wo [`ptr::read_volatile`] fun awọn ifiyesi aabo ati awọn apẹẹrẹ.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Ka iye lati `self` laisi gbigbe.
    /// Eyi fi iranti silẹ ni `self` aiyipada.
    ///
    /// Kii `read`, ijuboluwole le jẹ aiṣedeede.
    ///
    /// Wo [`ptr::read_unaligned`] fun awọn ifiyesi aabo ati awọn apẹẹrẹ.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Awọn ẹda Awọn baiti `count * size_of<T>` lati `self` si `dest`.
    /// Orisun ati ibi-ajo le ṣapọ.
    ///
    /// NOTE: eyi ni aṣẹ *ariyanjiyan* kanna bi [`ptr::copy`].
    ///
    /// Wo [`ptr::copy`] fun awọn ifiyesi aabo ati awọn apẹẹrẹ.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Awọn ẹda Awọn baiti `count * size_of<T>` lati `self` si `dest`.
    /// Orisun ati ibi-ajo le *ko* ṣe ni lqkan.
    ///
    /// NOTE: eyi ni aṣẹ *ariyanjiyan* kanna bi [`ptr::copy_nonoverlapping`].
    ///
    /// Wo [`ptr::copy_nonoverlapping`] fun awọn ifiyesi aabo ati awọn apẹẹrẹ.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Ṣe iṣiro aiṣedeede ti o nilo lati loo si ijuboluwole lati jẹ ki o baamu si `align`.
    ///
    /// Ti ko ba ṣee ṣe lati ṣe deede ijuboluwole, imuse naa pada `usize::MAX`.
    /// O jẹ iyọọda fun imuse lati *nigbagbogbo* pada `usize::MAX`.
    /// Iṣe algorithm rẹ nikan le dale lori gbigba aiṣedeede lilo nibi, kii ṣe atunṣe rẹ.
    ///
    /// Ifiweranṣẹ ti han ni nọmba awọn eroja `T`, kii ṣe awọn baiti.Iye ti o pada le ṣee lo pẹlu ọna `wrapping_add`.
    ///
    /// Ko si awọn onigbọwọ ohunkohun ti iṣeduro ijuboluwole kii yoo ṣan tabi kọja kọja ipin ti ijuboluwole tọka si.
    ///
    /// O di fun olupe naa lati rii daju pe aiṣedeede ti o pada ni o tọ ni gbogbo awọn ofin miiran ju titete lọ.
    ///
    /// # Panics
    ///
    /// Iṣẹ panics ti `align` ko ba jẹ agbara-ti-meji.
    ///
    /// # Examples
    ///
    /// Wiwọle si `u8` nitosi si bi `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // lakoko ti ijuboluwole le ṣe deede nipasẹ `offset`, yoo tọka si ita ipin naa
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // Aabo: `align` ti ṣayẹwo lati jẹ agbara ti 2 loke
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Pada ipari gigun ege.
    ///
    /// Iye ti a pada ni nọmba ti awọn eroja **, kii ṣe nọmba awọn baiti.
    ///
    /// Iṣẹ yii jẹ ailewu, paapaa nigba ti a ko le sọ iru nkan ge si itọka ege nitori ijuboluwo naa jẹ asan tabi aiṣedeede.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // Aabo: eyi jẹ ailewu nitori `*const [T]` ati `FatPtr<T>` ni ipilẹ kanna.
            // `std` nikan le ṣe iṣeduro yii.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Pada a aise ijuboluwole si bibẹ saarin.
    ///
    /// Eyi jẹ deede si sisọ `self` si `*const T`, ṣugbọn iru-ailewu diẹ sii.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Pada a aise ijuboluwole to ohun ano tabi subslice, lai ṣe igboro yiyewo.
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro tabi nigbati `self` ko ṣe igbasilẹ ni *[ihuwasi ti a ko ṣalaye]* paapaa ti a ko lo ijuboluwo ti o jẹ abajade.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // Aabo: olupe naa ni idaniloju pe `self` jẹ igbasilẹ ati `index` ni awọn igboro.
        unsafe { index.get_unchecked(self) }
    }

    /// Pada `None` ti ijuboluwo naa ba jẹ asan, tabi bẹẹkọ o pada nkan ti o pin si iye ti a fi we ni `Some`.
    /// Ni idakeji si [`as_ref`], eyi ko nilo pe iye ni lati bẹrẹ.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Nigbati o ba n pe ọna yii, o ni lati rii daju pe *boya* ijuboluwole jẹ NULL *tabi* gbogbo awọn atẹle jẹ otitọ:
    ///
    /// * Atọka gbọdọ jẹ [valid] fun awọn kika fun `ptr.len() * mem::size_of::<T>()` ọpọlọpọ awọn baiti, ati pe o gbọdọ wa ni deedee ni deede.Eyi tumọ si ni pataki:
    ///
    ///     * Gbogbo ibiti iranti ti bibẹ pẹlẹbẹ yii gbọdọ wa ninu ohun ti a fi sọtọ kan!
    ///       Awọn ege ko le gun kọja ọpọlọpọ awọn nkan ti a pin.
    ///
    ///     * Atọka gbọdọ wa ni deede paapaa fun awọn ege gigun-odo.
    ///     Idi kan fun eyi ni pe awọn iṣapeye ifilelẹ enum le gbarale awọn itọkasi (pẹlu awọn ege ti gigun eyikeyi) ni tito lẹtọ ati aiṣe-asan lati ṣe iyatọ wọn si data miiran.
    ///
    ///     Ti o le gba a ijuboluwole ti o jẹ nkan elo bi `data` fun odo-ipari ege lilo [`NonNull::dangling()`].
    ///
    /// * Iwọn lapapọ `ptr.len() * mem::size_of::<T>()` ti gige naa ko gbọdọ tobi ju `isize::MAX`.
    ///   Wo iwe aabo ti [`pointer::offset`].
    ///
    /// * O gbọdọ mu awọn ofin alipo ti Rust ṣẹ, nitori igbesi aye ti o pada `'a` ti yan lainidii ati pe ko ṣe afihan igbesi aye data gangan.
    ///   Ni pataki, fun iye akoko igbesi aye yii, iranti ti ijuboluwole tọka si ko gbọdọ ni iyipada (ayafi inu `UnsafeCell`).
    ///
    /// Eyi kan paapaa ti abajade ọna yii ko ba lo!
    ///
    /// Wo tun [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Equality fun awọn itọka
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Lafiwe fun awọn itọka
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}