use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Apo ti o wa ni ayika `*mut T` ti kii ṣe asan ti o tọka pe ẹniti o ni akopọ yii ni onitumọ naa.
/// Wulo fun ile awọn afoyemọ bi `Box<T>`, `Vec<T>`, `String`, ati `HashMap<K, V>`.
///
/// Kii `*mut T`, `Unique<T>` huwa "as if" o jẹ apẹẹrẹ ti `T`.
/// O ṣe `Send`/`Sync` ti `T` jẹ `Send`/`Sync`.
/// O tun tumo si ni irú ti lagbara aliasing onigbọwọ ohun apeere ti `T` le reti:
/// akọwe ti ijuboluwole ko yẹ ki o yipada laisi ọna alailẹgbẹ si Nini tirẹ ti o ni.
///
/// Ti o ko ba da loju boya o tọ lati lo `Unique` fun awọn idi rẹ, ronu nipa lilo `NonNull`, eyiti o ni awọn imọ-imọ ti ko lagbara.
///
///
/// Ko dabi `*mut T`, ijuboluwole nigbagbogbo gbọdọ jẹ asan, paapaa ti ijuboluwole ko ba kọkọ silẹ.
/// Eyi jẹ ki awọn enum le lo iye eewọ ti a eewọ bi eleyameya-`Option<Unique<T>>` ni iwọn kanna bi `Unique<T>`.
/// Sibẹsibẹ ijuboluwole tun le fẹlẹ ti ko ba jẹ akọsilẹ.
///
/// Kii `*mut T`, `Unique<T>` jẹ iyọda lori `T`.
/// Eyi yẹ ki o jẹ deede fun eyikeyi iru eyiti o ṣe atilẹyin awọn ibeere aliase Alailẹgbẹ.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ami yii ko ni awọn abajade fun iyatọ, ṣugbọn o jẹ dandan
    // fun idalẹjọ lati loye pe a ni oye ni `T` kan.
    //
    // Fun awọn alaye, wo:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` awọn itọka jẹ `Send` ti `T` jẹ `Send` nitori data ti wọn tọka jẹ aiṣedeede.
/// Akiyesi pe aiṣe ayipada alieji yii ko ni agbara nipasẹ eto iru;awọn ti afoyemọ lilo awọn `Unique` gbọdọ lagabara o.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` awọn itọka jẹ `Sync` ti `T` jẹ `Sync` nitori data ti wọn tọka jẹ aiṣedeede.
/// Akiyesi pe aiṣe ayipada alieji yii ko ni agbara nipasẹ eto iru;awọn ti afoyemọ lilo awọn `Unique` gbọdọ lagabara o.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Ṣẹda `Unique` tuntun ti o fẹsẹmulẹ, ṣugbọn o ni ibamu daradara.
    ///
    /// Eyi jẹ iwulo fun ipilẹṣẹ awọn iru eyiti o fi ipinlẹ laisọ, bi `Vec::new` ṣe.
    ///
    /// Ṣe akiyesi pe iye ijuboluwole le ṣe aṣoju aṣoju to tọ si `T` kan, eyiti o tumọ si pe eyi ko gbọdọ ṣee lo bi iye sentinel "not yet initialized".
    /// Awọn oriṣi ti o fi ipinlẹ lainidi gbọdọ tọpinpin ipilẹṣẹ nipasẹ awọn ọna miiran.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // Aabo: mem::align_of() pada tọsi, ijuboluwo ti kii ṣe asan.Awọn
        // awọn ipo lati pe new_unchecked() jẹ bọwọ fun bayi.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Ṣẹda `Unique` tuntun kan.
    ///
    /// # Safety
    ///
    /// `ptr` gbọdọ jẹ ti kii-asan.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Aabo: olupe gbọdọ ni idaniloju pe `ptr` kii ṣe asan.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ṣẹda `Unique` tuntun ti `ptr` kii ṣe asan.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Aabo: A ti ṣayẹwo ẹni ti o tọka si ko si jẹ asan.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Gba ohun ijuboluwole `*mut` ijuboluwole.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferences akoonu naa.
    ///
    /// Igbesi aye ti o ni abajade ni asopọ si ara ẹni nitorinaa eyi huwa "as if" o jẹ gangan apeere ti T ti n yawo.
    /// Ti igbesi aye (unbound) gigun ba nilo, lo `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi kan.
        unsafe { &*self.as_ptr() }
    }

    /// Mutably dereferences awọn akoonu.
    ///
    /// Igbesi aye ti o ni abajade ni asopọ si ara ẹni nitorinaa eyi huwa "as if" o jẹ gangan apeere ti T ti n yawo.
    /// Ti igbesi aye (unbound) gigun ba nilo, lo `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Aabo: olupe gbọdọ ni idaniloju pe `self` pade gbogbo awọn
        // awọn ibeere fun itọkasi iyipada.
        unsafe { &mut *self.as_ptr() }
    }

    /// Awọn adarọ si ijuboluwole ti oriṣi miiran.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // Aabo: Unique::new_unchecked() ṣẹda titun kan oto ati aini
        // ijuboluwole ti a fifun lati ma jẹ asan.
        // Niwọn igba ti a n kọja ara ẹni bi ijuboluwo, ko le jẹ asan.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Aabo: Itọkasi iyipada kan ko le jẹ asan
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}