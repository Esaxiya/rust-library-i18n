//! Okun ifọwọyi.
//!
//! Fun alaye sii, wo awọn [`std::str`] module.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ti aala
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. bẹrẹ <=ipari
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. aala ohun kikọ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // wa ohun kikọ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` gbọdọ jẹ kere ju yiya lọ ati aala aala kan
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Pada ipari ti `self`.
    ///
    /// Gigun yii wa ninu awọn baiti, kii ṣe [`char`] tabi awọn graphemes.
    /// Ni awọn ọrọ miiran, o le ma jẹ ohun ti eniyan ṣe akiyesi gigun okun.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // Fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Pada `true` ti o ba ti `self` ni o ni kan ipari ti odo baiti.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Sọwedowo ti `index`-th baiti ni akọkọ baiti ni a UTF-8 koodu ojuami ọkọọkan tabi opin ti awọn okun.
    ///
    ///
    /// Ibẹrẹ ati ipari okun naa (nigbati `atọka== self.len()`) ni a ka si awọn aala.
    ///
    /// Pada `false` ti `index` tobi ju `self.len()` lọ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // ibere ti `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // baiti keji ti `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // kẹta baiti ti `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ati yiya jẹ nigbagbogbo ok.
        // Idanwo fun 0 ni gbangba ki o le mu iwọn ṣayẹwo jade ni rọọrun ki o foju data okun kika kika fun ọran naa.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Eleyi jẹ bit idan deede si: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Yi awọn ege gige okun pada si bibẹ pẹlẹbẹ kan.
    /// Lati yi irẹwẹsi baiti pada sinu ege okun, lo iṣẹ [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // Aabo: ohun orin nitori a ṣe transmute awọn oriṣi meji pẹlu ipilẹ kanna
        unsafe { mem::transmute(self) }
    }

    /// Yi awọn ege gige ti o le yipada pada si bibẹ pẹlẹbẹ ti o le yipada.
    ///
    /// # Safety
    ///
    /// Olupe naa gbọdọ rii daju pe akoonu ti bibẹ pẹlẹbẹ naa jẹ UTF-8 ti o wulo ṣaaju ki yiya pari ati pe `str` ti o wa ni lilo.
    ///
    ///
    /// Lilo ti `str` kan ti awọn akoonu inu rẹ ko wulo UTF-8 jẹ ihuwasi ti a ko ṣalaye.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // Aabo: olukopa lati `&str` si `&[u8]` jẹ ailewu lati `str`
        // ni ifilelẹ kanna bii `&[u8]` (libstd nikan le ṣe iṣeduro yii).
        // Ifiweranṣẹ ijuboluwole jẹ ailewu nitori o wa lati itọkasi iyipada kan eyiti o jẹ ẹri lati wulo fun kikọ.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Yi awọn nkan gige okun pada si ijuboluwole aise.
    ///
    /// Bii awọn ege okun jẹ ege ti awọn baiti, ijuboluwole tọka si [`u8`] kan.
    /// Atọka yii yoo tọka si baiti akọkọ ti gige ege.
    ///
    /// Olupe gbọdọ rii daju pe ijuboluwole ti o pada ko kọ si.
    /// Ti o ba nilo lati yi awọn akoonu ti gige okun pada, lo [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Awọn a mutable okun bibẹ to a aise ijuboluwole.
    ///
    /// Bii awọn ege okun jẹ ege ti awọn baiti, ijuboluwole tọka si [`u8`] kan.
    /// Atọka yii yoo tọka si baiti akọkọ ti gige ege.
    ///
    /// O jẹ ojuṣe rẹ lati rii daju pe bibẹ pẹlẹbẹ okun nikan ni a tunṣe ni ọna ti o jẹ deede UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Pada ipin-iṣẹ ti `str`.
    ///
    /// Eyi ni yiyan ti a ko ni ẹru si titọka `str`.
    /// Padà [`None`] nigbakugba ti deede titọka isẹ yoo panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // awọn atọka kii ṣe lori awọn aala itẹlera UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ti aala
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Pada iwe-aṣẹ iyipada kan ti `str`.
    ///
    /// Eyi ni yiyan ti a ko ni ẹru si titọka `str`.
    /// Padà [`None`] nigbakugba ti deede titọka isẹ yoo panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ipari gigun
    /// assert!(v.get_mut(0..5).is_some());
    /// // ti aala
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Pada ohun sisoô subslice ti `str`.
    ///
    /// Eyi ni yiyan ti a ko ṣayẹwo si titọka `str`.
    ///
    /// # Safety
    ///
    /// Awọn olupe iṣẹ yii jẹ iduro pe awọn ipo wọnyi ni itẹlọrun:
    ///
    /// * Atọka ibẹrẹ ko gbọdọ kọja itọka ipari;
    /// * Awọn atọka gbọdọ wa laarin awọn opin ti bibẹ pẹlẹbẹ;
    /// * Atọka gbọdọ parq lori UTF-8 ọkọọkan aala.
    ///
    /// Ti o ba kuna pe, ege okun ti o pada le tọka iranti ti ko wulo tabi rufin awọn alailera ti a sọ nipa iru `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // Aabo: olupe gbọdọ gbe adehun adehun aabo fun `get_unchecked`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Pada iparọ iyipada kan, atunyẹwo ti a ko ṣayẹwo ti `str`.
    ///
    /// Eyi ni yiyan ti a ko ṣayẹwo si titọka `str`.
    ///
    /// # Safety
    ///
    /// Awọn olupe iṣẹ yii jẹ iduro pe awọn ipo wọnyi ni itẹlọrun:
    ///
    /// * Atọka ibẹrẹ ko gbọdọ kọja itọka ipari;
    /// * Awọn atọka gbọdọ wa laarin awọn opin ti bibẹ pẹlẹbẹ;
    /// * Atọka gbọdọ parq lori UTF-8 ọkọọkan aala.
    ///
    /// Ti o ba kuna pe, ege okun ti o pada le tọka iranti ti ko wulo tabi rufin awọn alailera ti a sọ nipa iru `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // Aabo: olupe gbọdọ gbe adehun adehun aabo fun `get_unchecked_mut`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ṣẹda gige okun lati gige ege okun miiran, yika awọn sọwedowo aabo.
    ///
    /// Eyi ko ṣe iṣeduro ni gbogbogbo, lo pẹlu iṣọra!Fun yiyan ailewu kan wo [`str`] ati [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Yi titun bibẹ lọ lati `begin` to `end`, pẹlu `begin` ṣugbọn lai `end`.
    ///
    /// Lati gba gige gige okun ti o ni iyipada dipo, wo ọna [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Awọn olupe iṣẹ yii jẹ iduro pe awọn ipo mẹta ni itẹlọrun:
    ///
    /// * `begin` ko gbọdọ kọja `end`.
    /// * `begin` ati `end` gbọdọ jẹ awọn ipo baiti laarin bibẹrẹ okun.
    /// * `begin` ati `end` gbọdọ parq lori UTF-8 ọkọọkan aala.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // Aabo: olupe gbọdọ gbe adehun adehun aabo fun `get_unchecked`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ṣẹda gige okun lati gige ege okun miiran, yika awọn sọwedowo aabo.
    /// Eyi ko ṣe iṣeduro ni gbogbogbo, lo pẹlu iṣọra!Fun yiyan ailewu kan wo [`str`] ati [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Yi titun bibẹ lọ lati `begin` to `end`, pẹlu `begin` ṣugbọn lai `end`.
    ///
    /// Lati gba ohun aileyipada okun bibẹ dipo, wo awọn [`slice_unchecked`] ọna.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Awọn olupe iṣẹ yii jẹ iduro pe awọn ipo mẹta ni itẹlọrun:
    ///
    /// * `begin` ko gbọdọ kọja `end`.
    /// * `begin` ati `end` gbọdọ jẹ awọn ipo baiti laarin bibẹrẹ okun.
    /// * `begin` ati `end` gbọdọ parq lori UTF-8 ọkọọkan aala.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // Aabo: olupe gbọdọ gbe adehun adehun aabo fun `get_unchecked_mut`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Pin bibẹrẹ okun kan si meji ni itọka kan.
    ///
    /// Awọn ariyanjiyan, `mid`, yẹ ki o wa a baiti aiṣedeede lati ibere ti awọn okun.
    /// O tun gbọdọ wa lori ala ti aaye koodu UTF-8 kan.
    ///
    /// Awọn ege meji ti o pada lọ lati ibẹrẹ okun gige si `mid`, ati lati `mid` si opin okun gige.
    ///
    /// Lati gba awọn ege okun ti o le yipada dipo, wo ọna [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti `mid` ni ko lori a UTF-8 koodu ojuami ààlà, tabi ti o ba jẹ ti o ti kọja opin ti awọn ti o kẹhin koodu ojuami ti awọn okun bibẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // awọn sọwedowo is_char_boundary pe atọka wa ni [0, .len()]
        if self.is_char_boundary(mid) {
            // Aabo: kan ṣayẹwo pe `mid` wa lori aala aala kan.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Pin gige ege okun iyipada kan ti o le yipada si meji ni itọka kan.
    ///
    /// Awọn ariyanjiyan, `mid`, yẹ ki o wa a baiti aiṣedeede lati ibere ti awọn okun.
    /// O tun gbọdọ wa lori ala ti aaye koodu UTF-8 kan.
    ///
    /// Awọn ege meji ti o pada lọ lati ibẹrẹ okun gige si `mid`, ati lati `mid` si opin okun gige.
    ///
    /// Lati gba awọn ege okun ti ko le yipada dipo, wo ọna [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti `mid` ni ko lori a UTF-8 koodu ojuami ààlà, tabi ti o ba jẹ ti o ti kọja opin ti awọn ti o kẹhin koodu ojuami ti awọn okun bibẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // awọn sọwedowo is_char_boundary pe atọka wa ni [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // Aabo: kan ṣayẹwo pe `mid` wa lori aala aala kan.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Pada aṣetunṣe kan lori [`char`] s ti gige ege.
    ///
    /// Bi gige ege ṣe ni UTF-8 to wulo, a le ṣe itusilẹ nipasẹ gige gige nipasẹ [`char`].
    /// Ọna yii pada iru aṣetunṣe bẹẹ.
    ///
    /// O ṣe pataki lati ranti pe [`char`] duro fun Iye Iwọn Scalar Unicode kan, ati pe o le ma baamu pẹlu imọran rẹ ti kini 'character' jẹ.
    ///
    /// Iyatọ lori awọn iṣupọ grapheme le jẹ ohun ti o fẹ gangan.
    /// Iṣẹ yii ko pese nipasẹ ikawe boṣewa ti Rust, ṣayẹwo crates.io dipo.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Ranti, [`char`] ko le ba ọgbọn-inu rẹ mu nipa awọn kikọ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // kii ṣe 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Pada aṣetunṣe kan lori [`char`] s ti gige ege, ati awọn ipo wọn.
    ///
    /// Bi gige ege ṣe ni UTF-8 to wulo, a le ṣe itusilẹ nipasẹ gige gige nipasẹ [`char`].
    /// Yi ọna ti pada ohun iterator ti awọn mejeeji wọnyi [`char`] s, bi daradara bi wọn baiti awọn ipo.
    ///
    /// Aṣetunṣe n mu awọn tuples jade.Ipo naa jẹ akọkọ, [`char`] jẹ keji.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Ranti, [`char`] ko le ba ọgbọn-inu rẹ mu nipa awọn kikọ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ko (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // akiyesi awọn 3 nibi, awọn ti o kẹhin ti ohun kikọ silẹ si mu soke meji baiti
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Atunṣe kan lori awọn baiti ti gige ege.
    ///
    /// Bi gige ege ṣe ni ọkọọkan lẹsẹsẹ ti awọn baiti, a le ṣe itọsẹ nipasẹ bibẹrẹ okun nipasẹ baiti.
    /// Ọna yii pada iru aṣetunṣe bẹẹ.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Pin pipin okun nipasẹ aaye funfun.
    ///
    /// Awọn iterator pada yoo pada okun ege ti o wa ni iha-ege ti awọn atilẹba okun bibẹ, niya nipa eyikeyi iye ti whitespace.
    ///
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    /// Ti o ba nikan fẹ lati pipin on ASCII whitespace dipo, lo [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Gbogbo awọn iru aaye funfun ni a ṣe akiyesi:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Pin gige okun nipasẹ ASCII aaye funfun.
    ///
    /// Atunṣe ti o pada yoo pada awọn ege okun ti o jẹ awọn ege-kekere ti bibẹ pẹlẹbẹ okun atilẹba, ti o ya sọtọ nipasẹ eyikeyi iye aaye aaye ASCII.
    ///
    ///
    /// To pipin nipa Unicode `Whitespace` dipo, lo [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Gbogbo awọn iru aaye funfun funfun ASCII ni a gbero:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Olutọju kan lori awọn ila ti okun kan, bi awọn ege okun.
    ///
    /// Awọn ila ti pari pẹlu boya (`\n`) tuntun kan tabi ipadabọ gbigbe pẹlu kikọ sii laini kan (`\r\n`).
    ///
    /// Ipari laini ipari jẹ aṣayan.
    /// Okun ti o pari pẹlu ipari laini ipari yoo pada awọn ila kanna bi bibẹkọ ti okun aami kanna laisi ipari ila ipari.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Ik ila ọgangan ti ko ba beere fun:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Atunṣe lori awọn ila ti okun kan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Pada aṣetunṣe ti `u16` lori okun ti a yipada bi UTF-16.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Pada `true` ti o ba jẹ pe apẹẹrẹ ti a fun ni ibaamu ipin-nkan ti ege okun yi.
    ///
    /// Pada `false` ti ko ba ṣe bẹ.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Pada si `true` ti apẹẹrẹ ti a fun ba ba prefix kan ti nkan gige okun yi.
    ///
    /// Pada `false` ti ko ba ṣe bẹ.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Pada `true` ti o ba ti fi fun Àpẹẹrẹ ibaamu a suffix yi okun bibẹ.
    ///
    /// Pada `false` ti ko ba ṣe bẹ.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Pada itọka baiti ti ohun kikọ akọkọ ti nkan gige okun ti o baamu apẹẹrẹ.
    ///
    /// Pada [`None`] ti apẹẹrẹ ko baamu.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Awọn ilana ti o nira sii nipa lilo ara ti ko ni aaye ati awọn pipade:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ko rii apẹẹrẹ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Pada itọka baiti fun ohun kikọ akọkọ ti ibaramu ti o tọ julọ julọ ti apẹrẹ ninu gige okun yii.
    ///
    /// Pada [`None`] ti apẹẹrẹ ko baamu.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Awọn ilana ti eka sii pẹlu awọn pipade:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ko rii apẹẹrẹ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Atunṣe kan lori awọn orisun ti okun gige yi, ti yapa nipasẹ awọn ohun kikọ ti o baamu nipasẹ apẹẹrẹ kan.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada yoo jẹ [`DoubleEndedIterator`] ti apẹẹrẹ ba gba laaye wiwa yiyipada ati wiwa forward/reverse mu awọn eroja kanna wa.
    /// Eyi jẹ otitọ fun, fun apẹẹrẹ, [`char`], ṣugbọn kii ṣe fun `&str`.
    ///
    /// Ti o ba ti Àpẹẹrẹ faye gba a ọna search ṣugbọn awọn oniwe-esi le yato lati kan siwaju search, awọn [`rsplit`] ọna ti le ṣee lo.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ti o ba ti Àpẹẹrẹ ni a bibẹ pẹlẹbẹ ti jo, pin lori kọọkan iṣẹlẹ ti eyikeyi ninu awọn ohun kikọ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ti okun ba ni awọn olupilẹṣẹ ifọrọranṣẹ pupọ, iwọ yoo pari pẹlu awọn okun ofo ninu iṣẹ:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Awọn ipinya onigbọwọ ti ya nipasẹ okun ofo.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Awọn oluyapa ni ibẹrẹ tabi ipari okun kan ni aladugbo nipasẹ awọn okun ofo.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Nigbati a lo okun ti o ṣofo bi oluyapa, o ya gbogbo iwa ni okun, pẹlu ibẹrẹ ati ipari okun naa.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Awọn onigbọwọ onigbọwọ le ja si ihuwasi iyalẹnu nigba ti a lo aaye funfun bi ipinya.Koodu yii tọ:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// O ṣe _not_ fun ọ:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Lo [`split_whitespace`] fun ihuwasi yii.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Atunṣe kan lori awọn orisun ti okun gige yi, ti yapa nipasẹ awọn ohun kikọ ti o baamu nipasẹ apẹẹrẹ kan.
    /// Awọn iyatọ lati aṣetunṣe ti a ṣe nipasẹ `split` ni pe `split_inclusive` fi apakan ti o baamu silẹ bi olutọpa ti okun.
    ///
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ti o ba jẹ pe ohun ti o kẹhin ti okun naa baamu, a yoo ṣe akiyesi nkan yẹn ni ifopinsi ti isomọ ti tẹlẹ.
    /// Ipele yẹn yoo jẹ ohun ti o kẹhin ti o pada nipasẹ aṣetunṣe.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Olutọju kan lori awọn orisun ti gige ege okun ti a fun, ti yapa nipasẹ awọn ohun kikọ ti o baamu nipasẹ apẹẹrẹ kan ati fifun ni aṣẹ yiyipada.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada pada nilo pe apẹẹrẹ ṣe atilẹyin wiwa yiyipada, ati pe yoo jẹ [`DoubleEndedIterator`] ti wiwa forward/reverse ba mu awọn eroja kanna wa.
    ///
    ///
    /// Fun iterating lati iwaju, ọna [`split`] le ṣee lo.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Atunṣe kan lori awọn orisun ti okun gige ti a fun, yapa nipasẹ awọn ohun kikọ ti o baamu nipasẹ apẹrẹ kan.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ti o baamu si [`split`], ayafi pe o ti foju sobusitireti ti o ba ṣofo.
    ///
    /// [`split`]: str::split
    ///
    /// Ọna yii le ṣee lo fun data okun ti o jẹ _terminated_, dipo _separated_ nipasẹ apẹrẹ kan.
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada yoo jẹ [`DoubleEndedIterator`] ti apẹẹrẹ ba gba laaye wiwa yiyipada ati wiwa forward/reverse mu awọn eroja kanna wa.
    /// Eyi jẹ otitọ fun, fun apẹẹrẹ, [`char`], ṣugbọn kii ṣe fun `&str`.
    ///
    /// Ti apẹẹrẹ ba gba wiwa yiyipada ṣugbọn awọn abajade rẹ le yato si wiwa siwaju, ọna [`rsplit_terminator`] le ṣee lo.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Olutọju kan lori awọn orisun ti `self`, ti yapa nipasẹ awọn ohun kikọ ti o baamu nipasẹ apẹẹrẹ kan ati fifun ni aṣẹ yiyipada.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ti o baamu si [`split`], ayafi pe o ti foju sobusitireti ti o ba ṣofo.
    ///
    /// [`split`]: str::split
    ///
    /// Ọna yii le ṣee lo fun data okun ti o jẹ _terminated_, dipo _separated_ nipasẹ apẹrẹ kan.
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada pada nilo pe apẹẹrẹ ṣe atilẹyin wiwa yiyipada, ati pe yoo pari ni ilọpo meji ti wiwa forward/reverse ba mu awọn eroja kanna wa.
    ///
    ///
    /// Fun iterating lati iwaju, ọna [`split_terminator`] le ṣee lo.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Olutọju kan lori awọn orisun ti okun gige ti a fun, ti o yapa nipasẹ apẹẹrẹ kan, ni ihamọ si ipadabọ ni ọpọlọpọ awọn ohun `n`.
    ///
    /// Ti a ba da awọn aropo `n` pada, okun ti o kẹhin (okun `n`th) yoo ni iyoku okun naa ninu.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada ko ni pari ni ilọpo meji, nitori kii ṣe ṣiṣe daradara lati ṣe atilẹyin.
    ///
    /// Ti apẹẹrẹ ba gba wiwa wiwa pada, ọna [`rsplitn`] le ṣee lo.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// An iterator lori substrings yi okun bibẹ, niya nipa kan Àpẹẹrẹ, ti o bere lati opin ti awọn okun, ni ihamọ si pada ni julọ `n` awọn ohun kan.
    ///
    ///
    /// Ti a ba da awọn aropo `n` pada, okun ti o kẹhin (okun `n`th) yoo ni iyoku okun naa ninu.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada ko ni pari ni ilọpo meji, nitori kii ṣe ṣiṣe daradara lati ṣe atilẹyin.
    ///
    /// Fun pipin lati iwaju, ọna [`splitn`] le ṣee lo.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Pin okun naa lori iṣẹlẹ akọkọ ti aala pàtó kan ati ki o pada ṣaju ṣaaju iṣaaju ati suffix lẹhin opin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Pin okun naa lori iṣẹlẹ to kẹhin ti olupin pàtó kan ti o si pada ìpele ṣaaju iṣaaju ati suffix lẹhin opin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Olutọju ọrọ lori awọn ere ibajẹ ti apẹẹrẹ laarin gige ege okun ti a fun.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada yoo jẹ [`DoubleEndedIterator`] ti apẹẹrẹ ba gba laaye wiwa yiyipada ati wiwa forward/reverse mu awọn eroja kanna wa.
    /// Eyi jẹ otitọ fun, fun apẹẹrẹ, [`char`], ṣugbọn kii ṣe fun `&str`.
    ///
    /// Ti apẹẹrẹ ba gba wiwa yiyipada ṣugbọn awọn abajade rẹ le yato si wiwa siwaju, ọna [`rmatches`] le ṣee lo.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Onitumọ kan lori awọn ere ibajẹ ti apẹẹrẹ laarin gige ege okun yii, ti fun ni aṣẹ yiyipada.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada pada nilo pe apẹẹrẹ ṣe atilẹyin wiwa yiyipada, ati pe yoo jẹ [`DoubleEndedIterator`] ti wiwa forward/reverse ba mu awọn eroja kanna wa.
    ///
    ///
    /// Fun iterating lati iwaju, awọn [`matches`] ọna ti le ṣee lo.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Onitumọ kan lori awọn ere ibajẹ ti apẹẹrẹ laarin nkan gige okun yii ati itọka ti ere-idaraya bẹrẹ ni.
    ///
    /// Fun awọn ere-kere ti `pat` laarin `self` ti o ni lqkan, awọn atokọ ti o baamu si idije akọkọ nikan ni a pada.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada yoo jẹ [`DoubleEndedIterator`] ti apẹẹrẹ ba gba laaye wiwa yiyipada ati wiwa forward/reverse mu awọn eroja kanna wa.
    /// Eyi jẹ otitọ fun, fun apẹẹrẹ, [`char`], ṣugbọn kii ṣe fun `&str`.
    ///
    /// Ti apẹẹrẹ ba gba wiwa yiyipada ṣugbọn awọn abajade rẹ le yato si wiwa siwaju, ọna [`rmatch_indices`] le ṣee lo.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // nikan `aba` akọkọ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Olutọju kan lori awọn ere ibajẹ ti apẹẹrẹ laarin `self`, ti fun ni aṣẹ yiyipada pẹlu itọka ere-kere.
    ///
    /// Fun awọn ere-kere ti `pat` laarin `self` ti o ṣapọ, awọn atọka ti o baamu to baramu to kẹhin nikan ni a pada.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iterator ihuwasi
    ///
    /// Olutọju ti o pada pada nilo pe apẹẹrẹ ṣe atilẹyin wiwa yiyipada, ati pe yoo jẹ [`DoubleEndedIterator`] ti wiwa forward/reverse ba mu awọn eroja kanna wa.
    ///
    ///
    /// Fun iterating lati iwaju, ọna [`match_indices`] le ṣee lo.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // nikan ni kẹhin `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Pada ajẹbẹ okun pẹlu yori ati trailing aaye funfun kuro.
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Padà a okun bibẹ pẹlu asiwaju whitespace kuro.
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// `start` ni ipo yii tumọ si ipo akọkọ ti okun baiti yẹn;fun a osi-to-ọtun ede bi English tabi Russian, yi ni yio je apa osi, ati fun ọtun-si-osi ede bi Arabic tabi Heberu, yi yoo jẹ awọn ọtun ẹgbẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Pada gige ege pẹlu yiyọ aaye funfun.
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// `end` ni ipo yii tumọ si ipo ikẹhin ti okun baiti yẹn;fun ede osi-si-ọtun bi Gẹẹsi tabi Russian, eyi yoo jẹ apa ọtun, ati fun awọn ede sọtun-si-osi bi Arabic tabi Heberu, eyi yoo jẹ apa osi.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Padà a okun bibẹ pẹlu asiwaju whitespace kuro.
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// 'Left' ni ipo yii tumọ si ipo akọkọ ti okun baiti yẹn;fun ede bii Arabic tabi Heberu ti o jẹ 'ọtun si osi' dipo 'osi si ọtun', eyi yoo jẹ ẹgbẹ _right_, kii ṣe apa osi.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Pada gige ege pẹlu yiyọ aaye funfun.
    ///
    /// 'Whitespace' ti wa ni asọye ni ibamu si awọn ofin ti Unicode Ti o ni Ohun-ini Core `White_Space`.
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// 'Right' ni yi o tọ ti o tumo si awọn ti o kẹhin ipo ti ti baiti okun;fun ede bii Arabic tabi Heberu ti o jẹ 'ọtun si osi' dipo 'osi si ọtun', eyi yoo jẹ ẹgbẹ _left_, kii ṣe ẹtọ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Pada ajẹkù okun pẹlu gbogbo awọn prefixes ati awọn suffixes ti o baamu apẹẹrẹ kan ti a yọ kuro leralera.
    ///
    /// [pattern] le jẹ [`char`], ege ti [`char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ranti baramu ti o mọ julọ, ṣe atunṣe ni isalẹ ti o ba jẹ
            // kẹhin baramu ti o yatọ si
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // Aabo: A mọ `Searcher` lati da awọn atọka to wulo pada.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Pada ajẹkù okun pẹlu gbogbo awọn prefixes ti o baamu apẹẹrẹ kan ti a yọ kuro leralera.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// `start` ni ipo yii tumọ si ipo akọkọ ti okun baiti yẹn;fun a osi-to-ọtun ede bi English tabi Russian, yi ni yio je apa osi, ati fun ọtun-si-osi ede bi Arabic tabi Heberu, yi yoo jẹ awọn ọtun ẹgbẹ.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // Aabo: A mọ `Searcher` lati da awọn atọka to wulo pada.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Pada aapọn okun pẹlu prefix kuro.
    ///
    /// Ti okun ba bẹrẹ pẹlu apẹẹrẹ `prefix`, yoo pada sipo lẹhin ti ìpele, ti a we ni `Some`.
    /// Kii `trim_start_matches`, ọna yii yọ prefix kuro ni ẹẹkan.
    ///
    /// Ti okun ko ba bẹrẹ pẹlu `prefix`, pada `None`.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Pada a okun bibẹ pẹlu awọn suffix kuro.
    ///
    /// Ti okun ba pari pẹlu apẹẹrẹ `suffix`, yoo mu okun pada ṣaaju suffix, ti a we ni `Some`.
    /// Ko dabi `trim_end_matches`, ọna yii n yọ suffix kuro ni ẹẹkan.
    ///
    /// Ti okun ko ba pari pẹlu `suffix`, pada `None`.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Pada gige ege pẹlu gbogbo awọn suffixes ti o baamu apẹẹrẹ kan ti a yọ kuro leralera.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// `end` ni ipo yii tumọ si ipo ikẹhin ti okun baiti yẹn;fun ede osi-si-ọtun bi Gẹẹsi tabi Russian, eyi yoo jẹ apa ọtun, ati fun awọn ede sọtun-si-osi bi Arabic tabi Heberu, eyi yoo jẹ apa osi.
    ///
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // Aabo: A mọ `Searcher` lati da awọn atọka to wulo pada.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Pada ajẹkù okun pẹlu gbogbo awọn prefixes ti o baamu apẹẹrẹ kan ti a yọ kuro leralera.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// 'Left' ni ipo yii tumọ si ipo akọkọ ti okun baiti yẹn;fun ede bii Arabic tabi Heberu ti o jẹ 'ọtun si osi' dipo 'osi si ọtun', eyi yoo jẹ ẹgbẹ _right_, kii ṣe apa osi.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Pada gige ege pẹlu gbogbo awọn suffixes ti o baamu apẹẹrẹ kan ti a yọ kuro leralera.
    ///
    /// [pattern] le jẹ `&str`, [`char`], ege ti ``char`] s, tabi iṣẹ kan tabi bíbo ti o pinnu boya ohun kikọ ba baamu.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Itọsọna ọrọ
    ///
    /// Okun jẹ ọkọọkan awọn baiti.
    /// 'Right' ni yi o tọ ti o tumo si awọn ti o kẹhin ipo ti ti baiti okun;fun ede bii Arabic tabi Heberu ti o jẹ 'ọtun si osi' dipo 'osi si ọtun', eyi yoo jẹ ẹgbẹ _left_, kii ṣe ẹtọ.
    ///
    ///
    /// # Examples
    ///
    /// Awọn ilana ti o rọrun:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Àpẹẹrẹ ti eka diẹ sii, ni lilo pipade kan:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Mu awọn nkan gige okun yii pọ si oriṣi miiran.
    ///
    /// Nitori `parse` jẹ gbogbogbo, o le fa awọn iṣoro pẹlu irufẹ irufẹ.
    /// Bi iru, `parse` jẹ ọkan ninu awọn diẹ igba ti o yoo ri awọn sintasi affectionately mọ bi awọn 'turbofish': `::<>`.
    ///
    /// Eyi ṣe iranlọwọ fun algorithm ifitonileti ye ni pataki iru iru ti o n gbiyanju lati sọ sinu.
    ///
    /// `parse` le parse sinu eyikeyi iru ti alailewu awọn [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Yoo pada [`Err`] ti ko ba ṣee ṣe lati ṣe iyọ pẹlẹbẹ okun yii sinu iru ti o fẹ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Lilo 'turbofish' dipo ṣiṣe alaye `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Aise lati parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Awọn iṣayẹwo ti gbogbo awọn kikọ ninu okun yii ba wa laarin ibiti ASCII wa.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // A le ṣe itọju baiti kọọkan gẹgẹ bi ohun kikọ nibi: gbogbo awọn ohun kikọ multibyte bẹrẹ pẹlu baiti kan ti ko si ni ibiti o wa ni tito, nitorina a yoo da sibẹ sibẹ.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Sọwedowo meji awọn gbolohun ọrọ wa ni ohun ASCII irú-insensitive baramu.
    ///
    /// Kanna bi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ṣugbọn laisi ipin ati didaakọ awọn igba aye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Awọn yi okun si awọn oniwe-ASCII oke nla deede ni-ibi.
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati da iye tuntun ti oke pada laisi iyipada eyi ti o wa, lo [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // Aabo: ailewu nitori a ṣe transmute awọn oriṣi meji pẹlu ipilẹ kanna.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Iyipada okun yii si ipo ASCII kekere ti o jẹ deede ni ipo.
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati pada titun kan lowercased iye lai iyipada awọn ti wa tẹlẹ ọkan, lo [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // Aabo: ailewu nitori a ṣe transmute awọn oriṣi meji pẹlu ipilẹ kanna.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Pada aṣetunṣe kan ti o sa asala kọọkan ni `self` pẹlu [`char::escape_debug`].
    ///
    ///
    /// Note: nikan awọn koko koodu grapheme ti o gbooro ti o bẹrẹ okun yoo sa asaala.
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Pada aṣetunṣe kan ti o sa asala kọọkan ni `self` pẹlu [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Pada aṣetunṣe kan ti o sa asala kọọkan ni `self` pẹlu [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Gẹgẹbi aṣetunṣe:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Lilo `println!` taara:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Mejeji jẹ deede si:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Lilo `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Ṣẹda ohun ṣofo str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ṣẹda ohun ṣofo iyipada str
    #[inline]
    fn default() -> Self {
        // Aabo: Okun ofo jẹ wulo UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Orukọ orukọ kan, iru fn oniye
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // Aabo: kii ṣe ailewu
        unsafe { from_utf8_unchecked(bytes) }
    };
}