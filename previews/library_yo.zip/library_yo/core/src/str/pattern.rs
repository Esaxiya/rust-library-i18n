//! API Apẹẹrẹ okun.
//!
//! Apẹẹrẹ API pese ilana jeneriki fun lilo awọn oriṣi awọn apẹẹrẹ nigba wiwa nipasẹ okun kan.
//!
//! Fun awọn alaye diẹ sii, wo traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ati [`DoubleEndedSearcher`].
//!
//! Botilẹjẹpe API yii jẹ riru, o farahan nipasẹ awọn API idurosinsin lori iru [`str`].
//!
//! # Examples
//!
//! [`Pattern`] jẹ [implemented][pattern-impls] ninu API idurosinsin fun [`&str`][`str`], [`char`], awọn ege ti [`char`], ati awọn iṣẹ ati awọn pipade imuse `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // apẹẹrẹ char
//! assert_eq!(s.find('n'), Some(2));
//! // ege ti chars Àpẹẹrẹ
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // Àpẹẹrẹ bíbo
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Àpẹẹrẹ okun kan.
///
/// A `Pattern<'a>` ṣalaye pe iru imuṣe le ṣee lo bi apẹẹrẹ okun fun wiwa ni [`&'a str`][str] kan.
///
/// Fun apẹẹrẹ, `'a'` ati `"aa"` jẹ awọn ilana ti yoo baamu ni itọka `1` ninu okun `"baaaab"`.
///
/// trait funrararẹ ṣe bi akọle fun iru [`Searcher`] ti o ni ibatan, eyiti o ṣe iṣẹ gangan ti wiwa awọn iṣẹlẹ ti apẹẹrẹ ni okun kan.
///
///
/// O da lori iru apẹẹrẹ, ihuwasi awọn ọna bii [`str::find`] ati [`str::contains`] le yipada.
/// Tabili ti o wa ni isalẹ ṣe apejuwe diẹ ninu awọn ihuwasi wọnyẹn.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Oluwadi ti o somọ fun apẹẹrẹ yii
    type Searcher: Searcher<'a>;

    /// Ṣe oluwadi ti o ni nkan lati `self` ati `haystack` lati wa inu.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Awọn iṣayẹwo boya apẹẹrẹ baamu nibikibi ninu koriko
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Awọn iṣayẹwo boya apẹẹrẹ baamu ni iwaju koriko koriko
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Awọn iṣayẹwo boya apẹẹrẹ baamu ni ẹhin koriko koriko
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Yọ apẹẹrẹ kuro ni iwaju koriko, ti o ba baamu.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // Aabo: A mọ `Searcher` lati da awọn atọka to wulo pada.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Yọ awọn Àpẹẹrẹ lati pada ti haystack, ti o ba ti o ibaamu.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // Aabo: A mọ `Searcher` lati da awọn atọka to wulo pada.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Abajade ti pipe [`Searcher::next()`] tabi [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Ṣe afihan pe a ti rii ibaramu ti apẹẹrẹ ni `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Ṣe afihan pe a ti kọ `haystack[a..b]` bi ibaamu ti ṣee ṣe ti apẹẹrẹ.
    ///
    /// Akiyesi pe o le wa `Reject` ju ọkan lọ laarin `Match`es meji, ko si ibeere fun wọn lati ni idapo si ọkan.
    ///
    ///
    Reject(usize, usize),
    /// Ṣe afihan pe gbogbo baiti ti koriko koriko ti bẹwo, pari ipari aṣetunṣe.
    ///
    Done,
}

/// Oluwadi kan fun apẹẹrẹ okun.
///
/// trait yii n pese awọn ọna fun wiwa fun awọn ere-kere ti kii ṣe agbekọja ti apẹẹrẹ ti o bẹrẹ lati iwaju (left) ti okun kan.
///
/// Yoo ṣe imuse nipasẹ awọn iru `Searcher` ti o ni ibatan ti [`Pattern`] trait.
///
/// The trait ti wa ni samisi lewu nitori awọn iwon pada nipa awọn [`next()`][Searcher::next] ọna ti wa ni ti a beere lati luba on wulo utf8 aala ni haystack.
/// Eyi n jẹ ki awọn alabara ti trait yii lati ge koriko koriko laisi awọn sọwedowo asiko asiko diẹ.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter fun okun ti o wa lati wa ninu
    ///
    /// Yoo ma pada [`&str`][str] kanna.
    fn haystack(&self) -> &'a str;

    /// Ṣe igbesẹ wiwa atẹle ti o bẹrẹ lati iwaju.
    ///
    /// - Pada [`Match(a, b)`][SearchStep::Match] ti `haystack[a..b]` baamu apẹẹrẹ.
    /// - Pada [`Reject(a, b)`][SearchStep::Reject] ti `haystack[a..b]` ko ba le ba apẹrẹ mu, paapaa apakan.
    /// - Pada [`Done`][SearchStep::Done] ti gbogbo baiti koriko koriko ba ti bẹwo.
    ///
    /// Awọn san ti [`Match`][SearchStep::Match] ati [`Reject`][SearchStep::Reject] iye soke lati kan [`Done`][SearchStep::Done] yoo ni Ìwé sakani ti o wa ni ẹgbẹ, ti kii-agbekọja, ibora ti gbogbo haystack, ati ti igbọwọle utf8 aala.
    ///
    ///
    /// Abajade [`Match`][SearchStep::Match] nilo lati ni gbogbo apẹrẹ ti o baamu, sibẹsibẹ awọn abajade [`Reject`][SearchStep::Reject] le pin si ọna lainidii ọpọlọpọ awọn ajẹkù to wa nitosi.Awọn sakani mejeeji le ni gigun odo.
    ///
    /// Gẹgẹbi apẹẹrẹ, apẹẹrẹ `"aaa"` ati koriko koriko `"cbaaaaab"` le ṣe agbejade ṣiṣan naa
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Wa abajade [`Match`][SearchStep::Match] atẹle.Wo [`next()`][Searcher::next].
    ///
    /// Kii [`next()`][Searcher::next], ko si iṣeduro pe awọn sakani ti o pada ti eyi ati [`next_reject`][Searcher::next_reject] yoo bori.
    /// Eyi yoo pada `(start_match, end_match)` pada, nibiti start_match jẹ itọka ti ibiti ere-idaraya bẹrẹ, ati pe end_match ni itọka lẹhin opin ere-idije naa.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Wa abajade [`Reject`][SearchStep::Reject] atẹle.Wo [`next()`][Searcher::next] ati [`next_match()`][Searcher::next_match].
    ///
    /// Kii [`next()`][Searcher::next], ko si iṣeduro pe awọn sakani ti o pada ti eyi ati [`next_match`][Searcher::next_match] yoo bori.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Oluwadi yiyipada fun apẹẹrẹ okun kan.
///
/// trait yii n pese awọn ọna fun wiwa fun awọn ere-kere ti kii ṣe agbekọja ti apẹẹrẹ ti o bẹrẹ lati ẹhin (right) ti okun kan.
///
/// Yoo ṣe imuse nipasẹ awọn iru [`Searcher`] ti o ni ibatan ti [`Pattern`] trait ti apẹẹrẹ ba ṣe atilẹyin wiwa fun lati ẹhin.
///
///
/// Ko nilo awọn sakani atọka ti trait yii da pada lati baamu deede ti iṣawari wiwa ni idakeji.
///
/// Fun awọn idi idi ti yi trait ni samisi lewu, ri wọn obi trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Ṣe igbesẹ wiwa atẹle ti o bẹrẹ lati ẹhin.
    ///
    /// - Pada [`Match(a, b)`][SearchStep::Match] ti `haystack[a..b]` baamu apẹẹrẹ.
    /// - Pada [`Reject(a, b)`][SearchStep::Reject] ti `haystack[a..b]` ko ba le ba apẹrẹ mu, paapaa apakan.
    /// - Pada [`Done`][SearchStep::Done] ti gbogbo baiti koriko koriko ba ti bẹwo
    ///
    /// Awọn san ti [`Match`][SearchStep::Match] ati [`Reject`][SearchStep::Reject] iye soke lati kan [`Done`][SearchStep::Done] yoo ni Ìwé sakani ti o wa ni ẹgbẹ, ti kii-agbekọja, ibora ti gbogbo haystack, ati ti igbọwọle utf8 aala.
    ///
    ///
    /// Abajade [`Match`][SearchStep::Match] nilo lati ni gbogbo apẹrẹ ti o baamu, sibẹsibẹ awọn abajade [`Reject`][SearchStep::Reject] le pin si ọna lainidii ọpọlọpọ awọn ajẹkù to wa nitosi.Awọn sakani mejeeji le ni gigun odo.
    ///
    /// Gẹgẹbi apẹẹrẹ, apẹẹrẹ `"aaa"` ati koriko haystii `"cbaaaaab"` le ṣe agbejade ṣiṣan `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Nwa awọn nigbamii ti [`Match`][SearchStep::Match] esi.
    /// Wo [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Wa abajade [`Reject`][SearchStep::Reject] ti o tẹle.
    /// Wo [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Aami trait lati ṣafihan pe [`ReverseSearcher`] kan le ṣee lo fun imuse [`DoubleEndedIterator`].
///
/// Fun eyi, impl ti [`Searcher`] ati [`ReverseSearcher`] nilo lati tẹle awọn ipo wọnyi:
///
/// - Gbogbo awọn abajade ti `next()` nilo lati jẹ aami kanna si awọn abajade ti `next_back()` ni aṣẹ yiyipada.
/// - `next()` ati `next_back()` nilo lati huwa bi awọn opin meji ti iye awọn iye kan, iyẹn ni pe wọn ko le "walk past each other".
///
/// # Examples
///
/// `char::Searcher` ni a `DoubleEndedSearcher` nitori wiwa fun a [`char`] nikan nbeere nwa ni ọkan ni akoko kan, eyi ti o huwa kanna lati mejeji pari.
///
/// `(&str)::Searcher` ti a ko ti a `DoubleEndedSearcher` nitori awọn Àpẹẹrẹ `"aa"` ni haystack `"aaa"` ibaamu bi boya `"[aa]a"` tabi `"a[aa]"`, ti o da lati eyi ti o ti wa ni ẹgbẹ wá.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl fun char
/////////////////////////////////////////////////////////////////////////////

/// Iru iru si `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ailewu ailaabo: `finger`/`finger_back` gbọdọ jẹ ijẹrisi baiti utf8 to wulo ti `haystack` Ailera yii le fọ *laarin* next_match ati next_match_back, sibẹsibẹ wọn gbọdọ jade pẹlu awọn ika ọwọ lori awọn aala aaye koodu to wulo.
    //
    //
    /// `finger` ni itọka baiti lọwọlọwọ ti iṣawari siwaju.
    /// Foju inu wo pe o wa ṣaaju baiti ni itọka rẹ, ie
    /// `haystack[finger]` ni akọkọ baiti ti awọn bibẹ a gbọdọ ayewo nigba siwaju Nwa
    ///
    finger: usize,
    /// `finger_back` jẹ itọka baiti lọwọlọwọ ti wiwa yiyipada.
    /// Fojuinu wipe o wa lẹhin ti awọn baiti ni awọn oniwe-Ìwé, ie
    /// haystack [finger_back, 1] jẹ baiti ti o kẹhin ti ege ti a gbọdọ ṣe ayẹwo lakoko wiwa siwaju (ati nitorinaa baiti akọkọ lati ṣe ayewo nigbati o pe next_back()).
    ///
    finger_back: usize,
    /// Ohun kikọ ti a wa fun
    needle: char,

    // ailewu ailopin: `utf8_size` gbọdọ jẹ kere ju 5
    /// Nọmba awọn baiti `needle` gba nigba ti o yipada ni utf8.
    utf8_size: usize,
    /// A utf8 ti yipada daakọ ti `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // Aabo: 1-4 aabo aabo ti `get_unchecked`
        // 1. `self.finger` ati `self.finger_back` wa ni titọju lori awọn aala unicode (eyi ko ni iyipada)
        // 2. `self.finger >= 0` niwon o bẹrẹ ni 0 ati pe o pọ si nikan
        // 3. `self.finger < self.finger_back` nitori bibẹkọ ti char `iter` yoo da `SearchStep::Done` pada
        // 4.
        // `self.finger` wa ṣaaju opin ti haystack nitori `self.finger_back` bẹrẹ ni ipari o dinku nikan
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ṣafikun aiṣedeede baiti ti ohun kikọ lọwọlọwọ lai ṣe aiyipada bi utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // gba koriko lẹhin ohun kikọ ti o kẹhin ti a rii
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // baiti ti o kẹhin ti abẹrẹ koodu utf8 Aabo: A ni iyipada kan ti `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Awọn titun ika ni awọn Ìwé ti awọn baiti a ri, plus ọkan, niwon a memchr'd fun awọn ti o kẹhin baiti ti awọn kikọ silẹ.
                //
                // Ṣe akiyesi pe eyi kii ṣe fun wa nigbagbogbo ika lori aala UTF8.
                // Ti a ko ba rii * iwa wa a le ti tọka si baiti ti kii ṣe kẹhin ti ohun kikọ 3-baiti tabi 4-baiti kan.
                // A ko le foju si baiti bibẹrẹ ti o wulo t`okan nitori ohun kikọ bii ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` yoo jẹ ki a wa baiti keji nigbagbogbo nigbati o n wa ẹkẹta.
                //
                //
                // Sibẹsibẹ, eyi dara dara.
                // Nigba ti a ba ni ko baramu ti self.finger jẹ lori a UTF8 ala, yi ko baramu ti a ko ti gbarale lori laarin yi ọna (o ti wa ni gbarale lori ni CharSearcher::next()).
                //
                // A jade ni ọna yii nikan nigbati a de opin okun, tabi ti a ba ri nkan.Nigba ti a ba rii nkan ti `finger` yoo ṣeto si aala UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ko ri nkankan, jade
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // jẹ ki next_reject lo imuse aiyipada lati Oluwadi trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // Aabo: wo asọye fun next() loke
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // iyokuro baiti aiṣedeede ti ohun kikọ lọwọlọwọ laisi aiyipada bi utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // gba koriko soke si ṣugbọn kii ṣe pẹlu iwa ti o kẹhin ti a wa
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // baiti ti o kẹhin ti abẹrẹ koodu utf8 Aabo: A ni iyipada kan ti `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // a wa nkan ti o jẹ aiṣedeede nipasẹ self.finger, ṣafikun self.finger lati ṣe atunṣe atokọ atilẹba
                //
                let index = self.finger + index;
                // memrchr yoo da atọka ti baiti ti a fẹ lati wa pada.
                // Ni ọran ti ohun kikọ ASCII, eyi jẹ otitọ ni a fẹ ki ika tuntun wa ("after" apẹrẹ ti a rii ninu apẹrẹ ti aṣetunṣe iyipada).
                //
                // Fun awọn chars multibyte a nilo lati fo si isalẹ nipasẹ nọmba ti awọn baiti diẹ ti wọn ni ju ASCII lọ
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // gbe ika si ohun kikọ ti a rii (ie, ni itọka ibẹrẹ rẹ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // A ko le lo finger_back=itọka, iwọn + 1 nibi.
                // Ti a ba ri awọn ti o kẹhin shaha kan ti o yatọ-won ti ohun kikọ silẹ (tabi arin baiti kan ti a ti o yatọ si ohun kikọ silẹ) ti a nilo lati ijalu awọn finger_back si isalẹ lati `index`.
                // Eleyi bakanna mu `finger_back` ni o pọju lati ko si ohun to wa lori a ààlà, ṣugbọn yi ni dara niwon a nikan jade yi iṣẹ lori kan ala tabi nigbati awọn haystack ti wá patapata.
                //
                //
                // Ko next_match yi ko ni ni awọn isoro ti tun baiti ni utf-8 nitori ti a ba Nwa fun awọn ti o kẹhin baiti, ati awọn ti a le nikan ti ri awọn ti o kẹhin baiti nigbati wiwa ni ọna.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ko ri nkankan, jade
                return None;
            }
        }
    }

    // jẹ ki next_reject_back lo imuse aiyipada lati Oluwadi trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Awọn wiwa fun awọn chars ti o dọgba pẹlu [`char`] ti a fun.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl fun ohun elo MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Ṣe afiwe awọn gigun ti aṣetun nkan bibẹrẹ ti abẹnu lati wa ipari ti oriṣi lọwọlọwọ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Ṣe afiwe awọn gigun ti aṣetun nkan bibẹrẹ ti abẹnu lati wa ipari ti oriṣi lọwọlọwọ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl fun&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Yi/Yọ nitori aibikita ni itumọ.

/// Iru iru si `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Awọn iwadii fun awọn chars ti o dọgba pẹlu eyikeyi ti [`char`] s ninu ege.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl fun F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Iru iru si `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Awọn wiwa fun [`char`] ti o ba asọtẹlẹ ti a fun mu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl fun&&str
/////////////////////////////////////////////////////////////////////////////

/// Awọn aṣoju si `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl fun &str
/////////////////////////////////////////////////////////////////////////////

/// Non-allocating substring search.
///
/// Yoo mu apẹrẹ `""` bii pipadabọ awọn ere-kere ofo ni aala ohun kikọ kọọkan.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Awọn iṣayẹwo boya apẹẹrẹ baamu ni iwaju koriko koriko.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Yọ apẹẹrẹ kuro ni iwaju koriko, ti o ba baamu.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // Aabo: ìpele a ti o kan wadi lati tẹlẹ.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Awọn iṣayẹwo boya apẹẹrẹ baamu ni ẹhin koriko koriko.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Yọ awọn Àpẹẹrẹ lati pada ti haystack, ti o ba ti o ibaamu.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // Aabo: suffix kan jẹrisi lati wa tẹlẹ.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Oluwadi wiwa ọna meji
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Ni nkan Iru fun `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // abẹrẹ ofo kọ gbogbo char ati ibaamu gbogbo okun ofo laarin wọn
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ṣe agbekalẹ awọn atọka *Baramu* ti o wulo ti o pin ni awọn aala adaṣe niwọn igba ti o ba ṣe deede ti o baamu ati pe koriko ati abẹrẹ wulo UTF-8 *Awọn kọ* lati algorithm le ṣubu lori awọn atọka eyikeyi, ṣugbọn a yoo rin wọn pẹlu ọwọ si aala ohun kikọ atẹle, ki wọn jẹ ailewu utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // foo si aala char ti nbo
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // kọ awọn ọrọ `true` ati `false` jade lati ṣe iwuri fun akopọ lati ṣe pataki awọn ọran meji lọtọ.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // foo si aala char ti nbo
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // kọ jade `true` ati `false`, bi `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Ipo inu ti algorithm wiwa ọna-ọna ọna meji.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// atọka ifosiwewe ifosiwewe
    crit_pos: usize,
    /// lominu ni factorization Ìwé fun ifasilẹ awọn abẹrẹ
    crit_pos_back: usize,
    period: usize,
    /// `byteset` jẹ ẹya itẹsiwaju (ko ara ti awọn meji ọna alugoridimu);
    /// o ni a 64-bit "fingerprint" ibi ti kọọkan ti ṣeto si bù `j` ibamu si a (baiti&63)==j bayi ni abẹrẹ.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// atọka sinu abẹrẹ ṣaaju eyi ti a ti baamu tẹlẹ
    memory: usize,
    /// atọka sinu abẹrẹ lẹhin eyi ti a ti baamu tẹlẹ
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Alaye ti a le ka ni pataki ti ohun ti n lọ nibi ni a le rii ninu iwe Crochemore ati iwe Rytter "Text Algorithms", ch 13.
        // Ni pato wo koodu fun "Algorithm CP" lori p.
        // 323.
        //
        // Ohun ti n lọ lori ni a ni diẹ ninu awọn lominu ni factorization (u, v) ti awọn abẹrẹ, ati awọn ti a fẹ lati mo boya u ni a suffix ti&v [.. akoko].
        // Ti o ba jẹ bẹ, a lo "Algorithm CP1".
        // Tabi ki a lo "Algorithm CP2", eyi ti o wa ni iṣapeye fun nigbati awọn akoko ti awọn abẹrẹ ni o tobi.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ọran igba kukuru-asiko naa jẹ iṣiro to ṣe deede ifosiwewe to ṣe pataki lọtọ fun abẹrẹ yiyipada x=u 'v' nibo | v '|<period(x).
            //
            // Eyi ni iyara nipasẹ akoko ti a mọ tẹlẹ.
            // Akiyesi pe ọrọ bii x= "acba" le ni ifosiwewe ni iwaju siwaju (crit_pos=1, akoko=3) lakoko ti a ba n ṣalaye pẹlu akoko isunmọ ni idakeji (crit_pos=2, akoko=2).
            // A lo ifosiwewe yiyipada ti a fun ṣugbọn tọju akoko deede.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ọran igba pipẹ-a ni isunmọ si akoko gangan, ati maṣe lo iranti.
            //
            //
            // Isunmọ asiko naa nipa owun max(|u|, |v|) + 1.
            // Ifosiwewe pataki jẹ ṣiṣe lati lo fun mejeeji siwaju ati wiwa yiyipada.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Iye idinwin lati ṣe afihan pe asiko naa gun
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Ọkan ninu awọn imọran akọkọ ti Ọna Meji ni pe a ṣe ifosiwewe abẹrẹ naa si halves meji, (u, v), ati bẹrẹ igbiyanju lati wa v ninu koriko nipasẹ ọlọjẹ osi si ọtun.
    // Ti o ba ti v-kere, a gbiyanju lati baramu u nipa Antivirus si ọtun lati osi.
    // Bi o ṣe le pẹ to ti a le fo nigba ti a ba pade aiṣedeede jẹ gbogbo eyiti o da lori otitọ pe (u, v) jẹ ifosiwewe to ṣe pataki fun abẹrẹ naa.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` nlo `self.position` bi awọn oniwe-ikọrisi
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Ṣayẹwo pe a ni yara lati wa ni ipo + needle_last ko le kún ti o ba ti a ba ro ege ti wa ni didi nipa isize ká ibiti o.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Ni kiakia foju nipasẹ awọn ipin nla ti ko ni ibatan si sisopọ wa
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Ri ti o ba awọn ọtun apa ti awọn abẹrẹ-kere
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Ri ti o ba osi apa ti awọn abẹrẹ-kere
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // A ti rii ibaramu kan!
            let match_pos = self.position;

            // Note: fi self.period dipo ti needle.len() lati ni agbekọja-kere
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ṣeto si needle.len(), self.period fun awọn ere fifo
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Tẹle awọn imọran ni `next()`.
    //
    // Awọn itumọ jẹ iṣiro, pẹlu period(x) = period(reverse(x)) ati local_period(u, v) = local_period(reverse(v), reverse(u)), nitorinaa ti (u, v) jẹ ifosiwewe to ṣe pataki, bẹ naa (reverse(v), reverse(u)).
    //
    //
    // Fun ọran ti a ti ṣe iṣiro ifosiwewe pataki x=u 'v' (aaye `crit_pos_back`).A nilo | u |<period(x) fun ọran siwaju ati bayi | v '|<period(x) fun yiyipada.
    //
    // Lati wa ni idakeji nipasẹ koriko koriko, a wa siwaju nipasẹ haystack ti o yipada pẹlu abẹrẹ yiyipada, ti o baamu akọkọ u 'ati lẹhinna v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` lo `self.end` bi kọsọ rẹ-ki `next()` ati `next_back()` jẹ ominira.
        //
        let old_end = self.end;
        'search: loop {
            // Ṣayẹwo pe a ni yara lati wa ni opin, needle.len() yoo ipari si ni ayika nigba ti o wa ni ko si siwaju sii yara, ṣugbọn nitori bibẹ ipari ifilelẹ ti o le ko fi ipari gbogbo ọna pada sinu awọn ipari ti haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Ni kiakia foju nipasẹ awọn ipin nla ti ko ni ibatan si sisopọ wa
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Ri ti o ba osi apa ti awọn abẹrẹ-kere
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Ri ti o ba awọn ọtun apa ti awọn abẹrẹ-kere
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // A ti rii ibaramu kan!
            let match_pos = self.end - needle.len();
            // Note: iha self.period dipo ti needle.len() lati ni agbekọja-kere
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ṣe iṣiro suffix ti o pọ julọ ti `arr`.
    //
    // Ipele ti o pọ julọ jẹ ifosiwewe to ṣe pataki lo ṣee ṣe (u, v) ti `arr`.
    //
    // Awọn ipadabọ (`i`, `p`) nibiti `i` jẹ itọka ibẹrẹ ti v ati `p` jẹ akoko ti v.
    //
    // `order_greater` ipinnu ti o ba lexical ibere ni `<` tabi `>`.
    // Mejeeji ibere gbọdọ wa ni se isiro-awọn bere pẹlu awọn ti `i` yoo kan lominu ni factorization.
    //
    //
    // Fun awọn ọran igba pipẹ, akoko abajade ko ṣe deede (o kuru ju).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Ni ibamu si i ninu iwe naa
        let mut right = 1; // Ni ibamu to j ninu iwe
        let mut offset = 0; // Ni ibamu si k ninu iwe, ṣugbọn bẹrẹ ni 0
        // lati baamu titọka-orisun 0.
        let mut period = 1; // Ni ibamu to p ninu iwe

        while let Some(&a) = arr.get(right + offset) {
            // `left` yoo wa ni awọn inbounds nigbati `right` jẹ.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix jẹ kere, akoko ni gbogbo ìpele bẹ jina.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ilọsiwaju nipasẹ atunwi ti akoko lọwọlọwọ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix tobi, bẹrẹ lati ipo lọwọlọwọ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Ṣe iṣiro suffix ti o pọ julọ ti yiyipada `arr`.
    //
    // Awọn kundori suffix ni a ti ṣee ṣe lominu ni factorization (u ', v') ti `arr`.
    //
    // Pada `i` nibi ti `i` jẹ itọka ibẹrẹ ti v ', lati ẹhin;
    // pada lẹsẹkẹsẹ nigbati akoko kan ti `known_period` ba de.
    //
    // `order_greater` ipinnu ti o ba lexical ibere ni `<` tabi `>`.
    // Mejeeji ibere gbọdọ wa ni se isiro-awọn bere pẹlu awọn ti `i` yoo kan lominu ni factorization.
    //
    //
    // Fun awọn ọran igba pipẹ, akoko abajade ko ṣe deede (o kuru ju).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Ni ibamu si i ninu iwe naa
        let mut right = 1; // Ni ibamu to j ninu iwe
        let mut offset = 0; // Ni ibamu si k ninu iwe, ṣugbọn bẹrẹ ni 0
        // lati baamu titọka-orisun 0.
        let mut period = 1; // Ni ibamu to p ninu iwe
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix jẹ kere, akoko ni gbogbo ìpele bẹ jina.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Ilọsiwaju nipasẹ atunwi ti akoko lọwọlọwọ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix tobi, bẹrẹ lati ipo lọwọlọwọ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy gba awọn alugoridimu to boya foju ti kii-ere-kere bi yarayara bi o ti ṣee, tabi lati ise ni a mode ibi ti o ti ipele kọ jo ni kiakia.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Rekọja si baramu arin ni yarayara bi o ti ṣee
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit Kọ ni igbagbogbo
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}