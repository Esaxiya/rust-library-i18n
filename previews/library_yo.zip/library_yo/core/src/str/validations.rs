//! Awọn iṣẹ ti o ni ibatan si afọwọsi UTF-8.

use crate::mem;

use super::Utf8Error;

/// Padapo ikojọpọ koodu koodu akọkọ fun baiti akọkọ.
/// Baiti akọkọ jẹ pataki, nikan fẹ isalẹ awọn idinku 5 fun iwọn 2, awọn idinku 4 fun iwọn 3, ati awọn idinku 3 fun iwọn 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Pada iye ti `ch` imudojuiwọn pẹlu itesiwaju baiti `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Awọn iṣayẹwo boya baiti jẹ baiti itesiwaju UTF-8 (ie, bẹrẹ pẹlu awọn gige `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Say awọn nigbamii ti koodu ojuami jade ti a baiti iterator (ro a UTF-8-bi aiyipada).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Yiyipada UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Ọran Multibyte tẹle Iyipada lati apapo baiti kan lati: [[[x y] z] w]
    //
    // NOTE: Išẹ jẹ kókó si awọn gangan agbese nibi
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] nla
        // 5th bit ni 0xE0 .. 0xEF jẹ kedere nigbagbogbo, nitorinaa `init` tun wulo
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ọran lo nikan awọn idinku 3 kekere ti `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Say awọn ti o kẹhin koodu ojuami jade ti a baiti iterator (ro a UTF-8-bi aiyipada).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Yiyipada UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Ọran Multibyte tẹle Iyipada lati apapo baiti kan lati: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// lo isokuso lati ba u64 mu si lilo
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Pada `true` o ba ti eyikeyi baiti ninu awọn ọrọ `x` ni nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Rin nipasẹ `v` yiyewo pe o jẹ ọna UTF-8 to wulo, ti o pada `Ok(())` ni ọran yẹn, tabi, ti ko ba wulo, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // a nilo data, ṣugbọn kò si ẹnikan: aṣiṣe!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Fifi koodu baiti jẹ fun awọn akọjọ koodu\u {0080} si\u {07ff} akọkọ C2 80 DF BF ti o kẹhin
            // 3-byte encoding jẹ fun awọn akọjọ koodu\u {0800} si\u {ffff} akọkọ E0 A0 80 ikẹhin EF BF BF laisi awọn koodu ifisipo awọn iṣẹ\u {d800} si\u {dfff} ED A0 80 si ED BF BF
            // Ifitonileti baiti 4 jẹ fun awọn ami-koodu\u {1000} 0 si\u {10ff} ff akọkọ F0 90 80 80 kẹhin F4 8F BF BF
            //
            // Lo sintasi UTF-8 lati RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-iru UTF8-3= %xE0% xA0-BF UTF8-iru/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-iru/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ọran Ascii, gbiyanju lati foju siwaju ni kiakia.
            // Nigbati o ba tọka, ka awọn ọrọ 2 data fun aṣetunṣe titi ti a yoo fi rii ọrọ kan ti o ni baiti ti kii ṣe ascii.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // Aabo: niwon `align - index` ati `ascii_block_size` jẹ
                    // ọpọlọpọ awọn ti `usize_bytes`, `block = ptr.add(index)` ti wa ni deede ni ibamu pẹlu `usize` nitorinaa o jẹ ailewu si ifagile mejeeji `block` ati `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // adehun ba ti wa ni a nonascii baiti
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // igbesẹ lati aaye ibi ti iṣu ọrọ ọrọ duro
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Ti a fun ni baiti akọkọ, ṣe ipinnu iye awọn baiti ti o wa ninu iwa UTF-8 yii.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Ipara ti awọn iye iye ti baiti itesiwaju.
const CONT_MASK: u8 = 0b0011_1111;
/// Iye ti awọn tag die-die (tag boju ni !CONT_MASK) ti a itesiwaju baiti.
const TAG_CONT_U8: u8 = 0b1000_0000;

// truncate `&str` si ipari ni deede dogba si `max` pada `true` ti o ba ti ge, ati str tuntun.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}