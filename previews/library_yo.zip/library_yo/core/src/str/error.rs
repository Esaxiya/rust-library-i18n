//! Awọn asọye iru aṣiṣe utf8.

use crate::fmt;

/// Awọn aṣiṣe eyiti o le waye nigbati o n gbiyanju lati tumọ itumọ ti [`u8`] bi okun.
///
/// Bi iru, awọn `from_utf8` ebi ti awọn iṣẹ ati awọn ọna fun awọn mejeeji [`String`] s ati [`&str`] s Rii lilo ti yi aṣiṣe, fun apẹẹrẹ.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Awọn ọna iru aṣiṣe yii le ṣee lo lati ṣẹda iṣẹ ti o jọra si `String::from_utf8_lossy` laisi ipin iranti okiti:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Pada itọka ninu okun ti a fun soke eyiti eyiti o jẹrisi UTF-8 ti o wulo.
    ///
    /// O jẹ itọka ti o pọ julọ bii pe `from_utf8(&input[..index])` yoo da `Ok(_)` pada.
    ///
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// use std::str;
    ///
    /// // diẹ ninu awọn baiti ti ko wulo, ni vector kan
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 pada a Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // baiti keji ko wulo nibi
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Pese alaye diẹ sii nipa ikuna naa:
    ///
    /// * `None`: opin igbewọle ti de lairotele.
    ///   `self.valid_up_to()` jẹ 1 si 3 baiti lati opin titẹ sii.
    ///   Ti ṣiṣan baiti kan (bii faili kan tabi iho nẹtiwọọki kan) ti wa ni kikọ ni afikun, eyi le jẹ `char` ti o wulo eyiti ọkọọkan baiti UTF-8 n ṣe awọn ọpọ awọn ege pupọ.
    ///
    ///
    /// * `Some(len)`: baiti airotẹlẹ ti pade.
    ///   Gigun ti a pese ni ti ọkọọkan baiti ti ko wulo ti o bẹrẹ ni itọka ti `valid_up_to()` fun.
    ///   Imọ-yẹ ki o pada lẹhin ti ọkọọkan (lẹhin ti sii a [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ni irú ti lossy imọ-.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Aṣiṣe kan pada nigbati sisọ `bool` kan nipa lilo [`from_str`] kuna
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}