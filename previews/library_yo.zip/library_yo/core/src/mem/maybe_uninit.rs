use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Iru aṣọ wiwọ kan lati kọ awọn iṣẹlẹ ailakọkọ ti `T`.
///
/// # Initialization ko baramu
///
/// Awọn alakojo, ni apapọ, dawọle ti a ayípadà wa ni daradara initialized gẹgẹ bi awọn ibeere ti ayípadà ká iru.Fun apẹẹrẹ, a ayípadà of itọkasi iru gbọdọ wa ni deedee ati ti kii-NULL.
/// Eleyi jẹ ẹya ko baramu ti o gbọdọ *nigbagbogbo* wa ni ọwọ si, ani ni lewu koodu.
/// Bi awọn kan Nitori, odo-initializing a ayípadà of itọkasi iru fa instantaneous [undefined behavior][ub], ko si boya ti itọkasi lailai olubwon lo lati wọle si iranti:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ihuwasi ti a ko ṣalaye!⚠️
/// // Awọn deede koodu pẹlu `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ihuwasi ti a ko ṣalaye!⚠️
/// ```
///
/// Eyi ni a yanturu nipasẹ awọn alakojo fun orisirisi optimizations, gẹgẹ bi awọn eliding run-akoko sọwedowo ati silẹ `enum` akọkọ.
///
/// Bakan naa, iranti ailopin patapata le ni eyikeyi akoonu, lakoko ti `bool` kan gbọdọ jẹ `true` tabi `false` nigbagbogbo.Nitorinaa, ṣiṣẹda `bool` ti ko ni oye jẹ ihuwasi ti a ko ṣalaye:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ihuwasi ti a ko ṣalaye!⚠️
/// // Awọn deede koodu pẹlu `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ihuwasi ti a ko ṣalaye!⚠️
/// ```
///
/// Jubẹlọ, uninitialized iranti jẹ pataki ni wipe o ko ni ni a ti o wa titi iye ("fixed" afipamo "it won't change without being written to").Kika awọn kanna uninitialized baiti ọpọ igba le fun o yatọ si awọn esi.
/// Eyi jẹ ki ihuwasi ti a ko ṣalaye lati ni data ti ko ni oye ninu oniyipada paapaa ti oniyipada yẹn ni iru odidi odidi kan, eyiti bibẹkọ ti le mu eyikeyi apẹẹrẹ *ti o wa titi*
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ihuwasi ti a ko ṣalaye!⚠️
/// // Awọn deede koodu pẹlu `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ihuwasi ti a ko ṣalaye!⚠️
/// ```
/// (Akiyesi pe awọn ofin ni ayika uninitialized odidi ko ba wa ni fipinu sibẹsibẹ, sugbon titi ti won wa, o ni ṣiṣe lati yago fun wọn.)
///
/// Lori oke ti ti, ranti wipe ọpọlọpọ awọn orisi ni afikun invariants kọja jo ni a kà initialized ni iru ipele.
/// Fun apẹẹrẹ, a `1`-initialized [`Vec<T>`] ti wa ni ka initialized (labẹ awọn ti isiyi imuse; eyi ko je a idurosinsin lopolopo) nitori awọn ibeere nikan ni alakojo mo nipa o jẹ wipe awọn data ijuboluwole gbọdọ jẹ ti kii-asan.
/// Ṣiṣẹda iru `Vec<T>` yii ko fa *lẹsẹkẹsẹ* ihuwasi ti a ko ṣalaye, ṣugbọn yoo fa ihuwasi aisọye pẹlu awọn iṣiṣẹ to ni aabo julọ (pẹlu fifisilẹ rẹ).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ṣe iṣẹ lati jẹki koodu ti ko ni aabo lati ba data ti a ko mọ.
/// O jẹ ifihan agbara si alakojo n tọka pe data nibi le *ma* ṣe ipilẹṣẹ:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Ṣẹda ohun kedere uninitialized itọkasi.
/// // Awọn alakojo mọ pé data inu a `MaybeUninit<T>` le jẹ invalid, ati ki o nibi yi ni ko UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Ṣeto ti o si a wulo iye.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Fa data ti a ṣe jade-eyi ni a gba laaye nikan *lẹhin* ipilẹṣẹ daradara `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Awọn alakojo ki o si mọ lati ko ṣe eyikeyi ti ko tọ awqn tabi optimizations lori yi koodu.
///
/// O le ronu ti `MaybeUninit<T>` bi pe o dabi bit bi `Option<T>` ṣugbọn laisi eyikeyi titele-akoko ṣiṣe ati laisi eyikeyi awọn sọwedowo aabo.
///
/// ## out-pointers
///
/// O le lo `MaybeUninit<T>` lati se "out-pointers": dipo ti pada data lati kan iṣẹ, ṣe o kan ijuboluwole si diẹ ninu awọn (uninitialized) iranti lati fi awọn esi sinu.
/// Yi le jẹ wulo nigba ti o jẹ pataki fun awọn olupe to iṣakoso bi iranti awọn esi ti wa ni fipamọ ni olubwon soto, ati awọn ti o fẹ lati yago fun kobojumu e.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ko ni ju awọn atijọ akoonu ti, eyi ti o jẹ pataki.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Bayi a mọ `v` ti wa ni initialized!Eyi tun rii daju pe vector n silẹ daradara.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initializing ohun orun ano-nipasẹ-ano
///
/// `MaybeUninit<T>` a le lo lati initialize kan ti o tobi orun ano-nipasẹ-ano:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Ṣẹda ohun uninitialized orun ti `MaybeUninit`.
///     // The `assume_init` jẹ ailewu nitori awọn iru a ti wa ni Annabi si ti initialized nibi ni a ìdìpọ 'MaybeUninit`s, eyi ti ko beere initialization.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Sisọ awọn a `MaybeUninit` wo ni ohunkohun.
///     // Bayi ni lilo aise ijuboluwole iṣẹ dipo ti `ptr::write` ko ni fa atijọ uninitialized iye to wa ni silẹ.
/////
///     // Tun ti o ba ti wa ni kan panic nigba yi lupu, a ni a iranti jo, ṣugbọn nibẹ ni ko si iranti ailewu oro.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ohun gbogbo ti wa ni ipilẹṣẹ.
///     // Transmute awọn orun si awọn initialized iru.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// O tun le ṣiṣẹ pẹlu kan initialized imole, eyi ti o le wa ni ri ni kekere-ipele datastructures.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Ṣẹda ohun uninitialized orun ti `MaybeUninit`.
/// // The `assume_init` jẹ ailewu nitori awọn iru a ti wa ni Annabi si ti initialized nibi ni a ìdìpọ 'MaybeUninit`s, eyi ti ko beere initialization.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Ka awọn nọmba ti eroja ti a ti sọtọ.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Fun kọọkan ohun kan ninu awọn orun, ju o ba ti a soto o.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initializing a struct oko-nipasẹ-oko
///
/// O le lo `MaybeUninit<T>`, ati awọn [`std::ptr::addr_of_mut`] Makiro, to initialize structs oko nipa oko:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initializing awọn `name` oko
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initializing awọn `list` aaye Ti o ba ti wa nibẹ ni a panic nibi, ki o si awọn `String` ni `name` aaye jo.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Gbogbo awọn aaye ti wa ni initialized, ki a pe `assume_init` lati gba ohun initialized foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ti wa ni ẹri lati ni awọn iwọn kanna, titete, ati Abi bi `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Sibẹsibẹ ranti wipe a iru *ti o ni awọn* a `MaybeUninit<T>` ko jẹ kanna akọkọ;Rust wo ni ko ni apapọ lopolopo ti awọn aaye ti a `Foo<T>` ni kanna ibere bi a `Foo<U>` paapa ti o ba `T` ati `U` ni kanna iwọn ati ki o titete.
///
/// Pẹlupẹlu nitori eyikeyi iye bit wulo fun `MaybeUninit<T>` olupilẹṣẹ ko le lo awọn iṣapeye non-zero/niche-filling, eyiti o le jẹ abajade ni iwọn nla kan:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ti o ba ti `T` ni FFI-ailewu, ki o si ki o jẹ `MaybeUninit<T>`.
///
/// Nigba ti `MaybeUninit` ni `#[repr(transparent)]` (afihan ti o ṣe onigbọwọ kanna iwọn, titete, ati Abi bi `T`), yi wo ni *ko* yi eyikeyi ninu awọn ti tẹlẹ caveats.
/// `Option<T>` ati `Option<MaybeUninit<T>>` le tun ni o yatọ si titobi, ati awọn orisi ti o ni awọn a aaye ti Iru `T` le wa ni gbe jade (ati won) otooto ju ti o ba ti oko wà `MaybeUninit<T>`.
/// `MaybeUninit` jẹ iru iṣọkan kan, ati pe `#[repr(transparent)]` lori awọn awin ko ni riru (wo [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Lori akoko, awọn gangan onigbọwọ ti `#[repr(transparent)]` on awin le da, ati `MaybeUninit` le tabi ko le wa `#[repr(transparent)]`.
/// Ti o si wipe, `MaybeUninit<T>` yio *nigbagbogbo* lopolopo wipe o ni kanna iwọn, titete, ati Abi bi `T`;o ni o kan ti awọn ọna `MaybeUninit` ọlọnà pe lopolopo le da.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang ohun kan ki a le fi ipari si miiran orisi ni o.Eleyi jẹ wulo fun Generators.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ko pipe `T::clone()`, a ko le mọ ti o ba ti a ti wa initialized to fun awọn ti.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ṣẹda `MaybeUninit<T>` tuntun ti a ṣe ipilẹ pẹlu iye ti a fun.
    /// O jẹ ailewu lati pe [`assume_init`] lori pada iye ti yi iṣẹ.
    ///
    /// Akọsilẹ ti sisọ a `MaybeUninit<T>` yoo ko pe `T` ká ju koodu.
    /// O jẹ ojuṣe rẹ lati rii daju `T` olubwon silẹ ti o ba ti ni initialized.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Ṣẹda titun kan `MaybeUninit<T>` ni ohun uninitialized ipinle.
    ///
    /// Akọsilẹ ti sisọ a `MaybeUninit<T>` yoo ko pe `T` ká ju koodu.
    /// O jẹ ojuṣe rẹ lati rii daju `T` olubwon silẹ ti o ba ti ni initialized.
    ///
    /// Wo awọn [type-level documentation][MaybeUninit] fun awọn apere.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Ṣẹda ọna tuntun ti awọn ohun `MaybeUninit<T>`, ni ipo aibikita.
    ///
    /// Note: ni a future Rust ti ikede yi ọna le di kobojumu nigbati orun gegebi sintasi faye gba [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Apẹẹrẹ ti o wa ni isalẹ le lẹhinna lo `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Pada a ege o ṣee (o ṣee kere) ti a ti ka gangan
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // Aabo: An uninitialized `[MaybeUninit<_>; LEN]` jẹ wulo.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Ṣẹda titun kan `MaybeUninit<T>` ni ohun uninitialized ipinle, pẹlu awọn iranti ni kún pẹlu `0` baiti.O da lori `T` boya iyẹn ti ṣe tẹlẹ fun ipilẹṣẹ to dara.
    ///
    /// Fun apẹẹrẹ, `MaybeUninit<usize>::zeroed()` ti wa ni initialized, ṣugbọn `MaybeUninit<&'static i32>::zeroed()` ni ko nitori jo kò gbọdọ jẹ asan.
    ///
    /// Akọsilẹ ti sisọ a `MaybeUninit<T>` yoo ko pe `T` ká ju koodu.
    /// O jẹ ojuṣe rẹ lati rii daju `T` olubwon silẹ ti o ba ti ni initialized.
    ///
    /// # Example
    ///
    /// Atunse lilo ti yi iṣẹ: initializing a struct pẹlu odo, ibi ti gbogbo awọn aaye ti awọn struct le mu awọn bit-Àpẹẹrẹ 0 bi a wulo iye.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Tọ* lilo ti yi iṣẹ: pipe `x.zeroed().assume_init()` nigbati `0` ni ko kan wulo bit-Àpẹẹrẹ fun awọn Iru:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inu kan bata, a ṣẹda a `NotZero` ti o ko ni ni a wulo discriminant.
    /// // Eleyi jẹ aisọye ihuwasi.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // Aabo: `u.as_mut_ptr()` ojuami si soto iranti.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Kn iye ti awọn `MaybeUninit<T>`.
    /// Eleyi yoo kọ nkan bo eyikeyi ti tẹlẹ iye lai sisọ o, ki wa ni ṣọra ko lati lo yi lemeji ayafi ti o ba fẹ lati foju nṣiṣẹ ni destructor.
    ///
    /// Fun rẹ wewewe, yi tun pada a mutable tọka si (bayi lailewu initialized) akoonu ti ti `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // Aabo: A o kan initialized yi.
        unsafe { self.assume_init_mut() }
    }

    /// N ni ijuboluwole si iye ti o wa ninu rẹ.
    /// Kika lati yi ijuboluwole tabi titan o sinu kan itọkasi ni aisọye ihuwasi ayafi ti `MaybeUninit<T>` ti wa ni initialized.
    /// Kikọ si iranti wipe yi ijuboluwole (non-transitively) ojuami to wa ni aisọye iwa (ayafi inu ẹya `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ṣẹda itọkasi kan sinu `MaybeUninit<T>`.Eleyi jẹ dara nitori a initialized o.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Tọ* lilo ti yi ọna:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // A ti da a tọka si ohun uninitialized vector!Eleyi jẹ aisọye ihuwasi.⚠️
    /// ```
    ///
    /// (Akiyesi pe awọn ofin ni ayika jo si uninitialized data ko ba wa ni fipinu sibẹsibẹ, sugbon titi ti won wa, o ni ṣiṣe lati yago fun wọn.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ati `ManuallyDrop` o wa mejeeji `repr(transparent)` ki a le lé awọn ijuboluwole.
        self as *const _ as *const T
    }

    /// Gba ijuboluwole iyipada si iye ti o wa ninu rẹ.
    /// Kika lati yi ijuboluwole tabi titan o sinu kan itọkasi ni aisọye ihuwasi ayafi ti `MaybeUninit<T>` ti wa ni initialized.
    ///
    /// # Examples
    ///
    /// Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ṣẹda itọkasi kan sinu `MaybeUninit<Vec<u32>>`.
    /// // Eleyi jẹ dara nitori a initialized o.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Tọ* lilo ti yi ọna:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // A ti da a tọka si ohun uninitialized vector!Eleyi jẹ aisọye ihuwasi.⚠️
    /// ```
    ///
    /// (Akiyesi pe awọn ofin ni ayika jo si uninitialized data ko ba wa ni fipinu sibẹsibẹ, sugbon titi ti won wa, o ni ṣiṣe lati yago fun wọn.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ati `ManuallyDrop` o wa mejeeji `repr(transparent)` ki a le lé awọn ijuboluwole.
        self as *mut _ as *mut T
    }

    /// Ayokuro awọn iye lati `MaybeUninit<T>` eiyan.Yi ni a nla ona lati rii daju wipe awọn data yoo ri awọn silẹ, nitori awọn Abajade `T` jẹ koko ọrọ si awọn ibùgbé ju mu.
    ///
    /// # Safety
    ///
    /// O ti wa ni soke si awọn olupe to lopolopo ti awọn `MaybeUninit<T>` gan ni ni ohun initialized ipinle.Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye lẹsẹkẹsẹ.
    /// Awọn [type-level documentation][inv] ni alaye siwaju sii nipa yi initialization ko baramu.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Lori oke ti ti, ranti wipe ọpọlọpọ awọn orisi ni afikun invariants kọja jo ni a kà initialized ni iru ipele.
    /// Fun apẹẹrẹ, a `1`-initialized [`Vec<T>`] ti wa ni ka initialized (labẹ awọn ti isiyi imuse; eyi ko je a idurosinsin lopolopo) nitori awọn ibeere nikan ni alakojo mo nipa o jẹ wipe awọn data ijuboluwole gbọdọ jẹ ti kii-asan.
    ///
    /// Ṣiṣẹda iru `Vec<T>` yii ko fa *lẹsẹkẹsẹ* ihuwasi ti a ko ṣalaye, ṣugbọn yoo fa ihuwasi aisọye pẹlu awọn iṣiṣẹ to ni aabo julọ (pẹlu fifisilẹ rẹ).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Tọ* lilo ti yi ọna:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ko ti ipilẹṣẹ sibẹsibẹ, nitorinaa laini to kẹhin yii fa ihuwasi ti a ko ṣalaye.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // Aabo: awọn olupe gbọdọ lopolopo ti `self` ti wa ni initialized.
        // Eyi tun tumọ si pe `self` gbọdọ jẹ iyatọ `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Say awọn iye lati `MaybeUninit<T>` eiyan.Abajade `T` jẹ koko ọrọ si mimu silẹ deede.
    ///
    /// Nigbakugba ti o ba ṣee ṣe, o dara lati lo [`assume_init`] dipo, eyiti o ṣe idiwọ ẹda ẹda akoonu ti `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// O di si olupe lati ṣe idaniloju pe `MaybeUninit<T>` gaan wa ni ipo ipilẹṣẹ.Pipe yi nigbati awọn akoonu ti a ko ti sibẹsibẹ ni kikun initialized okunfa aisọye ihuwasi.
    /// Awọn [type-level documentation][inv] ni alaye siwaju sii nipa yi initialization ko baramu.
    ///
    /// Jubẹlọ, yi leaves a daakọ ti awọn kanna data sile ninu awọn `MaybeUninit<T>`.
    /// Nigba lilo ọpọ idaako ti awọn data (nipa pipe `assume_init_read` ọpọ igba, tabi akọkọ pipe `assume_init_read` ati ki o [`assume_init`]), o jẹ ojuṣe rẹ lati rii daju wipe ti o data ki o le nitootọ wa ni duplicated.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ni `Copy`, ki a le ka ọpọ igba.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplicating a `None` iye jẹ dara, ki a le ka ọpọ igba.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Tọ* lilo ti yi ọna:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // A bayi da meji idaako ti kanna vector, yori si kan ni ilopo-free ⚠️ nigba ti won mejeeji gba silẹ!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // Aabo: awọn olupe gbọdọ lopolopo ti `self` ti wa ni initialized.
        // Kika lati `self.as_ptr()` jẹ ailewu niwon `self` yẹ ki o wa initialized.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Ṣubu iye ti o wa ninu aye silẹ.
    ///
    /// Ti o ba ni ohun-ini ti `MaybeUninit`, o le lo [`assume_init`] dipo.
    ///
    /// # Safety
    ///
    /// O di si olupe lati ṣe idaniloju pe `MaybeUninit<T>` gaan wa ni ipo ipilẹṣẹ.Pipe yi nigbati awọn akoonu ti a ko ti sibẹsibẹ ni kikun initialized okunfa aisọye ihuwasi.
    ///
    /// Lori oke ti ti, gbogbo afikun invariants ti awọn iru `T` gbọdọ wa ni ooto, bi awọn `Drop` imuse ti `T` (tabi awọn oniwe-ẹgbẹ) le gbekele yi.
    /// Fun apẹẹrẹ, a `1`-initialized [`Vec<T>`] ti wa ni ka initialized (labẹ awọn ti isiyi imuse; eyi ko je a idurosinsin lopolopo) nitori awọn ibeere nikan ni alakojo mo nipa o jẹ wipe awọn data ijuboluwole gbọdọ jẹ ti kii-asan.
    ///
    /// Sisọ awọn iru a `Vec<T>` sibẹsibẹ yoo fa aisọye ihuwasi.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // Aabo: awọn olupe gbọdọ lopolopo ti `self` ti wa ni initialized ati
        // satisfies gbogbo invariants ti `T`.
        // Sisọ awọn iye ni ibi jẹ ailewu ti o ba ti ni irú.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// N ni a pín tọka si wa ninu iye.
    ///
    /// Eyi le wulo nigba ti a fẹ lati wọle si `MaybeUninit` kan ti a ti bẹrẹ ṣugbọn ko ni nini ti `MaybeUninit` (idilọwọ lilo `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn ihuwasi ti a ko ṣalaye: o wa si olupe lati ṣe idaniloju pe `MaybeUninit<T>` gaan wa ni ipo ipilẹṣẹ.
    ///
    ///
    /// # Examples
    ///
    /// ### Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Ṣiṣẹ `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nisisiyi pe a mọ `MaybeUninit<_>` wa lati wa ni ipilẹṣẹ, o dara lati ṣẹda itọkasi ti o pin si rẹ:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // Aabo: `x` ti a ti initialized.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Tọ* usages yi ọna:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // A ti da a tọka si ohun uninitialized vector!Eleyi jẹ aisọye ihuwasi.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Ṣe ipilẹṣẹ `MaybeUninit` nipa lilo `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Itọkasi si `Cell<bool>` ti ko ni oye: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // Aabo: awọn olupe gbọdọ lopolopo ti `self` ti wa ni initialized.
        // Eyi tun tumọ si pe `self` gbọdọ jẹ iyatọ `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// N ni a mutable (unique) tọka si wa ninu iye.
    ///
    /// Eyi le wulo nigba ti a fẹ lati wọle si `MaybeUninit` kan ti a ti bẹrẹ ṣugbọn ko ni nini ti `MaybeUninit` (idilọwọ lilo `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn ihuwasi ti a ko ṣalaye: o wa si olupe lati ṣe idaniloju pe `MaybeUninit<T>` gaan wa ni ipo ipilẹṣẹ.
    /// Fun apẹẹrẹ, `.assume_init_mut()` ko le wa ni lo lati initialize a `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Atunse lilo ti yi ọna:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Ni ipilẹṣẹ *gbogbo* awọn baiti ti ifipamọ kikọ sii.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ṣiṣẹ `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Bayi a mọ pe `buf` ti a ti initialized, ki a le `.assume_init()` o.
    /// // Sibẹsibẹ, lilo `.assume_init()` le nfa ohun kan ti `memcpy` ti awọn 2048 awọn baiti.
    /// // To assert wa saarin ti a ti initialized lai didakọ o, a igbesoke awọn `&mut MaybeUninit<[u8; 2048]>` to a `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Aabo: `buf` ti a ti initialized.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Bayi a le lo `buf` bi awọn kan deede bibẹ:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Tọ* usages yi ọna:
    ///
    /// O ko le lo `.assume_init_mut()` to initialize a iye:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // A ti da a (mutable) tọka si ohun uninitialized `bool`!
    ///     // Eleyi jẹ aisọye ihuwasi.⚠️
    /// }
    /// ```
    ///
    /// Fun apẹẹrẹ, o le ko [`Read`] sinu ohun uninitialized saarin:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tọka si uninitialized iranti!
    ///                             // Eyi jẹ ihuwasi ti a ko ṣalaye.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Tabi o le ti o lo taara oko wiwọle lati se oko-nipasẹ-oko mimu initialization:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tọka si uninitialized iranti!
    ///                  // Eyi jẹ ihuwasi ti a ko ṣalaye.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tọka si uninitialized iranti!
    ///                  // Eyi jẹ ihuwasi ti a ko ṣalaye.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): A Lọwọlọwọ gbekele lori awọn loke jije ko tọ, ie, a ni jo si uninitialized data (eg, ni `libcore/fmt/float.rs`).
    // A yẹ ki o ṣe a ik ipinnu nipa awọn ofin ṣaaju ki o to idaduro.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // Aabo: awọn olupe gbọdọ lopolopo ti `self` ti wa ni initialized.
        // Eyi tun tumọ si pe `self` gbọdọ jẹ iyatọ `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Mu awọn iye jade lati oriṣi awọn apoti `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// O ti wa ni soke si awọn olupe to lopolopo ti gbogbo awọn eroja ti awọn orun ni o wa ni ohun initialized ipinle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Aabo: Bayi ailewu bi a ti initialised gbogbo awọn eroja
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Awọn olupe onigbọwọ pe gbogbo awọn eroja ti awọn orun ti wa ni initialized
        // * `MaybeUninit<T>` ati T ti wa ni ẹri lati ni awọn kanna akọkọ
        // * BoyaUnint ko ju silẹ, nitorinaa ko si awọn ominira meji ati bayi iyipada jẹ ailewu
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ro gbogbo awọn eroja ti wa ni initialized, gba a bibẹ fun wọn.
    ///
    /// # Safety
    ///
    /// O ti wa ni soke si awọn olupe to ẹri wipe awọn `MaybeUninit<T>` eroja gan ni o wa ni ohun initialized ipinle.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye.
    ///
    /// Wo [`assume_init_ref`] fun alaye sii ki o si apeere.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // Aabo: simẹnti bibẹ to a `*const [T]` jẹ ailewu niwon awọn olupe onigbọwọ ti
        // `slice` ni initialized, and`MaybeUninit` wa ni ẹri lati ni kanna akọkọ bi `T`.
        // Awọn ijuboluwole gba ni wulo niwon o ntokasi si iranti ohun ini nipasẹ `slice` ti o jẹ a itọkasi ati bayi ẹri lati wa ni wulo fun Say.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ro gbogbo awọn eroja ti wa ni initialized, gba a mutable bibẹ fun wọn.
    ///
    /// # Safety
    ///
    /// O ti wa ni soke si awọn olupe to ẹri wipe awọn `MaybeUninit<T>` eroja gan ni o wa ni ohun initialized ipinle.
    ///
    /// Pipe eyi nigbati akoonu ko iti bẹrẹ ni kikun fa awọn iwa aisọye.
    ///
    /// Wo [`assume_init_mut`] fun alaye sii ki o si apeere.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // Aabo: iru si awọn akọsilẹ aabo fun `slice_get_ref`, ṣugbọn a ni kan
        // mutable itọkasi eyi ti o ti tun ẹri lati wa ni wulo fun Levin.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// N ni ijuboluwole kan si nkan akọkọ ti tito sile.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// N ni a mutable ijuboluwole si akọkọ ano ti awọn orun.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Dakọ awọn eroja lati `src` si `this`, n dapada tọka iyipada si awọn akoonu initalized ti `this` bayi.
    ///
    /// Ti o ba ti `T` ko ni se `Copy`, lo [`write_slice_cloned`]
    ///
    /// Eleyi jẹ iru si [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo panic ti awọn ege meji ni awọn gigun oriṣiriṣi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Aabo: a ti ṣakọ gbogbo awọn eroja ti ya sinu agbara apoju
    /// // akọkọ src.len() eroja ti awọn vec o wa wulo bayi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // Aabo: &[T] ati&[MaybeUninit<T>] Ni kanna akọkọ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // Aabo: Wulo eroja ti o kan ti a ti dakọ sinu `this` ki o ti wa initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Ibeji awọn eroja lati `src` to `this`, pada a mutable tọka si bayi initalized akoonu ti ti `this`.
    /// Eyikeyi awọn eroja ti a ti sọ tẹlẹ ko ni ju silẹ.
    ///
    /// Ti `T` ba ṣe `Copy`, lo [`write_slice`]
    ///
    /// Eleyi jẹ iru si [`slice::clone_from_slice`] sugbon ko ni ju tẹlẹ eroja.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo panic ti awọn ege meji ni awọn gigun oriṣiriṣi, tabi ti imuse ti `Clone` panics.
    ///
    /// Ba ti wa ni a panic, awọn tẹlẹ cloned eroja yoo wa ni silẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Aabo: a ti o kan cloned gbogbo awọn eroja ti Len sinu spare agbara
    /// // akọkọ src.len() eroja ti awọn vec o wa wulo bayi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ko copy_from_slice eyi ko pe clone_from_slice lori bibẹ yi ni nitori `MaybeUninit<T: Clone>` ko ni se Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // Aabo: yi aise bibẹ yoo ni nikan initialized ohun
                // ti o ni idi, o ti wa ni laaye lati ju silẹ o.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: A nilo lati ge wọn ni kedere si ipari kanna
        // fun igboro yiyewo lati wa ni elided, ati awọn optimizer yoo se ina memcpy fun o rọrun igba (fun apẹẹrẹ T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // oluso wa ni ti nilo b/c panic le ṣẹlẹ nigba kan oniye
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // Aabo: Awọn eroja ti o wulo ni a ti kọ sinu `this` nitorinaa o jẹ initized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}