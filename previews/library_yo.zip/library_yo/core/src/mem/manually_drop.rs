use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper lati dojuti alakojo lati laifọwọyi pipe 'T` ká destructor.
/// Eleyi wrapper jẹ 0-iye owo.
///
/// `ManuallyDrop<T>` jẹ koko ọrọ si awọn kanna akọkọ optimizations bi `T`.
/// Bii abajade, ko ni *ipa kankan* lori awọn arosinu ti akopọ ṣe nipa awọn akoonu rẹ.
/// Fun apẹẹrẹ, ipilẹṣẹ `ManuallyDrop<&mut T>` pẹlu [`mem::zeroed`] jẹ ihuwasi ti a ko ṣalaye.
/// Ti o ba nilo lati mu awọn uninitialized data, lo [`MaybeUninit<T>`] dipo.
///
/// Akiyesi pe wọle iye inu a `ManuallyDrop<T>` jẹ ailewu.
/// Yi ọna ti a `ManuallyDrop<T>` ti akoonu ti a ti lọ silẹ kò gbọdọ wa ni fara nipasẹ kan àkọsílẹ ailewu API.
/// Ni ibamu, `ManuallyDrop::drop` jẹ ailewu.
///
/// # `ManuallyDrop` ati ju ibere.
///
/// Rust ni [drop order] ti a ṣalaye daradara ti awọn iye.
/// Lati rii daju pe awọn aaye tabi awọn agbegbe ti lọ silẹ ni aṣẹ kan pato, tunto awọn ikede naa bii pe aṣẹ ifilọ silẹ ti o tọ jẹ eyiti o tọ.
///
/// O ti wa ni ṣee ṣe lati lo `ManuallyDrop` lati šakoso awọn ju ibere, sugbon yi nilo lewu koodu ati ki o jẹ gidigidi lati se ti tọ ninu niwaju unwinding.
///
///
/// Fun apẹẹrẹ, ti o ba ti o ba fẹ lati rii daju pe a kan pato aaye ti wa ni silẹ lẹhin ti awọn miran, ṣe awọn ti o kẹhin aaye ti a struct:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` yoo wa ni silẹ lẹhin `children`.
///     // Awọn onigbọwọ Rust pe awọn aaye silẹ silẹ ni aṣẹ ikede.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Ipari a iye to wa ni ọwọ silẹ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // O si tun le kuro lailewu ṣiṣẹ lori iye
    /// assert_eq!(*x, "Hello");
    /// // Ṣugbọn `Drop` yoo wa ko le ṣiṣe nibi
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ṣe afikun iye lati inu apoti `ManuallyDrop`.
    ///
    /// Eleyi gba awọn iye to wa ni silẹ lẹẹkansi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Eleyi silė awọn `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Gba iye lati inu apoti `ManuallyDrop<T>` jade.
    ///
    /// Ọna yii ni ipinnu akọkọ fun gbigbe awọn iye jade ni silẹ.
    /// Dipo ti lilo [`ManuallyDrop::drop`] lati ọwọ ju awọn iye, o le lo yi ọna lati ya awọn iye o si lo o sibẹsibẹ fẹ.
    ///
    /// Nigbakugba ti o ti ṣee, o jẹ preferable lati lo [`into_inner`][`ManuallyDrop::into_inner`] dipo, eyi ti idilọwọ duplicating awọn akoonu ti awọn `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Iṣẹ yii n gbe jade ni iye ti o wa ninu laisi idilọwọ lilo siwaju, nlọ ipo ti apo eiyan yii ko yipada.
    /// O jẹ ojuṣe rẹ lati rii daju wipe yi `ManuallyDrop` ti wa ni ko lo lẹẹkansi.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Aabo: a n ka lati itọkasi kan, eyiti o jẹ ẹri
        // lati wa ni wulo fun Say.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ọwọ silė awọn ti o wa ninu iye.Eleyi jẹ gangan deede si pipe [`ptr::drop_in_place`] pẹlu kan ijuboluwole si awọn ti o wa ninu iye.
    /// Bi iru, ayafi ti o wa ninu iye ni a sere struct, awọn destructor yoo wa ni a npe ni ni-ibi lai gbigbe awọn iye, ati bayi a le lo lati lailewu silẹ [pinned] data.
    ///
    /// Ti o ba ni nini ti awọn iye, o le lo [`ManuallyDrop::into_inner`] dipo.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii n ṣiṣẹ apanirun ti iye ti o wa ninu rẹ.
    /// Miiran ju awọn ayipada ti o ṣe nipasẹ apanirun funrararẹ, iranti naa ni a fi silẹ ko yipada, ati nitorinaa bi olupilẹṣẹ ba n ṣojuuṣe ṣi idaduro apẹẹrẹ diẹ eyiti o wulo fun iru `T`.
    ///
    ///
    /// Sibẹsibẹ, yi "zombie" iye yẹ ki o wa ko le fara si ailewu koodu, ki o si yi iṣẹ yẹ ki o ko wa ni a npe diẹ ju ẹẹkan.
    /// Lati lo a iye lẹhin ti o ti n a ti lọ silẹ, tabi ju a iye ọpọ igba, le fa aisọye Ihuwasi (ti o da lori ohun ti `drop` wo ni).
    /// Yi ti ni deede idaabobo nipasẹ awọn iru eto, sugbon olumulo ti `ManuallyDrop` gbọdọ opagun awon onigbọwọ lai iranlowo lati alakojo.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // Aabo: a n sọ iye ti o tọka si nipasẹ itọkasi iyipada
        // eyiti o jẹ ẹri lati wulo fun kikọ.
        // O jẹ fun olupe naa lati rii daju pe `slot` ko tun silẹ.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}