//! Ipilẹ awọn iṣẹ fun awọn olugbagbọ pẹlu iranti.
//!
//! Eleyi module ni awọn iṣẹ fun querying awọn iwọn ati titete orisi, initializing ati ifọwọyi iranti.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Gba nini ati "forgets" nipa awọn iye **lai nṣiṣẹ awọn oniwe-destructor**.
///
/// Eyikeyi oro iye seto, gẹgẹ bi awọn okiti iranti tabi faili mu, yoo Dúró lailai ninu ohun ọdọ ipinle.Sugbon, o ko še onigbọwọ wipe awọn ifẹnule lati yi iranti yoo wa nibe wulo.
///
/// * Ti o ba fẹ lati jo iranti, wo [`Box::leak`].
/// * Ti o ba fẹ lati gba a aise ijuboluwole si iranti, wo [`Box::into_raw`].
/// * Ti o ba fẹ sọ iye kan daradara, ṣiṣe apanirun rẹ, wo [`mem::drop`].
///
/// # Safety
///
/// `forget` ti ko ba ti samisi bi `unsafe`, nitori Rust ká ailewu onigbọwọ ma ko ni a lopolopo ti destructors yoo ma ṣiṣe.
/// Fun apẹẹrẹ, eto kan le ṣẹda iyipo itọkasi nipa lilo [`Rc`][rc], tabi pe [`process::exit`][exit] lati jade laisi awọn apanirun ti nṣiṣẹ.
/// Bayi, gbigba `mem::forget` lati ailewu koodu ko ni taa yi Rust ailewu onigbọwọ.
///
/// Iyẹn sọ, jijo awọn orisun bii iranti tabi awọn nkan I/O jẹ eyiti ko fẹ.
/// Awọn nilo wa soke ni diẹ ninu awọn specialized lilo igba fun FFI tabi lewu koodu, sugbon ani ki o si, [`ManuallyDrop`] wa ni ojo melo fẹ.
///
/// Nitori igbagbe iye kan ni a gba laaye, eyikeyi koodu `unsafe` ti o kọ gbọdọ gba laaye fun iṣeeṣe yii.O ko ba le pada a iye ati reti wipe awọn olupe ti yoo dandan ṣiṣe awọn iye ká destructor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Awọn oṣuwọn ilana ailewu lilo `mem::forget` ni lati circumvent a iye ká destructor muse nipasẹ awọn `Drop` trait.Fun apẹẹrẹ, yi yoo jo a `File`, ie
/// gba aaye ti o ya nipasẹ oniyipada pada ṣugbọn maṣe pa orisun orisun eto:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Eleyi jẹ wulo nigbati awọn nini ti awọn abele awọn oluşewadi a ti tẹlẹ gbe si koodu ti ita Rust, fun apẹẹrẹ nipa sisẹ awọn aise faili descriptor to C koodu.
///
/// # Ibasepo pẹlu `ManuallyDrop`
///
/// Nigba ti `mem::forget` tun le ṣee lo lati gbe *iranti* nini, ṣe bẹẹ ni aṣiṣe-prone.
/// [`ManuallyDrop`] yẹ ki o wa lo dipo.Ro, fun apẹẹrẹ, yi koodu:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Kọ a `String` lilo awọn awọn akoonu ti `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // jo `v` nitori awọn oniwe-iranti ti wa ni bayi itọju rẹ nipa `s`
/// mem::forget(v);  // Aṣiṣe, v ni invalid ati ki o gbọdọ wa ko le kọja si iṣẹ kan
/// assert_eq!(s, "Az");
/// // `s` ti wa ni kikọ silẹ silẹ laipẹ ati adehun iranti rẹ ti pin.
/// ```
///
/// Nibẹ ni o wa meji oran pẹlu awọn loke apẹẹrẹ:
///
/// * Ti o ba ti diẹ koodu ni won fi kun laarin awọn ikole ti `String` ati awọn epe ti `mem::forget()`, a panic laarin o yoo fa a ė free nitori awọn kanna iranti ti wa ni lököökan nipa mejeeji `v` ati `s`.
/// * Lẹhin pipe `v.as_mut_ptr()` ati sisẹ awọn nini ti awọn data to `s`, awọn `v` iye ni invalid.
/// Paapaa nigba ti a iye ti wa ni o kan gbe si `mem::forget` (eyi ti yoo ko ayewo o), diẹ ninu awọn orisi ni o muna awọn ibeere lori wọn iye ti ṣe wọn invalid nigbati purpili tabi ko gun ini.
/// Lilo awọn iye ti ko wulo ni eyikeyi ọna, pẹlu gbigbe wọn si tabi da wọn pada lati awọn iṣẹ, o jẹ ihuwasi ti a ko ṣalaye ati pe o le fọ awọn imọran ti olupilẹṣẹ ṣe.
///
/// Yipada si `ManuallyDrop` yago fun awọn ọran mejeeji:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ṣaaju ki a to ṣapapọ `v` sinu awọn ẹya aise rẹ, rii daju pe ko lọ silẹ!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Bayi ṣapapọ `v`.Awọn iṣiṣẹ wọnyi ko le ṣe panic, nitorinaa ko le jo.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Lakotan, kọ `String` kan.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ti wa ni kikọ silẹ silẹ laipẹ ati adehun iranti rẹ ti pin.
/// ```
///
/// `ManuallyDrop` ni igboya ṣe idiwọ ominira-meji nitori a mu apanirun `v` ṣaaju ṣiṣe ohunkohun miiran.
/// `mem::forget()` ko gba laaye eyi nitori pe o jẹ ariyanjiyan rẹ, o fi agbara mu wa lati pe nikan lẹhin yiyọ ohunkohun ti a nilo lati `v`.
/// Paapaa ti o ba ṣafihan panic kan laarin ikole ti `ManuallyDrop` ati kikọ okun (eyiti ko le ṣẹlẹ ninu koodu bi o ti han), yoo ja si jo ati kii ṣe ọfẹ meji.
/// Ni awọn ọrọ miiran, `ManuallyDrop` ṣe aṣiṣe ni ẹgbẹ jijo dipo aṣiṣe ni ẹgbẹ ti (ilọpo-) sisọ silẹ.
///
/// Pẹlupẹlu, `ManuallyDrop` ṣe idiwọ fun wa lati ni si "touch" `v` lẹhin gbigbe ohun-ini si `s`-igbesẹ ikẹhin ti ibaraenisepo pẹlu `v` lati sọ rẹ laisi ṣiṣe apanirun rẹ ni a yago fun patapata.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Bii [`forget`], ṣugbọn tun gba awọn iye ti ko ni iwọn.
///
/// Iṣẹ yii jẹ shim ti o pinnu lati yọkuro nigbati ẹya `unsized_locals` ba ni iduroṣinṣin.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Pada iwọn ti iru ninu awọn baiti.
///
/// Ni pataki diẹ sii, eyi ni aiṣedeede ninu awọn baiti laarin awọn eroja atẹle ni ọna kan pẹlu iru ohun kan pẹlu fifẹ titete.
///
/// Nitorinaa, fun eyikeyi iru `T` ati ipari `n`, `[T; n]` ni iwọn ti `n * size_of::<T>()`.
///
/// Ni gbogbogbo, iwọn iru kan ko ni iduroṣinṣin kọja awọn akopọ, ṣugbọn awọn oriṣi pato gẹgẹbi awọn ipilẹṣẹ jẹ.
///
/// Tabili atẹle n fun ni iwọn fun awọn ipilẹṣẹ.
///
/// Iru |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Pẹlupẹlu, `usize` ati `isize` ni iwọn kanna.
///
/// Awọn oriṣi `*const T`, `&T`, `Box<T>`, `Option<&T>`, ati `Option<Box<T>>` gbogbo wọn ni iwọn kanna.
/// Ti `T` jẹ Iwọn, gbogbo awọn iru wọnyẹn ni iwọn kanna bi `usize`.
///
/// Iyipada ti ijuboluwole ko yi iwọn rẹ pada.Bii eyi, `&T` ati `&mut T` ni iwọn kanna.
/// Bakanna fun `*const T` ati `* mut T`.
///
/// # Iwọn awọn ohun `#[repr(C)]`
///
/// Aṣoju `C` fun awọn ohun kan ni ipilẹ ti a ti ṣalaye.
/// Pẹlu ipilẹ yii, iwọn awọn ohun tun jẹ iduroṣinṣin bi igba ti gbogbo awọn aaye ni iwọn iduroṣinṣin.
///
/// ## Iwọn ti Awọn ipa
///
/// Fun `structs`, iwọn naa ni ipinnu nipasẹ algorithm atẹle.
///
/// Fun aaye kọọkan ninu ilana ti a paṣẹ nipasẹ aṣẹ ikede:
///
/// 1. Fi iwọn aaye kun.
/// 2. Ṣe iwọn iwọn lọwọlọwọ si ọpọ ti o sunmọ julọ ti [alignment] aaye ti n bọ.
///
/// Ni ipari, yika iwọn ti iṣeto si ọpọ ti o sunmọ ti [alignment] rẹ.
/// Ṣiṣeto ti iṣeto jẹ igbagbogbo tito lẹtọ julọ ti gbogbo awọn aaye rẹ;eyi le yipada pẹlu lilo `repr(align(N))`.
///
/// Kii `C`, awọn idiwọn iwọn odo ko ni yika si baiti kan ni iwọn.
///
/// ## Iwọn ti Enums
///
/// Awọn Enums ti ko gbe data miiran yatọ si iyasoto ni iwọn kanna bi C enums lori pẹpẹ ti wọn kojọ fun.
///
/// ## Iwọn ti Awọn Awin
///
/// Iwọn ti iṣọkan jẹ iwọn ti aaye ti o tobi julọ.
///
/// Kii `C`, awọn ẹgbẹ awin ti ko ni iyipo si baiti kan ni iwọn.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // diẹ ninu awọn primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // diẹ ninu awọn imole
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Ijuboluwole iwọn Equality
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Lilo `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Awọn iwọn ti akọkọ oko ni 1, ki o si fi 1 si awọn iwọn.Iwọn ni 1.
/// // Iṣatunṣe ti aaye keji jẹ 2, nitorinaa ṣafikun 1 si iwọn fun fifẹ.Iwọn ni 2.
/// // Awọn iwọn ti awọn keji aaye jẹ 2, ki o si fi 2 si awọn iwọn.Iwọn ni 4.
/// // Awọn titete ti awọn kẹta oko ni 1, ki o si fi 0 si awọn iwọn fun òwú.Iwọn ni 4.
/// // Iwọn aaye kẹta ni 1, nitorinaa fi 1 si iwọn naa.Iwọn ni 5.
/// // Ni ipari, tito eto naa jẹ 2 (nitori titete titọ julọ laarin awọn aaye rẹ jẹ 2), nitorinaa ṣafikun 1 si iwọn fun fifẹ.
/// // Iwọn ni 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs tẹle awọn kanna ofin.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Akiyesi pe reordering awọn aaye le kekere ti awọn iwọn.
/// // A le yọ awọn mejeeji òwú baiti nipa o nri `third` ṣaaju ki o to `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union iwọn ni awọn iwọn ti awọn ti oko.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Pada iwọn ti tokasi-si iye ninu awọn baiti.
///
/// Eyi nigbagbogbo jẹ kanna bi `size_of::<T>()`.
/// Sibẹsibẹ, nigbati `T`*ko ni* ko si iwọn ti a mọ ni iṣiro, fun apẹẹrẹ, gige kan [`[T]`][slice] tabi [trait object] kan, lẹhinna `size_of_val` le ṣee lo lati gba iwọn ti a mọ ni agbara.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // Aabo: `val` jẹ itọkasi kan, nitorinaa o jẹ itọka aise to wulo
    unsafe { intrinsics::size_of_val(val) }
}

/// Pada iwọn ti tokasi-si iye ninu awọn baiti.
///
/// Eyi nigbagbogbo jẹ kanna bi `size_of::<T>()`.Sibẹsibẹ, nigbati `T`*ko ni* iwọn ti a mọ ni iṣiro, fun apẹẹrẹ, nkan gige [`[T]`][slice] tabi [trait object] kan, lẹhinna `size_of_val_raw` le ṣee lo lati gba iwọn ti a mọ ni agbara.
///
/// # Safety
///
/// Iṣẹ yii jẹ ailewu nikan lati pe ti awọn ipo wọnyi ba mu:
///
/// - Ti o ba ti `T` ni `Sized`, iṣẹ yi jẹ nigbagbogbo ailewu lati pe.
/// - Ti iru ti ko ni iwọn ti `T` jẹ:
///     - [slice] kan, lẹhinna ipari iru iru nkan gbodo jẹ odidi ipilẹṣẹ, ati iwọn ti *gbogbo iye*(ipari iru iruju + prefix ti iwọn iwọn) gbọdọ baamu ni `isize`.
///     - [trait object] kan, lẹhinna apakan vtable ti ijuboluwole gbọdọ tọka si vtable to wulo ti o gba nipasẹ ipọnju ti ko nira, ati iwọn ti *gbogbo iye*(ipari iru iruju + prefix titobi iwọn) gbọdọ baamu ni `isize`.
///
///     - (unstable) [extern type] kan, lẹhinna iṣẹ yii jẹ ailewu nigbagbogbo lati pe, ṣugbọn le panic tabi bibẹẹkọ pada iye ti ko tọ, bi a ko ṣe mọ iru iru ita.
///     Eyi jẹ ihuwasi kanna bi [`size_of_val`] lori itọkasi si oriṣi kan pẹlu iru iru ita.
///     - bibẹkọ ti, o ti wa ni conservatively ko ba gba laaye lati pe iṣẹ yi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // Aabo: olupe gbọdọ pese ijuboluwo to wulo
    unsafe { intrinsics::size_of_val(val) }
}

/// Pada si tito nkan ti o kere ju ti [ABI] ti a beere.
///
/// Gbogbo itọkasi si iye ti iru `T` gbọdọ jẹ ọpọ ti nọmba yii.
///
/// Eyi ni tito lẹda ti a lo fun awọn aaye ti ipilẹ.O le jẹ kere ju tito yiyan lọ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Pada si titọ kere julọ ti [ABI] ti iru iye ti `val` tọka si.
///
/// Gbogbo itọkasi si iye ti iru `T` gbọdọ jẹ ọpọ ti nọmba yii.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // Aabo: val jẹ itọkasi kan, nitorinaa o jẹ itọka aise to wulo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Pada si tito nkan ti o kere ju ti [ABI] ti a beere.
///
/// Gbogbo itọkasi si iye ti iru `T` gbọdọ jẹ ọpọ ti nọmba yii.
///
/// Eyi ni tito lẹda ti a lo fun awọn aaye ti ipilẹ.O le jẹ kere ju tito yiyan lọ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Pada si titọ kere julọ ti [ABI] ti iru iye ti `val` tọka si.
///
/// Gbogbo itọkasi si iye ti iru `T` gbọdọ jẹ ọpọ ti nọmba yii.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // Aabo: val jẹ itọkasi kan, nitorinaa o jẹ itọka aise to wulo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Pada si titọ kere julọ ti [ABI] ti iru iye ti `val` tọka si.
///
/// Gbogbo itọkasi si iye ti iru `T` gbọdọ jẹ ọpọ ti nọmba yii.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Iṣẹ yii jẹ ailewu nikan lati pe ti awọn ipo wọnyi ba mu:
///
/// - Ti o ba ti `T` ni `Sized`, iṣẹ yi jẹ nigbagbogbo ailewu lati pe.
/// - Ti iru ti ko ni iwọn ti `T` jẹ:
///     - [slice] kan, lẹhinna ipari iru iru nkan gbodo jẹ odidi ipilẹṣẹ, ati iwọn ti *gbogbo iye*(ipari iru iruju + prefix ti iwọn iwọn) gbọdọ baamu ni `isize`.
///     - [trait object] kan, lẹhinna apakan vtable ti ijuboluwole gbọdọ tọka si vtable to wulo ti o gba nipasẹ ipọnju ti ko nira, ati iwọn ti *gbogbo iye*(ipari iru iruju + prefix titobi iwọn) gbọdọ baamu ni `isize`.
///
///     - (unstable) [extern type] kan, lẹhinna iṣẹ yii jẹ ailewu nigbagbogbo lati pe, ṣugbọn le panic tabi bibẹẹkọ pada iye ti ko tọ, bi a ko ṣe mọ iru iru ita.
///     Eyi jẹ ihuwasi kanna bi [`align_of_val`] lori itọkasi si oriṣi kan pẹlu iru iru ita.
///     - bibẹkọ ti, o ti wa ni conservatively ko ba gba laaye lati pe iṣẹ yi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // Aabo: olupe gbọdọ pese ijuboluwo to wulo
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Pada `true` ti o ba sọ awọn iye silẹ ti iru awọn ọrọ `T` silẹ.
///
/// Eyi jẹ itọkasi ti iṣapeye, ati pe o le ṣe imulẹ ni ilodisi:
/// o le da `true` pada fun awọn oriṣi ti ko nilo kosi silẹ.
/// Bii bii nigbagbogbo pada `true` yoo jẹ imuse ti o wulo ti iṣẹ yii.Sibẹsibẹ ti iṣẹ yii ba da `false` pada ni otitọ, lẹhinna o le rii daju pe fifisilẹ `T` ko ni ipa kankan.
///
/// Awọn imuṣẹ ipele kekere ti awọn nkan bii awọn akopọ, eyiti o nilo lati fi data wọn silẹ pẹlu ọwọ, yẹ ki o lo iṣẹ yii lati yago fun igbiyanju ainidiṣe lati ju gbogbo awọn akoonu wọn silẹ nigbati wọn ba parun.
///
/// Eyi le ma ṣe iyatọ ninu awọn idasilẹ idasilẹ (nibiti lupu ti ko ni awọn ipa-ẹgbẹ ni a rii ati rọọrun ni rọọrun), ṣugbọn igbagbogbo jẹ win nla fun awọn aṣiṣe aṣiṣe.
///
/// Akiyesi pe [`drop_in_place`] ti ṣe iṣayẹwo yii tẹlẹ, nitorinaa ti iṣẹ iṣẹ rẹ ba le dinku si nọmba kekere ti awọn ipe [`drop_in_place`], lilo eyi ko ṣe pataki.
/// Ni akiyesi ni pato pe o le [`drop_in_place`] ege kan, ati pe eyi yoo ṣe ayẹwo aini_drop kan fun gbogbo awọn iye.
///
/// Awọn iru bii Vec nitorinaa `drop_in_place(&mut self[..])` nikan laisi lilo `needs_drop` ni gbangba.
/// Awọn oriṣi bii [`HashMap`], ni apa keji, ni lati sọ awọn iye silẹ ni ẹẹkan ati pe o yẹ ki o lo API yii.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Eyi ni apẹẹrẹ ti bi ikojọpọ le ṣe lo `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ju awọn data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Pada iye ti iru `T` ti o ni aṣoju nipasẹ apẹẹrẹ-gbogbo-odo.
///
/// Eyi tumọ si pe, fun apẹẹrẹ, baiti fifẹ ni `(u8, u16)` ko jẹ dandan ni asan.
///
/// Ko si iṣeduro pe apẹẹrẹ-gbogbo baiti-odo jẹ aṣoju iye to wulo ti iru `T` kan.
/// Fun apẹẹrẹ, apẹrẹ baiti-gbogbo kii ṣe iye to wulo fun awọn oriṣi itọkasi (`&T`, `&mut T`) ati awọn atọka iṣẹ.
/// Lilo `zeroed` lori iru awọn iru fa [undefined behavior][ub] lẹsẹkẹsẹ nitori [the Rust compiler assumes][inv] pe nigbagbogbo wa iye to wulo ninu oniyipada kan ti o ka ipilẹṣẹ.
///
///
/// Eyi ni ipa kanna bi [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// O wulo fun FFI nigbakan, ṣugbọn o yẹ ki a yago fun ni gbogbogbo.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Atunse lilo ti iṣẹ yii: bibẹrẹ odidi pẹlu odo.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Lilo ti ko tọ* ti iṣẹ yii: ipilẹṣẹ itọkasi pẹlu odo.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Iwa ti a ko ṣalaye!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ati ki o lẹẹkansi!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe iye-odo gbogbo kan wulo fun `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses awọn iṣayẹwo ipilẹṣẹ iranti deede ti Rust nipa didabẹ lati gbe iye iru `T`, lakoko ṣiṣe ohunkohun rara.
///
/// **Iṣẹ yii ti dinku.** Lo [`MaybeUninit<T>`] dipo.
///
/// Idi fun idinkuro ni pe iṣẹ ipilẹ ko le ṣee lo ni deede: o ni ipa kanna bi [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Gẹgẹbi [`assume_init` documentation][assume_init] ṣe alaye, [the Rust compiler assumes][inv] pe awọn iye ti wa ni ipilẹṣẹ daradara.
/// Bi awọn kan Nitori, pipe eg
/// `mem::uninitialized::<bool>()` n fa ihuwasi aisọye lẹsẹkẹsẹ fun gbigba `bool` ti kii ṣe pato boya `true` tabi `false`.
/// Ti o buru julọ, iranti ainitiititọ bi ohun ti o pada nihin jẹ pataki ni pe akopọ mọ pe ko ni iye ti o wa titi.
/// Eyi jẹ ki o jẹ ihuwasi ti a ko ṣalaye lati ni data ti ko ni oye ninu oniyipada paapaa ti oniyipada yẹn ni iru odidi kan.
/// (Akiyesi pe awọn ofin ni ayika uninitialized odidi ko ba wa ni fipinu sibẹsibẹ, sugbon titi ti won wa, o ni ṣiṣe lati yago fun wọn.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe iye ti ko ni oye jẹ deede fun `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Swaps awọn iye ni awọn ipo iyipada meji, laisi iparun boya ọkan.
///
/// * Ti o ba fẹ lati paarọ pẹlu aiyipada tabi iye idinwon, wo [`take`].
/// * Ti o ba fẹ yipada pẹlu iye ti o kọja, ti o pada ni iye atijọ, wo [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // Ailewu: Awọn atọka aise ni a ti ṣẹda lati awọn itọkasi iyipada ti o ni aabo to ni itẹlọrun gbogbo awọn
    // awọn idiwọ lori `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Rọpo `dest` pẹlu iye aiyipada ti `T`, n pada iye `dest` tẹlẹ.
///
/// * Ti o ba fẹ rọpo awọn iye ti awọn oniyipada meji, wo [`swap`].
/// * Ti o ba fẹ rọpo pẹlu iye ti o kọja dipo iye aiyipada, wo [`replace`].
///
/// # Examples
///
/// Apẹẹrẹ ti o rọrun:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ngbanilaaye gbigba nini ti aaye ipilẹ nipa rirọpo pẹlu iye "empty" kan.
/// Laisi `take` o le ṣiṣẹ sinu awọn oran bii wọnyi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Akiyesi pe `T` ko ṣe dandan ṣe [`Clone`], nitorinaa ko le paapaa ẹda oniye ati tunto `self.buf`.
/// Ṣugbọn `take` le ṣee lo lati yapa iye atilẹba ti `self.buf` lati `self`, gbigba laaye lati pada:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Rare `src` sinu `dest` ti a tọka, n pada iye `dest` ti tẹlẹ.
///
/// Ko si iye silẹ.
///
/// * Ti o ba fẹ rọpo awọn iye ti awọn oniyipada meji, wo [`swap`].
/// * Ti o ba fẹ rọpo pẹlu iye aiyipada, wo [`take`].
///
/// # Examples
///
/// Apẹẹrẹ ti o rọrun:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ngbanilaaye agbara ti aaye ipilẹ nipa rirọpo pẹlu iye miiran.
/// Laisi `replace` o le ṣiṣẹ sinu awọn oran bii wọnyi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Akiyesi pe `T` ko ṣe dandan ṣe [`Clone`], nitorinaa a ko le ṣe ẹda oniye `self.buf[i]` lati yago fun gbigbe naa.
/// Ṣugbọn `replace` le ṣee lo lati yapa iye atilẹba ni itọka yẹn lati `self`, gbigba laaye lati pada:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // Aabo: A ka lati `dest` ṣugbọn taara kọ `src` sinu rẹ lẹhinna,
    // iru eyi ti iye atijọ ko ṣe ẹda.
    // Ko si ohunkan ti o sọ silẹ ati pe nkankan nibi le panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Sọ awọn iye kan.
///
/// Eyi ṣe bẹ nipa pipe imuse ariyanjiyan ti [`Drop`][drop].
///
/// Eyi ko ni nkankan ṣe fun awọn iru eyiti o ṣe `Copy`, fun apẹẹrẹ
/// integers.
/// Iru awọn iye bẹẹ ni ẹda ati _then_ gbe sinu iṣẹ naa, nitorinaa iye naa wa lẹhin ipe iṣẹ yii.
///
///
/// Iṣẹ yii kii ṣe idan;o ti wa ni itumọ ọrọ gangan bi
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Nitori pe `_x` ti gbe sinu iṣẹ, o ti lọ silẹ laifọwọyi ṣaaju iṣẹ naa pada.
///
/// [drop]: Drop
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // fojuhan silẹ vector
/// ```
///
/// Niwọn igba ti [`RefCell`] ṣe mu awọn ofin yiya ṣiṣẹ ni asiko asiko, `drop` le tu silẹ awin [`RefCell`] kan:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // relinquish awọn mutable wín, lori yi Iho
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Awọn akopọ ati awọn oriṣi miiran ti n ṣe imuse [`Copy`] ko ni ipa nipasẹ `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // a daakọ `x` wa ni gbe ati ki o lọ silẹ
/// drop(y); // a daakọ `y` wa ni gbe ati ki o lọ silẹ
///
/// println!("x: {}, y: {}", x, y.0); // si tun wa
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Awọn itumọ `src` bi nini `&U`, ati lẹhinna ka `src` laisi gbigbe iye ti o wa ninu rẹ.
///
/// Iṣẹ yii yoo lailewu ro pe ijuboluwole `src` wulo fun awọn baiti [`size_of::<U>`][size_of] nipasẹ gbigbe `&T` si `&U` ati lẹhinna kika `&U` (ayafi pe eyi ni a ṣe ni ọna ti o tọ paapaa nigbati `&U` ṣe awọn ibeere titọ to lagbara ju `&T`).
/// O yoo tun ṣe ailewu ṣẹda ẹda ti iye ti o wa ninu rẹ dipo gbigbe kuro ni `src`.
///
/// Kii ṣe aṣiṣe akoko ikojọ ti `T` ati `U` ba ni awọn titobi oriṣiriṣi, ṣugbọn o gba iwuri pupọ lati pe iṣẹ yii nikan ni ibiti `T` ati `U` ni iwọn kanna.Iṣẹ yii nfa [undefined behavior][ub] ti `U` tobi ju `T` lọ.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Da awọn data lati 'foo_array' ki o si toju o bi a 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Yi awọn dakọ data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Awọn awọn akoonu ti 'foo_array' yẹ ki o ko ti yi pada
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ti U ba ni ibeere tito to ga julọ, src le ma baamu deede.
    if align_of::<U>() > align_of::<T>() {
        // Aabo: `src` jẹ itọkasi eyiti o jẹ ẹri lati wulo fun awọn kika.
        // Olupe naa gbọdọ ṣe onigbọwọ pe transmutation gangan jẹ ailewu.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // Aabo: `src` jẹ itọkasi eyiti o jẹ ẹri lati wulo fun awọn kika.
        // A kan ṣayẹwo pe `src as *const U` ti ṣe deede.
        // Olupe naa gbọdọ ṣe onigbọwọ pe transmutation gangan jẹ ailewu.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Iru Opaque ti o nsoju iyasọ ti enum kan.
///
/// Wo iṣẹ [`discriminant`] ninu module yii fun alaye diẹ sii.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Awọn imuṣẹ trait wọnyi ko le jẹ ariwo nitori a ko fẹ eyikeyi awọn aala lori T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Pada iye iyasọtọ idanimọ iyatọ enum ni `v`.
///
/// Ti `T` ko ba jẹ enum, pipe iṣẹ yii kii yoo ni ihuwasi ti a ko ṣalaye, ṣugbọn iye ipadabọ ko ṣalaye.
///
///
/// # Stability
///
/// Iyatọ ti iyatọ enum le yipada ti itumọ enum ba yipada.
/// Iyatọ ti diẹ ninu iyatọ kii yoo yipada laarin awọn akopọ pẹlu akopọ kanna.
///
/// # Examples
///
/// Eyi le ṣee lo lati ṣe afiwe awọn enum ti o gbe data, lakoko ti o ko fiyesi data gangan:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Pada nọmba awọn iyatọ ninu iru enum `T`.
///
/// Ti `T` ko ba jẹ enum, pipe iṣẹ yii kii yoo ni ihuwasi ti a ko ṣalaye, ṣugbọn iye ipadabọ ko ṣalaye.
/// Bakanna, ti `T` ba jẹ enum pẹlu awọn iyatọ diẹ sii ju `usize::MAX` iye owo ipadabọ ko ṣalaye.
/// Awọn abawọn ti a ko gbe ni yoo ka.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}