//! The `Default` trait fun orisi eyi ti o le ni o nilari aiyipada iye.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait kan fun fifun iru iye aiyipada to wulo.
///
/// Nigba miran, ti o fẹ lati kuna pada si diẹ ninu awọn Iru aiyipada iye, ki o si ma ko paapa bikita ohun ti o jẹ.
/// Eyi wa ni igbagbogbo pẹlu `struct`s ti o ṣalaye akojọpọ awọn aṣayan:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Bawo ni a le setumo diẹ ninu awọn aiyipada iye?O le lo `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Bayi, ti o gba gbogbo awọn ti awọn aiyipada iye.Rust awọn ohun elo `Default` fun ọpọlọpọ awọn oriṣi akọkọ.
///
/// Ti o ba fẹ fagile aṣayan kan pato, ṣugbọn tun da awọn aiyipada miiran duro:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Eleyi trait le ṣee lo pẹlu `#[derive]` ti o ba ti gbogbo awọn ti awọn iru ile oko se `Default`.
/// Nigbati `derive`d, yoo lo iye aiyipada fun iru aaye kọọkan.
///
/// ## Bawo ni mo ti se `Default`?
///
/// Pese ohun imuse fun awọn `default()` ọna ti pada ni iye ti rẹ iru ti o yẹ ki o wa ni awọn aiyipada:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// Pada "default value" fun iru kan.
    ///
    /// Aiyipada iye ti wa ni igba diẹ ninu awọn Iru ni ibẹrẹ iye, idanimo iye, tabi ohunkohun miiran ti o le ṣe ori bi a aiyipada.
    ///
    ///
    /// # Examples
    ///
    /// Lilo awọn iye aiyipada ti a ṣe sinu:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Ṣiṣe tirẹ:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Pada awọn aiyipada iye ti a iru ni ibamu si awọn `Default` trait.
///
/// Awọn iru to pada wa ni mu lero jade lati tọ;yi ni deede lati `Default::default()` ṣugbọn kikuru to iru.
///
/// Fun apere:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Nianfani Makiro ti o npese ohun impl ti awọn trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }