//! Atokun yii n ṣe apẹrẹ `Any` trait, eyiti o jẹ ki titẹ titẹ agbara ti eyikeyi iru `'static` nipasẹ iṣaro asiko asiko.
//!
//! `Any` ara rẹ le ṣee lo lati gba `TypeId` kan, ati pe o ni awọn ẹya diẹ sii nigba lilo bi ohun trait.
//! Gẹgẹbi `&dyn Any` (ohun elo trait ti a yawo), o ni awọn ọna `is` ati `downcast_ref`, lati ṣe idanwo ti iye ti o wa ninu jẹ iru ti a fifun, ati lati ni itọkasi itọkasi iye inu bi iru kan.
//! Bii `&mut dyn Any`, ọna `downcast_mut` tun wa, fun gbigba itọkasi iyipada si iye ti inu.
//! `Box<dyn Any>` afikun awọn `downcast` ọna, eyi ti igbiyanju lati lọkan padà to a `Box<T>`.
//! Wo awọn [`Box`] iwe fun awọn alaye ni kikun.
//!
//! Akọsilẹ ti `&dyn Any` wa ni opin si igbeyewo boya a iye jẹ ti pàtó kan nja iru, ati ki o le wa ko le lo lati igbeyewo boya a iru oôn a trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Awọn itọkasi Smart ati `dyn Any`
//!
//! Ihuwasi kan lati tọju ni lokan nigba lilo `Any` bi ohun trait, paapaa pẹlu awọn oriṣi bi `Box<dyn Any>` tabi `Arc<dyn Any>`, ni pe pipe `.type_id()` lori iye yoo ṣe `TypeId` ti *apoti*, kii ṣe nkan trait.
//!
//! Eyi le yẹra nipa yiyipada ijuboluwole ọlọgbọn sinu `&dyn Any` dipo, eyi ti yoo da nkan pada ti `TypeId`.
//! Fun apere:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Ti o ba siwaju sii seese lati fẹ yi:
//! let actual_id = (&*boxed).type_id();
//! // ... ju eyi lọ:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Wo ipo kan nibiti a fẹ lati jade iye ti o kọja si iṣẹ kan.
//! A mọ iye ti a n ṣiṣẹ lori awọn Aṣiṣe N ṣatunṣe, ṣugbọn a ko mọ iru nja rẹ.A fẹ lati fun itọju pataki si awọn oriṣi kan: ninu ọran yii titẹ sita ipari ti awọn iye okun ni iṣaaju iye wọn.
//! A ko mọ awọn nja iru ti wa iye ni sakojo akoko, ki a nilo lati lo asiko isise otito dipo.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Iṣẹ iṣẹ logger fun eyikeyi iru ti o ṣe Iṣe aṣiṣe.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Gbiyanju lati yi iye wa pada si `String` kan.
//!     // Ti o ba ṣaṣeyọri, a fẹ ṣejade gigun okun String` ati iye rẹ.
//!     // Ti kii ba ṣe bẹ, o jẹ oriṣi oriṣi: kan tẹ sita laisi ẹwa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Iṣẹ yi fe lati wọle awọn oniwe-paramita jade saju to ṣe iṣẹ pẹlu o.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ṣe iṣẹ miiran
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Eyikeyi trait
///////////////////////////////////////////////////////////////////////////////

/// trait kan lati farawe titẹ agbara.
///
/// Ọpọlọpọ awọn iru ṣe imuse `Any`.Bibẹẹkọ, eyikeyi iru eyiti o ni itọkasi ti kii ṣe `static` ko ṣe.
/// Wo [module-level documentation][mod] fun awọn alaye diẹ sii.
///
/// [mod]: crate::any
// Eleyi trait ni ko lewu, bi o tilẹ ti a gbekele lori awọn pato ti o ká ẹri ti impl ká `type_id` iṣẹ ni lewu koodu (eg, `downcast`).Ni deede, iyẹn yoo jẹ iṣoro, ṣugbọn nitori impl nikan ti `Any` jẹ imuse ibora, ko si koodu miiran ti o le ṣe `Any`.
//
// A le ṣe ni idaniloju ṣe trait yii lailewu-kii yoo fa fifọ, nitori a ṣakoso gbogbo awọn imuṣẹ-ṣugbọn a yan lati ma ṣe nitori iyẹn mejeeji ko ṣe pataki gaan ati pe o le da awọn olumulo loju nipa iyatọ ti traits ti ko ni aabo ati awọn ọna ti ko ni aabo (ie, `type_id` yoo tun ni aabo lati pe, ṣugbọn a le fẹ lati tọka bi iru bẹẹ ninu iwe).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Gba `TypeId` ti `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Awọn ọna itẹsiwaju fun Eyikeyi awọn ohun trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Rii daju pe abajade ti apẹẹrẹ, didapọ okun kan le tẹjade ati nitorinaa lo pẹlu `unwrap`.
// Le bajẹ ko si ohun to wa ni ti nilo ti o ba ti disipashi ṣiṣẹ pẹlu upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Pada `true` ti iru apoti ba jẹ kanna bii `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Gba `TypeId` ti iru iṣẹ yii ti fi sii pẹlu.
        let t = TypeId::of::<T>();

        // Gba `TypeId` ti awọn iru ninu awọn trait ohun (`self`).
        let concrete = self.type_id();

        // Ṣe afiwe mejeeji `TypeId`s lori isọgba.
        t == concrete
    }

    /// Pada diẹ ninu itọkasi si apoti ti o ba jẹ ti iru `T`, tabi `None` ti ko ba ṣe bẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // Aabo: kan ṣayẹwo boya a tọka si oriṣi ti o pe, ati pe a le gbarale
            // ti ayẹwo fun iranti ailewu nítorí pé a ti muse Eyikeyi fun gbogbo awọn orisi;ko si awọn idunnu miiran ti o le wa bi wọn yoo ṣe ja pẹlu impl wa.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Pada diẹ ninu itọkasi iyipada si iye apoti ti o ba jẹ ti iru `T`, tabi `None` ti ko ba ṣe bẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // Aabo: kan ṣayẹwo boya a tọka si oriṣi ti o pe, ati pe a le gbarale
            // ti ayẹwo fun iranti ailewu nítorí pé a ti muse Eyikeyi fun gbogbo awọn orisi;ko si awọn idunnu miiran ti o le wa bi wọn yoo ṣe ja pẹlu impl wa.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Siwaju si ọna ti a ṣalaye lori iru `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ati awọn ọna rẹ
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` duro fun idanimọ alailẹgbẹ agbaye fun iru kan.
///
/// `TypeId` kọọkan jẹ ohun aibikita eyiti ko gba laaye ayewo ti ohun ti o wa ninu ṣugbọn o gba awọn iṣẹ ipilẹ bii iṣọpọ oniye, ifiwera, titẹjade, ati fifihan.
///
///
/// `TypeId` kan wa lọwọlọwọ fun awọn iru eyiti o fun ni `'static`, ṣugbọn aropin yii le yọkuro ni future.
///
/// Lakoko ti `TypeId` ṣe imuṣe `Hash`, `PartialOrd`, ati `Ord`, o tọ lati ṣe akiyesi pe awọn elile ati aṣẹ yoo yatọ laarin awọn idasilẹ Rust.
/// Ṣọra ki o gbẹkẹle wọn inu koodu rẹ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Pada ni `TypeId` ti awọn iru yi jeneriki iṣẹ ti a ti instantiated pẹlu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Pada orukọ iru kan bi ege okun.
///
/// # Note
///
/// Eyi ni a pinnu fun lilo aisan.
/// Awọn gangan akoonu ti ati kika ti awọn okun pada ko ba wa ni pato, miiran ju jije a ti o dara ju-akitiyan apejuwe ti awọn iru.
/// Fun apẹẹrẹ, laarin awọn okun ti `type_name::<Option<String>>()` le pada jẹ `"Option<String>"` ati `"std::option::Option<std::string::String>"`.
///
///
/// O yẹ ki a ko ka okun ti o pada lati jẹ idanimọ alailẹgbẹ ti iru bi awọn oriṣi pupọ le ṣe maapu si orukọ iru kanna.
/// Bakan naa, ko si iṣeduro pe gbogbo awọn ẹya oriṣi kan yoo han ninu okun ti o pada: fun apẹẹrẹ, awọn alaye igbesi aye ko si ni lọwọlọwọ.
/// Ni afikun, iṣelọpọ le yipada laarin awọn ẹya ti alakojo.
///
/// Imuse lọwọlọwọ nlo awọn amayederun kanna bi awọn iwadii alakojọ ati debuginfo, ṣugbọn eyi ko ni idaniloju.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Pada orukọ iru ti tokasi-si iye bi gige okun.
/// Eyi kanna bii `type_name::<T>()`, ṣugbọn o le ṣee lo nibiti iru oniyipada kan ko si ni rọọrun.
///
/// # Note
///
/// Eyi ni a pinnu fun lilo aisan.Awọn gangan akoonu ti ati kika ti awọn okun ko ba wa ni pato, miiran ju jije a ti o dara ju-akitiyan apejuwe ti awọn iru.
/// Fun apẹẹrẹ, `type_name_of_val::<Option<String>>(None)` le pada `"Option<String>"` tabi `"std::option::Option<std::string::String>"`, sugbon ko `"foobar"`.
///
/// Ni afikun, iṣelọpọ le yipada laarin awọn ẹya ti alakojo.
///
/// Iṣẹ yii ko yanju awọn nkan trait, itumo pe `type_name_of_val(&7u32 as &dyn Debug)` le pada `"dyn Debug"`, ṣugbọn kii ṣe `"u32"`.
///
/// Ko yẹ ki a ka orukọ irufẹ idanimọ alailẹgbẹ ti iru kan;
/// ọpọlọpọ awọn oriṣi le pin orukọ iru kanna.
///
/// Imuse lọwọlọwọ nlo awọn amayederun kanna bi awọn iwadii alakojọ ati debuginfo, ṣugbọn eyi ko ni idaniloju.
///
/// # Examples
///
/// Ṣe atẹjade odidi odidi ati awọn iru omi loju omi.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}