//! Alakojo intrinsics.
//!
//! Awọn itumọ ti o baamu wa ni `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Awọn ti o baamu const imuṣẹ wa ni `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # const intrinsics
//!
//! Note: eyikeyi ayipada si awọn constness ti intrinsics yẹ ki o wa ni sísọ pẹlu awọn ede egbe.
//! Eyi pẹlu ayipada ninu awọn iduroṣinṣin ti awọn constness.
//!
//! Lati ṣe ohun elo lilo ti ara ni akoko ikojọpọ, ẹnikan nilo lati daakọ imuse lati <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> si `compiler/rustc_mir/src/interpret/intrinsics.rs` ati ṣafikun `#[rustc_const_unstable(feature = "foo", issue = "01234")]` si ojulowo.
//!
//!
//! Ti o ba ti ohun ojulowo wa ni ikure lati wa ni lo lati kan `const fn` pẹlu kan `rustc_const_stable` ro pe, awọn ojulowo ká ro pe gbọdọ jẹ `rustc_const_stable`, ju.
//! Iru ayipada kan ko yẹ ki o le ṣe lai T-Lang ijumọsọrọ, nitori ti o bakes a ẹya-ara sinu awọn ede ti o le wa ko le ṣe replicated ni olumulo koodu lai alakojo support.
//!
//! # Volatiles
//!
//! Awọn iyipada intrinsics pese mosi ti a ti pinnu lati sise lori I/O iranti, eyi ti wa ni ẹri lati ko wa ni reordered nipasẹ awọn alakojo kọja miiran iyipada intrinsics.Wo iwe LLVM lori [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Awọn atomiki intrinsics pese wọpọ atomiki mosi lori ẹrọ ọrọ, pẹlu ọpọ ṣee ṣe iranti orderings.Wọn ṣegbọran awọn itumọ-ọrọ kanna bi C++ 11.Wo awọn LLVM iwe lori [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A awọn ọna refresher lori iranti bere:
//!
//! * Gba, a idankan fun ra a titiipa.Atẹle atẹle ati kikọ le waye lẹhin idena naa.
//! * Tu silẹ, idena fun dasile titiipa kan.Opin Say ati Levin ya ibi ṣaaju ki awọn idankan duro.
//! * Sequentially dédé, sequentially dédé mosi ti wa ni ẹri lati ṣẹlẹ ni ibere.Eyi ni ipo boṣewa fun ṣiṣẹ pẹlu awọn iru atomiki ati pe o jẹ deede si Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Awọn wọnyi ni ilu okeere wa ni lilo fun simplifying ninu-doc ìjápọ
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Aabo: ri `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, wọnyi intrinsics ya aise ifẹnule nitori won mutate aliased iranti, eyi ti o jẹ ko wulo fun boya `&` tabi `&mut`.
    //

    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::SeqCst`] bi awọn mejeeji ni `success` ati `failure` sile.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::Acquire`] bi awọn mejeeji ni `success` ati `failure` sile.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange` nipasẹ gbigbe [`Ordering::Release`] bi `success` ati [`Ordering::Relaxed`] bi awọn ipilẹ `failure`.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::AcqRel`] bi awọn `success` ati [`Ordering::Acquire`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::Relaxed`] bi awọn mejeeji ni `success` ati `failure` sile.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange` nipasẹ gbigbe [`Ordering::SeqCst`] bi `success` ati [`Ordering::Relaxed`] bi awọn ipilẹ `failure`.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::SeqCst`] bi awọn `success` ati [`Ordering::Acquire`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange` nipasẹ gbigbe [`Ordering::Acquire`] bi `success` ati [`Ordering::Relaxed`] bi awọn ipilẹ `failure`.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange` ọna nipa ran [`Ordering::AcqRel`] bi awọn `success` ati [`Ordering::Relaxed`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya diduro ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange_weak` nipasẹ gbigbe [`Ordering::SeqCst`] bi awọn ipo `success` ati `failure` mejeeji.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::Acquire`] bi awọn mejeeji ni `success` ati `failure` sile.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange_weak` nipasẹ gbigbe [`Ordering::Release`] bi `success` ati [`Ordering::Relaxed`] bi awọn ipilẹ `failure`.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::AcqRel`] bi awọn `success` ati [`Ordering::Acquire`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::Relaxed`] bi awọn mejeeji ni `success` ati `failure` sile.
    ///
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::SeqCst`] bi awọn `success` ati [`Ordering::Relaxed`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `compare_exchange_weak` nipasẹ gbigbe [`Ordering::SeqCst`] bi `success` ati [`Ordering::Acquire`] bi awọn ipilẹ `failure`.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::Acquire`] bi awọn `success` ati [`Ordering::Relaxed`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Tọjú a iye ti o ba ti isiyi iye jẹ kanna bi awọn `old` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `compare_exchange_weak` ọna nipa ran [`Ordering::AcqRel`] bi awọn `success` ati [`Ordering::Relaxed`] bi awọn `failure` sile.
    /// Fun apere, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Èyà awọn ti isiyi iye ti awọn ijuboluwole.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `load` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Èyà awọn ti isiyi iye ti awọn ijuboluwole.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `load` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Èyà awọn ti isiyi iye ti awọn ijuboluwole.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `load` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Oja iye ni pàtó iranti ipo.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `store` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Oja iye ni pàtó iranti ipo.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `store` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Oja iye ni pàtó iranti ipo.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `store` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Ṣe tọju iye ni ipo iranti ti a ṣalaye, n pada iye atijọ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `swap` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ṣe tọju iye ni ipo iranti ti a ṣalaye, n pada iye atijọ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `swap` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ṣe tọju iye ni ipo iranti ti a ṣalaye, n pada iye atijọ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `swap` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ṣe tọju iye ni ipo iranti ti a ṣalaye, n pada iye atijọ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `swap` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ṣe tọju iye ni ipo iranti ti a ṣalaye, n pada iye atijọ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `swap` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_add` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_add` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_add` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_add` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Afikun si awọn lọwọlọwọ iye, pada awọn ti tẹlẹ iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `fetch_add` nipa gbigbe [`Ordering::Relaxed`] kọja bi `order`.
    /// Fun apere, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Iyokuro lati isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_sub` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyokuro lati isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_sub` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyokuro lati isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_sub` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyokuro lati isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `fetch_sub` nipasẹ gbigbe [`Ordering::AcqRel`] bi `order`.
    /// Fun apere, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iyokuro lati isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_sub` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ati pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_and` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ati pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_and` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ati pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_and` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ati pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_and` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ati pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `fetch_and` nipa gbigbe [`Ordering::Relaxed`] kọja bi `order`.
    /// Fun apere, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand Bitwise pẹlu iye lọwọlọwọ, n pada iye ti tẹlẹ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`AtomicBool`] iru nipasẹ awọn `fetch_nand` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand Bitwise pẹlu iye lọwọlọwọ, n pada iye ti tẹlẹ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`AtomicBool`] iru nipasẹ awọn `fetch_nand` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand Bitwise pẹlu iye lọwọlọwọ, n pada iye ti tẹlẹ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`AtomicBool`] iru nipasẹ awọn `fetch_nand` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand Bitwise pẹlu iye lọwọlọwọ, n pada iye ti tẹlẹ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`AtomicBool`] iru nipasẹ awọn `fetch_nand` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand Bitwise pẹlu iye lọwọlọwọ, n pada iye ti tẹlẹ.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`AtomicBool`] iru nipasẹ awọn `fetch_nand` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise tabi pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa lori awọn oriṣi [`atomic`] nipasẹ ọna `fetch_or` nipa gbigbe [`Ordering::SeqCst`] kọja bi `order`.
    /// Fun apere, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise tabi pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_or` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise tabi pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_or` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise tabi pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_or` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise tabi pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_or` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_xor` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_xor` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_xor` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_xor` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor pẹlu awọn ti isiyi iye, pada awọn ti tẹlẹ iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] orisi nipasẹ awọn `fetch_xor` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// O pọju pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kere pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Ẹya diduro ti ojulowo yii wa lori awọn oriṣi odidi ti a fowo si [`atomic`] nipasẹ ọna `fetch_min` nipa gbigbe [`Ordering::SeqCst`] bi `order`.
    /// Fun apere, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye nipa lilo a wole lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] wole integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kere pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Ẹya diduro ti ojulowo yii wa lori awọn oriṣi odidi odidi ti a ko fi orukọ silẹ [`atomic`] nipasẹ ọna `fetch_min` nipa gbigbe [`Ordering::Release`] kọja bi `order`.
    /// Fun apere, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_min` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kere pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Ẹya diduro ti ojulowo yii wa lori awọn oriṣi odidi odidi ti a ko fi orukọ silẹ [`atomic`] nipasẹ ọna `fetch_min` nipa gbigbe [`Ordering::Relaxed`] kọja bi `order`.
    /// Fun apere, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// O pọju pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Acquire`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Release`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// O pọju pẹlu awọn ti isiyi iye lilo ohun unsigned lafiwe.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa lori [`atomic`] unsigned integer orisi nipasẹ awọn `fetch_max` ọna nipa ran [`Ordering::Relaxed`] bi awọn `order`.
    /// Fun apere, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// The `prefetch` ojulowo ni a ofiri si awọn koodu monomono lati fi a prefetch ẹkọ ti o ba ti ni atilẹyin;bibẹkọ, o jẹ a-op.
    /// Prefetches ni ko si ipa lori awọn ihuwasi ti awọn eto sugbon le yi awọn oniwe-išẹ abuda.
    ///
    /// The `locality` ariyanjiyan gbọdọ jẹ kan ibakan odidi ati ki o jẹ a ti igba isinyi agbegbe specifier orisirisi lati (0), ko si agbegbe, to (3), lalailopinpin agbegbe pa ni kaṣe.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// The `prefetch` ojulowo ni a ofiri si awọn koodu monomono lati fi a prefetch ẹkọ ti o ba ti ni atilẹyin;bibẹkọ, o jẹ a-op.
    /// Prefetches ni ko si ipa lori awọn ihuwasi ti awọn eto sugbon le yi awọn oniwe-išẹ abuda.
    ///
    /// The `locality` ariyanjiyan gbọdọ jẹ kan ibakan odidi ati ki o jẹ a ti igba isinyi agbegbe specifier orisirisi lati (0), ko si agbegbe, to (3), lalailopinpin agbegbe pa ni kaṣe.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// The `prefetch` ojulowo ni a ofiri si awọn koodu monomono lati fi a prefetch ẹkọ ti o ba ti ni atilẹyin;bibẹkọ, o jẹ a-op.
    /// Prefetches ni ko si ipa lori awọn ihuwasi ti awọn eto sugbon le yi awọn oniwe-išẹ abuda.
    ///
    /// The `locality` ariyanjiyan gbọdọ jẹ kan ibakan odidi ati ki o jẹ a ti igba isinyi agbegbe specifier orisirisi lati (0), ko si agbegbe, to (3), lalailopinpin agbegbe pa ni kaṣe.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// The `prefetch` ojulowo ni a ofiri si awọn koodu monomono lati fi a prefetch ẹkọ ti o ba ti ni atilẹyin;bibẹkọ, o jẹ a-op.
    /// Prefetches ni ko si ipa lori awọn ihuwasi ti awọn eto sugbon le yi awọn oniwe-išẹ abuda.
    ///
    /// The `locality` ariyanjiyan gbọdọ jẹ kan ibakan odidi ati ki o jẹ a ti igba isinyi agbegbe specifier orisirisi lati (0), ko si agbegbe, to (3), lalailopinpin agbegbe pa ni kaṣe.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ogiri atomu.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa ni [`atomic::fence`] nipa gbigbe [`Ordering::SeqCst`] bi `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ogiri atomu.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa ni [`atomic::fence`] nipa gbigbe [`Ordering::Acquire`] bi `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ogiri atomu.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa ni [`atomic::fence`] nipa gbigbe [`Ordering::Release`] bi `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ogiri atomu.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii wa ni [`atomic::fence`] nipa gbigbe [`Ordering::AcqRel`] bi `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Idiwọ iranti alakojo-nikan.
    ///
    /// Memory accesses yoo ko wa ni reordered kọja yi idankan nipasẹ awọn alakojo, sugbon ko si ilana yoo wa ni emitted fun o.
    /// Eleyi jẹ deede fun mosi lori kanna o tẹle ti o le wa preempted, gẹgẹ bi awọn nigba ti sere pelu pẹlu ifihan handlers.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa ni [`atomic::compiler_fence`] nipa ran [`Ordering::SeqCst`] bi awọn `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Idiwọ iranti alakojo-nikan.
    ///
    /// Memory accesses yoo ko wa ni reordered kọja yi idankan nipasẹ awọn alakojo, sugbon ko si ilana yoo wa ni emitted fun o.
    /// Eleyi jẹ deede fun mosi lori kanna o tẹle ti o le wa preempted, gẹgẹ bi awọn nigba ti sere pelu pẹlu ifihan handlers.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa ni [`atomic::compiler_fence`] nipa ran [`Ordering::Acquire`] bi awọn `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Idiwọ iranti alakojo-nikan.
    ///
    /// Memory accesses yoo ko wa ni reordered kọja yi idankan nipasẹ awọn alakojo, sugbon ko si ilana yoo wa ni emitted fun o.
    /// Eleyi jẹ deede fun mosi lori kanna o tẹle ti o le wa preempted, gẹgẹ bi awọn nigba ti sere pelu pẹlu ifihan handlers.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa ni [`atomic::compiler_fence`] nipa ran [`Ordering::Release`] bi awọn `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Idiwọ iranti alakojo-nikan.
    ///
    /// Memory accesses yoo ko wa ni reordered kọja yi idankan nipasẹ awọn alakojo, sugbon ko si ilana yoo wa ni emitted fun o.
    /// Eleyi jẹ deede fun mosi lori kanna o tẹle ti o le wa preempted, gẹgẹ bi awọn nigba ti sere pelu pẹlu ifihan handlers.
    ///
    /// Awọn diduro ti ikede yi ojulowo wa ni [`atomic::compiler_fence`] nipa ran [`Ordering::AcqRel`] bi awọn `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magic ojulowo ti o derives awọn oniwe-itumo lati eroja so si awọn iṣẹ.
    ///
    /// Fun apẹẹrẹ, ṣiṣan data nlo eleyi lati fa awọn ifẹnti aimi ki `rustc_peek(potentially_uninitialized)` yoo ṣe ayẹwo lẹẹmeji pe ṣiṣan data ṣe iṣiro nitootọ pe o jẹ aibikita ni aaye yẹn ni ṣiṣakoso iṣakoso.
    ///
    ///
    /// Yi ojulowo yẹ ki o wa lo ti ita ti awọn alakojo.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborts awọn ipaniyan ti awọn ilana.
    ///
    /// Ẹya olumulo diẹ sii ati iduroṣinṣin ti išišẹ yii jẹ [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Sọ fun olufunni pe aaye yii ninu koodu ko le de ọdọ, n jẹ ki awọn iṣapeye siwaju sii.
    ///
    /// NB, eyi yatọ si macro `unreachable!()`: Ko dabi macro, eyiti panics nigbati o ba ṣiṣẹ, o jẹ *ihuwasi ti a ko ṣalaye* lati de ọdọ koodu ti o samisi pẹlu iṣẹ yii.
    ///
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii jẹ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Ṣe ifitonileti fun idaniloju pe ipo kan jẹ otitọ nigbagbogbo.
    /// Ti ipo naa ba jẹ eke, ihuwasi naa ko ṣalaye.
    ///
    /// Ko si koodu ti ipilẹṣẹ fun ojulowo yii, ṣugbọn aṣapẹrẹ yoo gbiyanju lati tọju rẹ (ati ipo rẹ) laarin awọn igbasilẹ, eyiti o le dabaru pẹlu iṣapeye ti koodu agbegbe ati dinku iṣẹ.
    /// O yẹ ki o ko ṣee lo bi awọn ko baramu le ti wa ni awari nipa awọn optimizer lori awọn oniwe-ara, tabi ti o ba ti o ko ni jeki eyikeyi significant optimizations.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tanilolobo si alakojo ti branch majemu jẹ seese lati wa ni otitọ.
    /// Pada ni iye kọja si o.
    ///
    /// Lilo eyikeyi miiran ju pẹlu `if` gbólóhùn yoo jasi ko ni ohun ipa.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Awọn itọkasi si akopọ pe ipo branch le jẹ irọ.
    /// Pada ni iye kọja si o.
    ///
    /// Lilo eyikeyi miiran ju pẹlu `if` gbólóhùn yoo jasi ko ni ohun ipa.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Executes a breakpoint pakute, fun ayewo nipa a debugger.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn breakpoint();

    /// Awọn iwọn ti a tẹ ni awọn baiti.
    ///
    /// Ni pataki diẹ sii, eyi ni aiṣedeede ninu awọn baiti laarin awọn ohun itẹlera ti iru kanna, pẹlu fifẹ titete.
    ///
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Iṣeduro ti o kere ju ti iru kan.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii jẹ [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Awọn afihan titete a iru.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Awọn iwọn ti awọn rannileti iye ni awọn baiti.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Awọn ti a beere titete ti awọn rannileti iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Gba pẹpẹ okun aimi ti o ni orukọ iru kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ni idanimọ eyiti o jẹ alailẹgbẹ agbaye si oriṣi pàtó kan.
    /// Iṣẹ yii yoo pada iye kanna fun iru laibikita eyikeyi crate ti o pe ni.
    ///
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A oluso fun awọn lewu awọn iṣẹ ti o le ko lailai ṣe ti o ba ti `T` ni uninhabited:
    /// Eleyi yoo statically boya panic, tabi ṣe ohunkohun.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A oluso fun awọn lewu awọn iṣẹ ti o le ko lailai ṣe ti o ba ti `T` ko ni laye odo-initialization: Eleyi yoo statically boya panic, tabi ṣe ohunkohun.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn assert_zero_valid<T>();

    /// A oluso fun awọn lewu awọn iṣẹ ti o le ko lailai ṣe ti o ba ti `T` ni o ni invalid bit elo: Eleyi yoo statically boya panic, tabi ṣe ohunkohun.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn assert_uninit_valid<T>();

    /// N ni a tọka si a aimi `Location` o nfihan ibi ti o ti a npe ni.
    ///
    /// Ṣe akiyesi lilo [`core::panic::Location::caller`](crate::panic::Location::caller) dipo.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Rare a iye jade ti dopin lai nṣiṣẹ ju lẹ pọ.
    ///
    /// Eyi wa daada fun [`mem::forget_unsized`];deede `forget` nlo `ManuallyDrop` dipo.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Ṣe atunkọ awọn ipin ti iye ti iru kan bii oriṣi miiran.
    ///
    /// Awọn oriṣi mejeeji gbọdọ ni iwọn kanna.
    /// Bẹni atilẹba, tabi abajade, le jẹ [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` jẹ deede semantically si iṣipopada iṣipopada ti iru kan sinu omiran.O idaako awọn die-die lati awọn orisun iye sinu nlo iye, ki o si gbàgbé atilẹba.
    /// O jẹ deede si C's `memcpy` labẹ iho, gẹgẹ bi `transmute_copy`.
    ///
    /// Nitori `transmute` ni a nipasẹ-iye isẹ, titete ti awọn *transmuted iye ara wọn* ni ko kan ibakcdun.
    /// Bi pẹlu eyikeyi iṣẹ miiran, akopọ tẹlẹ ti rii daju pe `T` ati `U` ti wa ni deedee deede.
    /// Sibẹsibẹ, nigbati o ba n gbe awọn iye ti *tọka si ni ibomiiran*(gẹgẹbi awọn itọkasi, awọn itọkasi, awọn apoti…), olupe naa ni lati rii daju pe tito deede awọn iye to tọka si.
    ///
    /// `transmute` ni **iyalẹnu** lewu.Nibẹ ni o wa kan tiwa ni nọmba kan ti ona lati fa [undefined behavior][ub] pẹlu iṣẹ yi.`transmute` yẹ ki o jẹ ibi isinmi to kẹhin.
    ///
    /// The [nomicon](../../nomicon/transmutes.html) ni o ni afikun iwe.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Nibẹ ni o wa kan diẹ ohun ti `transmute` jẹ gan wulo fun.
    ///
    /// Titan a ijuboluwole sinu kan iṣẹ ijuboluwole.Eleyi jẹ *ko* šee to ero ibi ti iṣẹ ifẹnule ati data ifẹnule ni orisirisi awọn titobi.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Faagun igbesi aye rẹ, tabi kikuru igbesi aye ailopin.Eyi ti ni ilọsiwaju, Rust ti ko ni ailewu pupọ!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Maṣe banujẹ: ọpọlọpọ awọn lilo ti `transmute` le ṣee ṣe nipasẹ awọn ọna miiran.
    /// Ni isalẹ awọn ohun elo ti o wọpọ ti `transmute` eyiti o le rọpo pẹlu awọn itumọ ailewu.
    ///
    /// Titan aise bytes(`&[u8]`) to `u32`, `f64`, ati be be .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // lo `u32::from_ne_bytes` dipo
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // tabi lo `u32::from_le_bytes` tabi `u32::from_be_bytes` lati tokasi awọn endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Titan ijuboluwole sinu `usize` kan:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Lo ohun `as` simẹnti dipo
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Titan a `*mut T` sinu ohun `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Lo a reborrow dipo
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Titan `&mut T` sinu `&mut U` kan:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Bayi, fi papo `as` ati reborrowing, akiyesi awọn chaining ti `as` `as` ni ko transitive
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Titan ohun `&str` sinu ohun `&[u8]`:
    ///
    /// ```
    /// // eyi kii ṣe ọna ti o dara lati ṣe eyi.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // O le lo `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Tabi, kan lo okun baiti kan, ti o ba ni iṣakoso lori gegebi okun naa
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Titan `Vec<&T>` sinu `Vec<Option<&T>>` kan.
    ///
    /// Lati transmute ni akojọpọ iru awọn ti awọn awọn akoonu ti a gba eiyan, o gbọdọ rii daju lati ko rú eyikeyi ninu awọn eiyan ká invariants.
    /// Fun `Vec`, eyi tumọ si pe iwọn *ati titete* ti awọn ori inu gbọdọ baamu.
    /// Miiran awọn apoti ki o le gbekele lori awọn iwọn ti awọn iru, titete, tabi ani awọn `TypeId`, ninu eyi ti irú transmuting yoo ko ni le ṣee ṣe ni gbogbo lai rú awọn eiyan invariants.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // ẹda oniye awọn vector bi a yoo tun lo wọn nigbamii
    /// let v_clone = v_orig.clone();
    ///
    /// // Lilo transmute: eyi gbekele lori awọn lalaïkomogba ti data ifilelẹ ti awọn `Vec`, ti o jẹ kan buburu agutan ati ki o le fa aisọye Ihuwasi.
    /////
    /// // Sibẹsibẹ, kii ṣe ẹda-ẹda.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Eyi ni imọran, ọna ailewu.
    /// // O ko ni da gbogbo vector, tilẹ, sinu titun kan orun.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Eleyi ni awọn to dara ti ko si-daakọ, lewu ọna ti "transmuting" a `Vec`, lai gbigbe ara lori awọn data akọkọ.
    /// // Dipo ti gangan pipe `transmute`, a ṣe kan ijuboluwole simẹnti, sugbon ni awọn ofin ti jijere awọn atilẹba akojọpọ iru (`&i32`) si titun kan (`Option<&i32>`), yi o ni gbogbo awọn kanna caveats.
    /////
    /// // Yato si awọn alaye ti pese loke, o tun kan si alagbawo awọn [`from_raw_parts`] iwe.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Ṣe imudojuiwọn eyi nigbati vec_into_raw_parts ti wa ni diduro.
    ///     // Rii daju pe atilẹba vector ko lọ silẹ.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Imulo awon `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Nibẹ ni o wa ọpọ ona lati ṣe eyi, ki o si nibẹ ni o wa ọpọ awọn iṣoro pẹlu awọn wọnyi (transmute) ọna.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // akọkọ: transmute kii ṣe iru ailewu;gbogbo awọn ti o sọwedowo ni wipe T ati
    ///         // U ni o wa ti kanna iwọn.
    ///         // Ẹlẹẹkeji, nihin, o ni awọn itọkasi iyipada meji ti o tọka si iranti kanna.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Eleyi olubwon xo ti iru isoro aabo;`&mut *` yoo* nikan *fun o ohun `&mut T` lati `&mut T` tabi `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // sibẹsibẹ, o si tun ni meji mutable jo ntokasi si kanna iranti.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Eyi ni bii ile-ikawe boṣewa ṣe.
    /// // Eyi ni ọna ti o dara julọ, ti o ba nilo lati ṣe nkan bi eleyi
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Eyi ni awọn itọka iyipada muti mẹta ti o tọka si iranti kanna.`slice`, awọn rvalue ret.0, ati awọn rvalue ret.1.
    ///         // `slice` a ko lo rara lẹhin `let ptr = ...`, ati nitorinaa ẹnikan le ṣe itọju rẹ bi "dead", ati nitorinaa, iwọ nikan ni awọn ege gige ti o le yipada meji.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Nigba ti yi mu ki awọn ojulowo const idurosinsin, a ni diẹ ninu awọn aṣa koodu ni const fn
    // awọn sọwedowo ti o dẹkun lilo rẹ laarin `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Pada `true` ti iru gangan ti a fun bi `T` nbeere fifọ pọ;pada `false` ti iru gangan ti a pese fun `T` awọn imuse `Copy`.
    ///
    ///
    /// Ti o ba ti gangan Iru bẹni nilo ju lẹ pọ tabi ọlọnà `Copy`, ki o si awọn pada iye ti yi iṣẹ ni lalaïkomogba ti.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii jẹ [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ṣe iṣiro aiṣedeede lati ọdọ ijuboluwole kan.
    ///
    /// Yi ti ni muse bi ohun ojulowo lati yago fun ni jijere si ati lati ẹya odidi, niwon awọn iyipada yoo jabọ kuro aliasing alaye.
    ///
    /// # Safety
    ///
    /// Mejeji awọn ti o bere ati Abajade ijuboluwole gbọdọ jẹ boya ni igboro tabi ọkan baiti ti o ti kọja opin ti ẹya soto ohun na.
    /// Ti o ba ti boya ijuboluwole ni jade ti igboro tabi isiro kún waye ki o si eyikeyi siwaju lilo ti awọn pada iye yoo ja si ni aisọye ihuwasi.
    ///
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calculates awọn aiṣedeede lati kan ijuboluwole, oyi murasilẹ.
    ///
    /// Eyi ni imuse bi ojulowo lati yago fun iyipada si ati lati odidi odidi kan, nitori iyipada ṣe idiwọ awọn iṣapeye kan.
    ///
    /// # Safety
    ///
    /// Ko awọn `offset` ojulowo, yi ojulowo ko ni ihamọ awọn Abajade ijuboluwole si ojuami sinu tabi ọkan baiti ti o ti kọja opin ti ẹya soto ohun, ati awọn ti o murasilẹ pẹlu meji ká iranlowo isiro.
    /// Abajade iye ni ko dandan wulo to wa ni lo lati kosi wiwọle iranti.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Deede si awọn yẹ `llvm.memcpy.p0i8.0i8.*` ojulowo, pẹlu kan iwọn ti `count`*`size_of::<T>()` ati awọn ẹya titete
    ///
    /// `min_align_of::<T>()`
    ///
    /// Awọn iyipada paramita ti ṣeto si `true`, ki o yoo wa ko le iṣapeye jade ayafi ti iwọn jẹ dogba si odo.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ni ibamu si ojulowo `llvm.memmove.p0i8.0i8.*` ti o yẹ, pẹlu iwọn ti `count* size_of::<T>()` ati titete ti
    ///
    /// `min_align_of::<T>()`
    ///
    /// Awọn iyipada paramita ti ṣeto si `true`, ki o yoo wa ko le iṣapeye jade ayafi ti iwọn jẹ dogba si odo.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ni ibamu si ojulowo `llvm.memset.p0i8.*` ti o yẹ, pẹlu iwọn ti `count* size_of::<T>()` ati titete ti `min_align_of::<T>()`.
    ///
    ///
    /// Awọn iyipada paramita ti ṣeto si `true`, ki o yoo wa ko le iṣapeye jade ayafi ti iwọn jẹ dogba si odo.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Ṣe a iyipada fifuye lati `src` ijuboluwole.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Ṣe a iyipada itaja si awọn `dst` ijuboluwole.
    ///
    /// Ẹya iduroṣinṣin ti ojulowo yii jẹ [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Ṣe a iyipada fifuye lati `src` ijuboluwole The ijuboluwole ti ko ba beere lati wa ni deedee.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Ṣe a iyipada itaja si awọn `dst` ijuboluwole.
    /// A ko nilo ijuboluwole lati wa ni deede.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Pada ti awọn square root ti ẹya `f32`
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Pada ti awọn square root ti ẹya `f64`
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ji ohun `f32` si ohun odidi agbara.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ji ohun `f64` si ohun odidi agbara.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Pada ni lai ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Pada ni lai ti ẹya `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Pada cosine ti `f32` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Pada awọn cosine ti ẹya `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ji ohun `f32` si ohun `f32` agbara.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ji ohun `f64` si ohun `f64` agbara.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Pada ni opolopo ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Pada ni opolopo ti ẹya `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Padà 2 dide si agbara ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Padà 2 dide si agbara ti ẹya `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Pada awọn adayeba logarithm ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Pada logarithm adayeba ti `f64` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Pada awọn mimọ 10 logarithm ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Pada logarithm ipilẹ 10 ti `f64` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Pada awọn mimọ 2 logarithm ti ẹya `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Pada awọn mimọ 2 logarithm ti ẹya `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Pada `a * b + c` fun `f32` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Pada `a * b + c` fun awọn iye `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Pada iye idi ti `f32` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Pada iye idi ti `f64` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Pada iye ti awọn iye `f32` meji.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Pada kere ti meji `f64` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Pada awọn ti o pọju ti awọn meji `f32` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Pada o pọju ti awọn iye `f64` meji.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Dakọ ami lati `y` si `x` fun awọn iye `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Idaako awọn àmi lati `y` to `x` fun `f64` iye.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Pada odidi titobiju ti o kere ju tabi dogba si `f32` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Pada odidi titobiju ti o kere ju tabi dogba si `f64` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Pada awọn kere odidi tobi ju tabi dogba si ohun `f32`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Pada awọn kere odidi tobi ju tabi dogba si ohun `f64`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Pada apa odidi ti `f32` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Pada apa odidi ti `f64` kan.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Pada sunmọ odidi si ohun `f32`.
    /// O le gbé ohun inexact lilefoofo-ojuami sile ti o ba ti ariyanjiyan ni ko ohun odidi.
    pub fn rintf32(x: f32) -> f32;
    /// Ṣe idapo odidi to sunmọ julọ si `f64` kan.
    /// O le gbé ohun inexact lilefoofo-ojuami sile ti o ba ti ariyanjiyan ni ko ohun odidi.
    pub fn rintf64(x: f64) -> f64;

    /// Pada sunmọ odidi si ohun `f32`.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ṣe idapo odidi to sunmọ julọ si `f64` kan.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Pada sunmọ odidi si ohun `f32`.Iyipo idaji-ọna igba kuro lati odo.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Pada sunmọ odidi si ohun `f64`.Iyipo idaji-ọna igba kuro lati odo.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Leefofo afikun ti o fun laaye optimizations da lori aljebra ofin.
    /// Le ro pe awọn igbewọle ti wa ni opin.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Leefofo iyokuro ti o fun laaye optimizations da lori aljebra ofin.
    /// Le ro pe awọn igbewọle ti wa ni opin.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Leefofo isodipupo ti o fun laaye optimizations da lori aljebra ofin.
    /// Le ro pe awọn igbewọle ti wa ni opin.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Pinpin leefofo ti o fun laaye awọn iṣapeye ti o da lori awọn ofin aljebra.
    /// Le ro pe awọn igbewọle ti wa ni opin.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Leefofo ku ti o fun laaye optimizations da lori aljebra ofin.
    /// Le ro pe awọn igbewọle ti wa ni opin.
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Lọkan padà pẹlu LLVM ká fptoui/fptosi, eyi ti o le pada undef fun iye jade ti ibiti o
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Diduro bi [`f32::to_int_unchecked`] ati [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Pada nọmba awọn idinku ti a ṣeto sinu iru nọmba odidi `T` kan
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `count_ones`.
    /// Fun apere,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Pada awọn nọmba ti asiwaju unset die-die (zeroes) ni ohun odidi iru `T`.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `leading_zeros` ọna.
    /// Fun apere,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// An `x` pẹlu iye `0` yoo pada awọn bit iwọn ti `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Bii `ctlz`, ṣugbọn afikun-ailewu bi o ṣe pada `undef` nigba ti a fun `x` pẹlu iye `0`.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Ṣe ipadabọ nọmba ti awọn idinku ti ko tọ si (zeroes) ninu iru nọmba odidi kan `T`.
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `trailing_zeros`.
    /// Fun apere,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` kan pẹlu iye `0` yoo da iwọn bit ti `T` pada:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Bi `cttz`, sugbon afikun-lewu bi o ti pada `undef` nigba ti fi fun ẹya `x` pẹlu iye `0`.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Yi awọn baiti pada ni iru nọmba odidi kan `T`.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `swap_bytes` ọna.
    /// Fun apere,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Reverses awọn die-die ni ohun odidi iru `T`.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `reverse_bits` ọna.
    /// Fun apere,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Ṣe ẹnikeji odidi afikun.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `overflowing_add` ọna.
    /// Fun apere,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ṣe ẹnikeji odidi iyokuro
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `overflowing_sub` ọna.
    /// Fun apere,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ṣe ẹnikeji odidi isodipupo
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `overflowing_mul`.
    /// Fun apere,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Ṣe pipin deede, ti o mu ki ihuwasi ti a ko ṣalaye nibiti `x % y != 0` tabi `y == 0` tabi `x == T::MIN && y == -1`
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Ṣe ohun sisoô pipin, Abajade ni aisọye iwa ibi ti `y == 0` tabi `x == T::MIN && y == -1`
    ///
    ///
    /// Safe wrappers fun yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `checked_div` ọna.
    /// Fun apere,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Pada iyokù ti pipin ti ko ṣayẹwo, ti o mu ki ihuwasi ti ko ṣalaye nigbati `y == 0` tabi `x == T::MIN && y == -1`
    ///
    ///
    /// Safe wrappers fun yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `checked_rem` ọna.
    /// Fun apere,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Ṣe ohun sisoô osi naficula, Abajade ni aisọye iwa nigbati `y < 0` tabi `y >= N`, ibi ti N ni awọn iwọn ti T ni die-die.
    ///
    ///
    /// Safe wrappers fun yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `checked_shl` ọna.
    /// Fun apere,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Ṣe ohun sisoô ọtun naficula, Abajade ni aisọye iwa nigbati `y < 0` tabi `y >= N`, ibi ti N ni awọn iwọn ti T ni die-die.
    ///
    ///
    /// Safe wrappers fun yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `checked_shr` ọna.
    /// Fun apere,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Pada awọn esi ti ohun sisoô afikun, Abajade ni aisọye iwa nigbati `x + y > T::MAX` tabi `x + y < T::MIN`.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Pada awọn esi ti ohun sisoô ìyọkúrò, Abajade ni aisọye iwa nigbati `x - y > T::MAX` tabi `x - y < T::MIN`.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Pada abajade ti isodipupo ti a ko ṣayẹwo, ti o mu ki ihuwasi ti ko ṣalaye nigbati `x *y > T::MAX` tabi `x* y < T::MIN`.
    ///
    ///
    /// Yi ojulowo ko ni ni a idurosinsin counterpart.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Performs n yi osi.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `rotate_left` ọna.
    /// Fun apere,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Ṣe n yi ọtun.
    ///
    /// Awọn ẹya diduro ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `rotate_right`.
    /// Fun apere,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Padà (a + b) Mod 2 <sup>N,</sup> ibi ti N ni awọn iwọn ti T ni die-die.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `wrapping_add` ọna.
    /// Fun apere,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Awọn ipadabọ (a, b) mod 2 <sup>N</sup>, nibiti N jẹ iwọn T ninu awọn idinku.
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `wrapping_sub`.
    /// Fun apere,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Awọn ipadabọ (a * b) moodi 2 <sup>N</sup>, nibiti N jẹ iwọn ti T ninu awọn idinku.
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `wrapping_mul`.
    /// Fun apere,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Computes `a + b`, saturating ni nomba igboro.
    ///
    /// Awọn ẹya iduroṣinṣin ti ojulowo yii wa lori awọn ipilẹṣẹ odidi nipasẹ ọna `saturating_add`.
    /// Fun apere,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Computes `a - b`, saturating ni nomba igboro.
    ///
    /// Awọn diduro awọn ẹya ti yi ojulowo wa o si wa lori awọn odidi primitives nipasẹ awọn `saturating_sub` ọna.
    /// Fun apere,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Pada iye ti iyasoto fun iyatọ ninu 'v';
    /// ti o ba ti `T` ni o ni ko discriminant, ba pada `0`.
    ///
    /// Awọn diduro ti ikede yi ojulowo ni [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Padà awọn nọmba ti aba ti awọn iru `T` lé to a `usize`;
    /// ti o ba ti `T` ni o ni ko aba, ba pada `0`.Uninhabited aba ti yoo wa ni kà.
    ///
    /// Awọn to-o wa ni-diduro ti ikede yi ojulowo ni [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ká "try catch" múu eyi ti o invokes awọn iṣẹ ijuboluwole `try_fn` pẹlu awọn data ijuboluwole `data`.
    ///
    /// Awọn kẹta ariyanjiyan ni iṣẹ kan ti a npe ni ti o ba ti a panic sẹlẹ.
    /// Iṣẹ yi gba awọn data ijuboluwole ati ki o kan ijuboluwole si awọn afojusun-kan pato sile ohun ti a mu.
    ///
    /// Fun alaye siwaju sii wo awọn alakojo ká orisun bi daradara bi std ká apeja imuse.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Ipele a `!nontemporal` itaja gẹgẹ LLVM (wo wọn docs).
    /// Jasi yoo ko di idurosinsin.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Wo iwe ti `<*const T>::offset_from` fun awọn alaye.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Wo iwe ti `<*const T>::guaranteed_eq` fun awọn alaye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Wo iwe ti `<*const T>::guaranteed_ne` fun awọn alaye.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Allocate ni sakojo akoko.Ko yẹ ki o pe ni asiko asiko.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Diẹ ninu awọn iṣẹ ti wa ni telẹ nibi nitori nwọn lairotẹlẹ ni se wa ni yi module on idurosinsin.
// Wo <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` tun ṣubu sinu ẹka yii, ṣugbọn ko le fi ipari si nitori ayẹwo ti `T` ati `U` ni iwọn kanna.)
//

/// Awọn iṣayẹwo boya `ptr` wa ni deede ṣe deede pẹlu ọwọ si `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Awọn ẹda Awọn baiti `count *size_of::<T>()` lati `src` si `dst`.Awọn orisun ati ki o nlo gbọdọ* ko * ni lqkan.
///
/// Fun awọn ẹkun ni ti iranti eyi ti o le ni lqkan, lo [`copy`] dipo.
///
/// `copy_nonoverlapping` ni semantically deede si C ká [`memcpy`], ṣugbọn pẹlu awọn ariyanjiyan ibere swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `src` gbọdọ jẹ [valid] fun Say ti `count * size_of::<T>()` baiti.
///
/// * `dst` gbọdọ jẹ [valid] fun Levin ti `count * size_of::<T>()` baiti.
///
/// * Mejeeji `src` ati `dst` gbọdọ wa ni deede.
///
/// * Ekun ti iranti ti o bẹrẹ ni `src` pẹlu iwọn ti `ka *
///   size_of: :<T>() `Baiti gbọdọ *ko* ni lqkan pẹlu awọn ekun ti iranti bẹrẹ ni `dst` pẹlu kanna iwọn.
///
/// Bi [`read`], `copy_nonoverlapping` ṣẹda a bitwise daakọ ti `T`, laibikita boya `T` ni [`Copy`].
/// Ti `T` kii ṣe [`Copy`], lilo *mejeeji* awọn iye ni agbegbe ti o bẹrẹ ni `*src` ati agbegbe ti o bẹrẹ ni `* dst` le [violate memory safety][read-ownership].
///
///
/// Akọsilẹ ti paapa ti o ba fe ni dakọ iwọn (`ka * size_of: :<T>() ') Ni `0`, awọn ifẹnule gbọdọ jẹ ti kii-NULL ati ki o daradara deedee.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ọwọ se [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// E gbogbo awọn eroja ti `src` sinu `dst`, nlọ `src` sofo.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Rii daju wipe `dst` ni o ni to agbara lati mu gbogbo awọn ti `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ipe lati ṣe aiṣedeede jẹ ailewu nigbagbogbo nitori `Vec` kii yoo pin diẹ sii ju awọn baiti `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` laisi sisọ awọn akoonu rẹ silẹ.
///         // A ṣe eyi ni akọkọ, lati yago fun awọn iṣoro bi o ba jẹ pe nkan siwaju si isalẹ panics.
///         src.set_len(0);
///
///         // Awọn meji awọn ẹkun ni ko le ni lqkan nitori mutable jo se ko inagijẹ, ati meji ti o yatọ vectors le ko ara kanna iranti.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Leti `dst` ti o bayi Oun ni awọn akoonu ti ti `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ṣe awọn wọnyi sọwedowo nikan ni run akoko
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ko panicking lati pa codegen ikolu kere.
        abort();
    }*/

    // Aabo: Adehun aabo fun `copy_nonoverlapping` gbọdọ jẹ
    // ọwọ si nipa awọn olupe ti.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Idaako `count * size_of::<T>()` baiti lati `src` to `dst`.Orisun ati ibi-ajo le ṣapọ.
///
/// Ti o ba ti orisun ati nlo yoo *kò* ni lqkan, [`copy_nonoverlapping`] le ṣee lo dipo.
///
/// `copy` ni semantically deede si C ká [`memmove`], ṣugbọn pẹlu awọn ariyanjiyan ibere swapped.
/// Didaakọ waye bi ẹni pe a daakọ awọn baiti lati `src` si ọna igba diẹ lẹhinna dakọ lati ori ila si `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `src` gbọdọ jẹ [valid] fun Say ti `count * size_of::<T>()` baiti.
///
/// * `dst` gbọdọ jẹ [valid] fun Levin ti `count * size_of::<T>()` baiti.
///
/// * Mejeeji `src` ati `dst` gbọdọ wa ni deede.
///
/// Bi [`read`], `copy` ṣẹda a bitwise daakọ ti `T`, laibikita boya `T` ni [`Copy`].
/// Ti o ba ti `T` ni ko [`Copy`], lilo awọn mejeeji ni iye ni ekun bẹrẹ ni `*src` ati awọn ekun bẹrẹ ni `* dst` le [violate memory safety][read-ownership].
///
///
/// Akọsilẹ ti paapa ti o ba fe ni dakọ iwọn (`ka * size_of: :<T>() ') Ni `0`, awọn ifẹnule gbọdọ jẹ ti kii-NULL ati ki o daradara deedee.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Daradara ṣẹda a Rust vector lati ẹya lewu saarin:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` gbọdọ wa ni deede ṣe deede fun iru rẹ ati ti kii-odo.
/// /// * `ptr` gbọdọ jẹ wulo fun Say ti `elts` contiguous eroja ti iru `T`.
/// /// * Awon eroja kò gbọdọ ṣee lo lẹhin pipe iṣẹ yi ayafi ti `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // Aabo: Wa precondition idaniloju awọn orisun ti wa ni deedee ati wulo,
///     // ati `Vec::with_capacity` ṣe idaniloju pe a ni aaye lilo lati kọ wọn.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // Aabo: A da o pẹlu yi Elo agbara sẹyìn,
///     // ati awọn ti tẹlẹ `copy` ti initialized wọnyi eroja.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ṣe awọn wọnyi sọwedowo nikan ni run akoko
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ko panicking lati pa codegen ikolu kere.
        abort();
    }*/

    // Aabo: aabo guide fun `copy` gbọdọ wa ni ọwọ si nipa awọn olupe ti.
    unsafe { copy(src, dst, count) }
}

/// Ṣeto awọn baiti `count * size_of::<T>()` ti iranti bẹrẹ ni `dst` si `val`.
///
/// `write_bytes` ni iru si C ká [`memset`], ṣugbọn kn `count * size_of::<T>()` baiti to `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `dst` gbọdọ jẹ [valid] fun Levin ti `count * size_of::<T>()` baiti.
///
/// * `dst` gbọdọ wa ni daradara deedee.
///
/// Afikun ohun ti, awọn olupe gbọdọ rii daju wipe kikọ `count * size_of::<T>()` baiti si fi fun ekun ti iranti esi ni a wulo iye ti `T`.
/// Lilo a ekun ti iranti ti tẹ bi a `T` ti o ni ohun invalid iye ti `T` ni aisọye ihuwasi.
///
/// Akọsilẹ ti paapa ti o ba fe ni dakọ iwọn (`ka * size_of: :<T>() ') Ni `0`, awọn ijuboluwole gbọdọ jẹ ti kii-NULL ati ki o daradara deedee.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ṣiṣẹda iye ti ko wulo:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // N jo awọn tẹlẹ waye iye nipa overwriting awọn `Box<T>` pẹlu kan asan ijuboluwole.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ni aaye yi, lilo tabi sisọ `v` esi ni aisọye ihuwasi.
/// // drop(v); // ERROR
///
/// // Ani ńjò `v` "uses" o, ati ki o nibi ti wa ni aisọye ihuwasi.
/// // mem::forget(v); // ERROR
///
/// // Ni otitọ, `v` jẹ alailagbara ni ibamu si awọn ailagbara irufẹ ipilẹ, nitorinaa *isẹ* kankan ti o kan o jẹ ihuwasi ti a ko ṣalaye.
/////
/// // jẹ ki v2 =v;//aṣiṣe
///
/// unsafe {
///     // Jẹ ki a dipo fi ni kan wulo iye
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Bayi ni apoti ni itanran
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // Aabo: aabo guide fun `write_bytes` gbọdọ wa ni ọwọ si nipa awọn olupe ti.
    unsafe { write_bytes(dst, val, count) }
}