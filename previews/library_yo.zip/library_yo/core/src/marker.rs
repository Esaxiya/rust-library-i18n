//! Atijo traits ati orisi o nsoju ipilẹ-ini ti omiran.
//!
//! Awọn oriṣi Rust le wa ni tito lẹtọ ni awọn ọna ti o wulo lọpọlọpọ gẹgẹbi awọn ohun-ini atọkanwa wọn.
//! Awọn wọnyi ni Oriṣi ti wa ni ipoduduro bi traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Awọn oriṣi ti o le gbe kọja awọn aala o tẹle ara.
///
/// Eleyi trait ti wa ni laifọwọyi muse nigbati awọn alakojo ipinnu ti o ni yẹ.
///
/// Ẹya apẹẹrẹ ti a ti kii-`Send` Iru ni awọn itọkasi-kika ijuboluwole [`rc::Rc`][`Rc`].
/// Ti o ba ti meji awon gbiyanju lati oniye [`Rc`] s ti ojuami si awọn kanna itọkasi-kà iye, nwọn ki o le gbiyanju lati mu awọn itọkasi ka ni akoko kanna, eyi ti o jẹ [undefined behavior][ub] nitori [`Rc`] ko ni lo atomiki mosi.
///
/// Awọn oniwe-cousin [`sync::Arc`][arc] wo ni lo atomiki mosi (incurring diẹ ninu awọn lori) ati bayi ni `Send`.
///
/// Wo [the Nomicon](../../nomicon/send-and-sync.html) fun awọn alaye diẹ sii.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Orisi pẹlu kan ibakan iwọn mọ ni sakojo akoko.
///
/// Gbogbo iru sile ni ohun ifisinu dè of `Sized`.Awọn pataki sintasi `?Sized` a le lo lati yọ yi owun ti o ba ti o ti n ko yẹ.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//aṣiṣe: won ti ko ba muse fun [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Awọn ọkan sile ni awọn ifisinu `Self` iru ti a trait.
/// trait kan ko ni asopọ `Sized` ti o han gbangba nitori eyi ko ni ibamu pẹlu [ohun trait] nibiti, ni itumọ, trait nilo lati ṣiṣẹ pẹlu gbogbo awọn oluṣe ti o ṣeeṣe, ati nitorinaa le jẹ iwọn eyikeyi.
///
///
/// Bó tilẹ jẹ pé Rust yoo jẹ ki o di `Sized` to a trait, o yoo ko ni anfani lati lo o lati fẹlẹfẹlẹ kan ti trait ohun nigbamii:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // jẹ ki y: &dyn Bar= &Impl;//aṣiṣe: awọn trait `Bar` ko le ṣee ṣe sinu ohun
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // fun Aiyipada, fun apẹẹrẹ, eyiti o nilo pe `[T]: !Default` jẹ iṣiro
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Awọn oriṣi ti o le jẹ "unsized" si iru iwọn to ni agbara.
///
/// Fun apẹẹrẹ, awọn won orun iru `[i8; 2]` alailewu `Unsize<[i8]>` ati `Unsize<dyn fmt::Debug>`.
///
/// Gbogbo awọn imuṣẹ ti `Unsize` ni a pese ni adani nipasẹ akopọ.
///
/// `Unsize` ti wa ni imuse fun:
///
/// - `[T; N]` ni `Unsize<[T]>`
/// - `T` ni `Unsize<dyn Trait>` nigba ti `T: Trait`
/// - `Foo<..., T, ...>` ni `Unsize<Foo<..., U, ...>>` ti o ba ti:
///   - `T: Unsize<U>`
///   - Foo jẹ ipilẹ
///   - Nikan ni kẹhin aaye ti `Foo` ni o ni a iru okiki `T`
///   - `T` kii ṣe apakan ti iru eyikeyi awọn aaye miiran
///   - `Bar<T>: Unsize<Bar<U>>`, ti aaye ti o kẹhin ti `Foo` ba ni iru `Bar<T>`
///
/// `Unsize` ti lo pẹlú pẹlu [`ops::CoerceUnsized`] lati gba "user-defined" awọn apoti bi [`Rc`] lati ni awọn gbalaye-won omiran.
/// Wo awọn [DST coercion RFC][RFC982] ati [the nomicon entry on coercion][nomicon-coerce] fun alaye diẹ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Ti a beere trait fun adúróṣinṣin lo ninu Àpẹẹrẹ-kere.
///
/// Eyikeyi iru ti derives `PartialEq` laifọwọyi alailewu yi trait, laibikita * boya awọn oniwe-iru-sile se `Eq`.
///
/// Ti ohun kan `const` ba ni diẹ ninu iru ti ko ṣe imuse trait yii, lẹhinna iru yẹn boya (1.) ko ṣe imuse `PartialEq` (eyiti o tumọ si pe ibakan naa kii yoo pese ọna afiwe, eyiti iran koodu gba pe o wa), tabi (2.) o ṣe imuse *tirẹ* version of `PartialEq` (eyi ti a ro ko baramu si a igbekale-Equality lafiwe).
///
///
/// Ni boya ninu awọn meji iṣẹlẹ loke, a kọ lilo ti iru kan ibakan ni a Àpẹẹrẹ baramu.
///
/// Wo tun awọn [structural match RFC][RFC1445], ati [issue 63438] eyi ti qkan Iṣipo pada lati ro-orisun oniru si yi trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Ti a beere trait fun adúróṣinṣin lo ninu Àpẹẹrẹ-kere.
///
/// Eyikeyi iru ti derives `Eq` laifọwọyi alailewu yi trait, laibikita * boya awọn oniwe-type sile se `Eq`.
///
/// Eleyi jẹ a hack lati ṣiṣẹ ni ayika kan aropin ninu wa iru eto.
///
/// # Background
///
/// A fẹ lati beere pe orisi ti consts lo ninu Àpẹẹrẹ-kere ni awọn ro pe `#[derive(PartialEq, Eq)]`.
///
/// Ni kan diẹ bojumu aye, a le ṣayẹwo ti ibeere nipa kan yiyewo ti awọn ti fi fun iru ọlọnà mejeji ni `StructuralPartialEq` trait *ki o si* awọn `Eq` trait.
/// Sibẹsibẹ, o le ni ADTs ti *ṣe*`derive(PartialEq, Eq)`, ki o si wa a nla ti a fẹ ni alakojo lati gba, ati sibẹsibẹ awọn ibakan ká iru kuna lati se `Eq`.
///
/// Èyíinì ni, a irú bi yi:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (The isoro ni awọn loke koodu ti wa ni wipe `Wrap<fn(&())>` ko ni se `PartialEq`, tabi `Eq`, nitori `fun < 'a> fn(&'a _)` does not implement those traits.)
///
/// Nitorina, a ko le gbekele lori rọrun ayẹwo fun `StructuralPartialEq` ati kiki `Eq`.
///
/// Bi awọn kan hack to iṣẹ ni ayika yi, a lo meji lọtọ traits itasi nipasẹ kọọkan ninu awọn meji ti derives (`#[derive(PartialEq)]` ati `#[derive(Eq)]`) ati ayẹwo pe mejeji ti wọn wa ni bayi bi ara ti igbekale-baramu yiyewo.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Orisi ti iye le wa ni duplicated nìkan nipa didakọ die-die.
///
/// Nipa aiyipada, ayípadà bindings ni 'Gbe oro ijora.'Ninu awọn ọrọ miiran:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ti gbe sinu `y`, ati ki o le wa ko le lo
///
/// // println! ("{: ?}", x);//aṣiṣe: lilo ti gbe iye
/// ```
///
/// Sibẹsibẹ, ti o ba ti a iru ọlọnà `Copy`, o dipo ni o ni 'da oro ijora':
///
/// ```
/// // A le ni anfani ifilọlẹ `Copy` kan.
/// // `Clone` jẹ tun beere fun, bi o ti ni a supertrait ti `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ni a daakọ ti `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// O ni pataki lati ṣe akiyesi wipe ninu awọn meji apeere, awọn nikan ni iyato ni boya o ti wa ni laaye lati wọle si `x` lẹhin ti awọn iṣẹ.
/// Labẹ awọn Hood, ati a daakọ ati ki o kan Gbe le ja si ni die-die ni dakọ ni iranti, biotilejepe yi ni ma iṣapeye kuro.
///
/// ## Bawo ni mo ti se `Copy`?
///
/// Nibẹ ni o wa ọna meji lati se `Copy` lori rẹ iru.Ohun ti o rọrun julọ ni lati lo `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// O tun le se `Copy` ati `Clone` ọwọ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Nibẹ ni kekere kan iyato laarin awọn meji: awọn `derive` nwon.Mirza yoo tun gbe kan `Copy` dè lori iru sile, eyi ti o ti ko nigbagbogbo fẹ.
///
/// ## Kini iyato laarin `Copy` ati `Clone`?
///
/// Awọn adakọ ṣẹlẹ laibikita, fun apẹẹrẹ gẹgẹ bi apakan ti iṣẹ iyansilẹ `y = x`.Ihuwasi ti `Copy` kii ṣe apọju pupọ;o jẹ nigbagbogbo kan ti o rọrun bit-ọlọgbọn daakọ.
///
/// Cloning jẹ iṣẹ ti o han kedere, `x.clone()`.Awọn imuse ti [`Clone`] le pese eyikeyi iru-kan pato iwa pataki lati pidánpidán iye lailewu.
/// Fun apẹẹrẹ, imuse ti [`Clone`] fun [`String`] nilo lati daakọ itọka-si ifipamọ okun ni okiti.
/// Ẹda bitwise ti awọn iye [`String`] yoo jo daakọ ijuboluwo naa, ti o yori si ilọpo meji si isalẹ laini.
/// Fun idi eyi, [`String`] ni [`Clone`] sugbon ko `Copy`.
///
/// [`Clone`] jẹ supertrait ti `Copy`, nitorinaa ohun gbogbo ti o jẹ `Copy` gbọdọ tun ṣe [`Clone`].
/// Ti o ba ti a iru ni `Copy` ki o si awọn oniwe-[`Clone`] imuse nikan nilo lati pada `*self` (wo awọn apẹẹrẹ loke).
///
/// ## Nigba ti le mi Iru jẹ `Copy`?
///
/// A iru le se `Copy` ti o ba ti gbogbo awọn ti awọn oniwe-irinše se `Copy`.Fun apẹẹrẹ, yi struct le jẹ `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Ẹya kan le jẹ `Copy`, ati pe [`i32`] jẹ `Copy`, nitorinaa `Point` ni ẹtọ lati jẹ `Copy`.
/// Nipa itansan, ro
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Ẹya `PointList` ko le ṣe `Copy`, nitori [`Vec<T>`] kii ṣe `Copy`.Ti a ba gbiyanju lati nianfani a `Copy` imuse, a yoo gba ohun ašiše:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Awọn itọkasi ti a pin Pipin (`&T`) tun jẹ `Copy`, nitorinaa iru kan le jẹ `Copy`, paapaa nigbati o ba ni awọn itọkasi pipin ti awọn iru `T` ti kii ṣe *kii ṣe*`Copy`.
/// Wo ipilẹ ti o tẹle, eyiti o le ṣe `Copy`, nitori pe o ni itọka *pinpin* nikan si iru `PointList` ti kii-Copy wa:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nigba ti *ko le* mi Iru jẹ `Copy`?
///
/// Diẹ ninu awọn orisi ko le wa ni dakọ lailewu.Fun apẹẹrẹ, didakọ `&mut T` yoo ṣẹda ohun aliased mutable itọkasi.
/// Didakọ [`String`] yoo pidánpidán ojuse fun ìṣàkóso awọn [`String`] 's saarin, yori si kan ė free.
///
/// Generalizing awọn igbehin nla, eyikeyi iru imulo [`Drop`] ko le jẹ `Copy`, nitori ti o ti n ìṣàkóso diẹ ninu awọn oluşewadi Yato si awọn oniwe-ara [`size_of::<T>`] baiti.
///
/// Ti o ba gbiyanju lati ṣe `Copy` lori ipilẹ tabi enum ti o ni data ti kii-Copy`, iwọ yoo gba aṣiṣe [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Nigba ti *yẹ* mi type jẹ `Copy`?
///
/// Gbogbo soro, ti o ba ti iru _can_ se `Copy`, o yẹ.
/// Jeki ni lokan, tilẹ, ti o ba nse `Copy` jẹ apakan ti àkọsílẹ API ti rẹ iru.
/// Ti o ba ti iru le di ti kii-`Copy` ni future, o le jẹ amoye to omit awọn `Copy` imuse bayi, lati yago fun a kikan API ayipada.
///
/// ## afikun implementors
///
/// Ni afikun si awọn [implementors listed below][impls], awọn wọnyi orisi tun se `Copy`:
///
/// * Iṣẹ kan orisi (ie, awọn pato orisi telẹ fun kọọkan iṣẹ)
/// * Awọn oriṣi ijuboluwole iṣẹ (fun apẹẹrẹ, `fn() -> i32`)
/// * Orun oniru, fun gbogbo awọn titobi, ti o ba awọn ohun kan iru tun alailewu `Copy` (eg, `[i32; 123456]`)
/// * Tuple orisi, ti o ba kọọkan paati tun alailewu `Copy` (eg, `()`, `(i32, bool)`)
/// * Bíbo orisi, ti wọn ba Yaworan ko si iye lati awọn ayika tabi ti o ba gbogbo iru sile iye se `Copy` ara wọn.
///   Akọsilẹ ti oniyipada sile nipa pín itọkasi nigbagbogbo se `Copy` (paapa ti o ba referent ko), nigba ti oniyipada sile nipa mutable itọkasi kò se `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Eleyi gba didakọ a iru ti ko ni se `Copy` nitori ti unsatisfied s'aiye igboro (didakọ `A<'_>` nigbati nikan `A<'static>: Copy` ati `A<'_>: Clone`).
// A ni yi ro pe nibi fun bayi nikan nitori nibẹ ni o wa oyimbo kan diẹ tẹlẹ specializations on `Copy` ti tẹlẹ tẹlẹ ninu awọn boṣewa ìkàwé, ati nibẹ ni ko si ona lati lailewu ni yi ihuwasi ọtun bayi.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Gba macro ṣiṣẹda impl kan ti trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Orisi fun eyi ti o jẹ ailewu lati pin jo laarin awon.
///
/// Eleyi trait ti wa ni laifọwọyi muse nigbati awọn alakojo ipinnu ti o ni yẹ.
///
/// Awọn kongẹ definition jẹ: a iru `T` ni [`Sync`] ti o ba ti ati ki o nikan ti o ba ti `&T` ni [`Send`].
/// Ni gbolohun miran, ti o ba ti nibẹ ni ko si seese ti [undefined behavior][ub] (pẹlu data meya) nigbati ran `&T` jo laarin awon.
///
/// Bi ọkan yoo reti, atijo orisi bi [`u8`] ati [`f64`] wa ni gbogbo awọn [`Sync`], ati ki wa ni o rọrun dagba orisi ti o ni awọn wọn, bi tuples, structs ati enums.
/// Diẹ apeere ti ipilẹ [`Sync`] orisi ni "immutable" orisi bi `&T`, ati awọn pẹlu awọn jogun mutability, gẹgẹ bi awọn [`Box<T>`][box], [`Vec<T>`][vec] ati julọ miiran gbigba omiran.
///
/// (Generic sile nilo lati wa ni [`Sync`] fun won eiyan lati wa ni [`Sync`].)
///
/// A ni itumo yanilenu Nitori ti awọn definition ni wipe `&mut T` ni `Sync` (ti o ba `T` ni `Sync`) koda bi o ti dabi bi ti o le pese unsynchronized iyipada.
/// Awọn omoluabi ni wipe a mutable itọkasi sile kan pín itọkasi (ti o ni, `& &mut T`) di ka-nikan, bi o ba ti wà a `& &T`.
/// Nibi nibẹ ni ko si ewu ti a data ije.
///
/// Orisi ti o wa ni ko `Sync` ni o wa awon ti o ni "interior mutability" ni a ti kii-tẹle-ailewu fọọmu, gẹgẹ bi awọn [`Cell`][cell] ati [`RefCell`][refcell].
/// Awon orisi gba fun iyipada ti awọn akoonu ti wọn ani nipasẹ ohun aileyipada, pín itọkasi.
/// Fun apẹẹrẹ awọn `set` ọna on [`Cell<T>`][cell] gba `&self`, ki o nilo nikan kan pín itọkasi [`&Cell<T>`][cell].
/// Awọn ọna performs ko si amušišẹpọ, bayi [`Cell`][cell] ko le jẹ `Sync`.
///
/// Miran ti apẹẹrẹ ti a ti kii-`Sync` Iru ni awọn itọkasi-kika ijuboluwole [`Rc`][rc].
/// Fun eyikeyi itọkasi [`&Rc<T>`][rc], o le oniye a titun [`Rc<T>`][rc], iyipada awọn itọkasi julo ni a ti kii-atomiki ọna.
///
/// Fun awọn ọran nigba ti ẹnikan ba nilo iyipada inu ilohunsoke ti o tẹle ara-ailewu, Rust n pese [atomic data types], bii titiipa fifin nipasẹ [`sync::Mutex`][mutex] ati [`sync::RwLock`][rwlock].
/// Awon orisi rii daju wipe eyikeyi iyipada ko le fa data meya, nibi awọn orisi ni o wa `Sync`.
/// Bakan naa, [`sync::Arc`][arc] n pese analog ailewu-tẹle ti [`Rc`][rc].
///
/// Awọn iru eyikeyi pẹlu iyipada inu gbọdọ tun lo ohun elo [`cell::UnsafeCell`][unsafecell] ni ayika value(s) eyiti o le yipada nipasẹ itọkasi itọkasi.
/// Ti kuna lati ṣe eyi ni [undefined behavior][ub].
/// Fun apẹẹrẹ, [`transmute`][transmute]-ing lati `&T` to `&mut T` ni invalid.
///
/// Wo [the Nomicon][nomicon-send-and-sync] fun alaye siwaju sii nipa `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ni kete ti support lati fi awọn akọsilẹ ni `rustc_on_unimplemented` gan ni Beta, ati awọn ti o ti a ti tesiwaju lati ṣayẹwo boya a bíbo ni nibikibi ninu awọn ibeere pq, fa o bi iru (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Odo-won Iru lo lati samisi awọn ohun ti o "act like" nwọn ara a `T`.
///
/// Fikun aaye `PhantomData<T>` si oriṣi rẹ sọ fun akopọ pe iru rẹ ṣe bi ẹni pe o tọju iye iru `T`, botilẹjẹpe kii ṣe gaan.
/// Alaye yi ti lo nigbati iširo awọn aabo-ini.
///
/// Fun kan diẹ ẹ sii ni-ijinle alaye ti bi o lati lo `PhantomData<T>`, jọwọ wo [the Nomicon](../../nomicon/phantom-data.html).
///
/// # A ghastly akọsilẹ 👻👻👻
///
/// Tilẹ ti won mejeji ni idẹruba awọn orukọ, `PhantomData` ati 'Phantom orisi' ti wa ni jẹmọ, sugbon ko aami.A Phantom iru paramita jẹ nìkan a iru paramita eyi ti o ti kò ti lo.
/// Ni Rust, yi igba fa awọn alakojo lati kerora, ati awọn ojutu ni lati fi kan "dummy" lilo nipa ọna ti `PhantomData`.
///
/// # Examples
///
/// ## Ajeku s'aiye sile
///
/// Boya awọn wọpọ lilo irú fun `PhantomData` ni a struct ti o ni o ni ohun ajeku s'aiye paramita, ojo melo bi ara ti diẹ ninu awọn lewu koodu.
/// Fun apẹẹrẹ, nibi ni a struct `Slice` ti o ni meji awọn ifẹnule ti iru `*const T`, aigbekele ntokasi si ohun orun ibikan:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ero naa ni pe data ipilẹ jẹ wulo nikan fun igbesi aye `'a`, nitorinaa `Slice` ko yẹ ki o kọja `'a`.
/// Sibẹsibẹ, yi idi ti a ko ti kosile ninu awọn koodu, niwon nibẹ ni o wa ti ko si ipawo ti awọn s'aiye `'a` ati ki o nibi ti o ti wa ni ko ko ohun ti data ti o kan si.
/// A le se atunse yi nipa enikeji awọn alakojo lati sise *bi o ba ti* awọn `Slice` struct ti o wa ninu a itọkasi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Eleyi tun ni Tan nbeere atọka `T: 'a`, o nfihan pe eyikeyi jo ni `T` o wa wulo lori awọn s'aiye `'a`.
///
/// Nigba ti initializing a `Slice` o nìkan pese awọn iye `PhantomData` fun awọn aaye `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Awọn iṣiro iru ti a ko lo
///
/// O ma ṣẹlẹ wipe o ni ajeku iru sile eyi ti fihan ohun ti Iru ti data a struct ni "tied" to, ani tilẹ ti data ti wa ni ko kosi ri ninu awọn struct ara.
/// Eyi ni apẹẹrẹ nibiti eyi waye pẹlu [FFI].
/// Awọn ajeji ni wiwo ipawo kapa ti Iru `*mut ()` to tọka si Rust iye ti o yatọ si omiran.
/// A orin awọn Rust iru lilo a Phantom iru igbeseô lori struct `ExternalResource` eyi ti o murasilẹ a mu.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Nini ati awọn ju ayẹwo
///
/// Fifi kan aaye ti Iru `PhantomData<T>` tọkasi wipe rẹ iru ti o ni data ti iru `T`.Eleyi ni Tan tumo si pe nigba ti iru ti wa ni silẹ, o le ju ọkan tabi diẹ ẹ sii instances ti awọn iru `T`.
/// Eleyi ni o ni ara lori awọn Rust alakojo ká [drop check] onínọmbà.
///
/// Ti o ba ti struct ko ni ni o daju *ara* awọn data ti iru `T`, o jẹ dara lati lo kan itọkasi iru, bi `PhantomData<&'a T>` (ideally) tabi `PhantomData<*const T>` (ti o ba ko si s'aiye kan), ki bi ko lati fihan nini.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Alakojo-ti abẹnu trait lo lati fihan iru enum discriminants.
///
/// Eleyi trait ti wa ni laifọwọyi muse fun gbogbo iru ati ki o ko fi eyikeyi onigbọwọ to [`mem::Discriminant`].
/// O jẹ **ihuwasi ti a ko ṣalaye** lati transmute laarin `DiscriminantKind::Discriminant` ati `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Awọn iru ti awọn discriminant, eyi ti gbọdọ ni itẹlọrun awọn trait bounds ti a beere nipa `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Alakojo-ti abẹnu trait lo lati mo boya a iru ni eyikeyi `UnsafeCell` fipa, sugbon ko nipasẹ ohun indirection.
///
/// Eleyi yoo ni ipa, fun apẹẹrẹ, boya a `static` ti ti iru wa ni gbe ni ka-nikan aimi iranti tabi writable aimi iranti.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Orisi ti o le wa ni kuro lailewu gbe lẹhin ti a pinned.
///
/// Rust funrararẹ ko ni imọran ti awọn oriṣi ti ko ṣee gbe, ati pe o ronu awọn gbigbe (fun apẹẹrẹ, nipasẹ iṣẹ iyansilẹ tabi [`mem::replace`]) lati ni aabo nigbagbogbo.
///
/// The [`Pin`][Pin] Iru ti lo dipo lati se e nipasẹ awọn iru eto.Awọn ijuboluwole `P<T>` ti a we ninu apopọ [`Pin<P<T>>`][Pin] ko le ṣee gbe jade ninu.
/// Wo iwe [`pin` module] fun alaye diẹ sii lori pinni.
///
/// Ṣiṣe `Unpin` trait fun `T` gbe awọn ihamọ ti sisọ iru, eyiti o jẹ ki gbigbe `T` jade ti [`Pin<P<T>>`][Pin] pẹlu awọn iṣẹ bii [`mem::replace`].
///
///
/// `Unpin` ni o ni ko Nitori ni gbogbo fun ti kii-pinned data.
/// Ni pato, [`mem::replace`] inudidun rare `!Unpin` data (ti o ṣiṣẹ fun eyikeyi `&mut T`, ko o kan nigba ti `T: Unpin`).
/// Sibẹsibẹ, o ko ba le lo [`mem::replace`] on data ti a we inu a [`Pin<P<T>>`][Pin] nitori ti o ko ba le gba awọn `&mut T` ti o nilo fun awọn ti o, ati ki o *ti* ni ohun ti ki asopọ yi eto ise.
///
/// Nitorina eyi, fun apẹẹrẹ, le ṣee ṣe nikan lori awọn oriṣi ti n ṣe imuse `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // A nilo a mutable tọka si pe `mem::replace`.
/// // A le gba iru a itọkasi nipa (implicitly) invoking `Pin::deref_mut`, sugbon ti jẹ ṣee ṣe nikan nitori `String` ọlọnà `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait yii ni aṣeṣe adaṣe fun fere gbogbo iru.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// A sibomiiran iru eyi ti ko ni se `Unpin`.
///
/// Ti o ba ti a iru ni a `PhantomPinned`, o yoo ko se `Unpin` nipa aiyipada.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Imuṣẹ ti `Copy` fun atijo omiran.
///
/// Imuṣẹ ti ko le sapejuwe ninu Rust ti wa ni muse ni `traits::SelectionContext::copy_clone_conditions()` ni `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Pín jo le wa ni dakọ, ṣugbọn mutable jo *ko le*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}