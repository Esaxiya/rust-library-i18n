#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Ni awọn asọye agbekalẹ fun ipilẹ ti awọn iru akopọ ti n ṣajọ.
//!
//! Wọn le ṣee lo bi awọn ibi-afẹde ti awọn gbigbe ninu koodu ti ko ni aabo fun ifọwọyi awọn aṣoju aise taara.
//!
//!
//! Itumọ wọn yẹ ki o baamu ABI nigbagbogbo ni `rustc_middle::ty::layout`.
//!

/// Awọn oniduro ti a trait ohun bi `&dyn SomeTrait`.
///
/// Ẹya yii ni ipilẹ kanna bi awọn iru bi `&dyn SomeTrait` ati `Box<dyn AnotherTrait>`.
///
/// `TraitObject` ti ni idaniloju lati ba awọn ipilẹ mu, ṣugbọn kii ṣe iru awọn ohun ti trait (fun apẹẹrẹ, awọn aaye ko ni iraye si taara lori `&dyn SomeTrait` kan) bẹni ko ṣakoso iṣakoso naa (yiyipada itumọ ko ni yi ifilelẹ ti `&dyn SomeTrait` kan pada).
///
/// A ṣe apẹrẹ nikan lati ṣee lo nipasẹ koodu ti ko ni aabo ti o nilo lati ṣe afọwọyi awọn alaye ipele-kekere.
///
/// Ko si ọna lati tọka si gbogbo awọn ohun trait lapapọ, nitorinaa ọna kan lati ṣẹda awọn iye ti iru yii ni pẹlu awọn iṣẹ bii [`std::mem::transmute`][transmute].
/// Bakan naa, ọna kan ṣoṣo lati ṣẹda ohun trait tootọ lati iye `TraitObject` jẹ pẹlu `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ṣiṣẹpọ nkan trait pẹlu awọn oriṣi ti ko tọ si-ọkan nibiti vtable ko ni ibamu si iru iye ti eyiti ijuboluwole data tọka-jẹ eyiti o ṣeeṣe ki o yorisi ihuwasi ti a ko ṣalaye.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // apẹẹrẹ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // jẹ ki akopọ ṣe nkan trait
/// let object: &dyn Foo = &value;
///
/// // wo aise oniduro
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ijuboluwole data ni adirẹsi ti `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // kọ nkan tuntun, tọka si `i32` ti o yatọ, ṣọra lati lo `i32` vtable lati `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // o yẹ ki o ṣiṣẹ gẹgẹ bi ẹni pe a ti kọ nkan trait kan lati `other_value` taara
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}