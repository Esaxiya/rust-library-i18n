//! Awọn iye iyan.
//!
//! Iru [`Option`] ṣe aṣoju iye iyan: gbogbo [`Option`] jẹ boya [`Some`] ati pe o ni iye kan, tabi [`None`], ati pe ko ṣe.
//! [`Option`] awọn oriṣi wopo pupọ ni koodu Rust, nitori wọn ni nọmba awọn lilo:
//!
//! * Awọn iye akọkọ
//! * Pada awọn iye pada fun awọn iṣẹ ti a ko ṣalaye lori gbogbo ibiti wọn ti n tẹwọle (awọn iṣẹ apakan)
//! * Pada iye fun bibẹkọ ti o sọ awọn aṣiṣe ti o rọrun, nibiti [`None`] ti pada lori aṣiṣe
//! * Awọn aaye ipilẹ aṣayan
//! * Awọn aaye apẹrẹ ti o le yawo tabi "taken"
//! * Awọn ariyanjiyan iṣẹ iyan
//! * Awọn itọka ti ko le ṣe
//! * Swapping ohun jade ti soro ipo
//!
//! [`Option`] s ni a ṣopọ pọ pẹlu ibaramu apẹrẹ lati beere wiwa iye kan ati ṣe igbese, ṣiṣe iṣiro nigbagbogbo fun ọran [`None`].
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Iye ipadabọ iṣẹ naa jẹ aṣayan
//! let result = divide(2.0, 3.0);
//!
//! // Baramu Apẹrẹ lati gba iye naa pada
//! match result {
//!     // Pipin naa wulo
//!     Some(x) => println!("Result: {}", x),
//!     // Pipin naa ko wulo
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: Ṣe afihan bi a ṣe lo `Option` ni adaṣe, pẹlu ọpọlọpọ awọn ọna
//
//! # Awọn aṣayan ati awọn atọka (awọn atọka "nullable")
//!
//! Awọn oriṣi ijuboluwole Rust gbọdọ nigbagbogbo tọka si ipo to wulo;ko si awọn itọkasi "null".Dipo, Rust ni awọn ifọkasi *aṣayan*, bii apoti ti o ni aṣayan, [`Aṣayan]]` <`[` Apoti<T>"]"> ".
//!
//! Apẹẹrẹ atẹle n lo [`Option`] lati ṣẹda apoti aṣayan ti [`i32`].
//! Ṣe akiyesi pe lati lo iye [`i32`] ti inu akọkọ, iṣẹ `check_optional` nilo lati lo ibaramu apẹrẹ lati pinnu boya apoti naa ni iye kan (ie, o jẹ [`Some(...)`][`Some`]) tabi kii ṣe ([`None`]).
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Awọn onigbọwọ Rust lati jẹ ki awọn iru `T` wọnyi atẹle bii [`Option<T>`] ni iwọn kanna bi `T`:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` struct ni ayika ọkan ninu awọn oriṣi ninu atokọ yii.
//!
//! O ti ni idaniloju siwaju pe, fun awọn ọran loke, ẹnikan le [`mem::transmute`] lati gbogbo awọn iye to wulo ti `T` si `Option<T>` ati lati `Some::<T>(_)` si `T` (ṣugbọn gbigbe `None::<T>` si `T` jẹ ihuwasi ti ko ṣalaye).
//!
//! # Examples
//!
//! Ibamu apẹẹrẹ ipilẹ lori [`Option`]:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // Mu itọkasi si okun ti o wa ninu
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Yọ okun ti o wa ninu rẹ, pa Aṣayan run
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Ṣe ipilẹṣẹ abajade kan si [`None`] ṣaaju iṣaaju:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Atokọ data lati wa nipasẹ.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // A yoo wa orukọ ti ẹranko nla julọ, ṣugbọn lati bẹrẹ pẹlu a ti ni `None`.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // Bayi a ti rii orukọ ẹranko nla kan
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// Iru `Option`.Wo [the module level documentation](self) fun diẹ sii.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Ko si iye
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Diẹ ninu iye `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Iru imuse
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Ibeere awọn iye to wa ninu rẹ
    /////////////////////////////////////////////////////////////////////////

    /// Pada `true` ti aṣayan ba jẹ iye [`Some`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Padà `true` ti o ba ti aṣayan jẹ a [`None`] iye.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Pada `true` ti aṣayan ba jẹ iye [`Some`] ti o ni iye ti a fun.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Adaparọ fun ṣiṣẹ pẹlu awọn itọkasi
    /////////////////////////////////////////////////////////////////////////

    /// Awọn iyipada lati `&Option<T>` si `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Yipada `Aṣayan <` [`String`]`>> sinu`Aṣayan <`[`usize`]`> `, titọju atilẹba.
    /// Ọna [`map`] gba ariyanjiyan `self` nipasẹ iye, n gba atilẹba, nitorinaa ilana yii lo `as_ref` lati kọkọ mu `Option` kan si itọkasi si iye inu atilẹba.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Ni akọkọ, sọ `Option<String>` si `Option<&String>` pẹlu `as_ref`, lẹhinna jẹun *pe* pẹlu `map`, nlọ `text` lori akopọ naa.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// Awọn iyipada lati `&mut Option<T>` si `Option<&mut T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// Awọn iyipada lati [`Pin`]`<&Aṣayan<T>> si"Aṣayan <"["Pin`]" <&T>>.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // Aabo: `x` jẹ ẹri lati wa ni pinni nitori pe o wa lati `self`
        // eyi ti o ti pinni.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// Awọn iyipada lati [`Pin`]`<&mut Aṣayan<T>> si"Aṣayan <"["Pin`]" <&mut T>> ".
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // Aabo: `get_unchecked_mut` ko lo rara lati gbe `Option` inu `self`.
        // `x` ti ni idaniloju lati wa ni pinni nitori pe o wa lati `self` eyiti o pinni.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // Gbigba si awọn iye ti o wa ninu
    /////////////////////////////////////////////////////////////////////////

    /// Pada iye [`Some`] ti o wa ninu rẹ, n gba iye `self`.
    ///
    /// # Panics
    ///
    /// Panics ti iye naa jẹ [`None`] pẹlu ifiranṣẹ panic aṣa ti a pese nipasẹ `msg`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// Pada iye [`Some`] ti o wa ninu rẹ, n gba iye `self`.
    ///
    /// Nitori iṣẹ yii le panic, lilo rẹ ni apọju gbogbogbo.
    /// Dipo, fẹ lati lo ibaramu apẹrẹ ati mu ọran [`None`] ni gbangba, tabi pe [`unwrap_or`], [`unwrap_or_else`], tabi [`unwrap_or_default`].
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ti iye ti ara ẹni ba dọgba [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Pada iye [`Some`] ti o wa ninu tabi aiyipada ti a pese.
    ///
    /// Awọn ariyanjiyan ti o kọja si `unwrap_or` jẹ igbelewọn itara;ti o ba n kọja abajade ti ipe iṣẹ kan, o ni iṣeduro lati lo [`unwrap_or_else`], eyiti a ṣe ayẹwo ọlẹ.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// Pada iye [`Some`] ti o wa ninu rẹ tabi ṣe iṣiro rẹ lati bíbo.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Pada iye [`Some`] ti o wa ninu rẹ, n gba iye `self`, laisi ṣayẹwo pe iye kii ṣe [`None`].
    ///
    ///
    /// # Safety
    ///
    /// Pipe ọna yii lori [`None`] jẹ *[ihuwasi ti a ko ṣalaye]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Iwa ti a ko ṣalaye!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // Aabo: A gbọdọ ṣe adehun adehun aabo nipasẹ olupe naa.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Iyipada awọn iye ti o wa ninu rẹ
    /////////////////////////////////////////////////////////////////////////

    /// Awọn maapu ohun `Option<T>` si `Option<U>` nipa lilo iṣẹ kan si iye ti o wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// Yipada `Aṣayan <` [`String`]`>> sinu`Aṣayan <`[`usize`]`> `, n gba atilẹba:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` gba ararẹ *nipasẹ iye*, n gba `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Lo iṣẹ kan si iye ti o wa ninu rẹ (ti eyikeyi ba jẹ), tabi da pada aiyipada ti a pese (ti kii ba ṣe bẹ).
    ///
    /// Awọn ariyanjiyan ti o kọja si `map_or` jẹ igbelewọn itara;ti o ba n kọja abajade ti ipe iṣẹ kan, o ni iṣeduro lati lo [`map_or_else`], eyiti a ṣe ayẹwo ọlẹ.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Ṣe iṣẹ kan si iye ti o wa ninu (ti eyikeyi ba jẹ), tabi ṣe iṣiro aiyipada (ti kii ba ṣe bẹ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// Yipada `Option<T>` sinu [`Result<T, E>`] kan, ṣiṣe aworan [`Some(v)`] si [`Ok(v)`] ati [`None`] si [`Err(err)`].
    ///
    /// Awọn ariyanjiyan ti o kọja si `ok_or` jẹ igbelewọn itara;ti o ba n kọja abajade ti ipe iṣẹ kan, o ni iṣeduro lati lo [`ok_or_else`], eyiti a ṣe ayẹwo ọlẹ.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// Yipada `Option<T>` sinu [`Result<T, E>`] kan, ṣiṣe aworan [`Some(v)`] si [`Ok(v)`] ati [`None`] si [`Err(err())`].
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Awọn ifibọ `value` sinu aṣayan lẹhinna pada itọkasi itọsi si rẹ.
    ///
    /// Ti aṣayan ba ti ni iye tẹlẹ, iye atijọ ti wa silẹ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // Aabo: koodu ti o wa loke kan kun aṣayan naa
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Awọn akọle Iterator
    /////////////////////////////////////////////////////////////////////////

    /// Pada aṣetunṣe lori iye ti o le wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Pada a aṣetunṣe iyipada lori iye ti o le wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Awọn iṣẹ Boolean lori awọn iye, itara ati ọlẹ
    /////////////////////////////////////////////////////////////////////////

    /// Pada [`None`] ti aṣayan ba jẹ [`None`], bibẹkọ ti o pada `optb`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Pada [`None`] ti aṣayan ba jẹ [`None`], bibẹkọ ti pe `f` pẹlu iye ti a we ati da abajade pada.
    ///
    ///
    /// Diẹ ninu awọn ede pe iṣẹ yii ni flatmap.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Pada [`None`] ti aṣayan ba jẹ [`None`], bibẹkọ ti pe `predicate` pẹlu iye ti a we ati awọn pada:
    ///
    ///
    /// - [`Some(t)`] ti `predicate` ba pada `true` (ibiti `t` jẹ iye ti a we), ati
    /// - [`None`] ti o ba ti `predicate` pada `false`.
    ///
    /// Iṣẹ yii n ṣiṣẹ bakanna si [`Iterator::filter()`].
    /// O le fojuinu `Option<T>` jẹ aṣetunṣe lori ọkan tabi awọn eroja odo.
    /// `filter()` jẹ ki o pinnu iru awọn eroja lati tọju.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Pada aṣayan ti o ba ni iye ninu rẹ, bibẹkọ ti o pada `optb`.
    ///
    /// Awọn ariyanjiyan ti o kọja si `or` jẹ igbelewọn itara;ti o ba n kọja abajade ti ipe iṣẹ kan, o ni iṣeduro lati lo [`or_else`], eyiti a ṣe ayẹwo ọlẹ.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Pada aṣayan ti o ba ni iye ninu rẹ, bibẹẹkọ pe `f` o si da abajade pada.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// Pada [`Some`] ti o ba jẹ deede ọkan ninu `self`, `optb` jẹ [`Some`], bibẹkọ ti o pada [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Awọn iṣẹ iru-titẹ sii lati fi sii ti Ko ba si ati dapada itọkasi kan
    /////////////////////////////////////////////////////////////////////////

    /// Awọn ifibọ `value` sinu aṣayan ti o ba jẹ [`None`], lẹhinna da itọkasi itọkasi iyipada si iye ti o wa ninu rẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Awọn ifibọ iye aiyipada sinu aṣayan ti o ba jẹ [`None`], lẹhinna da itọkasi itọkasi iyipada si iye ti o wa ninu rẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// Awọn ifibọ iye kan ti a ṣe iṣiro lati `f` sinu aṣayan ti o ba jẹ [`None`], lẹhinna da itọkasi itọkasi iyipada si iye ti o wa ninu rẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // Aabo: iyatọ `None` fun `self` yoo ti rọpo nipasẹ `Some` kan
            // iyatọ ninu koodu loke.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Mu iye kuro ninu aṣayan, nlọ [`None`] kan si ipo rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Rọpo iye gangan ninu aṣayan nipasẹ iye ti a fun ni paramita, dapada iye atijọ ti o ba wa, fifi [`Some`] silẹ ni ipo rẹ laisi iparun boya ọkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// Zips `self` pẹlu `Option` miiran.
    ///
    /// Ti `self` jẹ `Some(s)` ati `other` jẹ `Some(o)`, ọna yii pada `Some((s, o))`.
    /// Tabi ki, `None` ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// Zips `self` ati `Option` miiran pẹlu iṣẹ `f`.
    ///
    /// Ti `self` jẹ `Some(s)` ati `other` jẹ `Some(o)`, ọna yii pada `Some(f(s, o))`.
    /// Tabi ki, `None` ti pada.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Awọn maapu kan `Option<&T>` si `Option<T>` nipasẹ didakọ awọn akoonu ti aṣayan naa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Maapu ohun `Option<&mut T>` si ohun `Option<T>` nipa didakọ awọn awọn akoonu ti awọn aṣayan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Awọn maapu kan `Option<&T>` si `Option<T>` nipasẹ kilọ awọn akoonu ti aṣayan naa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Awọn maapu kan `Option<&mut T>` si `Option<T>` nipasẹ kilọ awọn akoonu ti aṣayan naa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// Gba `self` lakoko ti o nreti [`None`] ati gbigba ohunkohun pada.
    ///
    /// # Panics
    ///
    /// Panics ti iye naa jẹ [`Some`], pẹlu ifiranṣẹ panic pẹlu ifiranṣẹ ti o kọja, ati akoonu ti [`Some`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Eyi kii ṣe panic, nitori gbogbo awọn bọtini jẹ alailẹgbẹ.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// Gba `self` lakoko ti o nreti [`None`] ati gbigba ohunkohun pada.
    ///
    /// # Panics
    ///
    /// Panics ti iye naa jẹ [`Some`], pẹlu aṣa panic aṣa ti a pese nipasẹ iye [`Some`]`.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Eyi kii ṣe panic, nitori gbogbo awọn bọtini jẹ alailẹgbẹ.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// Pada iye [`Some`] ti o wa ninu tabi aiyipada kan
    ///
    /// Gba ariyanjiyan `self` lẹhinna, ti [`Some`] ba, da iye ti o wa ninu rẹ pada, bibẹkọ ti [`None`], ba pada [default value] fun iru naa.
    ///
    ///
    /// # Examples
    ///
    /// Yipada okun kan si odidi, titan awọn okun ti a ko dara si 0 (iye aiyipada fun awọn odidi).
    /// [`parse`] yi okun pada si iru eyikeyi miiran ti o ṣe [`FromStr`], ti o pada [`None`] lori aṣiṣe.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// Awọn iyipada lati `Option<T>` (tabi `&Option<T>`) si `Option<&T::Target>`.
    ///
    /// Fi Aṣayan atilẹba silẹ ni aaye, ṣiṣẹda tuntun kan pẹlu itọkasi si atilẹba, ni afikun fifunni awọn akoonu nipasẹ [`Deref`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// Awọn iyipada lati `Option<T>` (tabi `&mut Option<T>`) si `Option<&mut T::Target>`.
    ///
    /// Fi oju-iwe `Option` akọkọ silẹ ni aaye, ṣiṣẹda tuntun kan ti o ni itọka iyipada kan si iru `Deref::Target` iru ti inu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// Ṣe itumọ `Option` kan ti [`Result`] sinu [`Result`] ti `Option` kan.
    ///
    /// [`None`] yoo ya aworan si [`Ok`]`(`[Kò si]]` `.
    /// [`Some`]`(`[`Ok`] `(_))` ati [`Some`]`(`[`Err`] `(_))` yoo maapu si [`Ok`]`(`[`Some`] `(_))` ati [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Eyi jẹ iṣẹ lọtọ lati dinku iwọn koodu ti .expect() funrararẹ.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Eyi jẹ iṣẹ lọtọ lati dinku iwọn koodu ti .expect_none() funrararẹ.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Awọn imuṣẹ Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// Awọn ipadabọ [`None`][Option::None].
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Pada olutaja ti n gba lori iye ti o le wa ninu rẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// Awọn ẹda Awọn `val` sinu `Some` tuntun.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// Awọn iyipada lati `&Option<T>` si `Option<&T>`.
    ///
    /// # Examples
    ///
    /// Yipada `Aṣayan <` [`String`]`>> sinu`Aṣayan <`[`usize`]`> `, titọju atilẹba.
    /// Ọna [`map`] gba ariyanjiyan `self` nipasẹ iye, n gba atilẹba, nitorinaa ilana yii lo `as_ref` lati kọkọ mu `Option` kan si itọkasi si iye inu atilẹba.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// Awọn iyipada lati `&mut Option<T>` si `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Awọn Iterators Aṣayan
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Atunṣe kan lori itọkasi si iyatọ [`Some`] ti [`Option`] kan.
///
/// Aṣatunṣe n mu iye kan wa ti [`Option`] jẹ [`Some`], bibẹẹkọ ko si.
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`Option::iter`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Atunṣe kan lori itọkasi iyipada kan si iyatọ [`Some`] ti [`Option`] kan.
///
/// Aṣatunṣe n mu iye kan wa ti [`Option`] jẹ [`Some`], bibẹẹkọ ko si.
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`Option::iter_mut`].
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// Atunṣe lori iye ni iyatọ [`Some`] ti [`Option`] kan.
///
/// Aṣatunṣe n mu iye kan wa ti [`Option`] jẹ [`Some`], bibẹẹkọ ko si.
///
/// `struct` yii ni a ṣẹda nipasẹ iṣẹ [`Option::into_iter`].
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Gba eroja kọọkan ninu [`Iterator`]: ti o ba jẹ [`None`][Option::None], ko si awọn eroja siwaju sii, ati pe [`None`][Option::None] ti pada.
    /// Ti ko si [`None`][Option::None] ti o waye, a gba apoti pẹlu awọn iye ti [`Option`] kọọkan.
    ///
    /// # Examples
    ///
    /// Eyi ni apẹẹrẹ eyiti o ṣe alekun gbogbo odidi ninu vector kan.
    /// A lo iyatọ ti a ṣayẹwo ti `add` ti o da `None` pada nigbati iṣiro yoo ja si iṣan-omi.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Bi o ti le rii, eyi yoo da awọn ohun ti o nireti pada.
    ///
    /// Eyi ni apẹẹrẹ miiran ti o gbidanwo lati yọ ọkan kuro ninu atokọ miiran ti awọn odidi, ni akoko yii n ṣayẹwo fun iṣan omi:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Niwọn igba ti o kẹhin jẹ asan, yoo ṣan silẹ.Nitorinaa, iye abajade ni `None`.
    ///
    /// Eyi ni iyatọ lori apẹẹrẹ ti tẹlẹ, n fihan pe ko si awọn eroja siwaju sii ti a gba lati `iter` lẹhin akọkọ `None`.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Niwọn igba ti ẹlomiran ti fa iṣan omi, ko si awọn eroja siwaju sii ti o gba, nitorinaa iye ikẹhin ti `shared` jẹ 6 (= `3 + 2 + 1`), kii ṣe 16.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Eyi le paarọ rẹ pẹlu Iterator::scan nigbati a ba ti pa aṣiṣe iṣẹ yii.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// Iru aṣiṣe ti o ni abajade lati lilo (`?`) oniṣẹ igbiyanju si iye `None` kan.
/// Ti o ba fẹ gba `x?` (nibiti `x` jẹ `Option<T>`) lati yipada si iru aṣiṣe rẹ, o le ṣe `impl From<NoneError>` fun `YourErrorType`.
///
/// Ni ọran yẹn, `x?` laarin iṣẹ kan ti o pada `Result<_, YourErrorType>` yoo tumọ iye `None` sinu abajade `Err`.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// Awọn iyipada lati `Option<Option<T>>` si `Option<T>`
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Flattening nikan yọ ipele kan ti itẹ-ẹiyẹ ni akoko kan:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}