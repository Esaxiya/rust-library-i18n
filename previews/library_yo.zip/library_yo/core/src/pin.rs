//! Awọn oriṣi ti o pin data si ipo rẹ ni iranti.
//!
//! O ti wa ni ma wulo lati ni ohun ti o ti wa ni ẹri ko lati gbe, ninu awọn ori wipe won placement ni iranti ko ni yi, ati ki o le bayi wa ni gbarale lori.
//! Apẹẹrẹ akọkọ ti iru oju iṣẹlẹ bẹ yoo jẹ awọn iṣesi itọka ara ẹni, bi gbigbe ohun kan pẹlu awọn itọka si ara rẹ yoo sọ wọn di asan, eyiti o le fa ihuwasi aisọye.
//!
//! Ni ipele giga, [`Pin<P>`] ṣe idaniloju pe ijuboluwo ti eyikeyi ijuboluwole iru `P` ni ipo idurosinsin ninu iranti, itumo pe a ko le gbe e ni ibomiiran ati pe iranti rẹ ko le ṣe pinpin titi ti o fi lọ silẹ.A sọ pe oṣere naa jẹ "pinned".Awọn nkan ni oye diẹ sii nigbati o ba jiroro awọn oriṣi ti o ṣopọ pinned pẹlu data ti a ko pinned;[see below](#projections-and-structural-pinning) fun awọn alaye diẹ sii.
//!
//! Nipa aiyipada, gbogbo awọn oriṣi ni Rust ṣee gbe.
//! Rust ngbanilaaye gbigbe gbogbo awọn iru nipasẹ-iye, ati awọn oriṣi ijuboluwole ti o wọpọ bii [`Box<T>`] ati `&mut T` gba laaye rirọpo ati gbigbe awọn iye ti wọn ni: o le jade kuro ninu [`Box<T>`], tabi o le lo [`mem::swap`].
//! [`Pin<P>`] murasilẹ iru ijuboluwole kan `P`, nitorinaa [`Pin`]`<`[`Apoti`]] `<T>> awọn iṣẹ pọ bi igbagbogbo
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Apoti`]] `<T>> ti lọ silẹ, nitorinaa awọn akoonu inu rẹ, ati iranti n gba
//!
//! ipinfunni.Bakan naa, [`Pin`]`<&mut T>`jẹ pupọ bi `&mut T`.Sibẹsibẹ, [`Pin<P>`] ko jẹ ki awọn alabara gba [`Box<T>`] tabi `&mut T` si data ti a pinni, eyiti o tumọ si pe o ko le lo awọn iṣẹ bii [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` nilo `&mut T`, ṣugbọn a ko le gba.
//!     // A ti di, a ko le paarọ awọn akoonu ti awọn itọkasi wọnyi.
//!     // A le lo `Pin::get_unchecked_mut`, ṣugbọn iyẹn jẹ ailewu fun idi kan:
//!     // a ko gba ọ laaye lati lo fun gbigbe awọn nkan kuro ninu `Pin`.
//! }
//! ```
//!
//! O tọ lati tun sọ pe [`Pin<P>`] ko *ṣe* yi otitọ pada pe olupilẹṣẹ Rust ṣe akiyesi gbogbo awọn iru gbigbe.[`mem::swap`] jẹ adarọ-ese fun eyikeyi `T`.Dipo, [`Pin<P>`] ṣe idiwọ awọn iye * * kan (ti a tọka si nipasẹ awọn atọka ti a we ni [`Pin<P>`]) lati ṣee gbe nipa ṣiṣe ko ṣee ṣe lati pe awọn ọna ti o nilo `&mut T` lori wọn (bii [`mem::swap`]).
//!
//! [`Pin<P>`] le ṣee lo lati fi ipari si eyikeyi ijuboluwole iru `P`, ati bi iru o ṣe ajọṣepọ pẹlu [`Deref`] ati [`DerefMut`].[`Pin<P>`] kan nibiti o yẹ ki a ka `P: Deref` si bi "`P`-style pointer" si `P::Target` ti a pin-nitorinaa, [`Pin`] kan`<`[`Box`] `<T>> jẹ ijuboluwole ti o ni si `T` ti a pin, ati pe`` Pin`]`<`[`Rc`]]`<T>> jẹ ijuboluwo ti a ka si `T` ti a pin.
//! Fun atunṣe, [`Pin<P>`] gbarale awọn imuse ti [`Deref`] ati [`DerefMut`] kii ṣe lati jade kuro ni paramita `self` wọn, ati pe lailai lati pada ijuboluwole si data ti a fiweko nigbati wọn pe wọn lori ijuboluwole ti a pinni.
//!
//! # `Unpin`
//!
//! Ọpọlọpọ awọn oriṣi nigbagbogbo ṣee gbe larọwọto, paapaa nigba ti a pinni, nitori wọn ko gbẹkẹle igbẹkẹle adirẹsi iduroṣinṣin.Eyi pẹlu gbogbo awọn oriṣi ipilẹ (bii [`bool`], [`i32`], ati awọn itọkasi) bakanna pẹlu awọn oriṣi ti o wa ninu awọn iru wọnyi nikan.Awọn oriṣi ti ko bikita nipa pinning ṣe imuse [`Unpin`] auto-trait, eyiti o fagile ipa ti [`Pin<P>`].
//! Fun `T: Unpin`, [`Pin`]`<`[`Apoti`]] `<T>>`ati iṣẹ [`Box<T>`] ni idanimọ, bii ṣe [`Pin`] `<&mut T>` ati `&mut T`.
//!
//! Akiyesi pe pinning ati [`Unpin`] nikan ni ipa lori itọka-lati tẹ `P::Target`, kii ṣe iru ijuboluwole `P` funrararẹ ti o di ni [`Pin<P>`].Fun apẹẹrẹ, boya tabi rara [`Box<T>`] jẹ [`Unpin`] ko ni ipa lori ihuwasi ti [`Pin`]`<`[`Box`] `<T>> (nibi, `T` jẹ itọka-lati tẹ).
//!
//! # Apẹẹrẹ: ilana itọka ara ẹni
//!
//! Ṣaaju ki a lọ sinu awọn alaye diẹ sii lati ṣalaye awọn iṣeduro ati awọn yiyan ti o ni nkan ṣe pẹlu `Pin<T>`, a jiroro diẹ ninu awọn apẹẹrẹ fun bi o ṣe le lo.
//! Ni idaniloju si [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Eyi jẹ ilana itọka ti ara ẹni nitori aaye gige ni aaye si aaye data.
//! // A ko le sọ fun akopọ nipa iyẹn pẹlu itọkasi deede, nitori apẹẹrẹ yii ko ṣe ṣapejuwe pẹlu awọn ofin yiya deede.
//! //
//! // Dipo a lo ijuboluwo aise, botilẹjẹpe ọkan eyiti a mọ pe ko ni asan, bi a ṣe mọ pe o ntoka si okun.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Lati rii daju pe data ko gbe nigbati iṣẹ naa ba pada, a gbe sinu okiti nibiti yoo wa fun igbesi aye ohun naa, ati ọna kan ti o le wọle si yoo jẹ nipasẹ itọka si rẹ.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // a ṣẹda atokọ nikan ni kete ti data wa ni ipo bibẹkọ ti yoo ti gbe tẹlẹ ṣaaju ki a to bẹrẹ
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // a mọ pe eyi jẹ ailewu nitori ṣiṣatunṣe aaye kan ko gbe gbogbo eto lọ
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Atọka yẹ ki o tọka si ipo to tọ, niwọn igba ti igbekalẹ ko ti i gbe.
//! //
//! // Nibayi, a ni ominira lati gbe ijuboluwole ni ayika.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Niwọn igba ti iru wa ko ṣe imuse Unpin, eyi yoo kuna lati ṣajọ:
//! // jẹ ki mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Apere: intrusive atokọ ti o ni asopọ meji-meji
//!
//! Ninu akojọ intrusive ti o ni asopọ ti ilọpo meji, ikojọpọ ko ṣe ipinnu iranti gangan fun awọn eroja funrararẹ.
//! Ipin ni idari nipasẹ awọn alabara, ati awọn eroja le gbe lori fireemu akopọ ti o wa ni kuru ju gbigba lọ.
//!
//! Lati ṣe iṣẹ yii, gbogbo eroja ni awọn itọka si iṣaaju rẹ ati arọpo ninu atokọ naa.A le fi kun awọn nkan nikan nigbati wọn ba pinni, nitori gbigbe awọn eroja ni ayika yoo sọ awọn itọka naa di asan.Pẹlupẹlu, imuse [`Drop`] ti eroja atokọ ti o ni asopọ yoo alemo awọn itọka ti ṣaju rẹ ati arọpo lati yọ ara rẹ kuro ninu atokọ naa.
//!
//! Ni pataki, a ni lati ni anfani lati gbẹkẹle [`drop`] ti a pe.Ti o ba le pin ipin kan tabi bibẹẹkọ ti di asan laisi pipe [`drop`], awọn itọka si inu rẹ lati awọn eroja adugbo rẹ yoo di asan, eyiti yoo fọ iṣeto data naa.
//!
//! Nitorina, pinning tun wa pẹlu kan [`drop`]-related lopolopo.
//!
//! # `Drop` guarantee
//!
//! Idi ti pinning ni lati ni anfani lati gbẹkẹle igbẹkẹle diẹ ninu data ninu iranti.
//! Lati ṣe iṣẹ yii, kii ṣe gbigbe data nikan ni ihamọ;ṣiṣe ipin, atunkọ, tabi bibẹkọ ti sọ iranti ti a lo lati tọju data di asan ni ihamọ, ju.
//! Ni ipari, fun data ti a fi pindi o ni lati ṣetọju ailopin pe *iranti rẹ kii yoo di alaile tabi tun ṣe lati akoko ti o ba pinned titi di igba ti a pe [`drop`]*.Ni ẹẹkan ti [`drop`] ba pada tabi panics, iranti le ṣee tun lo.
//!
//! Iranti le jẹ "invalidated" nipasẹ ipinpo iṣẹ, ṣugbọn pẹlu nipasẹ rirọpo [`Some(v)`] nipasẹ [`None`], tabi pipe [`Vec::set_len`] si "kill" diẹ ninu awọn eroja kuro ti vector.O le ṣe atunkọ nipa lilo [`ptr::write`] lati tun kọwe laisi pipe apanirun akọkọ.Ko si ọkan ninu eyi ti a gba laaye fun data ti a pinni laisi pipe [`drop`].
//!
//! Eyi ni deede iru iṣeduro pe atokọ asopọ asopọ lati apakan ti tẹlẹ nilo lati ṣiṣẹ ni deede.
//!
//! Ṣe akiyesi pe iṣeduro yii ko *tumọ si pe iranti ko jo!O tun dara patapata lati ma pe [`drop`] lori eroja ti a pinni (fun apẹẹrẹ, o tun le pe [`mem::forget`] lori [`Pin`]`<`[`Box`] `<T>>)).Ninu apẹẹrẹ ti atokọ ti o ni asopọ ilọpo meji, eroja yẹn yoo kan wa ninu atokọ naa.Sibẹsibẹ o le ma ṣe ọfẹ tabi tun lo ibi ipamọ* laisi pipe [`drop`] *.
//!
//! # `Drop` implementation
//!
//! Ti iru rẹ ba lo pinning (gẹgẹbi awọn apẹẹrẹ meji loke), o ni lati ṣọra nigbati o n ṣe imuse [`Drop`].Iṣẹ [`drop`] gba `&mut self`, ṣugbọn eyi ni a pe *paapaa ti o ba tẹ iru rẹ tẹlẹ*!O dabi pe olupilẹṣẹ ni a npe ni [`Pin::get_unchecked_mut`] laifọwọyi.
//!
//! Eyi ko le fa iṣoro ninu koodu ailewu nitori imuse iru kan ti o gbẹkẹle pinni nilo koodu ti ko ni aabo, ṣugbọn mọ pe ṣiṣe ipinnu lati lo lilo pinni ni oriṣi rẹ (fun apẹẹrẹ nipasẹ ṣiṣe diẹ ninu išišẹ lori [`Pin`]`<&Ara>`tabi [`Pin`] `<&mut Self>`) ni awọn abajade fun imuse [`Drop`] rẹ daradara: ti o ba le jẹ iru nkan kan ti iru rẹ, o gbọdọ tọju [`Drop`] bi gbigba aitọ [`Pin`]`<&mut Ara>`.
//!
//!
//! Fun apẹẹrẹ, o le ṣe `Drop` bii atẹle:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` o dara nitori a mọ pe iye yii ko tun lo lẹhin ti o ju silẹ.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Gangan ju koodu lọ nibi.
//!         }
//!     }
//! }
//! ```
//!
//! Iṣẹ `inner_drop` ni iru ti [`drop`]*yẹ ki o ni*, nitorinaa eyi rii daju pe o ko lo `self`/`this` lairotẹlẹ ni ọna ti o wa ni rogbodiyan pẹlu pinning.
//!
//! Pẹlupẹlu, ti iru rẹ ba jẹ `#[repr(packed)]`, akopọ yoo gbe awọn aaye laifọwọyi ni ayika lati ni anfani lati ju wọn silẹ.O le paapaa ṣe iyẹn fun awọn aaye ti o ṣẹlẹ lati wa ni deede to.Gẹgẹbi abajade, o ko le lo pinni pẹlu iru `#[repr(packed)]` kan.
//!
//! # Awọn asọtẹlẹ ati Pinning eto
//!
//! Nigbati o ba n ṣiṣẹ pẹlu awọn ilana ti a pinni, ibeere naa waye bi eniyan ṣe le wọle si awọn aaye ti ilana yẹn ni ọna ti o gba kan [`Pin`]`<&mut Struct>`.
//! Ọna ti o jẹ deede ni lati kọ awọn ọna oluranlọwọ (eyiti a pe ni *awọn asọtẹlẹ*) ti o tan [`Pin`]`<&mut Struct>`sinu itọkasi aaye, ṣugbọn iru iru itọkasi wo ni o ni?Ṣe o jẹ ``Pin`] `<&mut Field>` tabi `&mut Field`?
//! Ibeere kanna ni o waye pẹlu awọn aaye ti `enum` kan, ati tun nigbati o ba ṣe akiyesi awọn iru container/wrapper bii [`Vec<T>`], [`Box<T>`], tabi [`RefCell<T>`].
//! (Ibeere yii kan si awọn iyipada mejeeji ati awọn itọkasi ti a pin, a kan lo ọrọ ti o wọpọ julọ ti awọn ifọkasi idibajẹ nibi fun apejuwe.)
//!
//! O wa ni jade pe o jẹ otitọ si onkọwe ti eto data lati pinnu boya iṣiro ti a pinni fun aaye kan pato yipada [`Pin`]`<&mut Struct>`sinu [`Pin`] `<&mut Field>` tabi `&mut Field`.Awọn inira kan wa botilẹjẹpe, ati idiwọ pataki julọ ni *aitasera*:
//! gbogbo aaye le jẹ *boya* jẹ iṣẹ akanṣe si itọkasi ti a pinni,*tabi* ti pinning kuro bi apakan ti iṣiro naa.
//! Ti awọn mejeeji ba ṣe fun aaye kanna, iyẹn yoo ṣeeṣe ki o jẹ aiburu!
//!
//! Gẹgẹbi onkọwe ti eto data o gba lati pinnu fun aaye kọọkan boya fifin "propagates" si aaye yii tabi rara.
//! Pinning ti o ntan ni a tun pe ni "structural", nitori pe o tẹle ilana ti iru.
//! Ninu awọn abala atẹle, a ṣe apejuwe awọn ero ti o ni lati ṣe fun boya yiyan.
//!
//! ## Pinning *kii ṣe* igbekale fun `field`
//!
//! O le dabi ẹni ti ko ni oju inu pe aaye ti ipilẹ ti a pinni le ma di, ṣugbọn iyẹn gangan ni yiyan ti o rọrun julọ: ti a ko ba ṣẹda [`Pin`]`<&mut Field>`, ko si nkan ti o le ṣe aṣiṣe!Nítorí, ti o ba ti o ba pinnu pe diẹ ninu oko ko ni ni igbekale pinning, gbogbo awọn ti o ni lati rii daju ni wipe ti o ko ṣẹda a pinned tọka si pe oko.
//!
//! Awọn aaye laisi pinni igbekale le ni ọna asọtẹlẹ ti o yipada [`Pin`]`<&mut Struct>`sinu `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Eyi dara nitori pe `field` ko ṣe akiyesi pinni.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! O tun le `impl Unpin for Struct`*paapaa ti* iru `field` kii ṣe [`Unpin`].Ohun ti iru yẹn ronu nipa pinni kii ṣe ibamu nigbati ko ba ṣẹda [`Pin`]`<&mut Field>`.
//!
//! ## Pinning *jẹ* igbekale fun `field`
//!
//! Aṣayan miiran ni lati pinnu pe pinning jẹ "structural" fun `field`, ti o tumọ si pe ti o ba ṣe atokọ iṣeto lẹhinna bẹ naa ni aaye naa.
//!
//! Eyi ngbanilaaye kikọ asọtẹlẹ kan ti o ṣẹda aaye kan [`Pin`]` <&mut>>, nitorinaa n jẹri pe a pin aaye naa:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Eyi dara nitori pe a pin `field` nigbati `self` ba wa.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Sibẹsibẹ, pinni igbekale wa pẹlu awọn ibeere afikun diẹ:
//!
//! 1. Ẹya naa gbọdọ jẹ [`Unpin`] nikan ti gbogbo awọn aaye igbekale jẹ [`Unpin`].Eyi ni aiyipada, ṣugbọn [`Unpin`] jẹ trait ti o ni aabo, nitorinaa bi onkọwe ti iṣeto o jẹ ojuṣe rẹ *kii ṣe* lati ṣafikun ohunkan bi `impl<T> Unpin for Struct<T>`.
//! (Ṣe akiyesi pe fifi iṣẹ iṣiro kan nilo koodu ailewu, nitorinaa otitọ pe [`Unpin`] jẹ trait ti ko ni aabo ko fọ ilana ti o ni lati ni aibalẹ nipa eyikeyi eyi ti o ba lo `ailewu`.)
//! 2. Apanirun ti igbekalẹ ko gbọdọ gbe awọn aaye eto jade kuro ninu ariyanjiyan rẹ.Eyi ni aaye gangan ti a gbe dide ni [previous section][drop-impl]: `drop` gba `&mut self`, ṣugbọn iṣeto (ati nitorinaa awọn aaye rẹ) le ti ni pinni ṣaaju.
//!     O ni lati rii daju pe o ko gbe aaye kan ninu imuse [`Drop`] rẹ.
//!     Ni pataki, bi a ti salaye tẹlẹ, eyi tumọ si pe eto rẹ gbọdọ *ko* jẹ `#[repr(packed)]`.
//!     Wo apakan yẹn fun bii o ṣe le kọ [`drop`] ni ọna ti alapọpọ le ṣe iranlọwọ fun ọ kii ṣe fifọ pinning lairotẹlẹ.
//! 3. O gbọdọ rii daju pe o gbe [`Drop` guarantee][drop-guarantee] duro:
//!     ni kete ti a ba kọ eto rẹ, iranti ti o ni akoonu ninu rẹ ko ni atunkọ tabi tunṣe pinpin laisi pipe awọn apanirun akoonu naa.
//!     Eyi le jẹ ti ẹtan, bi ẹlẹri nipasẹ [`VecDeque<T>`]: apanirun ti [`VecDeque<T>`] le kuna lati pe [`drop`] lori gbogbo awọn eroja ti ọkan ninu awọn apanirun naa panics.Eyi rufin iṣeduro [`Drop`], nitori pe o le ja si awọn eroja ni gbigbe kakiri laisi pipe apanirun wọn.([`VecDeque<T>`] ko ni awọn asọtẹlẹ pinning, nitorinaa eyi ko fa ailagbara.)
//! 4. Iwọ ko gbọdọ pese awọn iṣẹ miiran miiran ti o le ja si gbigbe data kuro ni awọn aaye igbekale nigbati iru rẹ ba di.Fun apẹẹrẹ, ti iṣeto naa ba ni [`Option<T>`] ati pe iṣẹ `ya-bi pẹlu iru `fn(Pin<&mut Struct<T>>) -> Option<T>`, iṣẹ naa le ṣee lo lati gbe `T` kan lati `Struct<T>` ti a ti pin-eyiti o tumọ si sisọ pọ ko le jẹ ilana fun aaye ti o mu eyi data.
//!
//!     Fun apẹẹrẹ ti eka diẹ sii ti gbigbe data jade kuro ninu iru pinni kan, fojuinu ti [`RefCell<T>`] ba ni ọna `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` kan.
//!     Lẹhinna a le ṣe awọn atẹle:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Eyi jẹ ajalu, o tumọ si pe a le kọkọ akoonu ti [`RefCell<T>`] akọkọ (lilo `RefCell::get_pin_mut`) ati lẹhinna gbe akoonu yẹn ni lilo itọkasi iyipada ti a ni nigbamii.
//!
//! ## Examples
//!
//! Fun iru bii [`Vec<T>`], awọn iṣeeṣe mejeeji (pinni igbekale tabi rara) jẹ oye.
//! [`Vec<T>`] kan pẹlu pinni igbekale le ni awọn ọna `get_pin`/`get_pin_mut` lati gba awọn ifọkasi pinni si awọn eroja.Sibẹsibẹ, ko le * gba laaye lati pe [`pop`][Vec::pop] lori [`Vec<T>`] ti a pin nitori pe yoo gbe awọn akoonu (ti a pinni ti iṣeto)!Tabi o le gba [`push`][Vec::push] laaye, eyiti o le ṣe ipin ati nitorinaa tun le gbe awọn akoonu naa.
//!
//! [`Vec<T>`] kan laisi pinni igbekale le `impl<T> Unpin for Vec<T>`, nitori pe a ko awọn akoonu inu rẹ rara ati pe [`Vec<T>`] funrararẹ dara pẹlu gbigbe pẹlu.
//! Ni aaye yẹn pinning kan ko ni ipa lori vector rara.
//!
//! Ninu ile-ikawe boṣewa, awọn oriṣi ijuboluwo ni gbogbogbo ko ni pinni igbekale, ati nitorinaa wọn ko pese awọn isomọ pinni.Eyi ni idi ti `Box<T>: Unpin` ṣe mu fun gbogbo `T`.
//! O jẹ oye lati ṣe eyi fun awọn oriṣi ijuboluwole, nitori gbigbe `Box<T>` ko gbe `T` gangan: [`Box<T>`] le jẹ gbigbe lọfẹ (aka `Unpin`) paapaa ti `T` kii ṣe.Ni otitọ, paapaa [`Pin`]`<`[`Box`] `<T>> 'Ati [`Pin`]` <&mut T> `ni o wa nigbagbogbo [`Unpin`] ara wọn, fun idi kanna: awọn akoonu ti wọn (awọn `T`) ti wa ni pinned, ṣugbọn awọn ifẹnule ara wọn le ṣee gbe lai gbigbe awọn pinned data.
//! Fun [`Box<T>`] ati [`Pin`]`<`[`Box`] `<T>>,, boya a pin akoonu naa jẹ ominira patapata ti boya o ti tẹ ijuboluwole, itumo pinning kii ṣe * igbekale.
//!
//! Nigbati o ba n ṣe awopọ apapọ [`Future`] kan, iwọ yoo nigbagbogbo nilo isọdi eto fun futures ti o ni itẹ-ẹiyẹ, bi o ṣe nilo lati ni awọn itọka atokọ si wọn lati pe [`poll`].
//! Ṣugbọn ti akopọ rẹ ba ni eyikeyi data miiran ti ko nilo lati wa ni pinni, o le ṣe awọn aaye wọnyẹn kii ṣe ilana ati nitorinaa larọwọto wọle si wọn pẹlu itọkasi iyipada paapaa nigbati o kan ni [`Pin`]`<&mut Self>`(iru bii ninu imuse [`poll`] tirẹ).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// A ijuboluwole ijuboluwole.
///
/// Eyi jẹ apo-iwe ti o wa ni ayika iru ijuboluwole eyiti o jẹ ki ijuboluwole "pin" naa ni iye rẹ ni aaye, idilọwọ iye ti itọkasi nipa ijuboluwo naa lati gbe ayafi ti o ba ṣe [`Unpin`].
///
///
/// *Wo iwe [`pin` module] fun alaye kan ti pinni.*
///
/// [`pin` module]: self
///
// Note: awọn `Clone` nianfani ni isalẹ fa unsoundness bi o ti ṣee ṣe lati se
// `Clone` fun awọn itọkasi iyipada.
// Wo <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> fun awọn alaye diẹ sii.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Awọn imuṣẹ wọnyi ko ṣe ipilẹṣẹ lati yago fun awọn ọran ohun.
// `&self.pointer` ko yẹ ki o wọle si awọn imuṣẹ trait ti a ko gbẹkẹle.
//
// Wo <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> fun awọn alaye diẹ sii.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Kọ `Pin<P>` tuntun ni ayika ijuboluwo si diẹ ninu data ti iru ti o n ṣe [`Unpin`].
    ///
    /// Kii `Pin::new_unchecked`, ọna yii jẹ ailewu nitori ijuboluwole `P` awọn iforukọsilẹ si iru [`Unpin`] kan, eyiti o fagile awọn onigbọwọ pinni.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // Aabo: iye ti o tọka si jẹ `Unpin`, nitorinaa ko ni awọn ibeere
        // ni ayika pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Ṣiṣii `Pin<P>` yii ti o n pada ijuboluwole ti o wa.
    ///
    /// Eyi nilo pe data inu `Pin` yii jẹ [`Unpin`] ki a le foju awọn ailagbara pinning nigbati a ba ṣii rẹ.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Kọ `Pin<P>` tuntun ni ayika itọkasi si diẹ ninu awọn data ti iru kan ti o le tabi ko le ṣe `Unpin`.
    ///
    /// Ti awọn iforukọsilẹ `pointer` si iru `Unpin` kan, o yẹ ki o lo `Pin::new` dipo.
    ///
    /// # Safety
    ///
    /// Olukọ yii ko ni aabo nitori a ko le ṣe onigbọwọ pe a ti pin data ti o tọka si nipasẹ `pointer`, ti o tumọ si pe data ko ni gbe tabi ibi ipamọ rẹ ko ni idibajẹ titi yoo fi silẹ.
    /// Ti `Pin<P>` ti a kọ ko ṣe onigbọwọ pe data `P` data ti wa ni pinned, iyẹn jẹ irufin adehun API ati pe o le ja si ihuwasi ti ko ni alaye ni awọn iṣẹ (safe) nigbamii.
    ///
    /// Nipa lilo yi ọna, o ti wa ni ṣiṣe a promise nipa awọn `P::Deref` ati `P::DerefMut` imuṣẹ, ti o ba ti nwọn tẹlẹ.
    /// Ti o ṣe pataki julọ, wọn ko gbọdọ jade kuro ninu awọn ariyanjiyan `self` wọn: `Pin::as_mut` ati `Pin::as_ref` yoo pe `DerefMut::deref_mut` ati `Deref::deref`*lori ijuboluwo ti a pinni* ati reti awọn ọna wọnyi lati ṣe atilẹyin awọn alaini pinning.
    /// Pẹlupẹlu, nipa pipe ọna yii iwọ promise pe itọkasi `P` awọn iforukọsilẹ si kii yoo ni gbigbe kuro lẹẹkansii;ni pato, o gbodo ko ni le ṣee ṣe lati gba a `&mut P::Target` ati ki o si gbe jade ti awọn ti itọkasi (lilo, fun apẹẹrẹ [`mem::swap`]).
    ///
    ///
    /// Fun apẹẹrẹ, pipe `Pin::new_unchecked` lori `&'a mut T` ko ni ailewu nitori lakoko ti o ni anfani lati fi sii fun igbesi aye ti a fun ni `'a`, iwọ ko ni iṣakoso lori boya o wa ni titọ ni kete ti `'a` pari:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Eyi yẹ ki o tumọ si pe alatako `a` ko le tun gbe rara.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adirẹsi ti `a` yipada si `akopọ b`, nitorinaa `a` ti gbe paapaa botilẹjẹpe a ti sọ tẹlẹ!A ti ṣẹ adehun pinning API.
    /////
    /// }
    /// ```
    ///
    /// Iye kan, ni kete ti o pinni, gbọdọ wa ni pipin lailai (ayafi ti iru rẹ ba ṣe awọn `Unpin`).
    ///
    /// Bákan náà, pipe `Pin::new_unchecked` lori ohun `Rc<T>` jẹ lewu nitori nibẹ ni o le jẹ aliases si kanna data ti o wa ni ko koko-ọrọ awọn ihamọ pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Eyi yẹ ki o tumọ si pe alamọ le ko tun gbe lẹẹkansi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Bayi, ti o ba `x` je nikan ni itọkasi, a ni a mutable tọka si data ti a pinned loke, eyi ti a le lo lati gbe o bi a ti ri ninu awọn ti tẹlẹ apẹẹrẹ.
    ///     // A ti ṣẹ adehun pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Gba itọkasi pinni pinni lati ọdọ ijuboluwo ti a pinni yii.
    ///
    /// Eyi jẹ ọna jeneriki lati lọ lati `&Pin<Pointer<T>>` si `Pin<&T>`.
    /// O jẹ ailewu nitori, gẹgẹ bi apakan ti adehun ti `Pin::new_unchecked`, ijuboluwo ko le gbe lẹhin ti `Pin<Pointer<T>>` ti ṣẹda.
    ///
    /// "Malicious" awọn imuṣẹ ti `Pointer::Deref` bakanna ni adehun nipasẹ adehun ti `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // Aabo: wo awọn iwe lori iṣẹ yii
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Ṣiṣii `Pin<P>` yii ti o n pada ijuboluwole ti o wa.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu.O gbọdọ ṣe onigbọwọ pe iwọ yoo tẹsiwaju lati tọju ijuboluwole `P` bi a ti pin lẹyin ti o pe iṣẹ yii, ki awọn alailera lori iru `Pin` le jẹ iduro.
    /// Ti koodu naa nipa lilo abajade `P` ko tẹsiwaju lati ṣetọju awọn alaini pinni ti o jẹ o ṣẹ ti adehun API ati pe o le ja si ihuwasi ti a ko ṣalaye ni awọn iṣẹ (safe) nigbamii.
    ///
    ///
    /// Ti data ipilẹ jẹ [`Unpin`], o yẹ ki o lo [`Pin::into_inner`] dipo.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Gba itọkasi iyipada ti a pinni lati ọdọ ijuboluwo ti a pinni yii.
    ///
    /// Eyi jẹ ọna jeneriki lati lọ lati `&mut Pin<Pointer<T>>` si `Pin<&mut T>`.
    /// O jẹ ailewu nitori, gẹgẹ bi apakan ti adehun ti `Pin::new_unchecked`, ijuboluwo ko le gbe lẹhin ti `Pin<Pointer<T>>` ti ṣẹda.
    ///
    /// "Malicious" awọn imuṣẹ ti `Pointer::DerefMut` bakanna ni adehun nipasẹ adehun ti `Pin::new_unchecked`.
    ///
    /// Ọna yii wulo nigbati o ba n ṣe awọn ipe lọpọlọpọ si awọn iṣẹ ti o jẹ iru iru pinni kan.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // se nkan
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` run `self`, nitorinaa tun gbe `Pin<&mut Self>` pada nipasẹ `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // Aabo: wo awọn iwe lori iṣẹ yii
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Fi iye tuntun si iranti lẹhin itọkasi pinni.
    ///
    /// Eleyi yoo kọ nkan bo pinned data, ṣugbọn ti o jẹ dara: awọn oniwe-destructor olubwon sare niwaju jije kọ, ki ko si pinning lopolopo ti wa ni ru.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Ṣe PIN tuntun nipasẹ titoka iye inu.
    ///
    /// Fun apẹẹrẹ, ti o ba fe lati gba a `Pin` kan ti a ti oko ti nkankan, o le lo yi lati gba wọle si ti oko ninu ọkan ila ti koodu.
    /// Sibẹsibẹ, ọpọlọpọ awọn gotchas wa pẹlu "pinning projections" wọnyi;
    /// wo iwe [`pin` module] fun awọn alaye siwaju sii lori koko yẹn.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu.
    /// O gbọdọ ṣe onigbọwọ pe data ti o pada ko ni gbe niwọn igba ti iye ariyanjiyan ko gbe (fun apẹẹrẹ, nitori o jẹ ọkan ninu awọn aaye ti iye yẹn), ati pe iwọ ko jade kuro ninu ariyanjiyan ti o gba si iṣẹ inu ilohunsoke.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // Aabo: Adehun aabo fun `new_unchecked` gbọdọ jẹ
        // ọwọ si nipa awọn olupe ti.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// N ni a pín itọkasi jade ti a pin.
    ///
    /// Eyi jẹ ailewu nitori ko ṣee ṣe lati jade kuro ni itọkasi pinpin.
    /// O le dabi pe ọrọ kan wa nibi pẹlu iyipada inu: ni otitọ, o *ṣee ṣe* lati gbe `T` lati `&RefCell<T>` kan.
    /// Sibẹsibẹ, eyi kii ṣe iṣoro niwọn igba ti ko si tun wa `Pin<&T>` kan ti o tọka si data kanna, ati pe `RefCell<T>` ko jẹ ki o ṣẹda itọkasi kan si awọn akoonu rẹ.
    ///
    /// Wo ijiroro lori ["pinning projections"] fun awọn alaye siwaju sii.
    ///
    /// Note: `Pin` tun ṣe awọn `Deref` si ibi-afẹde naa, eyiti o le lo lati wọle si iye inu.
    /// Sibẹsibẹ, `Deref` nikan pese itọkasi kan ti o ngbe fun igba ti yiya ti `Pin`, kii ṣe igbesi aye ti `Pin` funrararẹ.
    /// Ọna yii ngbanilaaye titan `Pin` sinu itọkasi pẹlu igbesi aye kanna bi `Pin` atilẹba.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Yi awọn `Pin<&mut T>` yii pada si `Pin<&T>` pẹlu igbesi aye kanna.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Gba itọkasi iyipada si data inu `Pin` yii.
    ///
    /// Eyi nilo pe data inu `Pin` yii jẹ `Unpin`.
    ///
    /// Note: `Pin` tun ṣe awọn `DerefMut` si data, eyiti o le lo lati wọle si iye inu.
    /// Sibẹsibẹ, `DerefMut` nikan pese itọkasi kan ti o ngbe fun igba ti yiya ti `Pin`, kii ṣe igbesi aye ti `Pin` funrararẹ.
    ///
    /// Ọna yii ngbanilaaye titan `Pin` sinu itọkasi pẹlu igbesi aye kanna bi `Pin` atilẹba.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Gba itọkasi iyipada si data inu `Pin` yii.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu.
    /// O gbọdọ ṣe onigbọwọ pe iwọ kii yoo gbe data jade kuro ninu itọkasi iyipada ti o gba nigba ti o pe iṣẹ yii, ki awọn alailera lori iru `Pin` le jẹ iduro.
    ///
    ///
    /// Ti data ipilẹ jẹ `Unpin`, o yẹ ki o lo `Pin::get_mut` dipo.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ṣe PIN tuntun kan nipa aworan agbaye iye inu.
    ///
    /// Fun apẹẹrẹ, ti o ba fe lati gba a `Pin` kan ti a ti oko ti nkankan, o le lo yi lati gba wọle si ti oko ninu ọkan ila ti koodu.
    /// Sibẹsibẹ, ọpọlọpọ awọn gotchas wa pẹlu "pinning projections" wọnyi;
    /// wo iwe [`pin` module] fun awọn alaye siwaju sii lori koko yẹn.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu.
    /// O gbọdọ ṣe onigbọwọ pe data ti o pada ko ni gbe niwọn igba ti iye ariyanjiyan ko gbe (fun apẹẹrẹ, nitori o jẹ ọkan ninu awọn aaye ti iye yẹn), ati pe iwọ ko jade kuro ninu ariyanjiyan ti o gba si iṣẹ inu ilohunsoke.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // Aabo: olupe naa ni iduro fun ko gbe awọn
        // iye jade ti itọkasi yii.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // Aabo: bi iye ti `this` jẹ ẹri pe ko ni
        // ti gbe jade, ipe yii si `new_unchecked` jẹ ailewu.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Gba itọkasi ti a pinni lati itọkasi kan.
    ///
    /// Eyi jẹ ailewu, nitori `T` ti yawo fun igbesi aye `'static`, eyiti ko pari.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // Aabo: Awọn onigbọwọ awin aimi data ko ni jẹ
        // moved/invalidated titi di igba ti o lọ silẹ (eyiti kii ṣe rara).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Gba itọkasi iyipada ti a pinni lati itọkasi itọkasi iyipada aimi.
    ///
    /// Eyi jẹ ailewu, nitori `T` ti yawo fun igbesi aye `'static`, eyiti ko pari.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // Aabo: Awọn onigbọwọ awin aimi data ko ni jẹ
        // moved/invalidated titi di igba ti o lọ silẹ (eyiti kii ṣe rara).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: eyi tumọ si pe eyikeyi impl ti `CoerceUnsized` ti o fun laaye ni ipa lati
// a iru ti impls `Deref<Target=impl !Unpin>` to a iru ti impls `Deref<Target=Unpin>` ni unsound.
// Eyikeyi iru iwunilori yoo jasi jẹ aibikita fun awọn idi miiran, botilẹjẹpe, nitorinaa a nilo lati ṣọra lati ma jẹ ki iru awọn iwuri bẹẹ de ni std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}