// ignore-tidy-filelength

//! Isakoso bibẹ ati ifọwọyi.
//!
//! Fun awọn alaye diẹ sii wo [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Funfun rust memchr imuse, ya lati rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Iṣẹ yii jẹ ti gbogbo eniyan nikan nitori ko si ọna miiran lati sọ kikoro akọọlẹ.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Pada nọmba awọn eroja ninu ege.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // Aabo: ohun orin nitori a ṣe agbejade aaye ipari bi lilo (eyiti o gbọdọ jẹ)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // Aabo: eyi jẹ ailewu nitori `&[T]` ati `FatPtr<T>` ni ipilẹ kanna.
            // `std` nikan le ṣe iṣeduro yii.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Rọpo pẹlu `crate::ptr::metadata(self)` nigbati iyẹn jẹ iduroṣinṣin.
            // Gẹgẹ bi kikọ yii eyi fa aṣiṣe "Const-stable functions can only call other const-stable functions" kan.
            //

            // Aabo: Wiwọle si iye lati ajọṣepọ `PtrRepr` jẹ ailewu nitori * const T
            // ati PtrComponents<T>ni awọn ipalemo iranti kanna.
            // std nikan le ṣe iṣeduro yii.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Padà `true` ti o ba ti bibẹ ni o ni kan ipari ti 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Pada nkan akọkọ ti bibẹ, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Pada ijuboluwole iyipada si nkan akọkọ ti gige, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Pada akọkọ ati gbogbo iyoku ti awọn eroja ti ege, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Pada akọkọ ati gbogbo iyoku ti awọn eroja ti ege, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Pada awọn ti o kẹhin ati gbogbo awọn iyokù ti awọn eroja ti awọn bibẹ, tabi `None` ti o ba jẹ sofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Pada awọn ti o kẹhin ati gbogbo awọn iyokù ti awọn eroja ti awọn bibẹ, tabi `None` ti o ba jẹ sofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Pada ano ti o kẹhin ninu ege, tabi `None` ti o ba ṣofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Pada ijuboluwole iyipada si nkan ti o kẹhin ninu ege.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Pada itọkasi si eroja kan tabi isomọ ti o da lori iru itọka naa.
    ///
    /// - Ti o ba fun ni ipo, o pada tọka si eroja ni ipo yẹn tabi `None` ti o ba wa ni aala.
    ///
    /// - Ti o ba fun ni sakani kan, o tun pada si ipin ti o baamu si ibiti yẹn, tabi `None` ti o ba wa ni aala.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Pada tọka iyipada kan si nkan tabi ijẹrisi ti o da lori iru itọka (wo [`get`]) tabi `None` ti itọka naa ko ba kọja.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Pada a tọka si ohun ano tabi subslice, lai ṣe igboro yiyewo.
    ///
    /// Fun yiyan ailewu wo [`get`].
    ///
    /// # Safety
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro jẹ *[ihuwasi ti a ko ṣalaye]* paapaa ti itọkasi itọkasi ko ba lo.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // Aabo: olupe gbọdọ gbe atilẹyin pupọ julọ awọn ibeere aabo fun `get_unchecked`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Pada tọka iyipada kan si nkan tabi ijẹrisi, laisi ṣe ayẹwo awọn aala.
    ///
    /// Fun yiyan ailewu wo [`get_mut`].
    ///
    /// # Safety
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro jẹ *[ihuwasi ti a ko ṣalaye]* paapaa ti itọkasi itọkasi ko ba lo.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // Aabo: olupe gbọdọ gbe atilẹyin awọn ibeere aabo fun `get_unchecked_mut`;
        // ege naa jẹ dereferencable nitori `self` jẹ itọkasi ailewu.
        // Atọka ti o pada wa ni ailewu nitori awọn iwuri ti `SliceIndex` ni lati ṣe idaniloju pe o jẹ.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Pada a aise ijuboluwole si bibẹ saarin.
    ///
    /// Olupe naa gbọdọ rii daju pe ege naa wa ju ijuboluwole iṣẹ yii pada, tabi bẹẹkọ o yoo pari si tọka si idoti.
    ///
    /// Olupe naa gbọdọ tun rii daju pe iranti ti XXXX ijuboluwole tọka si ko kọ si (ayafi inu `UnsafeCell` kan) ni lilo ijuboluwole tabi ijuboluwo eyikeyi ti o wa lati inu rẹ.
    /// Ti o ba nilo lati paarọ awọn akoonu ti bibẹ pẹlẹbẹ naa, lo [`as_mut_ptr`].
    ///
    /// Ṣiṣatunṣe apo eiyan ti a tọka nipasẹ bibẹ pẹlẹbẹ yii le fa ki ifipamọ rẹ wa ni atunto, eyiti yoo tun jẹ ki awọn itọkasi eyikeyi tọ si.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Pada ijuboluwo iyipada ti ko lewu si ibi ifipamọ nkan bibẹ.
    ///
    /// Olupe naa gbọdọ rii daju pe ege naa wa ju ijuboluwole iṣẹ yii pada, tabi bẹẹkọ o yoo pari si tọka si idoti.
    ///
    /// Ṣiṣatunṣe apo eiyan ti a tọka nipasẹ bibẹ pẹlẹbẹ yii le fa ki ifipamọ rẹ wa ni atunto, eyiti yoo tun jẹ ki awọn itọkasi eyikeyi tọ si.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Pada awọn atokọ aise meji ti o tan ni nkan.
    ///
    /// Ibiti o pada wa ni sisi idaji, eyi ti o tumọ si pe awọn itọka ipari ipari *ọkan ti o kọja* abala ikẹhin ti ege.
    /// Ni ọna yii, nkan ti o ṣofo wa ni ipoduduro nipasẹ awọn itọka dogba meji, ati iyatọ laarin awọn itọka meji duro fun iwọn ti ege.
    ///
    /// Wo [`as_ptr`] fun awọn ikilọ lori lilo awọn itọkasi wọnyi.Atọka ipari nbeere pele ni afikun, nitori ko tọka si nkan to wulo ninu ege.
    ///
    /// Iṣẹ yii wulo fun ibaraenisepo pẹlu awọn wiwo ajeji eyiti o lo awọn itọka meji lati tọka si ọpọlọpọ awọn eroja ni iranti, bi o ṣe wọpọ ni C++ .
    ///
    ///
    /// O tun le wulo lati ṣayẹwo ti ijuboluwo si eroja kan tọka si nkan ti bibẹ pẹlẹbẹ yii:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // Aabo: `add` nibi wa ni ailewu, nitori:
        //
        //   - Awọn itọka mejeeji jẹ apakan ti nkan kanna, bi titọka taara kọja ohun naa tun ka.
        //
        //   - Iwọn ti bibẹrẹ ko tobi ju awọn baiti isize::MAX, bi a ṣe akiyesi nibi:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Ko si ipari ni ayika ti o kan, nitori awọn ege ko ni ipari ti o kọja opin aaye adirẹsi.
        //
        // Wo iwe ti pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Padà awọn meji lewu mutable ifẹnule leta ti awọn bibẹ.
    ///
    /// Ibiti o pada wa ni sisi idaji, eyi ti o tumọ si pe awọn itọka ipari ipari *ọkan ti o kọja* abala ikẹhin ti ege.
    /// Ni ọna yii, nkan ti o ṣofo wa ni ipoduduro nipasẹ awọn itọka dogba meji, ati iyatọ laarin awọn itọka meji duro fun iwọn ti ege.
    ///
    /// Wo [`as_mut_ptr`] fun awọn ikilọ lori lilo awọn itọkasi wọnyi.
    /// Atọka ipari nbeere pele ni afikun, nitori ko tọka si nkan to wulo ninu ege.
    ///
    /// Iṣẹ yii wulo fun ibaraenisepo pẹlu awọn wiwo ajeji eyiti o lo awọn itọka meji lati tọka si ọpọlọpọ awọn eroja ni iranti, bi o ṣe wọpọ ni C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // Aabo: Wo as_ptr_range() loke fun idi ti `add` nibi wa lailewu.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Yipada awọn eroja meji ninu gige.
    ///
    /// # Arguments
    ///
    /// * a, Atọka ti eroja akọkọ
    /// * b, Atọka ti eroja keji
    ///
    /// # Panics
    ///
    /// Panics ti `a` tabi `b` ba wa ni aala.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Ko le gba awọn awin iyipada mutable meji lati ọdọ vector kan, nitorinaa dipo lo awọn itọka aise.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // Aabo: `pa` ati `pb` ni a ti ṣẹda lati awọn itọka iyipada ti ko lewu ati tọka
        // si awọn eroja ninu gige ati nitorinaa a ṣe onigbọwọ lati wulo ati deede.
        // Akiyesi pe iraye si awọn eroja lẹhin `a` ati `b` ti ṣayẹwo ati pe yoo panic nigbati o ba kọja aala.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ṣe yiyipada aṣẹ awọn eroja ninu ege, ni aye.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Fun awọn oriṣi kekere, gbogbo olukọ kọọkan ka ni ọna deede ṣe dara.
        // A le ṣe dara julọ, ti a fun ni load/store aiṣedeede daradara, nipa ikojọpọ ẹyọ nla kan ati yiyipada iforukọsilẹ kan.
        //

        // Bi o ṣe yẹ LLVM yoo ṣe eyi fun wa, bi o ti mọ dara julọ ju ti a ṣe boya awọn kika aiṣedeede ni o munadoko (nitori awọn iyipada laarin awọn ẹya ARM oriṣiriṣi, fun apẹẹrẹ) ati kini iwọn chunk ti o dara julọ yoo jẹ.
        // Laanu, bi ti LLVM 4.0 (2017-05) o ṣii lupu nikan, nitorinaa a nilo lati ṣe eyi funrara wa.
        // (Idawọle: yiyipada jẹ iṣoro nitori pe awọn ẹgbẹ le ṣe deede ni otooto-yoo jẹ, nigbati ipari ba jẹ ajeji-nitorinaa ko si ọna ti gbigbejade ṣaaju-ati awọn ifiweranṣẹ lati lo SIMD ti o baamu ni kikun ni aarin.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Lo ojulowo llvm.bswap lati yiyipada u8s pada ni lilo kan
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // Aabo: Awọn ohun pupọ lo wa lati ṣayẹwo nibi:
                //
                // - Akọsilẹ ti `chunk` jẹ boya 4 tabi 8 nitori awọn cfg ayẹwo loke.Nítorí náà, `chunk - 1` jẹ rere.
                // - Atọka pẹlu itọka `i` jẹ itanran bi awọn iṣeduro ṣayẹwo lupu
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Atọka pẹlu itọka `ln - i - chunk = ln - (i + chunk)` dara:
                //   - `i + chunk > 0` jẹ trivially otitọ.
                //   - Awọn iṣeduro ṣayẹwo lupu:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, nitorinaa iyokuro ko ṣiṣẹ.
                // - Awọn ipe `read_unaligned` ati `write_unaligned` dara:
                //   - `pa` ojuami to Ìwé `i` ibi ti `i < ln / 2 - (chunk - 1)` (wo loke) ati `pb` ojuami si Ìwé `ln - i - chunk`, ki mejeji ni o wa ni o kere `chunk` ọpọlọpọ awọn baiti kuro lati opin `self`.
                //
                //   - Eyikeyi iranti ti a ṣe ipilẹ jẹ wulo `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Lo n yi-nipasẹ-16 lati ẹnjinia u16s ni a u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // Aabo: u32 ti ko ṣe deede le ka lati `i` ti `i + 1 < ln` ba jẹ
                // (Ati ki o han `i < ln`), nitori kọọkan ano jẹ 2 baiti ati awọn ti a ba kika 4.
                //
                // `i + chunk - 1 < ln / 2` # nigba majemu
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Niwon o kere ju ipari ti a pin nipasẹ 2, lẹhinna o gbọdọ wa ni awọn ala.
                //
                // Eleyi tun tumo si wipe awọn majemu `0 < i + chunk <= ln` ni nigbagbogbo bọwọ, aridaju awọn `pb` ijuboluwole le ṣee lo lailewu.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // Aabo: `i` ko kere ju idaji gigun pẹlẹbẹ naa
            // iwifun `i` ati `ln - i - 1` jẹ ailewu (`i` bẹrẹ ni 0 ati ki o yoo ko lọ siwaju ju `ln / 2 - 1`).
            // Abala awọn atọka `pa` ati `pb` nitorinaa wulo ati baamu, ati pe a le ka lati ati kọwe si.
            //
            //
            unsafe {
                // Lewu siwopu lati yago fun awọn igboro ṣayẹwo ni ailewu siwopu.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Pada ohun iterator lori awọn bibẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Pada aṣetunṣe ti o fun laaye iyipada iye kọọkan.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Pada aṣetunṣe kan lori gbogbo nkan windows ti ipari `size`.
    /// windows ni lqkan.
    /// Ti bibẹrẹ ba kuru ju `size`, aṣetunṣe ko pada awọn iye kankan.
    ///
    /// # Panics
    ///
    /// Panics ti `size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ti ege naa ba kuru ju `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    /// Awọn chunks jẹ awọn ege ati ki o ko ni lqkan.Ti `chunk_size` ko ba pin ipari ti ege, lẹhinna chunk ti o kẹhin kii yoo ni ipari `chunk_size`.
    ///
    /// Wo [`chunks_exact`] fun iyatọ ti aṣetunṣe yii ti o da awọn akopọ ti awọn ohun elo `chunk_size` deede gaan, ati [`rchunks`] fun aṣiwe kanna ṣugbọn bẹrẹ ni opin ege.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    /// Awọn chunks jẹ awọn ege iyipada, ati pe ko ni lqkan.Ti o ba ti `chunk_size` ko ni pin awọn ipari ti awọn bibẹ, ki o si awọn ti o kẹhin chunk yoo ko ni ipari `chunk_size`.
    ///
    /// Wo [`chunks_exact_mut`] fun iyatọ ti aṣetunṣe yii ti o da awọn akopọ ti awọn eroja deede `chunk_size` pada nigbagbogbo, ati [`rchunks_mut`] fun aṣiwe kanna ṣugbọn bẹrẹ ni opin gige.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    /// Awọn chunks jẹ awọn ege ati ki o ko ni lqkan.
    /// Ti `chunk_size` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `chunk_size-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `remainder` ti aṣetunṣe.
    ///
    ///
    /// Nitori kọọkan chunk nini gangan `chunk_size` eroja, awọn alakojo le igba je ki awọn Abajade koodu dara ju ninu ọran ti [`chunks`].
    ///
    /// Wo [`chunks`] fun iyatọ kan ti aṣetunṣe yii ti o tun da iyoku pada bi nkan kekere, ati [`rchunks_exact`] fun aṣiwe kanna ṣugbọn bẹrẹ ni opin ege.
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    /// Awọn chunks jẹ awọn ege iyipada, ati pe ko ni lqkan.
    /// Ti `chunk_size` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `chunk_size-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `into_remainder` ti aṣetunṣe.
    ///
    ///
    /// Nitori chunk kọọkan ti o ni awọn eroja `chunk_size` deede, alapọpọ le ṣe igbagbogbo koodu ti o ni abajade dara julọ ninu ọran ti [`chunks_mut`].
    ///
    /// Wo [`chunks_mut`] fun iyatọ kan ti aṣetunṣe yii ti o tun da iyoku pada bi nkan kekere, ati [`rchunks_exact_mut`] fun aṣiwe kanna ṣugbọn bẹrẹ ni opin ege.
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Pin ipin naa si ege kan ti awọn eto `N`-element, ni idaniloju pe ko si iyoku.
    ///
    ///
    /// # Safety
    ///
    /// Eyi le pe nikan nigbati
    /// - Bibẹ naa pin si gangan sinu awọn chunks N`-ano (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // Aabo: Awọn chunks eroja 1 ko ni iyoku
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // Aabo: Gigun gige (6) jẹ ọpọ ti 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Iwọnyi yoo jẹ alaimọ:
    /// // jẹ ki awọn ege: &[[_;5]]= slice.as_chunks_unchecked()//Gigun gige naa kii ṣe ọpọ ti 5 jẹ ki awọn ege:&[[_;0]]= slice.as_chunks_unchecked()//Awọn asun-gigun odo ko gba laaye rara
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Aabo: Ipilẹṣẹ wa jẹ deede ohun ti o nilo lati pe eyi
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // Aabo: A sọ nkan ti awọn eroja `new_len * N` sinu
        // ege kan ti `new_len` ọpọlọpọ awọn nkan ti eroja `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Pin ipin naa si ege kan ti awọn ohun elo `N`-element, ti o bẹrẹ ni ibẹrẹ pẹlẹbẹ naa, ati ege ti o ku pẹlu ipari ti o muna kere ju `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // AABO: A ti wa ni ijaya tẹlẹ fun odo, ati rii daju nipasẹ ikole
        // pe ipari ti isomọ jẹ ọpọ ti N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Pin ipin naa si ege kan ti awọn eto `N`-element, ti o bẹrẹ ni ipari pẹrẹrẹ, ati ege ti o ku pẹlu ipari ti o kere ju `N` lọ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // AABO: A ti wa ni ijaya tẹlẹ fun odo, ati rii daju nipasẹ ikole
        // pe ipari ti isomọ jẹ ọpọ ti N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Pada ohun iterator lori `N` eroja ti awọn bibẹ ni akoko kan, o bere ni ibẹrẹ ti awọn bibẹ.
    ///
    /// Awọn chunks jẹ awọn itọkasi orun ati pe ko ṣe lqkan.
    /// Ti `N` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `N-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `remainder` ti aṣetunṣe.
    ///
    ///
    /// Ọna yii jẹ deede jeneriki ti [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Pin ipin naa si ege kan ti awọn eto `N`-element, ni idaniloju pe ko si iyoku.
    ///
    ///
    /// # Safety
    ///
    /// Eyi le pe nikan nigbati
    /// - Bibẹ naa pin si gangan sinu awọn chunks N`-ano (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // Aabo: Awọn chunks eroja 1 ko ni iyoku
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // Aabo: Gigun gige (6) jẹ ọpọ ti 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Iwọnyi yoo jẹ alaimọ:
    /// // jẹ ki awọn ege: &[[_;5]]= slice.as_chunks_unchecked_mut()//Gigun gige naa kii ṣe ọpọ ti 5 jẹ ki awọn ege:&[[_;0]]= slice.as_chunks_unchecked_mut()//odo-ipari chunks ti wa ni ko gba ọ laaye
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // Aabo: Ipilẹṣẹ wa jẹ deede ohun ti o nilo lati pe eyi
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // Aabo: A sọ nkan ti awọn eroja `new_len * N` sinu
        // ege kan ti `new_len` ọpọlọpọ awọn nkan ti eroja `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Pin ipin naa si ege kan ti awọn ohun elo `N`-element, ti o bẹrẹ ni ibẹrẹ pẹlẹbẹ naa, ati ege ti o ku pẹlu ipari ti o muna kere ju `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // AABO: A ti wa ni ijaya tẹlẹ fun odo, ati rii daju nipasẹ ikole
        // pe ipari ti isomọ jẹ ọpọ ti N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Pin ipin naa si ege kan ti awọn eto `N`-element, ti o bẹrẹ ni ipari pẹrẹrẹ, ati ege ti o ku pẹlu ipari ti o kere ju `N` lọ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // AABO: A ti wa ni ijaya tẹlẹ fun odo, ati rii daju nipasẹ ikole
        // pe ipari ti isomọ jẹ ọpọ ti N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Pada ohun iterator lori `N` eroja ti awọn bibẹ ni akoko kan, o bere ni ibẹrẹ ti awọn bibẹ.
    ///
    /// Awọn chunks jẹ awọn itọkasi orun iyipada ati pe ko ṣe lqkan.
    /// Ti `N` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `N-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `into_remainder` ti aṣetunṣe.
    ///
    ///
    /// Ọna yii jẹ deede jeneriki ti [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0. Ṣayẹwo yii yoo jasi julọ yipada si ṣajọ aṣiṣe akoko ṣaaju ọna yii to ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Pada aṣetunṣe lori fifa windows ti awọn eroja `N` ti ege kan, bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    ///
    /// Eyi ni deede jeneriki deede ti [`windows`].
    ///
    /// Ti `N` ba tobi ju iwọn ege lọ, ko ni pada si windows.
    ///
    /// # Panics
    ///
    /// Panics ti `N` jẹ 0.
    /// Iyẹwo yii yoo ṣee ṣe yipada julọ si ṣajọ aṣiṣe akoko ṣaaju ọna yii ni diduro.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni opin bibẹ.
    ///
    /// Awọn chunks jẹ awọn ege ati ki o ko ni lqkan.Ti `chunk_size` ko ba pin ipari ti ege, lẹhinna chunk ti o kẹhin kii yoo ni ipari `chunk_size`.
    ///
    /// Wo [`rchunks_exact`] fun iyatọ ti aṣetunṣe yii ti o da awọn akopọ ti awọn eroja deede `chunk_size` pada nigbagbogbo, ati [`chunks`] fun aṣiwe kanna ṣugbọn bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni opin bibẹ.
    ///
    /// Awọn chunks jẹ awọn ege iyipada, ati pe ko ni lqkan.Ti o ba ti `chunk_size` ko ni pin awọn ipari ti awọn bibẹ, ki o si awọn ti o kẹhin chunk yoo ko ni ipari `chunk_size`.
    ///
    /// Wo [`rchunks_exact_mut`] fun iyatọ ti aṣetunṣe yii ti o da awọn akopọ ti awọn eroja deede `chunk_size` pada nigbagbogbo, ati [`chunks_mut`] fun aṣiwe kanna ṣugbọn bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni opin bibẹ.
    ///
    /// Awọn chunks jẹ awọn ege ati ki o ko ni lqkan.
    /// Ti `chunk_size` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `chunk_size-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `remainder` ti aṣetunṣe.
    ///
    /// Nitori kọọkan chunk nini gangan `chunk_size` eroja, awọn alakojo le igba je ki awọn Abajade koodu dara ju ninu ọran ti [`chunks`].
    ///
    /// Wo [`rchunks`] fun iyatọ ti aṣetunṣe yii ti o tun da iyoku pada bi nkan kekere, ati [`chunks_exact`] fun aṣiwe kanna ṣugbọn bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Pada aṣetunṣe kan lori awọn eroja `chunk_size` ti ege ni akoko kan, bẹrẹ ni opin bibẹ.
    ///
    /// Awọn chunks jẹ awọn ege iyipada, ati pe ko ni lqkan.
    /// Ti `chunk_size` ko ba pin ipari pẹlẹbẹ naa, lẹhinna o kẹhin ti o to awọn eroja `chunk_size-1` yoo ma gba silẹ ati pe o le gba pada lati iṣẹ `into_remainder` ti aṣetunṣe.
    ///
    /// Nitori chunk kọọkan ti o ni awọn eroja `chunk_size` deede, alapọpọ le ṣe igbagbogbo koodu ti o ni abajade dara julọ ninu ọran ti [`chunks_mut`].
    ///
    /// Wo [`rchunks_mut`] fun iyatọ ti aṣetunṣe yii ti o tun da iyoku pada bi nkan kekere, ati [`chunks_exact_mut`] fun aṣiwe kanna ṣugbọn bẹrẹ ni ibẹrẹ bibẹrẹ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ti `chunk_size` jẹ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Pada aṣetunṣe lori bibẹrẹ ti n ṣe awọn ṣiṣan ti kii ṣe agbekọja ti awọn eroja nipa lilo asọtẹlẹ lati ya wọn.
    ///
    /// A pe asọtẹlẹ naa lori awọn eroja meji ti o tẹle ara wọn, o tumọ si pe a pe asọtẹlẹ naa lori `slice[0]` ati `slice[1]` lẹhinna lori `slice[1]` ati `slice[2]` ati bẹbẹ lọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yi ọna ti a le lo lati jade ni lẹsẹsẹ subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Pada aṣetunṣe lori bibẹ pẹlẹpẹlẹ ti n ṣe awọn ṣiṣiṣẹ iyipada ti kii ṣe agbekọja ti awọn eroja ni lilo asọtẹlẹ lati ya wọn.
    ///
    /// A pe asọtẹlẹ naa lori awọn eroja meji ti o tẹle ara wọn, o tumọ si pe a pe asọtẹlẹ naa lori `slice[0]` ati `slice[1]` lẹhinna lori `slice[1]` ati `slice[2]` ati bẹbẹ lọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Yi ọna ti a le lo lati jade ni lẹsẹsẹ subslices:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Pin ipin kan si meji ni itọka kan.
    ///
    /// Ni igba akọkọ ti yoo ni gbogbo awọn atọka lati `[0, mid)` (laisi atokọ `mid` funrararẹ) ati ekeji yoo ni gbogbo awọn atọka lati `[mid, len)` (laisi awọn atọka `len` funrararẹ).
    ///
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // Aabo: `[ptr; mid]` ati `[mid; len]` wa ni inu `self`, eyiti
        // mu awọn ibeere ti `from_raw_parts_mut` ṣẹ.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Pin ipin ege iyipada kan si meji ni itọka kan.
    ///
    /// Ni igba akọkọ ti yoo ni gbogbo awọn atọka lati `[0, mid)` (laisi atokọ `mid` funrararẹ) ati ekeji yoo ni gbogbo awọn atọka lati `[mid, len)` (laisi awọn atọka `len` funrararẹ).
    ///
    ///
    /// # Panics
    ///
    /// Panics ti o ba jẹ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // Aabo: `[ptr; mid]` ati `[mid; len]` wa ni inu `self`, eyiti
        // mu awọn ibeere ti `from_raw_parts_mut` ṣẹ.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Pin ipin kan si meji ni itọka kan, laisi ṣe ayẹwo awọn igboro.
    ///
    /// Ni igba akọkọ ti yoo ni gbogbo awọn atọka lati `[0, mid)` (laisi atokọ `mid` funrararẹ) ati ekeji yoo ni gbogbo awọn atọka lati `[mid, len)` (laisi awọn atọka `len` funrararẹ).
    ///
    ///
    /// Fun yiyan ailewu wo [`split_at`].
    ///
    /// # Safety
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro jẹ *[ihuwasi ti a ko ṣalaye]* paapaa ti itọkasi itọkasi ko ba lo.Awọn olupe ni o ni lati rii daju wipe `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // Aabo: Olupe ni lati ṣayẹwo `0 <= mid <= self.len()` naa
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Pin ipin ege iyipada kan si meji ni itọka kan, laisi ṣe ayẹwo awọn igboro.
    ///
    /// Ni igba akọkọ ti yoo ni gbogbo awọn atọka lati `[0, mid)` (laisi atokọ `mid` funrararẹ) ati ekeji yoo ni gbogbo awọn atọka lati `[mid, len)` (laisi awọn atọka `len` funrararẹ).
    ///
    ///
    /// Fun yiyan ailewu wo [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Pipe ọna yii pẹlu itọka ti ita-igboro jẹ *[ihuwasi ti a ko ṣalaye]* paapaa ti itọkasi itọkasi ko ba lo.Awọn olupe ni o ni lati rii daju wipe `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // Aabo: Olupe ni lati ṣayẹwo `0 <= mid <= self.len()` naa.
        //
        // `[ptr; mid]` ati `[mid; len]` ko ni agbekọja, nitorinaa ipadabọ itọkasi iyipada kan dara.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Pada aṣetunṣe lori awọn ipin ti o yapa nipasẹ awọn eroja ti o baamu `pred`.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ti o ba ti akọkọ ano ti wa ni ti baamu, ohun ṣofo bibẹ yoo jẹ akọkọ ohun kan pada nipa awọn iterator.
    /// Bakan naa, ti o ba jẹ pe nkan ti o kẹhin ninu bibẹ pẹlẹbẹ naa ti baamu, ege ti o ṣofo yoo jẹ ohun ti o kẹhin ti a ti pada nipasẹ aṣetunṣe:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ti awọn eroja meji ti o baamu ba wa nitosi, taara nkan ti yoo ṣofo yoo wa laarin wọn:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Pada aṣetunṣe lori awọn ipin-ọja iyipada ti o yapa nipasẹ awọn eroja ti o baamu `pred`.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Pada aṣetunṣe lori awọn ipin ti o yapa nipasẹ awọn eroja ti o baamu `pred`.
    /// Ẹya ti o baamu wa ninu opin ifẹhinti iṣaaju bi ifopinsi.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ti o ba jẹ pe nkan ti o kẹhin ti bibẹ pẹlẹbẹ ti baamu, a yoo ṣe akiyesi eroja naa bi ẹni ti n fopin si bibẹrẹ ti tẹlẹ.
    ///
    /// Ige yẹn yoo jẹ ohun ti o kẹhin ti o pada nipasẹ aṣetunṣe.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Pada aṣetunṣe lori awọn ipin-ọja iyipada ti o yapa nipasẹ awọn eroja ti o baamu `pred`.
    /// Awọn ti baamu ano ti wa ni ti o wa ninu awọn ti tẹlẹ subslice bi a terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Pada aṣetunṣe lori awọn ipin-owo ti o yapa nipasẹ awọn eroja ti o baamu `pred`, bẹrẹ ni opin gige ati ṣiṣẹ sẹhin.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bii `split()`, ti o ba jẹ pe akọkọ tabi nkan ti o kẹhin ti baamu, nkan ti o ṣofo yoo jẹ nkan akọkọ (tabi ti o kẹhin) ti a ti da pada.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Pada aṣetunṣe lori awọn owo-ori iyipada ti o yapa nipasẹ awọn eroja ti o baamu `pred`, bẹrẹ ni opin gige ati ṣiṣẹ sẹhin.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Padà ohun iterator lori subslices niya nipa eroja ti o baramu `pred`, ni opin si pada ni julọ `n` awọn ohun kan.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// Ẹsẹ ikẹhin ti o pada, ti o ba jẹ eyikeyi, yoo ni iyoku ege naa.
    ///
    /// # Examples
    ///
    /// Tẹ sita awọn bibẹ pipin ni kete ti nipa awọn nọmba pelu 3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Padà ohun iterator lori subslices niya nipa eroja ti o baramu `pred`, ni opin si pada ni julọ `n` awọn ohun kan.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// Ẹsẹ ikẹhin ti o pada, ti o ba jẹ eyikeyi, yoo ni iyoku ege naa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Pada aṣetunṣe lori awọn ipin ti o yapa nipasẹ awọn eroja ti o baamu `pred` ni opin si ipadabọ ni ọpọlọpọ awọn ohun `n`.
    /// Yi bere ni opin ti awọn bibẹ ati iṣẹ arinsehin.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// Ẹsẹ ikẹhin ti o pada, ti o ba jẹ eyikeyi, yoo ni iyoku ege naa.
    ///
    /// # Examples
    ///
    /// Tẹjade pipin ege lẹẹkan, bẹrẹ lati opin, nipasẹ awọn nọmba ti a pin nipasẹ 3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Pada aṣetunṣe lori awọn ipin ti o yapa nipasẹ awọn eroja ti o baamu `pred` ni opin si ipadabọ ni ọpọlọpọ awọn ohun `n`.
    /// Yi bere ni opin ti awọn bibẹ ati iṣẹ arinsehin.
    /// Awọn ti baamu ano ni ko wa ninu awọn subslices.
    ///
    /// Ẹsẹ ikẹhin ti o pada, ti o ba jẹ eyikeyi, yoo ni iyoku ege naa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Pada `true` ti o ba jẹ pe ege naa ni eroja pẹlu iye ti a fun.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ti o ko ba ni `&T`, ṣugbọn `&U` kan ni iru `T: Borrow<U>` (fun apẹẹrẹ
    /// Okun: Yiya<str>`), o le lo `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ege ti `String`
    /// assert!(v.iter().any(|e| e == "hello")); // wa pẹlu `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Pada `true` ti o ba ti `needle` ni a ìpele ti awọn bibẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Nigbagbogbo da `true` pada ti `needle` ba jẹ nkan ti o ṣofo:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Pada `true` ti `needle` ba jẹ suffix ti ege naa.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Nigbagbogbo da `true` pada ti `needle` ba jẹ nkan ti o ṣofo:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Pada a subslice pẹlu awọn ìpele kuro.
    ///
    /// Ti bibẹrẹ naa ba bẹrẹ pẹlu `prefix`, o tun ṣe atun-pada lẹhin ti akọṣaaju, ti a we ni `Some`.
    /// Ti `prefix` ba ṣofo, nirọrun da ẹyọ atilẹba pada.
    ///
    /// Ti bibẹrẹ ko ba bẹrẹ pẹlu `prefix`, o pada `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Iṣẹ yi yoo nilo rewriting ti o ba ti ati nigbati SlicePattern di diẹ fafa.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Ṣe ipadabọ-ọja kan pada pẹlu ti yọ kuro.
    ///
    /// Ti o ba ti bibẹ pari pẹlu `suffix`, ba pada awọn subslice ṣaaju ki awọn suffix, ti a we ni `Some`.
    /// Ti `suffix` ba ṣofo, daada pada bibẹ pẹlẹbẹ naa.
    ///
    /// Ti bibẹrẹ ko ba pari pẹlu `suffix`, o pada `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Iṣẹ yi yoo nilo rewriting ti o ba ti ati nigbati SlicePattern di diẹ fafa.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Alakomeji wa iru nkan ti a ṣe lẹsẹsẹ fun nkan ti a fun.
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.
    /// Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    ///
    /// Wo tun [`binary_search_by`], [`binary_search_by_key`], ati [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nwa soke kan lẹsẹsẹ ti mẹrin eroja.
    /// Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ti o ba fẹ fi ohun kan sii si vector ti a ṣe lẹsẹsẹ, lakoko ti o n ṣetọju aṣẹ lẹsẹsẹ:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Alakomeji n wa iru nkan ti a ṣe lẹsẹsẹ pẹlu iṣẹ afiwe kan.
    ///
    /// Iṣẹ iṣapẹẹrẹ yẹ ki o ṣe aṣẹ ti o ni ibamu pẹlu irufẹ iru nkan ti o wa ni isalẹ, dapada koodu aṣẹ ti o tọka boya ariyanjiyan rẹ jẹ `Less`, `Equal` tabi `Greater` afojusun ti o fẹ.
    ///
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    /// Wo tun [`binary_search`], [`binary_search_by_key`], ati [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Nwa soke kan lẹsẹsẹ ti mẹrin eroja.Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // Aabo: ipe naa ni aabo nipasẹ awọn alailewu atẹle:
            // - `mid >= 0`
            // - `mid < size`: `mid` wa ni opin nipa `[left; right)` dè.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Awọn idi idi ti a lo if/else Iṣakoso sisan kuku ju baramu jẹ nitori baramu reorders lafiwe mosi, ti o jẹ perf kókó.
            //
            // Eyi ni x86 asm fun u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Alakomeji awọrọojulówo yi lẹsẹsẹ bibẹ pẹlu kan bọtini isediwon iṣẹ.
    ///
    /// Dawọle pe bibẹ naa ti to lẹsẹsẹ nipasẹ bọtini, fun apẹẹrẹ pẹlu [`sort_by_key`] nipa lilo iṣẹ isediwon bọtini kanna.
    ///
    /// Ti a ba rii iye naa lẹhinna [`Result::Ok`] ti pada, ti o ni itọka ti eroja ti o baamu.
    /// Ti awọn ere-kere lọpọlọpọ ba wa, lẹhinna eyikeyi ọkan ninu awọn ere-kere le ṣee pada.
    /// Ti a ko ba rii iye naa lẹhinna [`Result::Err`] ti pada, ti o ni atọka nibiti o le fi nkan ti o baamu sii lakoko mimu eto tito lẹsẹsẹ.
    ///
    ///
    /// Wo tun [`binary_search`], [`binary_search_by`], ati [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Wulẹ lẹsẹsẹ awọn eroja mẹrin ninu ege ege meji ti a to lẹsẹsẹ nipasẹ awọn eroja keji wọn.
    /// Ni igba akọkọ ti a rii, pẹlu ipo iyasọtọ ti a pinnu;a ko ri ekeji ati iketa;ẹkẹrin le baamu eyikeyi ipo ni `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Ti gba Lint rustdoc::broken_intra_doc_links laaye bi `slice::sort_by_key` ti wa ni crate `alloc`, ati pe bii bẹẹ ko si sibẹ nigba kikọ `core`.
    //
    // ojúewé si ibosile crate: #74481.Niwon primitives ti wa ni nikan ni akọsilẹ ninu libstd (#73423), yi kò nyorisi si dà ìjápọ ni iwa.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Awọn iru nkan, ṣugbọn ko le ṣe itọju aṣẹ ti awọn eroja dogba.
    ///
    /// Irufẹ yii jẹ riru (ie, le tunto awọn eroja to dogba), ni aaye (ie, ko ṣe ipin), ati *O*(*n*\*log(* n*)) buru-nla.
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori [pattern-defeating quicksort][pdqsort] nipasẹ Orson Peters, eyiti o ṣe idapọ ọrọ ọran ti o yara iyara ti iyara oninọrun pẹlu ọran ti o buru ju ti akopọ, lakoko ti o ṣaṣeyọri akoko laini lori awọn ege pẹlu awọn ilana kan.
    /// O nlo diẹ ninu iyatọ lati yago fun awọn ọran ibajẹ, ṣugbọn pẹlu seed ti o wa titi lati pese ihuwasi ṣiṣe ipinnu nigbagbogbo.
    ///
    /// O jẹ igbagbogbo yiyara ju tito lẹsẹsẹ idurosinsin, ayafi ni awọn ọran pataki diẹ, fun apẹẹrẹ, nigbati gige naa ba ni ọpọlọpọ awọn lẹsẹsẹ lẹsẹsẹ ti a ṣe pọpọ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Too bibẹ pẹlu iṣẹ afiwera, ṣugbọn o le ma ṣetọju aṣẹ awọn eroja to dogba.
    ///
    /// Irufẹ yii jẹ riru (ie, le tunto awọn eroja to dogba), ni aaye (ie, ko ṣe ipin), ati *O*(*n*\*log(* n*)) buru-nla.
    ///
    /// Iṣẹ afiwera gbọdọ ṣalaye aṣẹ-aṣẹ lapapọ fun awọn eroja inu ege.Ti aṣẹ ko ba jẹ apapọ, aṣẹ ti awọn eroja ko ṣalaye.Ibere jẹ aṣẹ lapapọ ti o ba jẹ (fun gbogbo `a`, `b` ati `c`):
    ///
    /// * lapapọ ati antisymmetric: deede ọkan ninu `a < b`, `a == b` tabi `a > b` jẹ otitọ, ati
    /// * transitive, `a < b` ati `b < c` tumọ si `a < c`.Kanna gbọdọ mu fun `==` ati `>` mejeeji.
    ///
    /// Fun apẹẹrẹ, lakoko ti [`f64`] ko ṣe imuse [`Ord`] nitori `NaN != NaN`, a le lo `partial_cmp` bi iru iṣẹ wa nigbati a mọ pe ege naa ko ni `NaN` kan.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori [pattern-defeating quicksort][pdqsort] nipasẹ Orson Peters, eyiti o ṣe idapọ ọrọ ọran ti o yara iyara ti iyara oninọrun pẹlu ọran ti o buru ju ti akopọ, lakoko ti o ṣaṣeyọri akoko laini lori awọn ege pẹlu awọn ilana kan.
    /// O nlo diẹ ninu iyatọ lati yago fun awọn ọran ibajẹ, ṣugbọn pẹlu seed ti o wa titi lati pese ihuwasi ṣiṣe ipinnu nigbagbogbo.
    ///
    /// O jẹ igbagbogbo yiyara ju tito lẹsẹsẹ idurosinsin, ayafi ni awọn ọran pataki diẹ, fun apẹẹrẹ, nigbati gige naa ba ni ọpọlọpọ awọn lẹsẹsẹ lẹsẹsẹ ti a ṣe pọpọ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // yiyipada ayokuro
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Awọn ege bibẹ pẹlu iṣẹ isediwon bọtini, ṣugbọn o le ma ṣe tọju aṣẹ ti awọn eroja dogba.
    ///
    /// Iru iru yii jẹ riru (ie, le tunto awọn eroja to dogba), ni aaye (ie, ko ṣe ipin), ati *O*(m\* * n *\* log(*n*)) buru-nla, nibiti iṣẹ bọtini jẹ *O*(*m*).
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori [pattern-defeating quicksort][pdqsort] nipasẹ Orson Peters, eyiti o ṣe idapọ ọrọ ọran ti o yara iyara ti iyara oninọrun pẹlu ọran ti o buru ju ti akopọ, lakoko ti o ṣaṣeyọri akoko laini lori awọn ege pẹlu awọn ilana kan.
    /// O nlo diẹ ninu iyatọ lati yago fun awọn ọran ibajẹ, ṣugbọn pẹlu seed ti o wa titi lati pese ihuwasi ṣiṣe ipinnu nigbagbogbo.
    ///
    /// Nitori imọran pipe bọtini rẹ, [`sort_unstable_by_key`](#method.sort_unstable_by_key) le jẹ ki o lọra ju [`sort_by_cached_key`](#method.sort_by_cached_key) ni awọn ọran nibiti iṣẹ bọtini ṣe gbowolori.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ṣe atunto bibẹ pẹlẹbẹ pe eroja ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Ṣe atunto bibẹ pẹlu iṣẹ alafiwe iru nkan ti o wa ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Ṣe atunto bibẹ pẹlu iṣẹ isediwon bọtini bii pe eroja ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Ṣe atunto bibẹ pẹlẹbẹ pe eroja ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    ///
    /// Reordering yii ni ohun-ini afikun pe eyikeyi iye ni ipo `i < index` yoo kere tabi dọgba pẹlu eyikeyi iye ni ipo `j > index` kan.
    /// Ni afikun, atunṣe yii jẹ riru (ie
    /// nọmba eyikeyi ti awọn eroja ti o dọgba le pari ni ipo `index`), ni aye (ie
    /// ko ṣe ipinfunni), ati *O*(*n*) ọran ti o buru julọ.
    /// Iṣẹ yii tun jẹ/mọ bi "kth element" ni awọn ile-ikawe miiran.
    /// O da ẹẹmẹta pada ti awọn iye atẹle: gbogbo awọn eroja ti o kere ju ọkan lọ ni itọka ti a fun, iye ni itọka ti a fun, ati gbogbo awọn eroja ti o tobi ju ọkan lọ ni atọka ti a fun.
    ///
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori ipin yiyan kiakia ti algorithm ọna iyara kanna ti a lo fun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nigbati `index >= len()`, tumọ si pe nigbagbogbo panics lori awọn ege ofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Wa agbedemeji
    /// v.select_nth_unstable(2);
    ///
    /// // A jẹ ẹri nikan fun bibẹ pẹlẹbẹ naa yoo jẹ ọkan ninu atẹle, da lori ọna ti a ṣe to lẹsẹsẹ nipa atọka pàtó kan.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ṣe atunto bibẹ pẹlu iṣẹ alafiwe iru nkan ti o wa ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    ///
    /// Reordering yii ni ohun-ini afikun pe eyikeyi iye ni ipo `i < index` yoo kere tabi dọgba pẹlu eyikeyi iye ni ipo `j > index` nipa lilo iṣẹ afiwera.
    /// Ni afikun, atunṣe yii jẹ riru (ie eyikeyi nọmba ti awọn eroja ti o dọgba le pari ni ipo `index`), ni aaye (ie ko ṣe ipin), ati *O*(*n*) ọran ti o buru julọ.
    /// Iṣẹ yii ni a tun mọ ni "kth element" ni awọn ile-ikawe miiran.
    /// O da ẹẹmẹta pada ti awọn iye atẹle: gbogbo awọn eroja ti o kere ju ọkan lọ ni itọka ti a fun, iye ni itọka ti a fun, ati gbogbo awọn eroja ti o tobi ju ọkan lọ ni itọka ti a fun, ni lilo iṣẹ afiwepọ ti a pese.
    ///
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori ipin yiyan kiakia ti algorithm ọna iyara kanna ti a lo fun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nigbati `index >= len()`, tumọ si pe nigbagbogbo panics lori awọn ege ofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Wa agbedemeji bi ẹnipe a ti to nkan ge ni tito isalẹ.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // A jẹ ẹri nikan fun bibẹ pẹlẹbẹ naa yoo jẹ ọkan ninu atẹle, da lori ọna ti a ṣe to lẹsẹsẹ nipa atọka pàtó kan.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Ṣe atunto bibẹ pẹlu iṣẹ isediwon bọtini bii pe eroja ni `index` wa ni ipo lẹsẹsẹ ipari rẹ.
    ///
    /// Reordering yii ni ohun-ini afikun pe eyikeyi iye ni ipo `i < index` yoo kere tabi dọgba pẹlu eyikeyi iye ni ipo `j > index` nipa lilo iṣẹ isediwon bọtini.
    /// Ni afikun, atunṣe yii jẹ riru (ie eyikeyi nọmba ti awọn eroja ti o dọgba le pari ni ipo `index`), ni aaye (ie ko ṣe ipin), ati *O*(*n*) ọran ti o buru julọ.
    /// Iṣẹ yii ni a tun mọ ni "kth element" ni awọn ile-ikawe miiran.
    /// O da ẹẹmẹta pada ti awọn iye atẹle: gbogbo awọn eroja ti o kere si ọkan ni itọka ti a fun, iye ni itọka ti a fun, ati gbogbo awọn eroja ti o tobi ju ọkan lọ ni itọka ti a fun, ni lilo iṣẹ isediwon bọtini ti a pese.
    ///
    ///
    /// # Imuse lọwọlọwọ
    ///
    /// Alugoridimu ti o wa lọwọlọwọ da lori ipin yiyan kiakia ti algorithm ọna iyara kanna ti a lo fun [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics nigbati `index >= len()`, tumọ si pe nigbagbogbo panics lori awọn ege ofo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Da agbedemeji pada bi ẹnipe a to lẹsẹsẹ ni ibamu si iye to pe.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // A jẹ ẹri nikan fun bibẹ pẹlẹbẹ naa yoo jẹ ọkan ninu atẹle, da lori ọna ti a ṣe to lẹsẹsẹ nipa atọka pàtó kan.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Rare gbogbo awọn eroja ti a tun ṣe leralera si opin gige ni ibamu si imuse [`PartialEq`] trait.
    ///
    ///
    /// Pada meji ege.Ni igba akọkọ ti ko ni itẹlera tun eroja.
    /// Secondkeji ni gbogbo awọn ẹda-ẹda ni aṣẹ ti a ko sọ tẹlẹ.
    ///
    /// Ti o ba ti ṣa nkan naa, ege akọkọ ti o pada ko ni awọn ẹda-ẹda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Rare gbogbo ṣugbọn akọkọ ti awọn eroja itẹlera si opin ege naa ni itẹlọrun ibatan ibatan ti a fifun.
    ///
    /// Pada meji ege.Ni igba akọkọ ti ko ni itẹlera tun eroja.
    /// Secondkeji ni gbogbo awọn ẹda-ẹda ni aṣẹ ti a ko sọ tẹlẹ.
    ///
    /// The `same_bucket` iṣẹ wa ni koja jo si meji eroja lati bibẹ ati ki o gbọdọ mọ ti o ba awọn eroja afiwe dogba.
    /// Awọn eroja naa ti kọja ni aṣẹ idakeji lati aṣẹ wọn ni ege, nitorinaa ti `same_bucket(a, b)` ba pada `true`, `a` ti gbe ni opin gige.
    ///
    ///
    /// Ti o ba ti ṣa nkan naa, ege akọkọ ti o pada ko ni awọn ẹda-ẹda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Botilẹjẹpe a ni itọkasi iyipada si `self`, a ko le ṣe awọn ayipada *lainidii*.Awọn ipe `same_bucket` le panic, nitorinaa a gbọdọ rii daju pe ege naa wa ni ipo to wulo ni gbogbo igba.
        //
        // Awọn ọna ti a mu yi ni nipa lilo swaps;a ṣe itọju lori gbogbo awọn eroja, yiyi pada bi a ti nlọ ki ni ipari awọn eroja ti a fẹ lati tọju wa ni iwaju, ati pe awọn ti a fẹ lati kọ wa ni ẹhin.
        // Lẹhinna a le pin nkan naa.
        // Iṣẹ yii tun jẹ `O(n)`.
        //
        // Apere: A bẹrẹ ni ipinle yi, ni ibi ti `r` o duro "tókàn
        // ka "ati `w` o duro" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ifiwera self[r] lodi si ara ẹni [w-1], eyi kii ṣe ẹda meji, nitorinaa a ṣe paṣipaarọ self[r] ati self[w] (ko si ipa bi r==w) ati lẹhinna alekun mejeeji r ati w, nlọ wa pẹlu:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ifiwera self[r] si ara ẹni [w-1], iye yii jẹ ẹda-ẹda, nitorina a ṣe afikun `r` ṣugbọn fi ohun gbogbo miiran silẹ ko yipada:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ifiwera self[r] si ara ẹni [w-1], eyi kii ṣe ẹda meji, nitorinaa yi self[r] ati self[w] pada ki o si ni ilosiwaju r ati w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Kii ṣe ẹda-ẹda, tun ṣe:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Pidánpidán, advance r. End ti bibẹ.Pin ni w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // Aabo: awọn `while` majemu onigbọwọ `next_read` ati `next_write`
        // kere ju `len`, nitorinaa o wa ninu `self`.
        // `prev_ptr_write` ojuami si ọkan ano ṣaaju ki o to `ptr_write`, ṣugbọn `next_write` bere ni 1, ki `prev_ptr_write` kò kere ju 0 ki o si jẹ inu awọn bibẹ.
        // Eyi mu awọn ibeere ṣẹ fun fifagilee `ptr_read`, `prev_ptr_write` ati `ptr_write`, ati fun lilo `ptr.add(next_read)`, `ptr.add(next_write - 1)` ati `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` tun jẹ afikun ni pupọ lẹẹkan fun lupu ni itumọ pupọ julọ ko si eroja ti a foju nigbati o le nilo lati paarọ.
        //
        // `ptr_read` ati `prev_ptr_write` ko tọka si eroja kanna.Eyi ni a nilo fun `&mut *ptr_read`, `&mut* prev_ptr_write` lati wa ni ailewu.
        // Alaye naa jẹ pe `next_read >= next_write` jẹ otitọ nigbagbogbo, nitorinaa `next_read > next_write - 1` paapaa.
        //
        //
        //
        //
        //
        unsafe {
            // Yago fun awọn sọwedowo aala nipa lilo awọn atọka aise.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Rare gbogbo ṣugbọn akọkọ ti awọn eroja itẹlera si opin nkan ti o yanju si bọtini kanna.
    ///
    ///
    /// Pada meji ege.Ni igba akọkọ ti ko ni itẹlera tun eroja.
    /// Secondkeji ni gbogbo awọn ẹda-ẹda ni aṣẹ ti a ko sọ tẹlẹ.
    ///
    /// Ti o ba ti ṣa nkan naa, ege akọkọ ti o pada ko ni awọn ẹda-ẹda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// N yi ege ni ipo nitori pe awọn eroja `mid` akọkọ ti ege naa gbe si opin lakoko ti awọn eroja `self.len() - mid` to kẹhin gbe si iwaju.
    /// Lẹhin pipe `rotate_left`, eroja tẹlẹ ni itọka `mid` yoo di eroja akọkọ ninu ege.
    ///
    /// # Panics
    ///
    /// Iṣẹ yi yio panic ti o ba ti `mid` ni o tobi ju awọn ipari ti awọn bibẹ.Akiyesi pe `mid == self.len()` ṣe _not_ panic ati pe o jẹ iyipo ti kii-op.
    ///
    /// # Complexity
    ///
    /// Gba laini (ni akoko `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Yiyi a subslice:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // Aabo: Iwọn `[p.add(mid) - mid, p.add(mid) + k)` jẹ ohun ti ko nira
        // wulo fun kika ati kikọ, bi o ṣe nilo nipasẹ `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rotates awọn bibẹ ni-ibi iru awọn ti akọkọ `self.len() - k` eroja ti awọn bibẹ Gbe lati opin nigba ti awọn ti o kẹhin `k` eroja gbe si iwaju.
    /// Lẹhin pipe `rotate_right`, eroja tẹlẹ ni itọka `self.len() - k` yoo di eroja akọkọ ninu ege.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo jẹ panic ti `k` ba tobi ju ipari ti ege naa.Akiyesi pe `k == self.len()` ṣe _not_ panic ati pe o jẹ iyipo ti kii-op.
    ///
    /// # Complexity
    ///
    /// Gba laini (ni akoko `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// N yi ijẹrisi kan:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // Aabo: Iwọn `[p.add(mid) - mid, p.add(mid) + k)` jẹ ohun ti ko nira
        // wulo fun kika ati kikọ, bi o ṣe nilo nipasẹ `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Kun `self` pẹlu awọn eroja nipasẹ cloning `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Kún `self` pẹlu eroja pada nipa pipe a bíbo leralera.
    ///
    /// Yi ọna ti nlo a bíbo lati ṣẹda titun síi.Ti o ba fẹ kuku [`Clone`] iye ti a fun, lo [`fill`].
    /// Ti o ba fẹ lo [`Default`] trait lati ṣe awọn iye, o le kọja [`Default::default`] bi ariyanjiyan.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Dakọ awọn eroja lati `src` sinu `self`.
    ///
    /// Gigun ti `src` gbọdọ jẹ bakanna bi `self`.
    ///
    /// Ti `T` ba ṣe `Copy`, o le jẹ oluṣe diẹ sii lati lo [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo panic ti awọn ege meji ni awọn gigun oriṣiriṣi.
    ///
    /// # Examples
    ///
    /// Ṣiṣẹda awọn eroja meji lati ori nkan sinu omiran:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Nitori awọn ege yẹ ki o jẹ gigun kanna, a ge nkan bibẹ orisun lati awọn eroja mẹrin si meji.
    /// // Yoo panic ti a ko ba ṣe eyi.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust mu lagabara pe o le jẹ itọkasi itọkasi ọkan nikan laisi awọn itọkasi ti ko le yipada si apakan kan pato data ni aaye kan pato.
    /// Nitori eyi, igbiyanju lati lo `clone_from_slice` lori ẹyọ kan ṣoṣo yoo ja si ikuna ikojọpọ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Lati ṣiṣẹ ni ayika eyi, a le lo [`split_at_mut`] lati ṣẹda awọn ege kekere meji ti o yatọ lati ege kan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Dakọ gbogbo awọn eroja lati `src` sinu `self`, ni lilo memcpy kan.
    ///
    /// Gigun ti `src` gbọdọ jẹ bakanna bi `self`.
    ///
    /// Ti `T` ko ba ṣe `Copy`, lo [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo panic ti awọn ege meji ni awọn gigun oriṣiriṣi.
    ///
    /// # Examples
    ///
    /// Didakọ awọn eroja meji lati ori nkan sinu omiran:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Nitori awọn ege yẹ ki o jẹ gigun kanna, a ge nkan bibẹ orisun lati awọn eroja mẹrin si meji.
    /// // Yoo panic ti a ko ba ṣe eyi.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust mu lagabara pe o le jẹ itọkasi itọkasi ọkan nikan laisi awọn itọkasi ti ko le yipada si apakan kan pato data ni aaye kan pato.
    /// Nitori eyi, igbiyanju lati lo `copy_from_slice` lori ẹyọ kan ṣoṣo yoo ja si ikuna ikojọpọ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Lati ṣiṣẹ ni ayika eyi, a le lo [`split_at_mut`] lati ṣẹda awọn ege kekere meji ti o yatọ lati ege kan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // The panic koodu ona ti a fi sinu kan tutu iṣẹ lati ko Bloat awọn ipe sii.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // Aabo: `self` wulo fun awọn eroja `self.len()` nipasẹ itumọ, ati pe `src` jẹ
        // ẹnikeji to ni kanna ipari.
        // Awọn ege ko le ni lqkan nitori mutable jo ni o wa iyasoto.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Idaako eroja lati apá kan ti bibẹ si miiran ara ti ara, nipa lilo a memmove.
    ///
    /// `src` ni ibiti o wa laarin `self` lati daakọ lati.
    /// `dest` jẹ itọka ibẹrẹ ti ibiti o wa laarin `self` lati daakọ si, eyiti yoo ni ipari kanna bi `src`.
    /// Awọn sakani meji naa le bori.
    /// Awọn opin ti awọn sakani meji gbọdọ jẹ kere ju tabi dogba si `self.len()`.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo jẹ panic ti boya ibiti o ba kọja opin ege, tabi ti opin `src` ba wa ṣaaju ibẹrẹ.
    ///
    ///
    /// # Examples
    ///
    /// Didakọ awọn baiti mẹrin laarin ege kan:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // Aabo: awọn ipo fun `ptr::copy` ti gbogbo ti ẹnikeji loke,
        // bi ni awọn wọnyẹn fun `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Swaps gbogbo awọn eroja ni `self` pẹlu awọn ti o wa ni `other`.
    ///
    /// Gigun ti `other` gbọdọ jẹ bakanna bi `self`.
    ///
    /// # Panics
    ///
    /// Iṣẹ yii yoo panic ti awọn ege meji ni awọn gigun oriṣiriṣi.
    ///
    /// # Example
    ///
    /// Piparọ awọn eroja meji kọja awọn ege:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ṣe imuṣẹ pe o le jẹ itọkasi iyipada ọkan nikan si nkan data kan ni aaye kan pato.
    ///
    /// Nitori eyi, pinnu lati lo `swap_with_slice` lori kan nikan bibẹ yoo ja si ni a sakojo ikuna:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Lati ṣiṣẹ ni ayika eyi, a le lo [`split_at_mut`] lati ṣẹda awọn ege kekere ti o le yipada pupọ meji lati ege kan:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // Aabo: `self` wulo fun awọn eroja `self.len()` nipasẹ itumọ, ati pe `src` jẹ
        // ẹnikeji to ni kanna ipari.
        // Awọn ege ko le ni lqkan nitori mutable jo ni o wa iyasoto.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Iṣẹ lati ṣe iṣiro awọn gigun ti aarin ati gige pẹlẹbẹ fun `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ohun ti a fẹ ṣe nipa `rest` jẹ iṣiro kini ọpọ ti `U`s ti a le fi sinu nọmba ti o kere julọ ti`T`s.
        //
        // Ati pe melo `T`s ti a nilo fun ọkọọkan iru "multiple".
        //
        // Ro fun apẹẹrẹ T=u8 U=u16.Lẹhinna a le fi 1 U sinu 2 Ts.Rọrun.
        // Bayi, ro fun apẹẹrẹ a irú ibi ti size_of: :<T>=16, iwọn_of::<U>=24.</u>
        // A le fi 2 Wa ni ibi ti gbogbo 3 Esi ni `rest` bibẹ.
        // A bit diẹ idiju.
        //
        // Agbekalẹ lati ṣe iṣiro yi ni:
        //
        // Wa= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Esi= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ti fẹ ati irọrun:
        //
        // Wa=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Esi=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Oriire niwon gbogbo eyi jẹ iṣiro-igbagbogbo ... iṣẹ nibi ko ṣe pataki!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algorithm stein iterative A yẹ ki o tun ṣe `const fn` yii (ki o pada si algorithm recursive ti a ba ṣe) nitori gbigbekele llvm lati sọ gbogbo eyi jẹ…daradara, o mu mi korọrun.
            //
            //

            // Aabo: `a` ati `b` ti ṣayẹwo lati jẹ awọn iye ti kii-odo.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // yọ gbogbo awọn ifosiwewe ti 2 kuro lati b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // Aabo: `b` wa ni ẹnikeji lati wa ni ti kii-odo.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Ologun pẹlu imọ yii, a le wa ọpọlọpọ `U`s ti a le baamu!
        let us_len = self.len() / ts * us;
        // Ati pe `T`s melo ni yoo wa ninu pẹlẹbẹ ti o tẹle!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Ṣe iyipada bibẹ pẹlẹbẹ si ege ti iru miiran, ni idaniloju titete awọn oriṣi ti wa ni itọju.
    ///
    /// Ọna yii pin awọn ege si awọn ege mẹta ti o yatọ: prefix, bibẹrẹ aarin pẹkipẹki ti iru tuntun, ati bibẹ pẹpẹ suffix.
    /// Ọna naa le jẹ ki gige aarin naa gun gigun nla ti o ṣeeṣe fun iru ti a fifun ati bibẹ pẹlẹbẹ titẹ sii, ṣugbọn iṣẹ ṣiṣe algorithm rẹ nikan ni o yẹ ki o da le lori, kii ṣe atunṣe rẹ.
    ///
    /// O jẹ iyọọda fun gbogbo data iwọle lati da pada bi ṣaju tabi fifọ iru-nkan.
    ///
    /// Ọna yii ko ni idi nigbati boya eroja titẹ sii `T` tabi eroja ti o wu `U` jẹ iwọn-odo ati pe yoo pada bibẹ pẹlẹbẹ atilẹba laisi pipin ohunkohun.
    ///
    /// # Safety
    ///
    /// Ọna yii jẹ pataki `transmute` pẹlu ọwọ si awọn eroja ti o wa ni pẹlẹbẹ aarin ti o pada, nitorinaa gbogbo awọn ikilọ deede ti o jẹ ti `transmute::<T, U>` tun waye nibi.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Akiyesi pe pupọ julọ iṣẹ yii yoo jẹ iṣiro nigbagbogbo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // mu awọn ZST ṣe pataki, eyiti o jẹ-maṣe mu wọn rara.
            return (self, &[], &[]);
        }

        // Ni akọkọ, wa ni aaye wo ni a pin laarin ipin akọkọ ati 2nd.
        // Rọrun pẹlu ptr.align_offset.
        let ptr = self.as_ptr();
        // Aabo: Wo ọna `align_to_mut` fun asọye aabo alaye.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // Aabo: Nisisiyi `rest` ti wa ni deede deedee, nitorinaa `from_raw_parts` ni isalẹ dara,
            // nitoriti olupe ṣe onigbọwọ pe a le ṣe transmute `T` si `U` lailewu.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Ṣe iyipada bibẹ pẹlẹbẹ si ege ti iru miiran, ni idaniloju titete awọn oriṣi ti wa ni itọju.
    ///
    /// Ọna yii pin awọn ege si awọn ege mẹta ti o yatọ: prefix, bibẹrẹ aarin pẹkipẹki ti iru tuntun, ati bibẹ pẹpẹ suffix.
    /// Ọna naa le jẹ ki gige aarin naa gun gigun nla ti o ṣeeṣe fun iru ti a fifun ati bibẹ pẹlẹbẹ titẹ sii, ṣugbọn iṣẹ ṣiṣe algorithm rẹ nikan ni o yẹ ki o da le lori, kii ṣe atunṣe rẹ.
    ///
    /// O jẹ iyọọda fun gbogbo data iwọle lati da pada bi ṣaju tabi fifọ iru-nkan.
    ///
    /// Ọna yii ko ni idi nigbati boya eroja titẹ sii `T` tabi eroja ti o wu `U` jẹ iwọn-odo ati pe yoo pada bibẹ pẹlẹbẹ atilẹba laisi pipin ohunkohun.
    ///
    /// # Safety
    ///
    /// Ọna yii jẹ pataki `transmute` pẹlu ọwọ si awọn eroja ti o wa ni pẹlẹbẹ aarin ti o pada, nitorinaa gbogbo awọn ikilọ deede ti o jẹ ti `transmute::<T, U>` tun waye nibi.
    ///
    /// # Examples
    ///
    /// Ipilẹ lilo:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Akiyesi pe pupọ julọ iṣẹ yii yoo jẹ iṣiro nigbagbogbo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // mu awọn ZST ṣe pataki, eyiti o jẹ-maṣe mu wọn rara.
            return (self, &mut [], &mut []);
        }

        // Ni akọkọ, wa ni aaye wo ni a pin laarin ipin akọkọ ati 2nd.
        // Rọrun pẹlu ptr.align_offset.
        let ptr = self.as_ptr();
        // Aabo: Nibi a n rii daju pe a yoo lo awọn itọka titọ fun U fun awọn
        // isinmi ti ọna.Eleyi ni a ṣe nipa ran a ijuboluwole si&[T] pẹlu ohun titete ìfọkànsí fun U.
        // `crate::ptr::align_offset` ni a pe pẹlu titọka deede ati ijuboluwole `ptr` (o wa lati itọka si `self`) ati pẹlu iwọn ti o jẹ agbara ti meji (nitori o wa lati titọ fun U), ni itẹlọrun awọn idiwọ aabo rẹ.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // A ko le lo `rest` lẹẹkansi lẹhin eyi, iyẹn yoo sọ asan inagijẹ `mut_ptr` rẹ di asan!Aabo: wo awọn asọye fun `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Awọn iṣayẹwo ti o ba ti to awọn eroja ti bibẹ pẹlẹbẹ yii.
    ///
    /// Iyẹn ni pe, fun eroja kọọkan `a` ati eroja atẹle rẹ `b`, `a <= b` gbọdọ mu.Ti o ba jẹ pe nkan naa n pese odo gangan tabi eroja kan, `true` ti pada.
    ///
    /// Akọsilẹ wipe ti o ba `Self::Item` jẹ nikan `PartialOrd`, sugbon ko `Ord`, awọn loke definition tumo si pe yi iṣẹ padà `false` o ba ti eyikeyi meji itẹlera ohun ni o wa ko afiwera.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Awọn sọwedowo ti awọn eroja ti bibẹ pẹlẹbẹ yii ti to lẹsẹsẹ nipa lilo iṣẹ afiwewe ti a fun.
    ///
    /// Dipo ti lilo `PartialOrd::partial_cmp`, iṣẹ yi nlo awọn ti fi fun `compare` iṣẹ lati mọ awọn bere fun ti awọn meji eroja.
    /// Yato si lati pe, o ni deede to [`is_sorted`];wo iwe rẹ fun alaye diẹ sii.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Awọn sọwedowo ti awọn eroja ti bibẹ pẹlẹbẹ yii ba to lẹsẹsẹ nipa lilo iṣẹ isediwon bọtini ti a fun.
    ///
    /// Dipo ifiwera awọn eroja ege taara, iṣẹ yii ṣe afiwe awọn bọtini ti awọn eroja, gẹgẹ bi ipinnu nipasẹ `f`.
    /// Yato si lati pe, o ni deede to [`is_sorted`];wo iwe rẹ fun alaye diẹ sii.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Pada itọka ti aaye ipin ni ibamu si asọtẹlẹ ti a fun (itọka ti eroja akọkọ ti ipin keji).
    ///
    /// A gbero nkan naa lati pin gẹgẹ bi asọtẹlẹ ti a fifun.
    /// Eyi tumọ si pe gbogbo awọn eroja fun eyiti asọtẹlẹ asọtẹlẹ pada jẹ otitọ ni bibẹrẹ ati gbogbo awọn eroja fun eyiti asọtẹlẹ asọtẹlẹ pada jẹ ni opin.
    ///
    /// Fun apẹẹrẹ, [7, 15, 3, 5, 4, 12, 6] jẹ ipin labẹ asọtẹlẹ x% 2!=0 (gbogbo awọn nọmba ajeji ni ibẹrẹ, gbogbo paapaa ni ipari).
    ///
    /// Ti a ko ba pin nkan yii, abajade ti o pada ko ni alaye ati pe ko ni itumọ, nitori ọna yii ṣe iru wiwa alakomeji kan.
    ///
    /// Wo tun [`binary_search`], [`binary_search_by`], ati [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // Aabo: Nigbati `left < right`, `left <= mid < right`.
            // Nitorinaa `left` maa n pọ si nigbagbogbo ati pe `right` maa n dinku nigbagbogbo, ati pe a yan ọkan ninu wọn.Ni awọn ọrọ mejeeji `left <= right` ni itẹlọrun.Nitorinaa ti `left < right` ni igbesẹ kan, `left <= right` ni itẹlọrun ni igbesẹ ti n tẹle.
            //
            // Nitorinaa niwọn igba `left != right`, `0 <= left < right <= len` ni itẹlọrun ati pe ti ọran yii `0 <= mid < len` ba ni itẹlọrun paapaa.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: A nilo lati ge wọn ni kedere si ipari kanna
        // lati jẹ ki o rọrun fun ẹrọ iṣapẹẹrẹ lati gbe awọn aala ṣayẹwo.
        // Ṣugbọn nitori ko le gbarale a tun ni amọja ti o fojuhan fun T: Ẹda.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Ṣẹda ege ti o ṣofo.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Ṣẹda gige gige ti o ni iyipada.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Awọn awoṣe ninu awọn ege, lọwọlọwọ, lo nikan nipasẹ `strip_prefix` ati `strip_suffix`.
/// Ni aaye future, a nireti lati ṣakopọ `core::str::Pattern` (eyiti o wa ni akoko kikọ ti ni opin si `str`) si awọn ege, ati lẹhinna trait yii ni yoo rọpo tabi paarẹ.
///
pub trait SlicePattern {
    /// Iru eroja ti ege naa baamu.
    type Item;

    /// Lọwọlọwọ, awọn alabara ti `SlicePattern` nilo gige kan.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}