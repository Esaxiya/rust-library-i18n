// Imuse atilẹba ti a gba lati rust-memchr.
// Aṣẹ-aṣẹ 2015 Andrew Gallant, awọn bluss ati Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Lo idinku.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Pada `true` ti `x` ba ni eyikeyi baiti odo ninu.
///
/// Lati *Awọn iṣiro Iṣiro*, J. Arndt:
///
/// `Ero ni lati ge iyokuro ọkan lati ọkọọkan awọn baiti ati lẹhinna wa awọn baiti nibiti awin ti ntan ni gbogbo ọna si pataki julọ
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Pada itọka akọkọ ti o baamu baiti `x` ni `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ona yara fun awọn ege kekere
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Ọlọjẹ fun iye baiti kan nipa kika awọn ọrọ `usize` meji ni akoko kan.
    //
    // Pin `text` ni awọn ẹya mẹta
    // - aiṣedede akọkọ ti ko ni deede, ṣaaju ọrọ akọkọ ti o baamu adirẹsi ninu ọrọ
    // - ara, ṣayẹwo nipasẹ awọn ọrọ 2 ni akoko kan
    // - apa ti o ku kẹhin, <Iwọn ọrọ

    // wa soke si ohun deedee ààlà
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // wa ara ti ọrọ naa
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // Aabo: awọn nigba ti ká predicate onigbọwọ kan ijinna ti o kere 2 * usize_bytes
        // laarin aiṣedeede ati opin bibẹ.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // fọ ti baiti baamu kan wa
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Wa baiti lẹhin ti aaye ti lupu ara duro.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Pada itọka ti o kẹhin ti o baamu baiti `x` ni `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Ọlọjẹ fun iye baiti kan nipa kika awọn ọrọ `usize` meji ni akoko kan.
    //
    // Pin `text` ni awọn ẹya mẹta:
    // - unaligned iru, lẹhin ti o kẹhin ọrọ deedee adiresi ni ọrọ,
    // - body, ti ṣayẹwo nipa 2 ọrọ ni akoko kan,
    // - akọkọ baiti ti o ku, <Iwọn ọrọ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // A pe eyi nikan lati gba gigun ti ṣaju ati suffix.
        // Ni aarin a ma n ṣe ilana awọn chunks meji ni ẹẹkan.
        // Aabo: gbigbe kaakiri `[u8]` si `[usize]` jẹ ailewu ayafi fun awọn iyatọ iwọn eyiti o ṣakoso nipasẹ `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Wa ara ti ọrọ naa, rii daju pe a ko rekọja min_aligned_offset.
    // aiṣedeede ti wa ni nigbagbogbo deedee, ki o kan igbeyewo `>` jẹ to ati ki o avoids ṣee ṣe kún.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // Aabo: aiṣedeede bẹrẹ ni len, suffix.len(), niwọn igba ti o tobi ju
        // min_aligned_offset (prefix.len()) awọn ti o ku ijinna ni o kere 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Fọ ti baiti ibaramu kan ba wa.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Wa baiti ṣaaju aaye ti lupu ara duro.
    text[..offset].iter().rposition(|elt| *elt == x)
}